# Nav.AI

Nav.AI is a web application designed to facilitate various processes at educational institutions. It leverages modern web technologies and integrates with several backend services to provide a seamless user experience.

## Table of Contents

- [Features](#features)
- [Technologies Used](#technologies-used)
- [Installation](#installation)
- [Environment Variables](#environment-variables)
- [Running the Application](#running-the-application)
- [Building the Application](#building-the-application)
- [Docker Deployment](#docker-deployment)
- [Contributing](#contributing)
- [License](#license)

## Features

- User authentication and authorization
- Dynamic content rendering
- Integration with backend services
- Responsive design
- Real-time data updates

## Technologies Used

- React
- TypeScript
- Vite
- React Router
- Bootstrap
- oidc-client-ts
- GSAP

## Installation

To get started with the project, follow these steps:

1. **Clone the repository:**

   ```sh
   git clone https://Data-AI-Studio-HPS-Europe@dev.azure.com/Data-AI-Studio-HPS-Europe/MaximumGPT/_git/maximum-gpt-app
   cd maximum-gpt-app
   ```

2. **Set up your .env** (Exemplary)

   ````APP_PORT=3000
   VITE_APP_CONTEXT_PATH=/maximumgpt
   VITE_BACKEND_BASE_URL=http://0.0.0.0:5002/api/v1/
   VITE_LOCAL_PROXY=http://0.0.0.0:3001/
   VITE_NVIDIA_VSS_BASE_URL=http://34.173.120.75:32481/
   VITE_APP_TOOLS_PREFIX="Nav.AI Tool - "
   VITE_REDIRECT_URI=http://0.0.0.0:3000```
   ````

3. **Building EQTY Policy Plane**

   ```
   git clone https://github.com/eqtylab/eqty-policy-plane.git ./eqty-source
   cd eqty-source
   pnpm install
   pnpm build
   cd dist
   cp * -R ../../src/components/eqty/policyplane/
   ```

4. **Running in Dev Mode**

   `pnpm dev`

## Building

1. `pnpm build`
2. `pnpm run preview --port 3000`

## Auto translate script

### 1. Set Environment Variables

Before running the script, set these in your terminal:

**Unix/macOS (`bash`, `zsh`):**

```bash
   export AZURE_OPENAI_API_KEY="xxxxxxxxxxxxxxxx"
   export AZURE_OPENAI_ENDPOINT="xxxxxxxxxxxxxxxxxx"
   export AZURE_OPENAI_DEPLOYMENT="xxxxxxxxxxxxxxxx"
```

**Windows PowerShell:**

```powershell
   $env:AZURE_OPENAI_API_KEY="xxxxxxxxxxxxxxxxxxxx"
   $env:AZURE_OPENAI_ENDPOINT="xxxxxxxxxxxxxxxxxxxxxxx"
   $env:AZURE_OPENAI_DEPLOYMENT="xxxxxxxxxxxxxxxxx"
```

---

### 2a. Add or Update a Single Key

If you want to add a single translation key under a specific object, run:

```bash
   node auto-translation.js "greetings.hello" "Hello there"
   # General format:
   node auto-translation.js "objectName.keyName" "Value"
```

**This will:**

- Add `greetings.hello` with the English value "Hello there" to `en.json`
- Automatically sync this key across all other translation files with AI translations

---

### 2b. If You're Adding Multiple New Keys

- Add the keys directly to `en.json`
- Then run:

```bash
   node auto-translation.js cleanup cleanup
```

**This will:**

- Fill missing keys in other languages
- Fix incorrect translations using GPT
- Sort keys alphabetically
- Regenerate type definitions

---

### 3. Auto-Generated Type Definitions

After syncing, the script auto-generates:

```
types/translation-key.ts
```

It exports a **flat constant object** like this:

```ts
export const TranslationKeys = {
  AGENTCARD_ADDBOOKMARK: "agentCard.addBookmark",
  AGENTCARD_EDIT: "agentCard.edit",
  ...
} as const;
```

---

### 🧑‍💻 4. Use Translations in Code

**Instead of:**

```ts
t("agentCard.addBookmark");
```

**Use:**

```ts
import { TranslationKeys } from "@/types/translation-key";

t(TranslationKeys.AGENTCARD_ADDBOOKMARK);
```

---

## To add a new language support

- Add a folder for the new language with the correct language code.
- Add a translation.json inside it and add empty bracket {} inside it.
- Run the auto translate script with cleanup as the key.
- Add the new translation language to i18n.tsx

## Testing & Coverage

**Run tests + tests coverage report**:

```bash
`pnpm test` : runs tests.
`pnpm test -- --coverage` : runs tests and generates coverage report.
```
