#!/bin/bash

# Quick Setup Script for New Developers
# This script sets up the development environment with all QC tools

echo "🚀 Setting up development environment..."
echo "======================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print status
print_status() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Check if pnpm is installed
if ! command -v pnpm &> /dev/null; then
    print_error "pnpm is not installed. Please install it first:"
    echo "npm install -g pnpm"
    exit 1
fi

print_status "pnpm found"

# Install dependencies
echo "📦 Installing dependencies..."
pnpm install

if [ $? -eq 0 ]; then
    print_status "Dependencies installed"
else
    print_error "Failed to install dependencies"
    exit 1
fi

# Initialize Husky (if not already done)
echo "🪝 Setting up Git hooks..."
pnpm prepare

if [ $? -eq 0 ]; then
    print_status "Git hooks configured"
else
    print_warning "Git hooks setup had issues (might already be configured)"
fi

# Test the setup
echo "🧪 Testing setup..."
echo ""

# Test lint-staged configuration
if grep -q "lint-staged" package.json; then
    print_status "lint-staged configured"
else
    print_error "lint-staged configuration missing"
fi

# Test Husky hooks
if [ -f ".husky/pre-commit" ] && [ -f ".husky/commit-msg" ] && [ -f ".husky/pre-push" ]; then
    print_status "All Git hooks present"
else
    print_warning "Some Git hooks might be missing"
fi

# Run initial validation
echo ""
echo "🔍 Running initial validation..."
pnpm format:check > /dev/null 2>&1
if [ $? -eq 0 ]; then
    print_status "Code formatting check passed"
else
    print_warning "Code formatting needs attention - run 'pnpm format' to fix"
fi

echo ""
echo "======================================"
echo -e "${GREEN}🎉 Setup completed successfully!${NC}"
echo ""
echo "📋 Next steps:"
echo "1. Install recommended VS Code extensions (see .vscode/extensions.json)"
echo "2. Read QC-SETUP.md for detailed documentation"
echo "3. Run 'pnpm validate' to test everything"
echo "4. Start developing with 'pnpm dev'"
echo ""
echo "🛠️ Useful commands:"
echo "  pnpm dev              # Start development server"
echo "  pnpm validate         # Run all quality checks"
echo "  pnpm fix-all          # Fix all auto-fixable issues"
echo "  pnpm type-check       # Check TypeScript types"
echo "  pnpm test             # Run tests"
echo ""
echo "📚 For more info, check:"
echo "  - QC-SETUP.md (Quality control documentation)"
echo "  - README.md (Project documentation)"
