import axios from "axios";
import fs from "fs";
import path from "path";

const TRANSLATION_PATH = "src/assets/locales";
const TYPES_PATH = "src/types";

// Azure OpenAI credentials from environment variables
const AZURE_API_KEY = process.env.AZURE_OPENAI_API_KEY;
const AZURE_ENDPOINT = "https://aiphuahhaiopai04.openai.azure.com";
const AZURE_DEPLOYMENT = "aip4d-gpt4o";
const AZURE_API_VERSION = "2024-02-15-preview";

// Validate required environment variables
if (!AZURE_API_KEY) {
  console.error("Error: Missing required Azure OpenAI environment variables");
  console.error("Please set AZURE_OPENAI_API_KEY");
  process.exit(1);
}

async function getLocales() {
  return fs.readdirSync(TRANSLATION_PATH).filter((file) => {
    const fullPath = path.join(TRANSLATION_PATH, file);
    return fs.statSync(fullPath).isDirectory();
  });
}

async function translate(text, targetLang) {
  if (targetLang === "en") return text;
  const prompt = `Translate the following text to ${targetLang}:\n"${text}"\nOnly return the translation.`;
  const url = `${AZURE_ENDPOINT}/openai/deployments/${AZURE_DEPLOYMENT}/chat/completions?api-version=${AZURE_API_VERSION}`;
  const headers = {
    "api-key": AZURE_API_KEY,
    "Content-Type": "application/json",
  };
  const data = {
    messages: [{ role: "user", content: prompt }],
    max_tokens: 100,
    temperature: 0.2,
  };
  const response = await axios.post(url, data, { headers });
  return response.data.choices[0].message.content.trim();
}

function setNested(obj, keys, value) {
  let current = obj;
  keys.forEach((key, idx) => {
    if (idx === keys.length - 1) {
      current[key] = value;
    } else {
      if (!current[key] || typeof current[key] !== "object") {
        current[key] = {};
      }
      current = current[key];
    }
  });
}

function sortObject(obj) {
  if (Array.isArray(obj)) {
    return obj.map(sortObject);
  } else if (obj !== null && typeof obj === "object") {
    return Object.keys(obj)
      .sort()
      .reduce((result, key) => {
        result[key] = sortObject(obj[key]);
        return result;
      }, {});
  }
  return obj;
}

async function getTranslationJson(locale) {
  const filePath = path.join(TRANSLATION_PATH, locale, "translation.json");
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

// Retry helper for async functions
async function retryAsync(fn, retries = 3, delay = 10000) {
  let lastError;
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (err) {
      lastError = err;
      console.error(`Attempt ${i + 1} failed: ${err.message}`);
      if (i < retries - 1) await new Promise((res) => setTimeout(res, delay));
    }
  }
  throw lastError;
}

async function fillMissingKeys(baseObj, targetObj, locale, keyPath = [], filePath = null, rootObj = null) {
  if (!rootObj) rootObj = targetObj;
  for (const key of Object.keys(baseObj)) {
    const currentPath = [...keyPath, key];
    if (!(key in targetObj)) {
      if (typeof baseObj[key] === "object" && baseObj[key] !== null && !Array.isArray(baseObj[key])) {
        targetObj[key] = {};
        await fillMissingKeys(baseObj[key], targetObj[key], locale, currentPath, filePath, rootObj);
      } else {
        // Translate and insert with retry
        const text = baseObj[key];
        const translation = await retryAsync(() => translate(text, locale));
        targetObj[key] = translation;
        console.log(`Added missing key for ${locale}: ${currentPath.join(".")} = ${translation}`);
        // Save after each new key (write the full root object)
        const sortedJson = sortObject(rootObj);
        if (filePath) {
          await retryAsync(() => fs.promises.writeFile(filePath, JSON.stringify(sortedJson, null, 2), "utf8"));
        }
      }
    } else if (typeof baseObj[key] === "object" && baseObj[key] !== null && !Array.isArray(baseObj[key])) {
      await fillMissingKeys(baseObj[key], targetObj[key], locale, currentPath, filePath, rootObj);
    }
  }
}

// Deep merge utility to merge fixed keys into the full translation object
function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    if (
      source[key] &&
      typeof source[key] === "object" &&
      !Array.isArray(source[key]) &&
      target[key] &&
      typeof target[key] === "object" &&
      !Array.isArray(target[key])
    ) {
      deepMerge(target[key], source[key]);
    } else {
      target[key] = source[key];
    }
  }
  return target;
}

// Add a function to verify and fix translations using the LLM
async function verifyAndFixTranslations(locale, enJson, localeJson, filePath) {
  if (locale === "en") return false;
  const prompt = `You are a professional translator. Compare the following English JSON and its ${locale} translation JSON. Identify any incorrect or inconsistent translations. If all translations are correct, reply with ONLY "OK". If there are errors, reply with the corrected ${locale} JSON only.\n\nENGLISH JSON:\n${JSON.stringify(enJson, null, 2)}\n\n${locale.toUpperCase()} JSON:\n${JSON.stringify(localeJson, null, 2)}`;
  const url = `${AZURE_ENDPOINT}/openai/deployments/${AZURE_DEPLOYMENT}/chat/completions?api-version=${AZURE_API_VERSION}`;
  const headers = {
    "api-key": AZURE_API_KEY,
    "Content-Type": "application/json",
  };
  const data = {
    messages: [{ role: "user", content: prompt }],
    max_tokens: 4096,
    temperature: 0.0,
  };
  const response = await axios.post(url, data, { headers });
  const content = (response.data.choices[0].message.content || "").trim();
  if (content === "OK") {
    return false;
  }
  try {
    // Remove Markdown code block if present
    const cleaned = content
      .replace(/^```(?:json)?\n?/i, "")
      .replace(/```$/, "")
      .trim();
    const fixedJson = JSON.parse(cleaned);
    // Merge the fixed keys into the existing localeJson
    deepMerge(localeJson, fixedJson);
    await retryAsync(() => fs.promises.writeFile(filePath, JSON.stringify(sortObject(localeJson), null, 2), "utf8"));
    console.log(`Verified and fixed translations for ${locale}. (Merged)`);
    return true;
  } catch (e) {
    console.error(`Failed to parse/fix ${locale} translation:`, e.message);
    return false;
  }
}

// Add function to verify all JSON files are saved
async function verifyAllFilesSaved(LOCALES, TRANSLATION_PATH) {
  for (const locale of LOCALES) {
    const filePath = path.join(TRANSLATION_PATH, locale, "translation.json");
    try {
      await fs.promises.access(filePath, fs.constants.R_OK | fs.constants.W_OK);
      const content = await fs.promises.readFile(filePath, "utf8");
      JSON.parse(content); // Verify it's valid JSON
    } catch (err) {
      throw new Error(`Failed to verify ${locale} translation file: ${err.message}`);
    }
  }
  return true;
}

function getAllKeys(obj, prefix = "") {
  let keys = [];
  for (const key in obj) {
    if (typeof obj[key] === "object" && obj[key] !== null) {
      keys = keys.concat(getAllKeys(obj[key], prefix ? `${prefix}.${key}` : key));
    } else {
      keys.push(prefix ? `${prefix}.${key}` : key);
    }
  }
  return keys;
}

function toNestedType(obj, indent = 0) {
  const pad = "  ".repeat(indent);
  let out = "{\n";
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === "object" && obj[key] !== null) {
      out += `${pad}  ${key}: ${toNestedType(obj[key], indent + 1)};\n`;
    } else {
      out += `${pad}  ${key}: string;\n`;
    }
  }
  out += pad + "}";
  return out;
}

function toCamelCase(str) {
  return (
    str
      // Replace all non-alphanumeric characters with a space
      .replace(/[^a-zA-Z0-9]+/g, " ")
      // Insert a space before an uppercase letter only if preceded by a lowercase letter or number
      .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
      // Lowercase everything, trim, and split into words
      .toLowerCase()
      .trim()
      .split(" ")
      // Capitalize all words except the first
      .map((word, i) => (i === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)))
      .join("")
  );
}

function keysToCamelCase(obj) {
  if (Array.isArray(obj)) {
    return obj.map(keysToCamelCase);
  } else if (obj !== null && typeof obj === "object") {
    return Object.entries(obj).reduce((acc, [key, value]) => {
      const camelKey = toCamelCase(key);
      acc[camelKey] = keysToCamelCase(value);
      return acc;
    }, {});
  }
  return obj;
}

async function main() {
  const [, , keyPath, ...textArr] = process.argv;
  const text = textArr.join(" ");
  const keys = keyPath ? keyPath.split(".") : null;

  // Special case: if both keyPath and text are 'cleanup', skip translation but do checking and sorting
  const isCleanup = keyPath === "cleanup" && text === "cleanup";

  const LOCALES = await getLocales();
  let enJson = await getTranslationJson("en");

  // Convert all keys in every locale to camelCase and save before any syncing logic
  for (const locale of LOCALES) {
    const filePath = path.join(TRANSLATION_PATH, locale, "translation.json");
    let json = JSON.parse(fs.readFileSync(filePath, "utf8"));
    const camelJson = keysToCamelCase(json);
    await retryAsync(() => fs.promises.writeFile(filePath, JSON.stringify(sortObject(camelJson), null, 2), "utf8"));
    if (locale === "en") enJson = camelJson;
  }

  // If adding a new key, first add it to English
  if (!isCleanup && keyPath && text) {
    const enFilePath = path.join(TRANSLATION_PATH, "en", "translation.json");
    setNested(enJson, keys, text);
    const sortedEnJson = sortObject(enJson);
    await retryAsync(() => fs.promises.writeFile(enFilePath, JSON.stringify(sortedEnJson, null, 2), "utf8"));
  }

  for (const locale of LOCALES) {
    const filePath = path.join(TRANSLATION_PATH, locale, "translation.json");
    const json = JSON.parse(fs.readFileSync(filePath, "utf8"));

    if (!isCleanup && keyPath && text) {
      // CLI mode: add/update a specific key
      const translation = await retryAsync(() => translate(text, locale));
      setNested(json, keys, translation);
      const sortedJson = sortObject(json);
      await retryAsync(() => fs.promises.writeFile(filePath, JSON.stringify(sortedJson, null, 2), "utf8"));
      console.log(`Updated ${locale}: ${keyPath} = ${translation}`);
    }
    if (locale !== "en") {
      // Fill missing keys from English, save as you go
      await fillMissingKeys(enJson, json, locale, [], filePath, json);
    }
    // Final sort and save (in case of CLI update or no missing keys)
    const sortedJson = sortObject(json);
    await retryAsync(() => fs.promises.writeFile(filePath, JSON.stringify(sortedJson, null, 2), "utf8"));
    // Verification step during cleanup
    if (isCleanup) {
      const changed = await verifyAndFixTranslations(locale, enJson, json, filePath);
      if (changed) {
        console.log(`Corrections applied for ${locale}`);
      }
    }
  }

  // Verify all files are saved before proceeding with type generation
  await verifyAllFilesSaved(LOCALES, TRANSLATION_PATH);
  console.log("All translation files verified and saved successfully.");

  if (!isCleanup && keyPath && text) {
    // Output the key ready to be added to the code
    console.log(`\nUse in code: TranslationKeys.${keyPath.replace(/\./g, "_").toUpperCase()}`);
  }
  if (isCleanup) {
    console.log("Clean up complete.");
  }

  // Always regenerate types after any translation changes
  const latestEnJson = await getTranslationJson("en");
  let allKeys = getAllKeys(latestEnJson);
  // Deduplicate keys (consolidate duplicates)
  allKeys = Array.from(new Set(allKeys));
  const nestedType = toNestedType(latestEnJson, 0);

  // Generate the .ts file with values
  const tsOutputPath = path.join(TYPES_PATH, "translation-keys.ts");
  const tsFileContent = `// AUTO-GENERATED FILE. DO NOT EDIT MANUALLY.

export const TranslationKeys = {
${allKeys.map((k) => `  ${k.replace(/\./g, "_").toUpperCase()}: "${k}"`).join(",\n")}
} as const;

export type TranslationKey = typeof TranslationKeys[keyof typeof TranslationKeys];
`;
  await retryAsync(() => fs.promises.writeFile(tsOutputPath, tsFileContent, "utf8"));
  console.log(`Translation keys file updated at ${tsOutputPath}`);

  // Generate the .d.ts file with types
  const typeOutputPath = path.join(TYPES_PATH, "translation-keys.d.ts");
  const typeFileContent = `// AUTO-GENERATED FILE. DO NOT EDIT MANUALLY.

export type TranslationJson = ${nestedType};
`;
  await retryAsync(() => fs.promises.writeFile(typeOutputPath, typeFileContent, "utf8"));
  console.log(`Type definitions updated at ${typeOutputPath}`);
}

main();
