#!/bin/sh

set -o allexport
. ../../.env
set +o allexport

read -p "Enter the translation key (e.g., greeting.hello) or "cleanup" to verify and cleanup translations: " keypath

if [ "$keypath" = "cleanup" ]; then
  node auto-translate.js "$keypath" "$keypath"
  exit 0
fi

read -p "Enter the English text to translate: " text

if [ -z "$keypath" ] || [ -z "$text" ]; then
  echo "Both key and text are required."
  exit 1
fi

node auto-translate.js "$keypath" "$text" 
