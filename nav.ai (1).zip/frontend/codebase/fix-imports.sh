#!/bin/bash

# Script to fix remaining import order issues
cd /Users/carl.sharpe/git/nav-ai-docker/frontend/codebase

echo "Running additional import order fixes..."

# Fix import order issues that ESLint can handle
pnpm lint:fix

# Run Prettier again to ensure consistent formatting
npx prettier --write .

echo "Import order fixes completed!"

# Show final status
echo ""
echo "Final lint status:"
pnpm lint 2>&1 | grep -E "problems|✖" | tail -1 || echo "No lint summary found"
