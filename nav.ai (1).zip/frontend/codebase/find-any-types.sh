#!/bin/bash

# Script to find all TypeScript 'any' type usages and report filename, context, and author
# Output: CSV file with columns: filename, line_number, context, author, date

OUTPUT_FILE="any-types-report.csv"
TEMP_FILE="/tmp/any_types_temp.txt"

# Create CSV header
echo "filename,line_number,context,author,date" > "$OUTPUT_FILE"

echo "Scanning for 'any' type usages in TypeScript files..."

# Find all TypeScript files and search for 'any' type patterns
find . -name "*.ts" -o -name "*.tsx" | grep -v node_modules | grep -v dist | while read -r file; do
    echo "Processing: $file"

    # Search for various 'any' patterns in the file
    grep -n -E ":\s*any\b|<any>|Array<any>|Promise<any>|Record<string,\s*any>|Record<any,|\(\.\.\.\w*:\s*any\[\]|\bas\s+any\b" "$file" 2>/dev/null | while IFS=: read -r line_num match; do
        # Clean up the match text for CSV (remove quotes, commas, newlines)
        clean_match=$(echo "$match" | sed 's/"/\\"/g' | tr -d '\n\r' | sed 's/,/;/g')

        # Get git blame info for this specific line
        blame_info=$(git blame -L "$line_num,$line_num" "$file" 2>/dev/null | head -1)

        if [[ -n "$blame_info" ]]; then
            # Extract commit hash, author, and date from git blame
            # Format: hash (Author Name YYYY-MM-DD HH:MM:SS +TIMEZONE LINE_NUM) code
            author=$(echo "$blame_info" | sed -E 's/^[a-f0-9]+[^(]*\(([^0-9]+)[0-9]{4}-[0-9]{2}-[0-9]{2}.*$/\1/' | sed 's/[[:space:]]*$//')
            date=$(echo "$blame_info" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}')

            # If author extraction failed, try alternative format
            if [[ "$author" == "$blame_info" ]] || [[ -z "$author" ]]; then
                # Try simpler extraction
                author=$(echo "$blame_info" | awk '{for(i=2;i<=NF;i++){if($i ~ /^[0-9]{4}-/){for(j=2;j<i;j++)printf "%s ", $j; break}}}' | sed 's/[()]//g' | sed 's/[[:space:]]*$//')
            fi

            # Clean filename (remove leading ./)
            clean_filename=$(echo "$file" | sed 's|^\./||')

            # Output CSV row
            echo "\"$clean_filename\",\"$line_num\",\"$clean_match\",\"$author\",\"$date\"" >> "$OUTPUT_FILE"
        fi
    done
done

echo ""
echo "Report generated: $OUTPUT_FILE"
echo "Summary:"
echo "--------"

# Generate summary statistics
total_files=$(cut -d',' -f1 "$OUTPUT_FILE" | tail -n +2 | sort -u | wc -l)
total_usages=$(tail -n +2 "$OUTPUT_FILE" | wc -l)
echo "Total files with 'any' types: $total_files"
echo "Total 'any' type usages: $total_usages"

echo ""
echo "Top contributors:"
echo "-----------------"
tail -n +2 "$OUTPUT_FILE" | cut -d',' -f4 | sed 's/"//g' | sort | uniq -c | sort -nr | head -5

echo ""
echo "Files with most 'any' usages:"
echo "-----------------------------"
tail -n +2 "$OUTPUT_FILE" | cut -d',' -f1 | sed 's/"//g' | sort | uniq -c | sort -nr | head -5
