#!/bin/bash

# ESLint Errors Only Checker
# This script runs ESLint and shows only errors (not warnings)

echo "🔍 Checking for ESLint errors only..."
echo "================================="

# Run ESLint with --quiet flag to show only errors
npx eslint . --quiet

EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✅ No ESLint errors found!"
    echo "Note: There may still be warnings. Run 'pnpm lint' to see all issues."
else
    echo ""
    echo "❌ Found ESLint errors that must be fixed before pushing."
    echo ""
    echo "💡 To fix automatically fixable issues:"
    echo "   pnpm lint:fix"
    echo ""
    echo "💡 To see all issues (including warnings):"
    echo "   pnpm lint"
fi

exit $EXIT_CODE
