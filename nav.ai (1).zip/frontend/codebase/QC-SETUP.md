# Quality Control (QC) Setup

This repository has been configured with comprehensive quality control tools to ensure code consistency, prevent bugs, and maintain high code standards.

## 🛠️ Tools Configured

### 1. **Husky** - Git Hooks Management

- **Purpose**: Automates quality checks at different stages of the Git workflow
- **Configuration**: `.husky/` directory
- **Hooks**:
  - `pre-commit`: Runs lint-staged to check staged files
  - `commit-msg`: Validates commit message format using commitlint
  - `pre-push`: Comprehensive validation before pushing to remote

### 2. **lint-staged** - Staged Files Processing

- **Purpose**: Runs linters and formatters only on staged files for faster feedback
- **Configuration**: `package.json` → `lint-staged` section
- **Actions**:
  - TypeScript/JavaScript: ESLint fix + Prettier + Type checking
  - CSS/SCSS: Stylelint fix + Prettier
  - JSON/Markdown/YAML: Prettier formatting

### 3. **Stylelint** - CSS/SCSS Linting

- **Purpose**: Enforces consistent CSS/SCSS coding standards
- **Configuration**: `.stylelintrc.json`
- **Features**:
  - SCSS support with standard rules
  - Prettier integration to avoid conflicts
  - Enhanced rules for better code quality
  - Performance optimizations (nesting depth, redundant properties)

### 4. **Commitlint** - Commit Message Validation

- **Purpose**: Enforces conventional commit message format
- **Configuration**: `.commitlintrc.json`
- **Format**: `type(scope): subject`
- **Types**: feat, fix, docs, style, refactor, perf, test, build, ci, chore, revert

### 5. **ESLint** - JavaScript/TypeScript Linting

- **Configuration**: `eslint.config.js`
- **Features**:
  - TypeScript support
  - React hooks validation
  - Import organization
  - Code quality rules

### 6. **Prettier** - Code Formatting

- **Configuration**: `.prettierrc`
- **Features**:
  - Import sorting
  - Consistent formatting across all file types

## 📋 Available Scripts

### Quality Control Scripts

```bash
# Individual checks
pnpm lint                    # ESLint check
pnpm lint:fix               # ESLint fix
pnpm lint:styles            # Stylelint check
pnpm lint:styles:fix        # Stylelint fix
pnpm format                 # Prettier format
pnpm format:check           # Prettier check
pnpm type-check             # TypeScript type checking
pnpm type-check:watch       # TypeScript type checking in watch mode

# Combined workflows
pnpm fix-all                # Fix all linting and formatting issues
pnpm validate               # Run all checks (lint + format + test)
pnpm validate:full          # Full validation including type checking
pnpm ci:validate            # CI validation (full + build)
```

### Testing Scripts

```bash
pnpm test                   # Run tests
pnpm test:watch            # Run tests in watch mode
pnpm test:ui               # Run tests with UI
pnpm coverage              # Generate coverage report
```

## 🚀 Workflow

### During Development

1. **Write code** following the established patterns
2. **Stage files** (`git add`)
3. **Commit** with conventional message format:
   ```bash
   git commit -m "feat(auth): add user authentication middleware"
   ```
4. **Pre-commit hook** automatically:
   - Runs ESLint fixes on staged JS/TS files
   - Runs Stylelint fixes on staged CSS/SCSS files
   - Formats files with Prettier
   - Performs TypeScript type checking
5. **Commit message validation** ensures conventional format
6. **Push** triggers pre-push validation:
   - Full TypeScript type checking
   - Complete linting and formatting validation
   - Test suite execution

### Manual Quality Checks

```bash
# Before submitting PR
pnpm validate:full

# Fix all auto-fixable issues
pnpm fix-all

# Check specific areas
pnpm lint:styles
pnpm type-check
```

## 🔧 Configuration Details

### Enhanced Stylelint Rules

- **Max nesting depth**: 4 levels
- **No redundant longhand properties**
- **No empty comments**
- **Max 1 ID selector per rule**
- **Disallowed units**: cm, mm, in, pc, pt
- **Minimum time values**: 100ms
- **Single-line max declarations**: 1

### Commit Message Examples

```bash
# ✅ Good
feat(ui): add dark mode toggle
fix(auth): resolve token expiration bug
docs: update installation instructions
style(header): improve responsive layout
refactor(api): extract validation logic
test(utils): add unit tests for date helpers

# ❌ Bad
Add feature
fix bug
Update files
WIP
```

## 🚨 Common Issues & Solutions

### Type Checking Failures

```bash
# Check types without emitting files
pnpm type-check

# Watch mode for development
pnpm type-check:watch
```

### Lint Conflicts

```bash
# Auto-fix most issues
pnpm fix-all

# Check what would be fixed
pnpm lint --fix --dry-run
```

### Commit Message Rejected

- Use conventional commit format: `type(scope): description`
- Keep header under 100 characters
- Use present tense: "add feature" not "added feature"

### Pre-push Failures

- Run `pnpm validate:full` locally before pushing
- Fix all type errors and linting issues
- Ensure all tests pass

## 🎯 Benefits

1. **Consistent Code Style**: Automated formatting and linting
2. **Early Bug Detection**: Type checking and linting catch issues early
3. **Better Git History**: Conventional commits improve readability
4. **Reduced Review Time**: Automated checks reduce manual review burden
5. **Quality Gates**: Prevent broken code from reaching main branch
6. **Developer Experience**: Fast feedback loop with staged file processing

## 📚 References

- [Conventional Commits](https://www.conventionalcommits.org/)
- [Husky Documentation](https://typicode.github.io/husky/)
- [lint-staged](https://github.com/okonet/lint-staged)
- [Stylelint Rules](https://stylelint.io/user-guide/rules/)
- [ESLint Rules](https://eslint.org/docs/rules/)
