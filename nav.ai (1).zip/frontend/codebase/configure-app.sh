#!/bin/sh
# configure-app.sh

# Set default paths based on typical Node.js app structure
#APP_ROOT=${APP_ROOT:-/app}
#DIST_DIR=${DIST_DIR:-${APP_ROOT}/dist}

# Get base path from environment or default to '/'
#BASE_PATH=${VITE_APP_CONTEXT_PATH:-/}

# Replace the base tag placeholder in index.html
#sed -i "s|__BASE_PATH__|$BASE_PATH|g" /app/dist/index.html

# Validate settings env vars
valid=1
if [ -n "$DEFAULT_THEME" ]; then
  if [ "$DEFAULT_THEME" != "dark" ] && [ "$DEFAULT_THEME" != "light" ]; then
    echo "ERROR: DEFAULT_THEME must be 'dark' or 'light' (got '$DEFAULT_THEME')"
    valid=0
  fi
fi
if [ -n "$DEFAULT_EQTY_POLICY_PLANE" ]; then
  if [ "$DEFAULT_EQTY_POLICY_PLANE" != "eu" ] && [ "$DEFAULT_EQTY_POLICY_PLANE" != "us" ] && [ "$DEFAULT_EQTY_POLICY_PLANE" != "aus" ]; then
    echo "ERROR: DEFAULT_EQTY_POLICY_PLANE must be 'eu', 'us' or 'aus' (got '$DEFAULT_EQTY_POLICY_PLANE')"
    valid=0
  fi
fi
if [ -n "$DEFAULT_PRIMARY_COLOR" ]; then
  case "$DEFAULT_PRIMARY_COLOR" in
    #[0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f]) ;;
    *) echo "ERROR: DEFAULT_PRIMARY_COLOR must be a valid hex color (e.g. #146AC8) (got '$DEFAULT_PRIMARY_COLOR')"; valid=0 ;;
  esac
fi
if [ -n "$DEFAULT_SECONDARY_COLOR" ]; then
  case "$DEFAULT_SECONDARY_COLOR" in
    #[0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f]) ;;
    *) echo "ERROR: DEFAULT_SECONDARY_COLOR must be a valid hex color (e.g. #3a7ecc) (got '$DEFAULT_SECONDARY_COLOR')"; valid=0 ;;
  esac
fi
if [ $valid -eq 0 ]; then
  exit 1
fi

# Create the runtime configuration script with environment variables
cat > /app/dist/config.js << EOF
window.ENV = {
  VITE_BACKEND_BASE_URL: "${VITE_BACKEND_BASE_URL}",
  VITE_APP_CONTEXT_PATH: "${VITE_APP_CONTEXT_PATH}",
  VITE_APP_TOOLS_PREFIX: "${VITE_APP_TOOLS_PREFIX}",
  VITE_REDIRECT_URI: "${VITE_REDIRECT_URI}",
  AUTH_OPENID_AUTHORITY_URL: "${AUTH_OPENID_AUTHORITY_URL}",
  FRONTEND_COMMIT: "${FRONTEND_COMMIT}",
  FRONTEND_BUILD_NUMBER: "${FRONTEND_BUILD_NUMBER}",
  FRONTEND_BUILD_DATETIME: "${FRONTEND_BUILD_DATETIME}",
  FRONTEND_DEPLOYMENT_DATETIME: "${FRONTEND_DEPLOYMENT_DATETIME}",
  DEFAULT_THEME: "${DEFAULT_THEME}",
  DEFAULT_PRIMARY_COLOR: "${DEFAULT_PRIMARY_COLOR}",
  DEFAULT_SECONDARY_COLOR: "${DEFAULT_SECONDARY_COLOR}",
  DEFAULT_EQTY_POLICY_PLANE: "${DEFAULT_EQTY_POLICY_PLANE}"
};
console.log("Runtime configuration loaded");
EOF

# Run the original command that starts the application
exec pnpm run preview --port $APP_PORT