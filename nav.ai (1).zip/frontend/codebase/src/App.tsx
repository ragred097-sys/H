import { useEffect } from "react";

import { RouterProvider } from "react-router-dom";

import "bootstrap-icons/font/bootstrap-icons.css";
import "bootstrap/scss/bootstrap.scss";

import "./App.scss";
import "./components/eqty/policyplane/styles.css";
import { LoaderProvider } from "./components/general/LoaderContext";
import { useNotification } from "./components/general/NotificationProvider";
import { createAppRouter } from "./routes/Routes.tsx";
import { setNotificationFunction } from "./utils/notificationHelper";

export default function App(): React.JSX.Element {
  const contextPath = window.ENV?.VITE_APP_CONTEXT_PATH || import.meta.env.VITE_APP_CONTEXT_PATH || "/";
  const router = createAppRouter(contextPath);
  const { openErrorNotification } = useNotification();

  useEffect(() => {
    setNotificationFunction(openErrorNotification);
  }, [openErrorNotification]);

  useEffect(() => {
    // Handle ResizeObserver loop error
    const handleError = (e: ErrorEvent) => {
      if (e.message.startsWith("ResizeObserver loop ")) {
        const resizeObserverErrDiv = document.getElementById("webpack-dev-server-client-overlay-div");
        const resizeObserverErr = document.getElementById("webpack-dev-server-client-overlay");
        if (resizeObserverErr) {
          resizeObserverErr.setAttribute("style", "display: none");
        }
        if (resizeObserverErrDiv) {
          resizeObserverErrDiv.setAttribute("style", "display: none");
        }
      }
    };

    window.addEventListener("error", handleError);

    // Cleanup event listener on unmount
    return () => {
      window.removeEventListener("error", handleError);
    };
  }, []);

  return (
    <LoaderProvider>
      <RouterProvider router={router} />
    </LoaderProvider>
  );
}
