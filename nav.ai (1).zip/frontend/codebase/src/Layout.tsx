import { Suspense, useEffect, useState } from "react";

import { UserManager } from "oidc-client-ts";

import { hasAuthParams, useAuth } from "react-oidc-context";
import { Outlet } from "react-router-dom";

import LeftBar from "./components/layout/LeftBar/LeftBar.tsx";
import NavBar from "./components/layout/NavBar/NavBar.tsx";
import SuperAgentConsoleOverlay from "./components/layout/SuperAgentConsoleOverlay.tsx";
import { Preference } from "./lib/Model.ts";
import { SystemService } from "./services/SystemService";
import { UserService } from "./services/UserService";
import { authStore } from "./stores/useStore.ts";
import { DEFAULT_SETTINGS } from "./utils/constants";
import { setThemeProperties } from "./utils/themeUtils";

function Layout({ userManager }: { userManager: UserManager }) {
  const { activeNavigator, isAuthenticated, isLoading, signinRedirect } = useAuth();
  const [hasTriedSignin, setHasTriedSignin] = useState(false);
  const userId = authStore((state) => state.user?.id);

  useEffect(() => {
    const handleAccessTokenExpired = async () => {
      console.log("Access token has expired");
      try {
        // Attempt silent renewal when the access token expires
        const renewedUser = await userManager?.signinSilent();
        console.log("Token renewed successfully", renewedUser);
      } catch (error) {
        console.error("Error renewing token", error);
        // Redirect to login if silent renew fails
        signinRedirect();
      }
    };

    // Add event listener for access token expiration
    userManager?.events?.addAccessTokenExpired(handleAccessTokenExpired);

    // Cleanup event listener when the component unmounts
    return () => {
      userManager?.events?.removeAccessTokenExpired(handleAccessTokenExpired);
    };
  }, [userManager, signinRedirect]);

  /**
   * Do auto sign in.
   *
   * See {@link https://github.com/authts/react-oidc-context?tab=readme-ov-file#automatic-sign-in}
   */
  useEffect(() => {
    if (!hasAuthParams() && !isAuthenticated && !activeNavigator && !isLoading && !hasTriedSignin) {
      signinRedirect();
      setHasTriedSignin(true);
    }
  }, [activeNavigator, hasTriedSignin, isAuthenticated, isLoading, signinRedirect]);

  useEffect(() => {
    if (isAuthenticated) {
      console.log("Authenticated", isAuthenticated);
      UserService.getCurrentAuthenticatedUser().then((user) => {
        authStore.getState().login(user);
        authStore.getState().setRoles(user.applicationAccessRoles);
      });
    } else if (!isAuthenticated) {
      console.log("Authenticated", isAuthenticated);
      authStore.getState().logout();
    }
  }, [isAuthenticated]);

  useEffect(() => {
    const defaultPreferences: Preference[] = [
      {
        description: "The theme of the application, light or dark.",
        label: "Theme",
        name: "theme",
        scope: "user",
        type: "text",
      },
      {
        description: "The primary color of the application.",
        label: "Primary Color",
        name: "primary-color",
        scope: "user",
        type: "text",
      },
      {
        description: "The secondary color of the application.",
        label: "Secondary Color",
        name: "secondary-color",
        scope: "user",
        type: "text",
      },
      {
        description: "The URL of the Equity Policy Plane.",
        label: "Equity Policy Plane",
        name: "eqty-policy-plane",
        scope: "user",
        type: "text",
      },
    ];

    const defaultSettings = {
      "eqty-policy-plane": DEFAULT_SETTINGS.EqtyPolicyPlane,
      "primary-color": DEFAULT_SETTINGS.PrimaryColor,
      "secondary-color": DEFAULT_SETTINGS.SecondaryColor,
      theme: DEFAULT_SETTINGS.Theme,
    };

    if (isAuthenticated) {
      SystemService.getSystemInfo().then((info) => {
        sessionStorage.setItem("eqty-version", info.eqty?.version ?? "");
        sessionStorage.setItem("user-version", info.user_version ?? "");
        sessionStorage.setItem("backend-commit", info.backend_commit ?? "");
        sessionStorage.setItem("backend-deployment-datetime", info.backend_deployment_datetime ?? "");
        sessionStorage.setItem("backend-build-number", info.backend_build_number ?? "");
        sessionStorage.setItem("backend-build-datetime", info.backend_build_datetime ?? "");
        sessionStorage.setItem("frontend-commit", window.ENV?.FRONTEND_COMMIT ?? "");
        sessionStorage.setItem("frontend-deployment-datetime", window.ENV?.FRONTEND_DEPLOYMENT_DATETIME ?? "");
        sessionStorage.setItem("frontend-build-number", window.ENV?.FRONTEND_BUILD_NUMBER ?? "");
        sessionStorage.setItem("frontend-build-datetime", window.ENV?.FRONTEND_BUILD_DATETIME ?? "");
      });

      UserService.getUserPreferences().then((preferences) => {
        const existingPreferences = new Set(preferences.map((p) => p.name));
        const missingPreferences = defaultPreferences.filter((pref) => !existingPreferences.has(pref.name));

        if (missingPreferences.length > 0) {
          Promise.all(missingPreferences.map((pref) => UserService.postUserPreference(pref))).catch((err) =>
            console.error("Failed to initialize preferences:", err)
          );
        }

        UserService.getUserSettings("me").then((settings) => {
          console.debug("Loaded preferences", preferences);
          console.debug("Loaded settings", settings);
          const getSettingValue = (prefName: keyof typeof defaultSettings) => {
            const pref = preferences.find((p) => p.name === prefName);
            return settings.find((s) => s.preferenceId === pref?.id)?.value || defaultSettings[prefName];
          };

          const themeValue = getSettingValue("theme");
          const primaryColorValue = getSettingValue("primary-color");
          const secondaryColorValue = getSettingValue("secondary-color");
          setThemeProperties(themeValue, primaryColorValue, secondaryColorValue);

          const eqtyPolicyPlaneValue = getSettingValue("eqty-policy-plane");
          sessionStorage.setItem("eqty-policy-plane", eqtyPolicyPlaneValue);
        });
      });
    }
  }, [isAuthenticated]);

  return (
    <>
      {isLoading && <div>Loading...</div>}
      {!isLoading && (
        <>
          {isAuthenticated ? (
            <>
              {userId && (
                <div className="layout text-light d-flex flex-column" style={{ height: "100vh" }}>
                  <NavBar />
                  <div className="d-flex flex-row flex-grow-1" style={{ height: "calc(100vh - 75px)" }}>
                    <LeftBar />
                    <div className="main-content flex-grow-1" style={{ overflow: "auto" }}>
                      <Suspense fallback={<div>Loading...</div>}>
                        <Outlet />
                      </Suspense>
                    </div>
                    <SuperAgentConsoleOverlay />
                  </div>
                </div>
              )}{" "}
            </>
          ) : (
            <div>Unauthorized</div>
          )}
        </>
      )}
    </>
  );
}

export default Layout;
