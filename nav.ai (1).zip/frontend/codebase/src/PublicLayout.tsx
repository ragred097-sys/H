import { Suspense, useEffect } from "react";

import { Container, Navbar } from "react-bootstrap";
import { Outlet } from "react-router-dom";

import navailogo from "./assets/images/navAILogo.png";
import { DEFAULT_SETTINGS } from "./utils/constants";
import { setThemeProperties } from "./utils/themeUtils";

function PublicLayout() {
  useEffect(() => {
    setThemeProperties(DEFAULT_SETTINGS.Theme, DEFAULT_SETTINGS.PrimaryColor, DEFAULT_SETTINGS.SecondaryColor);
  }, []);

  return (
    <div className="layout text-light d-flex flex-column" style={{ height: "100vh" }}>
      <Navbar className="transparent-navbar">
        <Container fluid className="d-flex align-items-center">
          <Navbar.Brand>
            <img style={{ height: "45px" }} src={navailogo} className="ps-1 pt-2" alt="Logo" />
          </Navbar.Brand>
        </Container>
      </Navbar>
      <div className="d-flex flex-row flex-grow-1" style={{ height: "calc(100vh - 75px)" }}>
        <div className="main-content" style={{ overflow: "hidden", overflowY: "auto" }}>
          <Suspense fallback={<div>Loading...</div>}>
            <Outlet />
          </Suspense>
        </div>
      </div>
    </div>
  );
}

export default PublicLayout;
