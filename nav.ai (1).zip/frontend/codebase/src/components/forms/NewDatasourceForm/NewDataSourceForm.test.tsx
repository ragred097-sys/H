import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import { ModuleType, PermissionType } from "../../../lib/Model";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";
import { NewDataSourceForm } from "./NewDataSourceForm";

// --- Mocks ---
vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

vi.mock("../../../lib/Backend", () => ({
  Backend: {
    createDataSource: vi.fn(),
    deleteDataSource: vi.fn(),
    getDatasourceById: vi.fn(),
    getModulesByType: vi.fn(),
    updateDataSource: vi.fn(),
  },
}));

vi.mock("../../general/NotificationProvider", () => ({
  useNotification: () => ({
    openErrorNotification: vi.fn(),
    openNotification: vi.fn(),
  }),
}));

vi.mock("../../../stores/useStore", () => ({
  authStore: vi.fn(() => ({ user: { id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2" } })),
}));

// --- Test Data ---
const embeddingModules = [
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:18:07.071140",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: false,
    description: "",
    favorite: false,
    id: "9abb6535-a7c5-4343-8d4e-8bb170fe74ca",
    name: "Text Embedding 3 Large (AIP-HPS)",
    parameters: [],
    specId: "846232c8-b6e9-4ee2-87ab-3e173768f06c",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:17:21.220441",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: true,
    description: "",
    favorite: false,
    id: "bae6ec3b-763f-423a-b135-9a678f81c037",
    name: "Text Embedding 3 Large (AIP-NAVAI)",
    parameters: [],
    specId: "846232c8-b6e9-4ee2-87ab-3e173768f06c",
    supportedInputs: [],
    tags: [],
  },
];
const vectorStores = [
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:20:02.318512",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: true,
    description: "",
    favorite: false,
    id: "fbea5348-88ac-4368-8f10-c958c1a421fb",
    name: "Qdrant Vector Store (Conversations)",
    parameters: [],
    specId: "6be9447d-b45e-4563-af34-22d44fbde905",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:19:16.385226",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: false,
    description: "",
    favorite: false,
    id: "980bba25-0f8f-4ba7-9d41-664674e8b7f9",
    name: "Qdrant Vector Store (Data)",
    parameters: [],
    specId: "6be9447d-b45e-4563-af34-22d44fbde905",
    supportedInputs: [],
    tags: [],
  },
];
const fileStores = [
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:21:15.838499",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: true,
    description: "",
    favorite: false,
    id: "ae3cb5dd-0256-4d09-9acf-d211aba4a3cf",
    name: "NVIDIA VSS Storage (Dev)",
    parameters: [],
    specId: "df96ca9b-45ad-478d-8acd-91d2ae38c9b6",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "2025-07-08T10:22:00.253164",
    creator: { __type_name: "User", id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2", name: "adarsh satpute" },
    default: false,
    description: "",
    favorite: false,
    id: "040d78a1-886e-46fb-af75-0a218d3a2a37",
    name: "NVIDIA VSS Storage (Demo)",
    parameters: [],
    specId: "df96ca9b-45ad-478d-8acd-91d2ae38c9b6",
    supportedInputs: [],
    tags: [],
  },
];
const dataSource = {
  __type_name: "DataSource",
  accessPermission: PermissionType.WRITE,
  createdAt: "2025-07-15T11:32:07.287207",
  creator: {
    __type_name: "User",
    id: "699e768f-0cc5-4153-b3ea-efc5d33e88a2",
    name: "adarsh satpute",
  },
  description: "hey",
  embeddingModelId: "bae6ec3b-763f-423a-b135-9a678f81c037",
  favorite: false,
  fileStorageId: "040d78a1-886e-46fb-af75-0a218d3a2a37",
  filterTag: "74fed073-231b-43f1-8afc-9e0b2fd10d9a",
  hidden: false,
  id: "f28daed2-03b2-467d-8982-6b69415631cd",
  ingestedFiles: [],
  name: "mydt",
  tags: [],
  vectorStoreId: "fbea5348-88ac-4368-8f10-c958c1a421fb",
};

// --- Test Suite ---
describe("NewDataSourceForm", () => {
  const mockProps = {
    handleClose: vi.fn(),
    onUpdateAgentFormDirty: vi.fn(),
    setIsFormDirty: vi.fn(),
    updateTrigger: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(ModuleService, "getModulesByType").mockImplementation((type: any) => {
      if (type === ModuleType.EMBEDDING_MODEL) return Promise.resolve(embeddingModules);
      if (type === ModuleType.VECTOR_STORE) return Promise.resolve(vectorStores);
      if (type === ModuleType.FILE_STORAGE) return Promise.resolve(fileStores);
      return Promise.resolve([]);
    });
    vi.spyOn(DataSourceService, "getDatasourceById").mockResolvedValue(dataSource);
  });

  // 1. Structure
  it("renders all required fields and buttons", async () => {
    const { container } = render(<NewDataSourceForm {...mockProps} />);

    await act(async () => {
      expect(container.querySelector("#name")).toBeInTheDocument();
      expect(container.querySelector("#description")).toBeInTheDocument();
      expect(container.querySelector("#filterTag")).toBeInTheDocument();
      expect(container.querySelector("#embeddingModelId")).toBeInTheDocument();
      expect(container.querySelector("#vectorStoreId")).toBeInTheDocument();
      expect(container.querySelector("#fileStorageId")).toBeInTheDocument();
      expect(screen.getByTestId("create-datasource-button")).toBeInTheDocument();
    });
  });

  // 2. Defaults in create mode
  it("populates default modules in create mode", async () => {
    const { container } = render(<NewDataSourceForm {...mockProps} />);
    await waitFor(() => {
      // Check default values using container
      const embeddingModelSelect = container.querySelector("#embeddingModelId") as HTMLSelectElement;
      const vectorStoreSelect = container.querySelector("#vectorStoreId") as HTMLSelectElement;
      const fileStoreSelect = container.querySelector("#fileStorageId") as HTMLSelectElement;
      expect(embeddingModelSelect.value).toBe(embeddingModules[1].id); // default embedding
      expect(vectorStoreSelect.value).toBe(vectorStores[0].id); // default vector
      expect(fileStoreSelect.value).toBe(fileStores[1].id); // default file store
    });
  });

  // 3. Edit mode populates fields from backend
  it("populates fields from backend in edit mode", async () => {
    await act(async () => {
      render(<NewDataSourceForm {...mockProps} initialDataSourceId={dataSource.id} />);
    });
    await waitFor(() => {
      expect(screen.getByDisplayValue(dataSource.name)).toBeInTheDocument();
      expect(screen.getByDisplayValue(dataSource.description)).toBeInTheDocument();
      expect(screen.getByDisplayValue(dataSource.filterTag)).toBeInTheDocument();
    });
  });

  // 4. Required fields show error if empty on submit
  it("shows error when a required field is empty and form is submitted", async () => {
    const { container } = render(<NewDataSourceForm {...mockProps} />);

    // Fill all fields with valid values using id
    fireEvent.change(container.querySelector("#name")!, { target: { value: "Test Name" } });
    fireEvent.change(container.querySelector("#description")!, { target: { value: "Test Description" } });
    fireEvent.change(container.querySelector("#filterTag")!, { target: { value: "test-filter-tag" } });
    fireEvent.change(container.querySelector("#embeddingModelId")!, { target: { value: embeddingModules[1].id } });
    fireEvent.change(container.querySelector("#vectorStoreId")!, { target: { value: vectorStores[0].id } });
    fireEvent.change(container.querySelector("#fileStorageId")!, { target: { value: fileStores[1].id } });

    // Now clear just the Name field
    fireEvent.change(container.querySelector("#name")!, { target: { value: "" } });
    fireEvent.click(screen.getByTestId("create-datasource-button"));
    await waitFor(() => {
      expect(screen.getByText("messages.nameRequired")).toBeInTheDocument();
    });
  });

  // 5. Delete button only in edit mode and for owner
  it("shows delete button in edit mode for owner", async () => {
    await act(async () => {
      render(<NewDataSourceForm {...mockProps} initialDataSourceId={dataSource.id} />);
    });
    const deleteButton = screen.getByRole("button", { name: /Delete/i });
    expect(deleteButton).toBeInTheDocument();
  });

  it("hides delete button for non-owner", async () => {
    vi.mocked(DataSourceService.getDatasourceById).mockResolvedValue({
      ...dataSource,
      accessPermission: PermissionType.READ,
      creator: { id: "someone-else", name: "Other User" },
    });
    await act(async () => {
      render(<NewDataSourceForm {...mockProps} initialDataSourceId={dataSource.id} />);
    });
    expect(screen.getByRole("button", { name: /Delete/i })).toBeDisabled();
  });
});
