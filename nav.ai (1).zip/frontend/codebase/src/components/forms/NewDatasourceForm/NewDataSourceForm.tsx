import { useEffect, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { v4 as uuidv4 } from "uuid";
import { z } from "zod";

import { Button, Form, Modal } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { DataSource, Module, ModuleType } from "../../../lib/Model";
import { authStore } from "../../../stores/useStore";
import { TranslationKeys } from "../../../types/translation-keys";
import { isAnyFormFieldDirty, typeConversionToString } from "../../../utils/agentFormFields";
import ModuleDropdown from "../../general/ModuleDropdown/ModuleDropdown";
import { useNotification } from "../../general/NotificationProvider";
import { RequiredLabel } from "../../general/RequiredLabel";
import TooltipTable from "../../general/SettingsTooltipTable";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";

export const NewDataSourceForm = ({
  handleClose,
  initialDataSourceId,
  onUpdateAgentFormDirty,
  setIsFormDirty,
  updateTrigger,
}: {
  handleClose: () => void;
  initialDataSourceId?: string;
  updateTrigger?: (res?: DataSource) => void;
  setIsFormDirty?: React.Dispatch<React.SetStateAction<boolean>>;
  onUpdateAgentFormDirty?: (isDirty: boolean) => void;
}) => {
  const userId = authStore((state) => state.user?.id);
  const { t } = useTranslation();
  const [fileStores, setFileStores] = useState<Module[]>([]);
  const [vectorStores, setVectorStores] = useState<Module[]>([]);
  const [embeddingModules, setEmbeddingModules] = useState<Module[]>([]);
  const [editDs, setEditDs] = useState<DataSource>();
  const [metaTag, setMetaTag] = useState("");
  const [loadingBtn, setLoadingBtn] = useState({
    create: false,
    delete: false,
    update: false,
  });
  const [selectedTooltip, setSelectedTooltip] = useState<string | null>(null);
  const { openErrorNotification } = useNotification();

  //datasource schema
  const dataSourceSchema = z.object({
    description: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
    embeddingModelId: z.string().nonempty(t(TranslationKeys.MESSAGES_EMBEDDINGMODELREQUIRED)),
    fileStorageId: z.string().nonempty(t(TranslationKeys.MESSAGES_FILESTOREREQUIRED)),
    filterTag: z.string().nonempty(t(TranslationKeys.MESSAGES_METATAGREQUIRED)),
    name: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
    vectorStoreId: z.string().nonempty(t(TranslationKeys.MESSAGES_VECTORSTOREREQUIRED)),
  });

  // @ts-expect-error neet to instantiate and empty object
  const [newDataSource, setNewDataSource] = useState<DataSource>({
    filterTag: uuidv4(),
  });

  const [showInfoTooltip, setShowInfoTooltip] = useState(false);

  const {
    formState: { errors },
    handleSubmit,
    register,
    setValue,
  } = useForm({
    defaultValues: {
      description: newDataSource?.description || "",
      embeddingModelId: newDataSource?.embeddingModelId || "",
      fileStorageId: newDataSource?.fileStorageId || "",
      filterTag: newDataSource?.filterTag || "",
      name: newDataSource?.name || "",
      vectorStoreId: newDataSource?.vectorStoreId || "",
    },
    mode: "onChange",
    resolver: zodResolver(dataSourceSchema),
  });

  useEffect(() => {
    const keysToCompare = ["name", "description", "embeddingModelId", "fileStorageId", "vectorStoreId"];

    const formDirty =
      isAnyFormFieldDirty(editDs as DataSource, newDataSource as DataSource, keysToCompare) ||
      typeConversionToString(metaTag) !== typeConversionToString(newDataSource?.filterTag);

    setIsFormDirty?.(formDirty);
    if (!formDirty) {
      onUpdateAgentFormDirty?.(false);
    }
  }, [editDs, newDataSource, setIsFormDirty, onUpdateAgentFormDirty, metaTag]);

  const handleCreateDataSource = async () => {
    const payload = { ...newDataSource };
    if (initialDataSourceId) {
      setLoadingBtn((prevState) => ({ ...prevState, update: true }));
      DataSourceService.updateDataSource(payload)
        .then((res) => {
          setLoadingBtn((prevState) => ({ ...prevState, update: false }));
          if (updateTrigger) updateTrigger(res);
          handleClose();
        })
        .catch((err) => {
          setLoadingBtn((prevState) => ({ ...prevState, update: false }));
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATEDATASOURCE), err as Error);
          handleClose();
        });
    } else {
      try {
        setLoadingBtn((prevState) => ({ ...prevState, create: true }));
        const response = await DataSourceService.createDataSource(payload);
        setLoadingBtn((prevState) => ({ ...prevState, create: false }));
        if (response.id) {
          if (updateTrigger) updateTrigger(response);
          handleClose();
        }
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATEDATASOURCE), error as Error);
        setLoadingBtn((prevState) => ({ ...prevState, create: false }));
      } finally {
        setLoadingBtn((prevState) => ({ ...prevState, create: false }));
        handleClose();
      }
    }
  };
  const handleDelete = () => {
    const payload = { ...newDataSource };
    setLoadingBtn((prevState) => ({ ...prevState, delete: true }));
    DataSourceService.deleteDataSource(payload)
      .then((res) => {
        if (updateTrigger) updateTrigger(res);
        handleClose();
        setLoadingBtn((prevState) => ({ ...prevState, delete: false }));
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETEDATASOURCE), err as Error);
        setLoadingBtn((prevState) => ({ ...prevState, delete: false }));
        handleClose();
      });
  };

  useEffect(() => {
    Promise.all([
      ModuleService.getModulesByType(ModuleType.EMBEDDING_MODEL),
      ModuleService.getModulesByType(ModuleType.VECTOR_STORE),
      ModuleService.getModulesByType(ModuleType.FILE_STORAGE),
    ])
      .then(([embedding, vector, fileStorage]) => {
        setEmbeddingModules(embedding);
        setVectorStores(vector);
        setFileStores(fileStorage);
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULETYPES), err as Error);
      });
  }, [openErrorNotification]);

  // Set default values after modules are loaded (for new datasource only)
  useEffect(() => {
    if (!initialDataSourceId && embeddingModules.length > 0 && vectorStores.length > 0 && fileStores.length > 0) {
      const defaultEmbedding = embeddingModules.find((m) => m.default === true);
      const defaultVector = vectorStores.find((m) => m.default === true);
      const defaultFileStore = fileStores.find((m) => m.default === true);

      if (defaultEmbedding || defaultVector || defaultFileStore) {
        setNewDataSource((prev) => ({
          ...prev,
          embeddingModelId: defaultEmbedding?.id || prev.embeddingModelId,
          fileStorageId: defaultFileStore?.id || prev.fileStorageId,
          vectorStoreId: defaultVector?.id || prev.vectorStoreId,
        }));

        // Also update the form values
        if (defaultEmbedding) {
          setValue("embeddingModelId", defaultEmbedding.id, { shouldValidate: true });
        }
        if (defaultVector) {
          setValue("vectorStoreId", defaultVector.id, { shouldValidate: true });
        }
        if (defaultFileStore) {
          setValue("fileStorageId", defaultFileStore.id, { shouldValidate: true });
        }
      }
    }
  }, [embeddingModules, vectorStores, fileStores, initialDataSourceId, setValue]);

  const handleDataSourceDetails = (
    key: string,
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setNewDataSource((prev) => ({ ...prev, [key]: e.target.value }));
  };

  useEffect(() => {
    if (initialDataSourceId) {
      DataSourceService.getDatasourceById(initialDataSourceId).then((res) => {
        setEditDs(res);
        setMetaTag(res?.filterTag ? (res.filterTag as string) : (newDataSource?.filterTag as string));
        setNewDataSource((prev) => {
          if (!res["filterTag"]) {
            return { ...prev, ...res, filterTag: uuidv4() };
          }
          return res;
        });
        setValue("name", res?.name, { shouldValidate: true });
        setValue("description", res?.description || "", {
          shouldValidate: true,
        });
        setValue("embeddingModelId", res?.embeddingModelId || "", {
          shouldValidate: true,
        });
        setValue("fileStorageId", res?.fileStorageId || "", {
          shouldValidate: true,
        });
        setValue("vectorStoreId", res?.vectorStoreId || "", {
          shouldValidate: true,
        });
        setValue("filterTag", res?.filterTag || uuidv4() || "", {
          shouldValidate: true,
        });
      });
    } else {
      setMetaTag(newDataSource?.filterTag as string);
    }
  }, [initialDataSourceId, newDataSource?.filterTag, setValue]);
  const handleDropDownClick = (moduleName: "embeddingModelId" | "vectorStoreId" | "fileStorageId", id: string) => {
    setValue(moduleName, id, {
      shouldDirty: true,
      shouldValidate: true,
    });
    setNewDataSource((prev) => ({ ...prev, [moduleName]: id }));
  };

  return (
    <>
      <Form onSubmit={handleSubmit(handleCreateDataSource)}>
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.MESSAGES_NAME, "Dataset Name")} />
          <Form.Control
            id="name"
            type="text"
            placeholder=""
            isInvalid={!!errors?.name}
            {...register("name")}
            onChange={(e) => handleDataSourceDetails("name", e)}
          />
          {errors.name && <Form.Control.Feedback type="invalid">{errors.name.message}</Form.Control.Feedback>}
        </Form.Group>
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.MESSAGES_DESCRIPTION, "Dataset Description")} />
          <Form.Control
            id="description"
            type="text"
            placeholder=""
            isInvalid={!!errors?.description}
            {...register("description")}
            onChange={(e) => handleDataSourceDetails("description", e)}
          />
          {errors.description && (
            <Form.Control.Feedback type="invalid">{errors.description.message}</Form.Control.Feedback>
          )}
        </Form.Group>

        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.MESSAGES_METATAGREQUIRED, "Meta Filter Tag (Automatic)")} />
          <Form.Control
            id="filterTag"
            type="text"
            placeholder=""
            isInvalid={!!errors?.filterTag}
            {...register("filterTag")}
            onChange={(e) => handleDataSourceDetails("filterTag", e)}
          />
          {errors.filterTag && <Form.Control.Feedback type="invalid">{errors.filterTag.message}</Form.Control.Feedback>}
          {initialDataSourceId && !editDs?.filterTag && (
            <p>
              <small className="text-danger">{t(TranslationKeys.MESSAGES_RECOMMENDUPDATEFILTERTAG)}</small>
            </p>
          )}
        </Form.Group>
        <div>
          <Form.Group className="mb-3">
            <RequiredLabel label={t(TranslationKeys.MESSAGES_EMBEDDINGMODELREQUIRED)} />
            {!embeddingModules?.every((mod) => !mod.capabilities || mod.capabilities.length === 0) && (
              <i
                className="bi bi-info-circle text-light"
                style={{ paddingLeft: "0.2rem" }}
                onClick={() => {
                  setSelectedTooltip("embeddingModel");
                  setShowInfoTooltip(true);
                }}
              ></i>
            )}
            <ModuleDropdown
              name="embeddingModelId"
              options={embeddingModules as Module[]}
              value={newDataSource.embeddingModelId || ""}
              placeholder={
                embeddingModules?.find((val) => val.id === newDataSource?.embeddingModelId)?.name ||
                t(TranslationKeys.MESSAGES_CHOOSEEMBEDDINGMODEL, "Choose Embedding Model")
              }
              onChange={(id) => handleDropDownClick("embeddingModelId", id as string)}
              registerProps={register("embeddingModelId")}
            />
            {errors.embeddingModelId && (
              <div className="invalid-feedback d-block">{String(errors?.embeddingModelId?.message)}</div>
            )}
          </Form.Group>

          <Form.Group className="mb-3">
            <RequiredLabel label={t(TranslationKeys.MESSAGES_VECTORSTOREREQUIRED, "Vector Store")} />
            {!vectorStores?.every((mod) => !mod.capabilities || mod.capabilities.length === 0) && (
              <i
                className="bi bi-info-circle text-light"
                style={{ paddingLeft: "0.2rem" }}
                onClick={() => {
                  setSelectedTooltip("vectorStore");
                  setShowInfoTooltip(true);
                }}
              ></i>
            )}
            <ModuleDropdown
              name="vectorStoreId"
              options={vectorStores as Module[]}
              value={newDataSource.vectorStoreId || ""}
              placeholder={
                vectorStores?.find((val) => val.id === newDataSource?.vectorStoreId)?.name ||
                t(TranslationKeys.MESSAGES_CHOOSEVECTORSTORE, "Choose Vector Store")
              }
              onChange={(id) => handleDropDownClick("vectorStoreId", id as string)}
              registerProps={register("vectorStoreId")}
            />
            {errors.vectorStoreId && (
              <div className="invalid-feedback d-block">{String(errors?.vectorStoreId?.message)}</div>
            )}
          </Form.Group>
          <Form.Group className="mb-4">
            <RequiredLabel label={t(TranslationKeys.MESSAGES_FILESTOREREQUIRED, "File Store")} />
            {!fileStores?.every((mod) => !mod.capabilities || mod.capabilities.length === 0) && (
              <i
                className="bi bi-info-circle text-light"
                style={{ paddingLeft: "0.2rem" }}
                onClick={() => {
                  setSelectedTooltip("fileStore");
                  setShowInfoTooltip(true);
                }}
              ></i>
            )}
            <ModuleDropdown
              name="fileStorageId"
              options={fileStores as Module[]}
              value={newDataSource.fileStorageId || ""}
              placeholder={
                fileStores?.find((val) => val.id === newDataSource.fileStorageId)?.name ||
                t(TranslationKeys.MESSAGES_CHOOSEFILESTORE, "Choose File Store")
              }
              onChange={(id) => handleDropDownClick("fileStorageId", id as string)}
              registerProps={register("fileStorageId")}
            />
            {errors.fileStorageId && (
              <div className="invalid-feedback d-block">{String(errors?.fileStorageId?.message)}</div>
            )}
          </Form.Group>
          <div className={`d-flex ${initialDataSourceId ? "justify-content-between" : "justify-content-end"}`}>
            {initialDataSourceId &&
              (loadingBtn && loadingBtn.delete ? (
                <button className="btn btn-danger" type="button" name="delete" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING, "Loading...")}
                </button>
              ) : (
                <Button variant="danger" onClick={handleDelete} disabled={editDs?.creator.id !== userId}>
                  {t(TranslationKeys.AGENTWORKFLOWFORM_DELETE, "Delete")}
                </Button>
              ))}
            {loadingBtn && (loadingBtn.create || loadingBtn.update) ? (
              <button className="btn btn-primary" type="button" disabled>
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                &nbsp;{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING, "Loading...")}
              </button>
            ) : (
              <Button type="submit" className="button" size="sm" data-testid="create-datasource-button">
                {!initialDataSourceId ? (
                  <>{t(TranslationKeys.MESSAGES_CREATEDATASOURCE, "Create Dataset")}</>
                ) : (
                  <>{t(TranslationKeys.MESSAGES_UPDATEDATASOURCE, "Update Dataset")}</>
                )}
              </Button>
            )}
          </div>
        </div>
      </Form>

      {/* Info tooltip for AI model selection */}
      <Modal
        show={showInfoTooltip}
        onHide={() => setShowInfoTooltip(false)}
        backdrop="static"
        size="lg"
        centered
        className="text-light custom-modal-backdrop capabilities-modal"
      >
        <Modal.Header style={{ fontWeight: "bold" }} closeButton>
          {selectedTooltip == "embeddingModel"
            ? t(TranslationKeys.AGENTFORM_EMBEDDINGMODELS)
            : selectedTooltip == "vectorStore"
              ? t(TranslationKeys.AGENTFORM_VECTORSTORES)
              : t(TranslationKeys.AGENTFORM_FILESTORES)}
        </Modal.Header>
        <Modal.Body>
          <TooltipTable
            tooltipData={
              selectedTooltip == "embeddingModel"
                ? embeddingModules
                : selectedTooltip == "vectorStore"
                  ? vectorStores
                  : fileStores
            }
          />
        </Modal.Body>
      </Modal>
    </>
  );
};
