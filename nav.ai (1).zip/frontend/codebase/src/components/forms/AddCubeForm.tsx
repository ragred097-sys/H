import { BaseSyntheticEvent, useEffect, useState } from "react";

import { Button, Form } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Cube, Tag } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { useFilterTags } from "../../utils/tagsHelper";
import DropdownSelect, { TagOrCustom } from "../general/Dropdown";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import { useNotification } from "../general/NotificationProvider";
import { TagService } from "./../../services/TagService";

interface CubeFormProps {
  cubeData?: Cube; //cube category data
  setIsFormDirty?: React.Dispatch<React.SetStateAction<boolean>>;
  handleClose?: () => void;
  handleUpdate?: () => void;
}
const AddCubeForm = ({ cubeData, handleClose, handleUpdate }: CubeFormProps) => {
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();
  const [allSelectedTags, setAllSelectedTags] = useState<TagOrCustom[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [loadingBtn, setLoadingBtn] = useState(false);
  const { filteredTags, loadTags } = useFilterTags();
  useEffect(() => {
    fetchTags();
  }, [loadTags]);
  const fetchTags = async () => {
    setTags(filteredTags);
  };
  const submitHandler = async (e: BaseSyntheticEvent) => {
    e.preventDefault();
    const selected = allSelectedTags.filter((tag) => "id" in tag); //tags selected from the list
    const newCreated = allSelectedTags.filter((tag) => "tempId" in tag)?.map((tag) => tag.name);
    try {
      setLoadingBtn(true);

      const [createdTags, updatedTags] = await Promise.all([
        await TagService.createTags(newCreated, cubeData as Cube),
        await TagService.updateTags(selected, cubeData as Cube),
      ]);
      const data = [...updatedTags, ...createdTags];
      if (data.length) {
        openNotification(t(TranslationKeys.MESSAGES_ADDTAGTOCATEGORYSUCCESS), "primary");
      }
      setAllSelectedTags(data);
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_ADDTAGTOCATEGORY), error as Error);
    } finally {
      setLoadingBtn(false);
      handleClose?.();
      handleUpdate?.();
    }
  };
  return (
    <>
      <Form className="pt-2">
        <Form.Group className="mb-3">
          <Form.Label>{t(TranslationKeys.CUBES_TAGS)}</Form.Label>
          <DropdownSelect options={tags} selectedTags={allSelectedTags} setSelectedTags={setAllSelectedTags} />
        </Form.Group>
        <div className="text-end me-2">
          {loadingBtn ? (
            <LoadingButton className={"btn btn-primary"} />
          ) : (
            <Button
              variant="primary"
              className="button"
              onClick={(e) => submitHandler(e)}
              disabled={allSelectedTags?.length == 0}
            >
              {t(TranslationKeys.CUBES_ADD)}
            </Button>
          )}
        </div>
      </Form>
    </>
  );
};
export default AddCubeForm;
