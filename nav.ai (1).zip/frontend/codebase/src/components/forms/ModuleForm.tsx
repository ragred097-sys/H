import React, { useEffect, useState } from "react";

import { Spinner } from "react-bootstrap";

import { Module, ModuleSpecification } from "../../lib/Model";
import { ModuleService } from "./../../services/ModuleService";
import { DynamicForm } from "./DynamicForm";

type ModuleFormProps = {
  type?: string;
  defaultValues?: Module;
  handleClose: () => void;
  updateTrigger?: (data?: Module) => void;
};

export const ModuleForm: React.FC<ModuleFormProps> = ({ defaultValues, handleClose, type, updateTrigger }) => {
  const [providers, setProviders] = useState<ModuleSpecification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProviders = async () => {
      setLoading(true);
      try {
        const res = await ModuleService.getModuleSpecifications();
        if (type) {
          setProviders(res?.filter((module) => module.type === type));
        } else {
          if (defaultValues) {
            const provider = res?.find((module) => module.id === defaultValues.specId);
            if (provider) {
              setProviders(res?.filter((module) => module.type === provider.type));
            }
          }
        }
      } catch (err) {
        console.log(err);
      } finally {
        setLoading(false);
      }
    };

    fetchProviders();
  }, []);

  return (
    <div>
      {loading && (
        <div className="d-flex justify-content-center align-items-center" style={{ height: "10rem" }}>
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        </div>
      )}

      {!loading && providers.length > 0 && (
        <DynamicForm
          providers={providers}
          defaultValues={defaultValues}
          handleClose={handleClose}
          updateTrigger={updateTrigger}
        />
      )}
    </div>
  );
};
