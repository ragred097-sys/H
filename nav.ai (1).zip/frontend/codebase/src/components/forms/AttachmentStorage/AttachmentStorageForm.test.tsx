import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { vi } from "vitest";

import { AttachmentStorageTable } from "./AttachmentStorageForm";
import { DocumentTypeConfig } from "../../../hooks/useAttachmentStorage";
import { DocumentType } from "../../../lib/Model";
import { ModuleService } from "../../../services/ModuleService";

// Mock react-i18next
vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string, fallback?: string) => fallback || key,
  }),
}));

interface AttachmentStorages {
  fileStorageId: string | null;
  type: DocumentType | null;
}

const mockFileStorages = [
  {
    __type_name: "Module",
    createdAt: "2025-03-15T06:09:49.863659",
    creator: { __type_name: "User", id: "59c52dc8-14bf-4f58-b907-01a6f9307a7f", name: "Ion Caza" },
    default: false,
    description: undefined,
    favorite: false,
    id: "48faac89-3ed3-4692-8b7e-d05f8b6df9fc",
    modifiedAt: "2025-06-25T06:46:51.246092",
    modifier: { __type_name: "User", id: "394b36a1-1486-45c4-b26c-b38e06f2dfee", name: "Shilpa Herle" },
    name: "MinIO File Storage",
    parameters: [],
    specId: "1e77cd2f-39d4-457a-84bd-950ea488cac3",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "2025-06-03T13:00:41.304786",
    creator: { __type_name: "User", id: "a24635bc-d289-41c2-bf3d-b984593677a6", name: "Patrick Rump" },
    default: false,
    description: undefined,
    favorite: false,
    id: "4a8a28b1-eda5-4ab9-952a-43cd9c708e0c",
    modifiedAt: "2025-06-06T10:45:17.297986",
    modifier: { __type_name: "User", id: "a24635bc-d289-41c2-bf3d-b984593677a6", name: "Patrick Rump" },
    name: "Nvidia VSS V2 Storage",
    parameters: [],
    specId: "df96ca9b-45ad-478d-8acd-91d2ae38c9b6",
    supportedInputs: [],
    tags: [],
  },
];

const mockAttachmentStorageDefaults: AttachmentStorages[] = [
  { fileStorageId: mockFileStorages[0].id, type: DocumentType.IMAGE },
  { fileStorageId: mockFileStorages[1].id, type: DocumentType.VIDEO },
];

describe("AttachmentStorageTable", () => {
  let mockOnTypeToggle: (type: DocumentType) => void;
  let mockOnFileStorageChange: (type: DocumentType, fileStorageId: string | null) => void;

  beforeEach(() => {
    vi.spyOn(ModuleService, "getModulesByType").mockResolvedValue(mockFileStorages);
    mockOnTypeToggle = vi.fn();
    mockOnFileStorageChange = vi.fn();
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  const createMockConfigs = (enabled: { [key in DocumentType]?: boolean } = {}): DocumentTypeConfig[] => {
    return Object.values(DocumentType).map((type) => {
      const isEnabled = enabled[type] || false;
      const defaultMapping = mockAttachmentStorageDefaults.find((d) => d.type === type);
      return {
        enabled: isEnabled,
        fileStorageId: isEnabled ? defaultMapping?.fileStorageId || null : null,
        type,
      };
    });
  };

  it("renders all document types as checkboxes", async () => {
    const configs = createMockConfigs();

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Check that all document types are rendered as checkboxes
    Object.values(DocumentType).forEach((type) => {
      expect(screen.getByLabelText(type)).toBeInTheDocument();
    });
  });

  it("shows dropdown when checkbox is checked", async () => {
    const configs = createMockConfigs({ [DocumentType.IMAGE]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // IMAGE checkbox should be checked and dropdown should be visible
    const imageCheckbox = screen.getByLabelText(DocumentType.IMAGE);
    expect(imageCheckbox).toBeChecked();

    // Wait for file storage options to load and find the dropdown
    await waitFor(() => {
      const dropdown = screen.getByRole("combobox");
      expect(dropdown).toBeInTheDocument();
      // Check that the dropdown has the correct value set
      expect(dropdown).toHaveValue(mockFileStorages[0].id);
    });
  });

  it("calls onTypeToggle when checkbox is clicked", async () => {
    const configs = createMockConfigs();

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    const imageCheckbox = screen.getByLabelText(DocumentType.IMAGE);

    await act(async () => {
      fireEvent.click(imageCheckbox);
    });

    expect(mockOnTypeToggle).toHaveBeenCalledWith(DocumentType.IMAGE);
  });

  it("calls onFileStorageChange when dropdown value changes", async () => {
    const configs = createMockConfigs({ [DocumentType.IMAGE]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Wait for dropdown to be available
    await waitFor(() => {
      const dropdown = screen.getByRole("combobox");
      expect(dropdown).toBeInTheDocument();
    });

    const dropdown = screen.getByRole("combobox");

    await act(async () => {
      fireEvent.change(dropdown, { target: { value: mockFileStorages[1].id } });
    });

    expect(mockOnFileStorageChange).toHaveBeenCalledWith(DocumentType.IMAGE, mockFileStorages[1].id);
  });

  it("shows default label only on default options", async () => {
    const configs = createMockConfigs({ [DocumentType.IMAGE]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Wait for file storage options to load
    await waitFor(() => {
      expect(screen.getByText("MinIO File Storage Default")).toBeInTheDocument();
    });

    // Only the default option should have the "Default" label
    expect(screen.getByText("MinIO File Storage Default")).toBeInTheDocument();
    expect(screen.getByText("Nvidia VSS V2 Storage")).toBeInTheDocument();
    expect(screen.queryByText("Nvidia VSS V2 Storage Default")).not.toBeInTheDocument();
  });

  it("renders multiple enabled document types with their respective dropdowns", async () => {
    const configs = createMockConfigs({
      [DocumentType.IMAGE]: true,
      [DocumentType.VIDEO]: true,
    });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Both checkboxes should be checked
    expect(screen.getByLabelText(DocumentType.IMAGE)).toBeChecked();
    expect(screen.getByLabelText(DocumentType.VIDEO)).toBeChecked();

    // Wait for both dropdowns to appear
    await waitFor(() => {
      const dropdowns = screen.getAllByRole("combobox");
      expect(dropdowns).toHaveLength(2);
    });
  });

  it("hides dropdown when checkbox is unchecked", async () => {
    const configs = createMockConfigs();

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // No checkboxes should be checked initially
    Object.values(DocumentType).forEach((type) => {
      expect(screen.getByLabelText(type)).not.toBeChecked();
    });

    // No dropdowns should be visible
    expect(screen.queryByRole("combobox")).not.toBeInTheDocument();
  });

  it("displays correct default file storage for each document type", async () => {
    const configs = createMockConfigs({
      [DocumentType.IMAGE]: true,
      [DocumentType.VIDEO]: true,
    });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Wait for dropdowns to load
    await waitFor(() => {
      const dropdowns = screen.getAllByRole("combobox");
      expect(dropdowns).toHaveLength(2);
    });

    // Check that each dropdown has the correct default value
    const dropdowns = screen.getAllByRole("combobox") as HTMLSelectElement[];

    // The first dropdown should be for IMAGE (since that's the order they appear in the enum)
    expect(dropdowns[0].value).toBe(mockFileStorages[0].id);
    // The second dropdown should be for VIDEO
    expect(dropdowns[1].value).toBe(mockFileStorages[1].id);
  });

  it("handles checkbox toggle correctly", async () => {
    const configs = createMockConfigs({ [DocumentType.IMAGE]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    const imageCheckbox = screen.getByLabelText(DocumentType.IMAGE);
    const videoCheckbox = screen.getByLabelText(DocumentType.VIDEO);

    // IMAGE should be checked, VIDEO should not
    expect(imageCheckbox).toBeChecked();
    expect(videoCheckbox).not.toBeChecked();

    // Only one dropdown should be visible
    await waitFor(() => {
      const dropdowns = screen.getAllByRole("combobox");
      expect(dropdowns).toHaveLength(1);
    });

    // Toggle VIDEO checkbox
    await act(async () => {
      fireEvent.click(videoCheckbox);
    });

    expect(mockOnTypeToggle).toHaveBeenCalledWith(DocumentType.VIDEO);
  });

  it("renders file storage options with correct default labels", async () => {
    const configs = createMockConfigs({ [DocumentType.VIDEO]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Wait for dropdown to load
    await waitFor(() => {
      const dropdown = screen.getByRole("combobox");
      expect(dropdown).toBeInTheDocument();
      expect(dropdown).toHaveValue(mockFileStorages[1].id);
    });

    // Check that the default option for VIDEO (Nvidia VSS V2 Storage) has the default label
    expect(screen.getByText("Nvidia VSS V2 Storage Default")).toBeInTheDocument();
    expect(screen.getByText("MinIO File Storage")).toBeInTheDocument();
    expect(screen.queryByText("MinIO File Storage Default")).not.toBeInTheDocument();
  });

  it("calls onFileStorageChange when dropdown value changes to different storage", async () => {
    const configs = createMockConfigs({ [DocumentType.IMAGE]: true });

    await act(async () => {
      render(
        <AttachmentStorageTable
          documentTypeConfigs={configs}
          onTypeToggle={mockOnTypeToggle}
          onFileStorageChange={mockOnFileStorageChange}
          attachmentStorageDefaults={mockAttachmentStorageDefaults}
        />
      );
    });

    // Wait for dropdown to load
    await waitFor(() => {
      const dropdown = screen.getByRole("combobox");
      expect(dropdown).toBeInTheDocument();
    });

    const dropdown = screen.getByRole("combobox");

    // Change to different file storage
    await act(async () => {
      fireEvent.change(dropdown, { target: { value: mockFileStorages[1].id } });
    });

    expect(mockOnFileStorageChange).toHaveBeenCalledWith(DocumentType.IMAGE, mockFileStorages[1].id);
  });
});
