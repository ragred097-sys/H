import React, { useEffect, useMemo, useState } from "react";

import { Form, FormCheck } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { DocumentTypeConfig } from "../../../hooks/useAttachmentStorage";
import { AttachmentStorages, DocumentType, Module, ModuleType } from "../../../lib/Model";
import { TranslationKeys } from "../../../types/translation-keys";
import { ModuleService } from "./../../../services/ModuleService";

type Props = {
  documentTypeConfigs: DocumentTypeConfig[];
  onTypeToggle: (type: DocumentType) => void;
  onFileStorageChange: (type: DocumentType, fileStorageId: string | null) => void;
  attachmentStorageDefaults?: AttachmentStorages[];
};

export const AttachmentStorageTable: React.FC<Props> = React.memo(
  ({ attachmentStorageDefaults, documentTypeConfigs, onFileStorageChange, onTypeToggle }) => {
    const [fileStorageOptions, setFileStoreOptions] = useState<Module[]>([]);
    const { t } = useTranslation();

    const fileStoreOptionsSorted = useMemo(
      () => fileStorageOptions.slice().sort((a, b) => a.name.localeCompare(b.name)),
      [fileStorageOptions]
    );

    useEffect(() => {
      ModuleService.getModulesByType(ModuleType.FILE_STORAGE)
        .then(setFileStoreOptions)
        .catch(() => setFileStoreOptions([]));
    }, []);

    return (
      <div className="flex-direction-column">
        <div className="mb-3">
          <h6 className="mb-2">
            {t(TranslationKeys.STORAGEATTACHMENTSFORM_CHOOSEFILETYPE, "Select File Types for Attachment Storage")}
          </h6>
          {documentTypeConfigs.map((config) => (
            <div key={config.type} className="mb-3">
              <div className="d-flex align-items-center gap-3" style={{ minWidth: 350 }}>
                <FormCheck
                  type="checkbox"
                  id={`checkbox-${config.type}`}
                  checked={config.enabled}
                  onChange={() => onTypeToggle(config.type)}
                  label={config.type}
                  className="mb-0"
                  style={{ minWidth: 90 }}
                />
                {config.enabled && (
                  <div style={{ flexGrow: 1 }}>
                    <Form.Select
                      value={config.fileStorageId || ""}
                      onChange={(e) => onFileStorageChange(config.type, e.target.value || null)}
                      className="ms-2"
                      style={{
                        fontSize: "0.875rem",
                        maxWidth: 350,
                        minWidth: 220, // Fixed width for all dropdowns
                      }}
                    >
                      <option value="">
                        {t(TranslationKeys.STORAGEATTACHMENTSFORM_CHOOSEFILESTORE, "Choose File Store")}
                      </option>
                      {fileStoreOptionsSorted.map((fs) => {
                        const defaultMapping = attachmentStorageDefaults?.find(
                          (mapping) => mapping.type === config.type
                        );
                        const isDefault = defaultMapping?.fileStorageId === fs.id;
                        return (
                          <option key={fs.id} value={fs.id} className={isDefault ? "select-default" : ""}>
                            {fs.name}
                            {isDefault ? " Default" : ""}
                          </option>
                        );
                      })}
                    </Form.Select>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
);
