import { useEffect, useState } from "react";

import { Button, Form, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Agent, AgentWorkflow, Assistant, AssistantGovernanceConfiguration } from "../../lib/Model";
import { GovernanceService } from "../../services/GovernanceService";
import { TranslationKeys } from "../../types/translation-keys";
import { useNotification } from "../general/NotificationProvider";

export const GovernanceForm = ({
  handleClose,
  initialData,
}: {
  handleClose: (governanceConfiguration: AssistantGovernanceConfiguration) => void;
  initialData: Assistant | Agent | AgentWorkflow;
}) => {
  const [loading, setLoading] = useState(false);
  const { openErrorNotification } = useNotification();
  const [governanceConfiguration, setGovernanceConfiguration] = useState<AssistantGovernanceConfiguration>();
  const [indicatorUuid, setindicatorUuid] = useState<string | null>(null);
  const { t } = useTranslation();

  useEffect(() => {
    setindicatorUuid(governanceConfiguration?.thumbs_indicator_uuid ?? null);
  }, [governanceConfiguration?.thumbs_indicator_uuid]);

  const handleIndicatorUuidChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setindicatorUuid(e.target.value);
  };

  const submitHandler = () => {
    if (governanceConfiguration) {
      governanceConfiguration.thumbs_indicator_uuid = indicatorUuid === "" ? null : indicatorUuid;
      GovernanceService.updateAgenticGovernanceConfiguration(initialData as Agent, governanceConfiguration);
      handleClose(governanceConfiguration);
    } else {
      const err = new Error("Governance configuration not found");
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATEGOVERNANCECONFIG), err);
      console.error("Error updating governance configuration:", err);
    }
  };

  useEffect(() => {
    setLoading(true);
    GovernanceService.getAgenticGovernanceConfiguration(initialData as Agent)
      .then((res) => {
        setGovernanceConfiguration(res);
        setLoading(false);
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCECONFIGURATION), err as Error);
        console.error("Error fetching governance configuration:", err);
        setLoading(false);
      });
  }, []);

  return loading ? (
    <Spinner />
  ) : (
    <>
      <Form>
        <Form.Label>{t(TranslationKeys.GOVERNANCEFORM_THUMBSUPDOWNINDICATOR)}</Form.Label>
        <Form.Control type="text" onChange={handleIndicatorUuidChange} value={indicatorUuid ?? ""}></Form.Control>
      </Form>
      <div className="text-end pt-2">
        <Button onClick={submitHandler}>{t(TranslationKeys.GOVERNANCEFORM_SETINDICATORUUID)}</Button>
      </div>
    </>
  );
};
