import { useCallback, useEffect, useRef, useState } from "react";

import { Button, Form, Table } from "react-bootstrap";
import { Typeahead, TypeaheadRef } from "react-bootstrap-typeahead";
import { useTranslation } from "react-i18next";

import { Conversation, DataSource, IngestionProcessStatus, Module, ModuleType } from "../../../lib/Model";
import { TranslationKeys } from "../../../types/translation-keys";
import { DEFAULT, MAX_IMAGE_UPLOAD_SIZE } from "../../../utils/constants";
import { getOrCreateConvoDataSource } from "../../../utils/crudUtils";
import { notificationFormatter } from "../../../utils/stringUtils";
import { typeaheadDefaultSelectStyle } from "../../../utils/typeaheadDefaultSelectStyle";
import { useNotification } from "../../general/NotificationProvider";
import { FileTracker, FileTrackerStatus, UploadProgress } from "../../general/UploadProgress/UploadProgress";
import { ConversationService } from "./../../../services/ConversationService";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";

const nvModuleSpecId = "c7bf8553-f4b5-4f2e-a168-b1ff3bd23cd4";

const allowableTypes =
  ".mov, .doc,.docx,.pdf,.txt,.rtf,.odt,.xls,.xlsx,.csv,.ods,.ppt,.pptx, .odp,image/png, image/jpeg, image/jpg, image/webp, image/svg+xml, image/gif, image/bmp, video/mp4, video/mov, video/webm, video/ogg, video/avi, video/mpeg";

const FileTable = ({ files }: { files: File[] }) => {
  return (
    <Table responsive striped>
      <thead>
        <tr>
          <td>File Name</td>
          <td>Status</td>
        </tr>
      </thead>
      <tbody>
        {files.map((file) => (
          <tr key={file.name}>
            <td>{file.name}</td>
            <td>Ready for Processing</td>
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

export default function UploadDataForm({
  conversation,
  dataSource,
  handleClose,
  model,
  selectedAi,
}: {
  dataSource?: DataSource;
  model?: Module;
  handleClose: () => void;
  conversation?: Conversation;
  selectedAi?: Module;
}) {
  const [candidateFiles, setCandidateFiles] = useState<File[]>([]);
  const [selectedDataSource, setSelectedDataSource] = useState<DataSource>();
  const [selectedModel, setSelectedModel] = useState<Module | null>(model || null);
  const [uploadStatus, setUploadStatus] = useState<FileTracker[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [fileStatuses, setFileStatuses] = useState<Record<string, FileTrackerStatus>>({});
  const [aiModels, setAiModels] = useState<Module[]>([]);
  const [selectedAiModel, setselectedAiModel] = useState<Module>();
  const [defaultModel, setDefaultModel] = useState<Module>();
  const [disableChooseFiles, setDisableChooseFiles] = useState(false);
  const [allFinished, setAllFinished] = useState(false);
  const [filesLength, setFilesLength] = useState(0);
  const [errorFileCount, setErrorFileCount] = useState(0);
  const typeaheadRef = useRef<TypeaheadRef>(null);
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();

  useEffect(() => {
    ModuleService.getModulesByType(ModuleType.LLM)
      .then((res) => {
        setAiModels(
          res?.map((model) => ({
            ...model,
            name: model?.default ? `${model.name}${DEFAULT}` : model.name,
          }))
        );
        if (!selectedAi) {
          //selectedai prop is undefined
          const defaultLlm = res?.find((model) => model.default);
          if (defaultLlm) {
            setselectedAiModel(defaultLlm);
            setDefaultModel(defaultLlm);
          } else {
            setselectedAiModel(res[0]);
            setDefaultModel(res[0]); //set first as a default one (this state remain untouched on onchange method)
          }
        }
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULES), err as Error);
      });
  }, []);

  useEffect(() => {
    if (selectedAi) {
      setselectedAiModel(selectedAi);
    }
  }, []);

  const fileTimeoutHandler = (dataObjects: any[], file: File) => {
    const ingestionStatus = dataObjects[0];
    const fileUploadDone = dataObjects[1];
    if (fileUploadDone && "currentStep" in ingestionStatus) {
      if (ingestionStatus?.currentStep == 5) {
        //success case
        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: FileTrackerStatus.DONE,
        }));
      } else {
        //large file case
        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: FileTrackerStatus.ERROR,
        }));
      }
    }
  };
  const processSingleFile = async (file: File) => {
    setUploadStatus((prev) => {
      const newStatus = {
        error: undefined,
        file,
        ingestionStatus: null,
        status: FileTrackerStatus.TRANSFERRING,
      };
      return [...(prev || []), newStatus];
    });
    if (selectedModel?.specId === nvModuleSpecId) {
      try {
        const dataObjects = await ConversationService.ingestVideoAttachment(
          file as File,
          conversation as Conversation,
          (update: IngestionProcessStatus) => {
            setUploadStatus((prev) => {
              const updatedStatus = (prev || []).map((tracker) =>
                tracker.file.name === file!.name
                  ? {
                      ...tracker,
                      error: update.currentStepName.startsWith("Error") ? "ERROR" : undefined,
                      ingestionStatus: {
                        ...update,
                      },
                      status: update.currentStepName.startsWith("Error")
                        ? FileTrackerStatus.PROCESSING
                        : FileTrackerStatus.ERROR,
                    }
                  : tracker
              );
              return updatedStatus;
            });
          }
        );
        // @ts-expect-error type definition
        setUploadStatus((prev) => {
          const updatedStatus = (prev || []).map((tracker) =>
            tracker.file.name === file!.name
              ? {
                  ...tracker,
                  ingestionStatus: {
                    ...tracker.ingestionStatus,
                    dataObjects,
                  },
                  status: FileTrackerStatus.DONE,
                }
              : tracker
          );
          return updatedStatus;
        });
        fileTimeoutHandler(dataObjects, file);
      } catch (error) {
        setUploadStatus((prev) => {
          const updatedStatus = (prev || []).map((tracker) =>
            tracker.file.name === file!.name
              ? {
                  ...tracker,
                  error: "ERROR",
                  status: FileTrackerStatus.ERROR,
                }
              : tracker
          );
          return updatedStatus;
        });
        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: FileTrackerStatus.ERROR,
        }));
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADVIDEO), error as Error);
      }
    } else {
      try {
        const dataObjects =
          file && file.type.startsWith("image/")
            ? await DataSourceService.ingestImage(
                file as File,
                selectedDataSource as DataSource,
                selectedAiModel as Module,
                (update: IngestionProcessStatus) => {
                  setUploadStatus((prev) => {
                    const updatedStatus = (prev || []).map((tracker) =>
                      tracker.file.name === file!.name
                        ? {
                            ...tracker,
                            error: update.currentStepName.startsWith("Error") ? "ERROR" : undefined,
                            ingestionStatus: {
                              ...update,
                            },
                            status: update.currentStepName.startsWith("Error")
                              ? FileTrackerStatus.PROCESSING
                              : FileTrackerStatus.ERROR,
                          }
                        : tracker
                    );
                    return updatedStatus;
                  });
                }
              )
            : await DataSourceService.ingestFile(
                file as File,
                selectedDataSource as DataSource,
                selectedAiModel as Module,
                (update: IngestionProcessStatus) => {
                  setUploadStatus((prev) => {
                    const updatedStatus = (prev || []).map((tracker) =>
                      tracker.file.name === file!.name
                        ? {
                            ...tracker,
                            error: update.currentStepName.startsWith("Error") ? "ERROR" : undefined,
                            ingestionStatus: {
                              ...update,
                            },
                            status: update.currentStepName.startsWith("Error")
                              ? FileTrackerStatus.ERROR
                              : FileTrackerStatus.PROCESSING,
                          }
                        : tracker
                    );
                    return updatedStatus;
                  });
                }
              );
        // @ts-expect-error type definition
        setUploadStatus((prev) => {
          const updatedStatus = (prev || []).map((tracker) =>
            tracker.file.name === file!.name
              ? {
                  ...tracker,
                  ingestionStatus: {
                    ...tracker.ingestionStatus,
                    dataObjects,
                  },
                  status: FileTrackerStatus.DONE,
                }
              : tracker
          );
          return updatedStatus;
        });
        fileTimeoutHandler(dataObjects, file);
      } catch (error) {
        setUploadStatus((prev) => {
          const updatedStatus = (prev || []).map((tracker) =>
            tracker.file.name === file!.name
              ? {
                  ...tracker,
                  error: "ERROR",
                  status: FileTrackerStatus.ERROR,
                }
              : tracker
          );
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error as Error);
          return updatedStatus;
        });
        setFileStatuses((prev) => ({
          ...prev,
          [file.name]: FileTrackerStatus.ERROR,
        }));
      }
    }
  };
  useEffect(() => {
    if (Object.keys(fileStatuses)?.length === filesLength) {
      setAllFinished(
        Object.values(fileStatuses).length > 0 &&
          Object.values(fileStatuses).every((fs) => fs === FileTrackerStatus.DONE || fs === FileTrackerStatus.ERROR)
      );
      setIsUploading(false); //received status of all files, update uploading to false
      const errorCount = Object.values(fileStatuses).filter((fs) => fs === FileTrackerStatus.ERROR)?.length;
      setErrorFileCount(errorCount);
    }
  }, [fileStatuses]);
  const processFiles = useCallback(async () => {
    console.debug("Starting file processing...");

    // Ensure no duplicate files
    const uniqueFiles = Array.from(new Set(candidateFiles.map((file) => file.name))).map((name) =>
      candidateFiles.find((file) => file.name === name)
    );
    await Promise.allSettled(uniqueFiles.map((file) => processSingleFile(file as File)));
    setFilesLength(uniqueFiles.length);
  }, [candidateFiles, conversation, selectedDataSource, selectedModel]);

  useEffect(() => {
    if (selectedDataSource) {
      setIsUploading(true);
    }
  }, [selectedDataSource]);

  useEffect(() => {
    if (conversation)
      ModuleService.getModuleById(conversation.llmIds[0])
        .then((res) => {
          setSelectedModel(res);
          setselectedAiModel(res);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULE), err as Error);
        });
  }, [conversation]);

  useEffect(() => {
    if (isUploading && selectedDataSource && selectedAiModel) {
      processFiles();
    }
  }, [isUploading, processFiles, selectedDataSource, selectedAiModel]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.some((file) => file.type.startsWith("image/") && file.size > MAX_IMAGE_UPLOAD_SIZE)) {
      openErrorNotification(
        notificationFormatter(t(TranslationKeys.ERRORMESSAGES_IMAGEUPLOADSIZEERROR), [
          (MAX_IMAGE_UPLOAD_SIZE / 1024 / 1024).toString(),
        ])
      );
      setCandidateFiles([]);
      return;
    } else setCandidateFiles(files);
  };

  const handleSubmit = async () => {
    setDisableChooseFiles(true);
    if (dataSource && selectedModel) {
      console.debug(
        `Datasource with name: ${dataSource.name} and id: ${dataSource.id} passed to component, using that`
      );
      setSelectedDataSource(dataSource);
    } else if (conversation) {
      const [newDataSource, modelInfo] = await getOrCreateConvoDataSource(conversation);
      console.debug("Uploading in Conversation mode");
      console.debug("Conversation Info:", conversation);
      console.debug("Data Source", newDataSource, "Model", modelInfo);

      setSelectedDataSource(newDataSource);
    } else {
      setSelectedDataSource(dataSource);
    }
  };
  return (
    <>
      <Form>
        <Form.Group controlId="formFileMultiple" className="mb-3">
          <Form.Label>Model for metadata extraction and summarization</Form.Label>
          <Typeahead
            id="module-typeahead"
            className="custom-ai-model-typeahead"
            inputProps={
              {
                "data-testid": "typeahead-test-id",
              } as unknown as React.InputHTMLAttributes<HTMLInputElement>
            }
            labelKey={"name"}
            renderMenuItemChildren={(option) => {
              const data = option as Module;
              const styles = typeaheadDefaultSelectStyle({
                defaultId: aiModels?.find((model) => model.default)?.id,
                optionId: data.id,
                selectedId: selectedAiModel?.id || "",
              });
              return (
                <div
                  className={aiModels?.find((model) => model.default)?.id === data?.id ? "select-default" : ""}
                  style={styles}
                >
                  {data.name}
                </div>
              );
            }}
            defaultSelected={
              selectedAi
                ? [
                    {
                      ...selectedAi,
                      name: selectedAi.default ? `${selectedAi.name}${DEFAULT}` : selectedAi.name,
                    },
                  ]
                : []
            }
            ref={typeaheadRef}
            options={aiModels}
            placeholder={
              selectedAi
                ? selectedAi.default
                  ? `${selectedAi.name}${DEFAULT}`
                  : `${selectedAi.name}`
                : selectedAiModel
                  ? selectedAiModel.default
                    ? `${selectedAiModel.name}${DEFAULT}`
                    : selectedAiModel.name
                  : ""
            }
            onChange={(aiMod) => {
              const newSelect = aiMod[0] as Module;
              if (newSelect) {
                setselectedAiModel(aiMod[0] as Module);
              } else {
                if (selectedAi) {
                  setselectedAiModel(selectedAi);
                } else {
                  setselectedAiModel(defaultModel as Module);
                }
              }
            }}
            style={{ marginBottom: "0.8rem" }}
          />
          <Form.Control
            className="custom-file-input"
            data-testId="file-upload-input"
            type="file"
            accept={allowableTypes}
            multiple
            onChange={handleFileChange}
            disabled={disableChooseFiles}
          />
        </Form.Group>
      </Form>

      {candidateFiles.length > 0 && !uploadStatus ? (
        <>
          <FileTable files={candidateFiles} />
        </>
      ) : (
        <></>
      )}
      {uploadStatus.length > 0 && <UploadProgress progress={uploadStatus} />}
      {/* display a message after all files settle down(if any file failed to upload) */}
      {errorFileCount > 0 && (
        <div>
          <p
            style={{
              color: "#3A7ECC",
              textAlign: "right",
            }}
          >{`${errorFileCount} ${errorFileCount === 1 ? t(TranslationKeys.ERRORMESSAGES_FILEUPLOAD) : t(TranslationKeys.ERRORMESSAGES_FILESUPLOAD)}`}</p>
        </div>
      )}
      <div className="text-end">
        {!allFinished ? (
          isUploading ? (
            <button className="btn btn-primary" type="button" disabled>
              <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              &nbsp;Processing Your Data...
            </button>
          ) : (
            <Button
              onClick={handleSubmit}
              className="button"
              disabled={!selectedAiModel || candidateFiles.length === 0 || disableChooseFiles}
            >
              <>Upload and Process</>
            </Button>
          )
        ) : (
          <Button
            onClick={() => {
              handleClose();
            }}
          >
            Close
          </Button>
        )}
      </div>
    </>
  );
}
