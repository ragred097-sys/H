import { act } from "react";

import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Mock, vi } from "vitest";

import { DataSource, Module, ModuleType, PermissionType } from "../../../lib/Model";
import { MAX_IMAGE_UPLOAD_SIZE } from "../../../utils/constants";
import { notificationFormatter } from "../../../utils/stringUtils";
import { NotificationProvider } from "../../general/NotificationProvider";
import { ConversationService } from "./../../../services/ConversationService";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";
import UploadDataForm from "./UploadDataForm";

// Helper to create mock files
const createMockFile = (name: string, size: number, type: string): File => {
  const file = new File([new ArrayBuffer(size)], name, { type });
  Object.defineProperty(file, "size", { value: size });
  return file;
};

vi.mock("../../../services/ConversationService", () => ({
  ConversationService: {
    ingestVideoAttachment: vi.fn(),
  },
}));

vi.mock("../../../services/ModuleService", () => ({
  ModuleService: {
    getModuleById: vi.fn(),
    getModulesByType: vi.fn(),
  },
}));

vi.mock("../../../lib/Backend", () => ({
  Backend: {
    getDataSources: vi.fn(),
    getModuleById: vi.fn(),
    getModulesByType: vi.fn(),
    ingestFile: vi.fn(),
    ingestImage: vi.fn(),
    ingestVideoAttachment: vi.fn(),
  },
}));

vi.mock("../../../services/DataSourceService", () => ({
  DataSourceService: {
    getDataSources: vi.fn(),
    ingestFile: vi.fn(),
    ingestImage: vi.fn(),
  },
}));

vi.mock("../../utils/crudUtils", () => ({
  getOrCreateConvoDataSource: vi.fn(),
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    i18n: {
      changeLanguage: vi.fn(() => new Promise(() => {})),
    },
    t: (key: string) => key,
  }),
}));

const mockOpenErrorNotification = vi.fn();

vi.mock("../../general/NotificationProvider", () => {
  return {
    NotificationProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    useNotification: () => ({
      openErrorNotification: mockOpenErrorNotification,
    }),
  };
});
const user = {
  id: "user-1",
  name: "user123",
};
//mock llms
const mockLLMs: Module[] = [
  {
    __type_name: "",
    createdAt: "",
    creator: user,
    default: false,
    favorite: false,
    id: "1",
    name: "Model A",
    parameters: [],
    specId: "s1",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "",
    createdAt: "",
    creator: user,
    default: true,
    favorite: false,
    id: "2",
    name: "Model B",
    parameters: [],
    specId: "s2",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "",
    createdAt: "",
    creator: user,
    default: false,
    favorite: false,
    id: "3",
    name: "Model C",
    parameters: [],
    specId: "s3",
    supportedInputs: [],
    tags: [],
  },
];
const mockDataSource: DataSource = {
  __type_name: "",
  accessPermission: PermissionType.READ,
  createdAt: "",
  creator: user,
  embeddingModelId: null,
  favorite: false,
  fileStorageId: null,
  id: "ds-2",
  ingestedFiles: [],
  name: "image-ds",
  tags: [],
  vectorStoreId: null,
};
describe("UploadDataForm", async () => {
  const mockHandleClose = vi.fn();
  beforeEach(() => {
    vi.clearAllMocks();
    ModuleService.getModulesByType = vi.fn().mockResolvedValue(mockLLMs);
    (DataSourceService.ingestImage as Mock).mockImplementation(async (_, __, ___, onProgress) => {
      onProgress({ currentStep: 1, currentStepName: "Started" });
      onProgress({ currentStep: 5, currentStepName: "Done", dataObjects: [{}] });
      return [
        { currentStep: 1, currentStepName: "Started" },
        { currentStep: 5, currentStepName: "Done", dataObjects: [{}] },
      ];
    });
    (ConversationService.ingestVideoAttachment as Mock).mockImplementation(async (_, __, onProgress) => {
      onProgress({ currentStep: 1, currentStepName: "Started" });
      onProgress({ currentStep: 5, currentStepName: "Done", dataObjects: [{}] });
      return [
        { currentStep: 1, currentStepName: "Started" },
        { currentStep: 5, currentStepName: "Done", dataObjects: [{}] },
      ];
    });
    (ModuleService.getModuleById as Mock).mockImplementation(async (_) => {
      return mockLLMs[0];
    });
    (DataSourceService.getDataSources as Mock).mockResolvedValue([mockDataSource]);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });
  const mockMessages = {
    ERRORMESSAGES_GETMODULES: "errorMessages.getModules",
    ERRORMESSAGES_IMAGEUPLOADSIZEERROR: "errorMessages.imageUploadSizeError",
  };
  it("renders typeahead menu items as option with correct text", async () => {
    render(<UploadDataForm handleClose={mockHandleClose} />);
    await waitFor(() => {
      expect(ModuleService.getModulesByType).toHaveBeenCalledWith(ModuleType.LLM);
    });
    const input = screen.getByTestId("typeahead-test-id");
    await act(async () => {
      fireEvent.focus(input);
    });
    const menuItems = await screen.findAllByRole("option");
    expect(menuItems).toHaveLength(3);
    const texts = menuItems.map((item) => item.textContent?.trim());
    expect(texts).toEqual(["Model A", "Model B - Default", "Model C"]);
  });
  it("Upload and Process button remains disabled if no files are selected", async () => {
    render(<UploadDataForm handleClose={mockHandleClose} selectedAi={mockLLMs[0]} />);
    expect(screen.getByTestId("typeahead-test-id")).toHaveValue(`${mockLLMs[0]?.name}`);
    expect(screen.getByRole("button", { name: /Upload and Process/i })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: /Upload and Process/i }));
    expect(DataSourceService.ingestFile as Mock).not.toHaveBeenCalled();
  });
  it("should show the selectai as selected if selectAi prop is not undefined ", () => {
    render(
      <NotificationProvider>
        <UploadDataForm
          dataSource={undefined}
          model={undefined}
          handleClose={vi.fn()}
          conversation={undefined}
          selectedAi={mockLLMs[0]}
        />
      </NotificationProvider>
    );
    const input = screen.getByTestId("typeahead-test-id");
    expect(input).toHaveValue("Model A");
  });
  it("shows error notification for oversized image files", async () => {
    render(
      <NotificationProvider>
        <UploadDataForm handleClose={mockHandleClose} />
      </NotificationProvider>
    );
    const fileInput = screen.getByTestId("file-upload-input");
    const oversizedImage = createMockFile("large.png", MAX_IMAGE_UPLOAD_SIZE + 1, "image/png");

    fireEvent.change(fileInput, { target: { files: [oversizedImage] } });

    await waitFor(() => {
      expect(mockOpenErrorNotification).toHaveBeenCalledWith(
        notificationFormatter(mockMessages.ERRORMESSAGES_IMAGEUPLOADSIZEERROR, [
          (MAX_IMAGE_UPLOAD_SIZE / 1024 / 1024).toString(),
        ])
      );
    });
    expect(screen.queryByText("large.png")).not.toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Upload and Process/i })).toBeDisabled();
  });
  it("updates candidateFiles and enables upload button on file selection", async () => {
    render(<UploadDataForm handleClose={mockHandleClose} selectedAi={mockLLMs[0]} />);
    await waitFor(() => {
      expect(screen.getByTestId("typeahead-test-id")).toHaveValue(`${mockLLMs[0]?.name}`);
    });
    const fileInput = screen.getByTestId("file-upload-input");
    const mockFile = createMockFile("test.pdf", 1024, "application/pdf");
    fireEvent.change(fileInput, { target: { files: [mockFile] } });
    await waitFor(
      () => {
        expect(screen.getByRole("button", { name: /Upload and Process/i })).toBeEnabled();
      },
      { timeout: 2000 }
    );
  });
  it("should call ingestImage for image files", async () => {
    (DataSourceService.ingestImage as Mock).mockImplementation((_, __, ___, onUpdate) => {
      onUpdate({ currentStep: 1, currentStepName: "Uploading" });
      onUpdate({ currentStep: 5, currentStepName: "Done" });
      return Promise.resolve(["data-obj-2", true]);
    });
    render(<UploadDataForm handleClose={mockHandleClose} dataSource={mockDataSource} selectedAi={mockLLMs[0]} />);
    await waitFor(() => {
      expect(ModuleService.getModulesByType).toHaveBeenCalled();
    });
    const fileInput = screen.getByTestId("file-upload-input");
    const imageFile = createMockFile("image.jpg", 50000, "image/jpeg");
    fireEvent.change(fileInput, { target: { files: [imageFile] } });
    const uploadButton = screen.getByRole("button", { name: "Upload and Process" });
    fireEvent.click(uploadButton);
    await waitFor(() => {
      expect(DataSourceService.ingestImage as Mock).toHaveBeenCalled();
    });
    await waitFor(() => {
      expect(screen.getByRole("button", { name: /Close/i })).toBeInTheDocument();
    });
  });
  it("should call ingestFile for general document files", async () => {
    (DataSourceService.ingestFile as Mock).mockImplementation((_, __, ___, onUpdate) => {
      onUpdate({ currentStep: 1, currentStepName: "Uploading Document" });
      onUpdate({ currentStep: 5, currentStepName: "Document Processed" });
      return Promise.resolve(["data-obj-file", true]);
    });
    render(<UploadDataForm handleClose={mockHandleClose} dataSource={mockDataSource} selectedAi={mockLLMs[0]} />);
    await waitFor(() => {
      expect(ModuleService.getModulesByType).toHaveBeenCalled();
    });
    const fileInput = screen.getByTestId("file-upload-input");
    const docFile = createMockFile("document.pdf", 150000, "application/pdf"); // A PDF file
    fireEvent.change(fileInput, { target: { files: [docFile] } });
    const uploadButton = screen.getByRole("button", { name: "Upload and Process" });
    fireEvent.click(uploadButton);
    await waitFor(() => {
      expect(DataSourceService.ingestFile as Mock).toHaveBeenCalledWith(
        docFile,
        mockDataSource,
        mockLLMs[0],
        expect.any(Function)
      );
    });
    await waitFor(() => {
      expect(screen.getByRole("button", { name: /Close/i })).toBeInTheDocument();
    });
  });
});
