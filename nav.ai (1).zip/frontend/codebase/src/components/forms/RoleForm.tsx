import { useEffect, useState } from "react";

import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

import { Col, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AccessRole } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { AccessControlService } from "./../../services/AccessControlService";

interface RoleFormProps {
  initialData?: AccessRole | null;
  handleClose: () => void;
}

function RoleForm({ handleClose, initialData: initialRole = null }: RoleFormProps) {
  const [roleName, setRoleName] = useState<string>("");
  const [roleDesc, setRoleDesc] = useState<string>("");
  const [showButtonSpinner, setShowButtonSpinner] = useState<boolean>(false);
  const [roleNameError, setRoleNameError] = useState<string>("");
  const { t } = useTranslation();

  // Populate form when initialRole changes
  useEffect(() => {
    if (initialRole) {
      setRoleName(initialRole.name);
      setRoleDesc(initialRole.description || "");
    }
  }, [initialRole]);

  const updateRoleName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRoleNameError("");
    setRoleName(e.target.value);
  };

  const updateRoleDesc = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRoleDesc(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleName.trim()) {
      setRoleNameError(t(TranslationKeys.ROLES_REQUIRED));
      return;
    }
    setRoleNameError("");
    setShowButtonSpinner(true);
    const roleData = {
      description: roleDesc,
      name: roleName,
      system: false,
    } as AccessRole;

    try {
      if (initialRole) {
        // Update existing role
        roleData.id = initialRole.id;
        await AccessControlService.updateAccessRole(roleData);
      } else {
        // Create new role
        await AccessControlService.createAccessRole(roleData);
      }
    } catch (error) {
      console.error("Error saving role:", error);
    } finally {
      console.log("Role saved successfully");
      // Close the modal
      handleClose();
      setShowButtonSpinner(false);
    }
  };

  return (
    <Form onSubmit={handleSubmit} className="p-2">
      <Form.Group className="mb-3" controlId="title">
        <Form.Label>{t(TranslationKeys.ROLES_ROLENAME)}</Form.Label>
        <Form.Control
          type="text"
          placeholder={t(TranslationKeys.ROLES_ROLENAMEPLACEHOLDER)}
          value={roleName}
          onChange={updateRoleName}
          isInvalid={!!roleNameError}
        />
        <Form.Control.Feedback type="invalid">{roleNameError}</Form.Control.Feedback>
      </Form.Group>

      <Form.Group className="mb-3" controlId="workspaceDescription">
        <Form.Label>{t(TranslationKeys.ROLES_ROLEDESCRIPTION)}</Form.Label>
        <Form.Control
          type="text"
          placeholder={t(TranslationKeys.ROLES_ROLEDESCRIPTIONPLACEHOLDER)}
          value={roleDesc}
          onChange={updateRoleDesc}
        />
      </Form.Group>
      <div className="d-dlex flex-col">
        <Row>
          <Col>
            <div className="text-end">
              {showButtonSpinner ? (
                <Button className="btn btn-primary" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.ROLES_LOADING)}
                </Button>
              ) : (
                <Button variant="primary" type="submit">
                  {initialRole ? t(TranslationKeys.ROLES_UPDATE) : t(TranslationKeys.ROLES_CREATE)}
                </Button>
              )}
            </div>
          </Col>
        </Row>
      </div>
    </Form>
  );
}

export default RoleForm;
