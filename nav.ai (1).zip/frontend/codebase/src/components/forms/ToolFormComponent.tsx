import { BaseSyntheticEvent, useEffect, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import Docxtemplater from "docxtemplater";
import InspectModule from "docxtemplater/js/inspect-module.js";
import PizZip from "pizzip";
import { z } from "zod";

import { Button, Form, Modal } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { Module, ModuleType, SystemInstruction } from "../../lib/Model";
import { ModuleService } from "../../services/ModuleService";
import { TranslationKeys } from "../../types/translation-keys";
import { TEMPLATE_SYSTEM_PROMPT, toolPrefix } from "../../utils/constants";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import ModuleDropdown from "../general/ModuleDropdown/ModuleDropdown";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import TooltipTable from "../general/SettingsTooltipTable";
import { SystemInstructionService } from "./../../services/SystemInstructionService";

interface ToolFormComponentProps {
  onToolCreated: (tool?: SystemInstruction | undefined) => void;
  initialData?: SystemInstruction;
  updateTrigger?: () => void;
  toolForm?: string | undefined;
}

export const ToolFormComponent = ({ initialData, onToolCreated, toolForm, updateTrigger }: ToolFormComponentProps) => {
  const [loadingBtn, setLoadingBtn] = useState(false);
  const [template, setTemplate] = useState<File>();
  const { openErrorNotification, openNotification } = useNotification();
  const [deleteLoading, setDeleteLoading] = useState(false);
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);

  const [fileStorages, setFileStorages] = useState<Module[]>([]);

  const [showInfoTooltip, setShowInfoTooltip] = useState(false);

  const baseSchema = z.object({
    description: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
    fileStorageId: z.string().optional(),
    message: z.string().nonempty(t(TranslationKeys.MESSAGES_INSTRUCTIONREQUIRED)),
    promptName: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
  });

  const schema =
    toolForm !== toolPrefix && !initialData
      ? baseSchema.extend({
          fileStorageId: z.string().nonempty(t(TranslationKeys.TOOLFORM_FILESTOREREQUIRED)),
        })
      : baseSchema;

  type ToolFormSchema = z.infer<typeof schema>;

  const {
    formState: { errors, isSubmitting },
    handleSubmit,
    register,
    setValue,
    watch,
  } = useForm({
    defaultValues: {
      description: initialData?.description || "",
      fileStorageId: "",
      message: initialData?.message || "",
      promptName: initialData ? initialData.name.replace(toolForm || "", "") : "",
    },
    mode: "onChange",
    resolver: zodResolver(schema),
  });

  // Watch all form values to check if they're filled
  const watchedFields = watch();
  const areAllFieldsFilled = Boolean(watchedFields.promptName && watchedFields.description && watchedFields.message);

  useEffect(() => {
    if (toolForm !== toolPrefix && !initialData) {
      ModuleService.getModulesByType(ModuleType.FILE_STORAGE)
        .then((fileStorageModules) => {
          setFileStorages(fileStorageModules);
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  const handleCreate: SubmitHandler<ToolFormSchema> = async (data, e?: BaseSyntheticEvent) => {
    e?.preventDefault();

    setLoadingBtn(true);
    let createdInstruction: SystemInstruction | null = null;
    try {
      // Create the new tool (system instruction)
      const payload = {
        description: data.description,
        message: data.message,
        name: toolForm + data.promptName,
      };

      if (initialData) {
        // Update existing tool
        const updatedInstruction = await SystemInstructionService.updateSystemInstruction({
          ...initialData,
          ...payload,
        });
        onToolCreated(updatedInstruction);
      } else {
        // Create new tool
        createdInstruction = await SystemInstructionService.createSystemInstruction(payload as SystemInstruction);
        let updatedMessage = data.message;

        // If a template file is provided, attach it and update the message
        if (template && createdInstruction) {
          const attachmentResponse = await SystemInstructionService.postSystemInstructionAttachment(
            createdInstruction.id,
            template,
            data.fileStorageId || ""
          );
          const fileId = attachmentResponse.id;
          updatedMessage += `\nFileId: ${fileId}\nSystemInstructionId: ${createdInstruction.id}`;

          // Retrieve and update the system instruction with the new message
          const systemInstruction = await SystemInstructionService.getSystemInstruction(createdInstruction.id);
          systemInstruction.message = updatedMessage;
          await SystemInstructionService.updateSystemInstruction(systemInstruction);
        }

        if (createdInstruction) {
          onToolCreated(createdInstruction);
        }
      }
    } catch (err) {
      // clean up malformed tool if template is provided
      if (createdInstruction && template) {
        try {
          await SystemInstructionService.deleteSystemInstruction(createdInstruction);
        } catch (error) {
          console.log(error);
        }
      }
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATETOOL), err as Error);
    } finally {
      if (updateTrigger) updateTrigger();
      setLoadingBtn(false);
    }
  };

  const handleDelete = async () => {
    if (initialData?.id) {
      try {
        setDeleteLoading(true);
        await SystemInstructionService.deleteSystemInstruction(initialData);
        openNotification(t(TranslationKeys.MESSAGES_DELETENAVAITOOL, "Nav.AI Tool deleted successfully."), "primary");
        if (updateTrigger) updateTrigger();
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETENAVAITOOLERROR), error as Error);
      } finally {
        setDeleteLoading(false);
        onToolCreated();
      }
    }
  };

  const populateFromTemplate = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".docx,.pptx";
    input.onchange = async (event) => {
      const file = (event.target as HTMLInputElement).files?.[0];
      if (file) {
        try {
          const arrayBuffer = await file.arrayBuffer();
          const iModule = new InspectModule();
          const doc = new Docxtemplater(new PizZip(arrayBuffer), {
            modules: [iModule],
          });
          doc.render();
          const tags = iModule.getAllTags();
          setValue("message", TEMPLATE_SYSTEM_PROMPT + Object.keys(tags).join(", "), { shouldValidate: true });
          setTemplate(file);
        } catch (err) {
          openErrorNotification(err as string);
        }
      }
    };
    input.click();
  };

  return (
    <>
      {loading && "Loading"}
      {!loading && (
        <Form id="createToolForm" onSubmit={handleSubmit(handleCreate)}>
          <Form.Group className="mb-3">
            <Form.Label>{t(TranslationKeys.TOOLFORM_TOOLNAME)}</Form.Label>
            <div className="d-flex align-items-center gap-2">
              <Form.Label className="m-0 text-nowrap">{toolForm}</Form.Label>
              <Form.Control
                id="promptName"
                as="input"
                className="flex-grow-1"
                isInvalid={!!errors.promptName}
                value={watch("promptName").replace(toolForm || "", "")}
                {...register("promptName")}
              />
            </div>
            {errors.promptName && (
              <Form.Control.Feedback type="invalid">{errors.promptName?.message?.toString()}</Form.Control.Feedback>
            )}
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>{t(TranslationKeys.TOOLFORM_TOOLDESCRIPTION)}</Form.Label>
            <Form.Control
              id="description"
              as="textarea"
              rows={2}
              isInvalid={!!errors.description}
              {...register("description")}
            />
            {errors.description && (
              <Form.Control.Feedback type="invalid">{errors.description?.message?.toString()}</Form.Control.Feedback>
            )}
          </Form.Group>

          {toolForm !== toolPrefix ? (
            <>
              {initialData ? (
                <div className="mb-4">{t(TranslationKeys.TOOLFORM_UPDATETEMPLATENOTE)}</div>
              ) : (
                <>
                  <Form.Group className="mb-3">
                    <RequiredLabel label={t(TranslationKeys.TOOLFORM_FILESTORE)} />
                    {!fileStorages?.every((mod) => !mod.capabilities || mod.capabilities.length === 0) && (
                      <i
                        className="bi bi-info-circle text-light"
                        style={{ paddingLeft: "0.2rem" }}
                        onClick={() => {
                          setShowInfoTooltip(true);
                        }}
                      ></i>
                    )}
                    <ModuleDropdown
                      name="fileStorageId"
                      options={fileStorages}
                      registerProps={register("fileStorageId")}
                      setValue={setValue}
                    />
                    {errors.fileStorageId && (
                      <Form.Control.Feedback type="invalid">
                        {errors.fileStorageId?.message?.toString()}
                      </Form.Control.Feedback>
                    )}
                  </Form.Group>

                  <Form.Group className="mb-3">
                    <Form.Label>{t(TranslationKeys.TOOLFORM_UPLOADTEMPLATE)}</Form.Label>
                    <Button onClick={populateFromTemplate} variant="transparent" className="me-2">
                      <i className="bi bi-cloud-upload" style={{ cursor: "pointer", marginLeft: "0.5rem" }}></i>
                    </Button>
                  </Form.Group>
                </>
              )}
            </>
          ) : null}
          <Form.Group className="mb-4">
            <Form.Label>{t(TranslationKeys.TOOLFORM_TOOLINSTRUCTIONS)}</Form.Label>
            <Form.Control
              id="message"
              className="pt-2"
              as="textarea"
              rows={5}
              disabled={initialData ? initialData.message?.includes("AUTO SYSTEM PROMPT") : !!template}
              isInvalid={!!errors.message}
              {...register("message")}
            />
            {errors.message && (
              <Form.Control.Feedback type="invalid">{errors.message?.message?.toString()}</Form.Control.Feedback>
            )}
          </Form.Group>

          <div className="text-end">
            {loadingBtn ? (
              <button className="btn btn-primary" type="button" disabled>
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                &nbsp;{t(TranslationKeys.TOOLFORM_LOADING)}
              </button>
            ) : (
              <div className="d-flex justify-content-between">
                <div>
                  {initialData ? (
                    <>
                      {deleteLoading ? (
                        <LoadingButton className={"btn btn-danger me-4"} />
                      ) : (
                        <Button variant="danger" type="button" onClick={handleDelete} className="me-2">
                          {t(TranslationKeys.TOOLFORM_DELETE)} {initialData.name}
                        </Button>
                      )}
                    </>
                  ) : null}
                </div>
                <div>
                  <Button
                    form="createToolForm"
                    type="submit"
                    className="button"
                    disabled={!areAllFieldsFilled || isSubmitting}
                  >
                    {initialData ? t(TranslationKeys.TOOLFORM_UPDATETOOL) : t(TranslationKeys.TOOLFORM_CREATETOOL)}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Form>
      )}
      {/* Info tooltip for File Storage model selection */}
      <Modal
        show={showInfoTooltip}
        onHide={() => setShowInfoTooltip(false)}
        backdrop="static"
        size="lg"
        centered
        className="text-light custom-modal-backdrop capabilities-modal"
      >
        <Modal.Header style={{ fontWeight: "bold" }} closeButton>
          {t(TranslationKeys.AGENTFORM_AIMODELS)}
        </Modal.Header>
        <Modal.Body>
          <TooltipTable tooltipData={fileStorages} />
        </Modal.Body>
      </Modal>
    </>
  );
};
