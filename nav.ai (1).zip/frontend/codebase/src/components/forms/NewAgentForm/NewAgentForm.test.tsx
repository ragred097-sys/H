import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Mock, afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { MemoryRouter } from "react-router-dom";

import { NotificationProvider } from "../../../components/general/NotificationProvider";
import { Agent, Assistant, Module, PermissionType } from "../../../lib/Model";
import { assetFormStore } from "../../../stores/useStore";
import { AgentService } from "./../../../services/AgentService";
import { AssistantService } from "./../../../services/AssistantService";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";
import { SystemInstructionService } from "./../../../services/SystemInstructionService";
import NewAgentForm from "./NewAgentForm";

vi.mock("../../../services/TagService", () => ({
  TagService: {
    createTags: vi.fn().mockResolvedValue([]),
    getTags: vi.fn().mockResolvedValue([]),
  },
}));

vi.mock("../../../services/SystemInstructionService", () => ({
  SystemInstructionService: {
    getSystemInstructions: vi.fn(),
  },
}));

vi.mock("../../../services/DataSourceService", () => ({
  DataSourceService: {
    getDataSources: vi.fn(),
  },
}));

vi.mock("../../../services/ModuleService", () => ({
  ModuleService: {
    getModulesByType: vi.fn(),
  },
}));

vi.mock("../../../services/AssistantService", () => ({
  AssistantService: {
    updateAssistant: vi.fn(),
  },
}));

vi.mock("../../../services/AgentService", () => ({
  AgentService: {
    updateAgent: vi.fn(),
  },
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

vi.mock("../../../lib/Backend", () => ({
  Backend: {
    getDataSources: vi.fn(),
    getModulesByType: vi.fn(),
    getSystemInstructions: vi.fn(),
    updateAgent: vi.fn(),
    updateAssistant: vi.fn(),
  },
}));

vi.mock("@/helpers/tagHelper", async () => {
  const actual = await vi.importActual<typeof import("../../../utils/tagsHelper")>("../../../utils/tagsHelper");
  return {
    ...actual,
    processTags: vi.fn(),
  };
});

const mockAssistant: Assistant = {
  __type_name: "Assistant",
  accessPermission: PermissionType.WRITE,
  attachmentStorages: [],
  createdAt: new Date().toISOString(),
  creator: { id: "system", name: "SYSTEM" },
  customSystemInstruction: "",
  dataSourceIds: [],
  description: "Test description",
  favorite: false,
  greetingMessage: "Hello!",
  icon: "",
  id: "assistant-1",
  image: "",
  llmIds: ["model-1"],
  name: "Test Assistant",
  sampleQuestions: [],
  systemInstructionIds: [],
  tags: [{ id: "tag1", name: "tag1" }],
};

const mockAgent: Agent = {
  __type_name: "Agent",
  accessPermission: PermissionType.WRITE,
  createdAt: new Date().toISOString(),
  creator: { id: "system", name: "SYSTEM" },
  customSystemInstruction: "",
  description: "Agent description",
  favorite: false,
  functionToolIds: [],
  icon: "",
  id: "agent-1",
  image: "",
  llmId: "model-2",
  name: "Test Agent",
  systemInstructionIds: [],
  tags: [],
};

const mockModels: Module[] = [
  {
    __type_name: "Module",
    capabilities: [
      {
        createdAt: new Date().toISOString(),
        creator: { id: "system", name: "SYSTEM" },
        default: false,
        description: "Summarization and translation capability",
        name: "SUMMARIZATION_TRANSLATION",
      },
      {
        createdAt: new Date().toISOString(),
        creator: { id: "system", name: "SYSTEM" },
        default: true,
        description: "Research and development capability",
        name: "RESEARCH_DEVELOPMENT",
      },
    ],
    createdAt: new Date().toISOString(),
    creator: { id: "system", name: "SYSTEM" },
    default: true,
    description: "Mock model one",
    favorite: false,
    id: "model-1",
    name: "Model One",
    parameters: [],
    specId: "spec-1",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    capabilities: [
      {
        createdAt: new Date().toISOString(),
        creator: { id: "system", name: "SYSTEM" },
        default: false,
        description: "Summarization and translation capability",
        name: "SUMMARIZATION_TRANSLATION",
      },
      {
        createdAt: new Date().toISOString(),
        creator: { id: "system", name: "SYSTEM" },
        default: true,
        description: "Research and development capability",
        name: "RESEARCH_DEVELOPMENT",
      },
    ],
    createdAt: new Date().toISOString(),
    creator: { id: "system", name: "SYSTEM" },
    default: false,
    description: "Mock model two",
    favorite: false,
    id: "model-2",
    name: "Model Two",
    parameters: [],
    specId: "spec-2",
    supportedInputs: [],
    tags: [],
  },
];

const mockMessages = {
  AGENTFORM_SELECTAIMODULE: "agentForm.selectAiModule",
};

describe("NewAgentForm - extended", () => {
  beforeEach(() => {
    assetFormStore.getState().reset();
    vi.clearAllMocks();
    (ModuleService.getModulesByType as Mock).mockResolvedValue(mockModels);
    (DataSourceService.getDataSources as any).mockResolvedValue([]);
    (SystemInstructionService.getSystemInstructions as any).mockResolvedValue([]);
    (AssistantService.updateAssistant as any).mockResolvedValue(mockAssistant);
    (AgentService.updateAgent as any).mockResolvedValue(mockAgent);
    // (TagsHelper.processTags as any).mockImplementation(() => Promise.resolve([]));
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it("set default model on create new agent if available", async () => {
    (ModuleService.getModulesByType as Mock).mockResolvedValue(mockModels);
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm />
        </NotificationProvider>
      </MemoryRouter>
    );
    const input = await screen.findByTestId("aimodel-test-id");
    expect(input).toHaveValue("model-1");
    expect(input).toHaveDisplayValue("Model One - Default");
  });

  it("show 'Select an ai model' if default is not present", async () => {
    (ModuleService.getModulesByType as Mock).mockResolvedValue(mockModels[1]);
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm />
        </NotificationProvider>
      </MemoryRouter>
    );
    const input = await screen.findByTestId("aimodel-test-id");
    expect(input).toHaveValue("");
    expect(input).toHaveDisplayValue(mockMessages?.AGENTFORM_SELECTAIMODULE);
  });

  it("show selected model on edit agent", async () => {
    (ModuleService.getModulesByType as Mock).mockResolvedValue(mockModels);
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const input = await screen.findByTestId("aimodel-test-id");
    expect(input).toHaveValue("model-1");
    expect(input).toHaveDisplayValue("Model One - Default");
  });

  it("calls handleClose after update", async () => {
    const handleClose = vi.fn();
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} handleClose={handleClose} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const submitBtn = screen.getByRole("button", { name: /update/i });
    fireEvent.click(submitBtn);
    await waitFor(() => {
      expect(handleClose).toHaveBeenCalled();
    });
  });

  it("shows info tooltip modal when triggered", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    // Simulate showing info tooltip modal
    // The modal is controlled by showInfoTooltip state, which is not exposed, so this is a placeholder
    // You can simulate by triggering the state via a button if present
  });

  it("renders tags dropdown if tags are available", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    await waitFor(() => {
      // Check for dropdown presence
      // This depends on the actual implementation of DropdownSelect
      // Placeholder: expect(screen.getByText(/Tag1/i)).toBeInTheDocument();
    });
  });

  it("calls updateAgent for utility agent", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAgent} isUtilityAgent={true} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const submitBtn = screen.getByRole("button", { name: /update/i });
    fireEvent.click(submitBtn);
    await waitFor(() => {
      expect(AgentService.updateAgent).toHaveBeenCalled();
    });
  });

  it("calls updateAssistant for assistant", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const submitBtn = screen.getByRole("button", { name: /update/i });
    fireEvent.click(submitBtn);
    await waitFor(() => {
      expect(AssistantService.updateAssistant).toHaveBeenCalled();
    });
  });

  it("shows error notification if processTags throws", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const submitBtn = screen.getByRole("button", { name: /update/i });
    fireEvent.click(submitBtn);
    await waitFor(() => {
      // The error notification is shown via NotificationProvider, which may render a message
      // Placeholder: expect(screen.getByText(/Tag error/i)).toBeInTheDocument();
    });
  });

  it("calls onUpdateAgentFormDirty and onUpdateAgentDirtyData when editing", async () => {
    const onUpdateAgentFormDirty = vi.fn();
    const onUpdateAgentDirtyData = vi.fn();
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm
            initialData={mockAssistant}
            onUpdateAgentFormDirty={onUpdateAgentFormDirty}
            onUpdateAgentDirtyData={onUpdateAgentDirtyData}
          />
        </NotificationProvider>
      </MemoryRouter>
    );
    await waitFor(() => {
      expect(onUpdateAgentFormDirty).toHaveBeenCalled();
      expect(onUpdateAgentDirtyData).toHaveBeenCalled();
    });
  });

  it("calls onCreateAgentFormDirty and onCreateAgentDirtyData when creating", async () => {
    const onCreateAgentFormDirty = vi.fn();
    const onCreateAgentDirtyData = vi.fn();
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm
            onCreateAgentFormDirty={onCreateAgentFormDirty}
            onCreateAgentDirtyData={onCreateAgentDirtyData}
          />
        </NotificationProvider>
      </MemoryRouter>
    );
    await waitFor(() => {
      expect(onCreateAgentFormDirty).toHaveBeenCalled();
      expect(onCreateAgentDirtyData).toHaveBeenCalled();
    });
  });

  it("shows delete confirmation modal for utility agent", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAgent} isUtilityAgent={true} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const deleteBtn = screen.getByRole("button", { name: /delete/i });
    fireEvent.click(deleteBtn);
  });

  it("updates form fields and triggers validation", async () => {
    render(
      <MemoryRouter>
        <NotificationProvider>
          <NewAgentForm initialData={mockAssistant} />
        </NotificationProvider>
      </MemoryRouter>
    );
    const nameInput = screen.getByDisplayValue("Test Assistant");
    fireEvent.change(nameInput, { target: { value: "Changed Name" } });
    expect(nameInput).toHaveValue("Changed Name");
    fireEvent.change(nameInput, { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: /update/i }));
    await waitFor(() => {
      expect(screen.getByText(/required/i)).toBeInTheDocument();
    });
  });
});
