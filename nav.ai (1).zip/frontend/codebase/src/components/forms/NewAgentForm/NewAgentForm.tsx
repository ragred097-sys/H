import { forwardRef, useCallback, useEffect, useImperativeHandle, useRef, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import UuidGenerator from "uuid-wand";
import { z } from "zod";

import { Button, Col, Collapse, Form, Modal, Row } from "react-bootstrap";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import {
  Agent,
  AssetForm,
  Assistant,
  AttachmentStorages,
  DataSource,
  Module,
  ModuleType,
  SystemInstruction,
  Tag,
} from "../../../lib/Model";
import { GovernanceService } from "../../../services/GovernanceService";
import { assetFormStore, authStore } from "../../../stores/useStore";
import { TranslationKeys } from "../../../types/translation-keys";
import { AgentDirtyDataHelper, AgentDirtyFields, UtilityAgentDirtyDataHelper } from "../../../utils/agentFormFields";
import { MAX_ICON_SIZE, MAX_IMAGE_SIZE, templatePrefix } from "../../../utils/constants";
import { isEqtyEnabled } from "../../../utils/eqty";
import { getPreferenceNameValuePairs, mapStorageDefaults } from "../../../utils/objectUtils";
import { processTags, useFilterTags } from "../../../utils/tagsHelper";
import DeleteAgent from "../../general/DeleteAgent";
import DeleteAssistant from "../../general/DeleteAssistant";
import DropdownSelect, { TagOrCustom } from "../../general/Dropdown";
import ModuleDropdown from "../../general/ModuleDropdown/ModuleDropdown";
import { useNotification } from "../../general/NotificationProvider";
import { RequiredLabel } from "../../general/RequiredLabel";
import TooltipTable from "../../general/SettingsTooltipTable";
import AgentReviewForm from "../AgentReviewForm";
import CustomAssetForm from "../CustomAssetForm";
import ImageUpload from "../ImageUpload";
import { updateAssetFormData } from "../updateAssetForm";
import { AgentService } from "./../../../services/AgentService";
import { ApplicationService } from "./../../../services/ApplicationService";
import { AssistantService } from "./../../../services/AssistantService";
import { DataSourceService } from "./../../../services/DataSourceService";
import { ModuleService } from "./../../../services/ModuleService";
import { SystemInstructionService } from "./../../../services/SystemInstructionService";
import { UserService } from "./../../../services/UserService";

interface UpdateForm {
  assetName: string;
  assetDescription: string;
  greeting: string;
  systemPrompts: string[];
  dataSources: string[];
  suggestions: string[];
  attachmentStorages: AttachmentStorages[];
  tools: string[];
  icon: string;
  image: string;
}

interface UpdateFormUtilityAgent {
  assetName: string;
  assetDescription: string;
  systemPrompts: string[];
  icon: string;
  image: string;
  functionToolIds: string[];
}
type FormValues = {
  assetName: string;
  assetDescription: string;
  modelDetails: string;
};
export type FormRef = {
  validateAndGetData: () => Promise<FormValues | null>;
};
export interface NewAgentFormProps {
  initialData?: Assistant | Agent;
  handleClose?: () => void;
  updateTrigger?: (subject?: Assistant | DataSource | Agent) => void;
  showDelete?: boolean;
  onUpdateAgentFormDirty?: (isDirty: boolean) => void;
  onCreateAgentFormDirty?: (value: boolean) => void;
  onCreateAgentDirtyData?: (data: AgentDirtyFields) => void;
  onUpdateAgentDirtyData?: (data: AgentDirtyFields) => void;
  isUtilityAgent?: boolean;
}
function NewAgentFormComponent(
  {
    handleClose,
    initialData,
    isUtilityAgent = false,
    onCreateAgentDirtyData,
    onCreateAgentFormDirty,
    onUpdateAgentDirtyData,
    onUpdateAgentFormDirty,
    showDelete = true,
    updateTrigger,
  }: NewAgentFormProps,
  ref: React.ForwardedRef<FormRef>
) {
  const userId = authStore((state) => state.user?.id);
  const [defaultAttachmentMappings, setDefaultAttachmentMappings] = useState<AttachmentStorages[]>([]);
  const [aiModels, setAiModels] = useState<Module[] | null>();
  const [customize, setCustomize] = useState(false);
  const assetForm = assetFormStore((state) => state);
  const [isInitialized, setIsInitialized] = useState(false);
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<TagOrCustom[]>((initialData?.tags as Tag[]) || []);
  const [allPrompts, setAllPrompts] = useState<SystemInstruction[]>([]);
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const [systemInstructions, setSystemInstructions] = useState<SystemInstruction[]>([]);
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [templates, setTemplates] = useState<SystemInstruction[]>([]);
  const [showInfoTooltip, setShowInfoTooltip] = useState(false);
  const [utilityAgentDeleteConfirmation, setUtilityAgentDeleteConfirmation] = useState(false);
  const toolPrefix = window.ENV?.VITE_APP_TOOLS_PREFIX || import.meta.env.VITE_APP_TOOLS_PREFIX || "Nav.AI Tool - ";
  const [formData, setFormData] = useState<UpdateForm | UpdateFormUtilityAgent>(() => {
    if (isUtilityAgent) {
      const agent = initialData as Agent;
      return {
        assetDescription: initialData?.description || "",
        assetName: initialData?.name || "",
        functionToolIds: agent?.functionToolIds || [],
        icon: initialData?.icon || "",
        image: initialData?.image || "",
        systemPrompts: initialData?.systemInstructionIds || [],
      };
    } else {
      const assistant = initialData as Assistant;
      return {
        assetDescription: initialData?.description || "",
        assetName: initialData?.name || "",
        attachmentStorages: assistant?.attachmentStorages || defaultAttachmentMappings,
        dataSources: assistant?.dataSourceIds || [],
        greeting: assistant?.greetingMessage || "",
        icon: initialData?.icon || "",
        image: initialData?.image || "",
        suggestions: assistant?.sampleQuestions || [],
        systemPrompts: initialData?.systemInstructionIds || [],
        tools: [],
      };
    }
  });
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    if (isUtilityAgent) {
      const agent = initialData as Agent;
      return agent?.llmId || "";
    } else {
      const assistant = initialData as Assistant;
      return assistant?.llmIds?.[0] || "";
    }
  });

  const [loadingBtn, setLoadingBtn] = useState({
    delete: false,
    tags: false,
    update: false,
  });
  const [defaultModelId, setDefaultModelId] = useState<string>();
  const [allCapabilitiesEmpty, setAllCapabilitiesEmpty] = useState(false);
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  // Zod Validation Schema for new Agent
  const formSchema = z.object(
    isUtilityAgent
      ? {
          assetDescription: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
          assetName: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
          icon: z.string().optional(),
          image: z.string().optional(),
          modelDetails: z.string().nonempty(t(TranslationKeys.MESSAGES_AIMODEL)),
          systemPrompts: z.array(z.string()).optional(),
        }
      : {
          assetDescription: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
          assetName: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
          attachmentStorages: z.array(z.any()).optional(),
          dataSources: z.array(z.string()).optional(),
          greeting: z.string().optional(),
          icon: z.string().optional(),
          image: z.string().optional(),
          modelDetails: z.string().nonempty(t(TranslationKeys.MESSAGES_AIMODEL)),
          suggestions: z.array(z.string()).optional(),
          systemPrompts: z.array(z.string()).optional(),
          tools: z.array(z.string()).optional(),
        }
  );

  const {
    formState: { errors, isDirty },
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    trigger,
  } = useForm({
    defaultValues: isUtilityAgent
      ? {
          assetDescription: initialData?.description || "",
          assetName: initialData?.name || "",
          icon: initialData?.icon || "",
          image: initialData?.image || "",
          modelDetails: (initialData as Agent)?.llmId || defaultModelId || "",
          systemPrompts: (initialData as Agent)?.systemInstructionIds || [],
        }
      : {
          assetDescription: initialData?.description || "",
          assetName: initialData?.name || "",
          attachmentStorages: (initialData as Assistant)?.attachmentStorages || [],
          dataSources: (initialData as Assistant)?.dataSourceIds || [],
          greeting: (initialData as Assistant)?.greetingMessage || "",
          icon: initialData?.icon || "",
          image: initialData?.image || "",
          modelDetails: (initialData as Assistant)?.llmIds?.[0] || defaultModelId || "",
          suggestions: (initialData as Assistant)?.sampleQuestions || [],
          systemPrompts: initialData?.systemInstructionIds || [],
          tools: [],
        },
    resolver: zodResolver(formSchema),
  });

  useImperativeHandle(
    ref,
    () => ({
      async validateAndGetData(): Promise<FormValues | null> {
        const isValid = await trigger();
        return isValid ? (getValues() as FormValues) : null;
      },
    }),
    [trigger, getValues]
  );

  //to set the initial value for form validation if defaultmodelid or initialdata is not set
  useEffect(() => {
    if ((initialData || defaultModelId) && !getValues("modelDetails")) {
      reset({
        ...getValues(),
        modelDetails: isUtilityAgent
          ? (initialData as Agent)?.llmId || defaultModelId
          : (initialData as Assistant)?.llmIds?.[0] || defaultModelId,
      });
    }
  }, [initialData, defaultModelId, reset]);

  useEffect(() => {
    if (isEqtyEnabled() && initialData?.id) {
      GovernanceService.getAgenticGovernanceConfiguration(initialData as Agent)
        .then((res) => {
          assetFormStore.getState().setField("governanceConfiguration", res);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCECONFIGURATION), err as Error);
          console.error("Error fetching governance configuration in new agent form:", err);
        });
    }
  }, [initialData]);

  // Cleanup assetFormStore on unmount
  useEffect(() => {
    return () => {
      // Reset all fields in assetFormStore to initial state
      assetFormStore.getState().reset();
    };
  }, []);
  //set initial data for edit case
  useEffect(() => {
    if (initialData) {
      setSelectedTags(initialData?.tags as Tag[]);
    }
  }, [initialData]);

  const lastUpdateDirtyState = useRef<boolean | null>(null);
  const lastUpdateDirtyData = useRef<AgentDirtyFields | null>(null);
  const lastCreateDirtyState = useRef<boolean | null>(null);
  const lastCreateDirtyData = useRef<AgentDirtyFields | null>(null);

  // Update dirty state and data for agent form
  useEffect(() => {
    if (!initialData) return; // Only for update mode

    let dirty = false;
    let dirtyData: AgentDirtyFields;

    if (!isUtilityAgent) {
      dirty =
        isDirty ||
        Object.values(AgentDirtyDataHelper(assetForm, initialData as Assistant, allPrompts)).includes(true) ||
        JSON.stringify(initialData?.tags?.map((item) => item.name).sort()) !==
          JSON.stringify(selectedTags?.map((item) => item.name).sort());

      dirtyData = AgentDirtyDataHelper(assetForm, initialData as Assistant, allPrompts);
    } else {
      dirty =
        isDirty ||
        Object.values(UtilityAgentDirtyDataHelper(assetForm, initialData as Agent)).includes(true) ||
        JSON.stringify(assetForm.tags?.map((tag) => tag.id).sort()) !==
          JSON.stringify(initialData?.tags?.map((tag) => tag.id).sort());

      dirtyData = UtilityAgentDirtyDataHelper(assetForm, initialData as Agent);
    }

    // Only call if dirty state changed
    if (lastUpdateDirtyState.current !== dirty) {
      onUpdateAgentFormDirty?.(dirty);
      lastUpdateDirtyState.current = dirty;
    }

    // Only call if dirty data changed
    if (JSON.stringify(lastUpdateDirtyData.current) !== JSON.stringify(dirtyData)) {
      onUpdateAgentDirtyData?.(dirtyData);
      lastUpdateDirtyData.current = dirtyData;
    }
  }, [
    allPrompts,
    assetForm,
    initialData,
    isDirty,
    isUtilityAgent,
    onUpdateAgentDirtyData,
    onUpdateAgentFormDirty,
    selectedTags,
  ]);

  //dirty state for new agent
  useEffect(() => {
    if (initialData) return; // Only run in create mode (skip if editing)

    let dirty = false;
    let dirtyData: AgentDirtyFields;

    if (!isUtilityAgent) {
      dirty = isDirty || Object.values(AgentDirtyDataHelper(assetForm)).includes(true) || selectedTags.length > 0;

      dirtyData = AgentDirtyDataHelper(assetForm);
    } else {
      dirty =
        isDirty || Object.values(UtilityAgentDirtyDataHelper(assetForm)).includes(true) || selectedTags.length > 0;

      dirtyData = UtilityAgentDirtyDataHelper(assetForm);
    }

    // Only call if dirty state changed
    if (lastCreateDirtyState.current !== dirty) {
      onCreateAgentFormDirty?.(dirty);
      lastCreateDirtyState.current = dirty;
    }

    // Only call if dirty data changed
    if (JSON.stringify(lastCreateDirtyData.current) !== JSON.stringify(dirtyData)) {
      onCreateAgentDirtyData?.(dirtyData);
      lastCreateDirtyData.current = dirtyData;
    }
  }, [
    assetForm,
    initialData,
    isDirty,
    isUtilityAgent,
    onCreateAgentDirtyData,
    onCreateAgentFormDirty,
    selectedTags.length,
  ]);

  useEffect(() => {
    ModuleService.getModulesByType(ModuleType.LLM)
      .then((res) => {
        setAiModels(res);
        if (!selectedModel) {
          const defaultModel = res?.find((model) => model.default);
          if (defaultModel) {
            setSelectedModel(defaultModel?.id);
            setDefaultModelId(defaultModel?.id);
          }
        }
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULES), err as Error);
        console.error(err);
      });
  }, [openErrorNotification]);
  //customhook for tags
  const { filteredTags, loadTags } = useFilterTags();
  const getTags = useCallback(() => {
    setTags(filteredTags);
  }, [filteredTags]);
  useEffect(() => {
    getTags();
  }, [getTags, loadTags]);

  const assistantAiModelRender = useCallback(() => {
    if (initialData) {
      assetFormStore.getState().setField("assetName", initialData.name);
      assetFormStore.getState().setField("assetDescription", initialData.description);
      assetFormStore.getState().setField("greeting", (initialData as Assistant).greetingMessage);

      DataSourceService.getDataSources()
        .then((res) => {
          const filteredDatasources = res.filter((ds) => !UuidGenerator.validate(ds.name));
          if (initialData) {
            const matchingDataSources = filteredDatasources.filter((item) =>
              (initialData as Assistant).dataSourceIds.includes(item.id)
            );
            setDataSources(matchingDataSources);
            assetFormStore.getState().setField("dataSources", matchingDataSources);
          }
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DATASOURCES), err as Error);
        });

      assetFormStore.getState().setField("suggestions", (initialData as Assistant).sampleQuestions);
      assetFormStore.getState().setField("attachmentStorages", (initialData as Assistant).attachmentStorages);
      SystemInstructionService.getSystemInstructions()
        .then((res) => {
          // saving all system instructions to a state which is passed to validator to check for changes in prompts and tools
          setAllPrompts(res);
          //filter system instructions that does not include tools and templates
          const filteredInstructions = res.filter(
            (el) => !el.name.includes(toolPrefix) && !el.name.includes(templatePrefix)
          );
          //filter tools that includes tools or templates
          const filteredTools = res.filter((el) => el.name.includes(toolPrefix) || el.name.includes(templatePrefix));
          if (initialData) {
            const matchingInstructions = filteredInstructions.filter((item) =>
              initialData.systemInstructionIds?.includes(item.id)
            );
            setSystemInstructions(matchingInstructions);
            assetFormStore.getState().setField("systemPrompts", matchingInstructions);

            const matchingTools = filteredTools.filter((item) => initialData.systemInstructionIds?.includes(item.id));
            setTemplates(matchingTools?.filter((item) => item?.name?.startsWith(templatePrefix)));
            // Set the tools field in assetFormStore
            assetFormStore.getState().setField("tools", matchingTools);
          }
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETSYSTEMINSTRUCTIONS), err as Error);
        });
      assetFormStore.getState().setField("icon", initialData.icon);
      assetFormStore.getState().setField("image", initialData.image);
      assetFormStore.getState().setField("llmIds", (initialData as Assistant).llmIds);
    }

    setFormData({
      assetDescription: initialData?.description || "",
      assetName: initialData?.name || "",
      attachmentStorages: (initialData as Assistant)?.attachmentStorages || [],
      dataSources: (initialData as Assistant)?.dataSourceIds || [],
      greeting: (initialData as Assistant)?.greetingMessage || "",
      icon: initialData?.icon || "",
      image: initialData?.image || "",
      suggestions: (initialData as Assistant)?.sampleQuestions || [],
      systemPrompts: initialData?.systemInstructionIds || [],
      tools: [],
    });
    const defaultModel = aiModels?.find((model) => model.default);
    setSelectedModel((initialData as Assistant)?.llmIds?.[0] || defaultModel?.id || "");
    //check if modelID is equal to llmID or modelID is equal to defaultodelID
    const selectedModel =
      aiModels?.find((model) => model.id === (initialData as Assistant)?.llmIds?.[0]) || defaultModel;
    assetFormStore.getState().setField("modelDetails", selectedModel as Module);
    setIsInitialized(true); // Mark as initialized
  }, [initialData, aiModels, openErrorNotification, toolPrefix, setAllPrompts]);
  const utilityAgentAiModelRender = useCallback(() => {
    setIsInitialized(true); // to show review form
    if (initialData) {
      assetFormStore.getState().setField("assetName", initialData.name);
      assetFormStore.getState().setField("assetDescription", initialData.description);
      SystemInstructionService.getSystemInstructions()
        .then((res) => {
          setAllPrompts(res);
          const filteredInstructions = res.filter(
            (el) => !el.name.includes(toolPrefix) && !el.name.includes(templatePrefix)
          );
          if (initialData) {
            const matchingInstructions = filteredInstructions.filter((item) =>
              initialData.systemInstructionIds?.includes(item.id)
            );
            setSystemInstructions(matchingInstructions);
            assetFormStore.getState().setField("systemPrompts", matchingInstructions);
          }
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETSYSTEMINSTRUCTIONS), err as Error);
        });
      assetFormStore.getState().setField("icon", initialData.icon);
      assetFormStore.getState().setField("image", initialData.image);
      assetFormStore.getState().setField("llmIds", (initialData as Agent).llmId); //tbd
    }
    setFormData({
      assetDescription: initialData?.description || "",
      assetName: initialData?.name || "",
      functionToolIds: (initialData as Agent)?.functionToolIds || [],
      icon: initialData?.icon || "",
      image: initialData?.image || "",
      systemPrompts: initialData?.systemInstructionIds || [],
    });
    const defaultModel = aiModels?.find((model) => model.default);
    setSelectedModel((initialData as Agent)?.llmId || defaultModel?.id || "");
    const selectedModel = aiModels?.find((model) => model.id === (initialData as Agent)?.llmId) || defaultModel;
    assetFormStore.getState().setField("modelDetails", selectedModel as Module);
    ModuleService.getModulesByType(ModuleType.FUNCTION_TOOL)
      .then((res) => {
        if (initialData) {
          const matchingInstructions = res.filter((item) => (initialData as Agent).functionToolIds?.includes(item.id));
          assetFormStore.getState().setField("functionTools", matchingInstructions);
        }
      })
      .catch(() => {});
  }, [initialData, aiModels, toolPrefix, setAllPrompts]);

  useEffect(() => {
    if (aiModels) setAllCapabilitiesEmpty(aiModels?.every((mod) => !mod.capabilities || mod.capabilities.length === 0));
  }, [aiModels]);

  useEffect(() => {
    if (!isUtilityAgent) {
      assistantAiModelRender();
    } else {
      utilityAgentAiModelRender();
    }
  }, [aiModels, assistantAiModelRender, isUtilityAgent, utilityAgentAiModelRender]);

  //to set tags into assetform
  useEffect(() => {
    // Only update if the values are different (deep comparison)
    if (JSON.stringify(assetForm.tags) !== JSON.stringify(selectedTags)) {
      assetForm.setField("tags", selectedTags);
    }
  }, [selectedTags]);
  // handlers
  const handleFormData = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setValue(name as keyof typeof formData | "modelDetails", value, {
      shouldValidate: true,
    }); //triggers validation
    setValue(name as keyof typeof formData | "modelDetails", value, {
      shouldDirty: true,
    });
    if (name === "modelDetails") {
      setSelectedModel(value);
      const selectedModel = aiModels?.find((model) => model.id === value);
      assetForm.setField(name as keyof AssetForm, selectedModel as Module);
    } else {
      assetForm.setField(name as keyof AssetForm, value);
    }
  };

  // Update Logic (MVP)
  const handleUpdateFormData = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setValue(name as keyof typeof formData | "modelDetails", value, {
      shouldValidate: true,
    }); //triggers validation
    setValue(name as keyof typeof formData | "modelDetails", value, {
      shouldDirty: true,
    });
    setFormData((orgData) => ({
      ...orgData,
      [name]: value,
    }));
    assetForm.setField(name as keyof AssetForm, value);
  };

  function updateData(initialData: Assistant | Agent, formData: UpdateForm | UpdateFormUtilityAgent) {
    const updatedData = { ...initialData };
    if (formData.assetName !== initialData.name) {
      updatedData.name = formData.assetName;
    }
    if (formData.assetDescription !== initialData.description) {
      updatedData.description = formData.assetDescription;
    }
    return updatedData;
  }

  const handleUtilityAgentUpdate = (tags: Tag[]) => {
    const updatePayload = updateData(initialData as Agent, formData as UpdateFormUtilityAgent);
    if (assetForm?.modelDetails?.id) (updatePayload as Agent).llmId = assetForm.modelDetails.id;
    if (assetForm?.systemPrompts) {
      updatePayload.systemInstructionIds = assetForm.systemPrompts.map((prompt) => prompt.id);
    }
    if (assetForm.tags) {
      //if new tags are added then assign updated values
      updatePayload.tags = tags ? tags : assetForm.tags;
    }
    if (assetForm.functionTools) {
      (updatePayload as Agent).functionToolIds = assetForm.functionTools?.map((fi) => fi.id) || [];
    }
    updatePayload.icon = assetForm.icon || "";
    updatePayload.image = assetForm.image || "";
    setLoadingBtn((prevState) => ({ ...prevState, update: true }));
    AgentService.updateAgent(updatePayload as Agent)
      .then((res) => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        if (updateTrigger) updateTrigger(res);
      })
      .catch((err) => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATEASSISTANT), err as Error);
      })
      .finally(() => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        if (handleClose) handleClose();
      });
  };
  //update assistant
  const handleAssistantUpdate = (tags: Tag[]) => {
    const updatePayload = updateData(initialData as Assistant, formData as UpdateForm);
    if (assetForm?.modelDetails?.id) (updatePayload as Assistant)["llmIds"] = [assetForm.modelDetails.id];

    (updatePayload as Assistant).greetingMessage = assetForm?.greeting || "";

    if (assetForm?.systemPrompts) {
      updatePayload.systemInstructionIds = assetForm.systemPrompts.map((prompt) => prompt.id);
    }
    if (assetForm?.dataSources) {
      (updatePayload as Assistant).dataSourceIds = assetForm.dataSources?.map((dataSource) => dataSource.id);
    }
    if (assetForm?.suggestions) {
      (updatePayload as Assistant).sampleQuestions = assetForm.suggestions;
    }
    if (assetForm?.tools) {
      const toolsData = assetForm.tools?.map((prompt) => prompt.id) || [];

      // logic to combine systemInstructionIds and toolsData
      let combinedInstructionIds = [];

      if (updatePayload?.systemInstructionIds && updatePayload.systemInstructionIds?.length > 0) {
        combinedInstructionIds = [...updatePayload.systemInstructionIds, ...toolsData];
      } else {
        combinedInstructionIds = toolsData;
      }

      updatePayload.systemInstructionIds = combinedInstructionIds;
    }

    if (assetForm.tags) {
      //if new tags are added then assign updated values
      updatePayload.tags = tags ? tags : assetForm.tags;
    }

    if (assetForm?.attachmentStorages) {
      (updatePayload as Assistant).attachmentStorages = assetForm.attachmentStorages;
    }

    updatePayload.icon = assetForm.icon || "";
    updatePayload.image = assetForm.image || "";
    updatePayload.customSystemInstruction = "";

    setLoadingBtn((prevState) => ({ ...prevState, update: true }));
    AssistantService.updateAssistant(updatePayload as Assistant)
      .then((res) => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        if (updateTrigger) updateTrigger(res);
      })
      .catch((err) => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATEASSISTANT), err as Error);
      })
      .finally(() => {
        setLoadingBtn((prevState) => ({ ...prevState, update: false }));
        if (handleClose) handleClose();
      });
  };

  // Update Logic
  const handleUpdate = async () => {
    let tags: Tag[] = [];
    try {
      tags = await processTags(selectedTags as TagOrCustom[], (loadingState) =>
        setLoadingBtn((prev) => ({
          ...prev,
          ...loadingState,
        }))
      );
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATETAGS), error as Error);
    }

    assetForm.setField("tags", tags); //update the store
    setSelectedTags(tags);
    if (isUtilityAgent) {
      handleUtilityAgentUpdate(tags);
    } else {
      handleAssistantUpdate(tags);
    }
  };

  // Delete confirmation popup for agent and utility agent
  const handleDelete = async () => {
    if (isUtilityAgent) {
      setUtilityAgentDeleteConfirmation(true);
    } else {
      setOpenDeleteConfirmation(true);
    }
  };

  const handleEnableCustom = () => {
    setCustomize(!customize);
    assetForm.setField("customizing", !customize);
  };

  async function fetchApplicationSettingsAndPreferences() {
    try {
      const [appSettings, preferences] = await Promise.all([
        ApplicationService.getApplicationSettings(),
        UserService.getUserPreferences(),
      ]);
      const prefNameValue = getPreferenceNameValuePairs(appSettings, preferences);
      return mapStorageDefaults(prefNameValue);
    } catch (err) {
      console.error("Error fetching application settings and preferences:", err);
      throw err;
    }
  }
  useEffect(() => {
    async function fetchAndSetData() {
      try {
        const defaultAttachments = await fetchApplicationSettingsAndPreferences();
        setDefaultAttachmentMappings(defaultAttachments);
        if (!initialData) {
          // Create mode: Set attachment storages in assetFormStore
          assetFormStore.getState().setField("attachmentStorages", defaultAttachments);
          AgentDirtyDataHelper(assetForm, undefined, undefined, defaultAttachments);
        }
      } catch (err) {
        console.error("Error fetching and setting data:", err);
      }
    }

    fetchAndSetData();
  }, [initialData, t, openErrorNotification]);
  const onselect = (id: string | number) => {
    const val = typeof id === "string" && id;
    const found = aiModels?.find((o) => o.id.toString() === val);
    if (found) {
      setSelectedModel(found?.id);
      assetForm.setField("modelDetails", found as Module);
      setValue("modelDetails", found?.id, { shouldValidate: true });
    }
  };
  return (
    <>
      {!initialData ? (
        <>
          <div>
            <div>
              <Form className="fs-6">
                <Form.Group controlId="assetName">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AGENTNAME)} />
                  <Form.Control
                    type="text"
                    placeholder={t(TranslationKeys.AGENTFORM_NAMEYOURAGENT)}
                    isInvalid={!!errors.assetName}
                    {...register("assetName")}
                    onChange={handleFormData}
                    style={{ borderRadius: "var(--bs-border-radius)" }}
                  />
                  {errors.assetName ? (
                    <Form.Control.Feedback type="invalid">{String(errors.assetName.message)}</Form.Control.Feedback>
                  ) : (
                    <Form.Control.Feedback type="invalid">
                      {t(TranslationKeys.MESSAGES_NAMEREQUIRED)}
                    </Form.Control.Feedback>
                  )}
                </Form.Group>
                <Form.Group controlId="assetDescription" className="mt-2">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AGENTDESCRIPTION)} />
                  <Form.Control
                    type="text"
                    placeholder={t(TranslationKeys.AGENTFORM_DESCRIBEYOURAGENT)}
                    isInvalid={!!errors.assetDescription}
                    {...register("assetDescription")}
                    onChange={handleFormData}
                    style={{ borderRadius: "var(--bs-border-radius)" }}
                  />
                  {errors.assetDescription ? (
                    <Form.Control.Feedback type="invalid">
                      {String(errors.assetDescription.message)}
                    </Form.Control.Feedback>
                  ) : (
                    <Form.Control.Feedback type="invalid">
                      {t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)}
                    </Form.Control.Feedback>
                  )}
                </Form.Group>
                <Form.Group controlId="modelDetails" className="mt-2">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AIMODEL)} />
                  {!allCapabilitiesEmpty && (
                    <i
                      className="bi bi-info-circle text-light"
                      style={{ paddingLeft: "0.2rem" }}
                      onClick={() => {
                        setShowInfoTooltip(true);
                      }}
                    ></i>
                  )}
                  <ModuleDropdown
                    name="modelDetails"
                    options={aiModels as Module[]}
                    value={selectedModel}
                    registerProps={register("modelDetails")}
                    onChange={onselect}
                  />
                  {errors.modelDetails ? (
                    <div className="invalid-feedback d-block">
                      {errors.modelDetails?.message
                        ? String(errors.modelDetails.message)
                        : t(TranslationKeys.MESSAGES_AIMODEL)}
                    </div>
                  ) : null}
                </Form.Group>
                <Form.Group className="mb-3 mt-2" controlId="tags">
                  <Form.Label>{t(TranslationKeys.AGENTFORM_TAGS)}</Form.Label>
                  <DropdownSelect
                    options={tags}
                    selectedTags={selectedTags}
                    setSelectedTags={setSelectedTags}
                    customStyle={true}
                  />
                </Form.Group>
              </Form>
            </div>

            <Form>
              <Form.Check
                type="switch"
                id="custom-switch"
                label={t(TranslationKeys.AGENTFORM_CUSTOMIZEAGENT)}
                className="mt-2"
                checked={customize}
                onClick={handleEnableCustom}
              />
            </Form>
            <Collapse in={customize}>
              <div>
                <CustomAssetForm
                  selectedAiModel={aiModels?.find((model) => model.id === selectedModel) as Module}
                  isUtilityAgent={isUtilityAgent}
                  defaultStorageAttachments={defaultAttachmentMappings}
                />
                <Row className=" d-flex flex-row gap-5 mt-3 mb-2">
                  <Col lg={3} className="d-flex">
                    <Form.Group className="flex-grow-1 d-flex flex-column">
                      <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_ICON)}</Form.Label>
                      <div className="flex-grow-1 d-flex align-items-center">
                        <ImageUpload
                          value={assetForm?.icon}
                          variant="circle"
                          maxSizeInBytes={MAX_ICON_SIZE}
                          width="6em"
                          height="6em"
                          onUpload={(base64Image: string) => {
                            setValue("icon", base64Image, {
                              shouldValidate: true,
                            });
                            updateAssetFormData([{ fieldName: "icon", value: base64Image }], assetForm);
                          }}
                          onDelete={() => {
                            setValue("icon", "", {
                              shouldValidate: true,
                            });
                            updateAssetFormData([{ fieldName: "icon", value: "" }], assetForm);
                          }}
                          onError={(error: Error) => {
                            openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                          }}
                        />
                      </div>
                    </Form.Group>
                  </Col>
                  <Col lg={3}>
                    <Form.Group>
                      <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_IMAGE)}</Form.Label>
                      <ImageUpload
                        width="8em"
                        height="6em"
                        value={assetForm?.image}
                        maxSizeInBytes={MAX_IMAGE_SIZE}
                        onDelete={() => {
                          setValue("image", "", {
                            shouldValidate: true,
                          });
                          updateAssetFormData([{ fieldName: "image", value: "" }], assetForm);
                        }}
                        onUpload={(base64Image: string) => {
                          setValue("image", base64Image, {
                            shouldValidate: true,
                          });
                          updateAssetFormData([{ fieldName: "image", value: base64Image }], assetForm);
                        }}
                        onError={(error: Error) => {
                          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                        }}
                      />
                    </Form.Group>
                  </Col>
                </Row>
              </div>
            </Collapse>
          </div>
        </>
      ) : (
        <>
          <Row>
            <Col>
              <Form className="fs-6" id="agent-form-update" onSubmit={handleSubmit(handleUpdate)}>
                <Form.Group controlId="assetName">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AGENTNAME)} />
                  <Form.Control
                    type="text"
                    placeholder={t(TranslationKeys.AGENTFORM_NAMEYOURAGENT)}
                    required={true}
                    isInvalid={!!errors.assetName}
                    {...register("assetName")}
                    onChange={handleUpdateFormData}
                    value={formData?.assetName || ""}
                  />
                  {errors.assetName && (
                    <Form.Control.Feedback type="invalid">{String(errors.assetName.message)}</Form.Control.Feedback>
                  )}
                </Form.Group>
                <Form.Group controlId="assetDescription" className="mt-2">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AGENTDESCRIPTION)} />
                  <Form.Control
                    type="text"
                    placeholder={t(TranslationKeys.AGENTFORM_DESCRIBEYOURAGENT)}
                    required={true}
                    isInvalid={!!errors.assetDescription}
                    {...register("assetDescription")}
                    onChange={handleUpdateFormData}
                    value={formData?.assetDescription || ""}
                  />
                  {errors.assetDescription && (
                    <Form.Control.Feedback type="invalid">
                      {String(errors.assetDescription.message)}
                    </Form.Control.Feedback>
                  )}
                </Form.Group>
                <Form.Group controlId="modelDetails" className="mt-2">
                  <RequiredLabel label={t(TranslationKeys.AGENTFORM_AIMODEL)} />
                  {!allCapabilitiesEmpty && (
                    <i
                      className="bi bi-info-circle text-light"
                      style={{ paddingLeft: "0.2rem" }}
                      onClick={() => {
                        setShowInfoTooltip(true);
                      }}
                    ></i>
                  )}
                  <ModuleDropdown
                    name="modelDetails"
                    options={aiModels as Module[]}
                    value={selectedModel}
                    registerProps={register("modelDetails")}
                    onChange={onselect}
                  />
                  {errors.modelDetails ? (
                    <div className="invalid-feedback d-block">
                      {errors.modelDetails?.message
                        ? String(errors.modelDetails.message)
                        : t(TranslationKeys.MESSAGES_AIMODEL)}
                    </div>
                  ) : null}
                </Form.Group>
                <Form.Group className="mb-3 mt-2" controlId="tags">
                  <Form.Label>{t(TranslationKeys.AGENTFORM_TAGS)}</Form.Label>
                  <DropdownSelect options={tags} selectedTags={selectedTags} setSelectedTags={setSelectedTags} />
                </Form.Group>
              </Form>
              <CustomAssetForm
                initialData={isUtilityAgent ? (initialData as Agent) : (initialData as Assistant)}
                onUpdateAssetForm={(updatedAssetData) => updateAssetFormData(updatedAssetData, assetForm)}
                selectedAiModel={aiModels?.find((model) => model.id === selectedModel) as Module}
                isUtilityAgent={isUtilityAgent}
                defaultStorageAttachments={defaultAttachmentMappings}
              />
              <Row className="mt-3 mb-2">
                <Col lg={3} className="d-flex">
                  <Form.Group className="flex-grow-1 d-flex flex-column">
                    <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_ICON)}</Form.Label>
                    <div className="flex-grow-1 d-flex align-items-center">
                      <ImageUpload
                        value={assetForm?.icon}
                        variant="circle"
                        maxSizeInBytes={MAX_ICON_SIZE}
                        width="6em"
                        height="6em"
                        onUpload={(base64Image: string) => {
                          setValue("icon", base64Image, {
                            shouldValidate: true,
                          });
                          updateAssetFormData([{ fieldName: "icon", value: base64Image }], assetForm);
                        }}
                        onDelete={() => {
                          setValue("icon", "", {
                            shouldValidate: true,
                          });
                          updateAssetFormData([{ fieldName: "icon", value: "" }], assetForm);
                        }}
                        onError={(error: Error) => {
                          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                        }}
                      />
                    </div>
                  </Form.Group>
                </Col>
                <Col lg={9}>
                  <Form.Group>
                    <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_IMAGE)}</Form.Label>
                    <ImageUpload
                      width="8em"
                      height="6em"
                      value={assetForm?.image}
                      maxSizeInBytes={MAX_IMAGE_SIZE}
                      onDelete={() => {
                        setValue("image", "", {
                          shouldValidate: true,
                        });
                        updateAssetFormData([{ fieldName: "image", value: "" }], assetForm);
                      }}
                      onUpload={(base64Image: string) => {
                        setValue("image", base64Image, {
                          shouldValidate: true,
                        });
                        updateAssetFormData([{ fieldName: "image", value: base64Image }], assetForm);
                      }}
                      onError={(error: Error) => {
                        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                      }}
                    />
                  </Form.Group>
                </Col>
              </Row>
            </Col>
            <Col>
              <div
                style={{
                  // maxHeight: "80%",
                  border: "0.5px solid grey",
                  borderRadius: "var(--bs-border-radius)",
                  marginTop: "1.95em",
                }}
              >
                {isInitialized && <AgentReviewForm data={assetForm} isUtilityAgent={isUtilityAgent} />}
              </div>
            </Col>
          </Row>
          <Row className="mt-3">
            <Col>
              <div className="text-start">
                {initialData && showDelete ? (
                  loadingBtn && loadingBtn.delete ? (
                    <button className="btn btn-danger" type="button" disabled>
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                      &nbsp;{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}
                    </button>
                  ) : (
                    <Button
                      variant="danger"
                      type="button"
                      onClick={handleDelete}
                      disabled={initialData?.creator.id !== userId}
                    >
                      {t(TranslationKeys.AGENTWORKFLOWFORM_DELETE)}
                    </Button>
                  )
                ) : null}
              </div>
            </Col>
            <Col>
              <div className="text-end">
                {loadingBtn && (loadingBtn.update || loadingBtn.tags) ? (
                  <button className="btn btn-primary" type="button" disabled>
                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    &nbsp;{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}
                  </button>
                ) : (
                  <Button variant="primary" type="submit" className="button" onClick={handleSubmit(handleUpdate)}>
                    {t(TranslationKeys.AGENTWORKFLOWFORM_UPDATE)}
                  </Button>
                )}
              </div>
            </Col>
          </Row>
        </>
      )}

      {/* confirmation modal for agent and utility agent  */}
      <Modal
        show={isUtilityAgent ? utilityAgentDeleteConfirmation : openDeleteConfirmation}
        onHide={() => (isUtilityAgent ? setUtilityAgentDeleteConfirmation(false) : setOpenDeleteConfirmation(false))}
        backdrop="static"
        size="lg"
        centered
        fullscreen="md-down"
        className="text-light custom-modal-backdrop"
      >
        <Modal.Header
          style={{
            fontWeight: "bold",
          }}
        >
          {isUtilityAgent ? "Delete Utility Agent?" : "Delete Agent?"}
        </Modal.Header>
        <Modal.Body>
          {isUtilityAgent ? (
            <DeleteAgent
              agent={initialData as Agent}
              systemPrompts={systemInstructions?.map((item) => item.name)}
              handleClose={handleClose}
              updateTrigger={updateTrigger}
              handleAgentClose={() => setUtilityAgentDeleteConfirmation(false)}
            />
          ) : (
            <DeleteAssistant
              assistant={initialData as Assistant}
              systemPrompts={systemInstructions?.map((item) => item.name)}
              dataSources={dataSources?.map((item) => item.name)}
              systemInstructions={systemInstructions}
              templates={templates}
              templatesList={templates?.map((item) => item.name)}
              handleClose={handleClose}
              updateTrigger={updateTrigger}
              handleAssistantClose={() => setOpenDeleteConfirmation(false)}
            />
          )}
        </Modal.Body>
      </Modal>

      {/* Info tooltip for AI model selection */}
      <Modal
        show={showInfoTooltip}
        onHide={() => setShowInfoTooltip(false)}
        backdrop="static"
        size="lg"
        centered
        fullscreen="md-down"
        className="text-light custom-modal-backdrop capabilities-modal"
      >
        <Modal.Header style={{ fontWeight: "bold" }} closeButton>
          {t(TranslationKeys.AGENTFORM_AIMODELS)}
        </Modal.Header>
        <Modal.Body>
          <TooltipTable tooltipData={aiModels as Module[]} />
        </Modal.Body>
      </Modal>
    </>
  );
}
const NewAgentForm = forwardRef<FormRef, NewAgentFormProps>(NewAgentFormComponent);
export default NewAgentForm;
