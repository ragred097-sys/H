import { BaseSyntheticEvent, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button, Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { SystemInstruction } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import { SystemInstructionService } from "./../../services/SystemInstructionService";

export const CreateSystemPromptForm = ({
  handleClose,
}: {
  handleClose?: (systemPrompts?: SystemInstruction[]) => void;
}) => {
  const [loadingBtn, setLoadingBtn] = useState(false);
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();

  const schema = z.object({
    description: z
      .string()
      .trim()
      .min(1, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTDESCRIPTIONREQUIRED))
      .refine((val) => val.trim().length > 0, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTDESCRIPTIONREQUIRED)),
    message: z
      .string()
      .trim()
      .min(1, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTINSTRUCTIONREQUIRED))
      .refine((val) => val.trim().length > 0, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTINSTRUCTIONREQUIRED)),
    promptName: z
      .string()
      .trim()
      .min(1, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTNAMEREQUIRED))
      .refine((val) => val.trim().length > 0, t(TranslationKeys.ERRORMESSAGES_SYSTEMPROMPTNAMEREQUIRED)),
  });

  type SystemPromptSchema = z.infer<typeof schema>;

  const {
    formState: { errors, isDirty, isSubmitting, isValid },
    handleSubmit,
    register,
    reset,
  } = useForm({
    defaultValues: {
      description: "",
      message: "",
      promptName: "",
    },
    mode: "onChange",
    resolver: zodResolver(schema),
  });

  const handleCreate: SubmitHandler<SystemPromptSchema> = async (data, e?: BaseSyntheticEvent) => {
    e?.preventDefault();
    const payload = {
      description: data?.description as string,
      message: data?.message as string,
      name: data?.promptName as string,
    };
    setLoadingBtn(true);
    try {
      const res = await SystemInstructionService.createSystemInstruction(payload as SystemInstruction);
      if (handleClose) {
        handleClose([res]);
      }
      reset();
    } catch (err) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATESYSINSFORM), err as Error);
    } finally {
      setLoadingBtn(false);
    }
  };

  return (
    <Form onSubmit={handleSubmit(handleCreate)}>
      <Form.Group className="mb-3">
        <RequiredLabel label={t(TranslationKeys.SYSTEMPROMPTFORM_INSTRUCTIONNAME)} />
        <Form.Control id="promptName" as="input" isInvalid={!!errors.promptName} {...register("promptName")} />
        {errors.promptName && (
          <Form.Control.Feedback type="invalid">{errors.promptName?.message?.toString()}</Form.Control.Feedback>
        )}
      </Form.Group>
      <Form.Group className="mb-3">
        <RequiredLabel label={t(TranslationKeys.SYSTEMPROMPTFORM_INSTRUCTIONDESCRIPTION)} />
        <Form.Control
          id="description"
          as="textarea"
          rows={2}
          isInvalid={!!errors.description}
          {...register("description")}
        />
        {errors.description && (
          <Form.Control.Feedback type="invalid">{errors.description?.message?.toString()}</Form.Control.Feedback>
        )}
      </Form.Group>
      <Form.Group className="mb-4">
        <RequiredLabel label={t(TranslationKeys.SYSTEMPROMPTFORM_INSTRUCTION)} />
        <Form.Control
          id="message"
          className="pt-2"
          as="textarea"
          rows={5}
          isInvalid={!!errors.message}
          {...register("message")}
        />
        {errors.message && (
          <Form.Control.Feedback type="invalid">{errors.message?.message?.toString()}</Form.Control.Feedback>
        )}
      </Form.Group>
      <div className="text-end">
        {loadingBtn ? (
          <Button variant="primary" disabled>
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            &nbsp;Creating...
          </Button>
        ) : (
          <Button type="submit" variant="primary" className="button" disabled={!isValid || !isDirty || isSubmitting}>
            {t(TranslationKeys.MESSAGES_CREATEPROMPT)}
          </Button>
        )}
      </div>
    </Form>
  );
};
