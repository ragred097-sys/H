import { useEffect, useState } from "react";

import { Button, Col, Container, Form, ListGroup, Modal, Row, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Agent, Module, ModuleType } from "../../lib/Model";
import { assetFormStore, authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { ADMIN_ROLE } from "../../utils/constants";
import ListSkeleton from "../general/ListSkeleton";
import { GradientCircleButton } from "../general/RoundButton";
import { ModuleService } from "./../../services/ModuleService";
import { ModuleForm } from "./ModuleForm";

export const FunctionToolForm = ({ handleClose, initialData }: { handleClose: () => void; initialData?: Agent }) => {
  const { t } = useTranslation();
  const assetForm = assetFormStore((state) => state);
  const [functionTools, setFunctionTools] = useState<Module[]>();
  const [selectedFunctionTool, setSelectedFunctionTool] = useState<Module>();
  const [newFunctionalTool, setNewFunctionTool] = useState<boolean>();
  const [pickedFunctionTools, setPickedFunctionTools] = useState<Module[]>();
  const [loading, setLoading] = useState(false);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const userRoles = authStore((state) => state.roles);

  useEffect(() => {
    setIsAdmin(userRoles?.some((role) => role.name == ADMIN_ROLE));
  }, [userRoles]);

  useEffect(() => {
    setLoading(true);
    ModuleService.getModulesByType(ModuleType.FUNCTION_TOOL)
      .then((res) => {
        setFunctionTools(res);
        setLoading(false);
        if (assetForm?.functionTools?.length) {
          const matchingInstructions = res.filter((item) => assetForm.functionTools!.some((fi) => fi.id === item.id));
          setPickedFunctionTools(matchingInstructions);
        }
      })
      .catch(() => {
        setLoading(false);
      });
  }, []);
  const FunctionToolDetails = ({ selectedFunctionTool }: { selectedFunctionTool: Module }) => {
    if (selectedFunctionTool) {
      return (
        <div key={selectedFunctionTool.id}>
          <p className="fw-bold">{t(TranslationKeys.MESSAGES_NAME)}:</p>
          <p>{selectedFunctionTool?.name}</p>
          <div>
            <p className="fw-bold">{t(TranslationKeys.MESSAGES_DESCRIPTION)}:</p>
            <p>{selectedFunctionTool?.description ? selectedFunctionTool?.description : "-"}</p>
          </div>
          {Array.isArray(selectedFunctionTool?.parameters) && selectedFunctionTool.parameters.length > 0 && (
            <>
              {selectedFunctionTool.parameters.map((param, i) => (
                <div key={i}>
                  <p className="fw-bold">{param?.name}:</p>
                  <p>{param?.value}</p>
                </div>
              ))}
            </>
          )}
        </div>
      );
    }
    return null;
  };
  const handleFunctionToolSelect = (id: string) => {
    const selectedFunctionTool = functionTools?.find((el) => el.id === id);
    if (selectedFunctionTool) {
      setSelectedFunctionTool(selectedFunctionTool);
    }
  };
  const handlePickFunctionTools = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pickedItem = functionTools?.find((el) => el.id === e.target.value);
    if (pickedItem) {
      setPickedFunctionTools((prev = []) => {
        if (prev.some((item) => item?.id === pickedItem.id)) {
          return prev.filter((el) => el?.id !== pickedItem.id);
        } else {
          return [...prev, pickedItem];
        }
      });
    }
  };
  const handleSelect = () => {
    assetForm.setField("functionTools", pickedFunctionTools);
    handleClose();
  };
  const handleTriggerUpdate = (newlyCreatedModule: Module) => {
    setLoading(true);
    ModuleService.getModulesByType(ModuleType.FUNCTION_TOOL)
      .then((res) => {
        setFunctionTools(res);
        setLoading(false);
        if (assetForm?.functionTools?.length) {
          const matchingInstructions = res.filter((item) => assetForm.functionTools!.some((fi) => fi.id === item.id));
          if (res) {
            setPickedFunctionTools([...(matchingInstructions || []), newlyCreatedModule]);
            setSelectedFunctionTool(newlyCreatedModule);
          } else {
            setPickedFunctionTools(matchingInstructions);
          }
        } else {
          setSelectedFunctionTool(newlyCreatedModule);
          setPickedFunctionTools([newlyCreatedModule]);
        }
      })
      .catch(() => {
        setLoading(false);
      });
  };
  return (
    <>
      <Container fluid className="d-flex flex-column h-100">
        <div className="d-flex flex-row align-items-center">
          <span className="pe-2">{t(TranslationKeys.MESSAGES_EXISTINGFUNCTIONTOOLS)}</span>
          {isAdmin && (
            <Button variant="transparent" onClick={() => setNewFunctionTool(true)}>
              <GradientCircleButton dim="22px" fontSize="14px" />
            </Button>
          )}
        </div>
        <Row className="flex-grow-1">
          <Col xs={4} className="overflow-auto me-2" style={{ height: "50vh" }}>
            <div>
              {loading ? (
                <ListSkeleton length={15} />
              ) : (
                <ListGroup>
                  {functionTools?.map((functionTool) => (
                    <div className="d-flex flex-row" key={functionTool.id}>
                      <Form className="pt-1 pe-2">
                        <Form.Check
                          type="checkbox"
                          value={functionTool.id}
                          checked={pickedFunctionTools?.some((item) => item.id === functionTool.id)}
                          onChange={(e) => {
                            handlePickFunctionTools(e);
                          }}
                        />
                      </Form>
                      <Button
                        key={functionTool.id}
                        value={functionTool.id}
                        variant={
                          getComputedStyle(document.documentElement).getPropertyValue("--theme-color") == "dark"
                            ? "outline-light"
                            : "light"
                        }
                        className={`mb-2 navai-button w-75 ${
                          selectedFunctionTool?.id === functionTool.id ? "active" : ""
                        }`}
                        style={{
                          borderRadius: "var(--bs-border-radius)",
                          wordWrap: "break-word",
                        }}
                        size="sm"
                        onClick={() => handleFunctionToolSelect(functionTool.id)}
                      >
                        {functionTool.name}
                      </Button>
                    </div>
                  ))}
                </ListGroup>
              )}
            </div>
          </Col>
          <Col className="overflow-auto navai-button pt-2 pb-3 ps-3 pe-3" style={{ height: "50vh" }}>
            <div className="h-100 d-flex flex-column">
              <div className="flex-grow-1 overflow-auto">
                {loading ? (
                  <div className="w-100 h-50 d-flex justify-content-center align-items-center">
                    <Spinner animation="border" role="status">
                      <span className="visually-hidden">{t(TranslationKeys.MESSAGES_LOADING)}</span>
                    </Spinner>
                  </div>
                ) : (
                  <>
                    {selectedFunctionTool ? <FunctionToolDetails selectedFunctionTool={selectedFunctionTool} /> : null}
                  </>
                )}
              </div>
            </div>
          </Col>
        </Row>
        <div className="text-end mt-3 pe-3">
          <Button className="button" onClick={() => handleSelect()}>
            {!initialData
              ? t(TranslationKeys.MESSAGES_SELECTFUNCTIONTOOL)
              : t(TranslationKeys.MESSAGES_UPDATEFUNCTIONTOOL)}
          </Button>
        </div>
        {/* create new function tool modal */}
        {
          <Modal
            show={newFunctionalTool}
            size="xl"
            onHide={() => setNewFunctionTool(false)}
            backdrop="static"
            centered
            className="text-light custom-modal-backdrop "
          >
            <Modal.Header closeButton>
              <Modal.Title>{t(TranslationKeys.MESSAGES_CREATEFUNCTIONTOOL)}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <ModuleForm
                type={ModuleType.FUNCTION_TOOL}
                handleClose={() => {
                  setNewFunctionTool(false);
                }}
                updateTrigger={(res) => handleTriggerUpdate(res as Module)}
              />
            </Modal.Body>
          </Modal>
        }
      </Container>
    </>
  );
};
