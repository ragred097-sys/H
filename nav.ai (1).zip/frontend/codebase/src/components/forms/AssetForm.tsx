import { useEffect, useRef, useState } from "react";

import { Button, Col, Fade, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import navaiLogo from "../../assets/images/navAILogo.png";
import { Agent, Assistant, Tag, Workspace } from "../../lib/Model";
import { assetFormStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { AgentDirtyFields } from "../../utils/agentFormFields";
import { filterObject } from "../../utils/formTools";
import { processTags } from "../../utils/tagsHelper";
import { TagOrCustom } from "../general/Dropdown";
import { useNotification } from "../general/NotificationProvider";
import { AgentService } from "./../../services/AgentService";
import { AssistantService } from "./../../services/AssistantService";
import { WorkspaceService } from "./../../services/WorkspaceService";
import AgentReviewForm from "./AgentReviewForm";
import NewAgentForm, { FormRef } from "./NewAgentForm/NewAgentForm";

// const assetTypes = [
//   {
//     agent: "Agent",
//     datasource: "Data Source",
//     agenticFlow: "Mult-Agent Coordinator",
//     prompt: "System Prompt",
//     widget: "Widget",
//   },
// ];

// const tips = [
//   "An Agent is a customizable LLM that contains custom System Prompts, data sources, and tools",
//   "A Data Source is a specialized container that can hold data used by an Agent",
//   "An agentic workflow coordinates and oversees the delegation, execution, and integration of tasks by sub-agents to achieve a specific goal efficiently.",
//   "A System Prompt is a set of instructions used by an Agent to tailor it for specific use cases",
//   "A Widget is a custom asset that links to an external resource, such as another web application",
// ];

export default function NewAssetForm({
  handleClose,
  isUtilityAgent = false,
  onCreateAgentDirtyData,
  onCreateAgentFormDirty,
  triggerUpdate,
  workspace,
}: {
  handleClose: () => void;
  triggerUpdate?: (agent: Assistant | Agent) => void;
  workspace: Workspace | undefined;
  onCreateAgentFormDirty?: (value: boolean) => void;
  onCreateAgentDirtyData?: (data: AgentDirtyFields) => void;
  isUtilityAgent?: boolean;
}) {
  const assetForm = assetFormStore((state) => state);
  const [showReview, setShowReview] = useState(false);
  const [showLogo, setShowLogo] = useState(true);
  const [loading, setLoading] = useState({
    buildAgent: false,
    tags: false,
  });
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const formRef = useRef<FormRef>(null);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (assetForm.customizing) {
      setShowLogo(false);
      timer = setTimeout(() => {
        setShowReview(true);
      }, 500);
    } else {
      setShowReview(false);
      timer = setTimeout(() => {
        setShowLogo(true);
      }, 500);
    }
    return () => clearTimeout(timer);
  }, [assetForm.customizing]);

  const handleBuildUtilityAgent = async (tags: Tag[]) => {
    const payload = {
      description: assetForm.assetDescription,
      functionToolIds: assetForm.functionTools?.map((fi) => fi.id) || [],
      icon: assetForm?.icon,
      image: assetForm?.image,
      llmId: assetForm?.modelDetails?.id,
      name: assetForm.assetName,
      systemInstructionIds: assetForm.systemPrompts?.map((sp) => sp.id) || [],
      tags: tags ? tags : assetForm.tags || [],
    };
    if (payload.name && payload.description && payload.llmId != undefined) {
      setLoading((prevState) => ({ ...prevState, buildAgent: true }));
      await AgentService.createAgent(payload as unknown as Agent)
        .then((res) => {
          WorkspaceService.linkAgentToWorkspace(workspace as Agent, res)
            .then((res) => {
              if (triggerUpdate) {
                triggerUpdate(res);
              }
              handleClose();
            })
            .catch((error) => {
              setLoading((prevState) => ({ ...prevState, buildAgent: false }));
              openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINKWORKSPACEAGENT), error as Error);
              handleClose();
            });
        })
        .catch((error) => {
          setLoading((prevState) => ({ ...prevState, buildAgent: false }));
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATEAGENT), error as Error);
        });
    }
  };
  const handleBuild = async () => {
    let tags: Tag[] = [];
    try {
      tags = await processTags(assetForm?.tags as TagOrCustom[], (loadingState) =>
        setLoading((prev) => ({
          ...prev,
          ...loadingState,
        }))
      );
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATETAGS), error as Error);
    }
    assetForm.setField("tags", tags);
    if (formRef.current) {
      const data = await formRef.current.validateAndGetData();
      if (data) {
        if (isUtilityAgent) {
          handleBuildUtilityAgent(tags);
        } else {
          let combinedInstructionIds = assetForm.systemPrompts?.map((sp) => sp.id) || [];

          if (assetForm?.tools && assetForm.tools.length > 0) {
            const toolIds = assetForm.tools.map((tool) => {
              return tool.id;
            });
            combinedInstructionIds = [...combinedInstructionIds, ...toolIds];
          }

          const payload = {
            attachmentStorages: assetForm.attachmentStorages || [],
            customSystemInstruction: null,
            dataSourceIds: assetForm?.dataSources?.map((ds) => ds.id) || [],
            description: assetForm.assetDescription,
            greetingMessage: assetForm?.greeting,
            icon: assetForm?.icon,
            image: assetForm?.image,
            llmIds: [assetForm?.modelDetails?.id],
            name: assetForm.assetName,
            sampleQuestions: assetForm.suggestions || null,
            systemInstructionIds: combinedInstructionIds || [],
            tags: tags ? tags : assetForm.tags || [],
          };

          if (payload.name && payload.description && payload.llmIds[0] != undefined) {
            const filteredPayload = filterObject(payload);
            setLoading((prevState) => ({ ...prevState, buildAgent: true }));
            await AssistantService.createAssistant(filteredPayload)
              .then((res) => {
                WorkspaceService.linkAssistantToWorkspace(workspace as Assistant, res)
                  .then((res) => {
                    if (triggerUpdate) {
                      triggerUpdate(res);
                    }
                    handleClose();
                  })
                  .catch((error) => {
                    setLoading((prevState) => ({ ...prevState, buildAgent: false }));
                    openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINKWORKSPACEASSISTANT), error as Error);
                    handleClose();
                  });
              })
              .catch((error) => {
                setLoading((prevState) => ({ ...prevState, buildAgent: false }));
                openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATEASSISTANT), error as Error);
              });
          }
        }
      }
    }
  };

  const WizardButton = () => {
    if (assetForm.formStage === "assetDetail") {
      return loading && (loading.buildAgent || loading.tags) ? (
        <button className="btn btn-primary" type="button" disabled>
          <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
          &nbsp;{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}
        </button>
      ) : (
        <Button onClick={handleBuild} className="button">
          {t(TranslationKeys.AGENTFORM_BUILDAGENT)}
        </Button>
      );
    }
  };

  return (
    <>
      <Row>
        <Col xs={3}>
          <div>
            <NewAgentForm
              ref={formRef}
              onCreateAgentFormDirty={onCreateAgentFormDirty}
              onCreateAgentDirtyData={onCreateAgentDirtyData}
              isUtilityAgent={isUtilityAgent}
            />
          </div>
        </Col>
        <Col>
          <div className="transition-container">
            <Fade in={showLogo} timeout={1000} unmountOnExit>
              <div className="d-flex justify-content-center align-items-center pt-4">
                <img
                  className="pulse-animation"
                  style={{
                    height: "7em",
                    paddingTop: "2em",
                    transition: "all 1s ease-in-out",
                  }}
                  src={navaiLogo}
                  alt="Logo"
                />
              </div>
            </Fade>

            <Fade in={showReview} timeout={1000} unmountOnExit>
              <div
                style={{
                  // maxHeight: "80%",
                  border: "0.5px solid grey",
                  borderRadius: "var(--bs-border-radius)",
                  marginTop: "1.95em",
                }}
              >
                <AgentReviewForm data={assetForm} isUtilityAgent={isUtilityAgent} />
              </div>
            </Fade>
          </div>
        </Col>
      </Row>
      <div className="text-end">
        <WizardButton />
      </div>
    </>
  );
}
