import { useState } from "react";

import { Button, Modal } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import {
  type Agent,
  type AssetForm,
  type Assistant,
  AssistantGovernanceConfiguration,
  AttachmentStorages,
  type Module,
  TypeName,
} from "../../lib/Model";
import { assetFormStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { isEqtyEnabled } from "../../utils/eqty";
import { SuggestionForm } from "../SuggestionForm";
import { AgentStorageAttachmentForm } from "./AgentStorageAttachment";
import { DataSourceForm } from "./DataSourceForm";
import { FunctionToolForm } from "./FunctionToolForm";
import { GovernanceForm } from "./GovernanceForm";
import GreetingForm from "./GreetingForm";
import { SystemPromptForm } from "./SystemPromptForm";
import { ToolForm } from "./ToolForm";
import { updateAssetFormData } from "./updateAssetForm";

export default function CustomAssetForm({
  defaultStorageAttachments,
  initialData,
  isUtilityAgent,
  onUpdateAssetForm,
  selectedAiModel,
}: {
  initialData?: Assistant | Agent;
  defaultStorageAttachments?: AttachmentStorages[];
  selectedAiModel?: Module;
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: string | number | boolean | null;
    }[]
  ) => void;
  isUtilityAgent?: boolean;
}) {
  const { t } = useTranslation();
  const assetForm = assetFormStore((state) => state);
  const [showDataForm, setShowDataForm] = useState(false);
  const [showPromptForm, setShowPromptForm] = useState(false);
  const [showGreetingForm, setShowGreetingForm] = useState(false);
  const [showToolForm, setShowToolForm] = useState(false);
  const [showGovernanceForm, setShowGovernanceForm] = useState(false);
  const [showSuggestionForm, setShowSuggestionForm] = useState(false);
  const [showAttachmentStorage, setShowAttachmentStorage] = useState(false);
  const [functionToolForm, setFunctionToolForm] = useState(false);
  const agentCustomizations = [
    {
      buttonIcon: <i className="bi bi-paperclip pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_STORAGEATTACHMENTS),
      clickAction: () => setShowAttachmentStorage(true),
      supportEntities: [TypeName.Assistant],
    },
    {
      buttonIcon: <i className="bi bi-database-add pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_REFERENCEDATA),
      clickAction: () => setShowDataForm(true),
      needId: false,
      supportEntities: [TypeName.Assistant],
    },
    {
      buttonIcon: <i className="bi bi-terminal-plus pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_SYSTEMPROMPTS),
      clickAction: () => setShowPromptForm(true),
      needId: false,
      supportEntities: [TypeName.Assistant, TypeName.Agent],
    },
    {
      buttonIcon: <i className="bi bi-chat-right-heart pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_CUSTOMGREETING),
      clickAction: () => setShowGreetingForm(true),
      needId: false,
      supportEntities: [TypeName.Assistant],
    },
    {
      buttonIcon: <i className="bi bi-person-raised-hand pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_PROMPTSUGGESTIONS),
      clickAction: () => setShowSuggestionForm(true),
      needId: false,
      supportEntities: [TypeName.Assistant],
    },

    {
      buttonIcon: <i className="bi bi-wrench-adjustable-circle pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_NAVAITOOLS),
      clickAction: () => setShowToolForm(true),
      needId: false,
      supportEntities: [TypeName.Assistant],
    },
    {
      buttonIcon: <i className="bi bi-tools pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_FUNCTIONTOOLS),
      clickAction: () => setFunctionToolForm(true),
      needId: false,
      supportEntities: [TypeName.Agent],
    },
  ];

  if (isEqtyEnabled()) {
    agentCustomizations.push({
      buttonIcon: <i className="bi bi-shield-check pe-2"></i>,
      buttonName: t(TranslationKeys.AGENTREVIEW_GOVERNANCESETTINGS),
      clickAction: () => setShowGovernanceForm(true),
      needId: true,
      supportEntities: [TypeName.Assistant, TypeName.Agent],
    });
  }

  const handleClosePrompt = () => {
    setShowPromptForm(false);
  };
  const handleCloseTool = () => {
    setShowToolForm(false);
  };

  const createGreeting = (greeting: string) => {
    assetForm.setField("greeting", greeting);
    if (initialData && onUpdateAssetForm) {
      onUpdateAssetForm?.([{ fieldName: "greeting", value: greeting }]);
    }
    setShowGreetingForm(false);
  };
  const handleCloseFunctionTool = () => {
    setFunctionToolForm(false);
  };
  const handleCloseGovernance = (governanceConfiguration: AssistantGovernanceConfiguration) => {
    assetForm.setField("governanceConfiguration", governanceConfiguration);
    setShowGovernanceForm(false);
  };
  return (
    <>
      <div className="w-100 d-flex flex-column">
        {agentCustomizations
          .filter((option) => option.supportEntities?.includes(isUtilityAgent ? TypeName.Agent : TypeName.Assistant))
          .map((opt) => (
            <Button
              key={opt.buttonName}
              className="mt-2 text-start navai-button"
              variant="outline"
              onClick={opt.clickAction}
              disabled={opt.needId && !initialData?.id}
            >
              {opt.buttonIcon}
              {opt.buttonName}
            </Button>
          ))}
      </div>

      {/* Modal Section */}
      {/* Data Modal */}
      <Modal
        show={showDataForm}
        backdrop="static"
        centered
        size="xl"
        className="text-light custom-modal-backdrop"
        onHide={() => setShowDataForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDREFERENCEDATA)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATEREFERENCEDATA)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <DataSourceForm
            handleClose={() => setShowDataForm(false)}
            initialData={initialData as Assistant}
            onUpdateAssetForm={updateAssetFormData}
            selectedAiModel={selectedAiModel}
          />
        </Modal.Body>
      </Modal>
      {/* Prompt Modal */}
      <Modal
        show={showPromptForm}
        backdrop="static"
        centered
        size="xl"
        className="text-light  custom-modal-backdrop"
        onHide={() => setShowPromptForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDSYSTEMINSTRUCTIONS)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATESYSTEMINSTRUCTIONS)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <SystemPromptForm handleClose={handleClosePrompt} initialData={initialData as Assistant} />
        </Modal.Body>
      </Modal>
      {/* Greeting Modal */}
      <Modal
        show={showGreetingForm}
        backdrop="static"
        centered
        className="text-light  custom-modal-backdrop"
        onHide={() => setShowGreetingForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDGREETING)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATEGREETING)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <GreetingForm isUpdate={!!initialData} onSubmit={createGreeting} />
        </Modal.Body>
      </Modal>
      {/* Tool Modal */}
      <Modal
        show={showToolForm}
        backdrop="static"
        centered
        size="xl"
        className="text-light  custom-modal-backdrop fat-modal"
        onHide={() => setShowToolForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDTOOLS)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATETOOLS)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ToolForm
            handleClose={handleCloseTool}
            initialData={initialData as Assistant}
            onUpdateAssetForm={updateAssetFormData}
          />
        </Modal.Body>
      </Modal>
      {/* Prompt Suggestions */}
      <Modal
        show={showSuggestionForm}
        backdrop="static"
        centered
        className="text-light  custom-modal-backdrop"
        onHide={() => setShowSuggestionForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDPROMPTSUGGESTIONS)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATEPROMPTSUGGESTIONS)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <SuggestionForm
            handleClose={() => setShowSuggestionForm(false)}
            initialData={initialData as Assistant}
            onUpdateAssetForm={updateAssetFormData}
          />
        </Modal.Body>
      </Modal>

      {/* Attachment Storage  */}
      <Modal
        show={showAttachmentStorage}
        backdrop="static"
        centered
        className="text-light  custom-modal-backdrop"
        onHide={() => setShowAttachmentStorage(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDSTORAGEATTACHMENTS)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATESTORAGEATTACHMENTS)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AgentStorageAttachmentForm
            handleClose={() => setShowAttachmentStorage(false)}
            initialData={initialData as Assistant}
            onUpdateAssetForm={updateAssetFormData}
            attachmentStorageDefaults={defaultStorageAttachments}
          />
        </Modal.Body>
      </Modal>

      {/* Function Tool */}
      <Modal
        size="xl"
        show={functionToolForm}
        backdrop="static"
        centered
        className="text-light  custom-modal-backdrop"
        onHide={() => setFunctionToolForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {!initialData
              ? t(TranslationKeys.CUSTOMASSETFORM_ADDFUNCTIONTOOL)
              : t(TranslationKeys.CUSTOMASSETFORM_UPDATEFUNCTIONTOOL)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <FunctionToolForm handleClose={handleCloseFunctionTool} initialData={initialData as Agent} />
        </Modal.Body>
      </Modal>
      <Modal
        show={showGovernanceForm}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => setShowGovernanceForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.CUSTOMASSETFORM_GOVERNANCESETTINGS)}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <GovernanceForm handleClose={handleCloseGovernance} initialData={initialData as Assistant} />
        </Modal.Body>
      </Modal>
    </>
  );
}
