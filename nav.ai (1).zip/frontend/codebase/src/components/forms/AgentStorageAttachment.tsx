import { useEffect } from "react";

import { Button, Form } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AttachmentStorageTable } from "./AttachmentStorage/AttachmentStorageForm";
import { useAttachmentStorage } from "../../hooks/useAttachmentStorage";
import { AssetForm, Assistant, AttachmentStorages } from "../../lib/Model";
import { assetFormStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";

export const AgentStorageAttachmentForm = ({
  attachmentStorageDefaults,
  handleClose,
  initialData,
  onUpdateAssetForm,
}: {
  handleClose: () => void;
  initialData?: Assistant;
  attachmentStorageDefaults?: AttachmentStorages[];
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: AttachmentStorages[];
    }[],
    assetForm: AssetForm
  ) => void;
}) => {
  const assetForm = assetFormStore((state) => state);
  const { t } = useTranslation();
  const initialAttachmentStorages = assetForm.attachmentStorages ?? initialData?.attachmentStorages ?? [];
  const { attachmentStorages, documentTypeConfigs, handleFileStorageChange, handleTypeToggle, setAttachmentStorages } =
    useAttachmentStorage(initialAttachmentStorages, attachmentStorageDefaults);

  // Initialize from store or initialData
  useEffect(() => {
    let incomingStorages = assetForm.attachmentStorages ?? initialData?.attachmentStorages ?? [];
    incomingStorages = incomingStorages.filter((e) => e.type || e.fileStorageId);
    if (incomingStorages.length > 0) {
      setAttachmentStorages(incomingStorages);
    }
  }, [assetForm.attachmentStorages, initialData, setAttachmentStorages]);

  // Helper to add an entry and update everything
  const addEntryAndUpdate = (storages: AttachmentStorages[]) => {
    if (onUpdateAssetForm) {
      onUpdateAssetForm(
        [
          {
            fieldName: "attachmentStorages",
            value: storages.length > 0 ? storages : [{ fileStorageId: null, type: null }],
          },
        ],
        assetForm
      );
    }
    handleClose();
  };

  // Submit
  const handleCreate = () => {
    addEntryAndUpdate(attachmentStorages);
  };

  return (
    <>
      <Form className="w-100" onSubmit={(e) => e.preventDefault()}>
        <div className="mb-3">
          <h6 className="mb-3 fw-bold">{t(TranslationKeys.AGENTWORKFLOWFORM_FILETYPESSTORAGE)}</h6>
          <AttachmentStorageTable
            documentTypeConfigs={documentTypeConfigs}
            onTypeToggle={handleTypeToggle}
            onFileStorageChange={handleFileStorageChange}
            attachmentStorageDefaults={attachmentStorageDefaults}
          />
          <div className="mt-3 d-flex justify-content-end">
            <Button variant="primary" className="button" onClick={handleCreate}>
              {t(TranslationKeys.AGENTWORKFLOWFORM_SAVE)}
            </Button>
          </div>
        </div>
      </Form>
    </>
  );
};
