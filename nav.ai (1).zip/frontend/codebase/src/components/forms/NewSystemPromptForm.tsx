import { useMemo, useState } from "react";

import { Button, Form } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { SystemInstruction } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import { useNotification } from "../general/NotificationProvider";
import { SystemInstructionService } from "./../../services/SystemInstructionService";

export default function NewSystemPromptForm({
  handleClose,
  initialData,
  isSystemPage,
  readOnly,
  updateTrigger,
}: {
  initialData?: SystemInstruction;
  handleClose?: () => void;
  updateTrigger?: () => void;
  readOnly?: boolean;
  isSystemPage?: boolean;
}) {
  const [newPromptData, setNewPromptData] = useState<{
    id?: string;
    name: string;
    description: string;
    message: string;
  }>();
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleFormData = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    const updatedFormData = { ...newPromptData, [id]: value };
    //@ts-expect-error just no
    setNewPromptData(updatedFormData);
  };

  const handleDelete = async () => {
    if (initialData?.id) {
      try {
        setDeleteLoading(true);
        await SystemInstructionService.deleteSystemInstruction(initialData);
        openNotification(t(TranslationKeys.MESSAGES_DELETESYSTEMINSTRUCTION), `primary`);
        if (updateTrigger) updateTrigger();
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETESYSTEMINSTRUCTIONERROR), error as Error);
      } finally {
        setDeleteLoading(false);
        if (handleClose) handleClose();
      }
    }
  };

  useMemo(() => {
    if (initialData) {
      setNewPromptData({
        description: initialData.description,
        id: initialData.id,
        message: initialData.message,
        name: initialData.name,
      });
    }
  }, [initialData]);

  const handleClick = async () => {
    if (!initialData) {
      const payload = {
        description: newPromptData?.description as string,
        message: newPromptData?.message as string,
        name: newPromptData?.name as string,
      };
      await SystemInstructionService.createSystemInstruction(payload as SystemInstruction)
        .then(() => {
          openNotification(t(TranslationKeys.MESSAGES_CLONESYSTEMINSTRUCTION), `primary`);
        })
        .catch(() => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_NEWSYSTEMINSTRUCTIONERROR));
        });
    } else {
      await SystemInstructionService.updateSystemInstruction(newPromptData as SystemInstruction).then((res) =>
        console.log(res)
      );
    }
    if (updateTrigger) updateTrigger();
    if (handleClose) handleClose();
  };

  return (
    <>
      <Form>
        <Form.Label>{t(TranslationKeys.MESSAGES_INSTRUCTIONNAME, "Instruction Name")}</Form.Label>
        <Form.Control id="name" as="input" onChange={handleFormData} value={newPromptData?.name} readOnly={readOnly} />
        <Form.Label className="pt-2">
          {t(TranslationKeys.MESSAGES_INSTRUCTIONDESCRIPTION, "Instruction Description")}
        </Form.Label>
        <Form.Control
          id="description"
          as="textarea"
          rows={6}
          onChange={handleFormData}
          value={newPromptData?.description}
          readOnly={readOnly}
        />
        <Form.Label className="pt-2">{t(TranslationKeys.MESSAGES_INSTRUCTION, "Instruction")}</Form.Label>
        <Form.Control
          id="message"
          className="pt-2"
          as="textarea"
          rows={20}
          onChange={handleFormData}
          value={newPromptData?.message}
          readOnly={readOnly}
        />
      </Form>
      {!readOnly ? (
        <div className="text-end mt-3">
          {initialData && !isSystemPage ? (
            deleteLoading ? (
              <LoadingButton className={"btn btn-danger me-4"} />
            ) : (
              <Button variant="danger" type="button" onClick={handleDelete} className="me-2">
                {t(TranslationKeys.MESSAGES_DELETE, "Delete")} {initialData?.name}
              </Button>
            )
          ) : null}
          <Button onClick={handleClick} className="button" disabled={!newPromptData}>
            {initialData
              ? t(TranslationKeys.MESSAGES_UPDATEPROMPT, "Update Prompt")
              : t(TranslationKeys.MESSAGES_CREATEPROMPT, "Create Prompt")}
          </Button>
        </div>
      ) : null}
    </>
  );
}
