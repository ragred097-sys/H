import { AssetForm } from "../../lib/Model";

export type UpdatedData = {
  fieldName: keyof AssetForm;
  value: any;
}[];

export const updateAssetFormData = (updatedData: UpdatedData, assetForm: AssetForm) => {
  if (updatedData && updatedData.length > 0) {
    updatedData.forEach((update) => {
      assetForm.setField(update.fieldName, update.value); // Process each update
    });
  }
};
