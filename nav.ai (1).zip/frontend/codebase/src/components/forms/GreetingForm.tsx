import { useEffect, useState } from "react";

import { Button, Form } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { assetFormStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";

const maxCharacterAllowed = 350;
export default function GreetingForm({
  isUpdate = false,
  onSubmit,
}: {
  isUpdate: boolean;
  onSubmit: (val: string) => void;
}) {
  const { t } = useTranslation();
  const [greeting, setGreeting] = useState<string>("");
  const assetForm = assetFormStore((state) => state);
  useEffect(() => {
    setGreeting(assetForm.greeting || "");
  }, [assetForm.greeting]);

  const handleGreetingText = (e: React.ChangeEvent<HTMLInputElement>) => {
    setGreeting(e.target.value);
  };

  const submitHandler = () => {
    onSubmit(greeting);
  };

  return (
    <>
      <Form>
        <Form.Label>{t(TranslationKeys.GREETINGFORM_GREETING)}</Form.Label>
        <Form.Control
          as="textarea"
          rows={2}
          onChange={handleGreetingText}
          value={greeting}
          maxLength={maxCharacterAllowed}
        ></Form.Control>
        <div className="pt-1 pb-1" style={{ color: "#6c757d", fontSize: "15px", textAlign: "right" }}>
          {greeting.length} / {maxCharacterAllowed}
        </div>
      </Form>
      <div className="text-end">
        <Button className="button" onClick={submitHandler}>
          {!isUpdate ? t(TranslationKeys.GREETINGFORM_ADDGREETING) : t(TranslationKeys.GREETINGFORM_UPDATEGREETING)}
        </Button>
      </div>
    </>
  );
}
