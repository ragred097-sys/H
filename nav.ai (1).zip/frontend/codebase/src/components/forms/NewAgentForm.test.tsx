import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import NewAgentForm from "./NewAgentForm/NewAgentForm";
import { assetFormStore } from "../../stores/useStore";
import { Assistant, Agent, Module, PermissionType } from "../../lib/Model";
import * as BackendModule from "../../lib/Backend";
import * as TagsHelper from "../../lib/utils/TagsHelper";
import { MemoryRouter } from "react-router-dom";
import { NotificationProvider } from "../../components/general/NotificationProvider";

vi.mock("react-i18next", () => ({
    useTranslation: () => ({
        t: (key: string) => key,
    }),
    initReactI18next: {
        type: "3rdParty",
        init: () => { },
    },
}));

vi.mock("../../lib/Backend", () => ({
    Backend: {
        getModulesByType: vi.fn(),
        getDataSources: vi.fn(),
        getSystemInstructions: vi.fn(),
        updateAssistant: vi.fn(),
        updateAgent: vi.fn(),
    },
}));

vi.mock("../../lib/utils/TagsHelper", () => ({
    useFilterTags: () => ({
        filteredTags: [],
        loadTags: vi.fn(),
    }),
    processTags: vi.fn(() => Promise.resolve([])),
}));

const mockAssistant: Assistant = {
    id: "assistant-1",
    name: "Test Assistant",
    description: "Test description",
    greetingMessage: "Hello!",
    systemInstructionIds: [],
    dataSourceIds: [],
    sampleQuestions: [],
    attachmentStorages: [],
    tags: [],
    icon: "",
    image: "",
    llmIds: ["model-1"],
    customSystemInstruction: "",
    __type_name: "Assistant",
    creator: { id: "system", name: "SYSTEM" },
    createdAt: new Date().toISOString(),
    favorite: false,
    accessPermission: PermissionType.WRITE,
};

const mockAgent: Agent = {
    id: "agent-1",
    name: "Test Agent",
    description: "Agent description",
    systemInstructionIds: [],
    tags: [],
    icon: "",
    image: "",
    llmId: "model-2",
    functionToolIds: [],
    customSystemInstruction: "",
    creator: { id: "system", name: "SYSTEM" },
    createdAt: new Date().toISOString(),
    favorite: false,
    __type_name: "Agent",
    accessPermission: PermissionType.WRITE,
};

const mockModels: Module[] = [
    {
        id: "model-1",
        name: "Model One",
        specId: "spec-1",
        parameters: [],
        supportedInputs: [],
        __type_name: "Module",
        description: "Mock model one",
        creator: { id: "system", name: "SYSTEM" },
        createdAt: new Date().toISOString(),
        tags: [],
        favorite: false,
        default: true,
        capabilities: [
            {
                name: "SUMMARIZATION_TRANSLATION",
                default: false,
                description: "Summarization and translation capability",
                creator: { id: "system", name: "SYSTEM" },
                createdAt: new Date().toISOString()
            },
            {
                name: "RESEARCH_DEVELOPMENT",
                default: true,
                description: "Research and development capability",
                creator: { id: "system", name: "SYSTEM" },
                createdAt: new Date().toISOString()
            }
        ]
    },
    {
        id: "model-2",
        name: "Model Two",
        specId: "spec-2",
        parameters: [],
        supportedInputs: [],
        __type_name: "Module",
        description: "Mock model two",
        creator: { id: "system", name: "SYSTEM" },
        createdAt: new Date().toISOString(),
        tags: [],
        favorite: false,
        default: true,
        capabilities: [
            {
                name: "SUMMARIZATION_TRANSLATION",
                default: false,
                description: "Summarization and translation capability",
                creator: { id: "system", name: "SYSTEM" },
                createdAt: new Date().toISOString()
            },
            {
                name: "RESEARCH_DEVELOPMENT",
                default: true,
                description: "Research and development capability",
                creator: { id: "system", name: "SYSTEM" },
                createdAt: new Date().toISOString()
            }
        ]
    },
];

describe("NewAgentForm - extended", () => {
    beforeEach(() => {
        assetFormStore.getState().reset();
        vi.clearAllMocks();
        (BackendModule.Backend.getModulesByType as any).mockResolvedValue(mockModels);
        (BackendModule.Backend.getDataSources as any).mockResolvedValue([]);
        (BackendModule.Backend.getSystemInstructions as any).mockResolvedValue([]);
        (BackendModule.Backend.updateAssistant as any).mockResolvedValue(mockAssistant);
        (BackendModule.Backend.updateAgent as any).mockResolvedValue(mockAgent);
        (TagsHelper.processTags as any).mockResolvedValue([]);
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    it("calls handleClose after update", async () => {
        const handleClose = vi.fn();
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} handleClose={handleClose} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const submitBtn = screen.getByRole("button", { name: /save/i });
        fireEvent.click(submitBtn);
        await waitFor(() => {
            expect(handleClose).toHaveBeenCalled();
        });
    });

    it("shows info tooltip modal when triggered", async () => {
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} />
                </NotificationProvider>
            </MemoryRouter>
        );
        // Simulate showing info tooltip modal
        // The modal is controlled by showInfoTooltip state, which is not exposed, so this is a placeholder
        // You can simulate by triggering the state via a button if present
    });

    it("renders tags dropdown if tags are available", async () => {
        (TagsHelper.useFilterTags as any).mockReturnValue({
            filteredTags: [{ id: "tag-1", name: "Tag1" }],
            loadTags: vi.fn(),
        });
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} />
                </NotificationProvider>
            </MemoryRouter>
        );
        await waitFor(() => {
            // Check for dropdown presence
            // This depends on the actual implementation of DropdownSelect
            // Placeholder: expect(screen.getByText(/Tag1/i)).toBeInTheDocument();
        });
    });

    it("calls updateAgent for utility agent", async () => {
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAgent} isUtilityAgent={true} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const submitBtn = screen.getByRole("button", { name: /save/i });
        fireEvent.click(submitBtn);
        await waitFor(() => {
            expect(BackendModule.Backend.updateAgent).toHaveBeenCalled();
        });
    });

    it("calls updateAssistant for assistant", async () => {
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const submitBtn = screen.getByRole("button", { name: /save/i });
        fireEvent.click(submitBtn);
        await waitFor(() => {
            expect(BackendModule.Backend.updateAssistant).toHaveBeenCalled();
        });
    });

    it("shows error notification if processTags throws", async () => {
        (TagsHelper.processTags as any).mockImplementation(() => Promise.reject(new Error("Tag error")));
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const submitBtn = screen.getByRole("button", { name: /save/i });
        fireEvent.click(submitBtn);
        await waitFor(() => {
            // The error notification is shown via NotificationProvider, which may render a message
            // Placeholder: expect(screen.getByText(/Tag error/i)).toBeInTheDocument();
        });
    });

    it("calls onUpdateAgentFormDirty and onUpdateAgentDirtyData when editing", async () => {
        const onUpdateAgentFormDirty = vi.fn();
        const onUpdateAgentDirtyData = vi.fn();
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm
                        initialData={mockAssistant}
                        onUpdateAgentFormDirty={onUpdateAgentFormDirty}
                        onUpdateAgentDirtyData={onUpdateAgentDirtyData}
                    />
                </NotificationProvider>
            </MemoryRouter>
        );
        await waitFor(() => {
            expect(onUpdateAgentFormDirty).toHaveBeenCalled();
            expect(onUpdateAgentDirtyData).toHaveBeenCalled();
        });
    });

    it("calls onCreateAgentFormDirty and onCreateAgentDirtyData when creating", async () => {
        const onCreateAgentFormDirty = vi.fn();
        const onCreateAgentDirtyData = vi.fn();
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm
                        onCreateAgentFormDirty={onCreateAgentFormDirty}
                        onCreateAgentDirtyData={onCreateAgentDirtyData}
                    />
                </NotificationProvider>
            </MemoryRouter>
        );
        await waitFor(() => {
            expect(onCreateAgentFormDirty).toHaveBeenCalled();
            expect(onCreateAgentDirtyData).toHaveBeenCalled();
        });
    });

    it("shows delete confirmation modal for utility agent", async () => {
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAgent} isUtilityAgent={true} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const deleteBtn = screen.getByRole("button", { name: /delete/i });
        fireEvent.click(deleteBtn);
        await waitFor(() => {
            // Confirm modal for utility agent
            // Placeholder: expect(screen.getByText(/confirm delete/i)).toBeInTheDocument();
        });
    });

    it("updates form fields and triggers validation", async () => {
        render(
            <MemoryRouter>
                <NotificationProvider>
                    <NewAgentForm initialData={mockAssistant} />
                </NotificationProvider>
            </MemoryRouter>
        );
        const nameInput = screen.getByDisplayValue("Test Assistant");
        fireEvent.change(nameInput, { target: { value: "Changed Name" } });
        expect(nameInput).toHaveValue("Changed Name");
        // You can check for validation errors if you clear the field
        fireEvent.change(nameInput, { target: { value: "" } });
        fireEvent.click(screen.getByRole("button", { name: /save/i }));
        await waitFor(() => {
            expect(screen.getByText(/required/i)).toBeInTheDocument();
        });
    });
});