import { useCallback, useEffect, useRef, useState } from "react";

import UuidGenerator from "uuid-wand";

import { Button, Col, Container, Dropdown, Form, ListGroup, Modal, Row, Spinner, Table } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AssetForm, Assistant, DataObject, DataSource, Module, PermissionType, TypeName, User } from "../../lib/Model";
import { assetFormStore, authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { AgentDirtyFields, dirtyFieldsDefaultValues } from "../../utils/agentFormFields";
import { sortArrayOfObjs } from "../../utils/arrayUtils";
import { formatTimestamp } from "../../utils/dateUtils";
import AgentDetail from "../general/AgentDetail";
import ListSkeleton from "../general/ListSkeleton";
import { useNotification } from "../general/NotificationProvider";
import { UnsavedChanges } from "../general/UnsavedChangesModal";
import { AccessControlService } from "./../../services/AccessControlService";
import { DataSourceService } from "./../../services/DataSourceService";
import { UserService } from "./../../services/UserService";
import { NewDataSourceForm } from "./NewDatasourceForm/NewDataSourceForm";
import { ShareForm } from "./ShareForm";
import UploadDataForm from "./UploadDataForm/UploadDataForm";

export const DataSourceForm = ({
  handleClose,
  initialData,
  onUpdateAssetForm,
  selectedAiModel,
  viewMode,
}: {
  handleClose?: (datasources?: DataSource[]) => void;
  initialData?: Assistant;
  selectedAiModel?: Module;
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: unknown;
    }[],
    assetForm: AssetForm
  ) => void;
  viewMode?: boolean;
}) => {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const assetForm = assetFormStore((state) => state);
  const userId = authStore((state) => state.user?.id);
  const [, setUsers] = useState<User[]>([]);
  const [dataSources, setDataSources] = useState<DataSource[]>();
  const [myDataSources, setMyDataSources] = useState<DataSource[]>([]);
  const [selectedDataSource, setSelectedDataSource] = useState<DataSource>();
  const [newDsModal, setnewDsModal] = useState(false);
  const [uploadDataModal, setUploadDataModal] = useState(false);
  const [pickedDataSources, setPickedDataSources] = useState<DataSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [newlyCreatedDs, setNewlyCreatedDs] = useState<DataSource | null>(null);
  const [showSharing, setShowSharing] = useState(false);
  const [dataSource, setDataSource] = useState<DataSource | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [dataSourceId, setDataSourceId] = useState("");
  const [sharedDataSources, setSharedDataSources] = useState<DataSource[]>([]);
  const [loadingList, setLoadingList] = useState({
    mydataSourcesList: false,
    sharedDataSourcesList: false,
  });
  const [isFormDirty, setIsFormDirty] = useState(false);
  const [isUnsavedModalOpen, setIsUnsavedModalOpen] = useState(false);
  const [dirtyFields] = useState<AgentDirtyFields>(dirtyFieldsDefaultValues);

  // --- NEW: Single fetchAll function for users, data sources, and grants ---
  const isMounted = useRef(true);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setLoadingList({ mydataSourcesList: true, sharedDataSourcesList: true });
    try {
      const [usersRes, dataSourcesRes] = await Promise.all([
        UserService.getUsers(),
        DataSourceService.getDataSources(),
      ]);
      if (!isMounted.current) return;
      setUsers(usersRes);

      const filteredDatasources = dataSourcesRes.filter((ds) => !UuidGenerator.validate(ds.name));
      const sortedRes = sortArrayOfObjs(filteredDatasources, "name");
      setDataSources(sortedRes);

      if (assetForm?.dataSources?.length) {
        const matchingDataSources = filteredDatasources.filter((item) =>
          assetForm.dataSources!.some((ds) => ds.id === item.id)
        );
        setPickedDataSources(matchingDataSources);
      }

      if (userId) {
        const myDataSources = await Promise.all(
          sortedRes
            .filter((dataSource) => dataSource.creator.id === userId)
            .map(async (dataSource) => {
              const grants = await AccessControlService.getGrants(dataSource);
              const sharedWithIds = grants
                .filter((grant) => grant.assigneeType === TypeName.User)
                .map((grant) => grant.assigneeId);

              const sharedWithUsers = usersRes
                .filter((user) => sharedWithIds.includes(user.id))
                .map((user) => user.name);

              return {
                ...dataSource,
                sharedWithUsers,
              };
            })
        );
        const sharedDataSources = sortedRes
          .filter((dataSource) => dataSource.creator.id !== userId)
          .map((dataSource) => ({
            ...dataSource,
            sharedBy: dataSource.creator.name,
          }));
        if (!isMounted.current) return;
        setMyDataSources(myDataSources);
        setSharedDataSources(sharedDataSources);
      }
    } catch (err) {
      if (isMounted.current) openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DATASOURCES), err as Error);
    } finally {
      if (isMounted.current) {
        setLoading(false);
        setLoadingList({
          mydataSourcesList: false,
          sharedDataSourcesList: false,
        });
      }
    }
  }, [userId, assetForm?.dataSources, openErrorNotification]);

  useEffect(() => {
    isMounted.current = true;
    if (userId) fetchAll();
    return () => {
      isMounted.current = false;
    };
  }, [userId, fetchAll]);

  // Use fetchAll for reloads
  const reload = fetchAll;

  const handleDsSelect = (id: string) => {
    const selectedDataSource = dataSources?.find((ds) => ds.id === id);
    if (selectedDataSource) {
      setSelectedDataSource(selectedDataSource);
    }
  };

  const handleCloseNewDs = () => {
    setnewDsModal(false);
    setDataSourceId("");
    setDataSource(null);
  };

  const downloadDataObject = async (el: DataObject) => {
    const response = await DataSourceService.getDataObjectAsBlob(el.id);
    const blob = new Blob([response], { type: response.type });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = el.fileName;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  const handlePickDataSources = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pickedDs = dataSources?.find((ds) => ds.id === e.target.value);
    if (pickedDs) {
      setPickedDataSources((prevPickedDataSources) => {
        if (prevPickedDataSources.some((ds) => ds.id === pickedDs.id)) {
          return prevPickedDataSources.filter((ds) => ds.id !== pickedDs.id);
        } else {
          return [...prevPickedDataSources, pickedDs];
        }
      });
    }
  };

  const DataSourceDetails = ({ selectedDataSource }: { selectedDataSource: DataSource }) => {
    if (selectedDataSource) {
      return (
        <div key={selectedDataSource.id}>
          <div className="d-flex justify-content-between">
            <span className="fw-bold">
              {t(TranslationKeys.WORKSPACEINFOCARD_CREATEDBY)}: {selectedDataSource.creator.name}
            </span>
            {selectedDataSource?.accessPermission === PermissionType.WRITE && (
              <Button variant="transparent" size="lg" onClick={() => setUploadDataModal(true)}>
                <i className="bi bi-cloud-upload"></i>
              </Button>
            )}
          </div>

          <span className="fw-bold">{t(TranslationKeys.WORKSPACEINFOCARD_DESCRIPTION)}</span>
          <br />
          <span> {selectedDataSource?.description}</span>
          <br />

          {selectedDataSource.ingestedFiles?.length > 0 ? (
            <Table size="xs" striped>
              <thead>
                <tr style={{ fontSize: "0.9em" }}>
                  <th>{t(TranslationKeys.WORKSPACEINFOCARD_NAME)}</th>
                  <th>{t(TranslationKeys.WORKSPACEINFOCARD_TYPE)}</th>
                  <th>{t(TranslationKeys.WORKSPACEINFOCARD_CREATEDBY)}</th>
                  <th>{t(formatTimestamp(TranslationKeys.WORKSPACEINFOCARD_CREATEDON))}</th>
                  <th> </th>
                </tr>
              </thead>
              <tbody>
                {selectedDataSource.ingestedFiles.map((el, i) => (
                  <tr key={i} style={{ fontSize: "0.9em" }}>
                    <td>{el.fileName}</td>
                    <td>{el.mimeType}</td>
                    <td>{el.creator.name}</td>
                    <td>{formatTimestamp(el.createdAt)}</td>
                    <td>
                      <Button variant="link" size="sm" onClick={() => downloadDataObject(el)}>
                        <i className="bi bi-download"></i>
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>{t(TranslationKeys.AGENTFORM_NOFILESFORDATASOURCE)}</p>
          )}
        </div>
      );
    }
    return null;
  };

  const handleSelect = () => {
    assetForm.setField("dataSources", pickedDataSources);
    if (initialData && onUpdateAssetForm) {
      onUpdateAssetForm([{ fieldName: "dataSources", value: pickedDataSources }], assetForm);
    }
    if (handleClose) handleClose(pickedDataSources);
  };

  const handleCloseUploadForm = () => {
    reload();
    setUploadDataModal(false);
  };

  // Add effect to handle reload after state updates
  useEffect(() => {
    if (newlyCreatedDs) {
      reload();
      setNewlyCreatedDs(null);
    }
  }, [newlyCreatedDs, reload]);

  function openShareForm(data: boolean) {
    setShowSharing(data);
  }
  function handleSharing(datasource: DataSource) {
    setDataSource(datasource);
    setShowSharing(true);
  }
  const handleShow = (datasource: DataSource) => {
    setDataSource(datasource);
    setShowDetail(true);
  };
  const handleCloseInfoModal = () => {
    setShowDetail(false);
  };
  const handleEdit = (datasource: DataSource) => {
    setnewDsModal(true);
    setDataSource(dataSource);
    setDataSourceId(datasource?.id);
  };
  const renderDataSources = (receivedDataSources: DataSource[]) => {
    return (
      <div className="position-relative w-100">
        <ListGroup className="d-flex w-100" style={{ paddingRight: "1em" }}>
          {receivedDataSources?.map((datasource) => (
            <div className="d-flex w-100" key={datasource.id} style={{ minWidth: 0 }}>
              {!viewMode ? (
                <Form className="pt-2 pe-2 ps-2">
                  <Form.Check
                    type="checkbox"
                    value={datasource.id}
                    checked={pickedDataSources.some((ds) => ds.id === datasource.id)}
                    onChange={handlePickDataSources}
                  />
                </Form>
              ) : null}
              <div className="flex-grow-1 button-hover" style={{ minWidth: 0 }}>
                <Button
                  value={datasource.id}
                  variant={
                    getComputedStyle(document.documentElement).getPropertyValue("--theme-color") === "dark"
                      ? "outline-light"
                      : "light"
                  }
                  className={`mb-2 navai-button responsive-button w-100 ${
                    selectedDataSource?.id === datasource.id ? "active" : ""
                  }`}
                  size="sm"
                  style={{ borderRadius: "var(--bs-border-radius)" }}
                  onClick={() => handleDsSelect(datasource.id)}
                >
                  <div className="d-flex justify-content-between align-items-center w-100">
                    <div
                      className="text-start"
                      style={{
                        flex: 1,
                        minWidth: 0,
                        wordWrap: "break-word",
                      }}
                    >
                      {datasource.name}
                    </div>
                    <div className="text-end" onClick={(event) => event.stopPropagation()}>
                      <Dropdown align="start" drop="down-centered">
                        <Dropdown.Toggle
                          variant="transparent"
                          id="dropdown-basic"
                          className="no-caret custom-dropdown-toggle px-1"
                        >
                          <i
                            className="bi bi-three-dots-vertical"
                            style={{
                              color: selectedDataSource?.id === datasource.id ? "black" : undefined,
                            }}
                          ></i>
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          <Dropdown.Item onClick={() => handleShow(datasource)}>
                            {t(TranslationKeys.AGENTCARD_INFO)}
                          </Dropdown.Item>
                          {dataSources?.some(
                            (ds) => ds.id === datasource?.id && ds.accessPermission === PermissionType.WRITE
                          ) && (
                            <Dropdown.Item onClick={() => handleEdit(datasource)}>
                              {t(TranslationKeys.AGENTCARD_EDIT)}
                            </Dropdown.Item>
                          )}
                          {myDataSources?.some((ds) => ds.id === datasource?.id) && (
                            <Dropdown.Item onClick={() => handleSharing(datasource)}>
                              {t(TranslationKeys.AGENTCARD_SHARE)}
                            </Dropdown.Item>
                          )}
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                </Button>
              </div>
            </div>
          ))}
        </ListGroup>
      </div>
    );
  };

  const renderSection = (title: string, data: DataSource[], isLoading: boolean) => {
    return (
      <div
        className="mb-3"
        style={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          minHeight: 0,
        }}
      >
        {title && (
          <>
            <h4 className="mt-4 d-flex align-items-center mb-4">
              <p className="m-0">{t(title)}</p>
              {title === t(TranslationKeys.MESSAGES_OWNDATASET) && (
                <Button
                  onClick={() => setnewDsModal(true)}
                  className="ms-3 d-flex align-items-center"
                  variant="secondary"
                  size="sm"
                >
                  <i className="bi bi-plus-lg"></i>
                </Button>
              )}
            </h4>
          </>
        )}
        <div style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
          {isLoading ? (
            <ListSkeleton length={4} styleInline={{ marginRight: "15px" }} />
          ) : data.length > 0 ? (
            renderDataSources(data)
          ) : title === t(TranslationKeys.MESSAGES_SHAREDDATASET) ? (
            <p>{t(TranslationKeys.MESSAGES_EMPTYSHAREDMESSAGE)}</p>
          ) : (
            <></>
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      <Container fluid className="d-flex flex-column h-100">
        <Row className="flex-grow-1">
          <Col xs={4} className="me-2">
            <div
              style={{
                height: "78vh",
                overflowY: "auto",
                scrollbarWidth: "none",
              }}
            >
              <div style={{ height: "95%" }}>
                {loading ? (
                  <ListSkeleton length={15} styleInline={{ marginRight: "15px" }} />
                ) : (
                  <>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        height: "95%",
                      }}
                    >
                      <div style={{ flex: 1, minHeight: 0 }}>
                        {renderSection(
                          t(TranslationKeys.MESSAGES_OWNDATASET),
                          myDataSources,
                          loadingList.mydataSourcesList
                        )}
                      </div>
                      <div style={{ flex: 1, minHeight: 0 }}>
                        {renderSection(
                          t(TranslationKeys.MESSAGES_SHAREDDATASET),
                          sharedDataSources,
                          loadingList.sharedDataSourcesList
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          </Col>
          <Col className="overflow-auto pb-3 ps-3 pe-3 h-100">
            <div className="flex-column mt-2">
              <div
                style={{
                  border: "0.5px solid grey",
                  borderRadius: "var(--bs-border-radius)",
                  height: "75vh",
                }}
              >
                <div
                  style={{
                    height: "95%",
                    margin: "1em",
                    marginBottom: "1em",
                    marginTop: "1em",
                    overflow: "auto",
                  }}
                >
                  {loading ? (
                    <div className="w-100 h-50 d-flex justify-content-center align-items-center">
                      <Spinner animation="border" role="status">
                        <span className="visually-hidden">{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}</span>
                      </Spinner>
                    </div>
                  ) : (
                    <>{selectedDataSource ? <DataSourceDetails selectedDataSource={selectedDataSource} /> : null}</>
                  )}
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <div className="text-end mt-3 pe-3">
        {!viewMode ? (
          <Button onClick={handleSelect} className="button">
            {!initialData ? t(TranslationKeys.AGENTFORM_ADDTOAGENT) : t(TranslationKeys.AGENTFORM_UPDATEDATASOURCES)}
          </Button>
        ) : null}
      </div>
      {/* New DataSource Modal */}
      <Modal
        show={newDsModal}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => {
          if (isFormDirty) {
            setIsUnsavedModalOpen(true); //open unsaved confirmation popup
          } else {
            setDataSourceId("");
            setnewDsModal(false);
          }
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {dataSourceId ? t(TranslationKeys.AGENTFORM_UPDATEDATASOURCE) : t(TranslationKeys.AGENTFORM_ADDDATASOURCE)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <NewDataSourceForm
            handleClose={handleCloseNewDs}
            updateTrigger={(res) => {
              if (res) {
                setSelectedDataSource(() => ({ ...res }));
                setPickedDataSources((prevPickedDataSources) => [...prevPickedDataSources, res]);
                setNewlyCreatedDs(res);
              }
            }}
            {...(dataSourceId && { initialDataSourceId: dataSourceId })}
            setIsFormDirty={setIsFormDirty}
          />
        </Modal.Body>
      </Modal>
      {/* Upload Modal */}
      <Modal
        show={uploadDataModal}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop semi-fat-modal"
        onHide={() => setUploadDataModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.AGENTFORM_ADDFILESTO, { name: selectedDataSource?.name })}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <UploadDataForm
            dataSource={selectedDataSource}
            model={assetForm.modelDetails}
            handleClose={handleCloseUploadForm}
            selectedAi={selectedAiModel}
          />
        </Modal.Body>
      </Modal>
      {/* Sharing Modal */}
      <Modal
        show={showSharing}
        onHide={() => setShowSharing(false)}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop "
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {t(TranslationKeys.AGENTCARD_SHAREWITH, {
              name: dataSource?.name,
              type: dataSource?.__type_name,
            })}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ShareForm
            // @ts-expect-error to be fixed
            data={dataSource}
            openShareForm={openShareForm}
          />
        </Modal.Body>
      </Modal>
      {/* INFO MODAL */}
      <Modal
        show={showDetail}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop semi-fat-modal"
        onHide={handleCloseInfoModal}
      >
        <Modal.Header closeButton>
          <Modal.Title>{dataSource?.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AgentDetail data={dataSource as DataSource} />
        </Modal.Body>
      </Modal>
      {/* unsaved changes modal */}
      {isUnsavedModalOpen && (
        <Modal show={isUnsavedModalOpen} onHide={() => setIsUnsavedModalOpen(false)}>
          <Modal.Header>
            <Modal.Title>{t(TranslationKeys.AGENTWORKFLOWFORM_UNSAVEDCHANGES)}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <UnsavedChanges dirtyFields={dirtyFields} />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setIsUnsavedModalOpen(false)}>
              {t(TranslationKeys.AGENTWORKFLOWFORM_CANCEL)}
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                setIsUnsavedModalOpen(false);
                setDataSourceId("");
                setnewDsModal(false);
              }}
            >
              {t(TranslationKeys.AGENTWORKFLOWFORM_DISCARDCHANGES)}
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
};
