import { useEffect, useState } from "react";

import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";

import { Col, Modal, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Tag, Workspace } from "../../lib/Model";
import { authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { processTags, useFilterTags } from "../../utils/tagsHelper";
import DeleteWorkSpace from "../general/DeleteWorkspace";
import DropdownSelect, { TagOrCustom } from "../general/Dropdown";
import { useNotification } from "../general/NotificationProvider";
import { WorkspaceService } from "./../../services/WorkspaceService";

interface WorkspaceFormProps {
  initialData?: Workspace | null;
  handleClose: () => void;
  onDelete?: (id: string) => void;
  updateTrigger: () => void;
}

function WorkspaceForm({ handleClose, initialData: initialWorkspace = null, updateTrigger }: WorkspaceFormProps) {
  const { t } = useTranslation();
  const userId = authStore((state) => state.user?.id);

  const [wsName, setWsName] = useState<string>("");
  const [wsDesc, setWsDesc] = useState<string>("");
  const [loadingBtn, setLoadingBtn] = useState({
    create: false,
    delete: false,
    tags: false,
    update: false,
  });

  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<TagOrCustom[]>([]);
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const { openErrorNotification } = useNotification();
  // Populate form when initialWorkspace changes
  useEffect(() => {
    if (initialWorkspace) {
      setWsName(initialWorkspace.name);
      setWsDesc(initialWorkspace.description || "");
      setSelectedTags((initialWorkspace?.tags as Tag[]) || []);
    }
  }, [initialWorkspace]);

  //custom-hook return destructuring for tags
  const { filteredTags, loadTags } = useFilterTags();
  useEffect(() => {
    fetchTags();
  }, [loadTags]);
  const fetchTags = async () => {
    setTags(filteredTags);
  };
  const updateWsName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setWsName(e.target.value);
  };

  const updateWsDesc = (e: React.ChangeEvent<HTMLInputElement>) => {
    setWsDesc(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let tags: Tag[] = [];
    try {
      tags = await processTags(selectedTags as TagOrCustom[], (loadingState) =>
        setLoadingBtn((prevState) => ({
          ...prevState,
          ...loadingState,
        }))
      );
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATETAGS), error as Error);
    }
    setSelectedTags(tags);

    try {
      // @ts-expect-error types are garbage
      const workspaceData: Workspace = {
        description: wsDesc,
        name: wsName,
        tags: tags || [],
      };
      if (initialWorkspace) {
        setLoadingBtn((prevState) => ({ ...prevState, update: true }));
        workspaceData.id = initialWorkspace.id;
        await WorkspaceService.updateWorkspace(workspaceData);
      } else {
        setLoadingBtn((prevState) => ({ ...prevState, create: true }));
        await WorkspaceService.createWorkspace(workspaceData);
      }
    } catch (error) {
      setLoadingBtn((prevState) => ({ ...prevState, create: false }));
      setLoadingBtn((prevState) => ({ ...prevState, update: false }));
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_WORKASSISTANT), error as Error);
    } finally {
      console.log("Workspace saved successfully");
      setLoadingBtn((prevState) => ({ ...prevState, update: false }));
      updateTrigger();
      handleClose();
    }
  };

  const handleDelete = async () => {
    setOpenDeleteConfirmation(true);
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLFormElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
    }
  };
  return (
    <Form onSubmit={handleSubmit} className="p-4" onKeyDown={handleKeyDown}>
      <Form.Group className="mb-3" controlId="title">
        <Form.Label>{t(TranslationKeys.WORKSPACEFORM_WORKSPACENAME)}</Form.Label>
        <Form.Control
          type="text"
          placeholder={t(TranslationKeys.WORKSPACEFORM_WORKSPACENAMEPLACEHOLDER)}
          value={wsName}
          onChange={updateWsName}
          required
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="workspaceDescription">
        <Form.Label>{t(TranslationKeys.WORKSPACEFORM_WORKSPACEDESCRIPTION)}</Form.Label>
        <Form.Control
          type="text"
          placeholder={t(TranslationKeys.WORKSPACEFORM_WORKSPACEDESCRIPTIONPLACEHOLDER)}
          value={wsDesc}
          onChange={updateWsDesc}
        />
      </Form.Group>
      <Form.Group className="mb-3">
        <Form.Label>{t(TranslationKeys.WORKSPACEFORM_TAGS)}</Form.Label>
        <DropdownSelect options={tags} selectedTags={selectedTags} setSelectedTags={setSelectedTags} />
      </Form.Group>
      <div className="d-dlex flex-col">
        <Row>
          <Col>
            <div className="text-start">
              {initialWorkspace ? (
                loadingBtn && loadingBtn.delete ? (
                  <button className="btn btn-danger" type="button" disabled>
                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    &nbsp;{t(TranslationKeys.WORKSPACEFORM_LOADING)}
                  </button>
                ) : (
                  <Button
                    variant="danger"
                    type="button"
                    onClick={handleDelete}
                    disabled={initialWorkspace?.creator?.id !== userId}
                  >
                    {t(TranslationKeys.WORKSPACEFORM_DELETE)}
                  </Button>
                )
              ) : null}
            </div>
          </Col>
          <Col>
            <div className="text-end">
              {loadingBtn && (loadingBtn.update || loadingBtn.create || loadingBtn.tags) ? (
                <button className="btn btn-primary" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.WORKSPACEFORM_LOADING)}
                </button>
              ) : (
                <Button className="button" variant="primary" type="submit">
                  {initialWorkspace ? t(TranslationKeys.WORKSPACEFORM_UPDATE) : t(TranslationKeys.WORKSPACEFORM_CREATE)}
                </Button>
              )}
            </div>
          </Col>
        </Row>
      </div>
      <Modal
        show={openDeleteConfirmation}
        onHide={() => setOpenDeleteConfirmation(false)}
        backdrop="static"
        size="lg"
        centered
        className="text-light custom-modal-backdrop"
      >
        <Modal.Header
          style={{
            fontWeight: "bold",
          }}
        >
          {t(TranslationKeys.WORKSPACEFORM_DELETEWORKSPACETITLE)}
        </Modal.Header>
        <Modal.Body>
          <DeleteWorkSpace
            workspace={initialWorkspace}
            handleClose={handleClose}
            updateTrigger={updateTrigger}
            handleWorkspaceClose={() => setOpenDeleteConfirmation(false)}
          />
        </Modal.Body>
      </Modal>
    </Form>
  );
}

export default WorkspaceForm;
