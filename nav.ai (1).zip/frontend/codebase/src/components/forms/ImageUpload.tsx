import * as React from "react";

import { Card } from "react-bootstrap";

import { useNotification } from "../general/NotificationProvider";

interface Props {
  // base64 encoded image
  value: string | undefined;
  maxSizeInBytes: number | undefined;
  onUpload: (base64Image: string) => void;
  onError: (error: Error) => void;
  onDelete?: () => void;
  width?: string;
  height?: string;
  variant?: "circle" | "rounded" | "rect";
}

export default function ImageUpload({
  height = "18em",
  maxSizeInBytes,
  onDelete,
  onError,
  onUpload,
  value,
  variant = "rounded",
  width = "18em",
}: Props) {
  const allowedTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
    "image/bmp",
    "image/webp",
    "image/svg+xml",
  ];
  const inputRef = React.useRef<HTMLInputElement>(null);
  const { openErrorNotification } = useNotification();

  const triggerFileInput = () => {
    inputRef.current?.click();
  };

  const onImageUpload = () => {
    if (inputRef.current?.files) {
      const file = inputRef.current.files[0];
      try {
        if (file) {
          // List of allowed MIME types for image files
          if (!allowedTypes.includes(file.type)) {
            openErrorNotification(
              `Only the following types are allowed: ${allowedTypes
                .map((value) => value.replace("image/", ""))
                .join(", ")}`
            );
            return;
          }

          if (maxSizeInBytes && file.size > maxSizeInBytes) {
            openErrorNotification(`File size must be less than ${maxSizeInBytes / 1024 / 1024} MB.`);
            return;
          }

          const reader = new FileReader();
          reader.onloadend = () => {
            onUpload(reader.result as string);
          };
          reader.readAsDataURL(file);
        }
      } catch (error) {
        onError(error as Error);
      } finally {
        // Reset the input value using the ref
        if (inputRef.current) {
          inputRef.current.value = "";
        }
      }
    }
  };

  return (
    <Card
      style={{ height, overflow: "hidden", width }}
      className={variant === "circle" ? "rounded-circle" : variant === "rect" ? "rounded-0" : "rounded-3"}
    >
      <div className="position-relative overflow-hidden">
        {/* Displayed image */}
        <div className="ratio ratio-1x1">
          {value ? (
            <img src={value} alt="Displayed content" className="w-100 h-100" style={{ objectFit: "cover" }} />
          ) : (
            <div className="w-100 h-100 bg-light" />
          )}
        </div>

        {value ? (
          <div
            className="position-absolute bottom-0 start-50 translate-middle-x d-flex gap-2 py-1 px-2 mb-2"
            style={{
              backgroundColor: "rgba(0,0,0,0.8)",
              borderRadius: "12px",
              boxShadow: "0 2px 4px rgba(0,0,0,0.2)",
            }}
          >
            <i
              className="bi bi-pencil-fill text-white align-icon-middle"
              style={{ cursor: "pointer", transition: "transform 0.2s" }}
              onClick={triggerFileInput}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = "scale(1.2)";
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = "scale(1)";
              }}
            />

            <div className="vr bg-white opacity-75"></div>

            <i
              className="bi bi-trash-fill text-danger align-icon-middle"
              style={{ cursor: "pointer", transition: "transform 0.2s" }}
              onClick={onDelete}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = "scale(1.2)";
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = "scale(1)";
              }}
            />
          </div>
        ) : (
          <div
            style={{
              cursor: "pointer",
              paddingLeft: "0.1rem",
              paddingTop: "0.3rem",
            }}
            className="position-absolute top-0 start-0 end-0 bottom-0 
          bg-opacity-50 d-flex align-items-center justify-content-around 
          fw-bold rounded"
            onClick={triggerFileInput}
          >
            <i className="bi bi-file-earmark-arrow-up fs-1"></i>
          </div>
        )}
        <input
          ref={inputRef}
          type="file"
          accept={allowedTypes.map((value) => value.replace("image/", ".")).join(", ")}
          onChange={() => onImageUpload()}
          style={{ display: "none" }}
        />
      </div>
    </Card>
  );
}
