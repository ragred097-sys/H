import { useEffect, useState } from "react";

import { Button, Col, Container, Form, ListGroup, Modal, Row, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AssetForm, Assistant, SystemInstruction } from "../../lib/Model";
import { assetFormStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { sortArrayOfObjs } from "../../utils/arrayUtils";
import { templatePrefix } from "../../utils/constants";
import ListSkeleton from "../general/ListSkeleton";
import { useNotification } from "../general/NotificationProvider";
import { SystemInstructionService } from "./../../services/SystemInstructionService";
import { CreateSystemPromptForm } from "./CreateSystemPromptForm";

const toolPrefix = window.ENV?.VITE_APP_TOOLS_PREFIX || import.meta.env.VITE_APP_TOOLS_PREFIX || "Nav.AI Tool - ";

export const SystemPromptForm = ({
  handleClose,
  initialData,
  onUpdateAssetForm,
}: {
  handleClose?: (systemPrompts?: SystemInstruction[]) => void;
  initialData?: Assistant;
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: unknown;
    }[],
    assetForm: AssetForm
  ) => void;
}) => {
  const { t } = useTranslation();
  const assetForm = assetFormStore((state) => state);
  const [prompts, setPrompts] = useState<SystemInstruction[]>();
  const [selectedPrompt, setSelectedPrompt] = useState<SystemInstruction>();
  const [newPromptModal, setNewPromptModal] = useState(false);
  const [pickedPrompts, setPickedPrompts] = useState<SystemInstruction[]>([]);
  const [loading, setLoading] = useState(false);
  const { openErrorNotification } = useNotification();

  useEffect(() => {
    setLoading(true);
    SystemInstructionService.getSystemInstructions()
      .then((res) => {
        setLoading(false);
        const filteredInstructions = res.filter(
          (el) => !el.name.includes(toolPrefix) && !el.name.includes(templatePrefix)
        );
        const sortedRes = sortArrayOfObjs(filteredInstructions, "name");

        setPrompts(sortedRes);

        if (assetForm?.systemPrompts?.length) {
          const matchingInstructions = filteredInstructions.filter((item) =>
            assetForm.systemPrompts!.some((sp) => sp.id === item.id)
          );
          setPickedPrompts(matchingInstructions);
        }
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETSYSTEMINSTRUCTIONS), err as Error);
        setLoading(false);
      });
  }, []);

  const handlePickPrompts = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pickedItem = prompts?.find((el) => el.id === e.target.value);
    if (pickedItem) {
      setPickedPrompts((prev = []) => {
        if (prev.some((item) => item.id === pickedItem.id)) {
          return prev.filter((el) => el.id !== pickedItem.id);
        } else {
          return [...prev, pickedItem];
        }
      });
    }
  };

  const handlePromptSelect = (id: string) => {
    const selectedPrompt = prompts?.find((el) => el.id === id);
    if (selectedPrompt) {
      setSelectedPrompt(selectedPrompt);
    }
  };

  const PromptDetails = ({ selectedPrompt }: { selectedPrompt: SystemInstruction }) => {
    if (selectedPrompt) {
      return (
        <div key={selectedPrompt.id}>
          <p className="fw-bold">{t(TranslationKeys.SYSTEMPROMPTFORM_DESCRIPTION)}</p>
          <p>{selectedPrompt.description}</p>
          <p className="fw-bold">{t(TranslationKeys.SYSTEMPROMPTFORM_PROMPT)}</p>
          <p>{selectedPrompt.message}</p>
        </div>
      );
    }
    return null;
  };

  const handleSelect = () => {
    assetForm.setField("systemPrompts", pickedPrompts);
    if (initialData && onUpdateAssetForm) {
      onUpdateAssetForm([{ fieldName: "systemPrompts", value: pickedPrompts }], assetForm);
    }
    if (handleClose) handleClose(pickedPrompts);
  };

  const handleNewPromptCreated = (newPrompts?: SystemInstruction[]) => {
    if (newPrompts?.length) {
      setPickedPrompts((prev) => [...prev, ...newPrompts]);
      setNewPromptModal(false);
      // Reload the prompts list
      setLoading(true);
      SystemInstructionService.getSystemInstructions()
        .then((res) => {
          setLoading(false);
          const filteredInstructions = res.filter((el) => !el.name.includes(toolPrefix));
          const sortedRes = sortArrayOfObjs(filteredInstructions, "name");
          setPrompts(sortedRes);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETSYSTEMINSTRUCTIONS), err as Error);
          setLoading(false);
        });
    }
  };

  return (
    <>
      <Container fluid className="d-flex flex-column h-100">
        <h4 className="mt-4 d-flex align-items-center mb-4">
          <p className="m-0">{t(TranslationKeys.SYSTEMPROMPTFORM_EXISTINGPROMPTS)}</p>
          <Button
            onClick={() => setNewPromptModal(true)}
            className="ms-3 d-flex align-items-center"
            variant="secondary"
            size="sm"
          >
            <i className="bi bi-plus-lg"></i>
          </Button>
        </h4>

        <Row className="flex-grow-1">
          <Col xs={4} className="overflow-auto me-2" style={{ height: "50vh" }}>
            <div>
              {loading ? (
                <ListSkeleton length={15} />
              ) : (
                <ListGroup>
                  {prompts?.map((prompt) => (
                    <div className="d-flex flex-row" key={prompt.id}>
                      <Form className="pt-1 pe-2">
                        <Form.Check
                          type="checkbox"
                          value={prompt.id}
                          checked={pickedPrompts.some((item) => item.id === prompt.id)}
                          onChange={handlePickPrompts}
                        />
                      </Form>
                      <Button
                        key={prompt.id}
                        value={prompt.id}
                        variant={
                          getComputedStyle(document.documentElement).getPropertyValue("--theme-color") === "dark"
                            ? "outline-light"
                            : "light"
                        }
                        className={`mb-2 navai-button w-75 ${selectedPrompt?.id === prompt.id ? "active" : ""}`}
                        style={{
                          borderRadius: "var(--bs-border-radius)",
                          wordWrap: "break-word",
                        }}
                        size="sm"
                        onClick={() => handlePromptSelect(prompt.id)}
                      >
                        {prompt.name}
                      </Button>
                    </div>
                  ))}
                </ListGroup>
              )}
            </div>
          </Col>
          <Col className="overflow-auto navai-button pt-2 pb-3 ps-3 pe-3" style={{ height: "50vh" }}>
            <div className="h-100 d-flex flex-column">
              <div className="flex-grow-1 overflow-auto">
                {loading ? (
                  <div className="w-100 h-50 d-flex justify-content-center align-items-center">
                    <Spinner animation="border" role="status">
                      <span className="visually-hidden">{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}</span>
                    </Spinner>
                  </div>
                ) : (
                  <>{selectedPrompt ? <PromptDetails selectedPrompt={selectedPrompt} /> : null}</>
                )}
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <div className="text-end mt-3 pe-3">
        <Button className="button" onClick={handleSelect}>
          {!initialData
            ? t(TranslationKeys.SYSTEMPROMPTFORM_SELECTPROMPTS)
            : t(TranslationKeys.SYSTEMPROMPTFORM_UPDATEPROMPTS)}
        </Button>
      </div>
      <Modal
        show={newPromptModal}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => setNewPromptModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.SYSTEMPROMPTFORM_ADDSYSTEMINSTRUCTION)}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <CreateSystemPromptForm handleClose={handleNewPromptCreated} />
        </Modal.Body>
      </Modal>
    </>
  );
};
