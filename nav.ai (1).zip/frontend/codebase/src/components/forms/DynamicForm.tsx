import React, { useEffect, useMemo, useRef, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button, Form } from "react-bootstrap";
import { Menu, MenuItem, Typeahead, TypeaheadRef } from "react-bootstrap-typeahead";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { DocumentType, Module, ModuleCapabilities, ModuleSpecification } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { translateParamOrThrow } from "../../utils/translationUtils";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import { ModuleService } from "./../../services/ModuleService";

type DynamicFormProps = {
  providers: ModuleSpecification[];
  defaultValues?: Module;
  handleClose: () => void;
  updateTrigger?: (data?: Module) => void;
};

export const DynamicForm: React.FC<DynamicFormProps> = ({ defaultValues, handleClose, providers, updateTrigger }) => {
  const [selectedProviderId, setSelectedProviderId] = useState<string | undefined>();
  const [loading, setLoading] = useState({
    createUpdate: false,
    delete: false,
  });

  const [selectedInputs, setSelectedInputs] = useState<DocumentType[]>([]);
  const [funcToolDesc, setFuncToolDesc] = useState<string>("");
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const typeaheadRef = useRef<TypeaheadRef>(null);
  const supportedInputOptions = Object.values(DocumentType);
  const YesNoUnknownRadioGroup = ({
    name,
    onChange,
    value,
  }: {
    name: string;
    value: "yes" | "no" | "unknown";
    onChange: (val: "yes" | "no" | "unknown") => void;
  }) => (
    <>
      <div className="mb-1">
        {t(translateParamOrThrow(name, "REGISTRYFORM_CAPABILITIES_"), { defaultValue: `${name}` })}
      </div>
      <div className="d-flex gap-3">
        {["yes", "no", "unknown"].map((val) => (
          <Form.Check
            key={val}
            inline
            type="radio"
            label={val.charAt(0).toUpperCase() + val.slice(1)}
            name={`capability-${name}`}
            id={`${name}-${val}`}
            checked={value === val}
            onChange={() => onChange(val as "yes" | "no" | "unknown")}
          />
        ))}
      </div>
    </>
  );
  // Auto-select the provider if one matches the defaultValues
  useEffect(() => {
    if (!selectedProviderId && defaultValues) {
      const match = providers.find((prov) => prov?.id === defaultValues?.specId);
      if (match) setSelectedProviderId(match.id);
      setFuncToolDesc(defaultValues.description || "");
    }
  }, [defaultValues, providers, selectedProviderId]);

  const selectedProvider = useMemo(
    () => providers.find((p) => p.id === selectedProviderId),
    [providers, selectedProviderId]
  );
  const [capabilityStates, setCapabilityStates] = useState<Record<string, "yes" | "no" | "unknown">>({});

  const schema = useMemo(() => {
    const shape: Record<string, z.ZodTypeAny> = {
      moduleName: z
        .string({
          required_error: t(TranslationKeys.REGISTRYFORM_REQUIREDMODULENAMEFIELD),
        })
        .trim()
        .min(1, t(TranslationKeys.REGISTRYFORM_REQUIREDMODULENAMEFIELD)),
    };

    selectedProvider?.parameters?.forEach((param) => {
      const required = !param.optional;
      const baseType = z.string().trim();
      const label = t(translateParamOrThrow(param.name, "REGISTRYFORM_LABELS_"), { defaultValue: `${param.label}` });

      shape[param.name] = required
        ? baseType.min(1, t(TranslationKeys.REGISTRYFORM_REQUIREDBASEURLFIELD, { field: label }))
        : baseType.optional();
    });

    return z.object(shape);
  }, [selectedProvider]);

  const {
    formState: { errors },
    handleSubmit,
    register,
    reset,
  } = useForm({
    mode: "onChange",
    resolver: zodResolver(schema),
  });

  useEffect(() => {
    if (!selectedProvider && !defaultValues) return;

    const defaults = (selectedProvider?.parameters || []).reduce(
      (acc, param) => {
        const matchingDefault = defaultValues?.parameters?.find((p) => p.name === param.name);

        acc[param.name] = matchingDefault?.value ?? param?.value ?? `${param.default || ""}` ?? "";

        return acc;
      },
      {} as Record<string, string>
    );
    if (defaultValues?.name) {
      defaults.moduleName = defaultValues.name;
    }

    reset(defaults);
  }, [selectedProvider, reset, defaultValues]);

  const onSubmit = async (data: Record<string, string>) => {
    const { moduleName, ...parameters } = data;

    // @ts-expect-error types are garbage
    const payload: Module = defaultValues
      ? {
          capabilities: Object.entries(capabilityStates)
            .filter(([_, val]) => val !== "unknown")
            .map(([name, val]) => ({
              name,
              value: val === "yes",
            })),
          description:
            selectedProvider?.type === "FUNCTION_TOOL"
              ? funcToolDesc
              : defaultValues && defaultValues.description
                ? defaultValues.description
                : "",
          id: defaultValues.id,
          name: moduleName,
          parameters: Object.entries(parameters).map(([name, value]) => ({
            name,
            value,
          })),
          specId: selectedProviderId,
          supportedInputs: selectedInputs || [],
        }
      : {
          capabilities: Object.entries(capabilityStates)
            .filter(([_, val]) => val !== "unknown")
            .map(([name, val]) => ({
              name,
              value: val === "yes",
            })),
          description: funcToolDesc ? funcToolDesc : "",
          name: moduleName,
          parameters: Object.entries(parameters).map(([name, value]) => ({
            name,
            value,
          })),
          specId: selectedProviderId,
          supportedInputs: selectedInputs || [],
        };

    try {
      setLoading((prevState) => ({ ...prevState, createUpdate: true }));
      const response = defaultValues
        ? await ModuleService.updateModule(payload)
        : await ModuleService.createModule(payload);

      if (response.id) {
        handleClose();
        updateTrigger?.(response);
      }
    } catch (error) {
      openErrorNotification(
        defaultValues ? t(TranslationKeys.ERRORMESSAGES_UPDATEMODULE) : t(TranslationKeys.ERRORMESSAGES_CREATEMODULE),
        error as Error
      );
    } finally {
      setLoading((prevState) => ({ ...prevState, createUpdate: false }));
    }
  };

  const handleDelete = async () => {
    if (defaultValues) {
      setLoading((prevState) => ({ ...prevState, delete: true }));

      await ModuleService.deleteModule(defaultValues)
        .then(() => {
          updateTrigger!();
        })
        .catch((err) => openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETEMODULE), err as Error))
        .finally(() => {
          handleClose();
          setLoading((prevState) => ({ ...prevState, delete: false }));
        });
    }
  };

  useEffect(() => {
    const selectedFromApi = defaultValues?.capabilities || [];
    const states: Record<string, "yes" | "no" | "unknown"> = {};
    selectedProvider?.capabilities?.forEach((cap) => {
      const match = selectedFromApi.find((c) => c.name === cap.name);
      if (match) {
        states[cap.name] = match.value ? "yes" : "no";
      } else {
        states[cap.name] = "unknown";
      }
    });

    setCapabilityStates(states);
    setSelectedInputs((defaultValues?.supportedInputs as DocumentType[]) || []);
  }, [defaultValues, selectedProvider]);

  return (
    <Form onSubmit={handleSubmit(onSubmit)} noValidate>
      {!defaultValues && (
        <Form.Group className="mb-3" controlId="providerSelect">
          <Form.Label>{t(TranslationKeys.REGISTRYFORM_SELECTPROVIDER)}</Form.Label>
          <Form.Select value={selectedProviderId || ""} onChange={(e) => setSelectedProviderId(e.target.value)}>
            <option value="" disabled>
              {t(TranslationKeys.REGISTRYFORM_SELECTPROVIDERPLACEHOLDER)}
            </option>
            {providers.map((prov) => (
              <option key={prov.id} value={prov.id}>
                {prov.name}
              </option>
            ))}
          </Form.Select>
        </Form.Group>
      )}

      <Form.Group className="mb-3" controlId="modelSpec">
        <Form.Label>{t(TranslationKeys.REGISTRYFORM_MODELSPECIDLABEL)}</Form.Label>
        <Form.Control
          type="text"
          readOnly
          className="text-muted"
          value={defaultValues?.specId || selectedProviderId || ""}
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="moduleName">
        <RequiredLabel label={t(TranslationKeys.REGISTRYFORM_MODULENAMELABEL)} />
        <Form.Control
          type="text"
          placeholder={t(TranslationKeys.REGISTRYFORM_MODULENAMEPLACEHOLDER)}
          {...register("moduleName")}
          isInvalid={!!errors.moduleName}
        />
        <Form.Control.Feedback type="invalid">{errors.moduleName?.message?.toString()}</Form.Control.Feedback>
      </Form.Group>

      {selectedProvider?.parameters?.map((param) => (
        <Form.Group key={param.name} className="mb-3" controlId={param.name}>
          {param.optional ? (
            <Form.Label>
              {t(translateParamOrThrow(param.name, "REGISTRYFORM_LABELS_"), { defaultValue: `${param.label}` })}
            </Form.Label>
          ) : (
            <RequiredLabel
              label={t(translateParamOrThrow(param.name, "REGISTRYFORM_LABELS_"), { defaultValue: `${param.label}` })}
            />
          )}
          <Form.Control
            type="text"
            placeholder={t(translateParamOrThrow(param.name, "REGISTRYFORM_DESCRIPTION_"), {
              defaultValue: `${param.description}`,
            })}
            {...register(param.name)}
            isInvalid={!!errors[param.name]}
          />
          <Form.Control.Feedback type="invalid">{errors[param.name]?.message?.toString()}</Form.Control.Feedback>
        </Form.Group>
      ))}

      {selectedProvider && selectedProvider.type == "FUNCTION_TOOL" && (
        <Form.Group className="mb-3" controlId="description">
          <Form.Label>{t(TranslationKeys.MESSAGES_DESCRIPTION)}</Form.Label>
          <Form.Control
            type="text"
            value={funcToolDesc}
            onChange={(e) => setFuncToolDesc(e.target.value)}
            placeholder={t(TranslationKeys.MESSAGES_DESCRIPTION)}
          />
        </Form.Group>
      )}

      {selectedProvider && selectedProvider.capabilities && selectedProvider.capabilities.length > 0 && (
        <>
          <Form.Label>{t(TranslationKeys.REGISTRYFORM_CAPABILITIES_CAPABILITIES)}</Form.Label>
          <Form.Group className="mb-3" controlId="modelSpec">
            <Typeahead
              id="capabilities-multiselect"
              labelKey={
                (option: any) =>
                  t(translateParamOrThrow(option.name, "REGISTRYFORM_CAPABILITIES_"), {
                    defaultValue: `${option.name}`,
                  })
                // option.label
              }
              multiple
              options={selectedProvider.capabilities}
              selected={selectedProvider.capabilities.filter((cap) => capabilityStates[cap.name] !== "unknown")}
              onChange={(selectedOptions) => {
                const updatedStates: Record<string, "yes" | "no" | "unknown"> = { ...capabilityStates };

                selectedProvider.capabilities?.forEach((cap) => {
                  const isSelected = selectedOptions.find((opt) => (opt as ModuleCapabilities).name === cap.name);
                  updatedStates[cap.name] = isSelected ? (capabilityStates[cap.name] ?? "yes") : "unknown"; // ✅ Reset to unknown if removed
                });

                setCapabilityStates(updatedStates);
              }}
              ref={typeaheadRef}
              filterBy={() => true}
              renderMenu={(results, menuProps) => (
                <Menu {...menuProps}>
                  {(results as typeof selectedProvider.capabilities).map((result, index) => (
                    <MenuItem
                      key={index}
                      option={result}
                      position={index}
                      className="d-flex flex-column align-items-start"
                    >
                      <YesNoUnknownRadioGroup
                        name={result.name}
                        value={capabilityStates[result.name] || "unknown"}
                        onChange={(val) => {
                          setCapabilityStates((prev) => ({
                            ...prev,
                            [result.name]: val,
                          }));
                        }}
                      />
                    </MenuItem>
                  ))}
                </Menu>
              )}
              placeholder={t(TranslationKeys.REGISTRYFORM_SELECTCAPABILITIES)}
            />
          </Form.Group>
        </>
      )}

      {selectedProvider &&
        selectedProvider.type !== "FUNCTION_TOOL" &&
        supportedInputOptions &&
        supportedInputOptions.length > 0 && (
          <>
            <Form.Label>Supported Inputs</Form.Label>
            <Form.Group className="mb-3" controlId="modelSpec">
              <Typeahead
                className="mb-3"
                id="inputs-multiselect"
                multiple
                options={supportedInputOptions}
                selected={selectedInputs}
                onChange={(selectedOptions) => {
                  setSelectedInputs(selectedOptions as DocumentType[]);
                }}
                ref={typeaheadRef}
                filterBy={() => true}
                renderMenu={(results, menuProps, _state) => (
                  <Menu {...menuProps}>
                    {(results as DocumentType[]).map((result, index) => (
                      <MenuItem
                        key={index}
                        option={result}
                        position={index}
                        className="d-flex align-items-center"
                        onClick={() => {
                          const isSelected = selectedInputs.some((item) => item === result);
                          if (isSelected) {
                            setSelectedInputs(selectedInputs.filter((item) => item !== result));
                          } else {
                            setSelectedInputs([...selectedInputs, result]);
                          }
                        }}
                      >
                        <>
                          <input
                            type="checkbox"
                            checked={selectedInputs.some((item) => item === result)}
                            readOnly
                            className="me-2"
                          />
                        </>
                        {result}
                      </MenuItem>
                    ))}
                  </Menu>
                )}
                placeholder={"select supported inputs"}
              />
            </Form.Group>
          </>
        )}

      <div className="d-flex justify-content-end pt-2">
        {defaultValues ? (
          loading && loading?.delete ? (
            <LoadingButton className={"btn btn-danger me-4"} />
          ) : (
            <Button variant="danger" type="button" onClick={handleDelete} className="me-2">
              {t(TranslationKeys.REGISTRYFORM_DELETEBUTTON, { name: `${defaultValues?.name}` })}
            </Button>
          )
        ) : null}

        {loading && loading?.createUpdate ? (
          <LoadingButton className={"btn btn-primary"} />
        ) : (
          <Button variant="primary" type="submit" className="button" disabled={!selectedProviderId}>
            {defaultValues ? (
              <>{t(TranslationKeys.REGISTRYFORM_UPDATEBUTTON, { name: `${defaultValues.name}` })}</>
            ) : (
              <>{t(TranslationKeys.REGISTRYFORM_CREATEBUTTON)}</>
            )}
          </Button>
        )}
      </div>
    </Form>
  );
};
