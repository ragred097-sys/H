import { useEffect, useState } from "react";

import { Button, Col, Container, Dropdown, Form, ListGroup, Modal, Row, Spinner, Tab, Tabs } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AssetForm, Assistant, SystemInstruction, TypeName, User } from "../../lib/Model";
import { assetFormStore, authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { sortArrayOfObjs } from "../../utils/arrayUtils";
import { templatePrefix, toolPrefix } from "../../utils/constants";
import AgentDetail from "../general/AgentDetail";
import ListSkeleton from "../general/ListSkeleton";
import { useNotification } from "../general/NotificationProvider";
import { AccessControlService } from "./../../services/AccessControlService";
import { SystemInstructionService } from "./../../services/SystemInstructionService";
import { UserService } from "./../../services/UserService";
import { ShareForm } from "./ShareForm";
import { ToolFormComponent } from "./ToolFormComponent";

export const ToolForm = ({
  handleClose,
  initialData,
  onUpdateAssetForm,
}: {
  handleClose: () => void;
  initialData?: Assistant | SystemInstruction;
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: string | number | boolean | SystemInstruction[];
    }[],
    assetForm: AssetForm
  ) => void;
  updateTrigger?: () => void;
}) => {
  const { t } = useTranslation();
  const userId = authStore((state) => state.user?.id);
  const assetForm = assetFormStore((state) => state);
  const [users, setUsers] = useState<User[]>([]);
  const [prompts, setPrompts] = useState<SystemInstruction[]>();
  const [selectedPrompt, setSelectedPrompt] = useState<SystemInstruction>();
  const [newPromptModal, setNewPromptModal] = useState(false);
  const [pickedPrompts, setPickedPrompts] = useState<SystemInstruction[]>([]);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<SystemInstruction[]>([]);
  const { openErrorNotification } = useNotification();
  const [newlyCreatedTool, setNewlyCreatedTool] = useState<SystemInstruction | null>(null);
  const [loadedTabs, setLoadedTabs] = useState({
    navAiTemplates: false,
    navAiTools: true,
  });
  const [loadingList, setLoadingList] = useState({
    myTemplateList: false,
    sharedTemplateList: false,
  });
  const [activeTab, setActiveTab] = useState(Object.entries(loadedTabs).find(([, isLoaded]) => isLoaded)?.[0]);
  const [myTemplates, setMyTemplates] = useState<SystemInstruction[]>([]);
  const [sharedTemplates, setSharedTemplates] = useState<SystemInstruction[]>([]);
  const [showSharing, setShowSharing] = useState(false);
  const [showDetail, setShowDetail] = useState(false);

  useEffect(() => {
    setLoading(true);
    const prefix = activeTab == "navAiTools" ? toolPrefix : templatePrefix;
    SystemInstructionService.getSystemInstructions()
      .then((res) => {
        setData(res);
        setLoading(false);
        const filteredInstructions = res.filter((el) => el.name.startsWith(prefix));
        const sortedInstructions = sortArrayOfObjs(filteredInstructions, "name");
        setPrompts(sortedInstructions);

        if (initialData && initialData.__type_name === TypeName.SystemInstruction) {
          setSelectedPrompt(initialData as SystemInstruction);
        }
        getSharedPrompts(sortedInstructions);
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETTOOLS), err as Error);
        setLoading(false);
      });
  }, [activeTab]);

  useEffect(() => {
    if (data.length && assetForm && "tools" in assetForm) {
      const filteredInstructions = data.filter(
        (el) => el.name.startsWith(toolPrefix) || el.name.startsWith(templatePrefix)
      );
      const matchingTools = filteredInstructions.filter((item) => assetForm.tools!.some((tool) => tool.id === item.id));
      setPickedPrompts(matchingTools);
    }
  }, [data.length, assetForm.tools?.length]);

  useEffect(() => {
    if (newlyCreatedTool) {
      reload();
      setNewlyCreatedTool(null);
    }
  }, [newlyCreatedTool]);

  useEffect(() => {
    UserService.getUsers()
      .then((res) => {
        setUsers(res);
      })
      .catch((err) => console.log(err));
  }, []);

  const getSharedPrompts = async (sortedRes: SystemInstruction[]) => {
    setLoadingList((prevState) => ({ ...prevState, myTemplateList: true }));
    setLoadingList((prevState) => ({
      ...prevState,
      sharedTemplateList: true,
    }));
    if (userId) {
      const myTemplates = await Promise.all(
        sortedRes
          .filter((systemInstruction) => systemInstruction.creator.id === userId)
          .map(async (systemInstruction) => {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const grants = await AccessControlService.getGrants(systemInstruction as any); // Fetch grants

            // Get "Shared With" users
            const sharedWithIds = grants
              .filter((grant) => grant.assigneeType === TypeName.User)
              .map((grant) => grant.assigneeId);

            const sharedWithUsers = users?.filter((user) => sharedWithIds.includes(user.id)).map((user) => user.name);

            return {
              ...systemInstruction,
              sharedWithUsers,
            };
          })
      );
      // Process "Shared datasources"
      const sharedTemplate = await Promise.all(
        sortedRes
          .filter((systemInstruction) => systemInstruction.creator.id !== userId)
          .map((systemInstruction) => {
            // Get "Shared By" user
            const sharedBy = systemInstruction.creator.name;
            return {
              ...systemInstruction,
              sharedBy, // Attach sharedBy to sharedDatasets
            };
          })
      );
      setMyTemplates(myTemplates);
      setSharedTemplates(sharedTemplate);
      setLoadingList((prevState) => ({
        ...prevState,
        myTemplateList: false,
      }));
      setLoadingList((prevState) => ({
        ...prevState,
        sharedTemplateList: false,
      }));
    }
  };

  const handleSelectTab = (key: string | null) => {
    if (key) {
      setActiveTab(key);
      setLoadedTabs((prev) => ({ ...prev, [key]: true }));
    }
  };

  const reload = () => {
    setLoading(true);
    SystemInstructionService.getSystemInstructions()
      .then((res) => {
        setLoading(false);
        const filteredInstructions = res.filter((el) =>
          el.name.startsWith(activeTab == "navAiTools" ? toolPrefix : templatePrefix)
        );
        const sortedInstructions = sortArrayOfObjs(filteredInstructions, "name");
        setPrompts(sortedInstructions);
        getSharedPrompts(sortedInstructions);
        if (selectedPrompt) {
          const selectedPromptObj = sortedInstructions.find((item) => selectedPrompt.id === item.id);
          if (selectedPromptObj) {
            setSelectedPrompt(selectedPromptObj);
          }
        }
      })
      .catch((err) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETTOOLS), err as Error);
        setLoading(false);
      });
  };

  const handlePromptSelect = (id: string) => {
    const selectedPrompt = prompts?.find((el) => el.id === id);
    if (selectedPrompt) {
      setSelectedPrompt(selectedPrompt);
    }
  };

  const handleSelect = () => {
    assetForm.setField("tools", pickedPrompts);
    if (initialData && onUpdateAssetForm) {
      onUpdateAssetForm([{ fieldName: "tools", value: pickedPrompts ?? [] }], assetForm);
    }
    handleClose();
  };

  const handlePickPrompts = (e: React.ChangeEvent<HTMLInputElement>) => {
    const pickedItem = prompts?.find((el) => el.id === e.target.value);
    if (pickedItem) {
      setPickedPrompts((prev = []) => {
        if (prev.some((item) => item.id === pickedItem.id)) {
          return prev.filter((el) => el.id !== pickedItem.id);
        } else {
          return [...prev, pickedItem];
        }
      });
    }
  };

  const handleToolCreated = (tool?: SystemInstruction) => {
    if (tool) {
      setNewlyCreatedTool(tool);
      setPickedPrompts((prev) => [...prev, tool]);
      setSelectedPrompt(tool);
    }
    reload();
    setNewPromptModal(false);
  };

  const handleInfo = (tool: SystemInstruction) => {
    setSelectedPrompt(tool);
    setShowDetail(true); // to be changed
  };

  const handleSharing = (tool: SystemInstruction) => {
    setSelectedPrompt(tool);
    setShowSharing(true);
  };

  const handleCloseInfoModal = () => {
    setShowDetail(false);
  };

  const openShareForm = (data: boolean) => {
    setShowSharing(data);
  };

  const handleEdit = (tool: SystemInstruction) => {
    setNewPromptModal(true);
    setSelectedPrompt(tool);
    reload();
  };

  const PromptDetails = ({ selectedPrompt }: { selectedPrompt: SystemInstruction }) => {
    if (selectedPrompt) {
      return (
        <div key={selectedPrompt.id}>
          <p className="fw-bold">{t(TranslationKeys.TOOLFORM_DESCRIPTION)}</p>
          <p>{selectedPrompt.description}</p>
          <p className="fw-bold">{t(TranslationKeys.TOOLFORM_PROMPT)}</p>
          <pre
            style={{
              fontFamily: "Courier, monospace",
              whiteSpace: "pre-wrap",
            }}
          >
            {selectedPrompt.message}
          </pre>
        </div>
      );
    }
    return null;
  };

  const renderTemplates = (receivedTemplates: SystemInstruction[]) => {
    return (
      <div className="position-relative w-100">
        <ListGroup className="d-flex w-100" style={{ paddingRight: "1em" }}>
          {receivedTemplates?.map((template) => (
            <div className="d-flex w-100" key={template.id} style={{ minWidth: 0 }}>
              <Form className="pt-2 pe-2 ps-2">
                <Form.Check
                  type="checkbox"
                  value={template.id}
                  checked={pickedPrompts.some((ds) => ds.id === template.id)}
                  onChange={handlePickPrompts}
                />
              </Form>
              <div className="flex-grow-1 button-hover" style={{ minWidth: 0 }}>
                <Button
                  value={template.id}
                  variant={
                    getComputedStyle(document.documentElement).getPropertyValue("--theme-color") === "dark"
                      ? "outline-light"
                      : "light"
                  }
                  className={`mb-2 navai-button responsive-button w-100 ${
                    selectedPrompt?.id === template.id ? "active" : ""
                  }`}
                  size="sm"
                  style={{ borderRadius: "var(--bs-border-radius)" }}
                  onClick={() => handlePromptSelect(template.id)}
                >
                  <div className="d-flex justify-content-between align-items-center w-100" style={{ height: "1.5rem" }}>
                    <div
                      className="text-start"
                      style={{
                        flex: 1,
                        minWidth: 0,
                        wordWrap: "break-word",
                      }}
                    >
                      {template.name}
                    </div>
                    <div className="text-end" onClick={(event) => event.stopPropagation()}>
                      <Dropdown align="start" drop="down-centered">
                        <Dropdown.Toggle
                          variant="transparent"
                          id="dropdown-basic"
                          className="no-caret custom-dropdown-toggle px-1 p-0"
                        >
                          <i
                            className="bi bi-three-dots-vertical"
                            style={{
                              color: selectedPrompt?.id === template.id ? "black" : undefined,
                            }}
                          ></i>
                        </Dropdown.Toggle>
                        <Dropdown.Menu>
                          <Dropdown.Item onClick={() => handleInfo(template)}>
                            {t(TranslationKeys.TOOLFORM_INFO)}
                          </Dropdown.Item>
                          {prompts?.some((si) => si.id === template?.id) && (
                            <Dropdown.Item onClick={() => handleEdit(template)}>
                              {t(TranslationKeys.TOOLFORM_EDIT)}
                            </Dropdown.Item>
                          )}
                          {myTemplates?.some((si) => si.id === template?.id) && (
                            <Dropdown.Item onClick={() => handleSharing(template)}>
                              {t(TranslationKeys.TOOLFORM_SHARE)}
                            </Dropdown.Item>
                          )}
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                </Button>
              </div>
            </div>
          ))}
        </ListGroup>
      </div>
    );
  };

  const renderSection = (title: string, data: SystemInstruction[], isLoading: boolean) => {
    return (
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          height: "100%",
          minHeight: 0,
        }}
        className="mb-3"
      >
        {title && (
          <>
            <h4 className="mt-4 d-flex align-items-center mb-4">
              <p className="m-0">{title}</p>
              {title == t(TranslationKeys.TOOLFORM_MYTEMPLATES) && (
                <Button
                  onClick={() => {
                    setNewPromptModal(true);
                    setSelectedPrompt(undefined);
                  }}
                  className="ms-3 d-flex align-items-center"
                  variant="secondary"
                  size="sm"
                >
                  <i className="bi bi-plus-lg"></i>
                </Button>
              )}
            </h4>
          </>
        )}
        <div style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
          {isLoading ? (
            <ListSkeleton length={4} styleInline={{ marginRight: "15px" }} />
          ) : data.length > 0 ? (
            renderTemplates(data)
          ) : (
            title === t(TranslationKeys.TOOLFORM_SHAREDWITHME) && (
              <p>{t(TranslationKeys.TOOLFORM_NOSHAREDTEMPLATES, "No shared templates available")}</p>
            )
          )}
        </div>
      </div>
    );
  };

  return (
    <>
      <Container fluid className="d-flex flex-column h-100">
        <Tabs activeKey={activeTab} onSelect={handleSelectTab} className="mb-3 d-flex">
          <Tab eventKey="navAiTools" title={toolPrefix.replace("- ", "")}>
            <div className="d-flex flex-wrap">
              <Row className="w-100">
                <h4 className="mt-4 d-flex align-items-center mb-4">
                  <p className="m-0">{t(TranslationKeys.TOOLFORM_EXISTINGTOOLS)}</p>
                </h4>
              </Row>
              <Row className="flex-grow-1">
                <Col xs={4} className="overflow-auto" style={{ height: "50vh" }}>
                  <div>
                    {loading ? (
                      <ListSkeleton length={15} />
                    ) : (
                      <ListGroup>
                        {prompts?.map((prompt) => (
                          <div className="d-flex flex-row" key={prompt.id}>
                            <Form className="pt-1 pe-2">
                              <Form.Check
                                type="checkbox"
                                value={prompt.id}
                                checked={pickedPrompts.some((item) => item.id === prompt.id)}
                                onChange={handlePickPrompts}
                              />
                            </Form>
                            <Button
                              key={prompt.id}
                              value={prompt.id}
                              variant={
                                getComputedStyle(document.documentElement).getPropertyValue("--theme-color") == "dark"
                                  ? "outline-light"
                                  : "light"
                              }
                              className={`mb-2 navai-button w-75 ${selectedPrompt?.id === prompt.id ? "active" : ""}`}
                              style={{
                                borderRadius: "var(--bs-border-radius)",
                                wordWrap: "break-word",
                              }}
                              size="sm"
                              onClick={() => handlePromptSelect(prompt.id)}
                            >
                              {prompt.name}
                            </Button>
                          </div>
                        ))}
                      </ListGroup>
                    )}
                  </div>
                </Col>
                <Col className="overflow-auto navai-button pt-2 pb-3 ps-3 pe-3" style={{ height: "50vh" }}>
                  <div className="h-100 d-flex flex-column">
                    <div className="flex-grow-1 overflow-auto">
                      {loading ? (
                        <div className="w-100 h-50 d-flex justify-content-center align-items-center">
                          <Spinner animation="border" role="status">
                            <span className="visually-hidden">{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}</span>
                          </Spinner>
                        </div>
                      ) : (
                        <>{selectedPrompt ? <PromptDetails selectedPrompt={selectedPrompt} /> : null}</>
                      )}
                    </div>
                  </div>
                </Col>
              </Row>
            </div>
          </Tab>

          <Tab eventKey="navAiTemplates" title={templatePrefix.replace("- ", "")}>
            <Container fluid className="d-flex flex-column h-100">
              <Row className="flex-grow-1">
                <Col className="me-2">
                  <div
                    style={{
                      height: "78vh",
                      overflowY: "auto",
                      scrollbarWidth: "none",
                    }}
                  >
                    <div style={{ height: "95%" }}>
                      {loading ? (
                        <ListSkeleton length={15} styleInline={{ marginRight: "15px" }} />
                      ) : (
                        <>
                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              height: "95%",
                            }}
                          >
                            <div style={{ flex: 1, minHeight: 0 }}>
                              {renderSection(
                                t(TranslationKeys.TOOLFORM_MYTEMPLATES, "My Templates"),
                                myTemplates,
                                loadingList.myTemplateList
                              )}
                            </div>
                            <div style={{ flex: 1, minHeight: 0 }}>
                              {renderSection(
                                t(TranslationKeys.TOOLFORM_SHAREDWITHME, "Shared with me"),
                                sharedTemplates,
                                loadingList.sharedTemplateList
                              )}
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </Col>
                <Col className="overflow-auto pb-3 ps-3 pe-3 h-100">
                  <div className="flex-column mt-2">
                    <div
                      style={{
                        border: "0.5px solid grey",
                        borderRadius: "var(--bs-border-radius)",
                        height: "75vh",
                      }}
                    >
                      <div
                        style={{
                          height: "95%",
                          margin: "1em",
                          marginBottom: "1em",
                          marginTop: "1em",
                          overflow: "auto",
                        }}
                      >
                        {loading ? (
                          <div className="w-100 h-50 d-flex justify-content-center align-items-center">
                            <Spinner animation="border" role="status">
                              <span className="visually-hidden">Loading...</span>
                            </Spinner>
                          </div>
                        ) : (
                          <>{selectedPrompt ? <PromptDetails selectedPrompt={selectedPrompt} /> : null}</>
                        )}
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          </Tab>
        </Tabs>
      </Container>
      <div className="text-end mt-3 pe-3">
        <Button className="button" onClick={handleSelect}>
          {!initialData ? t(TranslationKeys.TOOLFORM_SELECTTOOLS) : t(TranslationKeys.TOOLFORM_UPDATETOOLS)}
        </Button>
      </div>
      <Modal
        show={newPromptModal}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => setNewPromptModal(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.TOOLFORM_ADDTOOL)}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <ToolFormComponent initialData={selectedPrompt} toolForm={templatePrefix} onToolCreated={handleToolCreated} />
        </Modal.Body>
      </Modal>

      {/* Sharing Modal */}
      <Modal
        show={showSharing}
        onHide={() => setShowSharing(false)}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop "
      >
        <Modal.Header closeButton>
          {t(TranslationKeys.TOOLFORM_SHAREWITH, {
            name: selectedPrompt?.name,
            type: selectedPrompt?.__type_name,
          })}
        </Modal.Header>
        <Modal.Body>
          <ShareForm
            // @ts-expect-error to be fixed
            data={selectedPrompt}
            openShareForm={openShareForm}
          />
        </Modal.Body>
      </Modal>
      {/* INFO MODAL */}
      <Modal
        show={showDetail}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop semi-fat-modal"
        onHide={handleCloseInfoModal}
      >
        <Modal.Header closeButton>
          <Modal.Title>{selectedPrompt?.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AgentDetail data={selectedPrompt as SystemInstruction} />
        </Modal.Body>
      </Modal>
    </>
  );
};
