import { BaseSyntheticEvent, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button, Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { Cube } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import { TagService } from "./../../services/TagService";

interface CubeFormProps {
  cubeData?: Cube | undefined;
  setIsFormDirty?: React.Dispatch<React.SetStateAction<boolean>>;
  handleClose?: () => void;
  handleUpdate?: () => void;
}
const CubeForm = ({ cubeData, handleClose, handleUpdate }: CubeFormProps) => {
  const { t } = useTranslation();
  const { openErrorNotification, openNotification } = useNotification();
  const [loading, setLoading] = useState(false);

  const cubeSchema = z.object({
    description: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
    name: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
  });

  type CubeSchema = z.infer<typeof cubeSchema>;
  const {
    formState: { errors },
    handleSubmit,
    register,
  } = useForm({
    defaultValues: {
      description: cubeData?.description || "",
      name: cubeData?.name || "",
    },
    mode: "onChange",
    resolver: zodResolver(cubeSchema),
  });
  const submitHandler: SubmitHandler<CubeSchema> = async (data, e?: BaseSyntheticEvent) => {
    e?.preventDefault();
    try {
      setLoading(true);
      if (cubeData?.id) {
        //update cube category
        const payload = {
          ...cubeData,
          description: data?.description,
          name: data?.name,
        };
        const response = await TagService.updateCubeCategory(payload as Cube);
        if (response) openNotification(t(TranslationKeys.MESSAGES_TAGCATEGORYUPDATE), "primary");
      } else {
        const response = await TagService.createCubeCategory(data as Cube);
        if (response) openNotification(t(TranslationKeys.MESSAGES_TAGCATEGORYCREATE), "primary");
      }
      handleUpdate?.();
      handleClose?.();
    } catch (error) {
      if (cubeData?.id) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_TAGCATEGORYUPDATE), error as Error);
      } else {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_TAGCATEGORYCREATE), error as Error);
      }
    } finally {
      setLoading(false);
    }
  };
  return (
    <>
      <Form onSubmit={handleSubmit(submitHandler)} className="pt-2">
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.CUBES_NAME)} />
          <Form.Control id="name" type="text" placeholder="Name" isInvalid={!!errors?.name} {...register("name")} />
          {errors.name && <Form.Control.Feedback type="invalid">{errors.name.message}</Form.Control.Feedback>}
        </Form.Group>
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.CUBES_DESCRIPTION)} />
          <Form.Control
            id="description"
            type="text"
            placeholder="Description"
            isInvalid={!!errors?.description}
            {...register("description")}
          />
          {errors.description && (
            <Form.Control.Feedback type="invalid">{errors.description.message}</Form.Control.Feedback>
          )}
        </Form.Group>
        <div className="text-end me-2">
          {loading ? (
            <LoadingButton className={"btn btn-primary"} />
          ) : (
            <Button variant="primary" type="submit" className="button">
              {cubeData?.id ? t(TranslationKeys.CUBES_UPDATE) : t(TranslationKeys.CUBES_CREATE)}
            </Button>
          )}
        </div>
      </Form>
    </>
  );
};
export default CubeForm;
