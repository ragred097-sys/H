import { BaseSyntheticEvent, useCallback, useEffect, useMemo, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { ReactFlowProvider } from "@xyflow/react";
import { z } from "zod";

import { Button, Col, Form, Modal, Row } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import NewAssetForm from "./AssetForm";
import { AttachmentStorageTable } from "./AttachmentStorage/AttachmentStorageForm";
import { GovernanceForm } from "./GovernanceForm";
import ImageUpload from "./ImageUpload";
import { useAttachmentStorage } from "../../hooks/useAttachmentStorage";
import {
  Agent,
  AgentWorkflow,
  AgentWorkflowAgent,
  AgentWorkflowNode,
  Assistant,
  AssistantGovernanceConfiguration,
  AttachmentStorages,
  PermissionType,
  Tag,
  TypeName,
  Workspace,
} from "../../lib/Model";
import { assetFormStore, authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { AgentDirtyFields, dirtyFieldsDefaultValues, handleAgentDirtyDataTitles } from "../../utils/agentFormFields";
import { MAX_ICON_SIZE, MAX_IMAGE_SIZE } from "../../utils/constants";
import { isEqtyEnabled } from "../../utils/eqty";
import { getPreferenceNameValuePairs, mapStorageDefaults } from "../../utils/objectUtils";
import { processTags, useFilterTags } from "../../utils/tagsHelper";
import AgentWorkflowEditor from "../general/agent-workflow/AgentWorkflowEditor";
import AgentWorkflowEntityPicker from "../general/agent-workflow/AgentWorkflowEntityPicker";
import ConfirmationDialog from "../general/ConfirmationDialog";
import DropdownSelect, { TagOrCustom } from "../general/Dropdown";
import InfoTooltip from "../general/InfoTooltip";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import { UnsavedChanges } from "../general/UnsavedChangesModal";
import { AgentService } from "./../../services/AgentService";
import { AgentWorkflowService } from "./../../services/AgentWorkflowService";
import { ApplicationService } from "./../../services/ApplicationService";
import { AssistantService } from "./../../services/AssistantService";
import { UserService } from "./../../services/UserService";
import { WorkspaceService } from "./../../services/WorkspaceService";

interface AgentWorkflowFormProps {
  show: boolean;
  onHide: () => void;
  workspace?: Workspace;
  initialData?: AgentWorkflow | null;
  handleClose: () => void;
  updateTrigger: () => void;
}

function AgentWorkflowForm({
  handleClose,
  initialData,
  onHide,
  show,
  updateTrigger,
  workspace,
}: AgentWorkflowFormProps) {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const userId = authStore((state) => state.user?.id);

  const [loading, setLoading] = useState({
    buildAgent: false,
    tags: false,
  });
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [showDeleteOrchestratorConfirmation, setShowDeleteOrchestratorConfirmation] = useState(false);
  const [currentOrchestrator, setCurrentOrchestrator] = useState<AgentWorkflowNode | null>(null);
  const [orchestratorAgent, setOrchestratorAgent] = useState<Assistant | Agent | null>(null);
  const [icon, setIcon] = useState<string>("");
  const [image, setImage] = useState<string>("");
  const [isLoadingOrchestratorDetails, setIsLoadingOrchestratorDetails] = useState<boolean>(false);
  const [currentAgents, setCurrentAgents] = useState<AgentWorkflowAgent[]>([]);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showCreateOrchestrator, setShowCreateOrchestrator] = useState<boolean>(false);
  const [isConfirmClose, setIsConfirmClose] = useState(false);
  const [nonFormFieldDirty, setNonFormFieldDirty] = useState<boolean>(false);
  const [isOrchestratorFormDirty, setIsOrchestratorFormDirty] = useState(false);
  const [dirtyFields, setDirtyFields] = useState<AgentDirtyFields>(dirtyFieldsDefaultValues);
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<TagOrCustom[]>((initialData?.tags as Tag[]) || []);
  const assetForm = assetFormStore((state) => state);
  const [defaultAttachmentStorages, setDefaultAttachmentStorages] = useState<AttachmentStorages[]>([]);

  useEffect(() => {
    async function fetchDefaults() {
      try {
        // Fetch application settings and user preferences
        const [appSettings, preferences] = await Promise.all([
          ApplicationService.getApplicationSettings(),
          UserService.getUserPreferences(),
        ]);

        const prefNameValue = getPreferenceNameValuePairs(appSettings, preferences);
        const attachmentStorages = mapStorageDefaults(prefNameValue);
        setDefaultAttachmentStorages(attachmentStorages);
      } catch (err) {
        openErrorNotification(TranslationKeys.ERRORMESSAGES_ERRORAPPSETTINGSANDPREFERENCES);
      }
    }
    fetchDefaults();
  }, []);

  const initialAttachmentStorages = initialData?.attachmentStorages || defaultAttachmentStorages || [];
  const { attachmentStorages, documentTypeConfigs, handleFileStorageChange, handleTypeToggle, setAttachmentStorages } =
    useAttachmentStorage(initialAttachmentStorages, defaultAttachmentStorages);

  // Sync hook state with form defaults (like AgentStorageAttachment)
  useEffect(() => {
    const incomingStorages = initialData?.attachmentStorages ?? defaultAttachmentStorages ?? [];
    setAttachmentStorages(incomingStorages);
  }, [initialData?.attachmentStorages, defaultAttachmentStorages, setAttachmentStorages]);

  const [showGovernanceForm, setShowGovernanceForm] = useState(false);
  const handleCloseGovernance = (governanceConfiguration: AssistantGovernanceConfiguration) => {
    assetForm.setField("governanceConfiguration", governanceConfiguration);
    setShowGovernanceForm(false);
  };

  // Zod Validation Schema for Agent Workflow
  const rootSchema = z.object({
    id: z.string().nonempty(t(TranslationKeys.MESSAGES_ORCHESTRATORREQUIRED)),
    type: z.string().nonempty(t(TranslationKeys.MESSAGES_ORCHESTRATORREQUIRED)),
  });

  const agentSchema = z.object({
    canHandOffTo: z.array(rootSchema).nullable().default(null).optional(),
    id: z.string(),
    type: z.string(),
  });

  const attachmentStorageSchema = z.object({
    fileStorageId: z.string().nullable().optional(),
    type: z.string().nullable().optional(),
  });

  const workflowSchema = z.object({
    agents: z.array(agentSchema).default([]).optional(),
    attachmentStorages: z.array(attachmentStorageSchema).optional(),
    description: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
    icon: z.string().optional(),
    image: z.string().optional(),
    name: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
    rootAgent: rootSchema,
    tags: z.array(z.any()).default([]).optional(),
  });

  // Infer type for Zod Validation Schema
  type RootSchema = z.infer<typeof rootSchema>;
  type WorkflowSchema = z.infer<typeof workflowSchema>;

  const initialOrchestrator = initialData?.rootAgent ? initialData?.rootAgent : { id: "", type: "" };
  const initialAgents = useMemo(() => initialData?.agents || [], [initialData?.agents]);

  const {
    formState: { errors, isDirty },
    handleSubmit,
    register,
    setValue,
    watch,
  } = useForm({
    defaultValues: {
      agents: initialAgents,
      attachmentStorages: initialData?.attachmentStorages || defaultAttachmentStorages,
      description: initialData?.description || "",
      icon: initialData?.icon || "",
      image: initialData?.image || "",
      name: initialData?.name || "",
      rootAgent: initialOrchestrator,
      tags: (initialData?.tags || []) as Tag[],
    },
    mode: "onChange",
    resolver: zodResolver(workflowSchema),
  });

  useEffect(() => {
    register("attachmentStorages");
  }, [register]);

  // side effect to set initial value of the form
  useEffect(() => {
    if (initialData) {
      setCurrentOrchestrator(initialData?.rootAgent?.id ? initialData.rootAgent : null);
      setCurrentAgents(initialData?.agents || []);
      setIcon(initialData?.icon || "");
      setImage(initialData?.image || "");
      setSelectedTags((initialData?.tags as Tag[]) || []);
    }
  }, [initialData, setValue]);

  // side effect which subscribe for values changes in form
  useEffect(() => {
    const subscription = watch((values) => {
      // check for changes in orchestrator, agents and handoffs
      if (
        !(JSON.stringify(values.agents) === JSON.stringify(initialAgents)) ||
        values.icon !== initialData?.icon ||
        values.image !== initialData?.image
      ) {
        setNonFormFieldDirty(true);
      } else {
        setNonFormFieldDirty(false);
      }

      setCurrentOrchestrator(values?.rootAgent?.id ? (values.rootAgent as AgentWorkflowNode) : null);
      setCurrentAgents((values?.agents as AgentWorkflowAgent[]) || []);
      setIcon(values?.icon || "");
      setImage(values?.image || "");
    });

    return () => subscription.unsubscribe();
  }, [watch, initialAgents, initialData?.icon, initialData?.image]);

  // side effect to fetch orchestrator details
  useEffect(() => {
    const fetchOrchestratorDetails = async (orchestrator: AgentWorkflowNode) => {
      setIsLoadingOrchestratorDetails(true);
      let details;
      try {
        if (orchestrator?.type == TypeName.Assistant) {
          details = await AssistantService.getAssistant(orchestrator.id);
        } else details = await AgentService.getAgent(orchestrator.id);
        setOrchestratorAgent(details);
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETORCHESTRATORDETAILS), error as Error);
      } finally {
        setIsLoadingOrchestratorDetails(false);
      }
    };

    if (currentOrchestrator) {
      fetchOrchestratorDetails(currentOrchestrator);
    }
  }, [currentOrchestrator]);

  const { filteredTags, loadTags } = useFilterTags();
  const fetchTags = useCallback(async () => {
    setTags(filteredTags);
  }, [filteredTags]);

  useEffect(() => {
    fetchTags();
  }, [fetchTags, loadTags]);

  // submit handler for agentic workflow form
  const submitHandler: SubmitHandler<WorkflowSchema> = async (data, e?: BaseSyntheticEvent) => {
    e?.preventDefault();

    const allAttachmentStorages = attachmentStorages;
    let tags: Tag[] = [];
    try {
      tags = await processTags(selectedTags as TagOrCustom[], (loadingState) =>
        setLoading((prev) => ({
          ...prev,
          ...loadingState,
        }))
      );
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATETAGS), error as Error);
    }
    setSelectedTags(tags);

    const filteredAttachmentStorages = (allAttachmentStorages || []).filter((row) => row.type && row.fileStorageId);

    const payload = {
      ...(initialData || {}),
      ...data,
      attachmentStorages:
        filteredAttachmentStorages.length > 0 ? filteredAttachmentStorages : [{ fileStorageId: null, type: null }],
      tags: tags ? (tags as Tag[]) : [],
    };
    if (initialData) {
      // triggers edit flow
      try {
        setLoading((prevState) => ({ ...prevState, buildAgent: true }));
        await AgentWorkflowService.updateAgentWorkflow(payload as AgentWorkflow);

        updateTrigger();
        handleClose();
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATESUPERAGENT), error as Error);
      } finally {
        setLoading((prevState) => ({ ...prevState, buildAgent: false }));
      }
    } else {
      // triggers create flow
      try {
        setLoading((prevState) => ({ ...prevState, buildAgent: true }));
        const res = await AgentWorkflowService.createAgentWorkflow(payload as unknown as AgentWorkflow);
        if (workspace) {
          try {
            await WorkspaceService.linkWorkflowToWorkspace(workspace, res);
          } catch (err) {
            openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINKWORKSPACEASSISTANT), err as Error);
          }
        }

        updateTrigger();
        handleClose();
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CREATESUPERAGENT), error as Error);
      } finally {
        setLoading((prevState) => ({ ...prevState, buildAgent: false }));
      }
    }
  };

  const handleDelete = async () => {
    if (initialData?.id) {
      setIsDeleting(true);

      try {
        await AgentWorkflowService.deleteAgentWorkflow(initialData as AgentWorkflow);

        updateTrigger();
        handleClose();
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETESUPERAGENT), error as Error);
      } finally {
        setIsDeleting(false);
      }
    }
  };

  const handleDeleteOrchestrator = () => {
    const updatedAgents = currentAgents.filter((agent) => agent.id !== currentOrchestrator?.id);
    setValue("agents", (updatedAgents || []) as AgentWorkflowAgent[], {
      shouldValidate: true,
    });
    setValue(
      "rootAgent",
      { id: "", type: "" },
      {
        shouldValidate: true,
      }
    );
  };

  const onCloseCreateOrchestrator = () => {
    if (isOrchestratorFormDirty) {
      setIsConfirmClose(true);
    } else setShowCreateOrchestrator(false);
  };
  const handleOrchestratorClose = () => {
    setShowCreateOrchestrator(false);
  };

  const handleWorkflowClose = () => {
    // check if attachment storage is dirty
    const initialAttachmentStorages = initialData?.attachmentStorages || defaultAttachmentStorages || [];
    const currentAttachmentStorages = attachmentStorages;
    const isAttachmentStorageDirty =
      JSON.stringify(currentAttachmentStorages) !== JSON.stringify(initialAttachmentStorages);

    if (
      isDirty ||
      nonFormFieldDirty ||
      isAttachmentStorageDirty ||
      JSON.stringify((initialData?.tags || [])?.map((item) => item.name).sort()) !=
        JSON.stringify((selectedTags || [])?.map((item) => item.name).sort())
    ) {
      setIsConfirmClose(true);
    } else {
      onHide();
    }
  };

  const handleCloseConfirmation = (confirm: boolean) => {
    if (confirm) {
      if (showCreateOrchestrator && isOrchestratorFormDirty) {
        //for create new orchestrator
        setShowCreateOrchestrator(false); //hide orchestrator modal
        setIsConfirmClose(false); //hide confirmation popup
        assetForm.reset(); //clear the assetForm when user clicks on discard for new orchestrator
      } else {
        onHide();
      }
    } else {
      setIsConfirmClose(false);
    }
  };
  //callback on orchestrator form dirty
  const handleNewOrchestratorDataChange = (data: boolean) => {
    setIsOrchestratorFormDirty(data);
  };

  return (
    <>
      <Modal
        show={show}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop"
        onHide={handleWorkflowClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>
            {initialData ? initialData.name : t(TranslationKeys.AGENTWORKFLOWFORM_NEWSUPERAGENT)}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col md={4} style={{ height: "500px", overflowY: "auto" }}>
              <Form onSubmit={handleSubmit(submitHandler)} className="p-2" id="agent-workflow-form">
                <Form.Group className="mb-3">
                  <RequiredLabel label={t(TranslationKeys.AGENTWORKFLOWFORM_NAME)} />
                  <Form.Control
                    id="name"
                    type="text"
                    placeholder={t(TranslationKeys.AGENTWORKFLOWFORM_NAMEPLACEHOLDER)}
                    isInvalid={!!errors.name}
                    {...register("name")}
                  />
                  {errors.name && <Form.Control.Feedback type="invalid">{errors.name.message}</Form.Control.Feedback>}
                </Form.Group>

                <Form.Group className="mb-3">
                  <RequiredLabel label={t(TranslationKeys.AGENTWORKFLOWFORM_DESCRIPTION)} />
                  <Form.Control
                    id="description"
                    as="textarea"
                    rows={3}
                    placeholder={t(TranslationKeys.AGENTWORKFLOWFORM_DESCRIPTIONPLACEHOLDER)}
                    isInvalid={!!errors.description}
                    {...register("description")}
                  />
                  {errors.description && (
                    <Form.Control.Feedback type="invalid">{errors.description.message}</Form.Control.Feedback>
                  )}
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_TAGS)}</Form.Label>
                  <DropdownSelect options={tags} selectedTags={selectedTags} setSelectedTags={setSelectedTags} />
                </Form.Group>

                {isEqtyEnabled() && (
                  <Form.Group className="mb-3">
                    <Button
                      key={"agentReview.governanceSettings"}
                      className="mt-2 text-start navai-button w-100"
                      variant="outline"
                      onClick={() => setShowGovernanceForm(true)}
                      disabled={!initialData?.id}
                    >
                      <i className="bi bi-shield-check pe-2"></i>
                      {t(TranslationKeys.AGENTREVIEW_GOVERNANCESETTINGS)}
                    </Button>
                  </Form.Group>
                )}

                <div className="mb-3">
                  <div className="mb-2">
                    <RequiredLabel
                      labelProps={{
                        className: "d-inline me-2",
                      }}
                      label={t(TranslationKeys.AGENTWORKFLOWFORM_ORCHESTRATORLABEL)}
                    />
                    <InfoTooltip message={t(TranslationKeys.AGENTWORKFLOWFORM_ORCHESTRATORTOOLTIP)} />
                  </div>
                  {currentOrchestrator ? (
                    <>
                      {isLoadingOrchestratorDetails && <div>{t(TranslationKeys.AGENTWORKFLOWFORM_LOADING)}</div>}

                      {orchestratorAgent && !isLoadingOrchestratorDetails && (
                        <div className="rounded p-3 border position-relative bg-primary-subtle w-100">
                          <div className="fw-bolder text-white">
                            <i className="bi bi-cpu me-2" />
                            {orchestratorAgent.name}
                          </div>

                          <Button
                            size="sm"
                            color="neutral"
                            variant="plain"
                            style={{
                              position: "absolute",
                              right: "-1rem",
                              top: "-1rem",
                              zIndex: 5,
                            }}
                            onClick={() => {
                              setShowDeleteOrchestratorConfirmation(true);
                            }}
                          >
                            <i className="bi bi-x-circle-fill" style={{ fontSize: "1rem" }}></i>
                          </Button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div
                      className={`rounded d-flex justify-content-center align-items-center gap-2 p-3 w-100 ${
                        errors.rootAgent ? "form-invalid-container" : "border"
                      }`}
                    >
                      <Button
                        size="sm"
                        style={{ flexBasis: "60%" }}
                        onClick={() => {
                          setShowAddModal(true);
                        }}
                        className="button"
                      >
                        {t(TranslationKeys.ENTITYPICKER_SELECTORCHESTRATORAGENT)}
                      </Button>
                    </div>
                  )}

                  {errors.rootAgent && (
                    <div className="invalid-feedback d-block">{t(TranslationKeys.MESSAGES_ORCHESTRATORREQUIRED)}</div>
                  )}
                </div>

                {/* Add File Storage for Attachment */}
                <Form.Group className="mb-3">
                  <Form.Label className="d-inline me-2">
                    {t(TranslationKeys.AGENTWORKFLOWFORM_FILETYPESSTORAGE)}
                  </Form.Label>
                  <InfoTooltip message={t(TranslationKeys.AGENTWORKFLOWFORM_FILETYPESTOOLTIP)} />
                  <AttachmentStorageTable
                    documentTypeConfigs={documentTypeConfigs}
                    onTypeToggle={handleTypeToggle}
                    onFileStorageChange={handleFileStorageChange}
                    attachmentStorageDefaults={defaultAttachmentStorages}
                  />
                </Form.Group>

                <Row>
                  <Col md={4} className="d-flex">
                    <Form.Group className="flex-grow-1 d-flex flex-column">
                      <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_ICON)}</Form.Label>
                      <div className="flex-grow-1 d-flex align-items-center">
                        <ImageUpload
                          value={icon}
                          variant="circle"
                          maxSizeInBytes={MAX_ICON_SIZE}
                          width="6em"
                          height="6em"
                          onUpload={(base64Image: string) => {
                            setValue("icon", base64Image, {
                              shouldValidate: true,
                            });
                            setIcon(base64Image);
                          }}
                          onDelete={() => {
                            setValue("icon", "", {
                              shouldValidate: true,
                            });
                            setIcon("");
                          }}
                          onError={(error: Error) => {
                            openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                          }}
                        />
                      </div>
                    </Form.Group>
                  </Col>

                  <Col md={8}>
                    <Form.Group>
                      <Form.Label>{t(TranslationKeys.AGENTWORKFLOWFORM_IMAGE)}</Form.Label>
                      <ImageUpload
                        width="12em"
                        height="8em"
                        value={image}
                        maxSizeInBytes={MAX_IMAGE_SIZE}
                        onDelete={() => {
                          setValue("image", "", {
                            shouldValidate: true,
                          });
                          setImage("");
                        }}
                        onUpload={(base64Image: string) => {
                          setValue("image", base64Image, {
                            shouldValidate: true,
                          });
                          setImage(base64Image);
                        }}
                        onError={(error: Error) => {
                          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPLOADIMG), error);
                        }}
                      />
                    </Form.Group>
                  </Col>
                </Row>
              </Form>
            </Col>

            <Col style={{ height: "500px" }}>
              <ReactFlowProvider>
                <AgentWorkflowEditor
                  workspace={workspace as Workspace}
                  orchestrator={currentOrchestrator}
                  agents={currentAgents}
                  isRead={initialData?.accessPermission === PermissionType.READ}
                  onUpdate={(agents) => {
                    setValue("agents", agents as AgentWorkflowAgent[], {
                      shouldValidate: true,
                    });
                  }}
                  onEndNodeUpdate={(agents: AgentWorkflowAgent[]) => {
                    setValue("agents", agents as AgentWorkflowAgent[], {
                      shouldValidate: true,
                    });
                  }}
                  onRootUpdate={(root) => {
                    setValue("rootAgent", root?.id ? (root as RootSchema) : { id: "", type: "" }, {
                      shouldValidate: true,
                    });
                  }}
                />
              </ReactFlowProvider>
            </Col>
          </Row>
        </Modal.Body>

        <Modal.Footer className="d-flex justify-content-between">
          <div className="text-start">
            {initialData ? (
              isDeleting ? (
                <button className="btn btn-danger" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;Loading...
                </button>
              ) : (
                <Button
                  variant="danger"
                  type="button"
                  onClick={() => {
                    setShowConfirmation(true);
                  }}
                  disabled={initialData?.creator.id !== userId}
                >
                  {t(TranslationKeys.AGENTWORKFLOWFORM_DELETE)}
                </Button>
              )
            ) : null}
          </div>

          <div className="text-end">
            {loading && (loading.buildAgent || loading.tags) ? (
              <button className="btn btn-primary" type="button" disabled>
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                &nbsp;Loading...
              </button>
            ) : (
              <Button variant="primary" form="agent-workflow-form" type="submit">
                {!initialData ? t(TranslationKeys.AGENTWORKFLOWFORM_SAVE) : t(TranslationKeys.AGENTWORKFLOWFORM_UPDATE)}
              </Button>
            )}
          </div>
        </Modal.Footer>
      </Modal>

      {/* Delete super agent confirmation */}
      {showConfirmation && (
        <ConfirmationDialog
          show={showConfirmation}
          confirmationQuestion={t(TranslationKeys.AGENTWORKFLOWFORM_DELETESUPERAGENTCONFIRM)}
          confirmationButtonLabel={t(TranslationKeys.AGENTWORKFLOWFORM_CONFIRM)}
          onClose={() => setShowConfirmation(false)}
          onConfirm={() => {
            setShowConfirmation(false);
            handleDelete();
          }}
        />
      )}
      {/* Delete orchestrator agent confirmation */}
      {showDeleteOrchestratorConfirmation && (
        <ConfirmationDialog
          show={showDeleteOrchestratorConfirmation}
          confirmationQuestion={t(TranslationKeys.AGENTWORKFLOWFORM_REMOVEORCHESTRATORCONFIRM)}
          confirmationButtonLabel={t(TranslationKeys.AGENTWORKFLOWFORM_CONFIRM)}
          onClose={() => setShowDeleteOrchestratorConfirmation(false)}
          onConfirm={() => {
            setShowDeleteOrchestratorConfirmation(false);
            handleDeleteOrchestrator();
          }}
        />
      )}

      {/* Modal - Entity Picker */}
      {showAddModal && (
        <Modal fullscreen size="lg" show={showAddModal} onHide={() => setShowAddModal(false)}>
          <AgentWorkflowEntityPicker
            workspace={workspace as Workspace}
            entities={currentAgents}
            isOrchestrator={true}
            onCancel={() => setShowAddModal(false)}
            onLink={(entity) => {
              const agentsObj = currentAgents?.length
                ? [
                    ...entity.map((a) => ({
                      canHandOffTo: null,
                      id: a.id,
                      type: a.__type_name,
                    })),
                    ...currentAgents,
                  ]
                : [
                    ...entity.map((a) => ({
                      canHandOffTo: null,
                      id: a.id,
                      type: a.__type_name,
                    })),
                  ];
              setShowAddModal(false);
              setValue("agents", agentsObj as AgentWorkflowAgent[], {
                shouldValidate: true,
              });
              setValue(
                "rootAgent",
                {
                  id: agentsObj[0].id,
                  type: agentsObj[0].type,
                } as RootSchema,
                { shouldValidate: true }
              );
            }}
          />
        </Modal>
      )}
      {/* Modal - Create New Orchestrator */}
      <Modal
        show={showCreateOrchestrator}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop"
        onHide={onCloseCreateOrchestrator}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.AGENTWORKFLOWFORM_CREATEORCHESTRATORAGENT)}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <NewAssetForm
            workspace={workspace as Workspace}
            handleClose={handleOrchestratorClose}
            triggerUpdate={(agent) => {
              const updatedAgents = [
                ...currentAgents,
                {
                  canHandOffTo: [],
                  id: agent.id,
                  type: agent.__type_name,
                },
              ];

              setValue("agents", updatedAgents as AgentWorkflowAgent[], {
                shouldValidate: true,
              });
              setValue(
                "rootAgent",
                {
                  id: agent.id,
                  type: agent.__type_name,
                } as RootSchema,
                {
                  shouldValidate: true,
                }
              );
            }}
            onCreateAgentFormDirty={handleNewOrchestratorDataChange}
            onCreateAgentDirtyData={(data: AgentDirtyFields) => handleAgentDirtyDataTitles(data, setDirtyFields)}
          />
        </Modal.Body>
      </Modal>

      {isConfirmClose && (
        <Modal show={isConfirmClose} onHide={() => setIsConfirmClose(false)}>
          <Modal.Header>
            <Modal.Title>{t(TranslationKeys.AGENTWORKFLOWFORM_UNSAVEDCHANGES)}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <UnsavedChanges dirtyFields={dirtyFields} />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => handleCloseConfirmation(false)}>
              {t(TranslationKeys.AGENTWORKFLOWFORM_CANCEL)}
            </Button>
            <Button variant="danger" onClick={() => handleCloseConfirmation(true)}>
              {t(TranslationKeys.AGENTWORKFLOWFORM_DISCARDCHANGES)}
            </Button>
          </Modal.Footer>
        </Modal>
      )}
      <Modal
        show={showGovernanceForm}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => setShowGovernanceForm(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Governance Settings</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <GovernanceForm handleClose={handleCloseGovernance} initialData={initialData as AgentWorkflow} />
        </Modal.Body>
      </Modal>
    </>
  );
}

export default AgentWorkflowForm;
