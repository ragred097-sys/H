import React, { BaseSyntheticEvent, useEffect, useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

import { Button, Form } from "react-bootstrap";
import { SubmitHandler, useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";

import { Tag } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import LoadingButton from "../general/LoadingButton/LoadingButton";
import { useNotification } from "../general/NotificationProvider";
import { RequiredLabel } from "../general/RequiredLabel";
import { TagService } from "./../../services/TagService";

interface tagFormProps {
  tagData: Tag | undefined;
  setIsFormDirty: React.Dispatch<React.SetStateAction<boolean>>;
  handleClose: () => void;
  handleUpdate?: () => void;
}
const TagForm = ({ handleClose, handleUpdate, setIsFormDirty, tagData }: tagFormProps) => {
  const [loading, setLoading] = useState(false);
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();

  const tagSchema = z.object({
    description: z.string().nonempty(t(TranslationKeys.MESSAGES_DESCRIPTIONREQUIRED)),
    name: z.string().nonempty(t(TranslationKeys.MESSAGES_NAMEREQUIRED)),
  });

  type TagSchema = z.infer<typeof tagSchema>;

  const {
    formState: { errors, isDirty },
    handleSubmit,
    register,
  } = useForm({
    defaultValues: {
      description: tagData?.description || "",
      name: tagData?.name || "",
    },
    mode: "onChange",
    resolver: zodResolver(tagSchema),
  });
  useEffect(() => {
    if (isDirty) {
      setIsFormDirty(true);
    } else {
      setIsFormDirty(false);
    }
  }, [isDirty, setIsFormDirty]);
  const submitHandler: SubmitHandler<TagSchema> = async (data, e?: BaseSyntheticEvent) => {
    e?.preventDefault();
    try {
      if (data) {
        const payload = {
          ...tagData,
          description: data?.description,
          name: data?.name,
        };
        setLoading(true);
        await TagService.updateTag(payload as Tag);
        handleUpdate?.();
      }
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_UPDATETAG), error as Error);
    } finally {
      setLoading(false);
      handleClose();
    }
  };
  return (
    <>
      <Form onSubmit={handleSubmit(submitHandler)} className="p-2">
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.MESSAGES_NAME, "Name")} />
          <Form.Control
            id="name"
            type="text"
            placeholder={t(TranslationKeys.MESSAGES_NAME, "Tag Name")}
            isInvalid={!!errors?.name}
            {...register("name")}
          />
          {errors.name && <Form.Control.Feedback type="invalid">{errors.name.message}</Form.Control.Feedback>}
        </Form.Group>
        <Form.Group className="mb-3">
          <RequiredLabel label={t(TranslationKeys.MESSAGES_DESCRIPTION, "Description")} />
          <Form.Control
            id="description"
            type="text"
            placeholder={t(TranslationKeys.MESSAGES_DESCRIPTION, "Tag Description")}
            isInvalid={!!errors?.description}
            {...register("description")}
          />
          {errors.description && (
            <Form.Control.Feedback type="invalid"> {errors?.description?.message}</Form.Control.Feedback>
          )}
        </Form.Group>
        <div className="text-end me-2">
          {loading ? (
            <LoadingButton className={"btn btn-primary"} />
          ) : (
            <Button variant="primary" type="submit" className="button">
              {t(TranslationKeys.WORKSPACEFORM_UPDATE, "Update")}
            </Button>
          )}
        </div>
      </Form>
    </>
  );
};
export default TagForm;
