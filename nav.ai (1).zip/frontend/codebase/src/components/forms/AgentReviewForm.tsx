import { useEffect, useState } from "react";

import { Form, ListGroup, Table } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AssetForm, DataSource, Module, ModuleType, SystemInstruction } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { isEqtyEnabled } from "../../utils/eqty";
import { getProviderLogo } from "../../utils/uiUtils";
import { ModuleService } from "./../../services/ModuleService";

export default function AgentReviewForm({ data, isUtilityAgent }: { data: AssetForm; isUtilityAgent: boolean }) {
  const [fileStorageOptions, setFileStorageOptions] = useState<Module[]>([]);

  useEffect(() => {
    ModuleService.getModulesByType(ModuleType.FILE_STORAGE)
      .then((modules: Module[]) => setFileStorageOptions(modules))
      .catch(() => setFileStorageOptions([]));
  }, []);

  // Helper to get storage name by id
  const getFileStorageName = (id: string | null) => {
    const found = fileStorageOptions.find((fs) => fs.id === id);
    return found ? found.name : id;
  };

  const { t } = useTranslation();

  interface Nameable {
    name: string;
  }

  const renderListRow = (label: string, items: SystemInstruction[] | DataSource[] | Module[] | Nameable[] = []) => (
    <tr>
      <td className="w-25 fw-bold">{label}</td>
      <td>
        <ListGroup variant="flush" as="ol" numbered>
          {items?.map((item, index) => (
            <ListGroup.Item
              as="li"
              key={index}
              className="p-0"
              style={{ backgroundColor: "transparent", border: "0", width: "400px", wordWrap: "break-word" }}
            >
              {item?.name}
            </ListGroup.Item>
          ))}
        </ListGroup>
      </td>
    </tr>
  );

  return (
    <div className="p-3 ">
      <Form.Label className="fs-5 fw-bold">{t(TranslationKeys.AGENTREVIEW_REVIEWAGENTCONFIG)}</Form.Label>
      <Table size="sm" striped responsive>
        <tbody>
          <tr>
            <td className="w-25 fw-bold">{t(TranslationKeys.AGENTFORM_AGENTNAME)}</td>
            <td>{data.assetName}</td>
          </tr>
          <tr>
            <td className="w-25 fw-bold">{t(TranslationKeys.AGENTFORM_AGENTDESCRIPTION)}</td>
            <td>{data.assetDescription}</td>
          </tr>
          <tr>
            <td className="w-25 fw-bold">{t(TranslationKeys.AGENTFORM_AIMODEL)}</td>
            <td>
              {data?.modelDetails?.name}
              {data?.modelDetails?.name ? (
                <img
                  className="ps-3"
                  src={getProviderLogo(data?.modelDetails?.name)}
                  style={{ height: "1em" }}
                  alt="provider logo"
                />
              ) : null}
            </td>
          </tr>
          {!isUtilityAgent && (
            <>
              {renderListRow(t(TranslationKeys.AGENTREVIEW_REFERENCEDATA), data.dataSources)}
              {renderListRow(t(TranslationKeys.AGENTREVIEW_SYSTEMPROMPTS), data.systemPrompts)}
              <tr>
                <td className="w-25 fw-bold">{t(TranslationKeys.AGENTREVIEW_CUSTOMGREETING)}</td>
                <td>{data?.greeting}</td>
              </tr>
              <tr>
                <td className="w-25 fw-bold">{t(TranslationKeys.AGENTREVIEW_PROMPTSUGGESTIONS)}</td>
                <td>
                  <ListGroup variant="flush" as="ol" numbered>
                    {data.suggestions?.map((el, idx) => (
                      <ListGroup.Item
                        as="li"
                        key={idx}
                        className="p-0"
                        style={{ backgroundColor: "transparent", border: "0" }}
                      >
                        {el}
                      </ListGroup.Item>
                    ))}
                  </ListGroup>
                </td>
              </tr>
              <tr>
                <td className="w-25 fw-bold">{t(TranslationKeys.AGENTREVIEW_STORAGEATTACHMENTS)}</td>
                <td>
                  <ListGroup variant="flush" as="ol" numbered>
                    {data.attachmentStorages
                      ?.filter((el) => el.type && el.fileStorageId)
                      .map((el, index) => (
                        <ListGroup.Item
                          as="li"
                          key={el.type + "-" + el.fileStorageId + "-" + index}
                          className="p-0"
                          style={{
                            backgroundColor: "transparent",
                            border: "0",
                          }}
                        >
                          {el.type} - {getFileStorageName(el.fileStorageId)}
                        </ListGroup.Item>
                      ))}
                  </ListGroup>
                </td>
              </tr>
              {renderListRow(t(TranslationKeys.AGENTREVIEW_NAVAITOOLS), data.tools)}
            </>
          )}
          {isUtilityAgent && (
            <>
              {renderListRow(t(TranslationKeys.AGENTREVIEW_SYSTEMPROMPTS), data.systemPrompts)}
              {renderListRow(t(TranslationKeys.AGENTREVIEW_FUNCTIONTOOLS), data.functionTools)}
            </>
          )}
          {isEqtyEnabled() && data.governanceConfiguration && (
            <>
              {renderListRow(t(TranslationKeys.AGENTREVIEW_GOVERNANCESETTINGS), [
                {
                  name: `${t(TranslationKeys.GOVERNANCEFORM_THUMBSUPDOWNINDICATOR)}: ${data.governanceConfiguration?.thumbs_indicator_uuid ?? t(TranslationKeys.AGENTREVIEW_NOTSET)}`,
                },
              ])}
            </>
          )}
        </tbody>
      </Table>
    </div>
  );
}
