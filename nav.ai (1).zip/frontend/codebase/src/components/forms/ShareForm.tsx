import { useEffect, useState } from "react";

import { Button, Form, Table } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import {
  AccessRole,
  Assistant,
  Module,
  PermissionType,
  RolePermission,
  SystemInstruction,
  TypeName,
  User,
  UserPermission,
  Workspace,
  getLabelFor,
} from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { sortArrayOfObjs } from "../../utils/arrayUtils";
import { useNotification } from "../general/NotificationProvider";
import { AccessControlService } from "./../../services/AccessControlService";
import { ApplicationService } from "./../../services/ApplicationService";
import { UserService } from "./../../services/UserService";

// Initial state constants
const initialUserPermissionState = {
  isNew: true,
  permissionType: PermissionType.READ,
  searchQuery: "",
  userId: "",
  userName: "",
};

const initialRolePermissionState = {
  isNew: true,
  permissionType: PermissionType.READ,
  roleId: "",
  roleName: "",
  searchQuery: "",
};

export const ShareForm = ({
  data,
  openShareForm,
  updateTrigger,
}: {
  data: Assistant | Workspace | SystemInstruction | Module;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  openShareForm: any;
  updateTrigger?: () => void;
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<AccessRole[]>([]);
  const [user, setUser] = useState<User | undefined>();
  const [userPermissions, setUserPermissions] = useState<UserPermission[]>([initialUserPermissionState]);
  const [rolePermissions, setRolePermissions] = useState<RolePermission[]>([initialRolePermissionState]);
  const [initialUserPermissions, setInitialUserPermissions] = useState<UserPermission[]>([]);
  const [initialRolePermissions, setInitialRolePermissions] = useState<RolePermission[]>([]);
  const [loadingBtn, setLoadingBtn] = useState({
    grant: false,
    updateGrant: false,
  });

  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();

  useEffect(() => {
    UserService.getUsers()
      .then(async (fetchedUsers) => {
        if (fetchedUsers) {
          setUsers(fetchedUsers);
          // Get roles for all users
          const userRoles = await ApplicationService.getUserAccessRoles(fetchedUsers.map((u) => u.id));
          // Update users with their roles
          setUsers(
            fetchedUsers.map((user) => ({
              ...user,
              roles: userRoles[user.id] || [],
            }))
          );
        }
      })
      .catch((error) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETUSERS), error as Error);
      });

    UserService.getCurrentUser()
      .then((res) => setUser(res))
      .catch((err) => openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETCURRENTUSER), err as Error));

    AccessControlService.getAccessRoles()
      .then((res) => {
        if (res) {
          setRoles(res);
        }
      })
      .catch((error) => {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETACCESSROLES), error as Error);
      });
  }, [data]);

  useEffect(() => {
    if ("accessPermission" in data && users.length > 0) {
      AccessControlService.getGrants(data)
        .then((res) => {
          // Initialize userPermissions from current grants
          const userPerms = res
            .filter((grant) => grant.assigneeType === TypeName.User)
            .map((grant) => ({
              isNew: false,
              permissionType: grant.accessLevel,
              searchQuery: "",
              userId: grant.assigneeId,
              userName: users.find((u) => u.id === grant.assigneeId)?.name || grant.assigneeId,
            }));

          if (userPerms.length > 0) {
            setUserPermissions(userPerms);
            setInitialUserPermissions(userPerms);
          } else {
            setUserPermissions([initialUserPermissionState]);
          }

          // Initialize rolePermissions from current grants
          const rolePerms = res
            .filter((grant) => grant.assigneeType === TypeName.AccessRole)
            .map((grant) => ({
              isNew: false,
              permissionType: grant.accessLevel,
              roleId: grant.assigneeId,
              roleName: roles.find((r) => r.id === grant.assigneeId)?.name || grant.assigneeId,
              searchQuery: "",
            }));
          if (rolePerms.length > 0) {
            setRolePermissions(rolePerms);
            setInitialRolePermissions(rolePerms);
          } else {
            setRolePermissions([initialRolePermissionState]);
          }
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGRANTS), err as Error);
        });
    }
  }, [data, users, roles]);

  // User list clean up
  const filterUsers = (users: User[]) => {
    const omitUsers = ["SYSTEM", user?.name];
    return users.filter((user) => !omitUsers.includes(user.name));
  };
  const filteredUsers = users ? filterUsers(users) : [];
  const sortedUsers = sortArrayOfObjs(filteredUsers, "name");

  const permissionTypes = Object.values(PermissionType).map((permission) => (
    <option key={permission} value={permission} className="m-2 p-2" style={{ borderRadius: "10px" }}>
      {permission}
    </option>
  ));

  // Handlers
  const handleAddNewRow = () => {
    setUserPermissions([...userPermissions, initialUserPermissionState]);
  };

  const handleRemoveRow = (index: number) => {
    const updatedPermissions = userPermissions.filter((_, i) => i !== index);
    setUserPermissions(updatedPermissions.length > 0 ? updatedPermissions : [initialUserPermissionState]);
  };

  const handleSearchChange = (index: number, query: string) => {
    const updatedPermissions = [...userPermissions];
    updatedPermissions[index] = {
      ...updatedPermissions[index],
      searchQuery: query,
    };
    setUserPermissions(updatedPermissions);
  };

  const handleUserSelect = (index: number, selectedUser: User) => {
    const updatedPermissions = [...userPermissions];
    updatedPermissions[index] = {
      ...updatedPermissions[index],
      isNew: true,
      searchQuery: selectedUser.name,
      userId: selectedUser.id,
      userName: selectedUser.name,
    };
    setUserPermissions(updatedPermissions);
  };

  const handleRemoveUser = async (userId: string) => {
    try {
      setLoadingBtn((prevState) => ({ ...prevState, grant: true }));
      await ApplicationService.deleteEntityPermissions(data.__type_name, data.id, {
        roleIds: [],
        userIds: [userId],
      });
      updateTrigger?.();
      setUserPermissions(userPermissions.filter((up) => up.userId !== userId));
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
    } catch (error) {
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GRANTPERMISSION), error as Error);
    }
  };

  const handleUpdateUserPermission = (userId: string, newPermission: PermissionType) => {
    setUserPermissions(
      userPermissions.map((up) => (up.userId === userId ? { ...up, permissionType: newPermission } : up))
    );
  };

  const handleAddNewRoleRow = () => {
    setRolePermissions([...rolePermissions, initialRolePermissionState]);
  };

  const handleRemoveRoleRow = (index: number) => {
    const updatedPermissions = rolePermissions.filter((_, i) => i !== index);
    setRolePermissions(updatedPermissions.length > 0 ? updatedPermissions : [initialRolePermissionState]);
  };

  const handleRoleSearchChange = (index: number, query: string) => {
    const updatedPermissions = [...rolePermissions];
    updatedPermissions[index] = {
      ...updatedPermissions[index],
      searchQuery: query,
    };
    setRolePermissions(updatedPermissions);
  };

  const handleRoleSelect = (index: number, selectedRole: AccessRole) => {
    const updatedPermissions = [...rolePermissions];
    updatedPermissions[index] = {
      ...updatedPermissions[index],
      isNew: true,
      roleId: selectedRole.id,
      roleName: selectedRole.name,
      searchQuery: selectedRole.name,
    };
    setRolePermissions(updatedPermissions);
  };

  const handleRemoveRole = async (roleId: string) => {
    try {
      setLoadingBtn((prevState) => ({ ...prevState, grant: true }));
      await ApplicationService.deleteEntityPermissions(data.__type_name, data.id, {
        roleIds: [roleId],
        userIds: [],
      });
      setRolePermissions(rolePermissions.filter((rp) => rp.roleId !== roleId));
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
    } catch (error) {
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GRANTPERMISSION), error as Error);
    }
  };

  const handleUpdateRolePermission = (roleId: string, newPermission: PermissionType) => {
    setRolePermissions(
      rolePermissions.map((rp) => (rp.roleId === roleId ? { ...rp, permissionType: newPermission } : rp))
    );
  };

  const handleShare = async () => {
    try {
      setLoadingBtn((prevState) => ({ ...prevState, grant: true }));

      // Separate new and existing permissions
      const newUserPermissions = userPermissions
        .filter((up) => up.userId && up.isNew)
        .map((up) => ({
          permissionType: up.permissionType,
          userId: up.userId,
        }));

      const existingUserPermissions = userPermissions
        .filter((up) => up.userId && !up.isNew)
        .map((up) => ({
          permissionType: up.permissionType,
          userId: up.userId,
        }));

      const newRolePermissions = rolePermissions
        .filter((rp) => rp.roleId && rp.isNew)
        .map((rp) => ({
          permissionType: rp.permissionType,
          roleId: rp.roleId,
        }));

      const existingRolePermissions = rolePermissions
        .filter((rp) => rp.roleId && !rp.isNew)
        .map((rp) => ({
          permissionType: rp.permissionType,
          roleId: rp.roleId,
        }));

      // If there are new permissions, use shareEntity
      if (newUserPermissions.length > 0 || newRolePermissions.length > 0) {
        await ApplicationService.shareEntity(data.__type_name, data.id, {
          rolePermissions: newRolePermissions,
          userPermissions: newUserPermissions,
        });
      }

      // If there are existing permissions with updates, use updateEntityPermissions
      if (existingUserPermissions.length > 0 || existingRolePermissions.length > 0) {
        await ApplicationService.updateEntityPermissions(data.__type_name, data.id, {
          rolePermissions: existingRolePermissions,
          userPermissions: existingUserPermissions,
        });
      }

      // Update the isNew flags after successful sharing
      setUserPermissions(
        userPermissions.map((up) => ({
          ...up,
          isNew: false,
        }))
      );
      setRolePermissions(
        rolePermissions.map((rp) => ({
          ...rp,
          isNew: false,
        }))
      );
      updateTrigger?.();
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
      openShareForm(false);
    } catch (error) {
      setLoadingBtn((prevState) => ({ ...prevState, grant: false }));
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GRANTPERMISSION), error as Error);
    }
  };

  const MAX_RESULTS = 5;

  // Filter users based on search query for a specific row
  const getFilteredUserOptions = (searchQuery: string, currentUserId: string) => {
    const filteredUsers = sortedUsers.filter(
      (user) =>
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !userPermissions.some((up) => up.userId === user.id && up.userId !== currentUserId)
    );

    return {
      hasMore: filteredUsers.length > MAX_RESULTS,
      results: filteredUsers.slice(0, MAX_RESULTS),
    };
  };

  // Filter roles based on search query for a specific row
  const getFilteredRoleOptions = (searchQuery: string, currentRoleId: string) => {
    const filteredRoles = roles.filter(
      (role) =>
        role.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !rolePermissions.some((rp) => rp.roleId === role.id && rp.roleId !== currentRoleId)
    );

    return {
      hasMore: filteredRoles.length > MAX_RESULTS,
      results: filteredRoles.slice(0, MAX_RESULTS),
    };
  };

  // Function to check if any changes were made
  const hasChanges = () => {
    // Check if any new permissions were added
    const hasNewPermissions =
      userPermissions.some((up) => up.isNew && up.userId) || rolePermissions.some((rp) => rp.isNew && rp.roleId);

    // Check if any existing permissions were modified
    const hasModifiedPermissions =
      initialUserPermissions.some((initialUp) => {
        const currentUp = userPermissions.find((up) => up.userId === initialUp.userId);
        return currentUp && currentUp.permissionType !== initialUp.permissionType;
      }) ||
      initialRolePermissions.some((initialRp) => {
        const currentRp = rolePermissions.find((rp) => rp.roleId === initialRp.roleId);
        return currentRp && currentRp.permissionType !== initialRp.permissionType;
      });

    // Check if any permissions were removed
    const hasRemovedPermissions =
      initialUserPermissions.some((initialUp) => !userPermissions.some((up) => up.userId === initialUp.userId)) ||
      initialRolePermissions.some((initialRp) => !rolePermissions.some((rp) => rp.roleId === initialRp.roleId));

    return hasNewPermissions || hasModifiedPermissions || hasRemovedPermissions;
  };

  return (
    <div>
      <div className="pt-0">
        <h5>{t(TranslationKeys.SHAREFORM_USERS)}</h5>
        <Table striped bordered hover className="align-middle">
          <thead>
            <tr>
              <th>{t(TranslationKeys.SHAREFORM_USER)}</th>
              <th>{t(TranslationKeys.SHAREFORM_PERMISSION)}</th>
              <th>{t(TranslationKeys.SHAREFORM_USERPARTOF)}</th>
              <th>{t(TranslationKeys.SHAREFORM_ACTION)}</th>
            </tr>
          </thead>
          <tbody>
            {userPermissions.map((up, index) => (
              <tr key={up.userId || `new-${index}`}>
                <td>
                  <div className="d-flex align-items-center">
                    {!up.userId && up.isNew ? (
                      <Form.Control
                        type="text"
                        placeholder={t(TranslationKeys.SHAREFORM_SEARCHUSERSPLACEHOLDER)}
                        value={up.searchQuery}
                        onChange={(e) => handleSearchChange(index, e.target.value)}
                      />
                    ) : (
                      <div className="d-flex align-items-center">
                        <span>{up.userName}</span>
                      </div>
                    )}
                  </div>
                  <div className="position-relative">
                    <div
                      className="search-results-container"
                      style={{
                        display: !up.userId && up.isNew && up.searchQuery ? "block" : "none",
                        left: 0,
                        maxHeight: "200px",
                        overflowY: "auto",
                        position: "absolute",
                        right: 0,
                        top: "100%",
                        zIndex: 1000,
                      }}
                    >
                      {!up.userId &&
                        up.isNew &&
                        up.searchQuery &&
                        getFilteredUserOptions(up.searchQuery, up.userId).results.length > 0 && (
                          <div
                            className="border rounded p-2 mt-1"
                            style={{
                              backgroundColor: getComputedStyle(document.documentElement).getPropertyValue(
                                "--bs-body-bg"
                              ),
                            }}
                          >
                            {getFilteredUserOptions(up.searchQuery, up.userId).results.map((user) => (
                              <div
                                key={user.id}
                                className="p-2 hover-highlight"
                                onClick={() => handleUserSelect(index, user)}
                                style={{ cursor: "pointer" }}
                              >
                                {user.name}
                              </div>
                            ))}
                            {getFilteredUserOptions(up.searchQuery, up.userId).hasMore && (
                              <div className="text-muted small p-2">
                                {t(TranslationKeys.SHAREFORM_SHOWINGTOPRESULTS)}
                              </div>
                            )}
                          </div>
                        )}
                    </div>
                  </div>
                </td>
                <td>
                  <Form.Select
                    value={up.permissionType}
                    onChange={(e) => handleUpdateUserPermission(up.userId, e.target.value as PermissionType)}
                  >
                    {permissionTypes}
                  </Form.Select>
                </td>
                <td>
                  {up.userId && (
                    <div>
                      {(() => {
                        const foundUser = users?.find((u: User) => u.id === up.userId);
                        const userRoles = foundUser?.roles;
                        return userRoles && userRoles.length > 0 ? (
                          <span>{userRoles.map((role: AccessRole) => getLabelFor(role)).join(", ")}</span>
                        ) : (
                          <span className="text-muted">{t(TranslationKeys.SHAREFORM_NOROLES)}</span>
                        );
                      })()}
                    </div>
                  )}
                </td>
                <td>
                  {up.userId ? (
                    up.isNew ? (
                      <Button variant="danger" size="sm" onClick={() => handleRemoveRow(index)}>
                        {t(TranslationKeys.SHAREFORM_REMOVE)}
                      </Button>
                    ) : (
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleRemoveUser(up.userId)}
                        disabled={loadingBtn.grant}
                      >
                        {t(TranslationKeys.SHAREFORM_REMOVE)}
                      </Button>
                    )
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
        <div className="mt-2">
          <Button variant="outline-secondary" onClick={handleAddNewRow}>
            +
          </Button>
        </div>
      </div>

      <div className="pt-2">
        <h5>{t(TranslationKeys.SHAREFORM_ROLES)}</h5>
        <Table striped bordered hover className="align-middle">
          <thead>
            <tr>
              <th>{t(TranslationKeys.SHAREFORM_ROLE)}</th>
              <th>{t(TranslationKeys.SHAREFORM_PERMISSION)}</th>
              <th>{t(TranslationKeys.SHAREFORM_ACTION)}</th>
            </tr>
          </thead>
          <tbody>
            {rolePermissions.map((rp, index) => (
              <tr key={rp.roleId || `new-${index}`}>
                <td>
                  <div className="d-flex align-items-center">
                    {!rp.roleId && rp.isNew ? (
                      <Form.Control
                        type="text"
                        placeholder={t(TranslationKeys.SHAREFORM_SEARCHROLESPLACEHOLDER)}
                        value={rp.searchQuery}
                        onChange={(e) => handleRoleSearchChange(index, e.target.value)}
                      />
                    ) : (
                      <div className="d-flex align-items-center">
                        <span>
                          {rp.roleName
                            ? getLabelFor({
                                id: rp.roleId,
                                name: rp.roleName,
                                system: true,
                              } as AccessRole)
                            : ""}
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="position-relative">
                    <div
                      className="search-results-container"
                      style={{
                        display: !rp.roleId && rp.isNew && rp.searchQuery ? "block" : "none",
                        left: 0,
                        maxHeight: "200px",
                        overflowY: "auto",
                        position: "absolute",
                        right: 0,
                        top: "100%",
                        zIndex: 1000,
                      }}
                    >
                      {!rp.roleId &&
                        rp.isNew &&
                        rp.searchQuery &&
                        getFilteredRoleOptions(rp.searchQuery, rp.roleId).results.length > 0 && (
                          <div
                            className="border rounded p-2 mt-1"
                            style={{
                              backgroundColor: getComputedStyle(document.documentElement).getPropertyValue(
                                "--bs-body-bg"
                              ),
                            }}
                          >
                            {getFilteredRoleOptions(rp.searchQuery, rp.roleId).results.map((role) => (
                              <div
                                key={role.id}
                                className="p-2 hover-highlight"
                                onClick={() => handleRoleSelect(index, role)}
                                style={{ cursor: "pointer" }}
                              >
                                {getLabelFor(role)}
                              </div>
                            ))}
                            {getFilteredRoleOptions(rp.searchQuery, rp.roleId).hasMore && (
                              <div className="text-muted small p-2">
                                {t(TranslationKeys.SHAREFORM_SHOWINGTOPRESULTS)}
                              </div>
                            )}
                          </div>
                        )}
                    </div>
                  </div>
                </td>
                <td>
                  <Form.Select
                    value={rp.permissionType}
                    onChange={(e) => handleUpdateRolePermission(rp.roleId, e.target.value as PermissionType)}
                  >
                    {permissionTypes}
                  </Form.Select>
                </td>
                <td>
                  {rp.roleId ? (
                    rp.isNew ? (
                      <Button variant="danger" size="sm" onClick={() => handleRemoveRoleRow(index)}>
                        {t(TranslationKeys.SHAREFORM_REMOVE)}
                      </Button>
                    ) : (
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleRemoveRole(rp.roleId)}
                        disabled={loadingBtn.grant}
                      >
                        {t(TranslationKeys.SHAREFORM_REMOVE)}
                      </Button>
                    )
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
        <div className="mt-2">
          <Button variant="outline-secondary" onClick={handleAddNewRoleRow}>
            +
          </Button>
        </div>
      </div>

      <div className="text-end mt-3">
        {loadingBtn && (loadingBtn.grant || loadingBtn.updateGrant) ? (
          <button className="btn btn-primary" type="button" disabled>
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            &nbsp;{t(TranslationKeys.SHAREFORM_LOADING)}
          </button>
        ) : (
          <Button className="button" onClick={handleShare} disabled={!hasChanges()}>
            {t(TranslationKeys.SHAREFORM_SHARE)}
          </Button>
        )}
      </div>

      <div className="mt-3 text-muted">
        {data.__type_name === TypeName.Workspace && (
          <p>
            <strong>{t(TranslationKeys.SHAREFORM_NOTE)}:</strong> {t(TranslationKeys.SHAREFORM_NOTEWORKSPACE)}
          </p>
        )}
        {data.__type_name === TypeName.Assistant && (
          <p>
            <strong>{t(TranslationKeys.SHAREFORM_NOTE)}:</strong> {t(TranslationKeys.SHAREFORM_NOTEAGENT)}
          </p>
        )}
      </div>
    </div>
  );
};
