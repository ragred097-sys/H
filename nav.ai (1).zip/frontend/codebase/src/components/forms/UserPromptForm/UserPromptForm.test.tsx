import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import UserPromptForm from "./UserPromptForm";
import { Assistant, Conversation, PermissionType, TypeName } from "../../../lib/Model";
import { ModuleService } from "../../../services/ModuleService";

vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

global.URL.createObjectURL = vi.fn(() => "mock-url");

const mockSuperAgent = {
  __type_name: "AgentWorkflow",
  accessPermission: PermissionType.WRITE,
  agents: [
    {
      id: "agent1",
      type: "Assistant",
    },
    {
      id: "another-agent-id",
      type: "Assistant",
    },
  ],
  attachmentStorages: [],
  createdAt: "2025-05-30T06:56:22.935361",
  creator: {
    __type_name: "User",
    id: "userId-1",
    name: "ishika chandwadkar",
  },
  customSystemInstruction: "",
  dataSourceIds: [],
  description: "test-super-agent",
  favorite: false,
  hidden: false,
  icon: "",
  id: "super-agent-id",
  image: "",
  llmIds: [],
  modifiedAt: "2025-06-17T06:44:45.241522",
  modifier: {
    __type_name: "User",
    id: "userId-1",
    name: "ishika chandwadkar",
  },
  name: "test-super-agent",
  rootAgent: {
    id: "agent1",
    type: "Assistant",
  },
  sampleQuestions: ["What is AI?"],
  systemInstructionIds: [],
  tags: [],
};

const mockAssistant = {
  __type_name: TypeName.Assistant,
  accessPermission: PermissionType.WRITE,
  attachmentStorages: [],
  color: "",
  createdAt: new Date().toISOString(),
  creator: { id: "user2", name: "Agent User" },
  customSystemInstruction: "",
  dataSourceIds: [],
  description: "",
  favorite: false,
  icon: "",
  id: "agent1",
  image: "",
  inputSchema: null,
  llmIds: ["llm2"],
  name: "Test Agent",
  outputSchema: null,
  sampleQuestions: ["Agent Q1", "Agent Q2"],
  systemInstructionIds: [],
  tags: [],
  updatedAt: new Date().toISOString(),
  visibility: "public",
  workflowNodes: [],
};

const mockConversation = {
  createdAt: new Date().toISOString(),
  creator: { id: "user1", name: "Test User" },
  favorite: false,
  id: "conv1",
  llmIds: ["llm1"],
  messages: [],
  name: "Test Conversation",
  tags: [],
  updatedAt: new Date().toISOString(),
  visibility: "public",
};

const mockLlm = {
  __type_name: TypeName.Module,
  createdAt: new Date().toISOString(),
  creationTimestamp: new Date(),
  creator: { id: "user2", name: "Agent User" },
  default: false,
  favorite: false,
  id: "llm2",
  name: "TestAIModel",
  parameters: [],
  specId: "spec2",
  supportedInputs: ["IMAGE", "TEXT"],
  tags: [],
  visibility: "public",
};

const mockChatData = [
  {
    content: "Hello",
    conversationId: "conv1",
    id: "msg1",
    overrides: [],
    parts: [],
    role: "user" as any,
    timestamp: new Date().toISOString(),
  },
  {
    content: "Hi there",
    conversationId: "conv1",
    id: "msg2",
    overrides: [],
    parts: [],
    role: "assistant" as any,
    timestamp: new Date().toISOString(),
  },
];

const mockCurrentAgent = {
  __type_name: TypeName.Assistant,
  llmIds: ["llm1"],
  sampleQuestions: ["What is AI?"],
} as Assistant;

describe("UserPromptForm", () => {
  const mockProps = {
    attachmentsMode: false,
    chatData: [] as any[],
    chatMode: "normal",
    currentAgent: undefined as any,
    currentChat: undefined as Conversation | undefined,
    currentRootAgent: undefined as any,
    disabled: false,
    documentHandler: vi.fn(),
    documents: [],
    handleSubmit: vi.fn(),
    isMasterActionOpen: false,
    openChatOverLay: vi.fn(),
    openDetailsOverLay: vi.fn(),
    refreshChat: vi.fn(),
    responding: false,
    rtxOn: false,
    selectedLlm: {
      __type_name: TypeName.Module,
      createdAt: new Date().toISOString(),
      creationTimestamp: new Date(),
      creator: { id: "user1", name: "System User" },
      default: false,
      favorite: false,
      id: "llm1",
      name: "GPT4o on Azure",
      parameters: [],
      specId: "spec1",
      supportedInputs: ["IMAGE", "TEXT"],
      tags: [],
      visibility: "public",
    },
    setCurrentChat: vi.fn(),
    toggleActions: vi.fn(),
    updateUserMessage: vi.fn(),
    userMessage: "",
    userMessageSetter: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("should enable send button when user types a message", () => {
    const props = {
      ...mockProps,
      userMessage: "Hello, help me?",
    };

    render(<UserPromptForm {...props} />);

    const sendButton = screen.getByRole("button", { name: "" }); // Send button
    expect(sendButton).not.toBeDisabled();
  });

  it("should call userMessageSetter when sample question is clicked", () => {
    const assistantProps = {
      ...mockProps,
      currentAgent: mockCurrentAgent,
    };
    render(<UserPromptForm {...assistantProps} />);

    const sampleQuestion = screen.getByText("What is AI?");
    fireEvent.click(sampleQuestion);

    expect(mockProps.userMessageSetter).toHaveBeenCalledWith("What is AI?");
  });

  const testCases: [string, typeof mockProps][] = [
    ["standalone mode", mockProps],
    [
      "currentAgent as Assistant",
      {
        ...mockProps,
        currentAgent: mockCurrentAgent,
      },
    ],
    [
      "currentAgent as AgentWorkflow",
      {
        ...mockProps,
        currentAgent: mockCurrentAgent,
        currentRootAgent: mockSuperAgent,
      },
    ],
  ];

  it.each(testCases)("should render send button when using %s", (_description, props) => {
    render(<UserPromptForm {...props} />);

    const sendButton = screen.getByRole("button", { name: "" });
    expect(sendButton).toBeInTheDocument();
    expect(sendButton).toBeDisabled();

    const icon = sendButton.querySelector(".bi-send");
    expect(icon).toBeInTheDocument();
  });

  it.each(testCases)(
    "should render conversation history and info buttons as enabled when using %s",
    (_description, props) => {
      render(<UserPromptForm {...props} />);

      const historyButton = screen.getByTitle("chat.conversationHistory");
      const infoButton = screen.getByTitle("chat.agentDetails");

      expect(historyButton).toBeInTheDocument();
      expect(infoButton).toBeInTheDocument();
      expect(historyButton).not.toBeDisabled();
      expect(infoButton).not.toBeDisabled();
    }
  );

  it.each(testCases)(
    "should render upload, share and master action buttons as disabled initially when using %s",
    (_description, props) => {
      render(<UserPromptForm {...props} />);

      const uploadButton = screen.getByTitle("chat.startConversationToUpload");
      const shareButton = screen.getByTitle("chat.shareConversation");
      const masterActionButton = screen.getByTitle("chat.showMasterActions");

      expect(uploadButton).toBeDisabled();
      expect(shareButton).toBeDisabled();
      expect(masterActionButton).toBeDisabled();
    }
  );

  const uploadAndShareEnabledCases: [string, typeof mockProps][] = [
    [
      "standalone mode",
      {
        ...mockProps,
        chatData: mockChatData,
        currentChat: mockConversation,
      },
    ],
    [
      "currentAgent as Assistant",
      {
        ...mockProps,
        chatData: mockChatData,
        currentAgent: mockCurrentAgent,
        currentChat: mockConversation,
      },
    ],
    [
      "currentAgent as AgentWorkflow",
      {
        ...mockProps,
        chatData: mockChatData,
        currentAgent: mockCurrentAgent,
        currentChat: mockConversation,
        currentRootAgent: mockSuperAgent,
      },
    ],
  ];

  it.each(uploadAndShareEnabledCases)(
    "should enable upload and share buttons when currentChat is set using %s",
    (_desc, props) => {
      render(<UserPromptForm {...props} />);

      const uploadButton = screen.getByTitle("chat.addDataToConversation");
      expect(uploadButton).not.toBeDisabled();

      const shareButton = screen.getByTitle("chat.shareConversation");
      expect(shareButton).not.toBeDisabled();
    }
  );

  const chatWithMultipleMessages = Array.from({ length: 6 }, (_, i) => ({
    content: `Message ${i + 1}`,
    conversationId: "conv1",
    id: `${i + 1}`,
    overrides: [],
    parts: [],
    role: i % 2 === 0 ? ("user" as any) : ("assistant" as any),
    timestamp: new Date().toISOString(),
  }));

  const masterActionEnabledCases: [string, typeof mockProps][] = [
    [
      "standalone mode",
      {
        ...mockProps,
        chatData: chatWithMultipleMessages,
      },
    ],
    [
      "currentAgent as Assistant",
      {
        ...mockProps,
        chatData: chatWithMultipleMessages,
        currentAgent: mockCurrentAgent,
      },
    ],
    [
      "currentAgent as AgentWorkflow",
      {
        ...mockProps,
        chatData: chatWithMultipleMessages,
        currentAgent: mockCurrentAgent,
        currentRootAgent: mockSuperAgent,
      },
    ],
  ];

  it.each(masterActionEnabledCases)(
    "should enable master action button when chat has 3 or more messages using %s",
    (_desc, props) => {
      render(<UserPromptForm {...props} />);

      const masterActionButton = screen.getByTitle("chat.showMasterActions");
      expect(masterActionButton).not.toBeDisabled();
    }
  );

  const llmWithoutSupport = {
    __type_name: TypeName.Module,
    createdAt: new Date().toISOString(),
    creationTimestamp: new Date(),
    creator: { id: "user1", name: "System User" },
    default: false,
    favorite: false,
    id: "llm1",
    name: "Generic LLM",
    parameters: [],
    specId: "spec1",
    supportedInputs: [],
    tags: [],
    visibility: "public",
  };

  const llmWithImageTextSupport = {
    ...llmWithoutSupport,
    supportedInputs: ["IMAGE", "TEXT"],
  };

  const placeholderDefault = "Type a message...";
  const placeholderWithSupport = "Type a message or drop an image, or a text file...";

  const placeholderUpdateCases: [string, typeof mockProps, typeof mockProps][] = [
    [
      "agent LLM with dynamic supportedInputs update",
      {
        ...mockProps,
        currentAgent: mockAssistant,
        selectedLlm: llmWithoutSupport,
      },
      {
        ...mockProps,
        currentAgent: mockAssistant,
        selectedLlm: llmWithImageTextSupport,
      },
    ],
    [
      "base assistant LLM with supportedInputs update",
      {
        ...mockProps,
        currentAgent: mockCurrentAgent,
        selectedLlm: llmWithoutSupport,
      },
      {
        ...mockProps,
        currentAgent: mockCurrentAgent,
        selectedLlm: llmWithImageTextSupport,
      },
    ],
  ];

  it.each(placeholderUpdateCases)(
    "should update the input placeholder when selectedLlm changes for %s",
    async (_desc, initialProps, updatedProps) => {
      const { rerender } = render(<UserPromptForm {...initialProps} />);

      const input = screen.getByRole("textbox");
      expect(input).toHaveAttribute("placeholder", placeholderDefault);

      rerender(<UserPromptForm {...updatedProps} />);

      expect(screen.getByRole("textbox")).toHaveAttribute("placeholder", placeholderWithSupport);
    }
  );

  it("should call handleSubmit when send button is clicked", () => {
    const props = {
      ...mockProps,
      userMessage: "Hello world",
    };

    render(<UserPromptForm {...props} />);

    const sendButton = screen.getByRole("button", { name: "" });
    fireEvent.click(sendButton);

    expect(mockProps.handleSubmit).toHaveBeenCalled();
  });

  it("should call handleSubmit when Enter key is pressed without Shift", () => {
    const props = {
      ...mockProps,
      userMessage: "Hello world",
    };

    render(<UserPromptForm {...props} />);

    const textarea = screen.getByRole("textbox");
    fireEvent.keyDown(textarea, { key: "Enter", shiftKey: false });

    expect(mockProps.handleSubmit).toHaveBeenCalled();
  });

  it("should disable text input when responding is true", () => {
    const props = {
      ...mockProps,
      responding: true,
    };

    render(<UserPromptForm {...props} />);

    const textarea = screen.getByRole("textbox");
    expect(textarea).toBeDisabled();
  });

  it('should display "Powered by" text with logo', () => {
    render(<UserPromptForm {...mockProps} />);
    const poweredByText = screen.getByText(/chat.poweredBy/i);
    expect(poweredByText).toBeInTheDocument();

    const logoImg = screen.getByAltText("Provider Logo");
    expect(logoImg).toBeInTheDocument();
    expect(logoImg).toHaveAttribute("src", expect.stringContaining("nvidia"));
  });

  it("should render sample questions from Agent and call userMessageSetter when clicked", () => {
    const userMessageSetter = vi.fn();

    render(<UserPromptForm {...mockProps} currentAgent={mockAssistant} userMessageSetter={userMessageSetter} />);

    const sampleQ1 = screen.getByText("Agent Q1");
    const sampleQ2 = screen.getByText("Agent Q2");
    expect(sampleQ1).toBeInTheDocument();
    expect(sampleQ2).toBeInTheDocument();

    fireEvent.click(sampleQ1);
    expect(userMessageSetter).toHaveBeenCalledWith("Agent Q1");
  });

  it("should not render sample questions if Agent has none", () => {
    const agent = {
      ...mockProps.currentAgent,
      __type_name: TypeName.Assistant,
      sampleQuestions: [],
    };

    render(<UserPromptForm {...mockProps} currentAgent={agent} />);

    expect(screen.queryByRole("button", { name: "Agent Q1" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Agent Q2" })).not.toBeInTheDocument();
  });

  it("should display Agent sample questions above the input box and update input when clicked", () => {
    const agent = {
      ...mockProps.currentAgent,
      __type_name: TypeName.Assistant,
      sampleQuestions: ["Prompt Suggestion 1", "Prompt Suggestion 2"],
    };
    const userMessageSetter = vi.fn();

    render(<UserPromptForm {...mockProps} currentAgent={agent} userMessageSetter={userMessageSetter} />);

    expect(screen.getByText("Prompt Suggestion 1")).toBeInTheDocument();
    expect(screen.getByText("Prompt Suggestion 2")).toBeInTheDocument();

    fireEvent.click(screen.getByText("Prompt Suggestion 2"));
    expect(userMessageSetter).toHaveBeenCalledWith("Prompt Suggestion 2");
  });

  it('should display "Powered by" text with logo and selected model name when agent is provided', async () => {
    const getModuleByIdMock = vi.spyOn(ModuleService, "getModuleById");
    getModuleByIdMock.mockResolvedValue(mockLlm);

    render(<UserPromptForm {...mockProps} currentAgent={mockAssistant} selectedLlm={mockLlm} />);

    screen.debug();

    await waitFor(() => {
      expect(screen.getByText(/TestAIModel/i)).toBeInTheDocument();
    });

    const poweredByText = screen.getByText(/chat.poweredBy/i);
    expect(poweredByText).toBeInTheDocument();

    const logoImg = screen.getByAltText("Provider Logo");
    expect(logoImg).toBeInTheDocument();
    expect(logoImg).toHaveAttribute("src", expect.stringContaining("nvidia"));

    getModuleByIdMock.mockRestore();
  });

  it('should display "Powered by" text with logo and selected model name when super agent is provided', async () => {
    const getModuleByIdMock = vi.spyOn(ModuleService, "getModuleById");
    getModuleByIdMock.mockResolvedValue(mockLlm);

    render(
      <UserPromptForm
        {...mockProps}
        currentAgent={mockAssistant}
        selectedLlm={mockLlm}
        currentRootAgent={mockSuperAgent}
      />
    );

    screen.debug();
    await waitFor(() => {
      expect(screen.getByText(/TestAIModel/i)).toBeInTheDocument();
    });

    const poweredByText = screen.getByText(/chat.poweredBy/i);
    expect(poweredByText).toBeInTheDocument();

    const logoImg = screen.getByAltText("Provider Logo");
    expect(logoImg).toBeInTheDocument();
    expect(logoImg).toHaveAttribute("src", expect.stringContaining("nvidia"));

    getModuleByIdMock.mockRestore();
  });
});
