import { useCallback, useEffect, useRef, useState } from "react";

import { Button, Form, Modal, OverlayTrigger, Spinner, Tooltip } from "react-bootstrap";
import { useDropzone } from "react-dropzone";
import { useTranslation } from "react-i18next";

import nvidia from "../../../assets/images/nvidia.png";
import {
  Agent,
  AgentWorkflow,
  Assistant,
  Attachment,
  ChatMode,
  Conversation,
  Message,
  Module,
  TypeName,
  typeOf,
} from "../../../lib/Model";
import { rightPaneChatIconState } from "../../../stores/useStore";
import { TranslationKeys } from "../../../types/translation-keys";
import {
  createChat,
  getOrCreateConvoDataSource,
  updateAgentWithAttachmentStorageForVss,
} from "../../../utils/crudUtils";
import { getPlaceholderText } from "../../../utils/translationUtils";
import ShareConversation from "../../chat/sharedConversation/ShareConversation";
import { AttachedFile } from "../../general/AttachedFile";
import { ChatDragOverlay } from "../../general/ChatDragOverlay/ChatDragOverlay";
import { DocumentPreviewList } from "../../general/DocumentPreviewList";
import UploadDataForm from "../UploadDataForm/UploadDataForm";
import { ModuleService } from "./../../../services/ModuleService";

const INPUT_CONTAINER_STYLES = {
  minHeight: "50px",
  minWidth: "35vw",
  overflow: "hidden",
  transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
} as const;

export default function UserPromptForm({
  attachmentsMode,
  chatData,
  chatMode,
  currentAgent,
  currentChat,
  currentRootAgent,
  disabled,
  documentHandler,
  documents,
  handleSubmit,
  isMasterActionOpen,
  onCancel,
  openChatOverLay,
  openDetailsOverLay,
  refreshChat,
  responding,
  rtxOn,
  selectedLlm,
  setCurrentChat,
  toggleActions,
  toggleAttachments,
  updateUserMessage,
  userMessage,
  userMessageSetter,
}: {
  openChatOverLay: () => void;
  openDetailsOverLay: () => void;
  chatData: Message[];
  currentAgent: Assistant | AgentWorkflow;
  userMessage: string;
  updateUserMessage: (e: React.ChangeEvent<HTMLInputElement>) => void;
  responding: boolean;
  handleSubmit: () => void;
  setCurrentChat: (conversation: Conversation) => void;
  currentChat?: Conversation;
  refreshChat: () => void;
  rtxOn: boolean;
  toggleActions: () => void;
  toggleAttachments?: () => void;
  userMessageSetter?: (msg: string) => void;
  documents: (Attachment | AttachedFile)[];
  documentHandler: (docs: (Attachment | AttachedFile)[]) => void;
  selectedLlm?: Module;
  isMasterActionOpen?: boolean;
  attachmentsMode?: boolean;
  disabled?: boolean;
  currentRootAgent?: Assistant | Agent | null;
  chatMode: string | undefined;
  onCancel?: () => void;
}) {
  const [showUpload, setShowUpload] = useState(false);
  const [llm, setLlm] = useState<Module>();
  const [dropLoading, setDropLoading] = useState(false);
  const [dropError, setDropError] = useState(false);
  const [dropErrorMessage, setDropErrorMessage] = useState("");
  const submitButtonRef = useRef<HTMLButtonElement>(null); // Add ref for submit button
  const [lineCount, setLineCount] = useState(1);
  const textareaRef = useRef<HTMLTextAreaElement | null>(null); // Add ref for textarea
  const [showShareConversation, setShowShareConversation] = useState(false);

  const { t } = useTranslation();

  const [isDragging, setIsDragging] = useState(false);
  const dragCounter = useRef(0);
  const { setIsChatUploadOpen, setIsSharedChatOpen } = rightPaneChatIconState();
  useEffect(() => {
    if (chatMode === "superagent") {
      if (currentRootAgent?.__type_name === TypeName.Assistant) {
        ModuleService.getModuleById((currentRootAgent as Assistant)?.llmIds[0]).then((res) => {
          setLlm(res);
        });
      }
      if (currentRootAgent?.__type_name === TypeName.Agent) {
        ModuleService.getModuleById((currentRootAgent as Agent)?.llmId).then((res) => {
          setLlm(res);
        });
      }
    } else {
      if (currentAgent && (currentAgent as Assistant)?.llmIds?.length) {
        ModuleService.getModuleById((currentAgent as Assistant)?.llmIds[0]).then((res) => {
          setLlm(res);
        });
      }
    }
  }, [chatMode, currentAgent]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (dropError) {
      timer = setTimeout(() => {
        setDropError(false);
      }, 1500);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [dropError]);

  const { getInputProps, getRootProps } = useDropzone({
    noClick: true,
    noKeyboard: true,
    onDrop: async (acceptedFiles) => {
      setIsDragging(false);
      setDropLoading(true);
      try {
        const newFiles = acceptedFiles.map((file) => new AttachedFile(file));

        const unsupportedFile = newFiles.find((file) => !selectedLlm?.supportedInputs.includes(file.type));
        if (unsupportedFile) {
          throw new Error(t(TranslationKeys.USERPROMPTFORM_UNSUPPORTEDFILETYPE));
        }

        // Prevent duplicates by checking file names and sizes

        const existingFileKeys = new Set(
          documents.map((doc) => (doc instanceof AttachedFile ? `${doc.name}-${doc.size}` : ""))
        );

        const uniqueNewFiles = newFiles.filter((file) => !existingFileKeys.has(`${file.name}-${file.size}`));

        setDropLoading(false);

        documentHandler([...documents, ...uniqueNewFiles]);
      } catch (error) {
        setDropLoading(false);
        setDropError(true);
        if (error instanceof Error) {
          setDropErrorMessage(error.message);
        } else {
          setDropErrorMessage(String(error));
        }
      }
    },
  });

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current += 1;
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current -= 1;
    if (dragCounter.current <= 0) {
      setIsDragging(false);
    }
  };

  const handleNativeDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    dragCounter.current = 0;
    setIsDragging(false);

    const data = e.dataTransfer.getData("custom/entity");
    if (data) {
      e.stopPropagation();
      const entity = JSON.parse(data);

      if (typeOf(entity) === TypeName.Attachment) {
        const newAttachment = entity as Attachment;

        const isDuplicate = documents.some((doc) => doc.id === newAttachment.id || doc.name === newAttachment.name);

        if (!isDuplicate) {
          documentHandler([...documents, newAttachment]);
        }
      }
    }
  };

  const onDragOver = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    // if (event.dataTransfer?.types?.includes("custom/entity")) {
    //   event.dataTransfer.dropEffect = 'copy';
    // }
  };

  const dragEvents = {
    onClick: (e: React.MouseEvent) => e.stopPropagation(),
    onDragEnter: handleDragEnter,
    onDragLeave: handleDragLeave,
    onDragOver: onDragOver,
    onDrop: handleNativeDrop,
  };
  const rootProps = getRootProps(dragEvents);

  const inputProps = getInputProps({
    onClick: (e) => e.stopPropagation(), // Prevent file picker from opening
  });

  const handleShowUpload = async () => {
    if (!currentChat && rtxOn) {
      if (currentAgent?.__type_name === TypeName.Assistant) {
        await updateAgentWithAttachmentStorageForVss(currentAgent as Assistant);
      } else {
        const llmId =
          currentRootAgent && currentRootAgent?.__type_name === TypeName?.Assistant
            ? (currentRootAgent as Assistant)?.llmIds[0]
            : (currentRootAgent as Agent)?.llmId;
        await updateAgentWithAttachmentStorageForVss(currentAgent as AgentWorkflow, llmId);
      }
      //Create a conversation
      createChat(
        chatMode as string,
        currentAgent as Assistant,
        "Video Summary" as string,
        chatMode === "superagent"
          ? currentRootAgent?.__type_name === TypeName.Agent
            ? (currentRootAgent as Agent)?.llmId
            : (currentRootAgent as Assistant)?.llmIds[0]
          : ((currentAgent as Assistant).llmIds[0] as string)
      ).then((chat) => {
        if (chat) {
          setCurrentChat(chat);
          getOrCreateConvoDataSource(chat).then((res) => {
            console.debug("Linking new chat to data source: ", res);
          });
        }
      });
    }
    setShowUpload(true);
    setIsChatUploadOpen(true);
  };
  const calculateLines = () => {
    if (!textareaRef.current) {
      return 0;
    }
    const computedStyle = window.getComputedStyle(textareaRef?.current);
    const lineHeight = parseFloat(computedStyle.lineHeight);
    const textareaHeight = textareaRef?.current.scrollHeight; // Get the scrollHeight of the textarea
    const lineCount = Math.floor(textareaHeight / lineHeight); // Calculate number of lines
    return lineCount;
  };
  useEffect(() => {
    if (textareaRef.current) {
      const res = calculateLines(); // Calculate lines whenever the text changes
      if (userMessage.length == 0) {
        setLineCount(1);
      } else {
        setLineCount(res);
      }
    }
  }, [userMessage]);

  const calculateHeight = useCallback(
    (lineCount: number) => {
      const baseHeight = 50; // Minimum height (when lineCount is low)
      const heightPerLine = 20;
      // Adjust height based on lineCount
      return baseHeight + (lineCount >= 2 ? (lineCount - 2) * heightPerLine + (lineCount - 0.2) : 0.5);
    },
    [lineCount]
  );

  // const onDragOver = (event:React.DragEvent<HTMLDivElement>) => {
  //   event.preventDefault();
  //   if (event.dataTransfer?.types?.includes("custom/entity")) {
  //     event.dataTransfer.dropEffect = 'copy';
  //   }
  // };

  const handleShare = () => {
    setShowShareConversation(true);
    setIsSharedChatOpen(true);
  };

  const submitButtonDisabled = responding || (!userMessage.trim() && documents.length === 0);

  const SampleQuestions = ({ onSelect, questions }: { questions: string[]; onSelect: (q: string) => void }) => {
    return (
      <div>
        {questions.map((q, i) => (
          <Button
            key={i}
            variant="outline"
            className="navai-button ps-3 pe-3 mb-2 me-2"
            size="sm"
            style={{ fontSize: "12px" }}
            onClick={() => onSelect(q)}
          >
            {q}
          </Button>
        ))}
      </div>
    );
  };
  return (
    <>
      <div
        className="d-flex flex-row"
        style={{
          boxSizing: "border-box",
          marginRight: attachmentsMode ? "30%" : "0",
          width: attachmentsMode ? "50%" : "70%",
        }}
      >
        <div className="chat-box-container">
          <div id="userPromptArea" className="mb-1">
            {currentRootAgent?.__type_name === TypeName.Assistant &&
            Array.isArray((currentRootAgent as Assistant).sampleQuestions) &&
            (currentRootAgent as Assistant).sampleQuestions.length > 0 ? (
              <SampleQuestions
                questions={(currentRootAgent as Assistant).sampleQuestions}
                onSelect={(q: string) => userMessageSetter?.(q)}
              />
            ) : Array.isArray((currentAgent as Assistant)?.sampleQuestions) &&
              (currentAgent as Assistant).sampleQuestions.length > 0 ? (
              <SampleQuestions
                questions={(currentAgent as Assistant).sampleQuestions}
                onSelect={(q: string) => userMessageSetter?.(q)}
              />
            ) : null}
            <div className="d-flex justify-content-center align-items-center flex-row">
              <div className="chat-box">
                <div
                  className="flex-grow-1 position-relative"
                  style={{
                    opacity: "0.9",
                    ...INPUT_CONTAINER_STYLES,
                    height:
                      isDragging || dropError || documents.length > 0
                        ? "120px"
                        : lineCount >= 5
                          ? `${calculateHeight(5)}px`
                          : `${calculateHeight(lineCount)}px`,
                  }}
                  {...rootProps}
                >
                  <input
                    {...inputProps}
                    placeholder={!isDragging && !dropError ? getPlaceholderText(selectedLlm) : ""}
                  />
                  {documents.length > 0 && (
                    <DocumentPreviewList
                      documents={documents as AttachedFile[]}
                      onRemove={(index) => {
                        documentHandler(documents.filter((_, i) => i !== index));
                      }}
                    />
                  )}
                  <Form.Group className="d-flex align-items-center flex-grow-1 position-relative">
                    <Form.Control
                      as="textarea"
                      ref={textareaRef}
                      value={userMessage}
                      onChange={updateUserMessage}
                      onClick={(e) => e.stopPropagation()} // Prevent click from opening upload dialog
                      style={{
                        backgroundColor: "transparent",
                        borderColor: "transparent",
                        boxShadow: "none",
                        height:
                          documents.length > 0
                            ? "45px"
                            : isDragging || dropError
                              ? "180px"
                              : userMessage.length === 0
                                ? "1.5em"
                                : lineCount >= 5
                                  ? `${calculateHeight(5)}px`
                                  : `${calculateHeight(lineCount)}px`,
                        lineHeight: isDragging || dropError ? "2" : "1.5",
                        maxHeight: isDragging || dropError ? "" : `${calculateHeight(5)}px`,
                        outline: "none",
                        overflowY: lineCount >= 5 ? "scroll" : "hidden",
                        resize: "none",
                        transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                      }}
                      disabled={disabled || responding}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSubmit();
                        }
                      }}
                      placeholder={isDragging || dropError ? "" : getPlaceholderText(selectedLlm)}
                    />
                    {isDragging && <ChatDragOverlay hasDocuments={documents.length > 0} />}
                    {dropLoading && (
                      <div
                        className="position-absolute w-100 d-flex flex-column justify-content-center align-items-center"
                        style={{
                          borderRadius: "25px",
                          height: "180px",
                          top: "0",
                          transform: "translateY(-15%)",
                          zIndex: 10,
                        }}
                      >
                        <Spinner animation="border" role="status">
                          <span className="visually-hidden">{t(TranslationKeys.ROLES_LOADING)}</span>
                        </Spinner>
                      </div>
                    )}
                    {dropError && (
                      <div
                        className="position-absolute w-100 d-flex flex-column justify-content-center align-items-center"
                        style={{
                          animation: "fadeIn 0.2s ease-in",
                          borderRadius: "25px",
                          height: "180px",
                          top: "0",
                          transform: "translateY(-15%)",
                          zIndex: 10,
                        }}
                      >
                        <i className="bi bi-exclamation-triangle text-danger" style={{ fontSize: "2rem" }}></i>
                        <span className="text-danger">
                          {dropErrorMessage || t(TranslationKeys.CHAT_ERRORORUNSUPPORTEDFILE)}
                        </span>
                      </div>
                    )}
                  </Form.Group>
                </div>
                {/* FOOTER */}
                <div className="d-flex flex-wrap-row justify-content-between bottom-0 w-100">
                  <div className="d-flex flex-row flex-wrap align-items-center" style={{ minWidth: "0px" }}>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={<Tooltip>{t(TranslationKeys.CHAT_CONVERSATIONHISTORY)}</Tooltip>}
                    >
                      <button
                        onClick={openChatOverLay}
                        className="extra-btn"
                        title={t(TranslationKeys.CHAT_CONVERSATIONHISTORY)}
                        aria-label={t(TranslationKeys.CHAT_CONVERSATIONHISTORY)}
                        style={{
                          height: "30px",
                          marginLeft: "8px",
                          marginRight: "0px",
                          width: "30px",
                        }}
                      >
                        <i className="bi bi-clock-history text-light"></i>
                      </button>
                    </OverlayTrigger>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={<Tooltip>{t(TranslationKeys.CHAT_AGENTDETAILS)}</Tooltip>}
                    >
                      <button
                        onClick={openDetailsOverLay}
                        className="extra-btn"
                        title={t(TranslationKeys.CHAT_AGENTDETAILS)}
                        style={{
                          height: "30px",
                          marginRight: "0px",
                          width: "30px",
                        }}
                      >
                        <i className="bi bi-info-lg text-light"></i>
                      </button>
                    </OverlayTrigger>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={
                        <Tooltip className="navai-tooltip">
                          {rtxOn ? (
                            <>{t(TranslationKeys.CHAT_UPLOADVIDEOTOOLTIP)}</>
                          ) : !currentChat?.name ? (
                            <>{t(TranslationKeys.CHAT_STARTCONVERSATIONTOUPLOAD)}</>
                          ) : (
                            <>{t(TranslationKeys.CHAT_ADDDATATOCONVERSATION)}</>
                          )}
                        </Tooltip>
                      }
                    >
                      <button
                        onClick={handleShowUpload}
                        disabled={rtxOn ? false : !currentChat?.name}
                        className="extra-btn"
                        title={
                          rtxOn
                            ? t(TranslationKeys.CHAT_UPLOADVIDEOTOOLTIP)
                            : !currentChat?.name
                              ? t(TranslationKeys.CHAT_STARTCONVERSATIONTOUPLOAD)
                              : t(TranslationKeys.CHAT_ADDDATATOCONVERSATION)
                        }
                        style={{
                          height: "30px",
                          width: "30px",
                        }}
                      >
                        <i className="bi bi-upload text-light"></i>
                      </button>
                    </OverlayTrigger>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={
                        <Tooltip className="navai-tooltip">
                          <>{t(TranslationKeys.CHAT_SHARECONVERSATION)}</>
                        </Tooltip>
                      }
                    >
                      <button
                        onClick={handleShare}
                        disabled={!currentChat?.name}
                        className="extra-btn"
                        title={t(TranslationKeys.CHAT_SHARECONVERSATION)}
                        style={{
                          height: "30px",
                          width: "30px",
                        }}
                      >
                        <i className="bi bi-share text-light"></i>
                      </button>
                    </OverlayTrigger>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={
                        <Tooltip className="navai-tooltip">
                          <>{t(TranslationKeys.ATTACHMENTS_UPLOADATTACHMENT)}</>
                        </Tooltip>
                      }
                    >
                      <button
                        onClick={toggleAttachments}
                        disabled={chatData?.length == 0 || chatMode == ChatMode.Standalone}
                        className="extra-btn"
                        title={t(TranslationKeys.ATTACHMENTS_UPLOADATTACHMENT)}
                        style={{
                          height: "30px",
                          width: "30px",
                        }}
                      >
                        <i className="bi bi-paperclip fw-bold" style={{ fontSize: "1.2rem" }}></i>
                      </button>
                    </OverlayTrigger>
                    <OverlayTrigger
                      placement="top-end"
                      delay={{ hide: 500, show: 750 }}
                      overlay={
                        <Tooltip className="navai-tooltip">
                          {isMasterActionOpen == false
                            ? t(TranslationKeys.CHAT_SHOWMASTERACTIONS)
                            : t(TranslationKeys.CHAT_HIDEMASTERACTIONS)}
                        </Tooltip>
                      }
                    >
                      <div>
                        <Button
                          variant="transparent"
                          onClick={toggleActions}
                          disabled={chatData.length >= 6 ? false : true}
                          style={{
                            border: "transparent",
                          }}
                          title={
                            isMasterActionOpen == false
                              ? t(TranslationKeys.CHAT_SHOWMASTERACTIONS)
                              : t(TranslationKeys.CHAT_HIDEMASTERACTIONS)
                          }
                        >
                          <i className="bi bi-activity extra-btn"></i>
                        </Button>
                      </div>
                    </OverlayTrigger>
                  </div>
                  <div
                    className="position-relative"
                    style={{
                      display: isDragging || dropError ? "none" : "block",
                      right: documents.length > 0 ? "25px" : "8px",
                    }}
                  >
                    {responding ? (
                      <Button
                        variant="transparent"
                        style={{
                          border: "transparent",
                        }}
                        onClick={onCancel}
                      >
                        <i
                          className="bi bi-stop-circle"
                          style={{
                            fontSize: "1.3rem",
                          }}
                        ></i>
                      </Button>
                    ) : (
                      <Button
                        ref={submitButtonRef}
                        variant="transparent"
                        onClick={handleSubmit}
                        style={{
                          border: "transparent",
                          opacity: submitButtonDisabled ? 0.5 : 1,
                        }}
                        disabled={submitButtonDisabled}
                      >
                        <i
                          className="bi bi-send text-light"
                          style={{
                            fontSize: "1.3rem",
                          }}
                        ></i>
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
            <div
              className="text-end align-items-center pt-1 pe-2"
              style={{
                marginRight: attachmentsMode ? "1em" : "0em",
              }}
            >
              <span className="ms-2 me-2 text-light" style={{ fontSize: "0.7em" }}>
                {`${llm?.name || ""} ${t(TranslationKeys.CHAT_POWEREDBY)}`}
              </span>
              <img src={nvidia} alt="Provider Logo" height="18px" style={{ borderRadius: "5px" }} />
            </div>
          </div>
        </div>
        <Modal
          size="lg"
          show={showUpload}
          onHide={() => {
            setShowUpload(false);
            setIsChatUploadOpen(false);
          }}
          backdrop="static"
          centered
          className="text-light custom-modal-backdrop "
        >
          <Modal.Header closeButton>
            <Modal.Title>
              {rtxOn
                ? t(TranslationKeys.CHAT_LOADVIDEOFORPROCESSING)
                : t(TranslationKeys.CHAT_ADDDATATO, { name: currentChat?.name })}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <UploadDataForm
              conversation={currentChat || undefined}
              handleClose={() => {
                setShowUpload(false);
                refreshChat();
                setIsChatUploadOpen(false);
              }}
              selectedAi={selectedLlm}
            />
          </Modal.Body>
        </Modal>
      </div>

      {/* Show Share Conversation */}
      {showShareConversation && currentChat && (
        <ShareConversation
          conversationId={currentChat?.id}
          show={showShareConversation}
          handleClose={() => {
            setShowShareConversation(false);
            setIsSharedChatOpen(false);
          }}
        />
      )}
    </>
  );
}
