import { useEffect, useState } from "react";

import { Button, Form, FormGroup } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AssetForm, Assistant } from "../lib/Model";
import { assetFormStore } from "../stores/useStore";
import { TranslationKeys } from "../types/translation-keys";
import { PROMPT_SUGGESTION_MIN_LENGTH } from "../utils/constants";
import { notificationFormatter } from "../utils/stringUtils";

/**
 * Form component for managing prompt suggestions
 * Allows adding, editing and removing prompt suggestions with validation
 *
 * @param handleClose - Function to close the form
 * @param initialData - Optional initial Assistant data for editing existing suggestions
 * @param onUpdateAssetForm - Optional callback when form is updated with new suggestions
 */
export const SuggestionForm = ({
  handleClose,
  initialData,
  onUpdateAssetForm,
}: {
  handleClose: () => void;
  initialData?: Assistant;
  onUpdateAssetForm?: (
    updatedAssetData: {
      fieldName: keyof AssetForm;
      value: string[];
    }[],
    assetForm: AssetForm
  ) => void;
}) => {
  const { t } = useTranslation();
  // State for managing suggestions and validation
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [error, setError] = useState<string>("");
  const [newEntry, setNewEntry] = useState<string>("");
  const [newEntryError, setNewEntryError] = useState<string>("");
  const [fieldErrors, setFieldErrors] = useState<string[]>([]);
  const assetForm = assetFormStore((state) => state);

  // Initialize suggestions from asset form store data
  useEffect(() => {
    if (assetForm.suggestions && assetForm.suggestions.length > 0) {
      setSuggestions(assetForm.suggestions ?? []);
      setFieldErrors(new Array(assetForm.suggestions.length).fill(""));
    }
  }, [assetForm.suggestions]);

  /**
   * Handles changes to existing suggestion entries
   * Validates entry length and updates errors accordingly
   */
  const handleFormData = (index: number) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const newSuggestions = [...suggestions];
    const newFieldErrors = [...fieldErrors];
    const value = e.target.value;

    newSuggestions[index] = value;

    if (!value.trim()) {
      newFieldErrors[index] = t(TranslationKeys.ERRORMESSAGES_FIELDCANNOTBEEMPTY);
    } else if (value.length < PROMPT_SUGGESTION_MIN_LENGTH) {
      newFieldErrors[index] = notificationFormatter(t(TranslationKeys.ERRORMESSAGES_PROMPTSUGGESTIONMINLENGTHERROR), [
        PROMPT_SUGGESTION_MIN_LENGTH.toString(),
      ]);
    } else {
      newFieldErrors[index] = "";
    }

    setFieldErrors(newFieldErrors);
    setSuggestions(newSuggestions);
  };

  /**
   * Handles changes to the new suggestion entry field
   * Clears error when entry becomes valid
   */
  const handleNewEntry = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewEntry(e.target.value);

    if (!(e.target.value.length > 0 && e.target.value.length < PROMPT_SUGGESTION_MIN_LENGTH)) {
      setNewEntryError("");
    }
  };

  /**
   * Removes a suggestion at the specified index
   */
  const handleRemove = (index: number) => {
    const newSuggestions = suggestions.filter((_, i) => i !== index);
    const newFieldErrors = fieldErrors.filter((_, i) => i !== index);

    setSuggestions(newSuggestions);
    setFieldErrors(newFieldErrors);
    setError("");
  };

  /**
   * Adds a new suggestion if it meets minimum length requirements
   */
  const addSuggestion = () => {
    if (newEntry.length < PROMPT_SUGGESTION_MIN_LENGTH) {
      setNewEntryError(
        notificationFormatter(t(TranslationKeys.ERRORMESSAGES_PROMPTSUGGESTIONMINLENGTHERROR), [
          PROMPT_SUGGESTION_MIN_LENGTH.toString(),
        ])
      );

      return;
    }

    setSuggestions([...suggestions, newEntry]);
    setFieldErrors([...fieldErrors, ""]);
    setNewEntry("");
    setNewEntryError("");
  };

  /**
   * Handles form submission
   * Validates all entries and updates asset form if valid
   */
  const handleCreate = () => {
    // If there's text in the new entry field, add it first
    if (newEntry.length > 0) {
      if (newEntry.length < PROMPT_SUGGESTION_MIN_LENGTH) {
        setNewEntryError(
          notificationFormatter(t(TranslationKeys.ERRORMESSAGES_PROMPTSUGGESTIONMINLENGTHERROR), [
            PROMPT_SUGGESTION_MIN_LENGTH.toString(),
          ])
        );
        return;
      }
      setSuggestions([...suggestions, newEntry]);
    }

    const allSuggestions = newEntry.length > 0 ? [...suggestions, newEntry] : suggestions;

    const newFieldErrors = allSuggestions.map((suggestion) => {
      if (!suggestion.trim()) {
        return t(TranslationKeys.ERRORMESSAGES_FIELDCANNOTBEEMPTY);
      }

      if (suggestion.length < PROMPT_SUGGESTION_MIN_LENGTH) {
        return notificationFormatter(t(TranslationKeys.ERRORMESSAGES_PROMPTSUGGESTIONMINLENGTHERROR), [
          PROMPT_SUGGESTION_MIN_LENGTH.toString(),
        ]);
      }

      return "";
    });

    setFieldErrors(newFieldErrors);

    if (newFieldErrors.some((error) => error !== "")) {
      return;
    }

    if (onUpdateAssetForm) {
      onUpdateAssetForm([{ fieldName: "suggestions", value: allSuggestions }], assetForm);
    }

    handleClose();
  };

  // Handle keyboard submission of new entry
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      addSuggestion();
    }
  };

  return (
    <>
      <div className="d-flex flex-column w-100">
        <Form className="w-100" onSubmit={(e) => e.preventDefault()}>
          <div className="mb-4">
            <h6 className="text-muted mb-3">{t(TranslationKeys.MESSAGES_PROMPTSUGGESTIONSNOTES)}</h6>
          </div>

          <div className="mb-3">
            <h6 className="mb-3 fw-bold">{t(TranslationKeys.MESSAGES_SYSTEMPROMPTS)}</h6>
            {suggestions?.length > 0 && (
              <>
                {suggestions.map((el, index) => (
                  <div key={index} className="d-flex flex-column mb-2">
                    <div className="d-flex flex-row align-items-center">
                      <div className="me-2 text-muted">{index + 1}.</div>
                      <Form.Control
                        className="flex-grow-1"
                        type="text"
                        value={el}
                        onChange={handleFormData(index)}
                        isInvalid={fieldErrors[index] !== ""}
                      />
                      <Button
                        className="ms-2 d-flex align-items-center"
                        variant="transparent"
                        onClick={() => handleRemove(index)}
                      >
                        <i className="bi bi-trash3 text-danger"></i>
                      </Button>
                    </div>
                    {fieldErrors[index] && <div className="text-danger mt-1 ms-4">{fieldErrors[index]}</div>}
                  </div>
                ))}
              </>
            )}

            <FormGroup className="mt-2">
              <div className="d-flex flex-row align-items-center">
                <div className="me-2 text-muted">{suggestions.length + 1}.</div>
                <Form.Control
                  className="flex-grow-1"
                  type="text"
                  value={newEntry}
                  onChange={handleNewEntry}
                  onKeyDown={handleKeyDown}
                  placeholder={t(TranslationKeys.MESSAGES_PROMPTSUGGESTIONPLACEHOLDER)}
                  isInvalid={!!newEntryError}
                  autoFocus
                />
                <Button
                  onClick={addSuggestion}
                  className="ms-2 d-flex align-items-center"
                  variant="primary"
                  disabled={newEntry.length === 0}
                >
                  <i className="bi bi-plus-lg"></i>
                </Button>
              </div>
              {newEntryError && <div className="text-danger mt-1 ms-4">{newEntryError}</div>}
            </FormGroup>

            {error && <div className="text-danger mt-2">{error}</div>}
          </div>
        </Form>
      </div>
      <div className="text-end pt-2">
        <Button className="button" disabled={fieldErrors.some((error) => error !== "")} onClick={handleCreate}>
          {!initialData
            ? t(TranslationKeys.MESSAGES_SAVEPROMPTS, "Save Prompt/s")
            : t(TranslationKeys.MESSAGES_UPDATEPROMPTS, "Update Prompt/s")}
        </Button>
      </div>
    </>
  );
};
