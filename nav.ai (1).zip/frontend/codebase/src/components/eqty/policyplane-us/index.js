import * as e from "react";
import t, {
  useState as a,
  useContext as c,
  memo as d,
  useEffect as i,
  useReducer as l,
  useLayoutEffect as m,
  useRef as n,
  useMemo as o,
  createContext as r,
  useCallback as s,
  forwardRef as w,
} from "react";

import V from "react-markdown";

import { useGSAP as y } from "@gsap/react";
import {
  addEdge as E,
  ReactFlow as b,
  useEdgesState as f,
  getBezierPath as g,
  useNodesState as h,
  Handle as p,
  Position as u,
} from "@xyflow/react";
import "@xyflow/react/dist/base.css";
import { DockviewDefaultTab as D, DockviewReact as H } from "dockview";
import "dockview/dist/styles/dockview.css";
import v from "gsap";
import {
  UserCheck as A,
  Clock as I,
  Terminal as L,
  CheckCircle as M,
  ExternalLink as N,
  AlertTriangle as O,
  Expand as P,
  Server as R,
  Database as S,
  Shield as T,
  CircleAlert as k,
} from "lucide-react";
import { create as x } from "zustand";
import { combine as C } from "zustand/middleware";

const _ = ({ children: e, responsiveRender: r, outsideGridRender: l }) => {
  const o = n(null),
    [s, c] = a({ width: 0, height: 0 }),
    d = 40;
  return (
    i(() => {
      const resizeHandler = () => {
        const element = o.current;
        if (!element) return;
        const t = element.offsetWidth,
          n = element.offsetHeight,
          a = Math.floor(t / d),
          i = Math.floor(n / d);
        c({ width: a * d, height: i * d });
      };
      return (resizeHandler(), window.addEventListener("resize", resizeHandler), () => window.removeEventListener("resize", resizeHandler));
    }, []),
    t.createElement(
      "div",
      { className: "component-container" },
      r && r(),
      !r &&
        t.createElement(
          "div",
          { className: "tw-pb-14 tw-pt-12 tw-px-5 tw-w-full tw-h-full tw-overflow-hidden tw-relative" },
          t.createElement(
            "div",
            { className: "tw-w-full tw-h-full tw-relative tw-flex tw-items-center tw-justify-center" },
            t.createElement(
              "div",
              { ref: o, className: "tw-absolute tw-inset-0 tw-z-50 tw-flex tw-justify-center" },
              t.createElement(
                "div",
                {
                  className: "tw-relative tw-shadow-[4px_4px_10px_1px_rgba(0,0,0,0.18)] tw-flex tw-justify-center",
                  style: {
                    width: s.width,
                    height: s.height,
                    backgroundImage:
                      "\n                  linear-gradient(to right, rgba(65,66,67,0.2) 1px, transparent 1px),\n                  linear-gradient(to bottom, rgba(65,66,67,0.2) 1px, transparent 1px)\n                ",
                    backgroundSize: "40px 40px",
                    borderRight: "1px solid rgba(65,66,67,0.2)",
                    borderBottom: "1px solid rgba(65,66,67,0.2)",
                  },
                },
                t.createElement("div", { className: "tw-relative tw-z-10 tw-w-full tw-max-w-[1736px] tw-h-full " }, e)
              )
            )
          ),
          l && l()
        )
    )
  );
};
function F(e, t) {
  let n;
  switch (t.type) {
    case "START_PIPELINE":
      n = { ...e, status: "running", startTime: Date.now() };
      break;
    case "PAUSE_PIPELINE":
      n = { ...e, status: "paused" };
      break;
    case "CANCEL_PIPELINE":
      n = { ...e, status: "cancelled", endTime: Date.now() };
      break;
    case "COMPLETE_PIPELINE":
      n = { ...e, status: "completed", endTime: Date.now() };
      break;
    case "UPDATE_NODE_STATUS":
      n = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            status: t.payload.status,
            ...("running" === t.payload.status ? { startTime: Date.now() } : {}),
          },
        },
      };
      break;
    case "ADD_LOG":
      n = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            logs: [...e.nodes[t.payload.nodeId].logs, t.payload.log],
          },
        },
      };
      break;
    case "COMPLETE_NODE":
      const a = e.stats?.completedNodes || 0;
      n = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            status: "completed",
            endTime: Date.now(),
            outputs: t.payload.outputs || [],
          },
        },
        stats: { ...e.stats, completedNodes: a + 1 },
      };
      break;
    case "OVERRIDE_GUARDRAIL":
      n = {
        ...e,
        userOverrides: [
          ...e.userOverrides,
          { nodeId: e.activeGuardrail?.nodeId || "", timestamp: t.payload.timestamp, reason: t.payload.reason },
        ],
        activeGuardrail: null,
      };
      break;
    case "REMEDIATE_GUARDRAIL":
      n = {
        ...e,
        userRemediations: [
          ...e.userRemediations,
          { nodeId: e.activeGuardrail?.nodeId || "", timestamp: t.payload.timestamp, reason: t.payload.reason },
        ],
        activeGuardrail: null,
      };
      break;
    default:
      return e;
  }
  return n;
}
class U {
  constructor(e, t) {
    ((this.nodeMetrics = new Map()),
      (this.checkInterval = null),
      (this.config = e),
      (this.dispatch = t),
      this.initializeNodeMetrics());
  }
  initializeNodeMetrics() {
    Object.entries(this.config.nodes).forEach(([e, t]) => {
      const n = t.dependencies?.map((e) => e.nodeId) || [];
      this.nodeMetrics.set(e, { phase: n.length ? "waiting" : "ready", waitingOn: n.length ? n : void 0, attempts: 0 });
    });
  }
  start() {
    ((this.checkInterval = setInterval(() => this.orchestrationCycle(), 500)),
      this.logPipelineState("Pipeline Started"));
  }
  logPipelineState(e) {
    (console.group(`Pipeline State - ${e}`),
      console.log("Timestamp:", new Date().toISOString()),
      this.nodeMetrics.forEach((e, t) => {
        console.log(`Node ${t}:`, { phase: e.phase, waitingOn: e.waitingOn, attempts: e.attempts });
      }),
      console.groupEnd());
  }
  orchestrationCycle() {
    let e = !1;
    (this.nodeMetrics.forEach((t, n) => {
      if ("waiting" === t.phase) {
        const n =
          t.waitingOn?.filter((e) => {
            const t = this.nodeMetrics.get(e);
            return !t || "completed" !== t.phase;
          }) || [];
        0 === n.length ? ((t.phase = "ready"), (t.waitingOn = void 0), (e = !0)) : (t.waitingOn = n);
      }
    }),
      this.nodeMetrics.forEach((t, n) => {
        "ready" === t.phase && (this.startNode(n), (e = !0));
      }),
      e && this.logPipelineState("Cycle Update"),
      Array.from(this.nodeMetrics.values()).every((e) => "completed" === e.phase) && this.cleanup());
  }
  startNode(e) {
    const t = this.nodeMetrics.get(e),
      n = this.config.nodes[e];
    if ("ready" !== t.phase) return;
    ((t.phase = "running"),
      t.attempts++,
      (t.startTime = Date.now()),
      this.dispatch({ type: "UPDATE_NODE_STATUS", payload: { nodeId: e, status: "running" } }));
    const a = Math.floor(n.minDuration + Math.random() * (n.maxDuration - n.minDuration));
    setTimeout(() => this.completeNode(e), a);
  }
  completeNode(e) {
    const t = this.nodeMetrics.get(e),
      n = this.config.nodes[e];
    ((t.phase = "completed"),
      (t.endTime = Date.now()),
      n.logsToOutput.forEach((t) => {
        this.dispatch({ type: "ADD_LOG", payload: { nodeId: e, log: t } });
      }),
      this.dispatch({ type: "COMPLETE_NODE", payload: { nodeId: e, outputs: n.outputs } }),
      Array.from(this.nodeMetrics.values()).every((e) => "completed" === e.phase) &&
        this.dispatch({ type: "COMPLETE_PIPELINE" }));
  }
  cleanup() {
    (this.checkInterval && (clearInterval(this.checkInterval), (this.checkInterval = null)),
      this.logPipelineState("Pipeline Completed"));
  }
}
const G = {
    nodes: {
      "claimant-details": {
        id: "claimant-details",
        label: "Source Intelligence Details",
        description: "Collects and processes detailed information from field operatives and intelligence sources",
        minDuration: 4e3,
        maxDuration: 1e4,
        logsToOutput: [
          {
            id: 101,
            content: "Field Intelligence Collection Complete",
            details: "Successfully processed raw intelligence from 5 field operatives in eastern border region",
            timestamp: "08:45:20",
            type: "success",
            agent: { id: "source-intel-1", name: "Field Intelligence Processor", type: "intel-collector" },
            metrics: { executionTime: 7850, apiCalls: [{ service: "secure-comms-api", duration: 2200, status: 200 }] },
            expandable: !0,
            hash: "int1a2k3e4d5",
          },
        ],
        outputs: [
          {
            id: "a1eb3c99-1c0b-4ef8-bb6d-6bb9bd380a11",
            title: "Source Intelligence Report",
            component: "markdown",
            params: {
              content:
                "## Satellite Imagery Analysis Report\n**Timestamp:** 2025-02-24 08:30 UTC\n**Location:** Eastern Border Region\n\n### Key Observations\n- Multiple unauthorized vehicle convoys detected in restricted zone\n- Communications array activated at Site Delta\n- Unusual troop movements near checkpoint locations\n- Civilian evacuation patterns observed in border villages\n- New defensive positions identified at key terrain features\n\n### Critical Concerns\n- Activity level increasing approximately 35% over 72 hours\n- Four unmarked transport vehicles on approach to restricted facility\n- Cross-border infrastructure suddenly reinforced\n- Unidentified electronic signatures detected in northwest sector\n\n### Personnel Count\n- ~120 military personnel visible in monitored areas\n- 14 armored vehicles newly deployed\n- 3 mobile command centers identified",
            },
            metadata: { description: "Comprehensive details from intelligence source perspective" },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      "claimant-media": {
        id: "claimant-media",
        label: "SIGINT Media",
        description: "Processes communications, electronic emissions, and digital transmissions for national security",
        minDuration: 5e3,
        maxDuration: 12e3,
        logsToOutput: [
          {
            id: 102,
            content: "SIGINT Collection Active",
            details:
              "Monitoring 14 frequency bands for communications, electronic emissions, and digital transmissions",
            timestamp: "09:10:05",
            type: "info",
            agent: { id: "sigint-1", name: "Signals Intelligence Processor", type: "signals-collector" },
            metrics: {
              executionTime: 8450,
              apiCalls: [{ service: "crypto-analysis-api", duration: 3800, status: 200 }],
            },
            expandable: !0,
            hash: "sig5a6k7e8d9",
          },
        ],
        outputs: [
          {
            id: "b27f1187-aba3-4b0d-a34e-a1d82319627c",
            title: "SIGINT Analysis",
            component: "markdown",
            params: {
              content:
                "# SIGINT Collection Report\n**Time:** 09:15 UTC\n**Collection Units:** Station Echo, Foxtrot, Lima\n\n## Active Collection Systems\n- ELINT Platform Echo: Communications monitoring\n- COMINT Node Foxtrot: Signal decryption\n- Cyber Unit Lima: Network traffic analysis\n\n## Intercepts in Progress\n1. Encrypted communications at Grid 372-481\n   - Military-grade encryption detected\n   - Pattern matches known adversary protocols\n   \n2. Unusual data transmissions from Command Facility\n   - Increased bandwidth consumption\n   - New receiving endpoints identified\n   \n3. Frequency changes in border surveillance systems\n   - Shift to alternative communications bands\n   - Possible coordination for operations\n\n## Collection Status\n- Deep packet inspection: Active\n- Additional collection platforms redirected\n- UAV signal collection deploying",
            },
            metadata: { description: "Analysis of signals intelligence gathered from sources" },
          },
        ],
        tooling: { type: "vision", provider: "nemo", config: { modelType: "mixed-modal" } },
      },
      "triage-claims": {
        id: "triage-claims",
        label: "Intelligence Triage",
        description: "Categorizes and prioritizes intelligence based on credibility, relevance, and time-sensitivity",
        minDuration: 3e3,
        maxDuration: 9e3,
        dependencies: [
          { nodeId: "claimant-details", required: !0 },
          { nodeId: "claimant-media", required: !0 },
        ],
        inputMergeStrategy: "prioritize",
        logsToOutput: [
          {
            id: 103,
            content: "Priority Intelligence Alert",
            details: "Multiple high-priority indicators detected in eastern border region",
            timestamp: "09:18:45",
            type: "warning",
            agent: { id: "triage-1", name: "Intelligence Prioritization System", type: "triage-system" },
            metrics: {},
            expandable: !0,
            hash: "tri9a0k1e2d3",
          },
        ],
        outputs: [
          {
            id: "c3b39d8-1bae-4ed3-b4db-2a74658f0d85",
            title: "Intelligence Triage Assessment",
            component: "jsonChart",
            params: {
              content: {
                labels: ["72hrs", "60hrs", "48hrs", "36hrs", "24hrs", "12hrs"],
                datasets: [
                  { label: "Communications Volume", data: [28, 35, 42, 65, 87, 112], color: "#FF0000" },
                  { label: "Troop Movements", data: [15, 18, 27, 38, 52, 78], color: "#00FF00" },
                  { label: "Logistics Activities", data: [22, 25, 38, 57, 82, 95], color: "#0000FF" },
                ],
                anomalyThreshold: 60,
                metadata: { activityLevel: "Critical", trendDirection: "Rapidly Increasing", peakTime: "06:30 UTC" },
              },
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      "witness-evidence": {
        id: "witness-evidence",
        label: "HUMINT Reports",
        description: "Collects and analyzes human intelligence reports",
        minDuration: 8e3,
        maxDuration: 18e3,
        logsToOutput: [
          {
            id: 104,
            content: "HUMINT Source Reports Processed",
            details: "3 high-reliability sources confirm military mobilization in target region",
            timestamp: "09:30:10",
            type: "agent-output",
            agent: { id: "humint-1", name: "Human Intelligence Processor", type: "humint-analyst" },
            output: { type: "markdown", id: "humint-analysis-001", location: "/outputs/humint/001" },
            expandable: !0,
            hash: "hum4a5k6e7d8",
          },
        ],
        outputs: [
          {
            id: "d4c18af1-a352-45e6-976e-3c194bdc6ee8",
            title: "HUMINT Analysis",
            component: "markdown",
            params: {
              content:
                '# HUMINT Source Reports Analysis\n**Last Updated:** 09:40 UTC\n\n## Verified Intelligence Reports\n\n### Source ALPHA-3\n1. "Military reserve units mobilized in eastern district. Unusual timing and scale."\n   - Source reliability: A1\n   - Multiple corroborating reports\n   - Timeline verified against SIGINT\n\n2. "Command-level meeting called at Central Headquarters with unusual attendance."\n   - Senior source confirmation\n   - Attendance roster verified\n   - Location matches previous pattern disruption\n\n### Source BRAVO-7\n- Regional Asset Network:\n  - Multiple reports of fuel and ammunition stockpiling\n  - Coordination of specialized units at Forward Base Charlie\n  - Photos of equipment staging areas verified\n\n### Source DELTA-2\n- Field Operative Updates:\n  - Command structure changes at Battalion level\n  - Specialized equipment deployment observed\n  - Real-time movement reporting from embedded assets\n\n## Warning Indicators\n- Command and control changes implemented ahead of schedule\n- Multiple reports of leave cancellations\n- Reports of communications blackout drills',
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      "other-parties-media": {
        id: "other-parties-media",
        label: "Allied Intel Sharing",
        description: "Manages intelligence shared by NATO allies and partner nations",
        minDuration: 6e3,
        maxDuration: 14e3,
        logsToOutput: [
          {
            id: 105,
            content: "NATO Intelligence Exchange Complete",
            details: "Intelligence received from 3 alliance partners confirming activity patterns",
            timestamp: "09:45:30",
            type: "info",
            agent: { id: "allied-1", name: "Allied Information Exchange", type: "intel-exchange" },
            expandable: !0,
            hash: "all8a9k0e1d2",
          },
        ],
        outputs: [
          {
            id: "e5303866d-d08a-48a7-81c3-c30486149d87",
            title: "Allied Intelligence Analysis",
            component: "markdown",
            params: {
              content:
                "# Intelligence Fusion Summary\n**Generated:** 10:00 UTC, February 24, 2025\n\n## Current Threat Assessment: HIGH\n\n### Operational Indicators\n- Eastern border region showing significant military activity\n- Force posture: Combat-ready and increasing\n- Rate of deployment: ~15% per 24 hours\n- Affected area: 80km border section\n\n### Impact Assessment\n1. Military Capability\n   - Multiple combat units identified\n   - Air defense systems activated\n   - Electronic warfare equipment deployed\n   - Communications secured and encrypted\n\n2. Intent Indicators\n   - Command and control activation patterns match previous operations\n   - Logistics flow consistent with sustained operations\n   - Pre-positioning of medical and support assets\n   - Forward reconnaissance active\n\n3. Resource Deployment\n   - 15+ armored vehicles confirmed\n   - 2 mobile command posts activated\n   - Forward air assets positioned\n   - Electronic warfare capabilities deployed\n\n### Critical Intelligence Gaps\n- Ultimate operational objectives\n- Timeline for potential action\n- Involvement of specialized units\n- Coordination with non-military elements",
            },
          },
        ],
        tooling: { type: "vision", provider: "nemo" },
      },
      cctv: {
        id: "cctv",
        label: "Geospatial Intelligence",
        description: "Processes satellite imagery, drone footage, and other geospatial data",
        minDuration: 7e3,
        maxDuration: 16e3,
        logsToOutput: [
          {
            id: 106,
            content: "GEOINT Analysis Complete",
            details: "Satellite and drone footage analysis reveals significant military movements",
            timestamp: "10:00:15",
            type: "success",
            agent: { id: "geoint-1", name: "Geospatial Intelligence Processor", type: "imagery-analyst" },
            expandable: !0,
            hash: "geo3a4k5e6d7",
          },
        ],
        outputs: [
          {
            id: "f6836695-f2d0-47f4-86e8-d0dbaae4031a",
            title: "GEOINT Analysis",
            component: "jsonChart",
            params: {
              content: {
                threatLevel: "HIGH",
                requiresEscalation: !0,
                factors: [
                  {
                    category: "Military Forces",
                    level: "Significant",
                    details: "Combat-ready units positioned in key locations",
                  },
                  {
                    category: "Command & Control",
                    level: "Active",
                    details: "Encrypted communications and command structure activated",
                  },
                  {
                    category: "Intelligence Indicators",
                    level: "Multiple",
                    details: "Pattern consistent with pre-operational staging",
                  },
                ],
                recommendations: [
                  "Immediate escalation to senior leadership",
                  "Increase collection across all intelligence disciplines",
                  "Activate contingency planning",
                ],
                validationStatus: "Corroborated by multiple intelligence sources",
              },
            },
          },
        ],
        tooling: { type: "vision", provider: "nemo", config: { modelType: "video-analytics" } },
      },
      "other-media": {
        id: "other-media",
        label: "OSINT Collection",
        description: "Gathers and analyzes open-source intelligence from public domains",
        minDuration: 5e3,
        maxDuration: 15e3,
        logsToOutput: [
          {
            id: 107,
            content: "Open Source Intelligence Gathered",
            details: "Analysis of social media, news outlets, and public data shows corroborating patterns",
            timestamp: "10:10:40",
            type: "info",
            agent: { id: "osint-1", name: "Open Source Collector", type: "osint-monitor" },
            expandable: !0,
            hash: "osi7a8k9e0d1",
          },
        ],
        outputs: [
          {
            id: "g7ec671-806a-4db2-8c60-f0f8754f9b7b",
            title: "OSINT Analysis",
            component: "markdown",
            params: {
              content:
                "# Intelligence Response Action Plan\n**Effective:** 10:15 UTC, February 24, 2025\n\n## IMMEDIATE ACTIONS REQUIRED\n\n### 1. Priority Collection Operations\n- Redirect satellite coverage to:\n  * Grid sectors 372-481 (communications hub)\n  * Eastern transportation corridors\n  * Forward Operating Base locations\n\n### 2. Intelligence Distribution\n- Immediate dissemination to Joint Operations Center\n- Notify NATO intelligence liaison officers\n- Brief national security leadership\n\n### 3. Resource Allocation\n- Activate 24-hour analysis cell\n- Request additional collection platforms\n- Establish joint intelligence fusion team\n\n### 4. Counterintelligence Measures\n- Enhance operational security protocols\n- Monitor for information leakage\n- Implement deception countermeasures\n\n## Execution Timeline\n1. Hour 1: Enhanced collection operations\n2. Hour 2: Initial assessment distribution\n3. Hour 3: Interagency coordination\n4. Hour 6: Comprehensive intelligence product\n\n## Communication Protocols\n- Secure briefings every 2 hours\n- Direct communication with collection assets\n- Updates via classified channels only",
            },
          },
        ],
        tooling: { type: "vision", provider: "nemo" },
      },
      "police-report": {
        id: "police-report",
        label: "Law Enforcement Data",
        description: "Coordinates with domestic and international law enforcement",
        minDuration: 6e3,
        maxDuration: 12e3,
        logsToOutput: [
          {
            id: 108,
            content: "Law Enforcement Intelligence Received",
            details: "Border security reports confirm unusual patterns of activity",
            timestamp: "10:15:20",
            type: "info",
            agent: { id: "lawenf-1", name: "Law Enforcement Liaison", type: "le-coordinator" },
            expandable: !0,
            hash: "law2a3k4e5d6",
          },
        ],
        outputs: [
          {
            id: "h8eb93a-071e-4407-8b78-a73aabd9e803",
            title: "Law Enforcement Data Analysis",
            component: "jsonChart",
            params: {
              content: [
                {
                  timestamp: "10:20:00 UTC",
                  recipient: "Joint Operations Center",
                  status: "Delivered",
                  message: "Priority intelligence update on border activities",
                  response: "Acknowledged, command briefing scheduled",
                },
                {
                  timestamp: "10:20:30 UTC",
                  recipient: "Collection Management",
                  status: "Delivered",
                  message: "Redirect SIGINT resources to Grid 372-481",
                  response: "Assets redirecting, ETA 30 minutes",
                },
                {
                  timestamp: "10:21:00 UTC",
                  recipient: "NATO Liaison",
                  status: "Delivered",
                  message: "Activate intelligence sharing protocols",
                  response: "Sharing activated, allied assets responding",
                },
                {
                  timestamp: "10:21:30 UTC",
                  recipient: "National Security Council",
                  status: "Delivered",
                  message: "Preliminary assessment of border activities",
                  response: "Received, briefing scheduled for 11:00 UTC",
                },
              ],
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      "group-evidence": {
        id: "group-evidence",
        label: "Intelligence Fusion",
        description: "Aggregates intelligence from multiple sources into a cohesive operational picture",
        minDuration: 5e3,
        maxDuration: 1e4,
        dependencies: [
          { nodeId: "witness-evidence", required: !1 },
          { nodeId: "other-parties-media", required: !1 },
          { nodeId: "cctv", required: !1 },
          { nodeId: "other-media", required: !1 },
          { nodeId: "police-report", required: !1 },
        ],
        logsToOutput: [
          {
            id: 109,
            content: "Multi-Source Intelligence Fusion Complete",
            details: "Comprehensive intelligence picture generated from all collection sources",
            timestamp: "10:25:10",
            type: "success",
            agent: { id: "fusion-1", name: "Intelligence Fusion Engine", type: "intel-integrator" },
            expandable: !0,
            hash: "fus6a7k8e9d0",
          },
        ],
        outputs: [
          {
            id: "i9eebc99-9c0b-4ef8-bb6d-6bb9bd380b22",
            title: "Consolidated Intelligence Package",
            component: "markdown",
            params: {
              content:
                "# CONSOLIDATED INTELLIGENCE REPORT\n**Classification: TOP SECRET//NOFORN**\n**Timestamp: 10:30 UTC, February 24, 2025**\n\n## EXECUTIVE SUMMARY\nIntelligence from multiple sources indicates significant military activity in the Eastern Border Region showing patterns consistent with preparation for offensive operations. Activity level has increased 35% over 72 hours with notable changes in command and control structures, communications patterns, and force positioning.\n\n## SOURCE INTEGRATION\n\n### GEOINT\n- Satellite imagery confirms 14 armored vehicles newly deployed\n- 3 mobile command centers established at Grid 372-481\n- Defensive positions reinforced along 80km border section\n- Unusual convoy patterns suggesting logistics buildup\n\n### SIGINT\n- Military-grade encrypted communications increased 112% in last 12 hours\n- Command facility showing unusual data transmission patterns\n- Frequency shifts detected in border surveillance systems\n- Electronic signatures consistent with advanced EW systems\n\n### HUMINT\n- Source ALPHA-3 confirms military reserve mobilization\n- Command-level meeting with unusual attendance reported\n- Multiple sources verify ammunition and fuel stockpiling\n- Leave cancellations implemented across multiple units\n\n### OSINT\n- Regional news reporting unusual military transport activity\n- Social media showing increased military presence in border towns\n- Commercial satellite imagery showing vehicle staging areas\n- Increased security measures at government facilities\n\n### LAW ENFORCEMENT\n- Border security reports increased inspections and detentions\n- Cross-border civilian traffic restricted at multiple checkpoints\n- Surveillance of key government officials increased\n- Unusual diplomatic security measures implemented\n\n## ASSESSMENT CONFIDENCE\nHigh confidence assessment based on multiple intelligence disciplines with source verification and cross-correlation.",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      "guardrail-1": {
        id: "guardrail-1",
        label: "Validate Classification and Legal Compliance",
        description: "Ensures intelligence handling complies with relevant laws and classification protocols",
        minDuration: 2e3,
        maxDuration: 4e3,
        dependencies: [{ nodeId: "group-evidence", required: !0 }],
        guardrails: { controlIds: ["guardrail-1"], checkOnStart: !0, checkOnComplete: !0 },
        alertConditions: {
          type: "data-protection",
          triggers: [
            "unprotected-pii-detected",
            "sensitive-data-exposure",
            "insufficient-encryption",
            "missing-data-minimization",
            "unauthorized-data-access",
          ],
        },
        logsToOutput: [
          {
            id: 110,
            content: "Classification Compliance Check Complete",
            details: "All intelligence properly classified according to handling requirements",
            timestamp: "10:28:45",
            type: "success",
            agent: { id: "compliance-1", name: "Classification Validator", type: "compliance-monitor" },
            expandable: !0,
            hash: "cla1a2k3e4d5",
          },
        ],
      },
      "analyze-data": {
        id: "analyze-data",
        label: "Pattern and Anomaly Detection",
        description: "Applies advanced analytics to identify patterns, anomalies, and correlations",
        minDuration: 1e4,
        maxDuration: 2e4,
        dependencies: [
          { nodeId: "triage-claims", required: !0 },
          { nodeId: "guardrail-1", required: !0 },
        ],
        outputs: [
          {
            id: "j10c18af1-a352-45e6-976e-3c194bdc6f99",
            title: "Intelligence Pattern Analysis",
            component: "markdown",
            params: {
              content:
                "# PATTERN ANALYSIS REPORT\n**Classification: TOP SECRET//NOFORN**\n**Reference: INTEL-2025-0224-042**\n\n## ACTIVITY PATTERN ASSESSMENT\n\n### Timeline Analysis\n- **72-48 Hours Prior:** Initial communications spike and logistics movement\n- **48-24 Hours Prior:** Command activation and force positioning\n- **24-12 Hours Prior:** Equipment deployment and communications security measures\n- **Current Status:** Full operational posture indicators present\n\n### Historical Pattern Matching\nAnalysis reveals 87% correlation with activity patterns observed prior to the April 2024 border incursion, with notable similarities in:\n- Command and control activation sequence\n- Communications security implementation\n- Force positioning relative to terrain features\n- Logistics flow patterns\n\n### Anomaly Detection\nThe following deviations from historical patterns are noted:\n1. More rapid deployment timeline (35% faster than previous operations)\n2. Enhanced electronic warfare component presence\n3. Higher level of operational security measures\n4. Presence of specialized units not previously observed\n\n### Indicator Analysis\n| Indicator | Status | Confidence |\n|-----------|--------|------------|\n| Force Mobilization | CONFIRMED | HIGH |\n| Command Activation | CONFIRMED | HIGH |\n| Logistics Buildup | CONFIRMED | MEDIUM |\n| Communications Security | CONFIRMED | HIGH |\n| Air Defense Activation | PARTIAL | MEDIUM |\n| Electronic Warfare | CONFIRMED | HIGH |\n\n## DECEPTION ANALYSIS\nCurrent patterns assessed as consistent with genuine operational preparation rather than deception operations based on:\n- Resource commitment level\n- Command involvement\n- Operational security measures\n- Deployment of high-value assets\n\n## CONCLUSION\nIntelligence indicators strongly suggest preparation for offensive operations with a high probability of activation within 24-48 hours based on current progression rate.",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic", config: { modelType: "analysis" } },
        logsToOutput: [
          {
            id: 111,
            content: "Pattern Recognition Alert",
            details: "87% pattern match with April 2024 border incursion detected",
            timestamp: "10:45:30",
            type: "warning",
            agent: { id: "pattern-1", name: "Pattern Analysis System", type: "analytics-engine" },
            expandable: !0,
            hash: "pat5a6k7e8d9",
          },
        ],
      },
      "verify-policy": {
        id: "verify-policy",
        label: "Verify National Security Priorities Alignment",
        description: "Evaluates intelligence against current national security directives",
        minDuration: 7e3,
        maxDuration: 14e3,
        dependencies: [{ nodeId: "analyze-data", required: !0 }],
        outputs: [
          {
            id: "k11eb3c99-1c0b-4ef8-bb6d-6bb9bd380c33",
            title: "Security Priority Assessment",
            component: "markdown",
            params: {
              content:
                "# NATIONAL SECURITY PRIORITIES ASSESSMENT\n**Classification: TOP SECRET//NOFORN**\n**Timestamp: 11:15 UTC, February 24, 2025**\n\n## ALIGNMENT WITH NATIONAL INTELLIGENCE PRIORITIES\n\n### Priority 1: Border Security and Territorial Integrity\n**DIRECT ALIGNMENT - CRITICAL**\n- Current activities present immediate challenge to border security\n- Territorial integrity potentially threatened by force posture\n- Early warning indicators fully triggered\n- Response threshold met for priority escalation\n\n### Priority 2: Regional Stability Operations\n**DIRECT ALIGNMENT - HIGH**\n- Activity patterns indicate potential for regional destabilization\n- Refugee flow implications if conflict erupts\n- Economic disruption potential high\n- Diplomatic implications require immediate attention\n\n### Priority 3: Counter-Terrorism and Non-State Actors\n**INDIRECT ALIGNMENT - MEDIUM**\n- Potential for exploitation of instability by non-state actors\n- Secondary effects on counter-terrorism operations\n- Intelligence collection disruption possible\n- Resources may require reallocation\n\n### Priority 4: Weapons Proliferation Control\n**MODERATE ALIGNMENT - MEDIUM**\n- Movement of advanced weapons systems detected\n- Potential transfer to non-state actors in region\n- Verification of weapons systems compliance required\n- Proliferation risk assessment needed\n\n## INTELLIGENCE DIRECTIVES ALIGNMENT\nCurrent intelligence collection and analysis efforts are properly aligned with National Intelligence Priorities Framework directives:\n- Collection assets appropriately tasked\n- Analysis resources correctly allocated\n- Dissemination protocols following established guidelines\n- Interagency coordination activated\n\n## RECOMMENDED PRIORITY ADJUSTMENTS\n1. Elevate eastern border region to Priority Designation Alpha\n2. Increase collection allocation by 35%\n3. Establish dedicated analysis cell for continuous assessment\n4. Implement twice-daily briefing schedule for national leadership",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 112,
            content: "Security Priority Alignment Confirmed",
            details: "Intelligence situation directly aligns with National Priority #1: Border Security",
            timestamp: "11:15:20",
            type: "info",
            agent: { id: "priority-1", name: "Security Priority Validator", type: "policy-validator" },
            expandable: !0,
            hash: "pri9a0k1e2d3",
          },
        ],
      },
      "estimate-costs": {
        id: "estimate-costs",
        label: "Threat Assessment",
        description: "Evaluates potential threats based on capability, intent, and opportunity",
        minDuration: 6e3,
        maxDuration: 12e3,
        dependencies: [{ nodeId: "verify-policy", required: !0 }],
        outputs: [
          {
            id: "l12f1187-aba3-4b0d-a34e-a1d82319627d",
            title: "Threat Assessment Report",
            component: "jsonChart",
            params: {
              content: {
                overall_threat_level: "SEVERE",
                confidence_level: "HIGH",
                timeframe: "IMMINENT (24-48 hours)",
                capability_assessment: [
                  {
                    category: "Ground Forces",
                    strength: "Battalion-level",
                    readiness: "Combat Ready",
                    threat_rating: 85,
                  },
                  {
                    category: "Command & Control",
                    strength: "Fully Operational",
                    readiness: "Active",
                    threat_rating: 90,
                  },
                  {
                    category: "Electronic Warfare",
                    strength: "Advanced Systems",
                    readiness: "Deployed",
                    threat_rating: 80,
                  },
                  {
                    category: "Logistics",
                    strength: "Sustained Operations",
                    readiness: "Positioned",
                    threat_rating: 75,
                  },
                ],
                intent_indicators: [
                  "Command structure activated to operational level",
                  "Forward positioning consistent with offensive operations",
                  "Intelligence collection against defensive positions",
                  "Communications security measures fully implemented",
                ],
                potential_scenarios: [
                  {
                    scenario: "Limited Border Incursion",
                    probability: "HIGH (70%)",
                    timeline: "24-48 hours",
                    indicators_present: "15/18",
                  },
                  {
                    scenario: "Full-Scale Offensive",
                    probability: "MEDIUM (40%)",
                    timeline: "48-72 hours",
                    indicators_present: "9/15",
                  },
                  {
                    scenario: "Show of Force Only",
                    probability: "LOW (15%)",
                    timeline: "Ongoing",
                    indicators_present: "3/12",
                  },
                ],
                recommended_readiness: "DEFCON 3",
              },
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 113,
            content: "Threat Assessment Complete",
            details: "Severe threat level determined with high confidence",
            timestamp: "11:30:40",
            type: "warning",
            agent: { id: "threat-1", name: "Threat Analysis System", type: "threat-assessor" },
            expandable: !0,
            hash: "thr4a5k6e7d8",
          },
        ],
      },
      "guardrail-2": {
        id: "guardrail-2",
        label: "Authorization for Sensitive Operations",
        description: "Ensures proper oversight for high-risk intelligence operations",
        minDuration: 3e3,
        maxDuration: 6e3,
        dependencies: [{ nodeId: "estimate-costs", required: !0 }],
        guardrails: { controlIds: ["guardrail-2"], checkOnStart: !0, checkOnComplete: !0 },
        alertConditions: {
          type: "data-protection",
          threshold: 0.75,
          triggers: ["high-value-claim", "complex-liability", "potential-fraud"],
        },
        logsToOutput: [
          {
            id: 114,
            content: "Senior Authority Approval Required",
            details: "Intelligence assessment requires senior leadership authorization",
            timestamp: "11:35:10",
            type: "guardrail-pass",
            agent: { id: "auth-1", name: "Operations Authorization Monitor", type: "oversight-system" },
            expandable: !0,
            hash: "aut8a9k0e1d2",
          },
        ],
      },
      "offer-care": {
        id: "offer-care",
        label: "Source Protection Assessment",
        description: "Identifies operational security risks and protection measures for sources",
        minDuration: 4e3,
        maxDuration: 8e3,
        dependencies: [{ nodeId: "triage-claims", required: !0 }],
        outputs: [
          {
            id: "m13b39d8-1bae-4ed3-b4db-2a74658f0d85",
            title: "Source Protection Plan",
            component: "markdown",
            params: {
              content:
                "# SOURCE PROTECTION ASSESSMENT\n**Classification: TOP SECRET//NOFORN**\n**Timestamp: 11:30 UTC, February 24, 2025**\n\n## CRITICAL SOURCE VULNERABILITY ANALYSIS\n\n### HUMINT Sources\n- **Source ALPHA-3:** HIGH RISK\n  * Current position exposes source to counterintelligence scrutiny\n  * Recent operational tempo increases exposure\n  * Recommended Action: Temporary communication blackout\n\n- **Source BRAVO-7:** MODERATE RISK\n  * Network position provides some operational security\n  * Increased military presence in area raises detection risk\n  * Recommended Action: Switch to emergency communication protocols\n\n- **Source DELTA-2:** SEVERE RISK\n  * Embedded position extremely vulnerable during heightened alert\n  * Access to critical information increases counterintelligence focus\n  * Recommended Action: Consider immediate extraction\n\n### Technical Collection Vulnerabilities\n1. SIGINT collection platforms potentially compromised by:\n   - Enhanced electronic warfare capabilities detected\n   - Counter-surveillance measures observed\n   - Signals intelligence countermeasures active\n\n2. GEOINT vulnerabilities:\n   - Increased counter-space activities\n   - Weather degradation expected in next 12 hours\n   - Physical masking of key facilities observed\n\n## PROTECTIVE MEASURES IMPLEMENTATION\n\n### Immediate Actions\n- Transition HUMINT sources to emergency protocols\n- Rotate SIGINT collection frequencies and methods\n- Diversify GEOINT collection platforms\n- Implement deception measures to mask collection focus\n\n### Mid-term Protection Strategy\n- Create alternate communication channels\n- Establish emergency extraction protocols\n- Develop counter-surveillance measures\n- Implement source identity compartmentalization\n\n## RISK MITIGATION TIMELINE\n1. Hour 1-2: Emergency protocol activation\n2. Hour 2-6: Communication security enhancement\n3. Hour 6-12: Counterintelligence sweep\n4. Hour 12-24: Full protection measures implementation\n\n## REQUIRED RESOURCES\n- Rapid reaction team on standby for extraction\n- Technical countermeasures deployment\n- Alternative communication systems\n- Deception operation support",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 115,
            content: "Source Protection Measures Implemented",
            details: "Protective protocols activated for 3 high-risk HUMINT sources",
            timestamp: "11:40:30",
            type: "info",
            agent: { id: "protection-1", name: "Source Security System", type: "asset-protector" },
            expandable: !0,
            hash: "pro3a4k5e6d7",
          },
        ],
      },
      "generate-plan": {
        id: "generate-plan",
        label: "Generate Intelligence Product",
        description: "Synthesizes complex intelligence into actionable reports",
        minDuration: 8e3,
        maxDuration: 15e3,
        dependencies: [
          { nodeId: "guardrail-2", required: !0 },
          { nodeId: "offer-care", required: !0 },
        ],
        outputs: [
          {
            id: "n14c18af1-a352-45e6-976e-3c194bdc6e88",
            title: "Intelligence Product",
            component: "markdown",
            params: {
              content:
                "# INTELLIGENCE PRODUCT\n**Classification: TOP SECRET//NOFORN//ORCON**\n**Product ID: IIR-2025-0224-EB-0001**\n**Date: February 24, 2025**\n\n## SITUATION ASSESSMENT\n\nIntelligence from multiple sources with high reliability indicates preparation for significant military operations along the eastern border region. Activity patterns, force composition, and command and control indicators suggest preparations for offensive action within the next 24-48 hours.\n\n## KEY FINDINGS\n\n1. **Military Forces**\n   - Battalion-strength forces positioned along 80km border section\n   - Combat readiness achieved across multiple units\n   - Special operations elements identified at three key locations\n   - Air defense and electronic warfare capabilities fully deployed\n\n2. **Command Intent**\n   - Operational command structure activated\n   - Communications security measures implemented\n   - Intelligence collection focused on defensive positions and response capabilities\n   - Logistics positioned for sustained operations\n\n3. **Timeline Assessment**\n   - Current Phase: Final Positioning (95% complete)\n   - Estimated Window for Action: 24-48 hours\n   - Readiness Level: Full Combat Capability\n   - Deception Indicators: Minimal, assessed as genuine operational preparation\n\n4. **Critical Vulnerabilities**\n   - Command and control nodes at Grid 372-481\n   - Logistics hub at Eastern Transportation Center\n   - Communications relay station at Mountain Position Alpha\n   - Forward fuel and ammunition depots\n\n## ASSESSMENT CONFIDENCE\n\nHigh confidence assessment based on multiple intelligence disciplines with source verification and cross-correlation. Alternative hypotheses considered and deemed less probable based on available intelligence.\n\n## RECOMMENDED ACTIONS\n\n1. **Immediate Military Response**\n   - Increase force readiness along affected border section\n   - Deploy counter-electronic warfare capabilities\n   - Activate air defense and early warning systems\n   - Position counter-mobility assets at key terrain features\n\n2. **Intelligence Operations**\n   - Maintain enhanced collection against identified targets\n   - Focus SIGINT on command and control networks\n   - Deploy additional HUMINT resources with access to decision makers\n   - Increase UAV reconnaissance of staging areas\n\n3. **Diplomatic Initiatives**\n   - Engage through established military deconfliction channels\n   - Initiate NATO consultation under Article 4\n   - Prepare evidence package for international distribution\n   - Activate bilateral security agreements\n\n## UPDATES AND DISTRIBUTION\n\nContinuous monitoring in effect with updates to follow at 2-hour intervals or as significant developments occur. Distribution to JOINT OPS, NATO INTEL, NSC, and authorized commands.",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 116,
            content: "Intelligence Product Generated",
            details: "Comprehensive intelligence assessment with recommendations completed",
            timestamp: "11:55:15",
            type: "success",
            agent: { id: "product-1", name: "Intelligence Product Generator", type: "intel-synthesizer" },
            expandable: !0,
            hash: "pro7a8k9e0d1",
          },
        ],
      },
      "notify-agent": {
        id: "notify-agent",
        label: "Disseminate to Decision Makers",
        description: "Ensures intelligence products reach appropriate decision-makers",
        minDuration: 3e3,
        maxDuration: 7e3,
        dependencies: [{ nodeId: "generate-plan", required: !0 }],
        outputs: [
          {
            id: "o15303866d-d08a-48a7-81c3-c30486149d87",
            title: "Decision Maker Notification Package",
            component: "toolNotify",
            params: {
              content:
                "# PRIORITY INTELLIGENCE DISSEMINATION\nTO: JOINT OPERATIONS COMMAND\nFROM: INTELLIGENCE DIRECTORATE\nSUBJECT: IMMINENT THREAT ASSESSMENT - EASTERN BORDER\nCLASSIFICATION: TOP SECRET//NOFORN//ORCON\n\nSUMMARY: High confidence assessment of imminent military action along Eastern Border Region within 24-48 hours. Battalion-strength forces with full combat capability positioned. Command and control activated. All indicators consistent with offensive operations preparation.\n\nKEY POINTS:\n1. Force posture changed to offensive configuration\n2. Command structure fully activated\n3. Electronic warfare capabilities deployed\n4. Logistics positioned for sustained operations\n5. Historical pattern match: 87% correlation with April 2024 incursion\n\nRECOMMENDED ACTIONS:\n1. Increase defensive posture immediately\n2. Activate contingency plans EAGLE SHIELD and SWIFT RESPONSE\n3. Position counter-electronic warfare assets\n4. Brief national leadership within 1 hour\n\nBRIEFING SCHEDULED: 12:15 UTC via SECURE CONFERENCE ALPHA\n\nRESPONSE REQUIRED: ACKNOWLEDGE RECEIPT AND CONFIRM BRIEFING ATTENDANCE\n\n//END PRIORITY TRANSMISSION//",
            },
          },
        ],
        tooling: { type: "notification", provider: "twilio" },
        logsToOutput: [
          {
            id: 117,
            content: "Intelligence Dissemination Complete",
            details: "Priority intelligence successfully delivered to Joint Operations Command",
            timestamp: "12:00:40",
            type: "success",
            agent: { id: "dissem-1", name: "Intelligence Disseminator", type: "intel-distributor" },
            metrics: {
              apiCalls: [
                { service: "secure-notification-api", duration: 800, status: 200 },
                { service: "command-portal-api", duration: 650, status: 200 },
              ],
            },
            expandable: !0,
            hash: "dis2a3k4e5d6",
          },
        ],
      },
      "guardrail-check3": {
        id: "guardrail-check3",
        label: "Human Verification of Intelligence Assessment",
        description: "Ensures qualified intelligence professionals review automated assessments",
        minDuration: 5e3,
        maxDuration: 1e4,
        dependencies: [{ nodeId: "notify-agent", required: !0 }],
        guardrails: { controlIds: ["ctrl-7"], checkOnStart: !0, checkOnComplete: !0 },
        alertConditions: {
          type: "content-warning",
          threshold: 0.6,
          triggers: ["incomplete-review", "automated-decision-override", "missing-authorization"],
        },
        logsToOutput: [
          {
            id: 118,
            content: "Human Analyst Verification Complete",
            details: "Senior intelligence officer has reviewed and validated assessment",
            timestamp: "12:10:20",
            type: "success",
            agent: { id: "verify-1", name: "Human Oversight Validator", type: "verification-system" },
            expandable: !0,
            hash: "ver6a7k8e9d0",
          },
        ],
      },
      "generate-summary": {
        id: "generate-summary",
        label: "Generate Brief for Joint Operations",
        description: "Compiles finalized intelligence into standardized formats for joint operations",
        minDuration: 5e3,
        maxDuration: 1e4,
        dependencies: [{ nodeId: "guardrail-check3", required: !0 }],
        outputs: [
          {
            id: "p16836695-f2d0-47f4-86e8-d0dbaae4031a",
            title: "Joint Operations Intelligence Brief",
            component: "markdown",
            params: {
              content:
                "# JOINT OPERATIONS INTELLIGENCE BRIEF\n**Classification: NATO SECRET//REL TO USA, FVEY**\n**OPERATION VIGILANT SHIELD**\n**February 24, 2025**\n\n## SITUATION OVERVIEW\n\nSignificant military activities detected along Eastern Border Region indicating preparation for offensive operations. Multiple intelligence sources with high reliability confirm battalion-strength forces positioned for potential action within 24-48 hours. This assessment has been validated through multi-source intelligence fusion and pattern analysis.\n\n## INTELLIGENCE SUMMARY\n\n### Observed Military Activities\n- Combat-ready battalion-strength forces positioned along 80km border section\n- Command and control nodes fully activated at Grid 372-481\n- Electronic warfare systems deployed at key terrain features\n- Logistics infrastructure positioned for sustained operations\n- Special operations elements identified at three critical locations\n\n### Assessment Confidence\nIntelligence confidence level: HIGH\n- Multiple intelligence disciplines confirming key indicators\n- Pattern analysis shows 87% correlation with previous offensive operations\n- Source reliability rated as high across collection platforms\n- Technical and human intelligence in strong agreement\n\n### Timeline Projection\n- Current Phase: Final Positioning (95% complete)\n- Estimated Window for Action: 24-48 hours\n- Preparatory Activities: Complete\n- Earliest Potential H-Hour: 06:00 UTC, February 25\n\n## NATO IMPLICATIONS\n\n### Article 4 Considerations\nCurrent situation meets threshold for NATO consultation under Article 4 of the North Atlantic Treaty regarding threats to territorial integrity, political independence, and security.\n\n### Joint Response Options\n1. Enhanced Forward Presence reinforcement\n2. Allied air policing mission expansion\n3. Joint intelligence collection prioritization\n4. Strategic communication coordination\n\n### Intelligence Sharing Requirements\n- Immediate distribution to all NATO allies\n- Enhanced sharing with operational commands\n- Support to NATO intelligence fusion center\n- Real-time updates through secure NATO channels\n\n## RECOMMENDED ACTIONS\n\n### Military Response\n- Increase readiness levels for rapid response forces\n- Deploy additional ISR assets to affected region\n- Enhance electronic warfare defensive posture\n- Position strategic reserves for rapid deployment\n\n### Political-Military Coordination\n- Activate NATO Military Committee emergency session\n- Brief North Atlantic Council within 3 hours\n- Prepare for Defense Ministerial consultation\n- Coordinate strategic messaging across Alliance\n\n## UPDATES AND REPORTING\n\nContinuous monitoring with formal updates at 2-hour intervals or as significant developments occur. Joint Intelligence Fusion Cell activated with allied liaison officers present. Next comprehensive assessment: 14:00 UTC.\n\n//END OF BRIEF//",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 119,
            content: "Joint Operations Brief Generated",
            details: "NATO-compatible intelligence brief created for allied operations",
            timestamp: "12:20:15",
            type: "success",
            agent: { id: "brief-1", name: "Joint Operations Briefer", type: "brief-generator" },
            expandable: !0,
            hash: "bri1a2k3e4d5",
          },
        ],
      },
    },
  },
  z = {
    status: "idle",
    nodes: Object.keys(G.nodes).reduce((e, t) => ({ ...e, [t]: { status: "idle", logs: [], outputs: [] } }), {}),
    activeGuardrail: null,
    userOverrides: [],
    userRemediations: [],
    metrics: { responseTime: 0, riskLevel: "low", activeIncidents: 0 },
    stats: { totalNodes: Object.keys(G.nodes).length, completedNodes: 0, failedNodes: 0, blockedNodes: 0 },
  },
  B = r(void 0);
function Z({ children: e }) {
  const [n, a] = l(F, z),
    i = o(() => new U(G, a), []),
    r = s(() => {
      "running" !== n.status &&
        (("idle" !== n.status && "completed" !== n.status && "cancelled" !== n.status) || a({ type: "START_PIPELINE" }),
        i.start());
    }, [n.status, i]),
    c = s(() => {
      "running" === n.status && a({ type: "PAUSE_PIPELINE" });
    }, [n.status]),
    d = s(() => {
      ("running" !== n.status && "paused" !== n.status) || a({ type: "CANCEL_PIPELINE" });
    }, [n.status]),
    m = s((e, t) => {
      a({ type: "OVERRIDE_GUARDRAIL", payload: { alertId: e, reason: t, timestamp: Date.now() } });
    }, []),
    w = s((e, t) => {
      a({ type: "REMEDIATE_GUARDRAIL", payload: { alertId: e, reason: t, timestamp: Date.now() } });
    }, []),
    p = o(
      () => ({
        state: n,
        startPipeline: r,
        pausePipeline: c,
        cancelPipeline: d,
        overrideGuardrail: m,
        remediateGuardrail: w,
      }),
      [n, r, c, d, m, w]
    );
  return t.createElement(B.Provider, { value: p }, e);
}
function q() {
  const e = c(B);
  if (void 0 === e) throw new Error("usePipeline must be used within a PipelineProvider");
  return e;
}
const $ = ({ data: e, onControlClick: n }) => {
    const { state: a } = q(),
      i = 0 === a.userOverrides.length,
      r = 0 === a.userRemediations.length;
    return t.createElement(
      t.Fragment,
      null,
      e.map((e) => {
        let a =
          "tw-px-2 tw-py-1 tw-rounded-lg tw-cursor-pointer tw-transition-colors tw-max-w-[200px] tw-flex tw-items-center tw-relative";
        return (
          e.isAlert && "guardrail-2" === e.id && i
            ? (a += " tw-border !tw-border-brandreddark tw-bg-brandred")
            : e.isAlert && "guardrail-2" === e.id && !i
              ? (a += " tw-border !tw-border-brandgreen tw-bg-brandgreen tw-text-branddialogbg")
              : e.isAlert && "guardrail-1" === e.id && r
                ? (a += " tw-border !tw-border-brandreddark tw-bg-brandred")
                : e.isAlert && "guardrail-1" === e.id && !r
                  ? (a += " tw-border !tw-border-brandgreen tw-bg-brandgreen tw-text-branddialogbg")
                  : e.mandatory && e.implemented
                    ? (a += " tw-border !tw-border-brandblue ")
                    : e.mandatory
                      ? (a += " tw-border !tw-border-red-600 tw-text-red-200")
                      : (a += " tw-border !tw-border-brandgray "),
          t.createElement(
            "div",
            { key: e.id, className: "tw-relative" },
            t.createElement(
              "div",
              {
                className: a,
                onClick: () => {
                  n(e);
                },
              },
              e.title
            ),
            e.isAlert &&
              "guardrail-2" === e.id &&
              i &&
              t.createElement(
                "div",
                {
                  id: `${e.id}-item-wrapper`,
                  className: "tw-absolute tw-inset-0 tw-z-0 tw-pointer-events-none",
                  style: { overflow: "visible" },
                },
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-delayed tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-more-delayed tw-opacity-40",
                })
              ),
            e.isAlert &&
              "guardrail-1" === e.id &&
              r &&
              t.createElement(
                "div",
                {
                  id: `${e.id}-item-wrapper`,
                  className: "tw-absolute tw-inset-0 tw-z-0 tw-pointer-events-none",
                  style: { overflow: "visible" },
                },
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-delayed tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-more-delayed tw-opacity-40",
                })
              )
          )
        );
      })
    );
  },
  j = ({ data: e, onControlClick: n }) =>
    t.createElement(
      "div",
      { className: "tw-text-white tw-flex-col tw-flex tw-items-center tw-overflow-x-visible" },
      t.createElement("h2", { className: "tw-text-[18px] tw-mb-4 tw-font-[500] tw-w-[200px]" }, "Active Policies"),
      t.createElement(
        "div",
        {
          className:
            "tw-flex tw-flex-col tw-gap-3 tw-font-[400] tw-text-[14.5px]  tw-h-[90%] tw-pb-14 tw-scroll-smooth\ttw-scrollbar-hidden",
          style: { overflowX: "visible" },
        },
        t.createElement($, { data: e, onControlClick: n })
      )
    ),
  Y = () =>
    t.createElement(
      "svg",
      {
        className: "agent-icon",
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement("path", {
        d: "M7.5 9.97414V4.16705C7.5 3.50401 7.76339 2.86813 8.23223 2.39929C8.70107 1.93045 9.33696 1.66705 10 1.66705C10.663 1.66705 11.2989 1.93045 11.7678 2.39929C12.2366 2.86813 12.5 3.50401 12.5 4.16705V5.00289M12.5 10.0016V15.8337C12.5 16.4968 12.2366 17.1326 11.7678 17.6015C11.2989 18.0703 10.663 18.3337 10 18.3337C9.33696 18.3337 8.70107 18.0703 8.23223 17.6015C7.76339 17.1326 7.5 16.4968 7.5 15.8337V14.9879",
        stroke: "rgb(13,14,15)",
        strokeLinecap: "round",
      }),
      t.createElement("path", {
        d: "M9.99935 12.5001H4.15935C2.78268 12.5001 1.66602 11.3809 1.66602 10.0001C1.66602 8.61923 2.78268 7.50006 4.15935 7.50006H4.99477M9.99935 7.50006H15.8281C16.4917 7.49951 17.1284 7.76258 17.5981 8.23141C18.0678 8.70024 18.332 9.33643 18.3327 10.0001C18.3327 11.3809 17.2114 12.5001 15.8281 12.5001H15.0268",
        stroke: "rgb(13,14,15)",
        strokeLinecap: "round",
      })
    ),
  W = () =>
    t.createElement(
      "svg",
      {
        id: "Layer_1",
        "data-name": "Layer 1",
        xmlns: "http://www.w3.org/2000/svg",
        version: "1.1",
        viewBox: "0 0 48 48",
      },
      t.createElement("path", {
        fill: "#ffffff",
        strokeWidth: 0,
        d: "M24,6.4L7.4,14.7l6.2,21.6,10.4,5.2,10.4-5.2,6.2-21.6L24,6.4ZM33.6,35.7l-9.6,4.8-9.6-4.8-5.8-20.4,15.4-7.7,15.4,7.7-5.8,20.4Z",
      }),
      t.createElement("path", {
        fill: "#ffffff",
        strokeWidth: 0,
        d: "M30.5,22.7c1.1,0,2-.9,2-2s-.9-2-2-2-1.1.3-1.5.7l-3.2-1.6c0-.1,0-.3,0-.4,0-1.1-.9-2-2-2s-2,.9-2,2,0,.3,0,.4l-3.2,1.6c-.4-.4-.9-.6-1.4-.6-1.1,0-2,.9-2,2s.9,2,2,2,.4,0,.7-.1l.9,1.4-1,1.4c-.2,0-.4-.1-.6-.1-1.1,0-2,.9-2,2s.9,2,2,2,1.1-.3,1.5-.7l3.2,1.6c0,.1,0,.3,0,.4,0,1.1.9,2,2,2s2-.9,2-2,0-.3,0-.4l3.2-1.6c.4.4.9.7,1.5.7,1.1,0,2-.9,2-2s-.9-2-2-2-.4,0-.6.1l-1-1.4,1-1.4c.2,0,.4.1.6.1ZM23.2,24.5s0,0-.1-.1h0c0-.1,0-.3,0-.4,0-.5.4-1,1-1s1,.4,1,1,0,.2,0,.4h0c0,0,0,.1-.1.2-.4.5-1.2.5-1.5,0ZM24.6,19.3l1.9,2.9-1.1.5c-.3-.3-.6-.5-1-.6v-2.8s0,0,.1,0ZM23.5,22.1c-.4.1-.7.3-1,.6l-1.1-.5,1.9-2.9s0,0,.1,0v2.8ZM20.9,25l-.7-1,.7-1,1.2.6c0,.1,0,.3,0,.4s0,.3,0,.4l-.9.4-.3.2ZM25.9,24.4c0-.1,0-.3,0-.4s0-.3,0-.4l1.2-.6.7,1-.7,1-1.2-.6ZM21.5,25.8h.2c0,0,.9-.5.9-.5,0,0,0,0,0,0,.2.3.6.5.9.6v2.8s0,0,0,0c0,0,0,0,0,0l-1.9-2.9ZM24.6,28.7s0,0,0,0c0,0,0,0,0,0v-2.8c.4,0,.7-.3.9-.6,0,0,0,0,0,0l1.1.5-1.9,2.9ZM30.5,19.8c.5,0,1,.4,1,1s-.4,1-1,1-1-.4-1-1,.4-1,1-1ZM28.6,21.1l-1.2.6-2-3,3.2,1.6c0,.1,0,.3,0,.4s0,.3,0,.4ZM24,16.5c.5,0,1,.4,1,1s-.4,1-1,1-1-.4-1-1,.4-1,1-1ZM22.5,18.7l-2,3-1.2-.6c0-.1,0-.2,0-.4s0-.3,0-.4l3.2-1.6ZM16.5,20.8c0-.5.4-1,1-1s1,.4,1,1-.4,1-1,1-1-.4-1-1ZM18.9,22s0,0,0,0l1.1.5-.4.5-.7-1.1ZM19.6,24.9l.4.5-1.1.5.7-1.1ZM16.5,27.3c0-.5.4-1,1-1s.7.2.9.5c0,.1.1.3.1.4,0,.1,0,.3-.1.4-.2.3-.5.5-.9.5s-1-.4-1-1ZM19.4,27.3h0c0-.1,0-.3,0-.4l1.2-.6,2,3h0s-3.2-1.6-3.2-1.6c0-.1,0-.3,0-.4ZM24,31.5c-.5,0-1-.4-1-1s0-.2,0-.4h0c0-.1.1-.2.2-.3,0,0,0,0,0,0,0,0,.1,0,.2-.1,0,0,0,0,.1,0,0,0,.2,0,.3,0,0,0,0,0,.1,0,0,0,.2,0,.3,0,0,0,0,0,.1,0,0,0,.1,0,.2.1,0,0,0,0,0,0,0,0,.1.2.2.3h0c0,.1,0,.3,0,.4,0,.5-.4,1-1,1ZM25.5,29.3h0s2-3,2-3l1.2.6c0,.1,0,.3,0,.4h0c0,.1,0,.3,0,.4l-3.2,1.6ZM31.5,27.3c0,.5-.4,1-1,1s-.7-.2-.9-.5c0-.1-.1-.3-.1-.4,0-.1,0-.3.1-.4.2-.3.5-.5.9-.5s1,.4,1,1ZM29.1,26l-1.1-.5.4-.5.7,1.1ZM28,22.6l1.1-.5-.7,1.1-.4-.5Z",
      }),
      t.createElement("path", { fill: "#ffffff", strokeWidth: 0, d: "M19,34.9v1.1l5,2.5,5-2.5v-1.1l-5,2.5-5-2.5Z" }),
      t.createElement("path", { fill: "#ffffff", strokeWidth: 0, d: "M32,14.6v-1.1l-8-4-8,4v1.1l8-4,8,4Z" })
    ),
  J = ({ title: e, subline: n, position: a = "top", type: i = "default", resolved: r = !1 }) => {
    let l = `tw-absolute tw-whitespace-nowrap ${{ top: "tw--top-10 tw-left-1/2 tw--translate-x-1/2", right: "tw-top-1/2 tw--translate-y-1/2 tw-left-full tw-ml-2", bottom: "tw-top-full tw-left-1/2 tw--translate-x-1/2 tw-mt-2", left: "tw-top-1/2 tw--translate-y-1/2 tw-right-full tw-mr-4" }[a]} !tw-border-brandbordergray tw-border tw-rounded-xl tw-p-1`;
    return (
      (l +=
        "alert" !== i || r
          ? "alert" === i && r
            ? " tw-bg-brandgreen !tw-border-brandgreen tw-text-branddialogbg"
            : " tw-text-white"
          : " tw-bg-brandred !tw-border-brandred tw-text-white"),
      t.createElement(
        "div",
        { className: `${l}` },
        t.createElement("div", { className: "tw-text-[14px]" }, e),
        n && t.createElement("div", { className: " tw-text-[10px]" }, n)
      )
    );
  };
var K = d(({ data: e }) => {
  const n = (e) => {
    if (!e) return {};
    switch (e) {
      case "running":
        return { background: "blue", animation: "node-pulse 2s ease-in-out infinite" };
      case "completed":
        return { background: "rgba(39, 174, 96, 0.2)", boxShadow: "0 0 15px rgba(39, 174, 96, 0.5)" };
      case "error":
        return { background: "rgba(255, 0, 0, 0.2)", boxShadow: "0 0 15px rgba(255, 0, 0, 0.5)" };
      default:
        return { background: "rgba(255, 255, 255, 0.1)", opacity: 0.8 };
    }
  };
  if (!e.hide)
    return e.type && "policy-alert" === e.type
      ? t.createElement(
          "div",
          { className: "wrapper wrapper-alert" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-justify-center tw-relative tw-w-full" },
            t.createElement("div", {
              className: "tw-absolute tw-w-full tw-h-px ",
              style: {
                background: e.resolved
                  ? "repeating-linear-gradient(to right, rgb(206, 255, 220) 0, rgb(206, 255, 220) 4px, transparent 4px, transparent 8px)"
                  : "repeating-linear-gradient(to right, rgba(208, 86, 89, 1) 0, rgba(208, 86, 89, 1) 4px, transparent 4px, transparent 8px)",
                backgroundSize: "8px 100%",
                backgroundPosition: "6px 0",
              },
            }),
            t.createElement(
              "div",
              { className: "tw-absolute ripple-wrapper" },
              t.createElement(
                "div",
                {
                  id: e.animating ? `ripple-point-eq-${e.controlId}` : "requires-ID",
                  className:
                    "tw-w-4 tw-h-4 tw-rounded-full tw-m-auto tw-relative " +
                    (e.resolved ? "tw-bg-brandgreen" : "tw-bg-brandalert"),
                },
                e.animating &&
                  t.createElement(
                    t.Fragment,
                    null,
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full animate-ripple " +
                        (e.resolved ? "tw-bg-brandgreen" : "tw-bg-brandalert"),
                      style: { opacity: "0.75" },
                    }),
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full animate-ripple-delayed " +
                        (e.resolved ? "tw-bg-brandgreen" : "tw-bg-brandalert"),
                      style: { opacity: "0.75" },
                    }),
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full animate-ripple-more-delayed " +
                        (e.resolved ? "tw-bg-brandgreen" : "tw-bg-brandalert"),
                      style: { opacity: "0.75" },
                    })
                  )
              )
            )
          ),
          e.title &&
            t.createElement(J, {
              title: e.title,
              subline: e.subline,
              position: e.labelPosition,
              resolved: e.resolved,
              type: "alert",
            })
        )
      : e.type && "nemo-guardrail" === e.type
        ? t.createElement(
            "div",
            { className: "wrapper tw-justify-center tw-items-center", style: n(e.status) },
            t.createElement(
              "div",
              { className: " tw-w-9 tw-h-9 tw-rounded-full" },
              t.createElement(W, null),
              t.createElement(p, { type: "target", position: u.Left }),
              t.createElement(p, { type: "source", position: u.Right }),
              t.createElement(p, { id: "sourcetop", type: "source", position: u.Top }),
              t.createElement(p, { id: "targetbottom", type: "target", position: u.Bottom }),
              t.createElement(p, { id: "sourceright", type: "source", position: u.Right }),
              t.createElement(p, { id: "targettop", type: "target", position: u.Top })
            ),
            e.title && t.createElement(J, { title: e.title, subline: e.subline, position: e.labelPosition })
          )
        : t.createElement(
            t.Fragment,
            null,
            t.createElement(
              "div",
              {
                className: `${e.parallelVertSize ? "wrapper-half" : "wrapper"}${e.hidden ? " !tw-opacity-0 " : ""}\n        tw-relative`,
                style: n(e.status),
              },
              "running" === e.status &&
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-[-2px] tw-rounded-full tw-border-8 tw-border-transparent tw-border-t-blue-400",
                  style: { animation: "rotate-ring 1s linear infinite" },
                }),
              t.createElement(
                "div",
                { className: "inner" },
                t.createElement(Y, null),
                t.createElement(p, { type: "target", position: u.Left }),
                t.createElement(p, { type: "source", position: u.Right }),
                t.createElement(p, { id: "sourcetop", type: "source", position: u.Top }),
                t.createElement(p, { id: "targetbottom", type: "target", position: u.Bottom }),
                t.createElement(p, { id: "sourceright", type: "source", position: u.Right }),
                t.createElement(p, { id: "targettop", type: "target", position: u.Top })
              ),
              e.title && t.createElement(J, { title: e.title, subline: e.subline, position: e.labelPosition })
            )
          );
});
const X = [
    {
      id: "claimant-details",
      position: { x: 200, y: 650 },
      data: {
        title: "Source Intelligence Details",
        labelPosition: "bottom",
        role: "Source Intelligence Details",
        backstory:
          "You process raw intelligence from field operatives, ensuring accurate collection of critical information while maintaining operational security protocols.",
        goal: "Collect comprehensive intelligence from sources, ensuring all relevant details are captured for proper assessment",
      },
      type: "turbo",
    },
    {
      id: "claimant-media",
      position: { x: 200, y: 750 },
      data: {
        title: "SIGINT Media",
        labelPosition: "bottom",
        role: "SIGINT Media",
        backstory:
          "You specialize in processing signals intelligence including communications, electronic emissions, and digital transmissions for national security purposes.",
        goal: "Process, categorize, and prepare SIGINT evidence for analysis, ensuring data integrity and proper classification",
      },
      type: "turbo",
    },
    {
      id: "triage-claims",
      position: { x: 380, y: 700 },
      data: {
        title: "Intelligence Triage",
        labelPosition: "bottom",
        role: "Intelligence Triage",
        backstory:
          "You evaluate incoming intelligence for credibility, relevance, and time-sensitivity to ensure critical information reaches decision-makers promptly.",
        goal: "Analyze incoming intelligence to categorize and prioritize based on criticality, reliability, and urgency to optimize resource allocation",
      },
      type: "turbo",
    },
    {
      id: "witness-evidence",
      position: { x: 300, y: 200 },
      data: {
        title: "HUMINT Reports",
        labelPosition: "top",
        role: "HUMINT Reports",
        backstory:
          "You specialize in human intelligence collection, managing field reports and identifying patterns across multiple sources.",
        goal: "Process and analyze human intelligence reports to extract actionable information for national security operations",
      },
      type: "turbo",
    },
    {
      id: "other-parties-media",
      position: { x: 300, y: 300 },
      data: {
        title: "Allied Intel Sharing",
        labelPosition: "top",
        role: "Allied Intel Sharing",
        backstory:
          "You manage intelligence shared by NATO allies and other partner nations, ensuring proper handling according to classification requirements.",
        goal: "Process shared intelligence from partner nations while maintaining proper attribution and classification protocols",
      },
      type: "turbo",
    },
    {
      id: "cctv",
      position: { x: 300, y: 400 },
      data: {
        title: "Geospatial Intelligence",
        labelPosition: "top",
        role: "Geospatial Intelligence",
        backstory:
          "You process satellite imagery, drone footage, and other geospatial data to identify strategic developments and threat indicators.",
        goal: "Analyze geospatial intelligence to identify key locations, movements, and patterns relevant to national security concerns",
      },
      type: "turbo",
    },
    {
      id: "other-media",
      position: { x: 300, y: 500 },
      data: {
        title: "OSINT Collection",
        labelPosition: "top",
        role: "OSINT Collection",
        backstory:
          "You gather and analyze open-source intelligence from public domains, social media, and commercial datasets.",
        goal: "Collect and analyze open-source information that provides context and supplements classified intelligence sources",
      },
      type: "turbo",
    },
    {
      id: "police-report",
      position: { x: 300, y: 600 },
      data: {
        title: "Law Enforcement Data",
        labelPosition: "top",
        role: "Law Enforcement Data",
        backstory:
          "You coordinate with domestic and international law enforcement to obtain relevant intelligence on threats to national security.",
        goal: "Gather and process information from law enforcement sources that may indicate potential national security threats",
      },
      type: "turbo",
    },
    {
      id: "group-evidence",
      position: { x: 640, y: 700 },
      data: {
        hidden: !0,
        title: "Intelligence Fusion",
        labelPosition: "top",
        role: "Intelligence Fusion",
        backstory:
          "You aggregate intelligence from multiple sources into a cohesive operational picture while maintaining proper classification levels.",
        goal: "Combine intelligence from diverse sources into a unified dataset for comprehensive threat analysis",
      },
      type: "turbo",
    },
    {
      id: "guardrail-1",
      position: { x: 650, y: 700 },
      data: {
        title: "Validate Classification and Legal Compliance",
        labelPosition: "bottom",
        type: "policy-alert",
        animating: !0,
        controlId: "guardrail-1",
        role: "Validate Classification and Legal Compliance",
        backstory:
          "You ensure all intelligence handling complies with relevant laws, treaties, and classification protocols to protect sources and methods.",
        goal: "Verify all intelligence is properly classified and handled according to legal frameworks including FISA and EO 12333",
      },
      type: "turbo",
    },
    {
      id: "analyze-data",
      position: { x: 800, y: 700 },
      data: {
        title: "Pattern and Anomaly Detection",
        labelPosition: "top",
        role: "Pattern and Anomaly Detection",
        backstory:
          "You apply advanced analytics to identify patterns, anomalies, and correlations across diverse intelligence sources.",
        goal: "Analyze collected intelligence to identify threat indicators, anomalous activities, and strategic patterns",
      },
      type: "turbo",
    },
    {
      id: "verify-policy",
      position: { x: 980, y: 800 },
      data: {
        title: "Verify National Security Priorities Alignment",
        labelPosition: "right",
        role: "Verify National Security Priorities Alignment",
        backstory:
          "You ensure intelligence findings align with established national security priorities and intelligence requirements.",
        goal: "Evaluate intelligence against current national security directives and collection priorities",
      },
      type: "turbo",
    },
    {
      id: "estimate-costs",
      position: { x: 980, y: 600 },
      data: {
        title: "Threat Assessment",
        labelPosition: "right",
        role: "Threat Assessment",
        backstory: "You evaluate potential threats based on capability, intent, opportunity, and historical precedent.",
        goal: "Quantify threat levels and potential impacts based on analysis of adversary capabilities and intentions",
      },
      type: "turbo",
    },
    {
      id: "guardrail-2",
      position: { x: 980, y: 500 },
      data: {
        controlId: "guardrail-2",
        type: "policy-alert",
        title: "Authorization for Sensitive Operations",
        labelPosition: "right",
        animating: !0,
        role: "Authorization for Sensitive Operations",
        backstory: "You ensure proper oversight and authorization for high-risk intelligence operations and reporting.",
        goal: "Validate automated intelligence assessments for sensitive situations requiring additional human oversight",
      },
      type: "turbo",
    },
    {
      id: "offer-care",
      position: { x: 650, y: 550 },
      data: {
        title: "Source Protection Assessment",
        labelPosition: "top",
        role: "Source Protection Assessment",
        backstory:
          "You identify operational security risks and develop measures to protect intelligence sources and methods.",
        goal: "Identify potential vulnerabilities in intelligence collection and recommend appropriate protection measures",
      },
      type: "turbo",
    },
    {
      id: "generate-plan",
      position: { x: 980, y: 400 },
      data: {
        title: "Generate Intelligence Product",
        labelPosition: "right",
        role: "Generate Intelligence Product",
        backstory:
          "You synthesize complex intelligence into actionable reports tailored to specific operational and strategic requirements.",
        goal: "Create detailed intelligence products that address identified threats, opportunities, and recommended courses of action",
      },
      type: "turbo",
    },
    {
      id: "notify-agent",
      position: { x: 980, y: 300 },
      data: {
        title: "Disseminate to Decision Makers",
        labelPosition: "left",
        role: "Disseminate to Decision Makers",
        backstory:
          "You ensure intelligence products reach appropriate decision-makers with proper context and classification.",
        goal: "Format and dispatch intelligence products to authorized personnel according to established dissemination protocols",
      },
      type: "turbo",
    },
    {
      id: "guardrail-check3",
      position: { x: 1100, y: 300 },
      data: {
        controlId: "guardrail-check3",
        resolved: !0,
        type: "policy-alert",
        title: "Human Verification of Intelligence Assessment",
        labelPosition: "top",
        role: "Human Verification of Intelligence Assessment",
        backstory:
          "You ensure qualified intelligence professionals review automated assessments before operational use.",
        goal: "Ensure that qualified human analysts verify AI-generated intelligence products before dissemination",
      },
      type: "turbo",
    },
    {
      id: "generate-summary",
      position: { x: 1200, y: 300 },
      data: {
        title: "Generate Brief for Joint Operations",
        labelPosition: "right",
        role: "Generate Brief for Joint Operations",
        backstory:
          "You compile finalized intelligence into standardized formats suitable for joint operations with NATO and partner nations.",
        goal: "Create standardized intelligence briefs compatible with joint operations systems and NATO protocols",
      },
      type: "turbo",
    },
  ],
  Q = [
    { id: "e1", source: "claimant-details", target: "triage-claims" },
    { id: "e2", source: "claimant-media", target: "triage-claims" },
    { id: "e3", source: "witness-evidence", target: "group-evidence" },
    { id: "e4", source: "other-parties-media", target: "group-evidence" },
    { id: "e5", source: "cctv", target: "group-evidence" },
    { id: "e6", source: "other-media", target: "group-evidence" },
    { id: "e7", source: "police-report", target: "group-evidence" },
    { id: "e8", source: "triage-claims", target: "analyze-data" },
    { id: "e9", source: "triage-claims", target: "offer-care" },
    { id: "e10", source: "analyze-data", target: "verify-policy" },
    {
      id: "e11",
      source: "verify-policy",
      target: "estimate-costs",
      sourceHandle: "sourcetop",
      targetHandle: "targetbottom",
    },
    {
      id: "e12",
      source: "estimate-costs",
      target: "generate-plan",
      sourceHandle: "sourcetop",
      targetHandle: "targetbottom",
    },
    { id: "e13", source: "offer-care", target: "generate-plan" },
    {
      id: "e14",
      source: "generate-plan",
      target: "notify-agent",
      sourceHandle: "sourcetop",
      targetHandle: "targetbottom",
    },
    { id: "e15", source: "notify-agent", target: "generate-summary" },
  ],
  ee = { turbo: K },
  te = {
    turbo: function ({
      id: e,
      sourceX: n,
      sourceY: a,
      targetX: i,
      targetY: r,
      sourcePosition: l,
      targetPosition: o,
      style: s = {},
      markerEnd: c,
    }) {
      const d = n === i,
        m = a === r,
        [w] = g({
          sourceX: d ? n + 1e-4 : n,
          sourceY: m ? a + 1e-4 : a,
          sourcePosition: l,
          targetX: i,
          targetY: r,
          targetPosition: o,
        });
      return t.createElement(
        t.Fragment,
        null,
        t.createElement("path", { id: e, style: s, className: "react-flow__edge-path", d: w, markerEnd: c })
      );
    },
  },
  ne = { type: "turbo", markerEnd: "edge-circle" },
  ae = ({ visible: e, content: n, position: a }) =>
    e
      ? n.isAlert
        ? t.createElement(
            "div",
            { style: { position: "absolute", left: a.x, top: a.y, zIndex: 99999 }, className: "tw-animate-fadeIn" },
            t.createElement(
              "div",
              {
                className:
                  "tw-bg-[#09090B]/95 tw-backdrop-blur-sm tw-border !tw-border-white/10 tw-rounded-lg tw-p-4 tw-w-[320px]",
              },
              t.createElement(
                "div",
                { className: "tw-flex tw-items-start tw-gap-3 tw-mb-3" },
                t.createElement(
                  "div",
                  null,
                  t.createElement(
                    "h3",
                    { className: "tw-text-white tw-text-sm tw-font-medium" },
                    "Authorization Required"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-gap-2 tw-mt-1" },
                    t.createElement(
                      "span",
                      {
                        className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-amber-500/10 tw-text-amber-400 tw-rounded",
                      },
                      "Auth Gate"
                    ),
                    t.createElement(
                      "span",
                      { className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-red-500/10 tw-text-red-400 tw-rounded" },
                      "Pending"
                    ),
                    t.createElement(
                      "span",
                      {
                        className:
                          "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-white/5 tw-text-white/60 tw-font-mono tw-rounded",
                      },
                      "GATE_ID: bak3f...a92d"
                    )
                  )
                )
              ),
              t.createElement(
                "div",
                { className: "tw-space-y-3" },
                t.createElement(
                  "div",
                  { className: "tw-p-2 tw-rounded-lg tw-bg-amber-500/[0.03] tw-border !tw-border-amber-500/10" },
                  t.createElement(
                    "div",
                    { className: "tw-text-xs tw-text-amber-400 tw-mb-1" },
                    "Critical System Notice"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-text-sm tw-text-white/90" },
                    "AI system requires authorization for emergency response prioritization. Social media data integration may influence rescue priority decisions."
                  )
                ),
                t.createElement(
                  "div",
                  { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                  t.createElement(
                    "div",
                    { className: "tw-text-xs tw-text-white/60 tw-mb-1" },
                    "Authorization Protocol"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-text-sm tw-text-white/90" },
                    "Human verification required for AI-driven emergency response system. Confirm implementation of safety controls before authorizing deployment."
                  )
                )
              )
            ),
            t.createElement(
              "style",
              null,
              "\n            @keyframes fadeIn {\n              from { opacity: 0; transform: translateY(-8px); }\n              to { opacity: 1; transform: translateY(0); }\n            }\n            .tw-animate-fadeIn {\n              animation: fadeIn 0.2s ease-out forwards;\n            }\n          "
            )
          )
        : t.createElement(
            "div",
            { style: { position: "absolute", left: a.x, top: a.y, zIndex: 99999 }, className: "tw-animate-fadeIn" },
            t.createElement(
              "div",
              {
                className:
                  "tw-bg-[#09090B]/95 tw-backdrop-blur-sm tw-border !tw-border-white/10 tw-rounded-lg tw-p-4 tw-w-[320px]",
              },
              n.role &&
                t.createElement(
                  "div",
                  { className: "tw-flex tw-items-start tw-gap-3 tw-mb-3" },
                  t.createElement(
                    "div",
                    null,
                    t.createElement("h3", { className: "tw-text-white tw-text-sm tw-font-medium" }, n.role),
                    t.createElement(
                      "div",
                      { className: "tw-flex tw-gap-2 tw-mt-1" },
                      t.createElement(
                        "span",
                        { className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-white/5 tw-text-white/60 tw-rounded" },
                        "Agent Node"
                      ),
                      t.createElement(
                        "span",
                        {
                          className:
                            "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-green-500/10 tw-text-green-400 tw-rounded",
                        },
                        "Active"
                      ),
                      t.createElement(
                        "span",
                        {
                          className:
                            "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-purple-500/10 tw-text-purple-400 tw-font-mono tw-rounded",
                        },
                        "bak3f...a92d"
                      )
                    )
                  )
                ),
              t.createElement(
                "div",
                { className: "tw-space-y-3" },
                n.backstory &&
                  t.createElement(
                    "div",
                    { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                    t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Backstory"),
                    t.createElement("div", { className: "tw-text-sm tw-text-white/90" }, n.backstory)
                  ),
                n.goal &&
                  t.createElement(
                    "div",
                    { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                    t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Primary Goal"),
                    t.createElement("div", { className: "tw-text-sm tw-text-white/90" }, n.goal)
                  )
              )
            ),
            t.createElement(
              "style",
              null,
              "\n        @keyframes fadeIn {\n          from { opacity: 0; transform: translateY(-8px); }\n          to { opacity: 1; transform: translateY(0); }\n        }\n        .tw-animate-fadeIn {\n          animation: fadeIn 0.2s ease-out forwards;\n        }\n      "
            )
          )
      : null,
  ie = ({ backgroundColor: e, textColor: n, onNodeClick: r = () => {} }) => {
    const l = e || "transparent",
      o = n || "rgb(243, 244, 246)",
      [c, d] = a({ visible: !1, content: {}, position: { x: 0, y: 0 } }),
      { state: m } = q(),
      [w, p, u] = h(X),
      [g, y, v] = f(Q);
    (i(() => {
      const e = w.map((e) => ({
        ...e,
        data: {
          ...e.data,
          status: m.nodes[e.id]?.status || "idle",
          animating:
            ("guardrail-2" === e.id && 0 === m.userOverrides.length) ||
            ("guardrail-1" === e.id && 0 === m.userRemediations.length),
          resolved:
            ("guardrail-2" === e.id && m.userOverrides.length > 0) ||
            ("guardrail-1" === e.id && m.userRemediations.length > 0) ||
            "guardrail-check3" === e.id,
          hide:
            ("nemo-guardrail1" === e.id && 0 === m.userRemediations.length) ||
            ("guardrail-1" === e.id && m.userRemediations.length > 0),
        },
      }));
      (console.log("Updated nodes:", e), p(e));
    }, [m, p]),
      i(() => {
        y((e) =>
          e.map((e) => {
            const t = m.nodes[e.source],
              n = m.nodes[e.target],
              a = "running" === t?.status,
              i =
                "idle" === n?.status
                  ? { opacity: 0.6, stroke: "rgb(222, 222, 222)" }
                  : { opacity: 1, stroke: "rgb(222, 222, 222)" };
            return { ...e, animated: a, style: i };
          })
        );
      }, [m, y]));
    const x = s((e) => y((t) => E(e, t)), []),
      [C, N] = a(null),
      I = s(() => {
        if (!C || !w?.length) return;
        C.fitView({ padding: 0.22 });
        const { x: e, y: t, zoom: n } = C.getViewport();
        C.setViewport({ x: e - 50, y: t + 10, zoom: n });
      }, [C, w]);
    (i(() => {
      (I(), d((e) => ({ visible: !1, content: {}, position: { x: 0, y: 0 } })));
    }, [I]),
      i(() => {
        const e = () => I();
        return (
          window.addEventListener("resize", e),
          () => {
            window.removeEventListener("resize", e);
          }
        );
      }, [I]));
    return t.createElement(
      t.Fragment,
      null,
      t.createElement(
        b,
        {
          style: { backgroundColor: l, color: o, position: "relative" },
          nodes: w,
          edges: g,
          onNodesChange: u,
          onEdgesChange: v,
          onConnect: x,
          nodeTypes: ee,
          edgeTypes: te,
          onInit: (e) => {
            N(e);
          },
          defaultEdgeOptions: ne,
          proOptions: { hideAttribution: !0 },
          onNodeClick: (e, t) => {
            r(t);
          },
          onNodeMouseEnter: (e, t) => {
            if (t.data?.role) {
              const n = document.querySelector(".react-flow");
              if (!n) return;
              const a = n.getBoundingClientRect(),
                i = e.target.getBoundingClientRect(),
                r = 320,
                l = 300,
                o = 32,
                s = i.top + i.height / 2;
              let c;
              c =
                a.right - i.right >= r + o
                  ? i.right - a.left + o
                  : i.left - a.left >= r + o
                    ? i.left - a.left - r - o
                    : Math.max(o, Math.min(a.width - r - o, i.left - a.left - r / 2));
              let m = s - a.top - l / 2;
              const w = o,
                p = a.height - l - 2 * o;
              ((m = Math.max(w, Math.min(m, p))),
                d({
                  visible: !0,
                  content: {
                    role: t.data.role,
                    backstory: t.data.backstory,
                    goal: t.data.goal,
                    isAlert: "reconfirm" === t.id || "remediate" === t.id,
                  },
                  position: { x: c, y: m },
                }));
            }
          },
          onNodeMouseLeave: () => {
            d((e) => ({ ...e, visible: !1 }));
          },
        },
        t.createElement(
          "svg",
          null,
          t.createElement(
            "defs",
            null,
            t.createElement(
              "marker",
              {
                id: "edge-circle",
                viewBox: "-5 -5 10 10",
                refX: "0",
                refY: "0",
                markerUnits: "strokeWidth",
                markerWidth: "10",
                markerHeight: "10",
                orient: "auto",
              },
              t.createElement("circle", { fill: "rgba(22, 189, 202, 1)", r: "2", cx: "0", cy: "0" })
            ),
            t.createElement(
              "symbol",
              { id: "agent-icon", viewBox: "0 0 20 20" },
              t.createElement("path", {
                d: "M7.5 9.97414V4.16705C7.5 3.50401 7.76339 2.86813 8.23223 2.39929C8.70107 1.93045 9.33696 1.66705 10 1.66705C10.663 1.66705 11.2989 1.93045 11.7678 2.39929C12.2366 2.86813 12.5 3.50401 12.5 4.16705V5.00289M12.5 10.0016V15.8337C12.5 16.4968 12.2366 17.1326 11.7678 17.6015C11.2989 18.0703 10.663 18.3337 10 18.3337C9.33696 18.3337 8.70107 18.0703 8.23223 17.6015C7.76339 17.1326 7.5 16.4968 7.5 15.8337V14.9879",
                stroke: "white",
                strokeLinecap: "round",
              }),
              t.createElement("path", {
                d: "M9.99935 12.5001H4.15935C2.78268 12.5001 1.66602 11.3809 1.66602 10.0001C1.66602 8.61923 2.78268 7.50006 4.15935 7.50006H4.99477M9.99935 7.50006H15.8281C16.4917 7.49951 17.1284 7.76258 17.5981 8.23141C18.0678 8.70024 18.332 9.33643 18.3327 10.0001C18.3327 11.3809 17.2114 12.5001 15.8281 12.5001H15.0268",
                stroke: "white",
                strokeLinecap: "round",
              })
            )
          )
        ),
        t.createElement(ae, { visible: c.visible, content: c.content, position: c.position })
      )
    );
  },
  re = ({ control: e, onOverride: n, onCancel: a, onDetails: i }) => {
    const r = "authorize" === e.alertType;
    return t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full" },
      t.createElement(
        "div",
        { className: "tw-rounded-xl tw-bg-branddialogbg tw-p-6 tw-max-w-[258px] tw-space-y-6 mt-3" },
        t.createElement(
          "div",
          {
            id: "eq-control-dialog",
            className: `tw-inline-block ${r ? "tw-bg-permission-gradient" : "tw-bg-red-500/20"} tw-text-white tw-rounded-lg tw-px-4 tw-py-2 tw-text-xs`,
          },
          r ? "Permissions needed" : "Remediation required"
        ),
        t.createElement(
          "p",
          { className: "tw-text-white tw-text-base" },
          r
            ? "This workflow is non-compliant without human authorization of multiple Sourcing Protocol controls."
            : "This workflow cannot proceed due to CUI handling requirements (32 CFR Part 2002). Controlled Unclassified Information must be properly secured with appropriate safeguards before execution."
        ),
        t.createElement(
          "div",
          { className: "tw-space-y-3" },
          r &&
            t.createElement(
              "button",
              {
                onClick: n,
                onMouseEnter: () => {
                  const e = document.getElementById("ripple-point-eq-ctrl-3");
                  e?.setAttribute("data-eqalertoverride", "true");
                },
                onMouseLeave: () => {
                  const e = document.getElementById("ripple-point-eq-ctrl-3");
                  e?.setAttribute("data-eqalertoverride", "false");
                },
                className:
                  "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-override-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
              },
              "Grant Authorization"
            ),
          t.createElement(
            "button",
            {
              onClick: a,
              className:
                "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-cancel-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
            },
            r ? "Cancel" : "Close"
          ),
          t.createElement(
            "button",
            {
              className:
                "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-open-details-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
              onClick: i,
            },
            "Open Details"
          )
        )
      )
    );
  },
  le = ({ onClose: e }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full tw-bg-branddialogbg_full tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-[600px] tw-p-6" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-justify-between tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-3" },
            t.createElement(
              "div",
              { className: "tw-px-2 tw-py-1 tw-bg-brandreddark tw-rounded-md tw-text-xs tw-text-white" },
              "CTRL-003"
            ),
            t.createElement("h2", { className: "tw-text-lg tw-text-white" }, "Sourcing Protocol: AI Action")
          ),
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2" },
            t.createElement("div", { className: "tw-w-2 tw-h-2 tw-bg-brandreddark tw-rounded-full tw-animate-pulse" }),
            t.createElement("span", { className: "tw-text-xs tw-text-white/60" }, "Active Control")
          )
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Purpose"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                "Governs AI decision-making in emergency response when processing social media and life-safety data"
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-gradient-to-br tw-from-brandreddark/20 tw-to-brandreddark/10 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Critical Triggers"),
              t.createElement(
                "ul",
                { className: "tw-space-y-2" },
                ["Life-threat detection", "Unverified social data", "Direct response actions"].map((e, n) =>
                  t.createElement(
                    "li",
                    { key: n, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white" },
                    t.createElement("div", { className: "tw-w-1 tw-h-1 tw-bg-brandreddark tw-rounded-full" }),
                    e
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
            t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Requirements"),
            t.createElement(
              "ul",
              { className: "tw-space-y-2" },
              [
                "Human authorization required",
                "Social media verification",
                "Cross-validation with EMS",
                "Override documentation",
              ].map((e, n) =>
                t.createElement(
                  "li",
                  { key: n, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white/80" },
                  t.createElement("div", { className: "tw-text-brandreddark" }, "•"),
                  e
                )
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-between tw-items-center tw-text-xs tw-text-white/40" },
          t.createElement("div", null, "Last Update: 2024-01-15"),
          t.createElement("div", null, "Priority: Critical")
        ),
        t.createElement(
          "button",
          {
            onClick: e,
            className:
              "tw-w-24 tw-absolute tw-bottom-4 tw-right-0 tw-left-0 tw-m-auto tw-text-white tw-text-xs tw-py-1.5 tw-rounded-lg tw-bg-brandreddark hover:tw-bg-opacity-90 tw-transition-colors",
          },
          "Close"
        )
      )
    ),
  oe = ({ onClose: e, onClick: n }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full tw-bg-branddialogbg_full tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-[640px] tw-p-4" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-justify-between tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-3" },
            t.createElement(
              "div",
              { className: "tw-px-2 tw-py-1 tw-bg-brandreddark tw-rounded-md tw-text-xs tw-text-white" },
              "CTRL-041"
            ),
            t.createElement(
              "div",
              { className: "tw-flex tw-items-center tw-gap-2" },
              t.createElement("h2", { className: "tw-text-lg tw-text-white" }, "CUI: 32 CFR Part 2002"),
              t.createElement("h4", { className: "tw-text-xs tw-text-white" }, "(Controlled Unclassified Information)")
            )
          ),
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2" },
            t.createElement("div", { className: "tw-w-2 tw-h-2 tw-bg-brandreddark tw-rounded-full tw-animate-pulse" }),
            t.createElement("span", { className: "tw-text-xs tw-text-white/60" }, "Active Control")
          )
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Purpose"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                "32 CFR Part 2002 requires federal agencies to implement appropriate safeguards to protect Controlled Unclassified Information (CUI) from unauthorized access and disclosure."
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-gradient-to-br tw-from-brandreddark/20 tw-to-brandreddark/10 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Critical Triggers"),
              t.createElement(
                "ul",
                { className: "tw-space-y-2" },
                [
                  "Presence of CUI in training dataset",
                  "Presence of CUI in inference operations",
                  "No detection of CUI classification markers",
                ].map((e, n) =>
                  t.createElement(
                    "li",
                    { key: n, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white" },
                    t.createElement("div", { className: "tw-w-1 tw-h-1 tw-bg-brandreddark tw-rounded-full" }),
                    e
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Requirements"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                "Implement safeguards to protect Controlled Unclassified Information from exposure in model training and inference within intelligence processing workflows."
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Suggested Action"),
              t.createElement(
                "div",
                { className: "tw-flex tw-justify-between tw-items-center" },
                t.createElement("span", { className: "tw-text-sm tw-text-white" }, "Implement:"),
                t.createElement(
                  "button",
                  {
                    onClick: n,
                    className:
                      "tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1.5 tw-bg-nvidiagreen tw-rounded-lg tw-text-white hover:tw-bg-opacity-90 tw-transition-colors hover:tw-shadow-md",
                  },
                  t.createElement("div", { className: "tw-w-8 tw-h-8" }, t.createElement(W, null)),
                  t.createElement("span", { className: "tw-text-xs" }, "Nemo Guardrail - CUI")
                )
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-between tw-items-center tw-text-xs tw-text-white/40" },
          t.createElement("div", null, "Last Update: 2024-01-15"),
          t.createElement("div", null, "Priority: Critical")
        ),
        t.createElement(
          "button",
          {
            onClick: e,
            className:
              "tw-w-24 tw-absolute tw-bottom-4 tw-right-0 tw-left-0 tw-m-auto tw-text-white tw-text-xs tw-py-1.5 tw-rounded-lg tw-bg-brandreddark hover:tw-bg-opacity-90 tw-transition-colors",
          },
          "Close"
        )
      )
    ),
  se = [
    { name: "Intelligence Fusion", details: "NVIDIA LLM & SIGINT Integration", color: "tw-border-purple-500/30" },
    { name: "Threat Assessment", details: "Nemo Guardrails & Analyst Override", color: "tw-border-green-500/30" },
    { name: "Mission Support", details: "JWICS & NATO Gateway Integration", color: "tw-border-orange-500/30" },
  ],
  ce = () => {
    const { state: e } = q(),
      n = e.userOverrides.length > 0 && e.userRemediations.length > 0,
      a = [
        {
          value: 15,
          label: "Total Agents",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M7 1.75L12.25 4.375V9.625L7 12.25L1.75 9.625V4.375L7 1.75Z",
              stroke: "currentColor",
              strokeWidth: "1.2",
            })
          ),
          color: "tw-text-cyan-400/80",
        },
        {
          value: e.userRemediations.length,
          label: "CUI Controls",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M2.33334 2.33334H11.6667M2.33334 7H11.6667M2.33334 11.6667H11.6667",
              stroke: "currentColor",
              strokeWidth: "1.2",
              strokeLinecap: "round",
            })
          ),
          color: "tw-text-green-400/80",
        },
        {
          value: 3,
          label: "Intel Sources",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M4.66666 1.75H9.33332L11.6667 4.08333V9.91667L9.33332 12.25H4.66666L2.33333 9.91667V4.08333L4.66666 1.75Z",
              stroke: "currentColor",
              strokeWidth: "1.2",
            })
          ),
          color: "tw-text-purple-400/80",
        },
        {
          value: 2,
          label: "Allied Systems",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M7.58333 1.75H11.6667V5.83333M11.6667 1.75L8.16667 5.25M6.41667 12.25H2.33333V8.16667M2.33333 12.25L5.83333 8.75",
              stroke: "currentColor",
              strokeWidth: "1.2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            })
          ),
          color: "tw-text-orange-400/80",
        },
      ];
    return t.createElement(
      "div",
      { className: "tw-w-[264px] tw-flex tw-flex-col tw-bg-branddialogbg tw-rounded-xl tw-p-4 mt-3" },
      t.createElement(
        "div",
        {
          className:
            "tw-w-full tw-text-center tw-py-1 tw-mb-4 tw-rounded-lg tw-text-sm tw-font-medium " +
            (n ? "tw-bg-brandgreen tw-text-branddialogbg" : "tw-bg-brandred tw-text-white"),
        },
        n ? "Compliant" : "Non-Compliant"
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
        t.createElement(
          "div",
          null,
          t.createElement(
            "h3",
            { className: "tw-text-white tw-text-sm tw-font-medium" },
            "Joint Intelligence Briefing"
          ),
          t.createElement("p", { className: "tw-text-white/60 tw-text-xs" }, "Agentic Workflow")
        )
      ),
      t.createElement(
        "div",
        { className: "tw-grid tw-grid-cols-2 tw-gap-2 tw-mb-4" },
        a.map((e, n) =>
          t.createElement(
            "div",
            { key: n, className: "tw-bg-white/[0.03] tw-rounded-lg tw-p-2 tw-border !tw-border-white/10" },
            t.createElement(
              "div",
              { className: `tw-flex tw-items-center tw-gap-1.5 ${e.color}` },
              e.value,
              t.createElement("span", { className: "tw-text-xs" }, e.label)
            )
          )
        )
      ),
      t.createElement(
        "div",
        { className: "tw-mb-3" },
        t.createElement(
          "div",
          { className: "tw-text-white/80 tw-text-xs tw-font-medium tw-mb-2" },
          "Intelligence Sources"
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-flex-wrap tw-gap-1" },
          ["Satellite Imagery", "SIGINT Data", "HUMINT Reports", "OSINT Feeds"].map((e) =>
            t.createElement(
              "span",
              {
                key: e,
                className:
                  "tw-px-2 tw-py-0.5 tw-rounded-full tw-text-[10px] tw-bg-white/[0.03] tw-border !tw-border-white/10 tw-text-white/80",
              },
              e
            )
          )
        )
      ),
      t.createElement(
        "div",
        { className: "tw-space-y-2" },
        se.map((e, n) =>
          t.createElement(
            "div",
            { key: n, className: `tw-border-l-2 ${e.color} tw-pl-2 tw-py-0.5` },
            t.createElement("div", { className: "tw-text-white tw-text-xs tw-font-medium" }, e.name),
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, e.details)
          )
        )
      )
    );
  },
  de = () =>
    t.createElement(
      "svg",
      { width: "32", height: "32", viewBox: "0 0 32 32", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
      t.createElement(
        "g",
        { clipPath: "url(#clip0_64855_12690)" },
        t.createElement("rect", { y: "6.10352e-05", width: "32", height: "32", rx: "16", fill: "black" }),
        t.createElement("rect", { x: "0.5", y: "0.500061", width: "31", height: "31", stroke: "#A9A9A9" }),
        t.createElement(
          "g",
          { filter: "url(#filter0_i_64855_12690)" },
          t.createElement("rect", { x: "0.5", y: "0.500061", width: "31", height: "31", rx: "15.5", stroke: "black" }),
          t.createElement("path", {
            d: "M13.5 15.9741V10.1671C13.5 9.50401 13.7634 8.86813 14.2322 8.39929C14.7011 7.93045 15.337 7.66705 16 7.66705C16.663 7.66705 17.2989 7.93045 17.7678 8.39929C18.2366 8.86813 18.5 9.50401 18.5 10.1671V11.0029M18.5 16.0016V21.8337C18.5 22.4968 18.2366 23.1326 17.7678 23.6015C17.2989 24.0703 16.663 24.3337 16 24.3337C15.337 24.3337 14.7011 24.0703 14.2322 23.6015C13.7634 23.1326 13.5 22.4968 13.5 21.8337V20.9879",
            stroke: "white",
            strokeLinecap: "round",
          }),
          t.createElement("path", {
            d: "M15.9993 18.5001H10.1593C8.78268 18.5001 7.66602 17.3809 7.66602 16.0001C7.66602 14.6192 8.78268 13.5001 10.1593 13.5001H10.9948M15.9993 13.5001H21.8281C22.4917 13.4995 23.1284 13.7626 23.5981 14.2314C24.0678 14.7002 24.332 15.3364 24.3327 16.0001C24.3327 17.3809 23.2114 18.5001 21.8281 18.5001H21.0268",
            stroke: "white",
            strokeLinecap: "round",
          })
        )
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "filter",
          {
            id: "filter0_i_64855_12690",
            x: "0",
            y: "6.10352e-05",
            width: "32",
            height: "32",
            filterUnits: "userSpaceOnUse",
            colorInterpolationFilters: "sRGB",
          },
          t.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
          t.createElement("feBlend", {
            mode: "normal",
            in: "SourceGraphic",
            in2: "BackgroundImageFix",
            result: "shape",
          }),
          t.createElement("feColorMatrix", {
            in: "SourceAlpha",
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
            result: "hardAlpha",
          }),
          t.createElement("feMorphology", {
            radius: "1",
            operator: "erode",
            in: "SourceAlpha",
            result: "effect1_innerShadow_64855_12690",
          }),
          t.createElement("feOffset", null),
          t.createElement("feComposite", { in2: "hardAlpha", operator: "arithmetic", k2: "-1", k3: "1" }),
          t.createElement("feColorMatrix", { type: "matrix", values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" }),
          t.createElement("feBlend", { mode: "normal", in2: "shape", result: "effect1_innerShadow_64855_12690" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_64855_12690" },
          t.createElement("rect", { y: "6.10352e-05", width: "32", height: "32", rx: "16", fill: "white" })
        )
      )
    ),
  me = () =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-gap-1 tw-h-[40px] tw-px-2 tw-bg-[rgb(223,246,246)] tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-8 tw-h-8 tw-bg-black tw-rounded-full tw-flex tw-items-center tw-justify-center" },
        t.createElement(de, null)
      ),
      t.createElement(
        "span",
        { className: "tw-text-black tw-text-[16px] ftw-ont-[400]" },
        "Joint Intelligence Briefing"
      )
    ),
  we = ({ showCertApp: e, setShowCertApp: n }) =>
    t.createElement("div", { className: "tw-flex tw-items-center tw-gap-2" }, t.createElement(me, null)),
  pe = ({ tabs: e, onTabChange: n }) => {
    const [i, r] = a(() => e.find((e) => e.current)?.name || e[0].name);
    return t.createElement(
      "div",
      { className: "tw-px-4 tw-py-6 sm:tw-px-6 lg:tw-px-8 tw-grow" },
      t.createElement(
        "div",
        { className: "tw-mx-auto tw-max-w-7xl" },
        t.createElement(
          "nav",
          { className: "tw-flex tw-py-4" },
          t.createElement(
            "ul",
            {
              role: "list",
              className:
                "tw-flex tw-min-w-full tw-flex-wrap tw-gap-x-6 tw-gap-y-2 tw-px-2 tw-text-sm tw-font-semibold tw-text-gray-400",
            },
            e.map((e) =>
              t.createElement(
                "li",
                {
                  key: e.name,
                  className: "tw-whitespace-nowrap hover:tw-text-gray-300 tw-cursor-pointer",
                  onClick: () => {
                    return ((t = e.name), r(t), void n(t));
                    var t;
                  },
                },
                t.createElement(
                  "span",
                  {
                    className:
                      "tw-block tw-px-1 tw-py-2 tw-transition-colors tw-duration-150 tw-cursor-pointer  " +
                      (i === e.name ? "tw-text-indigo-400" : ""),
                  },
                  e.name
                )
              )
            )
          )
        )
      )
    );
  },
  ue = () =>
    t.createElement(
      "div",
      { className: "tw-flex  tw-items-end tw-gap-4 " },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full",
          style: { backgroundColor: "rgba(206, 255, 220, 1)" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Compliant"
        )
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full",
          style: { backgroundColor: "rgba(208, 86, 89, 1)" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Not compliant"
        )
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full tw-border !tw-border-dashed",
          style: { borderColor: "rgba(255, 255, 255, 1) !important" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Unknown"
        )
      )
    );
var ge;
!(function (e) {
  ((e[(e.THIN = 1.5)] = "THIN"), (e[(e.NORMAL = 2)] = "NORMAL"), (e[(e.THICK = 8)] = "THICK"));
})(ge || (ge = {}));
const he = x(
    C(
      {
        buttons: [],
        props: [
          {
            title: "Executive Order 12333",
            color: "#5db0c8",
            width: ge.NORMAL,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "Foreign Intelligence Surveillance Act (FISA)",
            color: "#3c3d3d",
            width: ge.THIN,
            count: 2,
            hovered: !1,
            animation: null,
          },
          { title: "Sourcing Protocol", color: "#a35456", width: ge.THICK, count: 1, hovered: !1, animation: null },
          {
            title: "Controlled Unclassified Information (CUI)",
            color: "#ffffff",
            width: ge.NORMAL,
            count: 1,
            hovered: !1,
            animation: null,
          },
          {
            title: "Intelligence Community Directive 102",
            color: "#3c3d3d",
            width: ge.THIN,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "National Intelligence Priorities Framework",
            color: "#ffffff",
            width: ge.NORMAL,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "Intelligence Authorization Act",
            color: "#3c3d3d",
            width: ge.THIN,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "NATO Security Classification Protocols",
            color: "#3c3d3d",
            width: ge.THICK,
            count: 1,
            hovered: !1,
            animation: null,
          },
          {
            title: "National Space Security Policy",
            color: "#a35456",
            width: ge.THICK,
            count: 1,
            hovered: !1,
            animation: null,
          },
        ],
      },
      (e) => ({
        toggleHover: (t) => {
          e((e) => {
            const n = [...e.props];
            return ((n[t].hovered = !n[t].hovered), { props: n });
          });
        },
        setHover: (t, n) => {
          e((e) => {
            const a = [...e.props];
            return ((a[t].hovered = n), { props: a });
          });
        },
        setAnimation: (t, n) => {
          e((e) => {
            if (e.props[t].animation) return e;
            const a = [...e.props];
            return ((a[t].animation = n), { props: a });
          });
        },
        setButton: (t, n) => {
          e((e) => {
            const a = [...e.buttons];
            return ((a[t] = n), { buttons: a });
          });
        },
      })
    )
  ),
  fe = (e, t) => {
    const n = [...document.querySelectorAll(e)];
    if (!n || !n.length) return;
    const a = n[0].getTotalLength();
    return (
      n.forEach((e) => {
        ((e.style.strokeDasharray = `0 ${a}`), (e.style.strokeDashoffset = "0"));
      }),
      t.to(e, { strokeDasharray: `${a} ${a}`, duration: 1, ease: "power1.inOut" })
    );
  },
  Ee = () => {
    const e = he((e) => e.buttons),
      r = he((e) => e.props),
      [l, o] = a([]),
      [s, c] = a([]),
      d = n(null);
    (i(() => {
      if (!e[0]) return;
      const n = d.current?.getBoundingClientRect(),
        a = n?.height || 1,
        i = n?.width || 1,
        l = [],
        s = [];
      (e.forEach((n, o) => {
        const c = n.getBoundingClientRect();
        for (let n = 0; n < r[o].count; n++) {
          const d = c.top + c.height / 2 - 18 * n,
            m = a / 1.5 - 20 * (e.length - o) - 18 * n,
            w = `M0 ${d} H100  L${0.7 * i} ${m}  H${i}`,
            p = t.createElement("path", {
              d: w,
              stroke: r[o].color,
              strokeWidth: 0.8 * r[o].width,
              className: `line${o + 1} line`,
            });
          l.push(p);
          const u = `M0 ${d - 10} v20 L15 ${d} L0 ${d - 10} Z`,
            g = t.createElement("path", { d: u, fill: r[o].color });
          s.push(g);
        }
      }),
        o(l),
        c(s));
    }, [e]),
      m(() => {
        if (!l.length) return;
        const e = v.timeline({
          delay: 2,
          onComplete: () => {
            e.kill();
          },
        });
        fe(".line", e);
      }, [l.length]));
    const w = d.current?.getBoundingClientRect(),
      p = w?.width || 0,
      u = w?.height || 0,
      g = e[0]?.getBoundingClientRect() || 0,
      h = e[e.length - 1]?.getBoundingClientRect() || 0;
    return t.createElement(
      "div",
      { className: "tw-w-full tw-h-screen ", ref: d },
      t.createElement(
        "svg",
        { className: "tw-w-full tw-h-full ", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
        t.createElement(
          "g",
          { id: "lines-bg" },
          t.createElement("path", {
            d: `M100 ${g.top + g.height / 2} L100 ${h.top + h.height / 2} V${h.top + h.height / 2} L${0.7 * p} ${u / 1.5} V${u / 1.5 - 20 * e.length} Z`,
            fill: "#242625",
            fillOpacity: "0.59",
          })
        ),
        [...l],
        [...s]
      )
    );
  },
  be = w(({ title: e, i: n, ...a }, i) => {
    const r = he((e) => e.props);
    let l = "";
    switch (r[n].color) {
      case "#ffffff":
        l = "hover:tw-bg-white hover:tw-text-black";
        break;
      case "#5db0c8":
        l = "hover:tw-bg-btn-blue hover:tw-border-btn-blue";
        break;
      case "#a35456":
        l = "hover:tw-bg-btn-red hover:tw-border-btn-red";
        break;
      case "#3c3d3d":
        l = "hover:tw-bg-btn-grey hover:tw-border-btn-grey";
    }
    return t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-stretch tw-gap-x-2" },
      t.createElement(
        "div",
        {
          className: `tw-p-2 tw-border tw-font-medium tw-text-sm tw-border-gray-400 tw-rounded-lg tw-cursor-pointer tw-grow ${l}`,
          ...a,
          ref: i,
        },
        e
      ),
      t.createElement("p", { className: "tw-mr-4 tw-text-lg tw-font-bold" }, "10")
    );
  }),
  ye = () => {
    const e = he((e) => e.props),
      n = he((e) => e.setButton),
      { contextSafe: i } = y({ dependencies: [] }),
      [r, l] = a(new Array(e.length).fill(null)),
      o = i((e) => {
        const t = v.timeline({ paused: !0, repeatRefresh: !0 }),
          n = `.line${e + 1}`;
        let a = null;
        (r[e]
          ? (a = r[e])
          : ((a =
              2 === e
                ? ((e, t) => {
                    const n = [...document.querySelectorAll(e)];
                    if (n && n.length) return t.to(e, { opacity: 0, repeat: -1, yoyo: !0, ease: "power1.inOut" });
                  })(n, t)
                : fe(n, t)),
            l((t) => {
              const n = [...t];
              return ((n[e] = a), n);
            })),
          a && a.restart());
      }),
      s = i((e) => {
        2 === e && r[e] && r[e].revert();
      });
    return t.createElement(
      "div",
      null,
      t.createElement("h2", { className: "tw-mb-2 tw-text-lg tw-font-semibold" }, "Active Controls"),
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-gap-y-3" },
        e.map((e, a) =>
          t.createElement(be, {
            ref: (e) => e && n(a, e),
            key: a,
            i: a,
            title: e.title,
            onMouseOver: () => o(a),
            onMouseOut: () => s(a),
          })
        )
      )
    );
  };
function ve() {
  return t.createElement(
    "svg",
    { width: "20", height: "20", viewBox: "0 0 32 32", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_946)" },
      t.createElement("rect", { x: "1.24463", y: "0.5", width: "29.9787", height: "31", stroke: "#A9A9A9" }),
      t.createElement(
        "g",
        { filter: "url(#filter0_i_429_946)" },
        t.createElement("rect", {
          x: "1.24463",
          y: "0.5",
          width: "29.9787",
          height: "31",
          rx: "14.9894",
          stroke: "#F8F8F8",
        }),
        t.createElement("path", {
          d: "M14.2446 15.9741V10.167C14.2446 9.50395 14.508 8.86807 14.9769 8.39923C15.4457 7.93038 16.0816 7.66699 16.7446 7.66699C17.4077 7.66699 18.0436 7.93038 18.5124 8.39923C18.9812 8.86807 19.2446 9.50395 19.2446 10.167V11.0028M19.2446 16.0016V21.8337C19.2446 22.4967 18.9812 23.1326 18.5124 23.6014C18.0436 24.0703 17.4077 24.3337 16.7446 24.3337C16.0816 24.3337 15.4457 24.0703 14.9769 23.6014C14.508 23.1326 14.2446 22.4967 14.2446 21.8337V20.9878",
          stroke: "#F8F8F8",
          strokeLinecap: "round",
        }),
        t.createElement("path", {
          d: "M16.744 18.5H10.904C9.52731 18.5 8.41064 17.3808 8.41064 16C8.41064 14.6192 9.52731 13.5 10.904 13.5H11.7394M16.744 13.5H22.5727C23.2364 13.4994 23.873 13.7625 24.3427 14.2313C24.8124 14.7002 25.0766 15.3364 25.0773 16C25.0773 17.3808 23.9561 18.5 22.5727 18.5H21.7715",
          stroke: "#F8F8F8",
          strokeLinecap: "round",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "filter",
        {
          id: "filter0_i_429_946",
          x: "0.744629",
          y: "0",
          width: "30.9787",
          height: "32",
          filterUnits: "userSpaceOnUse",
          colorInterpolationFilters: "sRGB",
        },
        t.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
        t.createElement("feBlend", { mode: "normal", in: "SourceGraphic", in2: "BackgroundImageFix", result: "shape" }),
        t.createElement("feColorMatrix", {
          in: "SourceAlpha",
          type: "matrix",
          values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
          result: "hardAlpha",
        }),
        t.createElement("feMorphology", {
          radius: "1",
          operator: "erode",
          in: "SourceAlpha",
          result: "effect1_innerShadow_429_946",
        }),
        t.createElement("feOffset", null),
        t.createElement("feComposite", { in2: "hardAlpha", operator: "arithmetic", k2: "-1", k3: "1" }),
        t.createElement("feColorMatrix", { type: "matrix", values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" }),
        t.createElement("feBlend", { mode: "normal", in2: "shape", result: "effect1_innerShadow_429_946" })
      ),
      t.createElement(
        "clipPath",
        { id: "clip0_429_946" },
        t.createElement("rect", { x: "0.744629", width: "30.9787", height: "32", rx: "15.4894", fill: "white" })
      )
    )
  );
}
function xe() {
  return t.createElement(
    "svg",
    { width: "12", height: "12", viewBox: "0 0 23 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement("path", {
      d: "M22.2852 20.3123L13.157 1.925C12.51 0.621353 10.7864 0.621353 10.1389 1.925L1.0112 20.3123C0.870699 20.5954 0.800263 20.9131 0.806763 21.2344C0.813263 21.5558 0.896466 21.8698 1.04822 22.1458C1.20001 22.4219 1.41519 22.6506 1.67277 22.8095C1.93031 22.9685 2.2215 23.0523 2.51781 23.0528H20.7758C21.0724 23.0528 21.3639 22.9693 21.6219 22.8106C21.8798 22.6519 22.0953 22.4233 22.2475 22.1471C22.3995 21.8709 22.483 21.5567 22.4896 21.2351C22.4962 20.9135 22.4258 20.5956 22.2852 20.3123ZM11.6482 20.2061C11.4363 20.2061 11.2293 20.1379 11.053 20.0102C10.8769 19.8826 10.7396 19.7011 10.6585 19.4888C10.5774 19.2764 10.5562 19.0428 10.5976 18.8174C10.6389 18.5921 10.7409 18.385 10.8907 18.2225C11.0405 18.06 11.2314 17.9494 11.4392 17.9045C11.647 17.8597 11.8624 17.8827 12.0581 17.9706C12.2538 18.0586 12.4211 18.2075 12.5389 18.3986C12.6565 18.5897 12.7193 18.8143 12.7193 19.0441C12.7193 19.1967 12.6917 19.3478 12.6379 19.4888C12.584 19.6297 12.5051 19.7578 12.4056 19.8657C12.3062 19.9736 12.188 20.0592 12.0581 20.1176C11.9281 20.176 11.7888 20.2061 11.6482 20.2061ZM12.8115 8.52005L12.5041 15.6078C12.5041 15.8542 12.4138 16.0907 12.2531 16.265C12.0923 16.4394 11.8744 16.5373 11.6471 16.5373C11.4198 16.5373 11.2019 16.4394 11.0411 16.265C10.8804 16.0907 10.7901 15.8542 10.7901 15.6078L10.4827 8.52295C10.4758 8.35365 10.5003 8.1846 10.555 8.02585C10.6096 7.86705 10.6931 7.7218 10.8006 7.5988C10.9081 7.4758 11.0373 7.37755 11.1804 7.3098C11.3237 7.2421 11.478 7.2064 11.6343 7.20475H11.6455C11.8028 7.2047 11.9584 7.23915 12.1032 7.3061C12.2479 7.37305 12.3784 7.47115 12.4872 7.5944C12.596 7.71765 12.6806 7.86355 12.736 8.02325C12.7913 8.18285 12.8163 8.3531 12.8093 8.5235L12.8115 8.52005Z",
      fill: "white",
    })
  );
}
function Ce() {
  return t.createElement(
    "svg",
    { width: "123", height: "23", viewBox: "0 0 123 23", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_924)" },
      t.createElement(
        "mask",
        {
          id: "mask0_429_924",
          style: { maskType: "luminance" },
          maskUnits: "userSpaceOnUse",
          x: "0",
          y: "0",
          width: "123",
          height: "23",
        },
        t.createElement("path", { d: "M123 0.651611H0V22.7613H123V0.651611Z", fill: "white" })
      ),
      t.createElement(
        "g",
        { mask: "url(#mask0_429_924)" },
        t.createElement("path", {
          d: "M113.934 7.45996L116.558 14.3649H111.227L113.934 7.45996ZM111.126 4.77657L105.089 19.5119H109.343L110.302 16.8918H117.451L118.358 19.4953H123L116.911 4.77657H111.126ZM98.9823 19.5252H103.303V4.77657H98.9823V19.5252ZM68.9168 4.77657L65.3027 16.469L61.8375 4.77657H57.1641L62.1075 19.5252H68.3456L73.341 4.77657H68.9168ZM86.423 7.97933H88.2889C90.996 7.97933 92.7268 9.14457 92.7268 12.1675C92.7268 15.1905 90.9787 16.3724 88.2889 16.3724H86.423V7.97933ZM82.1339 4.77657V19.5252H89.1474C92.8965 19.5252 94.1081 18.926 95.4201 17.5843C96.3617 16.6454 96.9502 14.5746 96.9502 12.3107C96.9502 10.0468 96.4448 8.38217 95.5551 7.23357C93.9731 5.16277 91.6537 4.77657 88.2058 4.77657H82.1339ZM41.1015 4.74328V19.5086H45.4738V8.04258H48.8697C49.981 8.04258 50.7703 8.31891 51.3068 8.86824C51.9957 9.56406 52.2657 10.7127 52.2657 12.7668V19.5119H56.5029V11.3619C56.5029 5.53897 52.6361 4.74661 48.8697 4.74661H41.1015V4.74328ZM75.1549 4.77657V19.5252H79.4752V4.77657H75.1549Z",
          fill: "#010101",
        }),
        t.createElement("path", {
          d: "M3.61408 10.1933C3.61408 10.1933 6.79198 5.66549 13.1824 5.19606V3.54474C6.10309 4.0974 0 9.83706 0 9.83706C0 9.83706 3.46523 19.4753 13.1686 20.3509V18.603C6.03732 17.7474 3.61754 10.2099 3.61754 10.2099V10.1933H3.61408ZM13.1686 15.1273V16.7286C7.78551 15.8064 6.29003 10.4197 6.29003 10.4197C6.29003 10.4197 8.87943 7.66971 13.1686 7.21693V8.96479C10.9149 8.70511 9.14945 10.7293 9.14945 10.7293C9.14945 10.7293 10.1568 14.1418 13.1859 15.1273M13.1686 0.521767V3.54474L13.7917 3.51145C21.8126 3.25177 27.0433 9.83373 27.0433 9.83373C27.0433 9.83373 21.0406 16.8518 14.7852 16.8518C8.52979 16.8518 13.7086 16.8019 13.172 16.7053V18.5831C13.6082 18.633 14.0617 18.663 14.5186 18.663C20.3379 18.663 24.5578 15.7998 28.6288 12.4206C29.3004 12.9366 32.0767 14.2151 32.6479 14.7644C28.7811 17.8872 19.7494 20.4075 14.619 20.4075C9.4887 20.4075 13.6601 20.3742 13.1893 20.3276V22.9644H35.3031V0.521767H13.172H13.1686ZM13.1686 7.21693V5.19606C13.3693 5.19606 13.5874 5.16277 13.7917 5.16277C19.559 4.98632 23.3427 9.93361 23.3427 9.93361C23.3427 9.93361 19.2578 15.3836 14.8821 15.3836C10.5065 15.3836 13.7224 15.3037 13.1824 15.1239V8.97811C15.436 9.23779 15.8895 10.19 17.2188 12.3573L20.2306 9.93028C20.2306 9.93028 18.0289 7.16366 14.3456 7.16366C13.9578 7.16366 13.5736 7.16366 13.1686 7.2136",
          fill: "#010101",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_429_924" },
        t.createElement("rect", { width: "123", height: "22.1097", fill: "white", transform: "translate(0 0.651611)" })
      )
    )
  );
}
function Ne() {
  return t.createElement(
    "svg",
    { width: "64", height: "25", viewBox: "0 0 64 25", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_935)" },
      t.createElement("path", { d: "M5.19884 0.348602H0.636364V5.01328H5.19884V0.348602Z", fill: "black" }),
      t.createElement("path", {
        d: "M5.08518 24.6514V7.85192H0.766258V24.6514H5.08518ZM33.7914 24.8174V20.7005C33.1582 20.7005 32.6224 20.6673 32.2327 20.6009C31.7781 20.5345 31.4371 20.3685 31.2098 20.1361C30.9825 19.9037 30.8364 19.5717 30.7552 19.1401C30.6902 18.7251 30.6578 18.1773 30.6578 17.5133V11.6368H33.7914V7.85192H30.6578V1.29482H26.3226V17.5465C26.3226 18.9243 26.4363 20.0863 26.6636 21.0159C26.8909 21.9289 27.2806 22.676 27.8164 23.2404C28.3522 23.8048 29.0666 24.2032 29.9271 24.4522C30.8039 24.7012 31.908 24.8174 33.2231 24.8174H33.7914ZM58.6009 24.6514V0H54.2657V24.6514H58.6009ZM22.1498 9.49535C20.9483 8.16733 19.2597 7.50332 17.1165 7.50332C14.9732 7.50332 15.1356 7.71912 14.2751 8.15073C13.4308 8.58234 12.7001 9.17995 12.1318 9.94356L11.8883 10.259V7.85192H7.61808V24.6514H11.9208V15.7038V16.3181V16.0193C11.9695 14.4422 12.3429 13.2802 13.0573 12.5332C13.8204 11.7364 14.7459 11.338 15.8013 11.338C16.8567 11.338 18.0095 11.7364 18.6427 12.5C19.2597 13.2636 19.5844 14.3426 19.5844 15.7205V15.7537V24.6348H23.9521V15.1062C23.9521 12.7158 23.3513 10.8234 22.1498 9.49535ZM52.0251 16.2185C52.0251 15.0066 51.814 13.8778 51.4081 12.8154C50.9859 11.7696 50.4014 10.84 49.6708 10.0432C48.9239 9.24635 48.0309 8.63214 46.9917 8.18393C45.9526 7.73572 44.7998 7.51992 43.5496 7.51992C42.2994 7.51992 41.244 7.75232 40.2048 8.20053C39.1657 8.66534 38.2565 9.27955 37.4933 10.0598C36.7302 10.84 36.1132 11.7696 35.6749 12.832C35.2202 13.8944 35.0092 15.0398 35.0092 16.2517C35.0092 17.4635 35.2202 18.6089 35.6424 19.6713C36.0645 20.7337 36.6653 21.6633 37.4122 22.4436C38.159 23.2238 39.0845 23.8546 40.1561 24.3028C41.2277 24.7676 42.413 25 43.6795 25C47.3489 25 49.6221 23.2902 50.9859 21.6965L47.8685 19.2729C47.219 20.0697 45.6603 21.1487 43.7119 21.1487C41.7636 21.1487 41.4875 20.8665 40.7244 20.2855C39.9613 19.7211 39.4417 18.9243 39.1657 17.9449L39.117 17.7955H52.0251V16.2185ZM39.1495 14.6746C39.1495 13.4462 40.5296 11.3048 43.5009 11.2882C46.4722 11.2882 47.8685 13.4296 47.8685 14.658H39.1495V14.6746Z",
        fill: "black",
      }),
      t.createElement("path", {
        d: "M63.5368 22.4602C63.4556 22.261 63.3419 22.095 63.1958 21.9455C63.0497 21.7961 62.8873 21.6799 62.6925 21.5969C62.4976 21.5139 62.2866 21.4641 62.0755 21.4641C61.8644 21.4641 61.6533 21.5139 61.4585 21.5969C61.2637 21.6799 61.1013 21.7961 60.9552 21.9455C60.809 22.095 60.6954 22.261 60.6142 22.4602C60.533 22.6594 60.4843 22.8752 60.4843 23.091C60.4843 23.3068 60.533 23.5226 60.6142 23.7218C60.6954 23.921 60.809 24.087 60.9552 24.2364C61.1013 24.3858 61.2637 24.502 61.4585 24.585C61.6533 24.668 61.8644 24.7178 62.0755 24.7178C62.2866 24.7178 62.4976 24.668 62.6925 24.585C62.8873 24.502 63.0497 24.3858 63.1958 24.2364C63.3419 24.087 63.4556 23.921 63.5368 23.7218C63.618 23.5226 63.6667 23.3068 63.6667 23.091C63.6667 22.8752 63.618 22.6594 63.5368 22.4602ZM63.277 23.6222C63.212 23.7882 63.1146 23.9376 63.001 24.0538C62.8873 24.17 62.7412 24.2696 62.5788 24.336C62.4164 24.4024 62.2541 24.4356 62.0592 24.4356C61.8644 24.4356 61.702 24.4024 61.5397 24.336C61.3773 24.2696 61.2312 24.17 61.1175 24.0538C61.0039 23.9376 60.9064 23.7882 60.8415 23.6222C60.7766 23.4562 60.7441 23.2902 60.7441 23.091C60.7441 22.8918 60.7766 22.7258 60.8415 22.5598C60.9064 22.3938 61.0039 22.2444 61.1175 22.1282C61.2312 22.012 61.3773 21.9123 61.5397 21.8459C61.702 21.7795 61.8644 21.7463 62.0592 21.7463C62.2541 21.7463 62.4164 21.7795 62.5788 21.8459C62.7412 21.9123 62.8873 22.012 63.001 22.1282C63.1146 22.2444 63.212 22.3938 63.277 22.5598C63.3419 22.7258 63.3744 22.8918 63.3744 23.091C63.3906 23.2902 63.3419 23.4562 63.277 23.6222ZM62.3677 23.2238C62.4976 23.2072 62.5951 23.1574 62.6762 23.0744C62.7574 22.9914 62.8061 22.8752 62.8061 22.7092C62.8061 22.5432 62.7574 22.3938 62.6438 22.2942C62.5463 22.1946 62.3677 22.1448 62.1567 22.1448H61.4423V24.0206H61.7832V23.257H62.0268L62.4814 24.0206H62.8386L62.3677 23.2238ZM62.1891 22.9582H61.7832V22.427H62.1891C62.2378 22.427 62.2866 22.4436 62.3353 22.4602C62.384 22.4768 62.4164 22.51 62.4327 22.5432C62.4489 22.5764 62.4652 22.6262 62.4652 22.6926C62.4652 22.759 62.4489 22.8088 62.4327 22.842C62.4002 22.8752 62.3677 22.9084 62.3353 22.925C62.2866 22.9416 62.2378 22.9582 62.1891 22.9582Z",
        fill: "black",
      })
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_429_935" },
        t.createElement("rect", { width: "63.0303", height: "25", fill: "white", transform: "translate(0.636364)" })
      )
    )
  );
}
const Ie = () =>
    t.createElement(
      "div",
      null,
      t.createElement(
        "div",
        {
          className:
            "tw-py-4 tw-mr-16 tw-rounded-lg tw-pl-7 tw-pr-4 tw-bg-gradient-to-r tw-from-card-1 tw-from-[-30%] tw-to-card-2 tw-backdrop-blur-sm",
        },
        t.createElement(
          "div",
          { className: "tw-pb-4 tw-border-b tw-border-black" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw--translate-x-4 tw-gap-x-2" },
            t.createElement("div", {
              className: "tw-w-[8px] tw-h-[7px] tw-bg-[#00F996] tw-rounded-full tw-translate-y-1",
            }),
            t.createElement("h1", { className: "tw-text-xl" }, "Server Cluster 2")
          ),
          t.createElement("h2", { className: "tw-text-base" }, "US East - N. Carolina")
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-py-4 tw-place-content-center" },
          t.createElement(
            "div",
            null,
            t.createElement(
              "p",
              { className: "tw-text-gray-400 tw-text-xs" },
              "Dell R760 ",
              t.createElement("br", null),
              "GPU: NVIDIA H100 ",
              t.createElement("br", null),
              "AVG GPU: 83.8% ",
              t.createElement("br", null),
              "AVG GPU Usage: 78.1% ",
              t.createElement("br", null),
              "CPU Cores: 48 ",
              t.createElement("br", null),
              "AVG CPU: 2.5% ",
              t.createElement("br", null),
              "AVG CPU Memory: 10.2%"
            )
          ),
          t.createElement(
            "div",
            null,
            t.createElement(
              "div",
              { className: "tw-flex tw-mb-3 tw-gap-x-2 tw-align-center" },
              t.createElement("div", { className: "tw-w-[20px]" }, t.createElement(ve, null)),
              t.createElement("h2", { className: "tw-text-base tw-font-semibold" }, "Joint Intelligence Briefing")
            ),
            t.createElement(
              "div",
              { className: "tw-flex tw-items-start tw-p-1 tw-bg-[#A35456] tw-rounded-lg  " },
              t.createElement("div", { className: "" }, t.createElement(xe, null)),
              t.createElement(
                "p",
                { className: "tw-text-xs" },
                "Your action was halted because it flagged the sourcing protocol mandatory control #234"
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-[#D3E660] tw-p-2 " },
          t.createElement(Ce, null),
          t.createElement(
            "h2",
            { className: "tw-pt-6 tw-pb-12 tw-text-base tw-font-semibold tw-text-center tw-text-black" },
            "H100"
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-[#4F99E9] tw-px-3 tw-py-6 tw-grid tw-grid-cols-3 tw-gap-2 " },
          t.createElement(Ne, null),
          t.createElement("h2", { className: "tw-text-base tw-font-semibold tw-text-center tw-text-black " }, "XEON 5")
        )
      ),
      t.createElement(
        "button",
        { className: "tw-px-5 tw-py-2 tw-mt-2 tw-border tw-rounded-full tw-border-grey-500" },
        "00000006-0454-005"
      )
    ),
  ke = ({ title: e, content: n, IconRR: a }) =>
    t.createElement(
      "article",
      {
        className:
          "tw-flex tw-flex-col tw-p-2 tw-text-white tw-divide-y tw-rounded-lg tw-gap-y-1 tw-divide-sidebar/100 tw-bg-sidebar tw-backdrop-blur-sm",
      },
      t.createElement(
        "div",
        { className: "tw-flex tw-align-center tw-gap-x-1" },
        a,
        t.createElement("h2", { className: "tw-text-base" }, e)
      ),
      t.createElement("div", { className: "tw-pt-2" }, n)
    );
function Ae() {
  return t.createElement(
    "svg",
    { width: "38", height: "38", viewBox: "0 0 38 38", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_959)" },
      t.createElement("path", {
        d: "M31.6166 2.43192H13.6714C12.7032 2.43192 11.776 2.81648 11.092 3.50048L3.50112 11.0914C2.81712 11.7754 2.43256 12.7041 2.43256 13.6708V27.9679C2.43256 29.9834 4.06656 31.6159 6.08056 31.6159H22.5969C20.8519 29.9789 19.7606 27.6548 19.7606 25.0799C19.7606 20.1354 23.784 16.1119 28.7286 16.1119C31.3034 16.1119 33.6275 17.2048 35.2646 18.9482V6.07992C35.2646 4.06592 33.6321 2.43192 31.6166 2.43192ZM13.0726 20.0138H6.4864C5.92704 20.0138 5.47256 19.5608 5.47256 18.9999C5.47256 18.439 5.92552 17.9861 6.4864 17.9861H13.0726C13.6319 17.9861 14.0864 18.439 14.0864 18.9999C14.0864 19.5608 13.6334 20.0138 13.0726 20.0138ZM20.1664 15.4538H6.4864C5.92704 15.4538 5.47256 14.9993 5.47256 14.4399C5.47256 13.8806 5.92552 13.4261 6.4864 13.4261H20.1664C20.7258 13.4261 21.1802 13.879 21.1802 14.4399C21.1802 15.0008 20.7273 15.4538 20.1664 15.4538Z",
        fill: "url(#paint0_linear_429_959)",
      }),
      t.createElement("path", {
        d: "M28.728 18.544C25.1241 18.544 22.192 21.4761 22.192 25.08C22.192 28.6839 25.1241 31.616 28.728 31.616C32.3319 31.616 35.264 28.6839 35.264 25.08C35.264 21.4761 32.3319 18.544 28.728 18.544Z",
        fill: "url(#paint1_linear_429_959)",
      }),
      t.createElement("path", {
        d: "M32.7004 23.2836L32.9237 23.0361L32.6762 22.8128L32.2767 22.4523L32.0292 22.229L31.8059 22.4765L27.4396 27.3159L25.8534 25.7178L25.6186 25.4812L25.382 25.716L25.0001 26.095L24.7635 26.3299L24.9983 26.5664L27.2331 28.8182L27.4812 29.0682L27.7172 28.8067L32.7004 23.2836Z",
        fill: "black",
        stroke: "black",
        strokeWidth: "0.666667",
      })
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "linearGradient",
        {
          id: "paint0_linear_429_959",
          x1: "7.38694",
          y1: "3.68266",
          x2: "21.0331",
          y2: "36.3312",
          gradientUnits: "userSpaceOnUse",
        },
        t.createElement("stop", { stopColor: "#E2CCFF" }),
        t.createElement("stop", { offset: "1", stopColor: "#0D0D0D" })
      ),
      t.createElement(
        "linearGradient",
        {
          id: "paint1_linear_429_959",
          x1: "25.4016",
          y1: "20.8783",
          x2: "38.8821",
          y2: "42.1786",
          gradientUnits: "userSpaceOnUse",
        },
        t.createElement("stop", { stopColor: "white" }),
        t.createElement("stop", { offset: "0.459251" }),
        t.createElement("stop", { offset: "0.643137" })
      ),
      t.createElement(
        "clipPath",
        { id: "clip0_429_959" },
        t.createElement("rect", { width: "38", height: "38", fill: "white" })
      )
    )
  );
}
function Te() {
  return t.createElement(
    "svg",
    { width: "16", height: "17", viewBox: "0 0 16 17", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_511_140)" },
      t.createElement(
        "mask",
        {
          id: "mask0_511_140",
          style: { maskType: "alpha" },
          maskUnits: "userSpaceOnUse",
          x: "0",
          y: "0",
          width: "16",
          height: "17",
        },
        t.createElement("rect", { y: "0.5", width: "16", height: "16", fill: "#D9D9D9" })
      ),
      t.createElement(
        "g",
        { mask: "url(#mask0_511_140)" },
        t.createElement("path", {
          d: "M2.66665 13.8333C2.29998 13.8333 1.98609 13.7028 1.72498 13.4417C1.46387 13.1806 1.33331 12.8667 1.33331 12.5V4.50001C1.33331 4.13334 1.46387 3.81945 1.72498 3.55834C1.98609 3.29723 2.29998 3.16667 2.66665 3.16667H5.33331C5.5222 3.16667 5.68054 3.23056 5.80831 3.35834C5.93609 3.48612 5.99998 3.64445 5.99998 3.83334C5.99998 4.02223 5.93609 4.18056 5.80831 4.30834C5.68054 4.43612 5.5222 4.50001 5.33331 4.50001H2.66665V12.5H13.3333V4.50001H10.6666C10.4778 4.50001 10.3194 4.43612 10.1916 4.30834C10.0639 4.18056 9.99998 4.02223 9.99998 3.83334C9.99998 3.64445 10.0639 3.48612 10.1916 3.35834C10.3194 3.23056 10.4778 3.16667 10.6666 3.16667H13.3333C13.7 3.16667 14.0139 3.29723 14.275 3.55834C14.5361 3.81945 14.6666 4.13334 14.6666 4.50001V12.5C14.6666 12.8667 14.5361 13.1806 14.275 13.4417C14.0139 13.7028 13.7 13.8333 13.3333 13.8333H2.66665ZM7.33331 8.23334V3.83334C7.33331 3.64445 7.3972 3.48612 7.52498 3.35834C7.65276 3.23056 7.81109 3.16667 7.99998 3.16667C8.18887 3.16667 8.3472 3.23056 8.47498 3.35834C8.60276 3.48612 8.66665 3.64445 8.66665 3.83334V8.23334L9.93331 6.96667C10.0555 6.84445 10.2111 6.78334 10.4 6.78334C10.5889 6.78334 10.7444 6.84445 10.8666 6.96667C10.9889 7.08889 11.05 7.24445 11.05 7.43334C11.05 7.62223 10.9889 7.77778 10.8666 7.90001L8.46665 10.3C8.33331 10.4333 8.17776 10.5 7.99998 10.5C7.8222 10.5 7.66665 10.4333 7.53331 10.3L5.13331 7.90001C5.01109 7.77778 4.94998 7.62223 4.94998 7.43334C4.94998 7.24445 5.01109 7.08889 5.13331 6.96667C5.25554 6.84445 5.41109 6.78334 5.59998 6.78334C5.78887 6.78334 5.94442 6.84445 6.06665 6.96667L7.33331 8.23334Z",
          fill: "white",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_511_140" },
        t.createElement("rect", { width: "16", height: "16", fill: "white", transform: "translate(0 0.5)" })
      )
    )
  );
}
function Se() {
  return t.createElement(
    "svg",
    { width: "80", height: "16", viewBox: "0 0 80 16", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement("path", {
      d: "M3.6119 9.27006H10.223V6.14882H3.6119V3.44895H10.6828V0.327713H0.31427V15.6374H10.9206V12.5005H3.6119V9.27006Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M47.0677 0.32773L43.5323 5.85232L39.9968 0.32773H39.759H30.5796H25.2843V3.44897H29.8503V12.4849H24.999C25.2526 12.1728 25.4587 11.8451 25.649 11.5018C26.2197 10.4093 26.5209 9.16083 26.5209 7.80309C26.5209 6.69505 26.3148 5.63383 25.9343 4.69746C25.538 3.74548 24.9831 2.90275 24.2855 2.21608C23.588 1.5138 22.7477 0.967583 21.7806 0.577429C20.8294 0.187274 19.783 0 18.6891 0C17.5793 0 16.5329 0.20288 15.5817 0.577429C14.6304 0.967583 13.7902 1.5138 13.0768 2.21608C12.3792 2.91836 11.8243 3.74548 11.4279 4.69746C11.0316 5.64944 10.8413 6.69505 10.8413 7.80309C10.8413 8.92674 11.0474 9.97235 11.4279 10.9087C11.8243 11.8607 12.3792 12.7034 13.0768 13.3901C13.7743 14.0924 14.6146 14.6386 15.5817 15.0288C16.5329 15.4189 17.5793 15.6062 18.6891 15.6062H27.4405H29.8503H33.1479V3.43336H38.0468L41.8835 9.16083V15.6062H45.1811V9.19204L51.0946 0.32773H47.0677ZM22.7794 9.62901C22.5733 10.1908 22.2879 10.6902 21.9074 11.1116C21.5269 11.533 21.0672 11.8763 20.5281 12.126C19.9891 12.3757 19.3708 12.5006 18.6732 12.5006C17.9756 12.5006 17.3415 12.3757 16.8024 12.126C16.2634 11.8763 15.7878 11.533 15.4231 11.1116C15.0426 10.6902 14.7414 10.1908 14.5512 9.62901C14.3451 9.05159 14.2341 8.44294 14.2341 7.80309C14.2341 7.16324 14.3451 6.5546 14.5512 5.97717C14.7573 5.41534 15.0426 4.91595 15.4231 4.49458C15.8036 4.07321 16.2634 3.72988 16.8024 3.48018C17.3415 3.23048 17.9756 3.10563 18.6732 3.10563C19.3708 3.10563 19.9891 3.23048 20.5281 3.48018C21.0672 3.72988 21.5428 4.07321 21.9074 4.49458C22.2879 4.91595 22.5892 5.41534 22.7794 5.97717C22.9855 6.5546 23.0965 7.16324 23.0965 7.80309C23.0965 8.44294 22.9855 9.05159 22.7794 9.62901Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M62.8107 1.26408L57.3728 13.5618H51.8239V1.26408H50.5556V14.701H56.8813H58.1972H58.2131L59.7509 11.1272H66.9803L68.4706 14.701H69.8975L64.1583 1.26408H62.8107ZM60.2424 9.98794L63.4291 2.62182L66.5206 9.98794H60.2424Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M79.0928 9.64461C78.9501 9.25445 78.744 8.91112 78.4586 8.63021C78.1891 8.34929 77.872 8.1152 77.4915 7.94353C77.111 7.77187 76.7147 7.66262 76.2549 7.63141V7.6002C77.0635 7.42853 77.6818 7.1008 78.0781 6.6014C78.4903 6.102 78.6964 5.49336 78.6964 4.8223C78.6964 4.05759 78.5696 3.44895 78.3001 2.99637C78.0306 2.52819 77.6976 2.16925 77.2854 1.91955C76.8732 1.65424 76.3976 1.48257 75.8744 1.40454C75.3512 1.32651 74.8281 1.27969 74.3207 1.27969H70.3889V14.7166H74.7488C75.2086 14.7166 75.7159 14.6698 76.2391 14.5606C76.7781 14.4669 77.2696 14.264 77.7293 13.9987C78.1891 13.7178 78.5696 13.3433 78.8708 12.8439C79.1721 12.3601 79.3306 11.7202 79.3306 10.9555C79.3147 10.4717 79.2355 10.0348 79.0928 9.64461ZM74.4793 2.40334C74.8756 2.40334 75.2561 2.43455 75.6208 2.51258C75.9854 2.59061 76.3025 2.71546 76.572 2.90274C76.8415 3.09001 77.0635 3.33971 77.222 3.63623C77.3806 3.94835 77.4598 4.33851 77.4598 4.80669C77.4598 5.02518 77.4281 5.25927 77.3489 5.52458C77.2696 5.78988 77.111 6.02397 76.8891 6.25807C76.6513 6.49216 76.3342 6.67943 75.922 6.83549C75.5098 6.99156 74.9707 7.06959 74.3207 7.06959H71.6731L71.6573 2.40334H74.4793ZM77.9196 11.7827C77.8403 12.0792 77.6659 12.3601 77.4281 12.6254C77.1903 12.8907 76.8257 13.1092 76.3818 13.2965C75.922 13.4681 75.3195 13.5618 74.5744 13.5618H71.6573V8.20884H74.7647C75.161 8.20884 75.5574 8.25566 75.9537 8.3649C76.3501 8.45854 76.6988 8.63021 77.0001 8.84869C77.3013 9.06718 77.555 9.3637 77.7452 9.70703C77.9354 10.066 78.0306 10.4873 78.0306 10.9711C78.0464 11.2208 77.9989 11.4861 77.9196 11.7827Z",
      fill: "white",
    })
  );
}
const Me = [
    {
      title: "Controls Failed",
      content: t.createElement("p", { className: "text-red-400" }, "1 Controls"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement(
            "g",
            { clipPath: "url(#clip0_429_973)" },
            t.createElement("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M11.4448 3.75168C11.6929 3.32644 12.3073 3.32642 12.5554 3.75168L21.7685 19.5458C22.0186 19.9743 21.7094 20.5124 21.2133 20.5124H2.78689C2.29074 20.5124 1.98161 19.9743 2.2316 19.5458L11.4448 3.75168ZM14.4063 2.67196C13.3314 0.829199 10.6688 0.829192 9.59384 2.67196L0.380648 18.4661C-0.702671 20.3232 0.636904 22.6553 2.78689 22.6553H21.2133C23.3633 22.6553 24.7029 20.3232 23.6196 18.4661L14.4063 2.67196ZM13.2857 7.49995C13.2857 6.78988 12.7101 6.21424 12 6.21424C11.2899 6.21424 10.7143 6.78988 10.7143 7.49995V13.0714C10.7143 13.7815 11.2899 14.3571 12 14.3571C12.7101 14.3571 13.2857 13.7815 13.2857 13.0714V7.49995ZM10.2857 17.7857C10.2857 18.7325 11.0532 19.5 12 19.5C12.9468 19.5 13.7143 18.7325 13.7143 17.7857C13.7143 16.8389 12.9468 16.0714 12 16.0714C11.0532 16.0714 10.2857 16.8389 10.2857 17.7857Z",
              fill: "white",
            })
          ),
          t.createElement(
            "defs",
            null,
            t.createElement(
              "clipPath",
              { id: "clip0_429_973" },
              t.createElement("rect", { width: "24", height: "24", fill: "white" })
            )
          )
        );
      }, null),
    },
    {
      title: "Controls Passed",
      content: t.createElement(
        "p",
        {
          className: "tw-cursor-pointer",
          onClick: () => {
            window.open(
              "https://governance-studio.eqtylab.io/EU%20AI%20Act%20-%20Energy%20Provider/gov-studio/workspaces/27/dashboard",
              "_blank"
            );
          },
        },
        "45 Controls"
      ),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M12 1.92188C6.43401 1.92188 1.92188 6.43401 1.92188 12C1.92188 17.566 6.43401 22.0781 12 22.0781C17.566 22.0781 22.0781 17.566 22.0781 12C22.0781 6.43401 17.566 1.92188 12 1.92188ZM7.80979 11.9716C7.5352 11.697 7.09001 11.697 6.81542 11.9716C6.54083 12.2462 6.54083 12.6913 6.81542 12.9659L9.62792 15.7784C9.90251 16.053 10.3477 16.053 10.6222 15.7784L17.1847 9.21593C17.4593 8.94135 17.4593 8.49615 17.1847 8.22157C16.9102 7.94698 16.465 7.94698 16.1904 8.22157L10.1251 14.2868L7.80979 11.9716Z",
            fill: "white",
          })
        );
      }, null),
    },
    {
      title: "Agent Authority",
      content: t.createElement("p", null, "Provisioned by NAVAI"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement(
            "g",
            { clipPath: "url(#clip0_429_998)" },
            t.createElement(
              "g",
              { clipPath: "url(#clip1_429_998)" },
              t.createElement("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M3.14287 0.64286C1.73257 0.64286 0.589294 1.89007 0.589294 3.42857V8.01504C0.589294 14.951 4.65772 21.1089 10.6894 23.3021C10.891 23.3755 11.109 23.3755 11.3106 23.3021C17.3423 21.1089 21.4107 14.951 21.4107 8.01504V3.42857C21.4107 1.89007 20.2675 0.64286 18.8572 0.64286H3.14287ZM2.55358 3.42857C2.55358 3.07353 2.81741 2.78572 3.14287 2.78572H18.8572C19.1826 2.78572 19.4464 3.07353 19.4464 3.42857V8.01504C19.4464 13.9088 16.0581 19.1546 11 21.1515C5.94182 19.1546 2.55358 13.9088 2.55358 8.01504V3.42857ZM16.5952 7.71132C17.0275 7.18061 16.9839 6.36794 16.4973 5.89619C16.0108 5.42443 15.2659 5.47224 14.8334 6.00297L9.26817 12.833L6.99287 10.9714C6.47214 10.5454 5.73341 10.6605 5.34287 11.2286C4.95232 11.7966 5.05786 12.6025 5.57858 13.0286L8.72144 15.6C9.2118 16.0012 9.90222 15.9254 10.3095 15.4256L16.5952 7.71132Z",
                fill: "white",
              })
            )
          ),
          t.createElement(
            "defs",
            null,
            t.createElement(
              "clipPath",
              { id: "clip0_429_998" },
              t.createElement("rect", { width: "24", height: "24", fill: "white" })
            ),
            t.createElement(
              "clipPath",
              { id: "clip1_429_998" },
              t.createElement("rect", { width: "22", height: "24", fill: "white" })
            )
          )
        );
      }, null),
    },
    {
      title: "Developed by",
      content: t.createElement("p", null, "Supervisor #836"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M5.56473 5.14711C5.56473 3.48766 6.90959 2.14286 8.568 2.14286C10.2264 2.14286 11.5713 3.48766 11.5713 5.14711C11.5713 6.80655 10.2264 8.15136 8.568 8.15136C6.90959 8.15136 5.56473 6.80655 5.56473 5.14711ZM8.568 0C5.72563 0 3.42187 2.30468 3.42187 5.14711C3.42187 7.98953 5.72563 10.2942 8.568 10.2942C11.4104 10.2942 13.7141 7.98953 13.7141 5.14711C13.7141 2.30468 11.4104 0 8.568 0ZM9.64202 13.5029C9.64202 13.0138 9.73308 12.5459 9.89916 12.1153C9.46631 12.0433 9.02179 12.0059 8.56785 12.0059C3.75499 12.0059 0 16.2128 0 21.214C0 21.8056 0.479694 22.2854 1.07143 22.2854H11.8815C10.464 20.476 9.64202 18.2081 9.64202 15.7962V13.5029ZM11.5706 13.5029C11.5706 12.4378 12.434 11.5744 13.4992 11.5744H22.0706C23.1357 11.5744 23.9992 12.4378 23.9992 13.5029V15.7962C23.9992 19.4947 21.6324 22.7784 18.1236 23.9479C17.9039 24.0213 17.6659 24.0213 17.4461 23.9479C13.9373 22.7784 11.5706 19.4947 11.5706 15.7962V13.5029ZM13.7134 13.7172V15.7962C13.7134 18.4516 15.3387 20.8221 17.7849 21.7915C20.231 20.8221 21.8563 18.4516 21.8563 15.7962V13.7172H13.7134ZM20.471 16.832C20.8895 16.4135 20.8895 15.7352 20.471 15.3167C20.0527 14.8983 19.3742 14.8983 18.9559 15.3167L17.3563 16.9163L17.0425 16.6025C16.6241 16.184 15.9457 16.184 15.5273 16.6025C15.1088 17.0209 15.1088 17.6993 15.5273 18.1176L16.5987 19.189C17.0171 19.6075 17.6956 19.6075 18.1138 19.189L20.471 16.832Z",
            fill: "white",
          })
        );
      }, null),
    },
    {
      title: "Registration",
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "22", height: "22", viewBox: "0 0 22 22", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            d: "M5 5.00293H5.01M5 17.0029H5.01M3 1.00293H19C20.1046 1.00293 21 1.89836 21 3.00293V7.00293C21 8.1075 20.1046 9.00293 19 9.00293H3C1.89543 9.00293 1 8.1075 1 7.00293V3.00293C1 1.89836 1.89543 1.00293 3 1.00293ZM3 13.0029H19C20.1046 13.0029 21 13.8984 21 15.0029V19.0029C21 20.1075 20.1046 21.0029 19 21.0029H3C1.89543 21.0029 1 20.1075 1 19.0029V15.0029C1 13.8984 1.89543 13.0029 3 13.0029Z",
            stroke: "white",
            strokeLinecap: "round",
            "stroke-linejoin": "round",
          })
        );
      }, null),
      content: t.createElement(
        "div",
        null,
        t.createElement("p", null, "CID bafkr...aueq"),
        t.createElement("p", null, "HCS Oxe34...eb5e")
      ),
    },
  ],
  Le = () =>
    t.createElement(
      "div",
      { className: "tw-flex tw-flex-col tw-p-3 tw-rounded-lg tw-bg-sidebar tw-gap-y-2 tw-backdrop-blur-[14px]" },
      t.createElement(
        "div",
        { className: "tw-flex tw-align-center tw-gap-x-2" },
        t.createElement(Ae, null),
        t.createElement("h1", { className: "tw-text-xl" }, "Audit Certificate")
      ),
      Me.map((e, n) => t.createElement(ke, { key: n, IconRR: e.icon, title: e.title, content: e.content })),
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-m-2 tw-gap-y-2" },
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-end tw-align-center tw-gap-x-2" },
          t.createElement(Te, null),
          t.createElement("p", { className: "tw-text-sm" }, "Export")
        ),
        t.createElement("div", null, t.createElement(Se, null))
      )
    ),
  Pe = () => (
    y(() => {
      const e = v.timeline();
      (e.from(".policies", { x: -100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from(".server-card", { y: 100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from(".sidebar", { y: -100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from("#lines-bg", { opacity: 0, duration: 1 }, "-=1"));
    }, []),
    t.createElement(
      "div",
      {
        className:
          "tw-h-full tw-bg-transparent tw-flex tw-justify-center tw-items-center tw-text-white tw-overflow-hidden\n    ",
      },
      t.createElement(
        "div",
        { className: "tw-grid tw-items-center tw-grid-cols-12 tw-px-24" },
        t.createElement("div", { className: "tw-col-span-2 tw-policies" }, t.createElement(ye, null)),
        t.createElement("div", { className: "tw-col-span-4 tw-h-full" }, t.createElement(Ee, null)),
        t.createElement("div", { className: "tw-col-span-4 tw-server-card" }, t.createElement(Ie, null)),
        t.createElement("div", { className: "tw-col-span-2 tw-sidebar" }, t.createElement(Le, null))
      )
    )
  ),
  Oe = ({ isBlocked: e = !1, isPlaying: n = !1, onPlay: a, onPause: i, onCancel: r, onFinal: l }) => {
    const { state: o } = q(),
      s = o.userOverrides.length > 0 && o.userRemediations.length > 0,
      c = Object.values(o.nodes).filter((e) => "completed" === e.status).length;
    return t.createElement(
      "div",
      { className: "tw-w-[264px] tw-min-w-[264px] tw-rounded-xl tw-bg-branddialogbg tw-p-4" },
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-gap-3" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-gap-2 tw-w-full" },
          t.createElement("div", {
            className:
              "tw-min-w-[8px] tw-min-h-[8px] tw-rounded-full " +
              (e || !s
                ? "tw-bg-brandalert tw-animate-pulse-glow-alert"
                : "running" === o.status
                  ? "tw-bg-brandblue tw-animate-pulse-glow-blue"
                  : "completed" === o.status
                    ? "tw-bg-brandgreen tw-animate-pulse-glow-green"
                    : "tw-bg-gray-400 tw-animate-none"),
          }),
          t.createElement(
            "span",
            { className: "tw-text-white tw-text-xs tw-truncate" },
            e || !s
              ? "Workflow is not compliant"
              : "running" === o.status
                ? `Running: (${Math.min(Math.max(c - 1, 0), 15)}/15 Agents Complete)`
                : "completed" === o.status
                  ? "Completed"
                  : "Ready to Run"
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-gap-2" },
          n
            ? t.createElement(
                "button",
                {
                  onClick: i,
                  className:
                    "tw-flex tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-yellow-600/2 tw-text-white tw-text-sm hover:tw-bg-opacity-90",
                },
                t.createElement(
                  "svg",
                  {
                    className: "tw-animate-spin tw--ml-1 tw-mr-3 tw-h-5 tw-w-5 tw-text-white",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                  },
                  t.createElement("circle", {
                    className: "tw-opacity-25",
                    cx: "12",
                    cy: "12",
                    r: "10",
                    stroke: "currentColor",
                    "stroke-width": "4",
                  }),
                  t.createElement("path", {
                    className: "tw-opacity-75",
                    fill: "currentColor",
                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
                  })
                ),
                " ",
                "Pause"
              )
            : "completed" !== o.status
              ? t.createElement(
                  "button",
                  {
                    onClick: a,
                    disabled: e || !s,
                    className:
                      "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-text-white tw-text-sm\n                " +
                      (e || !s ? "tw-bg-gray-600 tw-cursor-not-allowed" : "tw-bg-brandblue hover:tw-bg-opacity-90"),
                  },
                  "Start"
                )
              : "completed" == o.status &&
                t.createElement(
                  "button",
                  {
                    onClick: l,
                    className:
                      "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-brandgreen tw-text-branddialogbg tw-text-sm hover:tw-bg-opacity-90",
                  },
                  "View Final Report"
                ),
          n &&
            t.createElement(
              "button",
              {
                onClick: r,
                className:
                  "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-brandred tw-text-white tw-text-sm hover:tw-bg-opacity-90",
              },
              "Cancel"
            )
        )
      )
    );
  };
function Re({ entry: e }) {
  switch (e.type) {
    case "human-override":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Override Details"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Approved By"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          ),
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Justification"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          )
        )
      );
    case "agent-output":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Output Details"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-3 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Type"),
            t.createElement("div", { className: "tw-text-white" }, e.output?.type)
          ),
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "ID"),
            t.createElement("div", { className: "tw-text-white" }, e.output?.id)
          ),
          t.createElement(
            "div",
            null,
            t.createElement(
              "button",
              {
                className:
                  "tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1 \n                             tw-rounded tw-bg-cyan-500/20 tw-text-cyan-400",
                onClick: () => {
                  console.log("Navigate to:", e.output?.location);
                },
              },
              t.createElement(N, { className: "tw-w-4 tw-h-4" }),
              "View Output"
            )
          )
        )
      );
    case "guardrail-pass":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Guardrail Evaluation"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Checks Passed"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          ),
          e.metrics &&
            t.createElement(
              "div",
              null,
              t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Evaluation Time"),
              t.createElement("div", { className: "tw-text-white" }, e.metrics.executionTime, "ms")
            )
        )
      );
    default:
      return e.metrics?.apiCalls?.length
        ? t.createElement(
            "div",
            { className: "tw-space-y-2" },
            t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "API Calls"),
            t.createElement(
              "div",
              { className: "tw-space-y-1" },
              e.metrics.apiCalls.map((e, n) =>
                t.createElement(
                  "div",
                  { key: n, className: "tw-flex tw-items-center tw-gap-4 tw-text-xs" },
                  t.createElement("span", { className: "tw-text-white/60" }, e.service),
                  t.createElement("span", { className: "tw-text-white" }, e.duration, "ms"),
                  t.createElement(
                    "span",
                    {
                      className:
                        "tw-px-1.5 tw-rounded " +
                        (e.status < 400 ? "tw-bg-green-500/20 tw-text-green-400" : "tw-bg-red-500/20 tw-text-red-400"),
                    },
                    e.status
                  )
                )
              )
            )
          )
        : null;
  }
}
const He = {
    info: { color: "tw-text-brandblue", background: "tw-bg-brandblue/5" },
    success: { color: "tw-text-green-400", background: "tw-bg-green-400/5" },
    error: { color: "tw-text-brandred", background: "tw-bg-brandred/5" },
    warning: { color: "tw-text-yellow-400", background: "tw-bg-yellow-400/5" },
    "agent-complete": { color: "tw-text-purple-400", background: "tw-bg-purple-400/5" },
    "agent-output": { color: "tw-text-cyan-400", background: "tw-bg-cyan-400/5" },
    "guardrail-pass": { color: "tw-text-emerald-400", background: "tw-bg-emerald-400/5" },
    "human-override": { color: "tw-text-amber-400", background: "tw-bg-amber-400/5" },
    critical: { color: "tw-text-red-500", background: "tw-bg-red-500/5" },
  },
  De = {
    "video-collector": "tw-text-blue-400",
    "video-analyzer": "tw-text-purple-400",
    "partner-analyzer": "tw-text-green-400",
    "service-call-analyzer": "tw-text-yellow-400",
    "social-monitor": "tw-text-orange-400",
    summarizer: "tw-text-cyan-400",
    "nemo-guardrail": "tw-text-red-400",
    "event-prioritizer": "tw-text-indigo-400",
    "policy-validator": "tw-text-pink-400",
    "plan-creator": "tw-text-emerald-400",
    "responder-notifier": "tw-text-amber-400",
  },
  Ve = {
    info: () => t.createElement(L, { className: "tw-h-3 tw-w-3" }),
    success: () => t.createElement(M, { className: "tw-h-3 tw-w-3" }),
    error: () => t.createElement(k, { className: "tw-h-3 tw-w-3" }),
    warning: () => t.createElement(k, { className: "tw-h-3 tw-w-3" }),
    "agent-complete": () => t.createElement(S, { className: "tw-h-3 tw-w-3" }),
    "agent-output": () => t.createElement(N, { className: "tw-h-3 tw-w-3" }),
    "guardrail-pass": () => t.createElement(T, { className: "tw-h-3 tw-w-3" }),
    "human-override": () => t.createElement(A, { className: "tw-h-3 tw-w-3" }),
    critical: () => t.createElement(k, { className: "tw-h-3 tw-w-3" }),
  };
function _e({ entry: e, onClick: n, isAutoScrollPaused: a }) {
  const i = Ve[e.type],
    r = He[e.type];
  return t.createElement(
    "tr",
    {
      onClick: n,
      className: `\n          tw-border-b \n          !tw-border-white/5\n          \n          ${r.background}\n          tw-text-xs // Consistent text size\n        `,
    },
    t.createElement("td", { className: "tw-p-2 tw-text-white/80" }, e.timestamp),
    e.agent
      ? t.createElement(
          "td",
          { className: "tw-p-2 tw-whitespace-nowrap tw-max-w-[196px]" },
          t.createElement(
            "div",
            { className: `tw-flex tw-items-center tw-gap-1.5 ${De[e.agent.type]}` },
            t.createElement("span", { className: "tw-text-xs" }, e.agent.name)
          )
        )
      : t.createElement("td", { className: "tw-p-2 tw-whitespace-nowrap" }),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-whitespace-nowrap tw-max-w-[136px]" },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-1.5" },
        t.createElement("div", { className: ` ${r.color}` }, t.createElement(i, null)),
        t.createElement("span", { className: `tw-text-xs tw-font-medium ${r.color}` }, e.type.toUpperCase())
      )
    ),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-min-w-0" },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("span", { className: "tw-truncate" }, e.content),
        e.output &&
          t.createElement(
            "button",
            {
              className: "tw-flex-shrink-0 tw-ml-2 tw-p-1 tw-rounded hover:tw-bg-white/10",
              onClick: (t) => {
                (t.stopPropagation(), console.log("Navigate to:", e.output?.location));
              },
            },
            t.createElement(N, { className: "tw-w-4 tw-h-4 tw-text-cyan-400" })
          )
      )
    ),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-min-w-0" },
      t.createElement("div", { className: "tw-truncate tw-text-white/60" }, e.details)
    ),
    e.metrics
      ? t.createElement(
          "td",
          { className: "tw-p-2 tw-text-xs tw-text-white/40 " },
          e.metrics.executionTime &&
            t.createElement(
              "div",
              { className: "tw-flex tw-items-center tw-gap-1" },
              t.createElement(I, { className: "tw-w-3 tw-h-3" }),
              e.metrics.executionTime,
              "ms"
            )
        )
      : t.createElement("td", { className: "tw-p-2 tw-text-xs tw-text-white/40 " }),
    t.createElement("td", { className: "tw-p-2 tw-text-xs tw-font-mono tw-text-white/40" }, e.hash?.substring(0, 12))
  );
}
function Fe({ logEntries: e = [], isOpen: i = !0, onToggle: r }) {
  const l = n(null),
    [s, c] = a(null),
    [d, m] = a(!1),
    [w, p] = a(null),
    [u, g] = a(new Set()),
    h = o(() => {
      const t = new Set();
      return (
        e.forEach((e) => {
          e.agent && t.add(e.agent);
        }),
        Array.from(t)
      );
    }, [e]);
  return t.createElement(
    "div",
    {
      className:
        "tw-absolute tw-bottom-0 tw-left-0 tw-right-0 tw-z-50 \n                      tw-transition-transform tw-duration-300 tw-ease-in-out \n                      " +
        (i ? "tw-translate-y-0" : "tw-translate-y-[calc(100%-40px)]"),
    },
    t.createElement(
      "div",
      {
        onClick: r,
        className:
          "tw-flex tw-items-center tw-justify-between  tw-cursor-pointer\n                         tw-px-4 tw-py-2 tw-rounded-t-xl \n                        tw-border-b !tw-border-white/10\n                        \n                         " +
          (i ? "tw-bg-branddialogbg/90" : "tw-bg-branddialogbg/40"),
      },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-4" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-gap-2 " },
          t.createElement(L, { className: "tw-w-4 tw-h-4 tw-text-brandblue  " }),
          t.createElement("span", { className: "tw-text-white tw-text-sm tw-font-medium" }, "Console Output")
        ),
        t.createElement(
          "select",
          {
            className: `tw-bg-transparent tw-border !tw-border-white/20 tw-rounded \n                         tw-px-2 tw-py-1 tw-text-white/80 tw-text-xs tw-w-[200px]\n                         \n                         ${i ? "tw-block" : "tw-hidden"}\n\n                         `,
            value: w || "",
            onChange: (e) => p(e.target.value || null),
          },
          t.createElement("option", { value: "" }, "All Agents"),
          h.map((e) => t.createElement("option", { key: e.id, value: e.id }, e.name))
        ),
        t.createElement(
          "button",
          {
            className: `tw-flex tw-items-center tw-gap-1 tw-px-2 tw-py-1 \n                         tw-rounded tw-text-xs ${d ? "tw-bg-white/10 tw-text-white/60" : "tw-bg-brandblue/20 tw-text-brandblue"}\n                         \n                          ${i ? "tw-block" : "tw-hidden"}\n                          `,
            onClick: () => m(!d),
          },
          t.createElement(I, { className: "tw-w-3 tw-h-3" }),
          d ? "Resume Auto-scroll" : "Auto-scrolling"
        )
      )
    ),
    t.createElement(
      "div",
      { className: "tw-bg-black tw-border-x !tw-border-white/10" },
      t.createElement(
        "div",
        { ref: l, className: "tw-h-[300px] tw-overflow-y-auto tw-font-mono" },
        t.createElement(
          "table",
          { className: "tw-w-full tw-table-fixed tw-text-xs tw-border-spacing-0" },
          t.createElement(
            "colgroup",
            null,
            t.createElement("col", { className: "tw-w-[45px]" }),
            t.createElement("col", { className: "tw-w-[116px]" }),
            t.createElement("col", { className: "tw-w-[90px]" }),
            t.createElement("col", { className: "tw-w-[200px]" }),
            t.createElement("col", { className: "tw-w-[300px]" }),
            t.createElement("col", { className: "tw-w-[50px]" }),
            t.createElement("col", { className: "tw-w-[70px]" })
          ),
          t.createElement(
            "thead",
            { className: "tw-sticky tw-top-0 tw-bg-[#2d293b]  tw-z-10   tw-border-b   !tw-border-white/10" },
            t.createElement(
              "tr",
              { className: "tw-border-b !tw-border-white/10" },
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[45px]" },
                "Time"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[116px]" },
                "Agent"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[90px]" },
                "Type"
              ),
              t.createElement("th", { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60" }, "Message"),
              t.createElement("th", { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60" }, "Details"),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[50px]" },
                "Metrics"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[70px]" },
                "CID"
              )
            )
          ),
          t.createElement(
            "tbody",
            null,
            e.map((e) =>
              t.createElement(
                t.Fragment,
                { key: e.id },
                t.createElement(_e, {
                  entry: { ...e, expanded: u.has(e.id) },
                  onClick: () => {
                    var t;
                    (e.expandable &&
                      ((t = e.id),
                      g((e) => {
                        const n = new Set(e);
                        return (n.has(t) ? n.delete(t) : n.add(t), n);
                      })),
                      m(!0));
                  },
                  isAutoScrollPaused: d,
                }),
                e.expandable &&
                  u.has(e.id) &&
                  t.createElement(
                    "tr",
                    { className: `${He[e.type].background} tw-opacity-80` },
                    t.createElement("td", { colSpan: 7, className: "tw-p-2 tw-h-8" }, t.createElement(Re, { entry: e }))
                  )
              )
            )
          )
        ),
        t.createElement("div", { className: "tw-h-8" })
      )
    )
  );
}
function Ue() {
  const [e, n] = a(!1),
    [r, l] = a([]),
    { state: o } = q();
  return (
    i(() => {
      const e = Object.values(o.nodes).reduce((e, t) => e.concat(t.logs), []);
      l(e);
    }, [o.nodes]),
    t.createElement(Fe, { logEntries: r, isOpen: e, onToggle: () => n(!e) })
  );
}
const Ge = "tw-h-full tw-w-full tw-overflow-auto tw-text-black relative",
  ze = ({ audioFiles: e }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-flex-col tw-space-y-4" },
      e
        .slice(0, 3)
        .map((e, n) =>
          t.createElement(
            "div",
            { key: n, className: "tw-w-full tw-max-w-md" },
            t.createElement(
              "audio",
              { controls: !0, className: "tw-w-full", src: e },
              "Your browser does not support the audio element."
            )
          )
        )
    ),
  Be = ({ images: e }) =>
    t.createElement(
      "div",
      { className: "grid h-full w-full grid-cols-2 gap-4 p-4" },
      e
        .slice(0, 4)
        .map((e, n) =>
          t.createElement(
            "div",
            {
              key: n,
              className: "relative overflow-hidden",
              style: { height: "100%", width: "100%", overflow: "auto", color: "black", position: "relative" },
            },
            t.createElement("img", { src: e, alt: `Grid image ${n + 1}`, className: "h-full w-full object-contain" })
          )
        )
    ),
  Ze = {
    default: (e) =>
      t.createElement(
        "div",
        { style: { height: "100%", width: "100%", overflow: "auto", color: "black", position: "relative" } },
        t.createElement(
          "div",
          { className: "tw-h-full tw-w-full tw-rounded tw-bg-gray-500/50" },
          e.params && e.params.mike ? e.params.mike : e.api.title
        )
      ),
    iframe: () => t.createElement("iframe", { style: { width: "100%", height: "100%" }, src: "https://dockview.dev" }),
    riskAssesment: (e) => {
      const n = e.params?.content;
      return n
        ? t.createElement(
            "div",
            { className: Ge },
            t.createElement(
              "div",
              { className: "tw-flex tw-flex-col tw-gap-4" },
              t.createElement(
                "div",
                { className: "tw-bg-brandreddark/20 tw-rounded-lg tw-p-4" },
                t.createElement(
                  "div",
                  { className: "tw-flex tw-justify-between tw-items-center tw-mb-4" },
                  t.createElement(
                    "h3",
                    { className: "tw-text-white tw-text-lg tw-font-medium" },
                    "Risk Level: ",
                    n.riskLevel
                  ),
                  n.requiresOverride &&
                    t.createElement(
                      "span",
                      { className: "tw-bg-brandreddark tw-px-2 tw-py-1 tw-rounded tw-text-sm" },
                      "Requires Override"
                    )
                ),
                t.createElement(
                  "div",
                  { className: "tw-space-y-3" },
                  n.factors.map((e, n) =>
                    t.createElement(
                      "div",
                      { key: n, className: "tw-bg-gray-800/50 tw-rounded tw-p-3" },
                      t.createElement(
                        "div",
                        { className: "tw-flex tw-justify-between tw-mb-1" },
                        t.createElement("span", { className: "tw-text-white/80" }, e.category),
                        t.createElement("span", { className: "tw-text-white" }, e.level)
                      ),
                      t.createElement("p", { className: "tw-text-white/60 tw-text-sm" }, e.details)
                    )
                  )
                ),
                t.createElement(
                  "div",
                  { className: "tw-mt-4" },
                  t.createElement(
                    "h4",
                    { className: "tw-text-white tw-text-sm tw-font-medium tw-mb-2" },
                    "Recommendations"
                  ),
                  t.createElement(
                    "ul",
                    { className: "tw-space-y-1" },
                    n.recommendations.map((e, n) =>
                      t.createElement("li", { key: n, className: "tw-text-white/80 tw-text-sm" }, "• ", e)
                    )
                  )
                )
              )
            )
          )
        : t.createElement("div", { className: "tw-text-white" }, "No assessment data");
    },
    audio: (e) => t.createElement("div", { className: Ge }, t.createElement(ze, { audioFiles: e.params.content })),
    jsonChart: (e) =>
      t.createElement(
        "div",
        { className: Ge },
        e.params?.content
          ? t.createElement(
              "div",
              { className: "tw-bg-gray-800/50 tw-rounded-lg tw-p-4 tw-h-full" },
              t.createElement("div", { className: "tw-text-white" }, JSON.stringify(e.params.content, null, 2))
            )
          : t.createElement("div", { className: "tw-text-white" }, "No chart data available")
      ),
    image: (e) =>
      t.createElement(
        "div",
        { className: Ge },
        t.createElement("img", {
          src: e.params.image,
          alt: "firms",
          className: "tw-h-full tw-w-full tw-object-contain",
        })
      ),
    imageGrid: (e) => t.createElement("div", { className: Ge }, t.createElement(Be, { images: e.params.images })),
    map: (e) => t.createElement("div", null, "TODO: Kepler.gl"),
    markdown: (e) =>
      t.createElement(
        "div",
        { className: Ge },
        t.createElement(
          V,
          {
            className:
              "tw-prose-xs tw-h-full tw-w-full tw-overflow-auto tw-rounded tw-bg-transparent tw-p-4 tw-text-white",
          },
          e.params && e.params.content ? e.params.content : "# no markdown"
        )
      ),
    toolNotify: (e) => {
      const n = e.params?.content;
      return n
        ? t.createElement(
            "div",
            { className: Ge },
            t.createElement(
              "div",
              { className: "tw-flex tw-flex-col tw-gap-2" },
              n.map((e, n) =>
                t.createElement(
                  "div",
                  { key: n, className: "tw-bg-gray-800/50 tw-rounded-lg tw-p-4 tw-border-l-4 tw-border-l-blue-500" },
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-justify-between tw-items-center tw-mb-2" },
                    t.createElement("span", { className: "tw-text-white/60 tw-text-xs" }, e.timestamp),
                    t.createElement(
                      "span",
                      { className: "tw-px-2 tw-py-1 tw-rounded tw-text-xs tw-bg-green-500/20 tw-text-green-300" },
                      e.status
                    )
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-flex-col tw-gap-1" },
                    t.createElement("span", { className: "tw-text-white tw-font-medium" }, "To: ", e.recipient),
                    t.createElement("p", { className: "tw-text-white/80" }, e.message),
                    t.createElement(
                      "p",
                      { className: "tw-text-white/60 tw-text-sm tw-italic" },
                      "Response: ",
                      e.response
                    )
                  )
                )
              )
            )
          )
        : t.createElement("div", { className: "tw-text-white" }, "No notifications");
    },
  },
  qe = (t) => {
    const [n, a] = e.useState(t.containerApi.hasMaximizedGroup()),
      [i, r] = e.useState("popout" === t.api.location.type);
    e.useEffect(() => {
      const e = t.containerApi.onDidMaximizedGroupChange(() => {
          a(t.containerApi.hasMaximizedGroup());
        }),
        n = t.api.onDidLocationChange(() => {
          r("popout" === t.api.location.type);
        });
      return () => {
        (e.dispose(), n.dispose());
      };
    }, [t.containerApi]);
    return e.createElement(
      "div",
      {
        className: "group-control",
        style: {
          display: "flex",
          alignItems: "center",
          padding: "0px 8px",
          height: "100%",
          color: "var(--dv-activegroup-visiblepanel-tab-color)",
        },
      },
      e.createElement(P, {
        className: "tw-mr-2 tw-h-4 tw-w-4",
        onClick: () => {
          t.containerApi.hasMaximizedGroup() ? t.containerApi.exitMaximizedGroup() : t.activePanel?.api.maximize();
        },
      })
    );
  },
  $e = {
    default: (t) =>
      e.createElement(D, {
        onContextMenu: (e) => {
          e.preventDefault();
        },
        ...t,
      }),
  },
  je = (e, t) => {
    if (0 === e) return {};
    const n = e % 4,
      a = Math.floor(e / 4);
    if (!Array.isArray(t) || !t.length) return {};
    if (0 === a) {
      const n = t[e - 1];
      return n?.id ? { position: { referencePanel: n.id, direction: "right" } } : {};
    }
    const i = t[4 * (a - 1) + n];
    return i?.id ? { position: { referencePanel: i.id, direction: "below" } } : {};
  },
  Ye = (t) => {
    const [n, r] = e.useState(),
      [l, o] = a(0),
      [s, c] = a([]),
      { state: d } = q(),
      m = Object.values(d.nodes).reduce((e, t) => e.concat(t.outputs), []),
      [w, p] = a(m);
    i(() => {
      if (!n) return;
      const e = Object.values(d.nodes).reduce((e, t) => e.concat(t.outputs), []),
        t = [];
      e.forEach((e, a) => {
        if (!n.getPanel(e.id) && e.id) {
          const i = { ...e, ...je(a, t) },
            r = n.addPanel(i);
          t.push(r);
        }
      });
    }, [d.nodes]);
    return e.createElement(
      "div",
      { className: "tw-h-full tw-flex tw-flex-col tw-grow tw-bg-transparent" },
      e.createElement(
        "div",
        { className: "tw-flex tw-h-0 tw-grow" },
        e.createElement(
          "div",
          { className: "tw-flex tw-h-full tw-overflow-hidden tw-grow" },
          e.createElement(H, {
            components: Ze,
            defaultTabComponent: $e.default,
            rightHeaderActionsComponent: qe,
            onReady: (e) => {
              if (!e?.api) return;
              r(e.api);
              const t = [];
              m.forEach((n, a) => {
                if (n.id) {
                  const i = { ...n, ...je(a, t) },
                    r = e.api.addPanel(i);
                  t.push(r);
                }
              });
            },
            className: t.theme || "dockview-theme-abyss",
          })
        )
      )
    );
  },
  We = ({ children: e }) =>
    t.createElement(
      "div",
      { className: " tw-h-full tw-w-full", style: { animation: "smoothSlideIn 0.6s ease-out forwards" } },
      t.createElement(
        "style",
        null,
        "\n        @keyframes smoothSlideIn {\n          0% {\n            opacity: 0;\n            transform: translateX(30px);\n          }\n          100% {\n            opacity: 1;\n            transform: translateX(0);\n          }\n        }\n      "
      ),
      e
    ),
  Je = ({ startId: e, endId: a, isEndpointInFlow: r = !0 }) => {
    const l = n(null),
      o = n(null),
      s = n(null),
      c = n(null);
    return (
      i(() => {
        o.current = document.querySelector(".react-flow__viewport")?.parentElement || null;
        const t = () => {
            const t = document.getElementById(e),
              n = document.getElementById(a),
              i = l.current,
              r = o.current;
            if (!(t && n && i && r)) return;
            const s = window.getComputedStyle(r.querySelector(".react-flow__viewport") || r);
            new DOMMatrix(s.transform);
            const c = t.getBoundingClientRect(),
              d = n.getBoundingClientRect(),
              m = c.right,
              w = c.top + c.height / 2,
              p = d.left,
              u = d.top + d.height / 2,
              g = `M ${m} ${w}\n                      C ${m + (p - m) / 3} ${w},\n                        ${m + (2 * (p - m)) / 3} ${u},\n                        ${p} ${u}`;
            i.setAttribute("d", g);
          },
          n = () => {
            requestAnimationFrame(t);
          };
        t();
        const i = o.current;
        if (i) {
          const e = i.querySelector(".react-flow__viewport");
          e &&
            ((c.current = new MutationObserver(n)),
            c.current.observe(e, { attributes: !0, attributeFilter: ["style", "transform"] }));
        }
        const r = document.getElementById(a)?.closest(".react-flow__node");
        return (
          r &&
            ((s.current = new MutationObserver(n)),
            s.current.observe(r, { attributes: !0, attributeFilter: ["style", "transform", "class"], subtree: !1 })),
          window.addEventListener("resize", n),
          () => {
            (window.removeEventListener("resize", n), c.current?.disconnect(), s.current?.disconnect());
          }
        );
      }, [e, a]),
      t.createElement(
        "svg",
        {
          className: "tw-fixed tw-inset-0 tw-pointer-events-none tw-z-50 tw-w-full tw-h-full",
          style: { overflow: "visible" },
        },
        t.createElement("path", {
          ref: l,
          strokeWidth: "1",
          fill: "none",
          strokeDasharray: "8,4",
          className: "tw-stroke-brandalert",
        })
      )
    );
  },
  Ke = ({ children: e, t: n = 1e3 }) => {
    const [a, i] = t.useState(!1);
    return (
      t.useEffect(() => {
        setTimeout(() => {
          i(!0);
        }, n);
      }, []),
      a ? t.createElement(t.Fragment, null, e) : null
    );
  },
  Xe = () =>
    t.createElement(
      "svg",
      {
        className: "tw-mt-[11px] tw-mr-3",
        width: "90",
        height: "90",
        viewBox: "0 0 90 90",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement(
        "g",
        { "clip-path": "url(#clip0_726_174)" },
        t.createElement("path", {
          d: "M74.8813 5.7598H32.3797C30.0865 5.7598 27.8905 6.6706 26.2705 8.2906L8.29209 26.269C6.67209 27.889 5.76129 30.0886 5.76129 32.3782V66.2398C5.76129 71.0134 9.63129 74.8798 14.4013 74.8798H53.5189C49.3861 71.0026 46.8013 65.4982 46.8013 59.3998C46.8013 47.689 56.3305 38.1598 68.0413 38.1598C74.1397 38.1598 79.6441 40.7482 83.5213 44.8774V14.3998C83.5213 9.6298 79.6549 5.7598 74.8813 5.7598ZM30.9613 47.401H15.3625C14.0377 47.401 12.9613 46.3282 12.9613 44.9998C12.9613 43.6714 14.0341 42.5986 15.3625 42.5986H30.9613C32.2861 42.5986 33.3625 43.6714 33.3625 44.9998C33.3625 46.3282 32.2897 47.401 30.9613 47.401ZM47.7625 36.601H15.3625C14.0377 36.601 12.9613 35.5246 12.9613 34.1998C12.9613 32.875 14.0341 31.7986 15.3625 31.7986H47.7625C49.0873 31.7986 50.1637 32.8714 50.1637 34.1998C50.1637 35.5282 49.0909 36.601 47.7625 36.601Z",
          fill: "url(#paint0_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M68.04 43.92C59.5044 43.92 52.56 50.8644 52.56 59.4C52.56 67.9356 59.5044 74.88 68.04 74.88C76.5756 74.88 83.52 67.9356 83.52 59.4C83.52 50.8644 76.5756 43.92 68.04 43.92Z",
          fill: "url(#paint1_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M77.1097 54.8399L77.333 54.5924L77.0855 54.3691L76.1392 53.5153L75.8918 53.292L75.6685 53.5395L65.0042 65.3591L60.908 61.2318L60.6732 60.9953L60.4366 61.2301L59.532 62.1279L59.2954 62.3627L59.5302 62.5993L64.8232 67.9324L65.0714 68.1824L65.3073 67.9209L77.1097 54.8399Z",
          fill: "black",
          stroke: "black",
          "stroke-width": "0.666667",
        })
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "linearGradient",
          {
            id: "paint0_linear_726_174",
            x1: "17.4953",
            y1: "8.72209",
            x2: "49.8151",
            y2: "86.0476",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "#E2CCFF" }),
          t.createElement("stop", { offset: "1", "stop-color": "#0D0D0D" })
        ),
        t.createElement(
          "linearGradient",
          {
            id: "paint1_linear_726_174",
            x1: "60.1618",
            y1: "49.4486",
            x2: "92.0893",
            y2: "99.8968",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "white" }),
          t.createElement("stop", { offset: "0.459251" }),
          t.createElement("stop", { offset: "0.643137" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_726_174" },
          t.createElement("rect", { width: "90", height: "90", fill: "white" })
        )
      )
    ),
  Qe = () => {
    const [e, n] = a("");
    return (
      i(() => {
        const e = new Date();
        e.setMinutes(e.getMinutes() - 1);
        const t = e.toLocaleString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          timeZone: "EST",
          hour12: !1,
        });
        n(t);
      }, []),
      t.createElement(
        "div",
        { className: "tw-h-[126px] tw-pl-24 tw-flex tw-items-center" },
        t.createElement(Xe, null),
        t.createElement(
          "div",
          { className: "tw-flex tw-flex-col" },
          t.createElement(
            "p",
            { className: "tw-text-white tw-text-[20px] tw-font-medium tw-leading-[100%] tw-mb-1" },
            "Response Summary"
          ),
          t.createElement(
            "span",
            { className: "tw-text-white tw-text-[32px] tw-font-normal tw-leading-[100%] tw-mb-1" },
            "Joint Intelligence Brief"
          ),
          t.createElement(
            "p",
            { className: "tw-text-[#A1A1AA] tw-font-normal tw-text-[13px] tw-leading-[100%]" },
            "Generated ",
            e
          )
        )
      )
    );
  },
  et = () => {
    const e = 10,
      n = 45,
      a = 2,
      i = `\n  Joint Intelligence Briefing - ${(() => {
        const e = new Date();
        return (
          e.setMinutes(e.getMinutes() - 1),
          e.toLocaleString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            timeZone: "EST",
            hour12: !1,
          })
        );
      })()}\n  \n  THREAT ASSESSMENT SUMMARY\n  SIGINT collection triggered multi-source verification protocol. Geospatial intelligence data aggregated from satellite imagery, drone surveillance and NATO partner feeds confirm developing situation. Analysis covers designated area of interest with cross-referenced intelligence indicators.\n  \n  KEY INTELLIGENCE GATHERED\n  - Satellite imagery analysis completed through automated verification\n  - SIGINT correlation across multiple collection platforms\n  - Geospatial intelligence mapping with terrain analysis\n  - Real-time threat monitoring through allied intelligence feeds\n  \n  INTELLIGENCE METRICS\n  - 45+ primary source confirmations\n  - 3 independent verification channels\n  - 2 automated analysis cycles completed\n  - 25+ corroborating intelligence indicators\n  - 78 related OSINT data points analyzed\n  \n  COMPLIANCE STATUS\n  Two protocol frameworks required verification:\n  1. Sourcing Protocol: Validated through compliance gateway\n  2. CUI Requirements: Information protection measures active\n  \n  All intelligence gathering executed in compliance with National Space Security Policy guidelines and validated through Nemo Guardrails system.\n  `;
    return t.createElement(
      "div",
      { className: "tw-p-6 tw-bg-[#09090B] tw-rounded-xl" },
      t.createElement(Qe, null),
      t.createElement(
        "div",
        { className: "tw-grid tw-grid-cols-3 tw-gap-4 tw-mb-8" },
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(T, { className: "tw-text-blue-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Policies Passed")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-blue-500" }, e)
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(M, { className: "tw-text-green-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Controls Passed")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-green-500" }, n)
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(O, { className: "tw-text-yellow-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Controls Mitigated")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-yellow-500" }, a)
        )
      ),
      t.createElement(
        "div",
        { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-6" },
        t.createElement("h3", { className: "tw-text-white tw-text-xl tw-mb-4" }, "Agentic Response Summary"),
        t.createElement("div", { className: "tw-text-gray-300 tw-whitespace-pre-line" }, i)
      )
    );
  },
  tt = [
    { id: "ctrl-1", title: "Executive Order 12333", isAlert: !1, mandatory: !0, implemented: !0 },
    {
      id: "ctrl-2",
      title: "Foreign Intelligence Surveillance Act (FISA)",
      isAlert: !1,
      mandatory: !1,
      implemented: !1,
    },
    {
      id: "guardrail-2",
      title: "Sourcing Protocol",
      isAlert: !0,
      mandatory: !0,
      implemented: !1,
      alertType: "authorize",
    },
    {
      id: "guardrail-1",
      title: "Controlled Unclassified Information (CUI)",
      isAlert: !0,
      mandatory: !0,
      implemented: !1,
    },
    { id: "ctrl-5", title: "Intelligence Community Directive 102", isAlert: !1, mandatory: !0, implemented: !0 },
    { id: "ctrl-6", title: "National Intelligence Priorities Framework", isAlert: !1, mandatory: !1, implemented: !0 },
    { id: "ctrl-7", title: "Intelligence Authorization Act", isAlert: !1, mandatory: !1, implemented: !0 },
    {
      id: "ctrl-9",
      title: "NATO Security Classification Protocols",
      isAlert: !0,
      mandatory: !1,
      implemented: !0,
      alertType: "remediate",
    },
    {
      id: "ctrl-10",
      title: "National Space Security Policy",
      isAlert: !1,
      mandatory: !1,
      implemented: !1,
      alertType: "authorize",
    },
  ],
  nt = () => {
    const [e, r] = a(!1),
      [l, o] = a(null),
      [s, c] = a(null),
      [d, m] = a(!1),
      [w, p] = a(!1),
      u = n(null),
      { state: g, startPipeline: h, overrideGuardrail: f, remediateGuardrail: E } = q(),
      [b, y] = a(!1),
      [v, x] = a(!1),
      [C, N] = a(!1),
      [I, k] = a(),
      A = () => {
        (f("guardrail-2", "Manual override approved"), y(!0), o(null));
      };
    i(() => {
      (o("guardrail-1"), c("guardrail-1-item-wrapper"), k(tt[3]));
    }, []);
    const [T, S] = t.useState([
      { name: "Agentic Workflow", current: !0 },
      { name: "Console", current: !1 },
      { name: "Policy Audit", current: !1 },
    ]);
    i(() => {
      const e = setTimeout(() => {
        p(!0);
      }, 750);
      return () => clearTimeout(e);
    }, []);
    const M = (e) => {
        if ((k(e), e.isAlert)) {
          const t = `${e.id}-item-wrapper`;
          (console.log("debug: handleControlClick", e.id, t),
            l && l !== e.id ? (o(e.id), c(t)) : l && l === e.id ? (o(null), m(!1)) : (o(e.id), c(t)));
        } else (o(null), m(!1));
      },
      L = (e) => {
        "guardrail-1" === e.id && (o("guardrail-1"), c("guardrail-1-item-wrapper"));
      },
      P = () => {
        (o(null), m(!1));
      },
      O = () => {
        m(!0);
      },
      R = T.find((e) => e.current)?.name || T[0].name;
    return t.createElement(
      _,
      { outsideGridRender: () => t.createElement(Ue, null) },
      t.createElement(
        "div",
        {
          ref: u,
          className:
            "tw-transition-opacity tw-duration-150 tw-ease-in-out tw-h-full " + (w ? "tw-opacity-100" : "tw-opacity-0"),
        },
        "Agentic Workflow" === R &&
          t.createElement(
            "div",
            { className: "tw-text-white tw-flex tw-h-full tw-flex-col tw-overflow-visible tw-p-6" },
            t.createElement(
              "div",
              { className: "tw-w-full tw-flex tw-overflow-x-visible tw-h-full" },
              t.createElement(j, { data: tt, onControlClick: M }),
              t.createElement(
                "div",
                { className: " tw-grow tw-relative tw-flex tw-items-center" },
                t.createElement(ie, { backgroundColor: "transparent", textColor: "white", onNodeClick: L }),
                d &&
                  "guardrail-1" === I?.id &&
                  t.createElement(
                    "div",
                    { className: "tw-w-11/12 tw-h-full tw-absolute tw-left-0 tw-right-0 tw-m-auto tw-z-[1000]" },
                    t.createElement(We, null, t.createElement(le, { onClose: () => m(!1) }))
                  ),
                d &&
                  "guardrail-1" === I?.id &&
                  t.createElement(
                    "div",
                    { className: "tw-w-11/12 tw-h-full tw-absolute tw-left-0 tw-right-0 tw-m-auto tw-z-[1000]" },
                    t.createElement(
                      We,
                      null,
                      t.createElement(oe, {
                        onClose: () => m(!1),
                        onClick: () => (E("guardrail-1", "Manual remediation approved"), o(null), m(!1), void x(!0)),
                      })
                    )
                  ),
                t.createElement("div", { className: "tw-absolute tw-bottom-0 tw-left-16" }, t.createElement(ue, null))
              ),
              t.createElement(
                "div",
                { className: "tw-relative tw-h-full" },
                t.createElement(Oe, {
                  isBlocked: !b || !v,
                  isPlaying: "running" === g.status,
                  onPlay: h,
                  onPause: () => null,
                  onCancel: () => null,
                  onFinal: () => N(!0),
                }),
                t.createElement(
                  "div",
                  { className: "tw-w-[264px] tw-relative" },
                  l &&
                    I?.isAlert &&
                    t.createElement(
                      We,
                      null,
                      t.createElement(re, { onOverride: A, onCancel: P, onDetails: O, control: I })
                    ),
                  !l && t.createElement(We, null, t.createElement(ce, null))
                )
              )
            ),
            l &&
              s &&
              t.createElement(
                t.Fragment,
                null,
                t.createElement(Ke, { t: 380 }, t.createElement(Je, { startId: s, endId: `ripple-point-eq-${I?.id}` })),
                t.createElement(
                  Ke,
                  { t: 380 },
                  t.createElement(Je, {
                    startId: `ripple-point-eq-${I?.id}`,
                    endId: "eq-control-dialog",
                    isEndpointInFlow: !1,
                  })
                )
              )
          ),
        "Console" === R &&
          t.createElement(
            "div",
            { className: "tw-relative tw-flex tw-w-full tw-flex-col tw-h-full tw-p-6" },
            t.createElement("div", { className: "tw-h-full tw-w-full" }, t.createElement(Ye, null))
          ),
        "Policy Audit" === R && t.createElement(Pe, null)
      ),
      t.createElement(
        "div",
        { className: "tw-absolute tw--top-10 tw-left-56 tw-transform tw--translate-y-[32px]  tw-flex tw-z-10" },
        t.createElement(we, { showCertApp: e, setShowCertApp: r }),
        t.createElement(pe, {
          tabs: T,
          onTabChange: (e) => {
            p(!1);
            const t = () => {
              (u.current?.removeEventListener("transitionend", t),
                S(T.map((t) => ({ ...t, current: t.name === e }))),
                setTimeout(() => {
                  requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                      p(!0);
                    });
                  });
                }, 200));
            };
            u.current?.addEventListener("transitionend", t);
          },
        })
      ),
      C
        ? t.createElement(
            "div",
            { className: "tw-fixed tw-inset-0 tw-z-[2000] tw-flex tw-items-center tw-justify-center tw-bg-black/50" },
            t.createElement(
              "div",
              {
                className: "tw-relative tw-bg-white tw-shadow-lg tw-max-h-[90vh] tw-overflow-auto",
                style: { width: "8.5in", height: "11in", transform: "scale(0.9)" },
              },
              t.createElement(
                "button",
                {
                  onClick: () => N(!1),
                  className:
                    "tw-absolute tw-top-4 tw-right-4 tw-z-10 tw-rounded-full tw-bg-gray-800 tw-p-2 tw-text-white hover:tw-bg-gray-700",
                },
                t.createElement(
                  "svg",
                  { className: "tw-h-6 tw-w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor" },
                  t.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l12 12",
                  })
                )
              ),
              t.createElement("div", { className: "tw-h-full tw-w-full tw-overflow-auto" }, t.createElement(et, null))
            )
          )
        : null
    );
  },
  at = () =>
    t.createElement(
      Z,
      null,
      t.createElement("style", null, "\n        .modal-body {\n        padding: 0;}\n      "),
      t.createElement(nt, null)
    ),
  it = () =>
    t.createElement(
      "svg",
      {
        className: "tw-mt-[11px] tw-mr-3",
        width: "90",
        height: "90",
        viewBox: "0 0 90 90",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement(
        "g",
        { "clip-path": "url(#clip0_726_174)" },
        t.createElement("path", {
          d: "M74.8813 5.7598H32.3797C30.0865 5.7598 27.8905 6.6706 26.2705 8.2906L8.29209 26.269C6.67209 27.889 5.76129 30.0886 5.76129 32.3782V66.2398C5.76129 71.0134 9.63129 74.8798 14.4013 74.8798H53.5189C49.3861 71.0026 46.8013 65.4982 46.8013 59.3998C46.8013 47.689 56.3305 38.1598 68.0413 38.1598C74.1397 38.1598 79.6441 40.7482 83.5213 44.8774V14.3998C83.5213 9.6298 79.6549 5.7598 74.8813 5.7598ZM30.9613 47.401H15.3625C14.0377 47.401 12.9613 46.3282 12.9613 44.9998C12.9613 43.6714 14.0341 42.5986 15.3625 42.5986H30.9613C32.2861 42.5986 33.3625 43.6714 33.3625 44.9998C33.3625 46.3282 32.2897 47.401 30.9613 47.401ZM47.7625 36.601H15.3625C14.0377 36.601 12.9613 35.5246 12.9613 34.1998C12.9613 32.875 14.0341 31.7986 15.3625 31.7986H47.7625C49.0873 31.7986 50.1637 32.8714 50.1637 34.1998C50.1637 35.5282 49.0909 36.601 47.7625 36.601Z",
          fill: "url(#paint0_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M68.04 43.92C59.5044 43.92 52.56 50.8644 52.56 59.4C52.56 67.9356 59.5044 74.88 68.04 74.88C76.5756 74.88 83.52 67.9356 83.52 59.4C83.52 50.8644 76.5756 43.92 68.04 43.92Z",
          fill: "url(#paint1_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M77.1097 54.8399L77.333 54.5924L77.0855 54.3691L76.1392 53.5153L75.8918 53.292L75.6685 53.5395L65.0042 65.3591L60.908 61.2318L60.6732 60.9953L60.4366 61.2301L59.532 62.1279L59.2954 62.3627L59.5302 62.5993L64.8232 67.9324L65.0714 68.1824L65.3073 67.9209L77.1097 54.8399Z",
          fill: "black",
          stroke: "black",
          "stroke-width": "0.666667",
        })
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "linearGradient",
          {
            id: "paint0_linear_726_174",
            x1: "17.4953",
            y1: "8.72209",
            x2: "49.8151",
            y2: "86.0476",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "#E2CCFF" }),
          t.createElement("stop", { offset: "1", "stop-color": "#0D0D0D" })
        ),
        t.createElement(
          "linearGradient",
          {
            id: "paint1_linear_726_174",
            x1: "60.1618",
            y1: "49.4486",
            x2: "92.0893",
            y2: "99.8968",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "white" }),
          t.createElement("stop", { offset: "0.459251" }),
          t.createElement("stop", { offset: "0.643137" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_726_174" },
          t.createElement("rect", { width: "90", height: "90", fill: "white" })
        )
      )
    ),
  rt = () => {
    const e = [
        {
          category: "1. Core Salesforce Platform Components",
          checks: [
            "Flow Builder with Case Creation Templates",
            "Process Builder with Loyalty Automation",
            "Custom Apex Classes for Business Logic",
            "Lightning Components for UI",
            "Experience Cloud Portal Configuration",
            "Custom Objects for Event Management",
            "Validation Rules and Triggers",
            "Platform Event Configurations",
          ],
        },
        {
          category: "2. Data Cloud Architecture",
          checks: [
            "Unified Profile Data Model",
            "CRM Data Stream Configuration",
            "S3 Data Ingestion Pipeline",
            "Identity Resolution Rules",
            "Real-time Sync Mechanisms",
            "Calculated Insights Framework",
            "Data Harmonization Rules",
            "Cross-object Relationship Maps",
          ],
        },
        {
          category: "3. Agentforce Implementation",
          checks: [
            "Atlas Reasoning Engine Configuration",
            "Agent Task Decomposition Rules",
            "Action Planning Framework",
            "Autonomous Operation Boundaries",
            "Platform-specific Guardrails",
            "Prompt Management System",
            "Agent Interaction Models",
            "Feedback Loop Implementation",
          ],
        },
        {
          category: "4. Integration Components",
          checks: [
            "Einstein Trust Layer Setup",
            "Databricks Connection Configuration",
            "External API Management",
            "Credit Card Loyalty Integration",
            "WhatsApp Channel Setup",
            "Messenger Integration",
            "Website Interaction Framework",
            "CRM Channel Orchestration",
          ],
        },
        {
          category: "5. Compliance Framework",
          checks: [
            "Data Residency Controls",
            "Cross-cloud Encryption",
            "Audit Trail System",
            "Data Masking Rules",
            "Access Control Framework",
            "Retention Policy Implementation",
            "GDPR Compliance Controls",
            "Security Monitoring System",
          ],
        },
      ],
      n = e.reduce((e, t) => e + t.checks.length, 0);
    return t.createElement(
      "div",
      { className: "component-container " },
      t.createElement(
        "div",
        { className: "tw-p-6 tw-px-32 tw-bg-[#09090B] tw-flex tw-flex-col" },
        t.createElement(
          "div",
          { className: "tw-h-[126px] tw-pl-24 tw-flex tw-items-center" },
          t.createElement(it, null),
          t.createElement(
            "div",
            { className: "tw-flex tw-flex-col" },
            t.createElement(
              "p",
              { className: "tw-text-white tw-text-[20px] tw-font-medium tw-leading-[100%] tw-mb-1" },
              "Audit Certificate"
            ),
            t.createElement(
              "span",
              { className: "tw-text-white tw-text-[32px] tw-font-normal tw-leading-[100%] tw-mb-1" },
              "EU AI Act - EMS"
            ),
            t.createElement(
              "p",
              { className: "tw-text-[#A1A1AA] tw-font-normal tw-text-[13px] tw-leading-[100%]" },
              "Last Completed 5 Sec Ago"
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-p-6 tw-pt-8 rounded" },
          t.createElement(
            "div",
            { className: "tw-grid tw-grid-cols-3 tw-gap-4 tw-mb-6 tw-box-border" },
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background:
                      "linear-gradient(279.39deg,  rgba(59, 130, 246, 0.35) 3.45%, rgba(21, 21, 23, 0) 102.13%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    padding: "16px",
                    gap: "8px",
                  },
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(T, { size: 24, className: "tw-text-blue-500" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Controls Met")
                ),
                t.createElement(
                  "div",
                  null,
                  t.createElement("div", { className: "tw-text-[56px]  tw-text-blue-500" }, n)
                )
              )
            ),
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background: "linear-gradient(283.45deg, rgba(34, 197, 94, 0.35) 2.95%, rgba(21, 21, 23, 0) 62.89%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                    padding: "16px",
                    paddingBottom: 8,
                    gap: "8px",
                  },
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(R, { size: 24, className: "tw-text-green-500" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Audit Authority")
                ),
                t.createElement("div", { className: "tw-text-[32px]  tw-text-green-500" }, "Aviva Insurance")
              )
            ),
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background:
                      "linear-gradient(279.39deg, rgba(226, 204, 255, 0.35) 3.45%, rgba(21, 21, 23, 0) 102.13%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    paddingTop: "16px",
                    paddingBottom: 8,
                    gap: "8px",
                  },
                  className: "tw-px-9",
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(R, { size: 24, className: "tw-text-white" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Registration")
                ),
                t.createElement(
                  "div",
                  { className: "tw-flex tw-flex-col tw-flex-grow tw-justify-center" },
                  t.createElement("span", { className: "tw-text-white tw-text-sm" }, "CID bafkr...aueq"),
                  t.createElement(
                    "span",
                    { className: "tw-text-white tw-text-sm" },
                    "HCS",
                    " ",
                    t.createElement(
                      "a",
                      { href: "https://hashscan.io/mainnet/transaction/1717101762.014321858", target: "_blank" },
                      "Oxe34...eb5e"
                    )
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-max-h-[800px] tw-overflow-auto" },
            e.map((e, n) =>
              t.createElement(
                "div",
                { key: n, className: "tw-p-4 tw-rounded-lg tw-border tw-border-[#27272A] tw-bg-[#D9D9D9]/5" },
                t.createElement(
                  "div",
                  { className: "tw-h-[40px]  tw-text-[#fafafa] tw-border-b tw-border-[#27272A]" },
                  e.category
                ),
                t.createElement(
                  "div",
                  { className: "tw-p-4" },
                  t.createElement(
                    "div",
                    { className: "tw-grid tw-gap-2" },
                    e.checks.map((e, n) =>
                      t.createElement(
                        "div",
                        { key: n, className: "tw-flex tw-items-center tw-gap-2" },
                        t.createElement(M, { size: 16, className: "tw-text-green-500" }),
                        t.createElement("span", { className: "tw-text-[14px] tw-text-[#A1A1AA]" }, e)
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    );
  };
export { at as AgentPolicyPlaneApplication, rt as AgentProvisionCertificate };
//# sourceMappingURL=index.js.map
