import "./App.css";
import AgentInferenceGraph from "./components/AgentInferenceGraph/AgentInferenceGraph";
import AgentRegistrationGraph5Datasets from "./components/AgentRegistrationGraph5Datasets/AgentRegistrationGraph5Datasets";
import AgentRegistrationGraph from "./components/AgentRegistrationGraph/AgentRegistrationGraph";

const App = () => {
  return (
    <>
      <h1>Agent Registration - Normal</h1>

      <AgentRegistrationGraph
        title="Agent Registration"
        agent="Turbo Puffin Agent"
        dataset="Turbo Puffin"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        width={1200}
        height={800}
        darkMode={true}
      />

      <br />
      <br />
      <br />

      <h1>Agent Registration - EU AI Act Guardrail</h1>

      {/* set metaOrder="1" to show the EU AI Act Guardrail for dataset node */}

      <AgentRegistrationGraph
        title="Agent Registration"
        agent="Turbo Puffin Agent"
        dataset="Turbo Puffin"
        metaOrder="1"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        width={1200}
        height={800}
        darkMode={true}
      />

      <br />
      <br />
      <br />

      <h1>Agent Registration (5 Datasets) - EU AI Act Guardrail</h1>

      {/* set metaOrderX="1" to show the EU AI Act Guardrail for a dataset node */}

      <AgentRegistrationGraph5Datasets
        title="Agent Registration"
        agent="Turbo Puffin Agent"
        dataset1="Turbo Puffin 1"
        metaOrder1="0"
        dataset2="Turbo Puffin 2"
        metaOrder2="0"
        dataset3="Turbo Puffin 3"
        metaOrder3="0"
        dataset4="Turbo Puffin 4"
        metaOrder4="1"
        dataset5="Turbo Puffin 5"
        metaOrder5="0"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        width={1200}
        height={800}
        darkMode={true}
      />

      <br />
      <br />
      <br />

      <h1>Inference Graph</h1>

      <AgentInferenceGraph
        title="Inference"
        agent="Turbo Puffin Agent"
        dataset="Turbo Puffin"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        userQuery="User Query"
        conversationContext="Conversation Context"
        augmentationData="Augmentation Data"
        systemPrompt="System Prompt"
        response="Response"
        width={1200}
        height={800}
        darkMode={false}
      />
    </>
  );
};

export default App;
