import LineageGraph from "../LineageGraph/LineageGraph";

import MANIFEST_TEMPLATE from "./agent-registration-manifest-template.json";

const AgentRegistrationGraph = ({
  title = "",
  agent = "Agent",
  dataset = "Dataset",
  metaOrder = "0",
  model = "Model",
  systemInstruction = "System Instruction",
  customInstruction = "Custom Instruction",
  width = 1200,
  height = 800,
  style = { border: "none" },
  darkMode = false,
}) => {
  const manifestText = JSON.stringify(MANIFEST_TEMPLATE)
    .replace(/{{AGENT_NAME}}/g, agent)
    .replace(/{{DATASET_NAME}}/g, dataset)
    .replace(/{{META_ORDER_NAME}}/g, metaOrder)
    .replace(/{{MODEL_NAME}}/g, model)
    .replace(/{{SYSTEM_INSTRUCTION_NAME}}/g, systemInstruction)
    .replace(/{{CUSTOM_INSTRUCTION_NAME}}/g, customInstruction);

  const manifest = JSON.parse(manifestText);

  return (
    <>
      <LineageGraph
        {...{
          title,
          manifest,
          width,
          height,
          style,
          darkMode,
        }}
      />
    </>
  );
};

export default AgentRegistrationGraph;
