import LineageGraph from "../LineageGraph/LineageGraph";

import MANIFEST_TEMPLATE from "./agent-registration-5-datasets-manifest-template.json";

const AgentRegistrationGraph5Datasets = ({
  title = "",
  agent = "Agent",
  dataset1 = "Dataset 1",
  metaOrder1 = "0",
  dataset2 = "Dataset 2",
  metaOrder2 = "0",
  dataset3 = "Dataset 3",
  metaOrder3 = "0",
  dataset4 = "Dataset 4",
  metaOrder4 = "0",
  dataset5 = "Dataset 5",
  metaOrder5 = "0",
  model = "Model",
  systemInstruction = "System Instruction",
  customInstruction = "Custom Instruction",
  width = 1200,
  height = 800,
  style = { border: "none" },
  darkMode = false,
}) => {
  const manifestText = JSON.stringify(MANIFEST_TEMPLATE)
    .replace(/{{AGENT_NAME}}/g, agent)
    .replace(/{{DATASET1_NAME}}/g, dataset1)
    .replace(/{{META_ORDER1_NAME}}/g, metaOrder1)
    .replace(/{{DATASET2_NAME}}/g, dataset2)
    .replace(/{{META_ORDER2_NAME}}/g, metaOrder2)
    .replace(/{{DATASET3_NAME}}/g, dataset3)
    .replace(/{{META_ORDER3_NAME}}/g, metaOrder3)
    .replace(/{{DATASET4_NAME}}/g, dataset4)
    .replace(/{{META_ORDER4_NAME}}/g, metaOrder4)
    .replace(/{{DATASET5_NAME}}/g, dataset5)
    .replace(/{{META_ORDER5_NAME}}/g, metaOrder5)
    .replace(/{{MODEL_NAME}}/g, model)
    .replace(/{{SYSTEM_INSTRUCTION_NAME}}/g, systemInstruction)
    .replace(/{{CUSTOM_INSTRUCTION_NAME}}/g, customInstruction);

  const manifest = JSON.parse(manifestText);

  return (
    <>
      <LineageGraph
        {...{
          title,
          manifest,
          width,
          height,
          style,
          darkMode,
        }}
      />
    </>
  );
};

export default AgentRegistrationGraph5Datasets;
