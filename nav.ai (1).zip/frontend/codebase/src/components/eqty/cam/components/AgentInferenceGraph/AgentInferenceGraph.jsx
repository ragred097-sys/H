import LineageGraph from "../LineageGraph/LineageGraph";

import MANIFEST_TEMPLATE from "./agent-inference-manifest-template.json";

const AgentInferenceGraph = ({
  title = "",
  agent = "Agent",
  dataset = "Dataset",
  model = "Model",
  systemInstruction = "System Instruction",
  customInstruction = "Custom Instruction",
  userQuery = "User Query",
  conversationContext = "Conversation Context",
  augmentationData = "Augmentation Data",
  systemPrompt = "System Prompt",
  response = "Response",
  width = 1600,
  height = 800,
  style = { border: "none" },
  darkMode = false,
}) => {
  const manifestText = JSON.stringify(MANIFEST_TEMPLATE)
    .replace(/{{AGENT_NAME}}/g, agent)
    .replace(/{{DATASET_NAME}}/g, dataset)
    .replace(/{{MODEL_NAME}}/g, model)
    .replace(/{{SYSTEM_INSTRUCTION_NAME}}/g, systemInstruction)
    .replace(/{{CUSTOM_INSTRUCTION_NAME}}/g, customInstruction)
    .replace(/{{USER_QUERY_NAME}}/g, userQuery)
    .replace(/{{CONVERSATION_CONTEXT_NAME}}/g, conversationContext)
    .replace(/{{AUGMENTATION_DATA_NAME}}/g, augmentationData)
    .replace(/{{SYSTEM_PROMPT_NAME}}/g, systemPrompt)
    .replace(/{{RESPONSE_NAME}}/g, response);

  const manifest = JSON.parse(manifestText);

  return (
    <>
      <LineageGraph
        {...{
          title,
          manifest,
          width,
          height,
          style,
          darkMode,
        }}
      />
    </>
  );
};

export default AgentInferenceGraph;
