import { useEffect, useState } from "react";

import { Spinner, Tab, Tabs } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AgentWorkflow } from "../../../lib/Model.js";
import { GovernanceService } from "../../../services/GovernanceService.js";
import { TranslationKeys } from "../../../types/translation-keys.js";
import { getEqtyPolicyPlane, renderEqtyPolicyPlane } from "../../../utils/eqty";
import { isDarkModeTheme } from "../../../utils/themeUtils";
import { useNotification } from "../../general/NotificationProvider";
import { AgentProvisionCertificate as AgentProvisionCertificateAUS } from "../policyplane-aus";
import { AgentProvisionCertificate as AgentProvisionCertificateEU } from "../policyplane-eu";
import { AgentProvisionCertificate as AgentProvisionCertificateUS } from "../policyplane-us";
// @ts-expect-error - AgentRegistrationGraph is a JSX file without type declarations
import AgentRegistrationGraph from "./AgentRegistrationGraph/AgentRegistrationGraph.jsx";

function removeLineageViolationScenario(obj: { [key: string]: any }): void {
  if (obj && typeof obj === "object") {
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        if (key === "meta_order") {
          if (obj[key] === "1") {
            obj[key] = "0";
          }
        } else if (typeof obj[key] === "object" && obj[key] !== null) {
          removeLineageViolationScenario(obj[key] as { [key: string]: any });
        }
      }
    }
  }
}

export default function AgentWorkflowLineage({ workflow }: { workflow: AgentWorkflow }) {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const [manifest, setManifest] = useState<{ [key: string]: any }>();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchManifest = async () => {
      try {
        const manifest = await GovernanceService.getAgenticLineage(workflow);
        if (getEqtyPolicyPlane() === "us") {
          // eliminate the EU GDPR violation when we're configured for a US audience
          removeLineageViolationScenario(manifest);
        }
        setManifest(manifest);
      } catch (error) {
        if (error instanceof Error) {
          console.error(t(TranslationKeys.ERRORMESSAGES_LINEAGEERROR), error.message);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINEAGEERROR), error);
        } else {
          console.error(t(TranslationKeys.ERRORMESSAGES_LINEAGEUNKNOWNERROR), error);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINEAGEUNKNOWNERROR), new Error());
        }
      } finally {
        setLoading(false); // Stop the spinner once all data is fetched
      }
    };

    fetchManifest();
  }, [workflow.id]);

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ height: "800px", width: "1200px" }}>
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  return (
    <>
      <Tabs defaultActiveKey="lineage" id="uncontrolled-tab-example" className="mb-3">
        <Tab eventKey="lineage" title="Agent Workflow Lineage">
          <AgentRegistrationGraph
            title={workflow.name}
            manifest={manifest}
            metaOrder="1"
            style={{ height: "85vh", width: "99vw" }}
            darkMode={isDarkModeTheme()}
          />
        </Tab>
        <Tab eventKey="cert" title="Agent Workflow Certificate">
          <div style={{ height: "85vh", width: "99vw" }}>
            {renderEqtyPolicyPlane(
              new Map([
                ["us", () => <AgentProvisionCertificateUS />],
                ["aus", () => <AgentProvisionCertificateAUS />],
                ["eu", () => <AgentProvisionCertificateEU />],
              ])
            )}
          </div>
        </Tab>
      </Tabs>
    </>
  );
}
