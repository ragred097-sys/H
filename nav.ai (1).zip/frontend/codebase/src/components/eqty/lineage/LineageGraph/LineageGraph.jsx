import { useEffect, useRef } from "react";

import { getEqtyPolicyPlane } from "../../../../utils/eqty";

const LineageGraph = ({
  title = "",
  manifest,
  width = 1200,
  height = 800,
  style = { border: "none" },
  darkMode = false,
}) => {
  const iframeRef = useRef(null);

  const baseUrl = "https://lineage-explorer.dev.eqtylab.io";
  const aus = getEqtyPolicyPlane() === "aus";
  const url = `${baseUrl}?darkmode=${darkMode}&policy=${aus ? "ai-ethics" : ""}`;

  const updateGraph = () => {
    if (iframeRef.current) {
      iframeRef.current.contentWindow.postMessage(
        {
          msgType: "embedded-mode-config",
          title,
          manifest,
        },
        "*"
      );
    }
  };

  // update graph when iFrame loads
  const handleIframeLoad = () => {
    updateGraph();
    // jank... better way would be to have explorer app send a message once it's ready
    setTimeout(updateGraph, 1000);
    setTimeout(updateGraph, 2000);
    setTimeout(updateGraph, 3000);
    setTimeout(updateGraph, 4000);
    setTimeout(updateGraph, 5000);
  };

  // update graph when props change
  useEffect(() => {
    updateGraph();
  }, [title, manifest]);

  return (
    <>
      <iframe
        ref={iframeRef}
        src={url}
        title={title}
        width={width}
        height={height}
        style={style}
        onLoad={handleIframeLoad}
      ></iframe>
    </>
  );
};

export default LineageGraph;
