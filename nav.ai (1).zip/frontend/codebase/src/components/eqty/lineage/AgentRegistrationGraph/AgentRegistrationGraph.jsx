import LineageGraph from "../LineageGraph/LineageGraph";

const AgentRegistrationGraph = ({
  title = "",
  manifest = null,
  width = 1200,
  height = 800,
  style = { border: "none" },
  darkMode = false,
}) => {
  return (
    <LineageGraph
      {...{
        title,
        manifest,
        width,
        height,
        style,
        darkMode,
      }}
    />
  );
};

export default AgentRegistrationGraph;
