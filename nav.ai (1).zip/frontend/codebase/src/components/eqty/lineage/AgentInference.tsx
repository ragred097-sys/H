import { useEffect, useState } from "react";

import { Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

// @ts-expect-error - AgentInferenceGraph is a JSX file without type declarations
import AgentInferenceGraph from "./AgentInferenceGraph/AgentInferenceGraph.jsx";
import { Assistant, Conversation, Message } from "../../../lib/Model.js";
import { GovernanceService } from "../../../services/GovernanceService";
import { TranslationKeys } from "../../../types/translation-keys.js";
import { isDarkModeTheme } from "../../../utils/themeUtils";
import { useNotification } from "../../general/NotificationProvider";

function escapeJSONString(str: string) {
  return str
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/\t/g, "\\t");
}
export default function AgentInference({
  conversation,
  messages,
}: {
  agent: Assistant;
  messages: Message[];
  conversation: Conversation;
}) {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const [manifest, setManifest] = useState<object>();
  const [loading, setLoading] = useState(true);
  const userMessage = messages[messages.length - 2]?.parts[0]?.content;
  const systemResponse = escapeJSONString(
    messages[messages.length - 1]?.parts[0]?.content.length > 50
      ? messages[messages.length - 1]?.parts[0]?.content.slice(0, 50)
      : messages[messages.length - 1]?.parts[0]?.content
  );

  console.log(userMessage, systemResponse);
  useEffect(() => {
    const fetchManifest = async () => {
      try {
        const manifest = await GovernanceService.getConversationLineage(conversation.id);
        setManifest(manifest);
      } catch (error) {
        if (error instanceof Error) {
          console.error(t(TranslationKeys.ERRORMESSAGES_LINEAGEERROR), error.message);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINEAGEERROR), error);
        } else {
          console.error(t(TranslationKeys.ERRORMESSAGES_LINEAGEUNKNOWNERROR), error);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINEAGEUNKNOWNERROR), new Error());
        }
      } finally {
        setLoading(false); // Stop the spinner once all data is fetched
      }
    };

    fetchManifest();
  }, [
    conversation.dataSourceIds,
    conversation.systemInstructionId,
    conversation.llmIds,
    conversation.assistantId,
    conversation.id,
    t,
    openErrorNotification,
  ]);

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ height: "800px", width: "1200px" }}>
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }
  return (
    <AgentInferenceGraph
      title={`Inference for Conversation: ${conversation.name}`}
      manifest={manifest}
      width={1200}
      height={800}
      darkMode={isDarkModeTheme()}
    />
  );
}
