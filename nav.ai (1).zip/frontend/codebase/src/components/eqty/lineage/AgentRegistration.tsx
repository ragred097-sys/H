// @ts-expect-error there are no types here
import AgentInferenceGraph from "./AgentInferenceGraph/AgentInferenceGraph.js";
// @ts-expect-error there are no types here
import AgentRegistrationGraph from "./AgentRegistrationGraph/AgentRegistrationGraph.js";

const AgentLineage = () => {
  return (
    <>
      <h1>Agent Registration</h1>

      <AgentRegistrationGraph
        title="Agent Registration"
        agent="Turbo Puffin Agent"
        dataset="Turbo Puffin"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        dark
        width={1200}
        height={800}
      />

      <br />
      <br />
      <br />

      <h1>Inference Graph</h1>

      <AgentInferenceGraph
        title="Inference"
        agent="Turbo Puffin Agent"
        dataset="Turbo Puffin"
        model="Phi-4"
        systemInstruction="Budget Analyst"
        customInstruction="Markdown Fluency"
        userQuery="User Query"
        conversationContext="Conversation Context"
        augmentationData="Augmentation Data"
        systemPrompt="System Prompt"
        response="Response"
        width={1200}
        height={800}
      />
    </>
  );
};
export default AgentLineage;
