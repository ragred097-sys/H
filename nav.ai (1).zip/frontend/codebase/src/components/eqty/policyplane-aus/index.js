import * as e from "react";
import t, {
  useRef as a,
  useContext as c,
  memo as d,
  useReducer as i,
  createContext as l,
  useLayoutEffect as m,
  useEffect as n,
  useMemo as o,
  useState as r,
  useCallback as s,
  forwardRef as w,
} from "react";

import _ from "react-markdown";

import { useGSAP as b } from "@gsap/react";
import {
  addEdge as E,
  useEdgesState as f,
  getBezierPath as g,
  useNodesState as h,
  Handle as p,
  Position as u,
  ReactFlow as x,
} from "@xyflow/react";
import "@xyflow/react/dist/base.css";
import { DockviewDefaultTab as T, DockviewReact as V } from "dockview";
import "dockview/dist/styles/dockview.css";
import v from "gsap";
import {
  UserCheck as A,
  AlertTriangle as D,
  Expand as H,
  Database as I,
  Shield as L,
  CircleAlert as M,
  ExternalLink as N,
  CheckCircle as P,
  Server as R,
  Terminal as S,
  Clock as k,
} from "lucide-react";
import { create as y } from "zustand";
import { combine as C } from "zustand/middleware";

const z = ({ children: e, responsiveRender: l, outsideGridRender: i }) => {
  const o = a(null),
    [s, c] = r({ width: 0, height: 0 }),
    d = 40;
  return (
    n(() => {
      const resizeHandler = () => {
        const element = o.current;
        if (!element) return;
        const t = element.offsetWidth,
          a = element.offsetHeight,
          r = Math.floor(t / d),
          n = Math.floor(a / d);
        c({ width: r * d, height: n * d });
      };
      return (resizeHandler(), window.addEventListener("resize", resizeHandler), () => window.removeEventListener("resize", resizeHandler));
    }, []),
    t.createElement(
      "div",
      { className: "component-container" },
      l && l(),
      !l &&
        t.createElement(
          "div",
          { className: "tw-pb-14 tw-pt-12 tw-px-5 tw-w-full tw-h-full tw-overflow-hidden tw-relative" },
          t.createElement(
            "div",
            { className: "tw-w-full tw-h-full tw-relative tw-flex tw-items-center tw-justify-center" },
            t.createElement(
              "div",
              { ref: o, className: "tw-absolute tw-inset-0 tw-z-50 tw-flex tw-justify-center" },
              t.createElement(
                "div",
                {
                  className: "tw-relative tw-shadow-[4px_4px_10px_1px_rgba(0,0,0,0.18)] tw-flex tw-justify-center",
                  style: {
                    width: s.width,
                    height: s.height,
                    backgroundImage:
                      "\n                  linear-gradient(to right, rgba(65,66,67,0.2) 1px, transparent 1px),\n                  linear-gradient(to bottom, rgba(65,66,67,0.2) 1px, transparent 1px)\n                ",
                    backgroundSize: "40px 40px",
                    borderRight: "1px solid rgba(65,66,67,0.2)",
                    borderBottom: "1px solid rgba(65,66,67,0.2)",
                  },
                },
                t.createElement("div", { className: "tw-relative tw-z-10 tw-w-full tw-max-w-[1736px] tw-h-full " }, e)
              )
            )
          ),
          i && i()
        )
    )
  );
};
function O(e, t) {
  let a;
  switch (t.type) {
    case "START_PIPELINE":
      a = { ...e, status: "running", startTime: Date.now() };
      break;
    case "PAUSE_PIPELINE":
      a = { ...e, status: "paused" };
      break;
    case "CANCEL_PIPELINE":
      a = { ...e, status: "cancelled", endTime: Date.now() };
      break;
    case "COMPLETE_PIPELINE":
      a = { ...e, status: "completed", endTime: Date.now() };
      break;
    case "UPDATE_NODE_STATUS":
      a = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            status: t.payload.status,
            ...("running" === t.payload.status ? { startTime: Date.now() } : {}),
          },
        },
      };
      break;
    case "ADD_LOG":
      a = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            logs: [...e.nodes[t.payload.nodeId].logs, t.payload.log],
          },
        },
      };
      break;
    case "COMPLETE_NODE":
      const r = e.stats?.completedNodes || 0;
      a = {
        ...e,
        nodes: {
          ...e.nodes,
          [t.payload.nodeId]: {
            ...e.nodes[t.payload.nodeId],
            status: "completed",
            endTime: Date.now(),
            outputs: t.payload.outputs || [],
          },
        },
        stats: { ...e.stats, completedNodes: r + 1 },
      };
      break;
    case "OVERRIDE_GUARDRAIL":
      a = {
        ...e,
        userOverrides: [
          ...e.userOverrides,
          { nodeId: e.activeGuardrail?.nodeId || "", timestamp: t.payload.timestamp, reason: t.payload.reason },
        ],
        activeGuardrail: null,
      };
      break;
    case "REMEDIATE_GUARDRAIL":
      a = {
        ...e,
        userRemediations: [
          ...e.userRemediations,
          { nodeId: e.activeGuardrail?.nodeId || "", timestamp: t.payload.timestamp, reason: t.payload.reason },
        ],
        activeGuardrail: null,
      };
      break;
    default:
      return e;
  }
  return a;
}
class Z {
  constructor(e, t) {
    ((this.nodeMetrics = new Map()),
      (this.checkInterval = null),
      (this.config = e),
      (this.dispatch = t),
      this.initializeNodeMetrics());
  }
  initializeNodeMetrics() {
    Object.entries(this.config.nodes).forEach(([e, t]) => {
      const a = t.dependencies?.map((e) => e.nodeId) || [];
      this.nodeMetrics.set(e, { phase: a.length ? "waiting" : "ready", waitingOn: a.length ? a : void 0, attempts: 0 });
    });
  }
  start() {
    ((this.checkInterval = setInterval(() => this.orchestrationCycle(), 500)),
      this.logPipelineState("Pipeline Started"));
  }
  logPipelineState(e) {
    (console.group(`Pipeline State - ${e}`),
      console.log("Timestamp:", new Date().toISOString()),
      this.nodeMetrics.forEach((e, t) => {
        console.log(`Node ${t}:`, { phase: e.phase, waitingOn: e.waitingOn, attempts: e.attempts });
      }),
      console.groupEnd());
  }
  orchestrationCycle() {
    let e = !1;
    (this.nodeMetrics.forEach((t, a) => {
      if ("waiting" === t.phase) {
        const a =
          t.waitingOn?.filter((e) => {
            const t = this.nodeMetrics.get(e);
            return !t || "completed" !== t.phase;
          }) || [];
        0 === a.length ? ((t.phase = "ready"), (t.waitingOn = void 0), (e = !0)) : (t.waitingOn = a);
      }
    }),
      this.nodeMetrics.forEach((t, a) => {
        "ready" === t.phase && (this.startNode(a), (e = !0));
      }),
      e && this.logPipelineState("Cycle Update"),
      Array.from(this.nodeMetrics.values()).every((e) => "completed" === e.phase) && this.cleanup());
  }
  startNode(e) {
    const t = this.nodeMetrics.get(e),
      a = this.config.nodes[e];
    if ("ready" !== t.phase) return;
    ((t.phase = "running"),
      t.attempts++,
      (t.startTime = Date.now()),
      this.dispatch({ type: "UPDATE_NODE_STATUS", payload: { nodeId: e, status: "running" } }));
    const r = Math.floor(a.minDuration + Math.random() * (a.maxDuration - a.minDuration));
    setTimeout(() => this.completeNode(e), r);
  }
  completeNode(e) {
    const t = this.nodeMetrics.get(e),
      a = this.config.nodes[e];
    ((t.phase = "completed"),
      (t.endTime = Date.now()),
      a.logsToOutput.forEach((t) => {
        this.dispatch({ type: "ADD_LOG", payload: { nodeId: e, log: t } });
      }),
      this.dispatch({ type: "COMPLETE_NODE", payload: { nodeId: e, outputs: a.outputs } }),
      Array.from(this.nodeMetrics.values()).every((e) => "completed" === e.phase) &&
        this.dispatch({ type: "COMPLETE_PIPELINE" }));
  }
  cleanup() {
    (this.checkInterval && (clearInterval(this.checkInterval), (this.checkInterval = null)),
      this.logPipelineState("Pipeline Completed"));
  }
}
const F = {
    nodes: {
      start: {
        id: "start",
        label: "Start",
        description: "Pipeline entry point",
        minDuration: 1e3,
        maxDuration: 2e3,
        outputs: [],
        logsToOutput: [
          {
            id: 9,
            content: "Human Override Required",
            details: "High-risk scenario detected - requires manual authorization",
            timestamp: "14:01:30",
            type: "warning",
            agent: { id: "policy-1", name: "Policy Override Validator", type: "policy-validator" },
            expandable: !0,
            hash: "bakY7wf3b4a2",
          },
          {
            id: 10,
            content: "Human Override Granted",
            details: "Emergency response protocol override approved by operator",
            timestamp: "14:02:00",
            type: "human-override",
            metrics: { executionTime: 500 },
            expandable: !0,
            hash: "bak6f2Y7e3a4",
          },
          {
            id: 1,
            content: "Pipeline execution started",
            details: "Initializing concurrent data collection paths",
            timestamp: "14:00:00",
            type: "info",
            hash: "bakk09F4w1dH",
            expandable: !0,
          },
        ],
      },
      video: {
        id: "video",
        label: "Collect video footage",
        description: "Collects and processes video feeds from surveillance systems",
        minDuration: 5e3,
        maxDuration: 15e3,
        logsToOutput: [
          {
            id: 2,
            content: "Video Feed Collector established connection",
            details: "Successfully connected to surveillance network - streaming from 8 critical flood zone cameras",
            timestamp: "14:00:02",
            type: "info",
            agent: { id: "video-1", name: "Video Feed Collector", type: "video-collector" },
            metrics: { executionTime: 1850, apiCalls: [{ service: "surveillance-api", duration: 1200, status: 200 }] },
            expandable: !0,
            hash: "bak1a2k3e4d5",
          },
        ],
        outputs: [],
        tooling: { type: "vision", provider: "nemo" },
      },
      analyze: {
        id: "analyze",
        label: "Analyze Footage",
        description: "Uses NVIDIA mixed-modal LLMs to analyze video content",
        minDuration: 1e4,
        maxDuration: 2e4,
        dependencies: [{ nodeId: "video", required: !0 }],
        logsToOutput: [
          {
            id: 3,
            content: "Video Analysis Complete",
            details: "NVIDIA mixed-modal LLM analysis detected rising water levels in zones A3 and B2",
            timestamp: "14:00:45",
            type: "agent-complete",
            agent: { id: "analyze-1", name: "Video Analyzer", type: "video-analyzer" },
            output: { type: "report", id: "video-analysis-001", location: "/outputs/video/001" },
            expandable: !0,
            hash: "baklf7600a2r",
          },
        ],
        outputs: [
          {
            id: "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11",
            title: "Video Feed Analysis",
            component: "markdown",
            params: {
              content:
                "## Video Analysis Report\n**Timestamp:** 2025-01-19 14:30 EST\n**Location:** Downtown River District\n\n### Key Observations\n- Multiple intersections showing standing water 2-3 feet deep\n- Traffic signals malfunctioning at Main & River St\n- Emergency vehicles navigating through flooded areas\n- Civilians attempting to wade through flood waters\n- Structural damage visible on riverside buildings\n\n### Critical Concerns\n- Water level rising at approximately 2 inches per hour\n- Two stranded vehicles with possible occupants\n- Bridge structural integrity may be compromised\n- Power lines down in northwest quadrant\n\n### People Count\n- ~25 civilians visible in affected areas\n- 3 emergency response vehicles\n- 2 rescue boats deployed",
            },
            metadata: { description: "Detailed analysis of visual content and events" },
          },
        ],
        tooling: { type: "vision", provider: "nemo", config: { modelType: "mixed-modal" } },
      },
      partner: {
        id: "partner",
        label: "Partner Report (Paramedic/Fire)",
        description: "Collects reports from local EMS stations",
        minDuration: 3e3,
        maxDuration: 8e3,
        logsToOutput: [
          {
            id: 4,
            content: "Partner Report Collection Started",
            details: "Retrieving reports from 5 local EMS stations",
            timestamp: "14:00:03",
            type: "info",
            agent: { id: "partner-1", name: "Partner Report Analyzer", type: "partner-analyzer" },
            expandable: !0,
            hash: "bak3a4k5e88q",
          },
        ],
        outputs: [
          {
            id: "e817b187-aba3-4b0d-a34e-a1d82319627c",
            title: "Partner Reports (EMS/Fire)",
            component: "markdown",
            params: {
              content:
                "# Emergency Services Situation Report\n**Time:** 14:45 EST\n**Reporting Units:** Station 7, 12, 15\n\n## Active Response Units\n- Engine 7: Water rescue operations\n- Ladder 12: Building evacuation\n- EMS Units: 3 ambulances deployed\n\n## Incidents in Progress\n1. Water rescue at 123 River Street\n   - 2 adults, 1 child\n   - Second floor evacuation needed\n   \n2. Medical emergency at Riverside Apartments\n   - Elderly resident requires evacuation\n   - Medical equipment needs power\n   \n3. Structure assessment at Downtown Bridge\n   - Signs of stress on support columns\n   - Engineering team requested\n\n## Resource Status\n- Swift water rescue team: Engaged\n- Additional boats requested\n- Helicopter support inbound",
            },
          },
        ],
        tooling: { type: "osint", provider: "anthropic" },
      },
      calls: {
        id: "calls",
        label: "Calls for service",
        description: "Monitors dispatch logs and analyzes call patterns",
        minDuration: 4e3,
        maxDuration: 1e4,
        logsToOutput: [
          {
            id: 5,
            content: "Service Call Analysis Alert",
            details: "Detected 300% increase in water-related emergency calls in past 15 minutes",
            timestamp: "14:00:15",
            type: "warning",
            agent: { id: "calls-1", name: "Service Call Analyzer", type: "service-call-analyzer" },
            output: { type: "chart", id: "call-pattern-001", location: "/outputs/calls/patterns/001" },
            expandable: !0,
            hash: "bak5a6k7e8d9",
          },
        ],
        outputs: [
          {
            id: "ce3b39d8-1bae-4ed3-b4db-2a74658f0d85",
            title: "Emergency Call Analysis",
            component: "jsonChart",
            params: {
              content: {
                labels: ["10:00", "11:00", "12:00", "13:00", "14:00", "15:00"],
                datasets: [
                  { label: "Water Emergency Calls", data: [5, 12, 25, 45, 62, 78], color: "#FF0000" },
                  { label: "Medical Emergency", data: [3, 8, 15, 22, 28, 35], color: "#00FF00" },
                  { label: "Evacuation Requests", data: [2, 5, 18, 35, 48, 55], color: "#0000FF" },
                ],
                anomalyThreshold: 40,
                metadata: { callVolume: "Critical", trendDirection: "Increasing", peakTime: "14:30 EST" },
              },
            },
          },
        ],
        alertConditions: { type: "anomaly", threshold: 0.75, triggers: ["high-call-volume", "pattern-change"] },
        tooling: { type: "osint", provider: "anthropic" },
      },
      social: {
        id: "social",
        label: "Social Media",
        description: "Monitors social media for distress signals",
        minDuration: 5e3,
        maxDuration: 12e3,
        logsToOutput: [
          {
            id: 6,
            content: "Social Media Monitor Alert",
            details: "Multiple verified distress calls detected on Twitter and Telegram in downtown area",
            timestamp: "14:00:20",
            type: "warning",
            agent: { id: "social-1", name: "Social Media Monitor", type: "social-monitor" },
            expandable: !0,
            hash: "bak0a1k2e3d4",
          },
        ],
        outputs: [
          {
            id: "14c18af1-a352-45e6-976e-3c194bdc6ee8",
            title: "Social Media Distress Signals",
            component: "markdown",
            params: {
              content:
                '# Social Media Distress Signals Analysis\n**Last Updated:** 14:50 EST\n\n## Verified Emergency Reports\n\n### Twitter\n1. @resident_jane: "Water rising fast on Oak Street. Entire first floor flooded. Need help! #downtownflood"\n   - Location confirmed\n   - Multiple corroborating reports\n   - Photos verified\n\n2. @local_news: "Live: Rescue boats deployed on Main Street. Multiple families being evacuated."\n   - Official news source\n   - Video footage verified\n   - Location matches emergency response data\n\n### Facebook\n- Community Group "Downtown Residents":\n  - Multiple reports of power outages in Riverside district\n  - Coordination of volunteer efforts at Community Center\n  - Photos of flooding at Central Park verified\n\n### Telegram\n- Emergency Channel Updates:\n  - Sandbag distribution at Fire Station 7\n  - Medical supply needs at Riverside Apartments\n  - Real-time flood level updates from residents\n\n## Warning Signals\n- Rising water levels reported in previously unaffected areas\n- Multiple requests for boat rescue\n- Reports of contaminated water',
            },
          },
        ],
        tooling: { type: "osint", provider: "anthropic" },
      },
      summary: {
        id: "summary",
        label: "Summary Key Events",
        description: "Aggregates and summarizes all collected information",
        minDuration: 8e3,
        maxDuration: 15e3,
        dependencies: [
          { nodeId: "partner", required: !0 },
          { nodeId: "calls", required: !0 },
          { nodeId: "social", required: !0 },
        ],
        inputMergeStrategy: "summarize",
        logsToOutput: [
          {
            id: 7,
            content: "OSINT Summary Generated",
            details: "Compiled emergency situation report from all OSINT sources",
            timestamp: "14:01:00",
            type: "agent-output",
            agent: { id: "summary-1", name: "Information Summarizer", type: "summarizer" },
            output: { type: "markdown", id: "osint-summary-001", location: "/outputs/summary/001" },
            expandable: !0,
            hash: "bak4a5k6e7d8",
          },
        ],
        outputs: [
          {
            id: "f303866d-d08a-48a7-81c3-c30486149d87",
            title: "Situation Summary",
            component: "markdown",
            params: {
              content:
                "# Comprehensive Situation Summary\n**Generated:** 15:00 EST, January 19, 2025\n\n## Current Emergency Status: CRITICAL\n\n### Flood Conditions\n- Downtown river district experiencing severe flooding\n- Water levels: 2-3 feet and rising\n- Rate of rise: ~2 inches per hour\n- Affected area: 12 square blocks\n\n### Impact Assessment\n1. Infrastructure\n   - Multiple roads impassable\n   - Bridge structural concerns\n   - Power outages affecting 300+ residences\n   - Communications systems stable\n\n2. Human Impact\n   - 45+ evacuation requests pending\n   - 25+ people requiring immediate assistance\n   - 3 medical emergencies reported\n   - No casualties reported\n\n3. Resource Deployment\n   - 3 EMS units active\n   - 2 rescue boats deployed\n   - Additional resources inbound\n   - Volunteer center established\n\n### Critical Needs\n- Additional water rescue teams\n- Emergency power generators\n- Medical supply distribution\n- Expanded evacuation capacity",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
      },
      remediate: {
        id: "remediate",
        label: "Validate PII protection measures",
        description: "GDPR Article 25 compliance checkpoint for data protection",
        minDuration: 2e3,
        maxDuration: 4e3,
        dependencies: [{ nodeId: "prioritize", required: !0 }],
        guardrails: { controlIds: ["ctrl-9"], checkOnStart: !0, checkOnComplete: !0 },
        alertConditions: {
          type: "data-protection",
          triggers: [
            "unprotected-pii-detected",
            "sensitive-data-exposure",
            "insufficient-encryption",
            "missing-data-minimization",
            "unauthorized-data-access",
          ],
        },
        logsToOutput: [],
      },
      "nemo-guardrail1": {
        id: "nemo-guardrail1",
        label: "Nemo Guardrail",
        description: "Analyzes risk factors and validates response necessity",
        minDuration: 3e3,
        maxDuration: 7e3,
        dependencies: [{ nodeId: "summary", required: !0 }],
        guardrails: { controlIds: ["ctrl-1", "ctrl-2", "ctrl-3"], checkOnComplete: !0 },
        tooling: { type: "llm", provider: "nemo" },
        logsToOutput: [
          {
            id: 8,
            content: "Nemo Guardrail Check Initiated",
            details: "Analyzing risk factors and validating response necessity",
            timestamp: "14:01:15",
            type: "info",
            agent: { id: "nemo-1", name: "Nemo Guardrail", type: "nemo-guardrail" },
            expandable: !0,
            hash: "bak9a0k1e2d3",
          },
        ],
        alertConditions: {
          type: "risk-level",
          threshold: 0.7,
          triggers: ["life-safety-risk", "misinformation-detected", "rapid-escalation"],
        },
        outputs: [],
      },
      prioritize: {
        id: "prioritize",
        label: "Prioritize event on need and impact",
        description: "Analyzes severity and determines response priorities",
        minDuration: 6e3,
        maxDuration: 12e3,
        dependencies: [
          { nodeId: "nemo-guardrail1", required: !0 },
          { nodeId: "analyze", required: !0 },
        ],
        inputMergeStrategy: "prioritize",
        outputs: [
          {
            id: "e5836695-f2d0-47f4-86e8-d0dbaae4031a",
            title: "Priority Risk Assessment",
            component: "riskAssesment",
            params: {
              content: {
                riskLevel: "CRITICAL",
                requiresOverride: !0,
                factors: [
                  { category: "Life Safety", level: "High", details: "Multiple active rescue operations required" },
                  { category: "Infrastructure", level: "Severe", details: "Critical systems compromised" },
                  { category: "Resource Capacity", level: "Strained", details: "Emergency services at 85% capacity" },
                ],
                recommendations: [
                  "Immediate evacuation of affected areas",
                  "Deploy all available rescue resources",
                  "Activate mutual aid agreements",
                ],
                validationStatus: "Verified by multiple sources",
              },
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 19,
            content: "Event Prioritization Complete",
            details: "Analyzed risk factors and determined response priorities",
            timestamp: "14:01:30",
            type: "agent-complete",
            agent: { id: "prioritize-1", name: "Event Prioritizer", type: "event-prioritizer" },
            output: { type: "report", id: "priority-report-001", location: "/outputs/priorities/001" },
            expandable: !0,
            hash: "bak2a3k4e5d6",
          },
        ],
      },
      reconfirm: {
        id: "reconfirm",
        label: "Grant AI-driven action in high-risk scenario",
        description: "Human approval checkpoint for high-risk scenarios",
        minDuration: 200,
        maxDuration: 1200,
        dependencies: [{ nodeId: "prioritize", required: !0 }],
        guardrails: { controlIds: ["ctrl-3"], checkOnStart: !0, checkOnComplete: !0 },
        alertConditions: {
          type: "risk-level",
          threshold: 0.8,
          triggers: ["high-risk-scenario", "human-life-risk", "misinformation-risk"],
        },
        logsToOutput: [],
      },
      plan: {
        id: "plan",
        label: "Establish the response plan",
        description: "Creates formal response plan documentation",
        minDuration: 8e3,
        maxDuration: 15e3,
        dependencies: [{ nodeId: "reconfirm", required: !0 }],
        outputs: [
          {
            id: "d22ec671-806a-4db2-8c60-f0f8754f9b7b",
            title: "Response Plan",
            component: "markdown",
            params: {
              content:
                "# Emergency Response Action Plan\n**Effective:** 15:15 EST, January 19, 2025\n\n## IMMEDIATE ACTIONS REQUIRED\n\n### 1. Priority Rescue Operations\n- Deploy all available water rescue teams to:\n  * 123 River Street (family with child)\n  * Riverside Apartments (medical emergency)\n  * Oak Street (multiple stranded residents)\n\n### 2. Infrastructure Security\n- Close Downtown Bridge to all traffic\n- Establish power restoration to critical facilities\n- Deploy emergency pumping stations\n\n### 3. Resource Allocation\n- Activate mutual aid agreements\n- Request state emergency resources\n- Establish emergency shelter at Community Center\n\n### 4. Medical Response\n- Set up medical triage at Fire Station 7\n- Coordinate hospital preparations\n- Deploy mobile medical units\n\n## Execution Timeline\n1. Hour 1: Initial rescue operations\n2. Hour 2: Infrastructure stabilization\n3. Hour 3: Shelter establishment\n4. Hour 4: Resource reallocation\n\n## Communication Protocols\n- Emergency broadcast every 30 minutes\n- Direct communication with rescue teams\n- Public updates via official channels",
            },
          },
        ],
        tooling: { type: "llm", provider: "anthropic" },
        logsToOutput: [
          {
            id: 11,
            content: "Response Plan Generated",
            details: "Comprehensive emergency response plan created",
            timestamp: "14:02:30",
            type: "agent-complete",
            agent: { id: "plan-1", name: "Response Plan Creator", type: "plan-creator" },
            output: { type: "report", id: "response-plan-001", location: "/outputs/plans/001" },
            expandable: !0,
            hash: "bak2a3k4e5d6",
          },
        ],
      },
      notify: {
        id: "notify",
        label: "Notify Investigators",
        description: "Dispatches notifications through multiple channels",
        minDuration: 5e3,
        maxDuration: 1e4,
        dependencies: [{ nodeId: "plan", required: !0 }],
        outputs: [
          {
            id: "108eb93a-071e-4407-8b78-a73aabd9e803",
            title: "First Responder Notifications",
            component: "toolNotify",
            params: {
              content: [
                {
                  timestamp: "15:20:00 EST",
                  recipient: "Fire Station 7",
                  status: "Delivered",
                  message: "Deploy water rescue teams to River Street",
                  response: "Acknowledged, teams deploying",
                },
                {
                  timestamp: "15:20:30 EST",
                  recipient: "EMS Central",
                  status: "Delivered",
                  message: "Medical emergency at Riverside Apartments",
                  response: "Units dispatched",
                },
                {
                  timestamp: "15:21:00 EST",
                  recipient: "Police Command",
                  status: "Delivered",
                  message: "Close Downtown Bridge immediately",
                  response: "Proceeding with closure",
                },
                {
                  timestamp: "15:21:30 EST",
                  recipient: "Emergency Management",
                  status: "Delivered",
                  message: "Activate emergency response plan",
                  response: "Plan activated, resources mobilizing",
                },
              ],
            },
          },
        ],
        tooling: { type: "notification", provider: "twilio" },
        logsToOutput: [
          {
            id: 12,
            content: "First Responder Notification Complete",
            details: "Successfully notified all emergency response units via Twilio and Apptek",
            timestamp: "14:03:00",
            type: "success",
            agent: { id: "notify-1", name: "First Responder Notifier", type: "responder-notifier" },
            metrics: {
              apiCalls: [
                { service: "twilio-api", duration: 800, status: 200 },
                { service: "apptek-api", duration: 600, status: 200 },
              ],
            },
            expandable: !0,
            hash: "bak7a8k9e0d1",
          },
        ],
      },
      end: {
        id: "end",
        label: "End",
        description: "Pipeline completion",
        minDuration: 1e3,
        maxDuration: 2e3,
        dependencies: [{ nodeId: "notify", required: !0 }],
        logsToOutput: [],
      },
    },
  },
  G = {
    status: "idle",
    nodes: Object.keys(F.nodes).reduce((e, t) => ({ ...e, [t]: { status: "idle", logs: [], outputs: [] } }), {}),
    activeGuardrail: null,
    userOverrides: [],
    userRemediations: [],
    metrics: { responseTime: 0, riskLevel: "low", activeIncidents: 0 },
    stats: { totalNodes: Object.keys(F.nodes).length, completedNodes: 0, failedNodes: 0, blockedNodes: 0 },
  },
  q = l(void 0);
function B({ children: e }) {
  const [a, r] = i(O, G),
    n = o(() => new Z(F, r), []),
    l = s(() => {
      "running" !== a.status &&
        (("idle" !== a.status && "completed" !== a.status && "cancelled" !== a.status) || r({ type: "START_PIPELINE" }),
        n.start());
    }, [a.status, n]),
    c = s(() => {
      "running" === a.status && r({ type: "PAUSE_PIPELINE" });
    }, [a.status]),
    d = s(() => {
      ("running" !== a.status && "paused" !== a.status) || r({ type: "CANCEL_PIPELINE" });
    }, [a.status]),
    m = s((e, t) => {
      r({ type: "OVERRIDE_GUARDRAIL", payload: { alertId: e, reason: t, timestamp: Date.now() } });
    }, []),
    w = s((e, t) => {
      r({ type: "REMEDIATE_GUARDRAIL", payload: { alertId: e, reason: t, timestamp: Date.now() } });
    }, []),
    p = o(
      () => ({
        state: a,
        startPipeline: l,
        pausePipeline: c,
        cancelPipeline: d,
        overrideGuardrail: m,
        remediateGuardrail: w,
      }),
      [a, l, c, d, m, w]
    );
  return t.createElement(q.Provider, { value: p }, e);
}
function U() {
  const e = c(q);
  if (void 0 === e) throw new Error("usePipeline must be used within a PipelineProvider");
  return e;
}
const $ = ({ data: e, onControlClick: a }) => {
    const { state: r } = U(),
      n = 0 === r.userOverrides.length,
      l = 0 === r.userRemediations.length;
    return t.createElement(
      t.Fragment,
      null,
      e.map((e) => {
        let r =
          "tw-px-2 tw-py-1 tw-rounded-lg tw-cursor-pointer tw-transition-colors tw-max-w-[200px] tw-flex tw-items-center tw-relative";
        return (
          e.isAlert && "ctrl-3" === e.id && n
            ? (r += " tw-border !tw-border-brandreddark tw-bg-brandred")
            : e.isAlert && "ctrl-3" === e.id && !n
              ? (r += " tw-border !tw-border-brandgreen tw-bg-brandgreen tw-text-branddialogbg")
              : e.isAlert && "ctrl-9" === e.id && l
                ? (r += " tw-border !tw-border-brandreddark tw-bg-brandred")
                : e.isAlert && "ctrl-9" === e.id && !l
                  ? (r += " tw-border !tw-border-brandgreen tw-bg-brandgreen tw-text-branddialogbg")
                  : e.mandatory && e.implemented
                    ? (r += " tw-border !tw-border-brandblue ")
                    : e.mandatory
                      ? (r += " tw-border !tw-border-red-600 tw-text-red-200")
                      : (r += " tw-border !tw-border-brandgray "),
          t.createElement(
            "div",
            { key: e.id, className: "tw-relative" },
            t.createElement(
              "div",
              {
                className: r,
                onClick: () => {
                  a(e);
                },
              },
              e.title
            ),
            e.isAlert &&
              "ctrl-3" === e.id &&
              n &&
              t.createElement(
                "div",
                {
                  id: `${e.id}-item-wrapper`,
                  className: "tw-absolute tw-inset-0 tw-z-0 tw-pointer-events-none",
                  style: { overflow: "visible" },
                },
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-delayed tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-more-delayed tw-opacity-40",
                })
              ),
            e.isAlert &&
              "ctrl-9" === e.id &&
              l &&
              t.createElement(
                "div",
                {
                  id: `${e.id}-item-wrapper`,
                  className: "tw-absolute tw-inset-0 tw-z-0 tw-pointer-events-none",
                  style: { overflow: "visible" },
                },
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-delayed tw-opacity-40",
                }),
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-0 tw-rounded-lg tw-border !tw-border-brandreddark animate-sonar-more-delayed tw-opacity-40",
                })
              )
          )
        );
      })
    );
  },
  j = ({ data: e, onControlClick: a }) =>
    t.createElement(
      "div",
      { className: "tw-text-white tw-flex-col tw-flex tw-items-center tw-overflow-x-visible" },
      t.createElement("h2", { className: "tw-text-[18px] tw-mb-4 tw-font-[500] tw-w-[200px]" }, "Active Policies"),
      t.createElement(
        "div",
        {
          className:
            "tw-flex tw-flex-col tw-gap-3 tw-font-[400] tw-text-[14.5px]  tw-h-[90%] tw-pb-14 tw-scroll-smooth\ttw-scrollbar-hidden",
          style: { overflowX: "visible" },
        },
        t.createElement($, { data: e, onControlClick: a })
      )
    ),
  Y = () =>
    t.createElement(
      "svg",
      {
        className: "agent-icon",
        width: "20",
        height: "20",
        viewBox: "0 0 20 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement("path", {
        d: "M7.5 9.97414V4.16705C7.5 3.50401 7.76339 2.86813 8.23223 2.39929C8.70107 1.93045 9.33696 1.66705 10 1.66705C10.663 1.66705 11.2989 1.93045 11.7678 2.39929C12.2366 2.86813 12.5 3.50401 12.5 4.16705V5.00289M12.5 10.0016V15.8337C12.5 16.4968 12.2366 17.1326 11.7678 17.6015C11.2989 18.0703 10.663 18.3337 10 18.3337C9.33696 18.3337 8.70107 18.0703 8.23223 17.6015C7.76339 17.1326 7.5 16.4968 7.5 15.8337V14.9879",
        stroke: "rgb(13,14,15)",
        strokeLinecap: "round",
      }),
      t.createElement("path", {
        d: "M9.99935 12.5001H4.15935C2.78268 12.5001 1.66602 11.3809 1.66602 10.0001C1.66602 8.61923 2.78268 7.50006 4.15935 7.50006H4.99477M9.99935 7.50006H15.8281C16.4917 7.49951 17.1284 7.76258 17.5981 8.23141C18.0678 8.70024 18.332 9.33643 18.3327 10.0001C18.3327 11.3809 17.2114 12.5001 15.8281 12.5001H15.0268",
        stroke: "rgb(13,14,15)",
        strokeLinecap: "round",
      })
    ),
  W = () =>
    t.createElement(
      "svg",
      {
        id: "Layer_1",
        "data-name": "Layer 1",
        xmlns: "http://www.w3.org/2000/svg",
        version: "1.1",
        viewBox: "0 0 48 48",
      },
      t.createElement("path", {
        fill: "#ffffff",
        strokeWidth: 0,
        d: "M24,6.4L7.4,14.7l6.2,21.6,10.4,5.2,10.4-5.2,6.2-21.6L24,6.4ZM33.6,35.7l-9.6,4.8-9.6-4.8-5.8-20.4,15.4-7.7,15.4,7.7-5.8,20.4Z",
      }),
      t.createElement("path", {
        fill: "#ffffff",
        strokeWidth: 0,
        d: "M30.5,22.7c1.1,0,2-.9,2-2s-.9-2-2-2-1.1.3-1.5.7l-3.2-1.6c0-.1,0-.3,0-.4,0-1.1-.9-2-2-2s-2,.9-2,2,0,.3,0,.4l-3.2,1.6c-.4-.4-.9-.6-1.4-.6-1.1,0-2,.9-2,2s.9,2,2,2,.4,0,.7-.1l.9,1.4-1,1.4c-.2,0-.4-.1-.6-.1-1.1,0-2,.9-2,2s.9,2,2,2,1.1-.3,1.5-.7l3.2,1.6c0,.1,0,.3,0,.4,0,1.1.9,2,2,2s2-.9,2-2,0-.3,0-.4l3.2-1.6c.4.4.9.7,1.5.7,1.1,0,2-.9,2-2s-.9-2-2-2-.4,0-.6.1l-1-1.4,1-1.4c.2,0,.4.1.6.1ZM23.2,24.5s0,0-.1-.1h0c0-.1,0-.3,0-.4,0-.5.4-1,1-1s1,.4,1,1,0,.2,0,.4h0c0,0,0,.1-.1.2-.4.5-1.2.5-1.5,0ZM24.6,19.3l1.9,2.9-1.1.5c-.3-.3-.6-.5-1-.6v-2.8s0,0,.1,0ZM23.5,22.1c-.4.1-.7.3-1,.6l-1.1-.5,1.9-2.9s0,0,.1,0v2.8ZM20.9,25l-.7-1,.7-1,1.2.6c0,.1,0,.3,0,.4s0,.3,0,.4l-.9.4-.3.2ZM25.9,24.4c0-.1,0-.3,0-.4s0-.3,0-.4l1.2-.6.7,1-.7,1-1.2-.6ZM21.5,25.8h.2c0,0,.9-.5.9-.5,0,0,0,0,0,0,.2.3.6.5.9.6v2.8s0,0,0,0c0,0,0,0,0,0l-1.9-2.9ZM24.6,28.7s0,0,0,0c0,0,0,0,0,0v-2.8c.4,0,.7-.3.9-.6,0,0,0,0,0,0l1.1.5-1.9,2.9ZM30.5,19.8c.5,0,1,.4,1,1s-.4,1-1,1-1-.4-1-1,.4-1,1-1ZM28.6,21.1l-1.2.6-2-3,3.2,1.6c0,.1,0,.3,0,.4s0,.3,0,.4ZM24,16.5c.5,0,1,.4,1,1s-.4,1-1,1-1-.4-1-1,.4-1,1-1ZM22.5,18.7l-2,3-1.2-.6c0-.1,0-.2,0-.4s0-.3,0-.4l3.2-1.6ZM16.5,20.8c0-.5.4-1,1-1s1,.4,1,1-.4,1-1,1-1-.4-1-1ZM18.9,22s0,0,0,0l1.1.5-.4.5-.7-1.1ZM19.6,24.9l.4.5-1.1.5.7-1.1ZM16.5,27.3c0-.5.4-1,1-1s.7.2.9.5c0,.1.1.3.1.4,0,.1,0,.3-.1.4-.2.3-.5.5-.9.5s-1-.4-1-1ZM19.4,27.3h0c0-.1,0-.3,0-.4l1.2-.6,2,3h0s-3.2-1.6-3.2-1.6c0-.1,0-.3,0-.4ZM24,31.5c-.5,0-1-.4-1-1s0-.2,0-.4h0c0-.1.1-.2.2-.3,0,0,0,0,0,0,0,0,.1,0,.2-.1,0,0,0,0,.1,0,0,0,.2,0,.3,0,0,0,0,0,.1,0,0,0,.2,0,.3,0,0,0,0,0,.1,0,0,0,.1,0,.2.1,0,0,0,0,0,0,0,0,.1.2.2.3h0c0,.1,0,.3,0,.4,0,.5-.4,1-1,1ZM25.5,29.3h0s2-3,2-3l1.2.6c0,.1,0,.3,0,.4h0c0,.1,0,.3,0,.4l-3.2,1.6ZM31.5,27.3c0,.5-.4,1-1,1s-.7-.2-.9-.5c0-.1-.1-.3-.1-.4,0-.1,0-.3.1-.4.2-.3.5-.5.9-.5s1,.4,1,1ZM29.1,26l-1.1-.5.4-.5.7,1.1ZM28,22.6l1.1-.5-.7,1.1-.4-.5Z",
      }),
      t.createElement("path", { fill: "#ffffff", strokeWidth: 0, d: "M19,34.9v1.1l5,2.5,5-2.5v-1.1l-5,2.5-5-2.5Z" }),
      t.createElement("path", { fill: "#ffffff", strokeWidth: 0, d: "M32,14.6v-1.1l-8-4-8,4v1.1l8-4,8,4Z" })
    ),
  K = ({ title: e, subline: a, position: r = "top", type: n = "default", resolved: l = !1 }) => {
    let i = `tw-absolute tw-whitespace-nowrap ${{ top: "tw--top-10 tw-left-1/2 tw--translate-x-1/2", right: "tw-top-1/2 tw--translate-y-1/2 tw-left-full tw-ml-2", bottom: "tw-top-full tw-left-1/2 tw--translate-x-1/2 tw-mt-2", left: "tw-top-1/2 tw--translate-y-1/2 tw-right-full tw-mr-4" }[r]} !tw-border-brandbordergray tw-border tw-rounded-xl tw-p-1`;
    return (
      (i +=
        "alert" !== n || l
          ? "alert" === n && l
            ? " tw-bg-brandgreen !tw-border-brandgreen tw-text-branddialogbg"
            : " tw-text-white"
          : " tw-bg-brandred !tw-border-brandred tw-text-white"),
      t.createElement(
        "div",
        { className: `${i}` },
        t.createElement("div", { className: "tw-text-[14px]" }, e),
        a && t.createElement("div", { className: " tw-text-[10px]" }, a)
      )
    );
  };
var X = d(({ data: e }) => {
  const a = (e) => {
    if (!e) return {};
    switch (e) {
      case "running":
        return { background: "rgba(0, 157, 255, 0.15)", animation: "node-pulse 2s ease-in-out infinite" };
      case "completed":
        return { background: "rgba(39, 174, 96, 0.2)", boxShadow: "0 0 15px rgba(39, 174, 96, 0.5)" };
      case "error":
        return { background: "rgba(255, 0, 0, 0.2)", boxShadow: "0 0 15px rgba(255, 0, 0, 0.5)" };
      default:
        return { background: "rgba(255, 255, 255, 0.1)", opacity: 0.5 };
    }
  };
  if (!e.hide)
    return e.type && "policy-alert" === e.type
      ? t.createElement(
          "div",
          { className: "wrapper wrapper-alert" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-justify-center tw-relative tw-w-full" },
            t.createElement("div", {
              className: "tw-absolute tw-w-full tw-h-px ",
              style: {
                background: e.resolved
                  ? "repeating-linear-gradient(to right, rgb(206, 255, 220) 0, rgb(206, 255, 220) 4px, transparent 4px, transparent 8px)"
                  : "repeating-linear-gradient(to right, rgba(208, 86, 89, 1) 0, rgba(208, 86, 89, 1) 4px, transparent 4px, transparent 8px)",
                backgroundSize: "8px 100%",
                backgroundPosition: "6px 0",
              },
            }),
            t.createElement(
              "div",
              { className: "tw-absolute ripple-wrapper" },
              t.createElement(
                "div",
                {
                  id: e.animating ? `ripple-point-eq-${e.controlId}` : "",
                  className:
                    "tw-w-4 tw-h-4 tw-bg-brandalert tw-rounded-full tw-m-auto tw-relative data-[eqalertoverride='true']:tw-bg-brandgreen",
                },
                e.animating &&
                  t.createElement(
                    t.Fragment,
                    null,
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full tw-bg-brandalert animate-ripple ",
                      style: { opacity: "0.75" },
                    }),
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full tw-bg-brandalert animate-ripple-delayed ",
                      style: { opacity: "0.75" },
                    }),
                    t.createElement("div", {
                      className:
                        "tw-absolute tw-inset-0 tw-w-4 tw-h-4 tw-rounded-full tw-bg-brandalert animate-ripple-more-delayed ",
                      style: { opacity: "0.75" },
                    })
                  )
              )
            )
          ),
          e.title &&
            t.createElement(K, {
              title: e.title,
              subline: e.subline,
              position: e.labelPosition,
              resolved: e.resolved,
              type: "alert",
            })
        )
      : e.type && "nemo-guardrail" === e.type
        ? t.createElement(
            "div",
            { className: "wrapper tw-justify-center tw-items-center", style: a(e.status) },
            t.createElement(
              "div",
              { className: " tw-w-9 tw-h-9 tw-rounded-full" },
              t.createElement(W, null),
              t.createElement(p, { type: "target", position: u.Left }),
              t.createElement(p, { type: "source", position: u.Right }),
              t.createElement(p, { id: "sourcetop", type: "source", position: u.Top }),
              t.createElement(p, { id: "targetbottom", type: "target", position: u.Bottom })
            ),
            e.title && t.createElement(K, { title: e.title, subline: e.subline, position: e.labelPosition })
          )
        : t.createElement(
            t.Fragment,
            null,
            t.createElement(
              "div",
              { className: (e.parallelVertSize ? "wrapper-half" : "wrapper") + " tw-relative", style: a(e.status) },
              "running" === e.status &&
                t.createElement("div", {
                  className:
                    "tw-absolute tw-inset-[-2px] tw-rounded-full tw-border-2 tw-border-transparent tw-border-t-blue-400",
                  style: { animation: "rotate-ring 1s linear infinite" },
                }),
              t.createElement(
                "div",
                { className: "inner" },
                t.createElement(Y, null),
                t.createElement(p, { type: "target", position: u.Left }),
                t.createElement(p, { type: "source", position: u.Right }),
                t.createElement(p, { id: "sourcetop", type: "source", position: u.Top }),
                t.createElement(p, { id: "targetbottom", type: "target", position: u.Bottom })
              ),
              e.title && t.createElement(K, { title: e.title, subline: e.subline, position: e.labelPosition })
            )
          );
});
const J = [
    { id: "start", position: { x: 50, y: 600 }, data: { title: "OSINT Feed", labelPosition: "bottom" }, type: "turbo" },
    {
      id: "partner",
      position: { x: 225, y: 525 },
      data: {
        title: "Twitter",
        labelPosition: "top",
        parallelVertSize: !0,
        role: "Partner Report Analyzer",
        backstory:
          "You are an agent dedicated to monitoring and analyzing reports from local EMS stations and fire departments. You understand emergency service protocols and can identify critical patterns in first responder reports.",
        goal: "Collect and analyze reports from local EMS stations, identifying key information relevant to flooding disasters",
      },
      type: "turbo",
    },
    {
      id: "calls",
      position: { x: 225, y: 600 },
      data: {
        title: "Calls for service",
        labelPosition: "top",
        parallelVertSize: !0,
        role: "Service Call Analyzer",
        backstory:
          "You are a specialized agent that monitors dispatch logs and analyzes emergency call patterns. You can detect anomalies in call frequencies and understand the significance of different types of emergency calls.",
        goal: "Parse local dispatch logs, monitor call frequencies, and detect anomaly patterns that might indicate escalating emergencies",
      },
      type: "turbo",
    },
    {
      id: "social",
      position: { x: 225, y: 675 },
      data: {
        title: "Telegram",
        labelPosition: "top",
        parallelVertSize: !0,
        role: "Social Media Monitor",
        backstory:
          "You are an agent skilled in monitoring social media platforms for emergency-related content. You can filter through Twitter, Facebook, and Telegram to identify genuine distress calls and emergency situations.",
        goal: "Monitor social media feeds for distress calls and emergency situations, filtering out noise to identify genuine calls for help",
      },
      type: "turbo",
    },
    {
      id: "video",
      position: { x: 100, y: 425 },
      data: {
        title: "Other Social Media",
        labelPosition: "top",
        role: "Video Feed Collector",
        backstory:
          "You are a specialized agent that interfaces with surveillance systems to gather real-time video footage during emergency situations. You understand how to efficiently collect and stream video data from multiple sources.",
        goal: "Collect and process video feeds from surveillance systems, ensuring high-quality footage is captured for analysis",
      },
      type: "turbo",
    },
    {
      id: "analyze",
      position: { x: 250, y: 425 },
      data: {
        title: "Analyze Footage",
        labelPosition: "top",
        role: "Video Analyzer",
        backstory:
          "You are an advanced NVIDIA mixed-modal LLM specializing in analyzing video content for emergency situations. You can identify critical visual elements, patterns, and events from surveillance footage.",
        goal: "Analyze video footage using mixed-modal techniques to identify and report on key events, people, objects, and potential hazards",
      },
      type: "turbo",
    },
    {
      id: "summary",
      position: { x: 450, y: 600 },
      data: {
        title: "Summary Key Events:",
        subline: "People, Object, Location, Event",
        labelPosition: "bottom",
        role: "Information Summarizer",
        backstory:
          "You are an expert in synthesizing information from multiple sources. You can take inputs from OSINT collection agents and create coherent, actionable summaries of emergency situations.",
        goal: "Create comprehensive summaries of key events by aggregating information from all OSINT sources and video analysis",
      },
      type: "turbo",
    },
    {
      id: "remediate",
      position: { x: 450, y: 525 },
      data: {
        controlId: "ctrl-9",
        title: "Validate PII protection measures",
        type: "policy-alert",
        animating: !0,
        labelPosition: "right",
        role: "GDPR Data Protection Protocol - Remediation Required",
        backstory:
          "Mandatory data protection checkpoint due to GDPR Article 25 requirements. System detected potential exposure of personal data in emergency response feeds, including unprotected social media content and victim location data.",
        goal: "Ensure appropriate technical measures are in place to protect personal data before processing emergency response information",
      },
      type: "turbo",
    },
    {
      id: "nemo-guardrail1",
      position: { x: 450, y: 525 },
      data: {
        hide: !0,
        title: "Nemo Guardrail",
        labelPosition: "right",
        type: "nemo-guardrail",
        role: "Nemo Guardrail",
        backstory:
          "You are a specialized safety system that analyzes risk factors and validates response necessity. You ensure all actions comply with safety protocols and ethical guidelines.",
        goal: "Analyze summaries for risk factors and validate whether emergency response is necessary, checking for potential misinformation or ethical concerns",
      },
      type: "turbo",
    },
    {
      id: "prioritize",
      position: { x: 450, y: 425 },
      data: {
        title: "Estimate Veracity",
        labelPosition: "right",
        role: "Event Prioritizer",
        backstory:
          "You are an expert in emergency triage, capable of analyzing multiple incidents and determining their relative priority based on need and potential impact.",
        goal: "Analyze severity of situations and determine response priorities, creating tactical approaches for first responders",
      },
      type: "turbo",
    },
    {
      id: "reconfirm",
      position: { x: 450, y: 350 },
      data: {
        controlId: "ctrl-3",
        title: "Grant AI-driven action in high-risk scenario",
        type: "policy-alert",
        animating: !0,
        labelPosition: "right",
        role: "Sourcing Protocol - Human Authorization",
        backstory:
          "Mandatory authorization checkpoint for AI systems making life-critical prioritization decisions in disaster response, particularly when influenced by social media signals. Flagged due to algorithmic triage of human rescue priorities.",
        goal: "Ensure human oversight of AI emergency response systems through explicit authorization protocols before deployment of rescue resources",
      },
      type: "turbo",
    },
    {
      id: "plan",
      position: { x: 450, y: 275 },
      data: {
        title: "Generate Alert",
        labelPosition: "right",
        role: "Response Plan Creator",
        backstory:
          "You are an expert in emergency response planning, capable of creating detailed, actionable response plans that incorporate all gathered intelligence and priorities.",
        goal: "Create formal, comprehensive response plans that include tactical approaches and clear instructions for first responders",
      },
      type: "turbo",
    },
    {
      id: "notify",
      position: { x: 450, y: 175 },
      data: {
        title: "Send Alert to Investigators",
        labelPosition: "top",
        role: "First Responder Notifier",
        backstory:
          "You are responsible for ensuring emergency information reaches first responders quickly and effectively. You can utilize multiple communication channels including Twilio and Apptek.",
        goal: "Dispatch notifications through multiple channels to first responders, ensuring critical information is delivered effectively",
      },
      type: "turbo",
    },
    {
      id: "end",
      position: { x: 600, y: 175 },
      data: { title: "Summary Threat Report", labelPosition: "right" },
      type: "turbo",
    },
  ],
  Q = [
    { id: "e-start-partner", source: "start", target: "partner" },
    { id: "e-start-calls", source: "start", target: "calls" },
    { id: "e-start-social", source: "start", target: "social" },
    { id: "e-partner-summary", source: "partner", target: "summary" },
    { id: "e-calls-summary", source: "calls", target: "summary" },
    { id: "e-social-summary", source: "social", target: "summary" },
    { id: "e-video-analyze", source: "video", target: "analyze" },
    { id: "e-analyze-prioritize", source: "analyze", target: "prioritize" },
    {
      id: "e-summary-prioritize",
      source: "summary",
      target: "prioritize",
      sourceHandle: "sourcetop",
      targetHandle: "targetbottom",
    },
    {
      id: "e-prioritize-plan",
      source: "prioritize",
      target: "plan",
      sourceHandle: "sourcetop",
      targetHandle: "targetbottom",
    },
    { id: "e-plan-notify", source: "plan", target: "notify", sourceHandle: "sourcetop", targetHandle: "targetbottom" },
    { id: "e-notify-end", source: "notify", target: "end" },
  ],
  ee = { turbo: X },
  te = {
    turbo: function ({
      id: e,
      sourceX: a,
      sourceY: r,
      targetX: n,
      targetY: l,
      sourcePosition: i,
      targetPosition: o,
      style: s = {},
      markerEnd: c,
    }) {
      const d = a === n,
        m = r === l,
        [w] = g({
          sourceX: d ? a + 1e-4 : a,
          sourceY: m ? r + 1e-4 : r,
          sourcePosition: i,
          targetX: n,
          targetY: l,
          targetPosition: o,
        });
      return t.createElement(
        t.Fragment,
        null,
        t.createElement("path", { id: e, style: s, className: "react-flow__edge-path", d: w, markerEnd: c })
      );
    },
  },
  ae = { type: "turbo", markerEnd: "edge-circle" },
  re = ({ visible: e, content: a, position: r }) =>
    e
      ? a.isAlert
        ? t.createElement(
            "div",
            { style: { position: "absolute", left: r.x, top: r.y, zIndex: 99999 }, className: "tw-animate-fadeIn" },
            t.createElement(
              "div",
              {
                className:
                  "tw-bg-[#09090B]/95 tw-backdrop-blur-sm tw-border !tw-border-white/10 tw-rounded-lg tw-p-4 tw-w-[320px]",
              },
              t.createElement(
                "div",
                { className: "tw-flex tw-items-start tw-gap-3 tw-mb-3" },
                t.createElement(
                  "div",
                  null,
                  t.createElement(
                    "h3",
                    { className: "tw-text-white tw-text-sm tw-font-medium" },
                    "Authorization Required"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-gap-2 tw-mt-1" },
                    t.createElement(
                      "span",
                      {
                        className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-amber-500/10 tw-text-amber-400 tw-rounded",
                      },
                      "Auth Gate"
                    ),
                    t.createElement(
                      "span",
                      { className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-red-500/10 tw-text-red-400 tw-rounded" },
                      "Pending"
                    ),
                    t.createElement(
                      "span",
                      {
                        className:
                          "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-white/5 tw-text-white/60 tw-font-mono tw-rounded",
                      },
                      "GATE_ID: bak3f...a92d"
                    )
                  )
                )
              ),
              t.createElement(
                "div",
                { className: "tw-space-y-3" },
                t.createElement(
                  "div",
                  { className: "tw-p-2 tw-rounded-lg tw-bg-amber-500/[0.03] tw-border !tw-border-amber-500/10" },
                  t.createElement(
                    "div",
                    { className: "tw-text-xs tw-text-amber-400 tw-mb-1" },
                    "Critical System Notice"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-text-sm tw-text-white/90" },
                    "AI system requires authorization for emergency response prioritization. Social media data integration may influence rescue priority decisions."
                  )
                ),
                t.createElement(
                  "div",
                  { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                  t.createElement(
                    "div",
                    { className: "tw-text-xs tw-text-white/60 tw-mb-1" },
                    "Authorization Protocol"
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-text-sm tw-text-white/90" },
                    "Human verification required for AI-driven emergency response system. Confirm implementation of safety controls before authorizing deployment."
                  )
                )
              )
            ),
            t.createElement(
              "style",
              null,
              "\n            @keyframes fadeIn {\n              from { opacity: 0; transform: translateY(-8px); }\n              to { opacity: 1; transform: translateY(0); }\n            }\n            .tw-animate-fadeIn {\n              animation: fadeIn 0.2s ease-out forwards;\n            }\n          "
            )
          )
        : t.createElement(
            "div",
            { style: { position: "absolute", left: r.x, top: r.y, zIndex: 99999 }, className: "tw-animate-fadeIn" },
            t.createElement(
              "div",
              {
                className:
                  "tw-bg-[#09090B]/95 tw-backdrop-blur-sm tw-border !tw-border-white/10 tw-rounded-lg tw-p-4 tw-w-[320px]",
              },
              a.role &&
                t.createElement(
                  "div",
                  { className: "tw-flex tw-items-start tw-gap-3 tw-mb-3" },
                  t.createElement(
                    "div",
                    null,
                    t.createElement("h3", { className: "tw-text-white tw-text-sm tw-font-medium" }, a.role),
                    t.createElement(
                      "div",
                      { className: "tw-flex tw-gap-2 tw-mt-1" },
                      t.createElement(
                        "span",
                        { className: "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-white/5 tw-text-white/60 tw-rounded" },
                        "Agent Node"
                      ),
                      t.createElement(
                        "span",
                        {
                          className:
                            "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-green-500/10 tw-text-green-400 tw-rounded",
                        },
                        "Active"
                      ),
                      t.createElement(
                        "span",
                        {
                          className:
                            "tw-px-1.5 tw-py-0.5 tw-text-[10px] tw-bg-purple-500/10 tw-text-purple-400 tw-font-mono tw-rounded",
                        },
                        "bak3f...a92d"
                      )
                    )
                  )
                ),
              t.createElement(
                "div",
                { className: "tw-space-y-3" },
                a.backstory &&
                  t.createElement(
                    "div",
                    { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                    t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Backstory"),
                    t.createElement("div", { className: "tw-text-sm tw-text-white/90" }, a.backstory)
                  ),
                a.goal &&
                  t.createElement(
                    "div",
                    { className: "tw-p-2 tw-rounded-lg tw-bg-white/[0.03] tw-border !tw-border-white/10" },
                    t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Primary Goal"),
                    t.createElement("div", { className: "tw-text-sm tw-text-white/90" }, a.goal)
                  )
              )
            ),
            t.createElement(
              "style",
              null,
              "\n        @keyframes fadeIn {\n          from { opacity: 0; transform: translateY(-8px); }\n          to { opacity: 1; transform: translateY(0); }\n        }\n        .tw-animate-fadeIn {\n          animation: fadeIn 0.2s ease-out forwards;\n        }\n      "
            )
          )
      : null,
  ne = ({ backgroundColor: e, textColor: a, onNodeClick: l = () => {} }) => {
    const i = e || "transparent",
      o = a || "rgb(243, 244, 246)",
      [c, d] = r({ visible: !1, content: {}, position: { x: 0, y: 0 } }),
      { state: m } = U(),
      [w, p, u] = h(J),
      [g, b, v] = f(Q);
    (n(() => {
      p((e) =>
        e.map((e) => ({
          ...e,
          data: {
            ...e.data,
            status: m.nodes[e.id]?.status || "idle",
            animating:
              ("reconfirm" === e.id && 0 === m.userOverrides.length) ||
              ("remediate" === e.id && 0 === m.userRemediations.length),
            resolved:
              ("reconfirm" === e.id && m.userOverrides.length > 0) ||
              ("remediate" === e.id && m.userRemediations.length > 0),
            hide:
              ("nemo-guardrail1" === e.id && 0 === m.userRemediations.length) ||
              ("remediate" === e.id && m.userRemediations.length > 0),
          },
        }))
      );
    }, [m, p]),
      n(() => {
        b((e) =>
          e.map((e) => {
            const t = m.nodes[e.source],
              a = m.nodes[e.target],
              r = "running" === t?.status,
              n =
                "idle" === a?.status
                  ? { opacity: 0.2, stroke: "rgb(222, 222, 222)" }
                  : { opacity: 1, stroke: "rgb(222, 222, 222)" };
            return { ...e, animated: r, style: n };
          })
        );
      }, [m, b]));
    const y = s((e) => b((t) => E(e, t)), []),
      [C, N] = r(null),
      k = s(() => {
        if (!C || !w?.length) return;
        C.fitView({ padding: 0.22 });
        const { x: e, y: t, zoom: a } = C.getViewport();
        C.setViewport({ x: e - 50, y: t + 10, zoom: a });
      }, [C, w]);
    (n(() => {
      (k(), d((e) => ({ visible: !1, content: {}, position: { x: 0, y: 0 } })));
    }, [k]),
      n(() => {
        const e = () => k();
        return (
          window.addEventListener("resize", e),
          () => {
            window.removeEventListener("resize", e);
          }
        );
      }, [k]));
    return t.createElement(
      t.Fragment,
      null,
      t.createElement(
        x,
        {
          style: { backgroundColor: i, color: o, position: "relative" },
          nodes: w,
          edges: g,
          onNodesChange: u,
          onEdgesChange: v,
          onConnect: y,
          nodeTypes: ee,
          edgeTypes: te,
          onInit: (e) => {
            N(e);
          },
          defaultEdgeOptions: ae,
          proOptions: { hideAttribution: !0 },
          onNodeClick: (e, t) => {
            l(t);
          },
          onNodeMouseEnter: (e, t) => {
            if (t.data?.role) {
              const a = document.querySelector(".react-flow");
              if (!a) return;
              const r = a.getBoundingClientRect(),
                n = e.target.getBoundingClientRect(),
                l = 320,
                i = 300,
                o = 32,
                s = n.top + n.height / 2;
              let c;
              c =
                r.right - n.right >= l + o
                  ? n.right - r.left + o
                  : n.left - r.left >= l + o
                    ? n.left - r.left - l - o
                    : Math.max(o, Math.min(r.width - l - o, n.left - r.left - l / 2));
              let m = s - r.top - i / 2;
              const w = o,
                p = r.height - i - 2 * o;
              ((m = Math.max(w, Math.min(m, p))),
                d({
                  visible: !0,
                  content: {
                    role: t.data.role,
                    backstory: t.data.backstory,
                    goal: t.data.goal,
                    isAlert: "reconfirm" === t.id || "remediate" === t.id,
                  },
                  position: { x: c, y: m },
                }));
            }
          },
          onNodeMouseLeave: () => {
            d((e) => ({ ...e, visible: !1 }));
          },
        },
        t.createElement(
          "svg",
          null,
          t.createElement(
            "defs",
            null,
            t.createElement(
              "marker",
              {
                id: "edge-circle",
                viewBox: "-5 -5 10 10",
                refX: "0",
                refY: "0",
                markerUnits: "strokeWidth",
                markerWidth: "10",
                markerHeight: "10",
                orient: "auto",
              },
              t.createElement("circle", { fill: "rgba(22, 189, 202, 1)", r: "2", cx: "0", cy: "0" })
            ),
            t.createElement(
              "symbol",
              { id: "agent-icon", viewBox: "0 0 20 20" },
              t.createElement("path", {
                d: "M7.5 9.97414V4.16705C7.5 3.50401 7.76339 2.86813 8.23223 2.39929C8.70107 1.93045 9.33696 1.66705 10 1.66705C10.663 1.66705 11.2989 1.93045 11.7678 2.39929C12.2366 2.86813 12.5 3.50401 12.5 4.16705V5.00289M12.5 10.0016V15.8337C12.5 16.4968 12.2366 17.1326 11.7678 17.6015C11.2989 18.0703 10.663 18.3337 10 18.3337C9.33696 18.3337 8.70107 18.0703 8.23223 17.6015C7.76339 17.1326 7.5 16.4968 7.5 15.8337V14.9879",
                stroke: "white",
                strokeLinecap: "round",
              }),
              t.createElement("path", {
                d: "M9.99935 12.5001H4.15935C2.78268 12.5001 1.66602 11.3809 1.66602 10.0001C1.66602 8.61923 2.78268 7.50006 4.15935 7.50006H4.99477M9.99935 7.50006H15.8281C16.4917 7.49951 17.1284 7.76258 17.5981 8.23141C18.0678 8.70024 18.332 9.33643 18.3327 10.0001C18.3327 11.3809 17.2114 12.5001 15.8281 12.5001H15.0268",
                stroke: "white",
                strokeLinecap: "round",
              })
            )
          )
        ),
        t.createElement(re, { visible: c.visible, content: c.content, position: c.position })
      )
    );
  },
  le = ({ control: e, onOverride: a, onCancel: r, onDetails: n }) => {
    const l = "authorize" === e.alertType;
    return t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full" },
      t.createElement(
        "div",
        { className: "tw-rounded-xl tw-bg-branddialogbg tw-p-6 tw-max-w-[258px] tw-space-y-6 mt-3" },
        t.createElement(
          "div",
          {
            id: "eq-control-dialog",
            className: `tw-inline-block ${l ? "tw-bg-permission-gradient" : "tw-bg-red-500/20"} tw-text-white tw-rounded-lg tw-px-4 tw-py-2 tw-text-xs`,
          },
          l ? "Permissions needed" : "Remediation required"
        ),
        t.createElement(
          "p",
          { className: "tw-text-white tw-text-base" },
          l
            ? "This workflow is non-compliant without human authorization of multiple Sourcing Protocol controls."
            : "This workflow cannot proceed due to GDPR Article 25 (Data Protection by Design) requirements. Potential PII data sources must be properly protected before execution."
        ),
        t.createElement(
          "div",
          { className: "tw-space-y-3" },
          l &&
            t.createElement(
              "button",
              {
                onClick: a,
                onMouseEnter: () => {
                  const e = document.getElementById("ripple-point-eq-ctrl-3");
                  e?.setAttribute("data-eqalertoverride", "true");
                },
                onMouseLeave: () => {
                  const e = document.getElementById("ripple-point-eq-ctrl-3");
                  e?.setAttribute("data-eqalertoverride", "false");
                },
                className:
                  "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-override-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
              },
              "Grant Authorization"
            ),
          t.createElement(
            "button",
            {
              onClick: r,
              className:
                "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-cancel-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
            },
            l ? "Cancel" : "Close"
          ),
          t.createElement(
            "button",
            {
              className:
                "tw-w-full tw-py-3 tw-px-4 tw-rounded-xl tw-bg-open-details-gradient tw-text-white tw-text-sm hover:tw-opacity-90 tw-transition-opacity",
              onClick: n,
            },
            "Open Details"
          )
        )
      )
    );
  },
  ie = ({ onClose: e }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full tw-bg-branddialogbg_full tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-[600px] tw-p-6" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-justify-between tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-3" },
            t.createElement(
              "div",
              { className: "tw-px-2 tw-py-1 tw-bg-brandreddark tw-rounded-md tw-text-xs tw-text-white" },
              "CTRL-003"
            ),
            t.createElement("h2", { className: "tw-text-lg tw-text-white" }, "Sourcing Protocol: AI Action")
          ),
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2" },
            t.createElement("div", { className: "tw-w-2 tw-h-2 tw-bg-brandreddark tw-rounded-full tw-animate-pulse" }),
            t.createElement("span", { className: "tw-text-xs tw-text-white/60" }, "Active Control")
          )
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Purpose"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                "Governs AI decision-making in emergency response when processing social media and life-safety data"
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-gradient-to-br tw-from-brandreddark/20 tw-to-brandreddark/10 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Critical Triggers"),
              t.createElement(
                "ul",
                { className: "tw-space-y-2" },
                ["Life-threat detection", "Unverified social data", "Direct response actions"].map((e, a) =>
                  t.createElement(
                    "li",
                    { key: a, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white" },
                    t.createElement("div", { className: "tw-w-1 tw-h-1 tw-bg-brandreddark tw-rounded-full" }),
                    e
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
            t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Requirements"),
            t.createElement(
              "ul",
              { className: "tw-space-y-2" },
              [
                "Human authorization required",
                "Social media verification",
                "Cross-validation with EMS",
                "Override documentation",
              ].map((e, a) =>
                t.createElement(
                  "li",
                  { key: a, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white/80" },
                  t.createElement("div", { className: "tw-text-brandreddark" }, "•"),
                  e
                )
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-between tw-items-center tw-text-xs tw-text-white/40" },
          t.createElement("div", null, "Last Update: 2024-01-15"),
          t.createElement("div", null, "Priority: Critical")
        ),
        t.createElement(
          "button",
          {
            onClick: e,
            className:
              "tw-w-24 tw-absolute tw-bottom-4 tw-right-0 tw-left-0 tw-m-auto tw-text-white tw-text-xs tw-py-1.5 tw-rounded-lg tw-bg-brandreddark hover:tw-bg-opacity-90 tw-transition-colors",
          },
          "Close"
        )
      )
    ),
  oe = ({ onClose: e, onClick: a }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-center tw-h-full tw-bg-branddialogbg_full tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-[640px] tw-p-4" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-justify-between tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-3" },
            t.createElement(
              "div",
              { className: "tw-px-2 tw-py-1 tw-bg-brandreddark tw-rounded-md tw-text-xs tw-text-white" },
              "CTRL-041"
            ),
            t.createElement(
              "div",
              { className: "tw-flex tw-items-center tw-gap-2" },
              t.createElement("h2", { className: "tw-text-lg tw-text-white" }, "GDPR: Article 25"),
              t.createElement(
                "h4",
                { className: "tw-text-xs tw-text-white" },
                "(Data protection by design and by default)"
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2" },
            t.createElement("div", { className: "tw-w-2 tw-h-2 tw-bg-brandreddark tw-rounded-full tw-animate-pulse" }),
            t.createElement("span", { className: "tw-text-xs tw-text-white/60" }, "Active Control")
          )
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-mb-4" },
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-1" }, "Purpose"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                'GDPR Article 25 ("Data protection by design and by default") requires organizations to implement appropriate technical and organizational measures to protect personal data.'
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-gradient-to-br tw-from-brandreddark/20 tw-to-brandreddark/10 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Critical Triggers"),
              t.createElement(
                "ul",
                { className: "tw-space-y-2" },
                [
                  "Presence of PII in fine-tuning dataset",
                  "Presence of PII in inference",
                  "No detection of PII classifiers",
                ].map((e, a) =>
                  t.createElement(
                    "li",
                    { key: a, className: "tw-flex tw-items-center tw-gap-2 tw-text-sm tw-text-white" },
                    t.createElement("div", { className: "tw-w-1 tw-h-1 tw-bg-brandreddark tw-rounded-full" }),
                    e
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-space-y-4" },
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Requirements"),
              t.createElement(
                "div",
                { className: "tw-text-sm tw-text-white" },
                "Implement safeguards to protect PII from being exposed in model training and inference from agentic workflows."
              )
            ),
            t.createElement(
              "div",
              { className: "tw-bg-white/5 tw-rounded-lg tw-p-3" },
              t.createElement("div", { className: "tw-text-xs tw-text-white/60 tw-mb-2" }, "Suggested Action"),
              t.createElement(
                "div",
                { className: "tw-flex tw-justify-between tw-items-center" },
                t.createElement("span", { className: "tw-text-sm tw-text-white" }, "Implement:"),
                t.createElement(
                  "button",
                  {
                    onClick: a,
                    className:
                      "tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1.5 tw-bg-nvidiagreen tw-rounded-lg tw-text-white hover:tw-bg-opacity-90 tw-transition-colors hover:tw-shadow-md",
                  },
                  t.createElement("div", { className: "tw-w-8 tw-h-8" }, t.createElement(W, null)),
                  t.createElement("span", { className: "tw-text-xs" }, "Nemo Guardrail - PII")
                )
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-between tw-items-center tw-text-xs tw-text-white/40" },
          t.createElement("div", null, "Last Update: 2024-01-15"),
          t.createElement("div", null, "Priority: Critical")
        ),
        t.createElement(
          "button",
          {
            onClick: e,
            className:
              "tw-w-24 tw-absolute tw-bottom-4 tw-right-0 tw-left-0 tw-m-auto tw-text-white tw-text-xs tw-py-1.5 tw-rounded-lg tw-bg-brandreddark hover:tw-bg-opacity-90 tw-transition-colors",
          },
          "Close"
        )
      )
    ),
  se = [
    { name: "Information Fusion", details: "NVIDIA LLM & OSINT Summary", color: "tw-border-purple-500/30" },
    { name: "Risk Assessment", details: "Nemo Guardrails & Human Override", color: "tw-border-green-500/30" },
    { name: "Response Execution", details: "Twilio & Apptek Integration", color: "tw-border-orange-500/30" },
  ],
  ce = () => {
    const { state: e } = U(),
      a = e.userOverrides.length > 0 && e.userRemediations.length > 0,
      r = [
        {
          value: 11,
          label: "Total Agents",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M7 1.75L12.25 4.375V9.625L7 12.25L1.75 9.625V4.375L7 1.75Z",
              stroke: "currentColor",
              strokeWidth: "1.2",
            })
          ),
          color: "tw-text-cyan-400/80",
        },
        {
          value: e.userRemediations.length,
          label: "Nemo Guard",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M2.33334 2.33334H11.6667M2.33334 7H11.6667M2.33334 11.6667H11.6667",
              stroke: "currentColor",
              strokeWidth: "1.2",
              strokeLinecap: "round",
            })
          ),
          color: "tw-text-green-400/80",
        },
        {
          value: 3,
          label: "Data Sources",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M4.66666 1.75H9.33332L11.6667 4.08333V9.91667L9.33332 12.25H4.66666L2.33333 9.91667V4.08333L4.66666 1.75Z",
              stroke: "currentColor",
              strokeWidth: "1.2",
            })
          ),
          color: "tw-text-purple-400/80",
        },
        {
          value: 2,
          label: "External Tools",
          icon: t.createElement(
            "svg",
            { width: "14", height: "14", viewBox: "0 0 14 14", fill: "none" },
            t.createElement("path", {
              d: "M7.58333 1.75H11.6667V5.83333M11.6667 1.75L8.16667 5.25M6.41667 12.25H2.33333V8.16667M2.33333 12.25L5.83333 8.75",
              stroke: "currentColor",
              strokeWidth: "1.2",
              strokeLinecap: "round",
              strokeLinejoin: "round",
            })
          ),
          color: "tw-text-orange-400/80",
        },
      ];
    return t.createElement(
      "div",
      { className: "tw-w-[264px] tw-flex tw-flex-col tw-bg-branddialogbg tw-rounded-xl tw-p-4 mt-3" },
      t.createElement(
        "div",
        {
          className:
            "tw-w-full tw-text-center tw-py-1 tw-mb-4 tw-rounded-lg tw-text-sm tw-font-medium " +
            (a ? "tw-bg-brandgreen tw-text-branddialogbg" : "tw-bg-brandred tw-text-white"),
        },
        a ? "Compliant" : "Non-Compliant"
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
        t.createElement(
          "div",
          null,
          t.createElement("h3", { className: "tw-text-white tw-text-sm tw-font-medium" }, "Notify Investigators"),
          t.createElement("p", { className: "tw-text-white/60 tw-text-xs" }, "Agentic Workflow")
        )
      ),
      t.createElement(
        "div",
        { className: "tw-grid tw-grid-cols-2 tw-gap-2 tw-mb-4" },
        r.map((e, a) =>
          t.createElement(
            "div",
            { key: a, className: "tw-bg-white/[0.03] tw-rounded-lg tw-p-2 tw-border !tw-border-white/10" },
            t.createElement(
              "div",
              { className: `tw-flex tw-items-center tw-gap-1.5 ${e.color}` },
              e.value,
              t.createElement("span", { className: "tw-text-xs" }, e.label)
            )
          )
        )
      ),
      t.createElement(
        "div",
        { className: "tw-mb-3" },
        t.createElement("div", { className: "tw-text-white/80 tw-text-xs tw-font-medium tw-mb-2" }, "Input Sources"),
        t.createElement(
          "div",
          { className: "tw-flex tw-flex-wrap tw-gap-1" },
          ["Video Feed", "EMS Reports", "Dispatch Logs", "Social Media"].map((e) =>
            t.createElement(
              "span",
              {
                key: e,
                className:
                  "tw-px-2 tw-py-0.5 tw-rounded-full tw-text-[10px] tw-bg-white/[0.03] tw-border !tw-border-white/10 tw-text-white/80",
              },
              e
            )
          )
        )
      ),
      t.createElement(
        "div",
        { className: "tw-space-y-2" },
        se.map((e, a) =>
          t.createElement(
            "div",
            { key: a, className: `tw-border-l-2 ${e.color} tw-pl-2 tw-py-0.5` },
            t.createElement("div", { className: "tw-text-white tw-text-xs tw-font-medium" }, e.name),
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, e.details)
          )
        )
      )
    );
  },
  de = () =>
    t.createElement(
      "svg",
      { width: "32", height: "32", viewBox: "0 0 32 32", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
      t.createElement(
        "g",
        { clipPath: "url(#clip0_64855_12690)" },
        t.createElement("rect", { y: "6.10352e-05", width: "32", height: "32", rx: "16", fill: "black" }),
        t.createElement("rect", { x: "0.5", y: "0.500061", width: "31", height: "31", stroke: "#A9A9A9" }),
        t.createElement(
          "g",
          { filter: "url(#filter0_i_64855_12690)" },
          t.createElement("rect", { x: "0.5", y: "0.500061", width: "31", height: "31", rx: "15.5", stroke: "black" }),
          t.createElement("path", {
            d: "M13.5 15.9741V10.1671C13.5 9.50401 13.7634 8.86813 14.2322 8.39929C14.7011 7.93045 15.337 7.66705 16 7.66705C16.663 7.66705 17.2989 7.93045 17.7678 8.39929C18.2366 8.86813 18.5 9.50401 18.5 10.1671V11.0029M18.5 16.0016V21.8337C18.5 22.4968 18.2366 23.1326 17.7678 23.6015C17.2989 24.0703 16.663 24.3337 16 24.3337C15.337 24.3337 14.7011 24.0703 14.2322 23.6015C13.7634 23.1326 13.5 22.4968 13.5 21.8337V20.9879",
            stroke: "white",
            strokeLinecap: "round",
          }),
          t.createElement("path", {
            d: "M15.9993 18.5001H10.1593C8.78268 18.5001 7.66602 17.3809 7.66602 16.0001C7.66602 14.6192 8.78268 13.5001 10.1593 13.5001H10.9948M15.9993 13.5001H21.8281C22.4917 13.4995 23.1284 13.7626 23.5981 14.2314C24.0678 14.7002 24.332 15.3364 24.3327 16.0001C24.3327 17.3809 23.2114 18.5001 21.8281 18.5001H21.0268",
            stroke: "white",
            strokeLinecap: "round",
          })
        )
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "filter",
          {
            id: "filter0_i_64855_12690",
            x: "0",
            y: "6.10352e-05",
            width: "32",
            height: "32",
            filterUnits: "userSpaceOnUse",
            colorInterpolationFilters: "sRGB",
          },
          t.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
          t.createElement("feBlend", {
            mode: "normal",
            in: "SourceGraphic",
            in2: "BackgroundImageFix",
            result: "shape",
          }),
          t.createElement("feColorMatrix", {
            in: "SourceAlpha",
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
            result: "hardAlpha",
          }),
          t.createElement("feMorphology", {
            radius: "1",
            operator: "erode",
            in: "SourceAlpha",
            result: "effect1_innerShadow_64855_12690",
          }),
          t.createElement("feOffset", null),
          t.createElement("feComposite", { in2: "hardAlpha", operator: "arithmetic", k2: "-1", k3: "1" }),
          t.createElement("feColorMatrix", { type: "matrix", values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" }),
          t.createElement("feBlend", { mode: "normal", in2: "shape", result: "effect1_innerShadow_64855_12690" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_64855_12690" },
          t.createElement("rect", { y: "6.10352e-05", width: "32", height: "32", rx: "16", fill: "white" })
        )
      )
    ),
  me = () =>
    t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-gap-1 tw-h-[40px] tw-px-2 tw-bg-[rgb(223,246,246)] tw-rounded-xl" },
      t.createElement(
        "div",
        { className: "tw-w-8 tw-h-8 tw-bg-black tw-rounded-full tw-flex tw-items-center tw-justify-center" },
        t.createElement(de, null)
      ),
      t.createElement("span", { className: "tw-text-black tw-text-[16px] ftw-ont-[400]" }, "Notify Investigators")
    ),
  we = ({ showCertApp: e, setShowCertApp: a }) =>
    t.createElement("div", { className: "tw-flex tw-items-center tw-gap-2" }, t.createElement(me, null)),
  pe = ({ tabs: e, onTabChange: a }) => {
    const [n, l] = r(() => e.find((e) => e.current)?.name || e[0].name);
    return t.createElement(
      "div",
      { className: "tw-px-4 tw-py-6 sm:tw-px-6 lg:tw-px-8 tw-grow" },
      t.createElement(
        "div",
        { className: "tw-mx-auto tw-max-w-7xl" },
        t.createElement(
          "nav",
          { className: "tw-flex tw-py-4" },
          t.createElement(
            "ul",
            {
              role: "list",
              className:
                "tw-flex tw-min-w-full tw-flex-wrap tw-gap-x-6 tw-gap-y-2 tw-px-2 tw-text-sm tw-font-semibold tw-text-gray-400",
            },
            e.map((e) =>
              t.createElement(
                "li",
                {
                  key: e.name,
                  className: "tw-whitespace-nowrap hover:tw-text-gray-300 tw-cursor-pointer",
                  onClick: () => {
                    return ((t = e.name), l(t), void a(t));
                    var t;
                  },
                },
                t.createElement(
                  "span",
                  {
                    className:
                      "tw-block tw-px-1 tw-py-2 tw-transition-colors tw-duration-150 tw-cursor-pointer  " +
                      (n === e.name ? "tw-text-indigo-400" : ""),
                  },
                  e.name
                )
              )
            )
          )
        )
      )
    );
  },
  ue = () =>
    t.createElement(
      "div",
      { className: "tw-flex  tw-items-end tw-gap-4 " },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full",
          style: { backgroundColor: "rgba(206, 255, 220, 1)" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Compliant"
        )
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full",
          style: { backgroundColor: "rgba(208, 86, 89, 1)" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Not compliant"
        )
      ),
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("div", {
          className: "tw-min-h-[11px] tw-min-w-[21px] tw-rounded-full tw-border !tw-border-dashed",
          style: { borderColor: "rgba(255, 255, 255, 1) !important" },
        }),
        t.createElement(
          "span",
          { className: "tw-text-xs tw-font-medium", style: { color: "rgba(255, 255, 255, 0.6)" } },
          "Unknown"
        )
      )
    );
var ge;
!(function (e) {
  ((e[(e.THIN = 1.5)] = "THIN"), (e[(e.NORMAL = 2)] = "NORMAL"), (e[(e.THICK = 8)] = "THICK"));
})(ge || (ge = {}));
const he = y(
    C(
      {
        buttons: [],
        props: [
          {
            title: "National Anti-Terrorist Prosecutor's Office",
            color: "#5db0c8",
            width: ge.NORMAL,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "Code of Criminal Procedure",
            color: "#3c3d3d",
            width: ge.THIN,
            count: 2,
            hovered: !1,
            animation: null,
          },
          { title: "Sourcing Protocol", color: "#a35456", width: ge.THICK, count: 1, hovered: !1, animation: null },
          { title: "Europol Protocols", color: "#ffffff", width: ge.NORMAL, count: 1, hovered: !1, animation: null },
          {
            title: "Preuves Numériques (Digital Evidence)",
            color: "#3c3d3d",
            width: ge.THIN,
            count: 2,
            hovered: !1,
            animation: null,
          },
          {
            title: "Perquisitions Protocols",
            color: "#ffffff",
            width: ge.NORMAL,
            count: 2,
            hovered: !1,
            animation: null,
          },
          { title: "EU AI Act", color: "#3c3d3d", width: ge.THIN, count: 2, hovered: !1, animation: null },
          { title: "GDPR", color: "#3c3d3d", width: ge.THICK, count: 1, hovered: !1, animation: null },
          {
            title: "French Data Protection and Civil Liberties Law",
            color: "#ffffff",
            width: ge.NORMAL,
            count: 2,
            hovered: !1,
            animation: null,
          },
          { title: "Droit de la Preuve", color: "#3c3d3d", width: ge.THIN, count: 2, hovered: !1, animation: null },
        ],
      },
      (e) => ({
        toggleHover: (t) => {
          e((e) => {
            const a = [...e.props];
            return ((a[t].hovered = !a[t].hovered), { props: a });
          });
        },
        setHover: (t, a) => {
          e((e) => {
            const r = [...e.props];
            return ((r[t].hovered = a), { props: r });
          });
        },
        setAnimation: (t, a) => {
          e((e) => {
            if (e.props[t].animation) return e;
            const r = [...e.props];
            return ((r[t].animation = a), { props: r });
          });
        },
        setButton: (t, a) => {
          e((e) => {
            const r = [...e.buttons];
            return ((r[t] = a), { buttons: r });
          });
        },
      })
    )
  ),
  fe = (e, t) => {
    const a = [...document.querySelectorAll(e)];
    if (!a || !a.length) return;
    const r = a[0].getTotalLength();
    return (
      a.forEach((e) => {
        ((e.style.strokeDasharray = `0 ${r}`), (e.style.strokeDashoffset = "0"));
      }),
      t.to(e, { strokeDasharray: `${r} ${r}`, duration: 1, ease: "power1.inOut" })
    );
  },
  Ee = () => {
    const e = he((e) => e.buttons),
      l = he((e) => e.props),
      [i, o] = r([]),
      [s, c] = r([]),
      d = a(null);
    (n(() => {
      if (!e[0]) return;
      const a = d.current?.getBoundingClientRect(),
        r = a?.height || 1,
        n = a?.width || 1,
        i = [],
        s = [];
      (e.forEach((a, o) => {
        const c = a.getBoundingClientRect();
        for (let a = 0; a < l[o].count; a++) {
          const d = c.top + c.height / 2 - 18 * a,
            m = r / 1.5 - 20 * (e.length - o) - 18 * a,
            w = `M0 ${d} H100  L${0.7 * n} ${m}  H${n}`,
            p = t.createElement("path", {
              d: w,
              stroke: l[o].color,
              strokeWidth: 0.8 * l[o].width,
              className: `line${o + 1} line`,
            });
          i.push(p);
          const u = `M0 ${d - 10} v20 L15 ${d} L0 ${d - 10} Z`,
            g = t.createElement("path", { d: u, fill: l[o].color });
          s.push(g);
        }
      }),
        o(i),
        c(s));
    }, [e]),
      m(() => {
        if (!i.length) return;
        const e = v.timeline({
          delay: 2,
          onComplete: () => {
            e.kill();
          },
        });
        fe(".line", e);
      }, [i.length]));
    const w = d.current?.getBoundingClientRect(),
      p = w?.width || 0,
      u = w?.height || 0,
      g = e[0]?.getBoundingClientRect() || 0,
      h = e[e.length - 1]?.getBoundingClientRect() || 0;
    return t.createElement(
      "div",
      { className: "tw-w-full tw-h-screen ", ref: d },
      t.createElement(
        "svg",
        { className: "tw-w-full tw-h-full ", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
        t.createElement(
          "g",
          { id: "lines-bg" },
          t.createElement("path", {
            d: `M100 ${g.top + g.height / 2} L100 ${h.top + h.height / 2} V${h.top + h.height / 2} L${0.7 * p} ${u / 1.5} V${u / 1.5 - 20 * e.length} Z`,
            fill: "#242625",
            fillOpacity: "0.59",
          })
        ),
        [...i],
        [...s]
      )
    );
  },
  xe = w(({ title: e, i: a, ...r }, n) => {
    const l = he((e) => e.props);
    let i = "";
    switch (l[a].color) {
      case "#ffffff":
        i = "hover:tw-bg-white hover:tw-text-black";
        break;
      case "#5db0c8":
        i = "hover:tw-bg-btn-blue hover:tw-border-btn-blue";
        break;
      case "#a35456":
        i = "hover:tw-bg-btn-red hover:tw-border-btn-red";
        break;
      case "#3c3d3d":
        i = "hover:tw-bg-btn-grey hover:tw-border-btn-grey";
    }
    return t.createElement(
      "div",
      { className: "tw-flex tw-items-center tw-justify-stretch tw-gap-x-2" },
      t.createElement(
        "div",
        {
          className: `tw-p-2 tw-border tw-font-medium tw-text-sm tw-border-gray-400 tw-rounded-lg tw-cursor-pointer tw-grow ${i}`,
          ...r,
          ref: n,
        },
        e
      ),
      t.createElement("p", { className: "tw-mr-4 tw-text-lg tw-font-bold" }, "10")
    );
  }),
  be = () => {
    const e = he((e) => e.props),
      a = he((e) => e.setButton),
      { contextSafe: n } = b({ dependencies: [] }),
      [l, i] = r(new Array(e.length).fill(null)),
      o = n((e) => {
        const t = v.timeline({ paused: !0, repeatRefresh: !0 }),
          a = `.line${e + 1}`;
        let r = null;
        (l[e]
          ? (r = l[e])
          : ((r =
              2 === e
                ? ((e, t) => {
                    const a = [...document.querySelectorAll(e)];
                    if (a && a.length) return t.to(e, { opacity: 0, repeat: -1, yoyo: !0, ease: "power1.inOut" });
                  })(a, t)
                : fe(a, t)),
            i((t) => {
              const a = [...t];
              return ((a[e] = r), a);
            })),
          r && r.restart());
      }),
      s = n((e) => {
        2 === e && l[e] && l[e].revert();
      });
    return t.createElement(
      "div",
      null,
      t.createElement("h2", { className: "tw-mb-2 tw-text-lg tw-font-semibold" }, "Active Controls"),
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-gap-y-3" },
        e.map((e, r) =>
          t.createElement(xe, {
            ref: (e) => e && a(r, e),
            key: r,
            i: r,
            title: e.title,
            onMouseOver: () => o(r),
            onMouseOut: () => s(r),
          })
        )
      )
    );
  };
function ve() {
  return t.createElement(
    "svg",
    { width: "20", height: "20", viewBox: "0 0 32 32", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_946)" },
      t.createElement("rect", { x: "1.24463", y: "0.5", width: "29.9787", height: "31", stroke: "#A9A9A9" }),
      t.createElement(
        "g",
        { filter: "url(#filter0_i_429_946)" },
        t.createElement("rect", {
          x: "1.24463",
          y: "0.5",
          width: "29.9787",
          height: "31",
          rx: "14.9894",
          stroke: "#F8F8F8",
        }),
        t.createElement("path", {
          d: "M14.2446 15.9741V10.167C14.2446 9.50395 14.508 8.86807 14.9769 8.39923C15.4457 7.93038 16.0816 7.66699 16.7446 7.66699C17.4077 7.66699 18.0436 7.93038 18.5124 8.39923C18.9812 8.86807 19.2446 9.50395 19.2446 10.167V11.0028M19.2446 16.0016V21.8337C19.2446 22.4967 18.9812 23.1326 18.5124 23.6014C18.0436 24.0703 17.4077 24.3337 16.7446 24.3337C16.0816 24.3337 15.4457 24.0703 14.9769 23.6014C14.508 23.1326 14.2446 22.4967 14.2446 21.8337V20.9878",
          stroke: "#F8F8F8",
          strokeLinecap: "round",
        }),
        t.createElement("path", {
          d: "M16.744 18.5H10.904C9.52731 18.5 8.41064 17.3808 8.41064 16C8.41064 14.6192 9.52731 13.5 10.904 13.5H11.7394M16.744 13.5H22.5727C23.2364 13.4994 23.873 13.7625 24.3427 14.2313C24.8124 14.7002 25.0766 15.3364 25.0773 16C25.0773 17.3808 23.9561 18.5 22.5727 18.5H21.7715",
          stroke: "#F8F8F8",
          strokeLinecap: "round",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "filter",
        {
          id: "filter0_i_429_946",
          x: "0.744629",
          y: "0",
          width: "30.9787",
          height: "32",
          filterUnits: "userSpaceOnUse",
          colorInterpolationFilters: "sRGB",
        },
        t.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
        t.createElement("feBlend", { mode: "normal", in: "SourceGraphic", in2: "BackgroundImageFix", result: "shape" }),
        t.createElement("feColorMatrix", {
          in: "SourceAlpha",
          type: "matrix",
          values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
          result: "hardAlpha",
        }),
        t.createElement("feMorphology", {
          radius: "1",
          operator: "erode",
          in: "SourceAlpha",
          result: "effect1_innerShadow_429_946",
        }),
        t.createElement("feOffset", null),
        t.createElement("feComposite", { in2: "hardAlpha", operator: "arithmetic", k2: "-1", k3: "1" }),
        t.createElement("feColorMatrix", { type: "matrix", values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0" }),
        t.createElement("feBlend", { mode: "normal", in2: "shape", result: "effect1_innerShadow_429_946" })
      ),
      t.createElement(
        "clipPath",
        { id: "clip0_429_946" },
        t.createElement("rect", { x: "0.744629", width: "30.9787", height: "32", rx: "15.4894", fill: "white" })
      )
    )
  );
}
function ye() {
  return t.createElement(
    "svg",
    { width: "12", height: "12", viewBox: "0 0 23 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement("path", {
      d: "M22.2852 20.3123L13.157 1.925C12.51 0.621353 10.7864 0.621353 10.1389 1.925L1.0112 20.3123C0.870699 20.5954 0.800263 20.9131 0.806763 21.2344C0.813263 21.5558 0.896466 21.8698 1.04822 22.1458C1.20001 22.4219 1.41519 22.6506 1.67277 22.8095C1.93031 22.9685 2.2215 23.0523 2.51781 23.0528H20.7758C21.0724 23.0528 21.3639 22.9693 21.6219 22.8106C21.8798 22.6519 22.0953 22.4233 22.2475 22.1471C22.3995 21.8709 22.483 21.5567 22.4896 21.2351C22.4962 20.9135 22.4258 20.5956 22.2852 20.3123ZM11.6482 20.2061C11.4363 20.2061 11.2293 20.1379 11.053 20.0102C10.8769 19.8826 10.7396 19.7011 10.6585 19.4888C10.5774 19.2764 10.5562 19.0428 10.5976 18.8174C10.6389 18.5921 10.7409 18.385 10.8907 18.2225C11.0405 18.06 11.2314 17.9494 11.4392 17.9045C11.647 17.8597 11.8624 17.8827 12.0581 17.9706C12.2538 18.0586 12.4211 18.2075 12.5389 18.3986C12.6565 18.5897 12.7193 18.8143 12.7193 19.0441C12.7193 19.1967 12.6917 19.3478 12.6379 19.4888C12.584 19.6297 12.5051 19.7578 12.4056 19.8657C12.3062 19.9736 12.188 20.0592 12.0581 20.1176C11.9281 20.176 11.7888 20.2061 11.6482 20.2061ZM12.8115 8.52005L12.5041 15.6078C12.5041 15.8542 12.4138 16.0907 12.2531 16.265C12.0923 16.4394 11.8744 16.5373 11.6471 16.5373C11.4198 16.5373 11.2019 16.4394 11.0411 16.265C10.8804 16.0907 10.7901 15.8542 10.7901 15.6078L10.4827 8.52295C10.4758 8.35365 10.5003 8.1846 10.555 8.02585C10.6096 7.86705 10.6931 7.7218 10.8006 7.5988C10.9081 7.4758 11.0373 7.37755 11.1804 7.3098C11.3237 7.2421 11.478 7.2064 11.6343 7.20475H11.6455C11.8028 7.2047 11.9584 7.23915 12.1032 7.3061C12.2479 7.37305 12.3784 7.47115 12.4872 7.5944C12.596 7.71765 12.6806 7.86355 12.736 8.02325C12.7913 8.18285 12.8163 8.3531 12.8093 8.5235L12.8115 8.52005Z",
      fill: "white",
    })
  );
}
function Ce() {
  return t.createElement(
    "svg",
    { width: "123", height: "23", viewBox: "0 0 123 23", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_924)" },
      t.createElement(
        "mask",
        {
          id: "mask0_429_924",
          style: { maskType: "luminance" },
          maskUnits: "userSpaceOnUse",
          x: "0",
          y: "0",
          width: "123",
          height: "23",
        },
        t.createElement("path", { d: "M123 0.651611H0V22.7613H123V0.651611Z", fill: "white" })
      ),
      t.createElement(
        "g",
        { mask: "url(#mask0_429_924)" },
        t.createElement("path", {
          d: "M113.934 7.45996L116.558 14.3649H111.227L113.934 7.45996ZM111.126 4.77657L105.089 19.5119H109.343L110.302 16.8918H117.451L118.358 19.4953H123L116.911 4.77657H111.126ZM98.9823 19.5252H103.303V4.77657H98.9823V19.5252ZM68.9168 4.77657L65.3027 16.469L61.8375 4.77657H57.1641L62.1075 19.5252H68.3456L73.341 4.77657H68.9168ZM86.423 7.97933H88.2889C90.996 7.97933 92.7268 9.14457 92.7268 12.1675C92.7268 15.1905 90.9787 16.3724 88.2889 16.3724H86.423V7.97933ZM82.1339 4.77657V19.5252H89.1474C92.8965 19.5252 94.1081 18.926 95.4201 17.5843C96.3617 16.6454 96.9502 14.5746 96.9502 12.3107C96.9502 10.0468 96.4448 8.38217 95.5551 7.23357C93.9731 5.16277 91.6537 4.77657 88.2058 4.77657H82.1339ZM41.1015 4.74328V19.5086H45.4738V8.04258H48.8697C49.981 8.04258 50.7703 8.31891 51.3068 8.86824C51.9957 9.56406 52.2657 10.7127 52.2657 12.7668V19.5119H56.5029V11.3619C56.5029 5.53897 52.6361 4.74661 48.8697 4.74661H41.1015V4.74328ZM75.1549 4.77657V19.5252H79.4752V4.77657H75.1549Z",
          fill: "#010101",
        }),
        t.createElement("path", {
          d: "M3.61408 10.1933C3.61408 10.1933 6.79198 5.66549 13.1824 5.19606V3.54474C6.10309 4.0974 0 9.83706 0 9.83706C0 9.83706 3.46523 19.4753 13.1686 20.3509V18.603C6.03732 17.7474 3.61754 10.2099 3.61754 10.2099V10.1933H3.61408ZM13.1686 15.1273V16.7286C7.78551 15.8064 6.29003 10.4197 6.29003 10.4197C6.29003 10.4197 8.87943 7.66971 13.1686 7.21693V8.96479C10.9149 8.70511 9.14945 10.7293 9.14945 10.7293C9.14945 10.7293 10.1568 14.1418 13.1859 15.1273M13.1686 0.521767V3.54474L13.7917 3.51145C21.8126 3.25177 27.0433 9.83373 27.0433 9.83373C27.0433 9.83373 21.0406 16.8518 14.7852 16.8518C8.52979 16.8518 13.7086 16.8019 13.172 16.7053V18.5831C13.6082 18.633 14.0617 18.663 14.5186 18.663C20.3379 18.663 24.5578 15.7998 28.6288 12.4206C29.3004 12.9366 32.0767 14.2151 32.6479 14.7644C28.7811 17.8872 19.7494 20.4075 14.619 20.4075C9.4887 20.4075 13.6601 20.3742 13.1893 20.3276V22.9644H35.3031V0.521767H13.172H13.1686ZM13.1686 7.21693V5.19606C13.3693 5.19606 13.5874 5.16277 13.7917 5.16277C19.559 4.98632 23.3427 9.93361 23.3427 9.93361C23.3427 9.93361 19.2578 15.3836 14.8821 15.3836C10.5065 15.3836 13.7224 15.3037 13.1824 15.1239V8.97811C15.436 9.23779 15.8895 10.19 17.2188 12.3573L20.2306 9.93028C20.2306 9.93028 18.0289 7.16366 14.3456 7.16366C13.9578 7.16366 13.5736 7.16366 13.1686 7.2136",
          fill: "#010101",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_429_924" },
        t.createElement("rect", { width: "123", height: "22.1097", fill: "white", transform: "translate(0 0.651611)" })
      )
    )
  );
}
function Ne() {
  return t.createElement(
    "svg",
    { width: "64", height: "25", viewBox: "0 0 64 25", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_935)" },
      t.createElement("path", { d: "M5.19884 0.348602H0.636364V5.01328H5.19884V0.348602Z", fill: "black" }),
      t.createElement("path", {
        d: "M5.08518 24.6514V7.85192H0.766258V24.6514H5.08518ZM33.7914 24.8174V20.7005C33.1582 20.7005 32.6224 20.6673 32.2327 20.6009C31.7781 20.5345 31.4371 20.3685 31.2098 20.1361C30.9825 19.9037 30.8364 19.5717 30.7552 19.1401C30.6902 18.7251 30.6578 18.1773 30.6578 17.5133V11.6368H33.7914V7.85192H30.6578V1.29482H26.3226V17.5465C26.3226 18.9243 26.4363 20.0863 26.6636 21.0159C26.8909 21.9289 27.2806 22.676 27.8164 23.2404C28.3522 23.8048 29.0666 24.2032 29.9271 24.4522C30.8039 24.7012 31.908 24.8174 33.2231 24.8174H33.7914ZM58.6009 24.6514V0H54.2657V24.6514H58.6009ZM22.1498 9.49535C20.9483 8.16733 19.2597 7.50332 17.1165 7.50332C14.9732 7.50332 15.1356 7.71912 14.2751 8.15073C13.4308 8.58234 12.7001 9.17995 12.1318 9.94356L11.8883 10.259V7.85192H7.61808V24.6514H11.9208V15.7038V16.3181V16.0193C11.9695 14.4422 12.3429 13.2802 13.0573 12.5332C13.8204 11.7364 14.7459 11.338 15.8013 11.338C16.8567 11.338 18.0095 11.7364 18.6427 12.5C19.2597 13.2636 19.5844 14.3426 19.5844 15.7205V15.7537V24.6348H23.9521V15.1062C23.9521 12.7158 23.3513 10.8234 22.1498 9.49535ZM52.0251 16.2185C52.0251 15.0066 51.814 13.8778 51.4081 12.8154C50.9859 11.7696 50.4014 10.84 49.6708 10.0432C48.9239 9.24635 48.0309 8.63214 46.9917 8.18393C45.9526 7.73572 44.7998 7.51992 43.5496 7.51992C42.2994 7.51992 41.244 7.75232 40.2048 8.20053C39.1657 8.66534 38.2565 9.27955 37.4933 10.0598C36.7302 10.84 36.1132 11.7696 35.6749 12.832C35.2202 13.8944 35.0092 15.0398 35.0092 16.2517C35.0092 17.4635 35.2202 18.6089 35.6424 19.6713C36.0645 20.7337 36.6653 21.6633 37.4122 22.4436C38.159 23.2238 39.0845 23.8546 40.1561 24.3028C41.2277 24.7676 42.413 25 43.6795 25C47.3489 25 49.6221 23.2902 50.9859 21.6965L47.8685 19.2729C47.219 20.0697 45.6603 21.1487 43.7119 21.1487C41.7636 21.1487 41.4875 20.8665 40.7244 20.2855C39.9613 19.7211 39.4417 18.9243 39.1657 17.9449L39.117 17.7955H52.0251V16.2185ZM39.1495 14.6746C39.1495 13.4462 40.5296 11.3048 43.5009 11.2882C46.4722 11.2882 47.8685 13.4296 47.8685 14.658H39.1495V14.6746Z",
        fill: "black",
      }),
      t.createElement("path", {
        d: "M63.5368 22.4602C63.4556 22.261 63.3419 22.095 63.1958 21.9455C63.0497 21.7961 62.8873 21.6799 62.6925 21.5969C62.4976 21.5139 62.2866 21.4641 62.0755 21.4641C61.8644 21.4641 61.6533 21.5139 61.4585 21.5969C61.2637 21.6799 61.1013 21.7961 60.9552 21.9455C60.809 22.095 60.6954 22.261 60.6142 22.4602C60.533 22.6594 60.4843 22.8752 60.4843 23.091C60.4843 23.3068 60.533 23.5226 60.6142 23.7218C60.6954 23.921 60.809 24.087 60.9552 24.2364C61.1013 24.3858 61.2637 24.502 61.4585 24.585C61.6533 24.668 61.8644 24.7178 62.0755 24.7178C62.2866 24.7178 62.4976 24.668 62.6925 24.585C62.8873 24.502 63.0497 24.3858 63.1958 24.2364C63.3419 24.087 63.4556 23.921 63.5368 23.7218C63.618 23.5226 63.6667 23.3068 63.6667 23.091C63.6667 22.8752 63.618 22.6594 63.5368 22.4602ZM63.277 23.6222C63.212 23.7882 63.1146 23.9376 63.001 24.0538C62.8873 24.17 62.7412 24.2696 62.5788 24.336C62.4164 24.4024 62.2541 24.4356 62.0592 24.4356C61.8644 24.4356 61.702 24.4024 61.5397 24.336C61.3773 24.2696 61.2312 24.17 61.1175 24.0538C61.0039 23.9376 60.9064 23.7882 60.8415 23.6222C60.7766 23.4562 60.7441 23.2902 60.7441 23.091C60.7441 22.8918 60.7766 22.7258 60.8415 22.5598C60.9064 22.3938 61.0039 22.2444 61.1175 22.1282C61.2312 22.012 61.3773 21.9123 61.5397 21.8459C61.702 21.7795 61.8644 21.7463 62.0592 21.7463C62.2541 21.7463 62.4164 21.7795 62.5788 21.8459C62.7412 21.9123 62.8873 22.012 63.001 22.1282C63.1146 22.2444 63.212 22.3938 63.277 22.5598C63.3419 22.7258 63.3744 22.8918 63.3744 23.091C63.3906 23.2902 63.3419 23.4562 63.277 23.6222ZM62.3677 23.2238C62.4976 23.2072 62.5951 23.1574 62.6762 23.0744C62.7574 22.9914 62.8061 22.8752 62.8061 22.7092C62.8061 22.5432 62.7574 22.3938 62.6438 22.2942C62.5463 22.1946 62.3677 22.1448 62.1567 22.1448H61.4423V24.0206H61.7832V23.257H62.0268L62.4814 24.0206H62.8386L62.3677 23.2238ZM62.1891 22.9582H61.7832V22.427H62.1891C62.2378 22.427 62.2866 22.4436 62.3353 22.4602C62.384 22.4768 62.4164 22.51 62.4327 22.5432C62.4489 22.5764 62.4652 22.6262 62.4652 22.6926C62.4652 22.759 62.4489 22.8088 62.4327 22.842C62.4002 22.8752 62.3677 22.9084 62.3353 22.925C62.2866 22.9416 62.2378 22.9582 62.1891 22.9582Z",
        fill: "black",
      })
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_429_935" },
        t.createElement("rect", { width: "63.0303", height: "25", fill: "white", transform: "translate(0.636364)" })
      )
    )
  );
}
const ke = () =>
    t.createElement(
      "div",
      null,
      t.createElement(
        "div",
        {
          className:
            "tw-py-4 tw-mr-16 tw-rounded-lg tw-pl-7 tw-pr-4 tw-bg-gradient-to-r tw-from-card-1 tw-from-[-30%] tw-to-card-2 tw-backdrop-blur-sm",
        },
        t.createElement(
          "div",
          { className: "tw-pb-4 tw-border-b tw-border-black" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw--translate-x-4 tw-gap-x-2" },
            t.createElement("div", {
              className: "tw-w-[8px] tw-h-[7px] tw-bg-[#00F996] tw-rounded-full tw-translate-y-1",
            }),
            t.createElement("h1", { className: "tw-text-xl" }, "Server Cluster 2")
          ),
          t.createElement("h2", { className: "tw-text-base" }, "Ireland East - Dublin")
        ),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-py-4 tw-place-content-center" },
          t.createElement(
            "div",
            null,
            t.createElement(
              "p",
              { className: "tw-text-gray-400 tw-text-xs" },
              "Dell R760 ",
              t.createElement("br", null),
              "GPU: NVIDIA H100 ",
              t.createElement("br", null),
              "AVG GPU: 83.8% ",
              t.createElement("br", null),
              "AVG GPU Usage: 78.1% ",
              t.createElement("br", null),
              "CPU Cores: 48 ",
              t.createElement("br", null),
              "AVG CPU: 2.5% ",
              t.createElement("br", null),
              "AVG CPU Memory: 10.2%"
            )
          ),
          t.createElement(
            "div",
            null,
            t.createElement(
              "div",
              { className: "tw-flex tw-mb-3 tw-gap-x-2 tw-align-center" },
              t.createElement("div", { className: "tw-w-[20px]" }, t.createElement(ve, null)),
              t.createElement("h2", { className: "tw-text-base tw-font-semibold" }, "Notify Investigators")
            ),
            t.createElement(
              "div",
              { className: "tw-flex tw-items-start tw-p-1 tw-bg-[#A35456] tw-rounded-lg  " },
              t.createElement("div", { className: "" }, t.createElement(ye, null)),
              t.createElement(
                "p",
                { className: "tw-text-xs" },
                "Your action was halted because it flagged the sourcing protocol mandatory control #234"
              )
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-[#D3E660] tw-p-2 " },
          t.createElement(Ce, null),
          t.createElement(
            "h2",
            { className: "tw-pt-6 tw-pb-12 tw-text-base tw-font-semibold tw-text-center tw-text-black" },
            "H100"
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-[#4F99E9] tw-px-3 tw-py-6 tw-grid tw-grid-cols-3 tw-gap-2 " },
          t.createElement(Ne, null),
          t.createElement("h2", { className: "tw-text-base tw-font-semibold tw-text-center tw-text-black " }, "XEON 5")
        )
      ),
      t.createElement(
        "button",
        { className: "tw-px-5 tw-py-2 tw-mt-2 tw-border tw-rounded-full tw-border-grey-500" },
        "00000006-0454-005"
      )
    ),
  Me = ({ title: e, content: a, IconRR: r }) =>
    t.createElement(
      "article",
      {
        className:
          "tw-flex tw-flex-col tw-p-2 tw-text-white tw-divide-y tw-rounded-lg tw-gap-y-1 tw-divide-sidebar/100 tw-bg-sidebar tw-backdrop-blur-sm",
      },
      t.createElement(
        "div",
        { className: "tw-flex tw-align-center tw-gap-x-1" },
        r,
        t.createElement("h2", { className: "tw-text-base" }, e)
      ),
      t.createElement("div", { className: "tw-pt-2" }, a)
    );
function Ae() {
  return t.createElement(
    "svg",
    { width: "38", height: "38", viewBox: "0 0 38 38", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_429_959)" },
      t.createElement("path", {
        d: "M31.6166 2.43192H13.6714C12.7032 2.43192 11.776 2.81648 11.092 3.50048L3.50112 11.0914C2.81712 11.7754 2.43256 12.7041 2.43256 13.6708V27.9679C2.43256 29.9834 4.06656 31.6159 6.08056 31.6159H22.5969C20.8519 29.9789 19.7606 27.6548 19.7606 25.0799C19.7606 20.1354 23.784 16.1119 28.7286 16.1119C31.3034 16.1119 33.6275 17.2048 35.2646 18.9482V6.07992C35.2646 4.06592 33.6321 2.43192 31.6166 2.43192ZM13.0726 20.0138H6.4864C5.92704 20.0138 5.47256 19.5608 5.47256 18.9999C5.47256 18.439 5.92552 17.9861 6.4864 17.9861H13.0726C13.6319 17.9861 14.0864 18.439 14.0864 18.9999C14.0864 19.5608 13.6334 20.0138 13.0726 20.0138ZM20.1664 15.4538H6.4864C5.92704 15.4538 5.47256 14.9993 5.47256 14.4399C5.47256 13.8806 5.92552 13.4261 6.4864 13.4261H20.1664C20.7258 13.4261 21.1802 13.879 21.1802 14.4399C21.1802 15.0008 20.7273 15.4538 20.1664 15.4538Z",
        fill: "url(#paint0_linear_429_959)",
      }),
      t.createElement("path", {
        d: "M28.728 18.544C25.1241 18.544 22.192 21.4761 22.192 25.08C22.192 28.6839 25.1241 31.616 28.728 31.616C32.3319 31.616 35.264 28.6839 35.264 25.08C35.264 21.4761 32.3319 18.544 28.728 18.544Z",
        fill: "url(#paint1_linear_429_959)",
      }),
      t.createElement("path", {
        d: "M32.7004 23.2836L32.9237 23.0361L32.6762 22.8128L32.2767 22.4523L32.0292 22.229L31.8059 22.4765L27.4396 27.3159L25.8534 25.7178L25.6186 25.4812L25.382 25.716L25.0001 26.095L24.7635 26.3299L24.9983 26.5664L27.2331 28.8182L27.4812 29.0682L27.7172 28.8067L32.7004 23.2836Z",
        fill: "black",
        stroke: "black",
        strokeWidth: "0.666667",
      })
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "linearGradient",
        {
          id: "paint0_linear_429_959",
          x1: "7.38694",
          y1: "3.68266",
          x2: "21.0331",
          y2: "36.3312",
          gradientUnits: "userSpaceOnUse",
        },
        t.createElement("stop", { stopColor: "#E2CCFF" }),
        t.createElement("stop", { offset: "1", stopColor: "#0D0D0D" })
      ),
      t.createElement(
        "linearGradient",
        {
          id: "paint1_linear_429_959",
          x1: "25.4016",
          y1: "20.8783",
          x2: "38.8821",
          y2: "42.1786",
          gradientUnits: "userSpaceOnUse",
        },
        t.createElement("stop", { stopColor: "white" }),
        t.createElement("stop", { offset: "0.459251" }),
        t.createElement("stop", { offset: "0.643137" })
      ),
      t.createElement(
        "clipPath",
        { id: "clip0_429_959" },
        t.createElement("rect", { width: "38", height: "38", fill: "white" })
      )
    )
  );
}
function Le() {
  return t.createElement(
    "svg",
    { width: "16", height: "17", viewBox: "0 0 16 17", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement(
      "g",
      { clipPath: "url(#clip0_511_140)" },
      t.createElement(
        "mask",
        {
          id: "mask0_511_140",
          style: { maskType: "alpha" },
          maskUnits: "userSpaceOnUse",
          x: "0",
          y: "0",
          width: "16",
          height: "17",
        },
        t.createElement("rect", { y: "0.5", width: "16", height: "16", fill: "#D9D9D9" })
      ),
      t.createElement(
        "g",
        { mask: "url(#mask0_511_140)" },
        t.createElement("path", {
          d: "M2.66665 13.8333C2.29998 13.8333 1.98609 13.7028 1.72498 13.4417C1.46387 13.1806 1.33331 12.8667 1.33331 12.5V4.50001C1.33331 4.13334 1.46387 3.81945 1.72498 3.55834C1.98609 3.29723 2.29998 3.16667 2.66665 3.16667H5.33331C5.5222 3.16667 5.68054 3.23056 5.80831 3.35834C5.93609 3.48612 5.99998 3.64445 5.99998 3.83334C5.99998 4.02223 5.93609 4.18056 5.80831 4.30834C5.68054 4.43612 5.5222 4.50001 5.33331 4.50001H2.66665V12.5H13.3333V4.50001H10.6666C10.4778 4.50001 10.3194 4.43612 10.1916 4.30834C10.0639 4.18056 9.99998 4.02223 9.99998 3.83334C9.99998 3.64445 10.0639 3.48612 10.1916 3.35834C10.3194 3.23056 10.4778 3.16667 10.6666 3.16667H13.3333C13.7 3.16667 14.0139 3.29723 14.275 3.55834C14.5361 3.81945 14.6666 4.13334 14.6666 4.50001V12.5C14.6666 12.8667 14.5361 13.1806 14.275 13.4417C14.0139 13.7028 13.7 13.8333 13.3333 13.8333H2.66665ZM7.33331 8.23334V3.83334C7.33331 3.64445 7.3972 3.48612 7.52498 3.35834C7.65276 3.23056 7.81109 3.16667 7.99998 3.16667C8.18887 3.16667 8.3472 3.23056 8.47498 3.35834C8.60276 3.48612 8.66665 3.64445 8.66665 3.83334V8.23334L9.93331 6.96667C10.0555 6.84445 10.2111 6.78334 10.4 6.78334C10.5889 6.78334 10.7444 6.84445 10.8666 6.96667C10.9889 7.08889 11.05 7.24445 11.05 7.43334C11.05 7.62223 10.9889 7.77778 10.8666 7.90001L8.46665 10.3C8.33331 10.4333 8.17776 10.5 7.99998 10.5C7.8222 10.5 7.66665 10.4333 7.53331 10.3L5.13331 7.90001C5.01109 7.77778 4.94998 7.62223 4.94998 7.43334C4.94998 7.24445 5.01109 7.08889 5.13331 6.96667C5.25554 6.84445 5.41109 6.78334 5.59998 6.78334C5.78887 6.78334 5.94442 6.84445 6.06665 6.96667L7.33331 8.23334Z",
          fill: "white",
        })
      )
    ),
    t.createElement(
      "defs",
      null,
      t.createElement(
        "clipPath",
        { id: "clip0_511_140" },
        t.createElement("rect", { width: "16", height: "16", fill: "white", transform: "translate(0 0.5)" })
      )
    )
  );
}
function Ie() {
  return t.createElement(
    "svg",
    { width: "80", height: "16", viewBox: "0 0 80 16", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
    t.createElement("path", {
      d: "M3.6119 9.27006H10.223V6.14882H3.6119V3.44895H10.6828V0.327713H0.31427V15.6374H10.9206V12.5005H3.6119V9.27006Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M47.0677 0.32773L43.5323 5.85232L39.9968 0.32773H39.759H30.5796H25.2843V3.44897H29.8503V12.4849H24.999C25.2526 12.1728 25.4587 11.8451 25.649 11.5018C26.2197 10.4093 26.5209 9.16083 26.5209 7.80309C26.5209 6.69505 26.3148 5.63383 25.9343 4.69746C25.538 3.74548 24.9831 2.90275 24.2855 2.21608C23.588 1.5138 22.7477 0.967583 21.7806 0.577429C20.8294 0.187274 19.783 0 18.6891 0C17.5793 0 16.5329 0.20288 15.5817 0.577429C14.6304 0.967583 13.7902 1.5138 13.0768 2.21608C12.3792 2.91836 11.8243 3.74548 11.4279 4.69746C11.0316 5.64944 10.8413 6.69505 10.8413 7.80309C10.8413 8.92674 11.0474 9.97235 11.4279 10.9087C11.8243 11.8607 12.3792 12.7034 13.0768 13.3901C13.7743 14.0924 14.6146 14.6386 15.5817 15.0288C16.5329 15.4189 17.5793 15.6062 18.6891 15.6062H27.4405H29.8503H33.1479V3.43336H38.0468L41.8835 9.16083V15.6062H45.1811V9.19204L51.0946 0.32773H47.0677ZM22.7794 9.62901C22.5733 10.1908 22.2879 10.6902 21.9074 11.1116C21.5269 11.533 21.0672 11.8763 20.5281 12.126C19.9891 12.3757 19.3708 12.5006 18.6732 12.5006C17.9756 12.5006 17.3415 12.3757 16.8024 12.126C16.2634 11.8763 15.7878 11.533 15.4231 11.1116C15.0426 10.6902 14.7414 10.1908 14.5512 9.62901C14.3451 9.05159 14.2341 8.44294 14.2341 7.80309C14.2341 7.16324 14.3451 6.5546 14.5512 5.97717C14.7573 5.41534 15.0426 4.91595 15.4231 4.49458C15.8036 4.07321 16.2634 3.72988 16.8024 3.48018C17.3415 3.23048 17.9756 3.10563 18.6732 3.10563C19.3708 3.10563 19.9891 3.23048 20.5281 3.48018C21.0672 3.72988 21.5428 4.07321 21.9074 4.49458C22.2879 4.91595 22.5892 5.41534 22.7794 5.97717C22.9855 6.5546 23.0965 7.16324 23.0965 7.80309C23.0965 8.44294 22.9855 9.05159 22.7794 9.62901Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M62.8107 1.26408L57.3728 13.5618H51.8239V1.26408H50.5556V14.701H56.8813H58.1972H58.2131L59.7509 11.1272H66.9803L68.4706 14.701H69.8975L64.1583 1.26408H62.8107ZM60.2424 9.98794L63.4291 2.62182L66.5206 9.98794H60.2424Z",
      fill: "white",
    }),
    t.createElement("path", {
      d: "M79.0928 9.64461C78.9501 9.25445 78.744 8.91112 78.4586 8.63021C78.1891 8.34929 77.872 8.1152 77.4915 7.94353C77.111 7.77187 76.7147 7.66262 76.2549 7.63141V7.6002C77.0635 7.42853 77.6818 7.1008 78.0781 6.6014C78.4903 6.102 78.6964 5.49336 78.6964 4.8223C78.6964 4.05759 78.5696 3.44895 78.3001 2.99637C78.0306 2.52819 77.6976 2.16925 77.2854 1.91955C76.8732 1.65424 76.3976 1.48257 75.8744 1.40454C75.3512 1.32651 74.8281 1.27969 74.3207 1.27969H70.3889V14.7166H74.7488C75.2086 14.7166 75.7159 14.6698 76.2391 14.5606C76.7781 14.4669 77.2696 14.264 77.7293 13.9987C78.1891 13.7178 78.5696 13.3433 78.8708 12.8439C79.1721 12.3601 79.3306 11.7202 79.3306 10.9555C79.3147 10.4717 79.2355 10.0348 79.0928 9.64461ZM74.4793 2.40334C74.8756 2.40334 75.2561 2.43455 75.6208 2.51258C75.9854 2.59061 76.3025 2.71546 76.572 2.90274C76.8415 3.09001 77.0635 3.33971 77.222 3.63623C77.3806 3.94835 77.4598 4.33851 77.4598 4.80669C77.4598 5.02518 77.4281 5.25927 77.3489 5.52458C77.2696 5.78988 77.111 6.02397 76.8891 6.25807C76.6513 6.49216 76.3342 6.67943 75.922 6.83549C75.5098 6.99156 74.9707 7.06959 74.3207 7.06959H71.6731L71.6573 2.40334H74.4793ZM77.9196 11.7827C77.8403 12.0792 77.6659 12.3601 77.4281 12.6254C77.1903 12.8907 76.8257 13.1092 76.3818 13.2965C75.922 13.4681 75.3195 13.5618 74.5744 13.5618H71.6573V8.20884H74.7647C75.161 8.20884 75.5574 8.25566 75.9537 8.3649C76.3501 8.45854 76.6988 8.63021 77.0001 8.84869C77.3013 9.06718 77.555 9.3637 77.7452 9.70703C77.9354 10.066 78.0306 10.4873 78.0306 10.9711C78.0464 11.2208 77.9989 11.4861 77.9196 11.7827Z",
      fill: "white",
    })
  );
}
const Pe = [
    {
      title: "Controls Failed",
      content: t.createElement("p", { className: "text-red-400" }, "0 Controls"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement(
            "g",
            { clipPath: "url(#clip0_429_973)" },
            t.createElement("path", {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M11.4448 3.75168C11.6929 3.32644 12.3073 3.32642 12.5554 3.75168L21.7685 19.5458C22.0186 19.9743 21.7094 20.5124 21.2133 20.5124H2.78689C2.29074 20.5124 1.98161 19.9743 2.2316 19.5458L11.4448 3.75168ZM14.4063 2.67196C13.3314 0.829199 10.6688 0.829192 9.59384 2.67196L0.380648 18.4661C-0.702671 20.3232 0.636904 22.6553 2.78689 22.6553H21.2133C23.3633 22.6553 24.7029 20.3232 23.6196 18.4661L14.4063 2.67196ZM13.2857 7.49995C13.2857 6.78988 12.7101 6.21424 12 6.21424C11.2899 6.21424 10.7143 6.78988 10.7143 7.49995V13.0714C10.7143 13.7815 11.2899 14.3571 12 14.3571C12.7101 14.3571 13.2857 13.7815 13.2857 13.0714V7.49995ZM10.2857 17.7857C10.2857 18.7325 11.0532 19.5 12 19.5C12.9468 19.5 13.7143 18.7325 13.7143 17.7857C13.7143 16.8389 12.9468 16.0714 12 16.0714C11.0532 16.0714 10.2857 16.8389 10.2857 17.7857Z",
              fill: "white",
            })
          ),
          t.createElement(
            "defs",
            null,
            t.createElement(
              "clipPath",
              { id: "clip0_429_973" },
              t.createElement("rect", { width: "24", height: "24", fill: "white" })
            )
          )
        );
      }, null),
    },
    {
      title: "Controls Passed",
      content: t.createElement(
        "p",
        {
          className: "tw-cursor-pointer",
          onClick: () => {
            window.open(
              "https://governance-studio.eqtylab.io/EU%20AI%20Act%20-%20Energy%20Provider/gov-studio/workspaces/27/dashboard",
              "_blank"
            );
          },
        },
        "45 Controls"
      ),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M12 1.92188C6.43401 1.92188 1.92188 6.43401 1.92188 12C1.92188 17.566 6.43401 22.0781 12 22.0781C17.566 22.0781 22.0781 17.566 22.0781 12C22.0781 6.43401 17.566 1.92188 12 1.92188ZM7.80979 11.9716C7.5352 11.697 7.09001 11.697 6.81542 11.9716C6.54083 12.2462 6.54083 12.6913 6.81542 12.9659L9.62792 15.7784C9.90251 16.053 10.3477 16.053 10.6222 15.7784L17.1847 9.21593C17.4593 8.94135 17.4593 8.49615 17.1847 8.22157C16.9102 7.94698 16.465 7.94698 16.1904 8.22157L10.1251 14.2868L7.80979 11.9716Z",
            fill: "white",
          })
        );
      }, null),
    },
    {
      title: "Agent Authority",
      content: t.createElement("p", null, "Provisioned by Garda"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement(
            "g",
            { clipPath: "url(#clip0_429_998)" },
            t.createElement(
              "g",
              { clipPath: "url(#clip1_429_998)" },
              t.createElement("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M3.14287 0.64286C1.73257 0.64286 0.589294 1.89007 0.589294 3.42857V8.01504C0.589294 14.951 4.65772 21.1089 10.6894 23.3021C10.891 23.3755 11.109 23.3755 11.3106 23.3021C17.3423 21.1089 21.4107 14.951 21.4107 8.01504V3.42857C21.4107 1.89007 20.2675 0.64286 18.8572 0.64286H3.14287ZM2.55358 3.42857C2.55358 3.07353 2.81741 2.78572 3.14287 2.78572H18.8572C19.1826 2.78572 19.4464 3.07353 19.4464 3.42857V8.01504C19.4464 13.9088 16.0581 19.1546 11 21.1515C5.94182 19.1546 2.55358 13.9088 2.55358 8.01504V3.42857ZM16.5952 7.71132C17.0275 7.18061 16.9839 6.36794 16.4973 5.89619C16.0108 5.42443 15.2659 5.47224 14.8334 6.00297L9.26817 12.833L6.99287 10.9714C6.47214 10.5454 5.73341 10.6605 5.34287 11.2286C4.95232 11.7966 5.05786 12.6025 5.57858 13.0286L8.72144 15.6C9.2118 16.0012 9.90222 15.9254 10.3095 15.4256L16.5952 7.71132Z",
                fill: "white",
              })
            )
          ),
          t.createElement(
            "defs",
            null,
            t.createElement(
              "clipPath",
              { id: "clip0_429_998" },
              t.createElement("rect", { width: "24", height: "24", fill: "white" })
            ),
            t.createElement(
              "clipPath",
              { id: "clip1_429_998" },
              t.createElement("rect", { width: "22", height: "24", fill: "white" })
            )
          )
        );
      }, null),
    },
    {
      title: "Developed by",
      content: t.createElement("p", null, "Supervisor #836"),
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            "fill-rule": "evenodd",
            "clip-rule": "evenodd",
            d: "M5.56473 5.14711C5.56473 3.48766 6.90959 2.14286 8.568 2.14286C10.2264 2.14286 11.5713 3.48766 11.5713 5.14711C11.5713 6.80655 10.2264 8.15136 8.568 8.15136C6.90959 8.15136 5.56473 6.80655 5.56473 5.14711ZM8.568 0C5.72563 0 3.42187 2.30468 3.42187 5.14711C3.42187 7.98953 5.72563 10.2942 8.568 10.2942C11.4104 10.2942 13.7141 7.98953 13.7141 5.14711C13.7141 2.30468 11.4104 0 8.568 0ZM9.64202 13.5029C9.64202 13.0138 9.73308 12.5459 9.89916 12.1153C9.46631 12.0433 9.02179 12.0059 8.56785 12.0059C3.75499 12.0059 0 16.2128 0 21.214C0 21.8056 0.479694 22.2854 1.07143 22.2854H11.8815C10.464 20.476 9.64202 18.2081 9.64202 15.7962V13.5029ZM11.5706 13.5029C11.5706 12.4378 12.434 11.5744 13.4992 11.5744H22.0706C23.1357 11.5744 23.9992 12.4378 23.9992 13.5029V15.7962C23.9992 19.4947 21.6324 22.7784 18.1236 23.9479C17.9039 24.0213 17.6659 24.0213 17.4461 23.9479C13.9373 22.7784 11.5706 19.4947 11.5706 15.7962V13.5029ZM13.7134 13.7172V15.7962C13.7134 18.4516 15.3387 20.8221 17.7849 21.7915C20.231 20.8221 21.8563 18.4516 21.8563 15.7962V13.7172H13.7134ZM20.471 16.832C20.8895 16.4135 20.8895 15.7352 20.471 15.3167C20.0527 14.8983 19.3742 14.8983 18.9559 15.3167L17.3563 16.9163L17.0425 16.6025C16.6241 16.184 15.9457 16.184 15.5273 16.6025C15.1088 17.0209 15.1088 17.6993 15.5273 18.1176L16.5987 19.189C17.0171 19.6075 17.6956 19.6075 18.1138 19.189L20.471 16.832Z",
            fill: "white",
          })
        );
      }, null),
    },
    {
      title: "Registration",
      icon: t.createElement(function () {
        return t.createElement(
          "svg",
          { width: "22", height: "22", viewBox: "0 0 22 22", fill: "none", xmlns: "http://www.w3.org/2000/svg" },
          t.createElement("path", {
            d: "M5 5.00293H5.01M5 17.0029H5.01M3 1.00293H19C20.1046 1.00293 21 1.89836 21 3.00293V7.00293C21 8.1075 20.1046 9.00293 19 9.00293H3C1.89543 9.00293 1 8.1075 1 7.00293V3.00293C1 1.89836 1.89543 1.00293 3 1.00293ZM3 13.0029H19C20.1046 13.0029 21 13.8984 21 15.0029V19.0029C21 20.1075 20.1046 21.0029 19 21.0029H3C1.89543 21.0029 1 20.1075 1 19.0029V15.0029C1 13.8984 1.89543 13.0029 3 13.0029Z",
            stroke: "white",
            strokeLinecap: "round",
            "stroke-linejoin": "round",
          })
        );
      }, null),
      content: t.createElement(
        "div",
        null,
        t.createElement("p", null, "CID bafkr...aueq"),
        t.createElement("p", null, "HCS Oxe34...eb5e")
      ),
    },
  ],
  Se = () =>
    t.createElement(
      "div",
      { className: "tw-flex tw-flex-col tw-p-3 tw-rounded-lg tw-bg-sidebar tw-gap-y-2 tw-backdrop-blur-[14px]" },
      t.createElement(
        "div",
        { className: "tw-flex tw-align-center tw-gap-x-2" },
        t.createElement(Ae, null),
        t.createElement("h1", { className: "tw-text-xl" }, "Audit Certificate")
      ),
      Pe.map((e, a) => t.createElement(Me, { key: a, IconRR: e.icon, title: e.title, content: e.content })),
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-m-2 tw-gap-y-2" },
        t.createElement(
          "div",
          { className: "tw-flex tw-justify-end tw-align-center tw-gap-x-2" },
          t.createElement(Le, null),
          t.createElement("p", { className: "tw-text-sm" }, "Export")
        ),
        t.createElement("div", null, t.createElement(Ie, null))
      )
    ),
  He = () => (
    b(() => {
      const e = v.timeline();
      (e.from(".policies", { x: -100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from(".server-card", { y: 100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from(".sidebar", { y: -100, duration: 1, ease: "power4.out", opacity: 0 }),
        e.from("#lines-bg", { opacity: 0, duration: 1 }, "-=1"));
    }, []),
    t.createElement(
      "div",
      {
        className:
          "tw-h-full tw-bg-transparent tw-flex tw-justify-center tw-items-center tw-text-white tw-overflow-hidden\n    ",
      },
      t.createElement(
        "div",
        { className: "tw-grid tw-items-center tw-grid-cols-12 tw-px-24" },
        t.createElement("div", { className: "tw-col-span-2 tw-policies" }, t.createElement(be, null)),
        t.createElement("div", { className: "tw-col-span-4 tw-h-full" }, t.createElement(Ee, null)),
        t.createElement("div", { className: "tw-col-span-4 tw-server-card" }, t.createElement(ke, null)),
        t.createElement("div", { className: "tw-col-span-2 tw-sidebar" }, t.createElement(Se, null))
      )
    )
  ),
  De = ({ isBlocked: e = !1, isPlaying: a = !1, onPlay: r, onPause: n, onCancel: l, onFinal: i }) => {
    const { state: o } = U(),
      s = o.userOverrides.length > 0 && o.userRemediations.length > 0,
      c = Object.values(o.nodes).filter((e) => "completed" === e.status).length;
    return t.createElement(
      "div",
      { className: "tw-w-[264px] tw-min-w-[264px] tw-rounded-xl tw-bg-branddialogbg tw-p-4" },
      t.createElement(
        "div",
        { className: "tw-flex tw-flex-col tw-gap-3" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-gap-2 tw-w-full" },
          t.createElement("div", {
            className:
              "tw-min-w-[8px] tw-min-h-[8px] tw-rounded-full " +
              (e || !s
                ? "tw-bg-brandalert tw-animate-pulse-glow-alert"
                : "running" === o.status
                  ? "tw-bg-brandblue tw-animate-pulse-glow-blue"
                  : "completed" === o.status
                    ? "tw-bg-brandgreen tw-animate-pulse-glow-green"
                    : "tw-bg-gray-400 tw-animate-none"),
          }),
          t.createElement(
            "span",
            { className: "tw-text-white tw-text-xs tw-truncate" },
            e || !s
              ? "Workflow is not compliant"
              : "running" === o.status
                ? `Running: (${Math.min(Math.max(c - 1, 0), 11)}/11 Agents Complete)`
                : "completed" === o.status
                  ? "Completed"
                  : "Ready to Run"
          )
        ),
        t.createElement(
          "div",
          { className: "tw-flex tw-gap-2" },
          a
            ? t.createElement(
                "button",
                {
                  onClick: n,
                  className:
                    "tw-flex tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-yellow-600/2 tw-text-white tw-text-sm hover:tw-bg-opacity-90",
                },
                t.createElement(
                  "svg",
                  {
                    className: "tw-animate-spin tw--ml-1 tw-mr-3 tw-h-5 tw-w-5 tw-text-white",
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                  },
                  t.createElement("circle", {
                    className: "tw-opacity-25",
                    cx: "12",
                    cy: "12",
                    r: "10",
                    stroke: "currentColor",
                    "stroke-width": "4",
                  }),
                  t.createElement("path", {
                    className: "tw-opacity-75",
                    fill: "currentColor",
                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z",
                  })
                ),
                " ",
                "Pause"
              )
            : "completed" !== o.status
              ? t.createElement(
                  "button",
                  {
                    onClick: r,
                    disabled: e || !s,
                    className:
                      "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-text-white tw-text-sm\n                " +
                      (e || !s ? "tw-bg-gray-600 tw-cursor-not-allowed" : "tw-bg-brandblue hover:tw-bg-opacity-90"),
                  },
                  "Start"
                )
              : "completed" == o.status &&
                t.createElement(
                  "button",
                  {
                    onClick: i,
                    className:
                      "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-brandgreen tw-text-branddialogbg tw-text-sm hover:tw-bg-opacity-90",
                  },
                  "View Final Report"
                ),
          a &&
            t.createElement(
              "button",
              {
                onClick: l,
                className:
                  "tw-flex-1 tw-py-2 tw-px-4 tw-rounded-lg tw-bg-brandred tw-text-white tw-text-sm hover:tw-bg-opacity-90",
              },
              "Cancel"
            )
        )
      )
    );
  };
function Re({ entry: e }) {
  switch (e.type) {
    case "human-override":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Override Details"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Approved By"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          ),
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Justification"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          )
        )
      );
    case "agent-output":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Output Details"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-3 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Type"),
            t.createElement("div", { className: "tw-text-white" }, e.output?.type)
          ),
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "ID"),
            t.createElement("div", { className: "tw-text-white" }, e.output?.id)
          ),
          t.createElement(
            "div",
            null,
            t.createElement(
              "button",
              {
                className:
                  "tw-flex tw-items-center tw-gap-2 tw-px-3 tw-py-1 \n                             tw-rounded tw-bg-cyan-500/20 tw-text-cyan-400",
                onClick: () => {
                  console.log("Navigate to:", e.output?.location);
                },
              },
              t.createElement(N, { className: "tw-w-4 tw-h-4" }),
              "View Output"
            )
          )
        )
      );
    case "guardrail-pass":
      return t.createElement(
        "div",
        { className: "tw-space-y-2" },
        t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "Guardrail Evaluation"),
        t.createElement(
          "div",
          { className: "tw-grid tw-grid-cols-2 tw-gap-4" },
          t.createElement(
            "div",
            null,
            t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Checks Passed"),
            t.createElement("div", { className: "tw-text-white" }, e.details)
          ),
          e.metrics &&
            t.createElement(
              "div",
              null,
              t.createElement("div", { className: "tw-text-white/60 tw-text-xs" }, "Evaluation Time"),
              t.createElement("div", { className: "tw-text-white" }, e.metrics.executionTime, "ms")
            )
        )
      );
    default:
      return e.metrics?.apiCalls?.length
        ? t.createElement(
            "div",
            { className: "tw-space-y-2" },
            t.createElement("h4", { className: "tw-text-white tw-font-medium" }, "API Calls"),
            t.createElement(
              "div",
              { className: "tw-space-y-1" },
              e.metrics.apiCalls.map((e, a) =>
                t.createElement(
                  "div",
                  { key: a, className: "tw-flex tw-items-center tw-gap-4 tw-text-xs" },
                  t.createElement("span", { className: "tw-text-white/60" }, e.service),
                  t.createElement("span", { className: "tw-text-white" }, e.duration, "ms"),
                  t.createElement(
                    "span",
                    {
                      className:
                        "tw-px-1.5 tw-rounded " +
                        (e.status < 400 ? "tw-bg-green-500/20 tw-text-green-400" : "tw-bg-red-500/20 tw-text-red-400"),
                    },
                    e.status
                  )
                )
              )
            )
          )
        : null;
  }
}
const Ve = {
    info: { color: "tw-text-brandblue", background: "tw-bg-brandblue/5" },
    success: { color: "tw-text-green-400", background: "tw-bg-green-400/5" },
    error: { color: "tw-text-brandred", background: "tw-bg-brandred/5" },
    warning: { color: "tw-text-yellow-400", background: "tw-bg-yellow-400/5" },
    "agent-complete": { color: "tw-text-purple-400", background: "tw-bg-purple-400/5" },
    "agent-output": { color: "tw-text-cyan-400", background: "tw-bg-cyan-400/5" },
    "guardrail-pass": { color: "tw-text-emerald-400", background: "tw-bg-emerald-400/5" },
    "human-override": { color: "tw-text-amber-400", background: "tw-bg-amber-400/5" },
    critical: { color: "tw-text-red-500", background: "tw-bg-red-500/5" },
  },
  Te = {
    "video-collector": "tw-text-blue-400",
    "video-analyzer": "tw-text-purple-400",
    "partner-analyzer": "tw-text-green-400",
    "service-call-analyzer": "tw-text-yellow-400",
    "social-monitor": "tw-text-orange-400",
    summarizer: "tw-text-cyan-400",
    "nemo-guardrail": "tw-text-red-400",
    "event-prioritizer": "tw-text-indigo-400",
    "policy-validator": "tw-text-pink-400",
    "plan-creator": "tw-text-emerald-400",
    "responder-notifier": "tw-text-amber-400",
  },
  _e = {
    info: () => t.createElement(S, { className: "tw-h-3 tw-w-3" }),
    success: () => t.createElement(P, { className: "tw-h-3 tw-w-3" }),
    error: () => t.createElement(M, { className: "tw-h-3 tw-w-3" }),
    warning: () => t.createElement(M, { className: "tw-h-3 tw-w-3" }),
    "agent-complete": () => t.createElement(I, { className: "tw-h-3 tw-w-3" }),
    "agent-output": () => t.createElement(N, { className: "tw-h-3 tw-w-3" }),
    "guardrail-pass": () => t.createElement(L, { className: "tw-h-3 tw-w-3" }),
    "human-override": () => t.createElement(A, { className: "tw-h-3 tw-w-3" }),
    critical: () => t.createElement(M, { className: "tw-h-3 tw-w-3" }),
  };
function ze({ entry: e, onClick: a, isAutoScrollPaused: r }) {
  const n = _e[e.type],
    l = Ve[e.type];
  return t.createElement(
    "tr",
    {
      onClick: a,
      className: `\n          tw-border-b \n          !tw-border-white/5\n          \n          ${l.background}\n          tw-text-xs // Consistent text size\n        `,
    },
    t.createElement("td", { className: "tw-p-2 tw-text-white/80" }, e.timestamp),
    e.agent
      ? t.createElement(
          "td",
          { className: "tw-p-2 tw-whitespace-nowrap tw-max-w-[196px]" },
          t.createElement(
            "div",
            { className: `tw-flex tw-items-center tw-gap-1.5 ${Te[e.agent.type]}` },
            t.createElement("span", { className: "tw-text-xs" }, e.agent.name)
          )
        )
      : t.createElement("td", { className: "tw-p-2 tw-whitespace-nowrap" }),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-whitespace-nowrap tw-max-w-[136px]" },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-1.5" },
        t.createElement("div", { className: ` ${l.color}` }, t.createElement(n, null)),
        t.createElement("span", { className: `tw-text-xs tw-font-medium ${l.color}` }, e.type.toUpperCase())
      )
    ),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-min-w-0" },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-2" },
        t.createElement("span", { className: "tw-truncate" }, e.content),
        e.output &&
          t.createElement(
            "button",
            {
              className: "tw-flex-shrink-0 tw-ml-2 tw-p-1 tw-rounded hover:tw-bg-white/10",
              onClick: (t) => {
                (t.stopPropagation(), console.log("Navigate to:", e.output?.location));
              },
            },
            t.createElement(N, { className: "tw-w-4 tw-h-4 tw-text-cyan-400" })
          )
      )
    ),
    t.createElement(
      "td",
      { className: "tw-p-2 tw-min-w-0" },
      t.createElement("div", { className: "tw-truncate tw-text-white/60" }, e.details)
    ),
    e.metrics
      ? t.createElement(
          "td",
          { className: "tw-p-2 tw-text-xs tw-text-white/40 " },
          e.metrics.executionTime &&
            t.createElement(
              "div",
              { className: "tw-flex tw-items-center tw-gap-1" },
              t.createElement(k, { className: "tw-w-3 tw-h-3" }),
              e.metrics.executionTime,
              "ms"
            )
        )
      : t.createElement("td", { className: "tw-p-2 tw-text-xs tw-text-white/40 " }),
    t.createElement("td", { className: "tw-p-2 tw-text-xs tw-font-mono tw-text-white/40" }, e.hash?.substring(0, 12))
  );
}
function Oe({ logEntries: e = [], isOpen: n = !0, onToggle: l }) {
  const i = a(null),
    [s, c] = r(null),
    [d, m] = r(!1),
    [w, p] = r(null),
    [u, g] = r(new Set()),
    h = o(() => {
      const t = new Set();
      return (
        e.forEach((e) => {
          e.agent && t.add(e.agent);
        }),
        Array.from(t)
      );
    }, [e]);
  return t.createElement(
    "div",
    {
      className:
        "tw-absolute tw-bottom-0 tw-left-0 tw-right-0 tw-z-50 \n                      tw-transition-transform tw-duration-300 tw-ease-in-out \n                      " +
        (n ? "tw-translate-y-0" : "tw-translate-y-[calc(100%-40px)]"),
    },
    t.createElement(
      "div",
      {
        onClick: l,
        className:
          "tw-flex tw-items-center tw-justify-between  tw-cursor-pointer\n                         tw-px-4 tw-py-2 tw-rounded-t-xl \n                        tw-border-b !tw-border-white/10\n                        \n                         " +
          (n ? "tw-bg-branddialogbg/90" : "tw-bg-branddialogbg/40"),
      },
      t.createElement(
        "div",
        { className: "tw-flex tw-items-center tw-gap-4" },
        t.createElement(
          "div",
          { className: "tw-flex tw-items-center tw-gap-2 " },
          t.createElement(S, { className: "tw-w-4 tw-h-4 tw-text-brandblue  " }),
          t.createElement("span", { className: "tw-text-white tw-text-sm tw-font-medium" }, "Console Output")
        ),
        t.createElement(
          "select",
          {
            className: `tw-bg-transparent tw-border !tw-border-white/20 tw-rounded \n                         tw-px-2 tw-py-1 tw-text-white/80 tw-text-xs tw-w-[200px]\n                         \n                         ${n ? "tw-block" : "tw-hidden"}\n\n                         `,
            value: w || "",
            onChange: (e) => p(e.target.value || null),
          },
          t.createElement("option", { value: "" }, "All Agents"),
          h.map((e) => t.createElement("option", { key: e.id, value: e.id }, e.name))
        ),
        t.createElement(
          "button",
          {
            className: `tw-flex tw-items-center tw-gap-1 tw-px-2 tw-py-1 \n                         tw-rounded tw-text-xs ${d ? "tw-bg-white/10 tw-text-white/60" : "tw-bg-brandblue/20 tw-text-brandblue"}\n                         \n                          ${n ? "tw-block" : "tw-hidden"}\n                          `,
            onClick: () => m(!d),
          },
          t.createElement(k, { className: "tw-w-3 tw-h-3" }),
          d ? "Resume Auto-scroll" : "Auto-scrolling"
        )
      )
    ),
    t.createElement(
      "div",
      { className: "tw-bg-black tw-border-x !tw-border-white/10" },
      t.createElement(
        "div",
        { ref: i, className: "tw-h-[300px] tw-overflow-y-auto tw-font-mono" },
        t.createElement(
          "table",
          { className: "tw-w-full tw-table-fixed tw-text-xs tw-border-spacing-0" },
          t.createElement(
            "colgroup",
            null,
            t.createElement("col", { className: "tw-w-[45px]" }),
            t.createElement("col", { className: "tw-w-[116px]" }),
            t.createElement("col", { className: "tw-w-[90px]" }),
            t.createElement("col", { className: "tw-w-[200px]" }),
            t.createElement("col", { className: "tw-w-[300px]" }),
            t.createElement("col", { className: "tw-w-[50px]" }),
            t.createElement("col", { className: "tw-w-[70px]" })
          ),
          t.createElement(
            "thead",
            { className: "tw-sticky tw-top-0 tw-bg-[#2d293b]  tw-z-10   tw-border-b   !tw-border-white/10" },
            t.createElement(
              "tr",
              { className: "tw-border-b !tw-border-white/10" },
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[45px]" },
                "Time"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[116px]" },
                "Agent"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[90px]" },
                "Type"
              ),
              t.createElement("th", { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60" }, "Message"),
              t.createElement("th", { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60" }, "Details"),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[50px]" },
                "Metrics"
              ),
              t.createElement(
                "th",
                { className: "tw-p-2 tw-text-left tw-font-medium tw-text-white/60 tw-w-[70px]" },
                "CID"
              )
            )
          ),
          t.createElement(
            "tbody",
            null,
            e.map((e) =>
              t.createElement(
                t.Fragment,
                { key: e.id },
                t.createElement(ze, {
                  entry: { ...e, expanded: u.has(e.id) },
                  onClick: () => {
                    var t;
                    (e.expandable &&
                      ((t = e.id),
                      g((e) => {
                        const a = new Set(e);
                        return (a.has(t) ? a.delete(t) : a.add(t), a);
                      })),
                      m(!0));
                  },
                  isAutoScrollPaused: d,
                }),
                e.expandable &&
                  u.has(e.id) &&
                  t.createElement(
                    "tr",
                    { className: `${Ve[e.type].background} tw-opacity-80` },
                    t.createElement("td", { colSpan: 7, className: "tw-p-2 tw-h-8" }, t.createElement(Re, { entry: e }))
                  )
              )
            )
          )
        ),
        t.createElement("div", { className: "tw-h-8" })
      )
    )
  );
}
function Ze() {
  const [e, a] = r(!1),
    [l, i] = r([]),
    { state: o } = U();
  return (
    n(() => {
      const e = Object.values(o.nodes).reduce((e, t) => e.concat(t.logs), []);
      i(e);
    }, [o.nodes]),
    t.createElement(Oe, { logEntries: l, isOpen: e, onToggle: () => a(!e) })
  );
}
const Fe = "tw-h-full tw-w-full tw-overflow-auto tw-text-black relative",
  Ge = ({ audioFiles: e }) =>
    t.createElement(
      "div",
      { className: "tw-flex tw-flex-col tw-space-y-4" },
      e
        .slice(0, 3)
        .map((e, a) =>
          t.createElement(
            "div",
            { key: a, className: "tw-w-full tw-max-w-md" },
            t.createElement(
              "audio",
              { controls: !0, className: "tw-w-full", src: e },
              "Your browser does not support the audio element."
            )
          )
        )
    ),
  qe = ({ images: e }) =>
    t.createElement(
      "div",
      { className: "grid h-full w-full grid-cols-2 gap-4 p-4" },
      e
        .slice(0, 4)
        .map((e, a) =>
          t.createElement(
            "div",
            {
              key: a,
              className: "relative overflow-hidden",
              style: { height: "100%", width: "100%", overflow: "auto", color: "black", position: "relative" },
            },
            t.createElement("img", { src: e, alt: `Grid image ${a + 1}`, className: "h-full w-full object-contain" })
          )
        )
    ),
  Be = {
    default: (e) =>
      t.createElement(
        "div",
        { style: { height: "100%", width: "100%", overflow: "auto", color: "black", position: "relative" } },
        t.createElement(
          "div",
          { className: "tw-h-full tw-w-full tw-rounded tw-bg-gray-500/50" },
          e.params && e.params.mike ? e.params.mike : e.api.title
        )
      ),
    iframe: () => t.createElement("iframe", { style: { width: "100%", height: "100%" }, src: "https://dockview.dev" }),
    riskAssesment: (e) => {
      const a = e.params?.content;
      return a
        ? t.createElement(
            "div",
            { className: Fe },
            t.createElement(
              "div",
              { className: "tw-flex tw-flex-col tw-gap-4" },
              t.createElement(
                "div",
                { className: "tw-bg-brandreddark/20 tw-rounded-lg tw-p-4" },
                t.createElement(
                  "div",
                  { className: "tw-flex tw-justify-between tw-items-center tw-mb-4" },
                  t.createElement(
                    "h3",
                    { className: "tw-text-white tw-text-lg tw-font-medium" },
                    "Risk Level: ",
                    a.riskLevel
                  ),
                  a.requiresOverride &&
                    t.createElement(
                      "span",
                      { className: "tw-bg-brandreddark tw-px-2 tw-py-1 tw-rounded tw-text-sm" },
                      "Requires Override"
                    )
                ),
                t.createElement(
                  "div",
                  { className: "tw-space-y-3" },
                  a.factors.map((e, a) =>
                    t.createElement(
                      "div",
                      { key: a, className: "tw-bg-gray-800/50 tw-rounded tw-p-3" },
                      t.createElement(
                        "div",
                        { className: "tw-flex tw-justify-between tw-mb-1" },
                        t.createElement("span", { className: "tw-text-white/80" }, e.category),
                        t.createElement("span", { className: "tw-text-white" }, e.level)
                      ),
                      t.createElement("p", { className: "tw-text-white/60 tw-text-sm" }, e.details)
                    )
                  )
                ),
                t.createElement(
                  "div",
                  { className: "tw-mt-4" },
                  t.createElement(
                    "h4",
                    { className: "tw-text-white tw-text-sm tw-font-medium tw-mb-2" },
                    "Recommendations"
                  ),
                  t.createElement(
                    "ul",
                    { className: "tw-space-y-1" },
                    a.recommendations.map((e, a) =>
                      t.createElement("li", { key: a, className: "tw-text-white/80 tw-text-sm" }, "• ", e)
                    )
                  )
                )
              )
            )
          )
        : t.createElement("div", { className: "tw-text-white" }, "No assessment data");
    },
    audio: (e) => t.createElement("div", { className: Fe }, t.createElement(Ge, { audioFiles: e.params.content })),
    jsonChart: (e) =>
      t.createElement(
        "div",
        { className: Fe },
        e.params?.content
          ? t.createElement(
              "div",
              { className: "tw-bg-gray-800/50 tw-rounded-lg tw-p-4 tw-h-full" },
              t.createElement("div", { className: "tw-text-white" }, JSON.stringify(e.params.content, null, 2))
            )
          : t.createElement("div", { className: "tw-text-white" }, "No chart data available")
      ),
    image: (e) =>
      t.createElement(
        "div",
        { className: Fe },
        t.createElement("img", {
          src: e.params.image,
          alt: "firms",
          className: "tw-h-full tw-w-full tw-object-contain",
        })
      ),
    imageGrid: (e) => t.createElement("div", { className: Fe }, t.createElement(qe, { images: e.params.images })),
    map: (e) => t.createElement("div", null, "TODO: Kepler.gl"),
    markdown: (e) =>
      t.createElement(
        "div",
        { className: Fe },
        t.createElement(
          _,
          {
            className:
              "tw-prose-xs tw-h-full tw-w-full tw-overflow-auto tw-rounded tw-bg-transparent tw-p-4 tw-text-white",
          },
          e.params && e.params.content ? e.params.content : "# no markdown"
        )
      ),
    toolNotify: (e) => {
      const a = e.params?.content;
      return a
        ? t.createElement(
            "div",
            { className: Fe },
            t.createElement(
              "div",
              { className: "tw-flex tw-flex-col tw-gap-2" },
              a.map((e, a) =>
                t.createElement(
                  "div",
                  { key: a, className: "tw-bg-gray-800/50 tw-rounded-lg tw-p-4 tw-border-l-4 tw-border-l-blue-500" },
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-justify-between tw-items-center tw-mb-2" },
                    t.createElement("span", { className: "tw-text-white/60 tw-text-xs" }, e.timestamp),
                    t.createElement(
                      "span",
                      { className: "tw-px-2 tw-py-1 tw-rounded tw-text-xs tw-bg-green-500/20 tw-text-green-300" },
                      e.status
                    )
                  ),
                  t.createElement(
                    "div",
                    { className: "tw-flex tw-flex-col tw-gap-1" },
                    t.createElement("span", { className: "tw-text-white tw-font-medium" }, "To: ", e.recipient),
                    t.createElement("p", { className: "tw-text-white/80" }, e.message),
                    t.createElement(
                      "p",
                      { className: "tw-text-white/60 tw-text-sm tw-italic" },
                      "Response: ",
                      e.response
                    )
                  )
                )
              )
            )
          )
        : t.createElement("div", { className: "tw-text-white" }, "No notifications");
    },
  },
  Ue = (t) => {
    const [a, r] = e.useState(t.containerApi.hasMaximizedGroup()),
      [n, l] = e.useState("popout" === t.api.location.type);
    e.useEffect(() => {
      const e = t.containerApi.onDidMaximizedGroupChange(() => {
          r(t.containerApi.hasMaximizedGroup());
        }),
        a = t.api.onDidLocationChange(() => {
          l("popout" === t.api.location.type);
        });
      return () => {
        (e.dispose(), a.dispose());
      };
    }, [t.containerApi]);
    return e.createElement(
      "div",
      {
        className: "group-control",
        style: {
          display: "flex",
          alignItems: "center",
          padding: "0px 8px",
          height: "100%",
          color: "var(--dv-activegroup-visiblepanel-tab-color)",
        },
      },
      e.createElement(H, {
        className: "tw-mr-2 tw-h-4 tw-w-4",
        onClick: () => {
          t.containerApi.hasMaximizedGroup() ? t.containerApi.exitMaximizedGroup() : t.activePanel?.api.maximize();
        },
      })
    );
  },
  $e = {
    default: (t) =>
      e.createElement(T, {
        onContextMenu: (e) => {
          (e.preventDefault(), alert("context menu"));
        },
        ...t,
      }),
  },
  je = (e, t) => {
    if (0 === e) return {};
    const a = e % 4,
      r = Math.floor(e / 4);
    if (!Array.isArray(t) || !t.length) return {};
    if (0 === r) {
      const a = t[e - 1];
      return a?.id ? { position: { referencePanel: a.id, direction: "right" } } : {};
    }
    const n = t[4 * (r - 1) + a];
    return n?.id ? { position: { referencePanel: n.id, direction: "below" } } : {};
  },
  Ye = (t) => {
    const [a, l] = e.useState(),
      [i, o] = r(0),
      [s, c] = r([]),
      { state: d } = U(),
      m = Object.values(d.nodes).reduce((e, t) => e.concat(t.outputs), []),
      [w, p] = r(m);
    n(() => {
      if (!a) return;
      const e = Object.values(d.nodes).reduce((e, t) => e.concat(t.outputs), []),
        t = [];
      e.forEach((e, r) => {
        if (!a.getPanel(e.id) && e.id) {
          const n = { ...e, ...je(r, t) },
            l = a.addPanel(n);
          t.push(l);
        }
      });
    }, [d.nodes]);
    return e.createElement(
      "div",
      { className: "tw-h-full tw-flex tw-flex-col tw-grow tw-bg-transparent" },
      e.createElement(
        "div",
        { className: "tw-flex tw-h-0 tw-grow" },
        e.createElement(
          "div",
          { className: "tw-flex tw-h-full tw-overflow-hidden tw-grow" },
          e.createElement(V, {
            components: Be,
            defaultTabComponent: $e.default,
            rightHeaderActionsComponent: Ue,
            onReady: (e) => {
              if (!e?.api) return;
              l(e.api);
              const t = [];
              m.forEach((a, r) => {
                if (a.id) {
                  const n = { ...a, ...je(r, t) },
                    l = e.api.addPanel(n);
                  t.push(l);
                }
              });
            },
            className: t.theme || "dockview-theme-abyss",
          })
        )
      )
    );
  },
  We = ({ children: e }) =>
    t.createElement(
      "div",
      { className: " tw-h-full tw-w-full", style: { animation: "smoothSlideIn 0.6s ease-out forwards" } },
      t.createElement(
        "style",
        null,
        "\n        @keyframes smoothSlideIn {\n          0% {\n            opacity: 0;\n            transform: translateX(30px);\n          }\n          100% {\n            opacity: 1;\n            transform: translateX(0);\n          }\n        }\n      "
      ),
      e
    ),
  Ke = ({ startId: e, endId: r, isEndpointInFlow: l = !0 }) => {
    const i = a(null),
      o = a(null),
      s = a(null),
      c = a(null);
    return (
      n(() => {
        o.current = document.querySelector(".react-flow__viewport")?.parentElement || null;
        const t = () => {
            const t = document.getElementById(e),
              a = document.getElementById(r),
              n = i.current,
              l = o.current;
            if (!(t && a && n && l)) return;
            const s = window.getComputedStyle(l.querySelector(".react-flow__viewport") || l);
            new DOMMatrix(s.transform);
            const c = t.getBoundingClientRect(),
              d = a.getBoundingClientRect(),
              m = c.right,
              w = c.top + c.height / 2,
              p = d.left,
              u = d.top + d.height / 2,
              g = `M ${m} ${w}\n                      C ${m + (p - m) / 3} ${w},\n                        ${m + (2 * (p - m)) / 3} ${u},\n                        ${p} ${u}`;
            n.setAttribute("d", g);
          },
          a = () => {
            requestAnimationFrame(t);
          };
        t();
        const n = o.current;
        if (n) {
          const e = n.querySelector(".react-flow__viewport");
          e &&
            ((c.current = new MutationObserver(a)),
            c.current.observe(e, { attributes: !0, attributeFilter: ["style", "transform"] }));
        }
        const l = document.getElementById(r)?.closest(".react-flow__node");
        return (
          l &&
            ((s.current = new MutationObserver(a)),
            s.current.observe(l, { attributes: !0, attributeFilter: ["style", "transform", "class"], subtree: !1 })),
          window.addEventListener("resize", a),
          () => {
            (window.removeEventListener("resize", a), c.current?.disconnect(), s.current?.disconnect());
          }
        );
      }, [e, r]),
      t.createElement(
        "svg",
        {
          className: "tw-fixed tw-inset-0 tw-pointer-events-none tw-z-50 tw-w-full tw-h-full",
          style: { overflow: "visible" },
        },
        t.createElement("path", {
          ref: i,
          strokeWidth: "1",
          fill: "none",
          strokeDasharray: "8,4",
          className: "tw-stroke-brandalert",
        })
      )
    );
  },
  Xe = ({ children: e, t: a = 1e3 }) => {
    const [r, n] = t.useState(!1);
    return (
      t.useEffect(() => {
        setTimeout(() => {
          n(!0);
        }, a);
      }, []),
      r ? t.createElement(t.Fragment, null, e) : null
    );
  },
  Je = () =>
    t.createElement(
      "svg",
      {
        className: "tw-mt-[11px] tw-mr-3",
        width: "90",
        height: "90",
        viewBox: "0 0 90 90",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement(
        "g",
        { "clip-path": "url(#clip0_726_174)" },
        t.createElement("path", {
          d: "M74.8813 5.7598H32.3797C30.0865 5.7598 27.8905 6.6706 26.2705 8.2906L8.29209 26.269C6.67209 27.889 5.76129 30.0886 5.76129 32.3782V66.2398C5.76129 71.0134 9.63129 74.8798 14.4013 74.8798H53.5189C49.3861 71.0026 46.8013 65.4982 46.8013 59.3998C46.8013 47.689 56.3305 38.1598 68.0413 38.1598C74.1397 38.1598 79.6441 40.7482 83.5213 44.8774V14.3998C83.5213 9.6298 79.6549 5.7598 74.8813 5.7598ZM30.9613 47.401H15.3625C14.0377 47.401 12.9613 46.3282 12.9613 44.9998C12.9613 43.6714 14.0341 42.5986 15.3625 42.5986H30.9613C32.2861 42.5986 33.3625 43.6714 33.3625 44.9998C33.3625 46.3282 32.2897 47.401 30.9613 47.401ZM47.7625 36.601H15.3625C14.0377 36.601 12.9613 35.5246 12.9613 34.1998C12.9613 32.875 14.0341 31.7986 15.3625 31.7986H47.7625C49.0873 31.7986 50.1637 32.8714 50.1637 34.1998C50.1637 35.5282 49.0909 36.601 47.7625 36.601Z",
          fill: "url(#paint0_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M68.04 43.92C59.5044 43.92 52.56 50.8644 52.56 59.4C52.56 67.9356 59.5044 74.88 68.04 74.88C76.5756 74.88 83.52 67.9356 83.52 59.4C83.52 50.8644 76.5756 43.92 68.04 43.92Z",
          fill: "url(#paint1_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M77.1097 54.8399L77.333 54.5924L77.0855 54.3691L76.1392 53.5153L75.8918 53.292L75.6685 53.5395L65.0042 65.3591L60.908 61.2318L60.6732 60.9953L60.4366 61.2301L59.532 62.1279L59.2954 62.3627L59.5302 62.5993L64.8232 67.9324L65.0714 68.1824L65.3073 67.9209L77.1097 54.8399Z",
          fill: "black",
          stroke: "black",
          "stroke-width": "0.666667",
        })
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "linearGradient",
          {
            id: "paint0_linear_726_174",
            x1: "17.4953",
            y1: "8.72209",
            x2: "49.8151",
            y2: "86.0476",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "#E2CCFF" }),
          t.createElement("stop", { offset: "1", "stop-color": "#0D0D0D" })
        ),
        t.createElement(
          "linearGradient",
          {
            id: "paint1_linear_726_174",
            x1: "60.1618",
            y1: "49.4486",
            x2: "92.0893",
            y2: "99.8968",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "white" }),
          t.createElement("stop", { offset: "0.459251" }),
          t.createElement("stop", { offset: "0.643137" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_726_174" },
          t.createElement("rect", { width: "90", height: "90", fill: "white" })
        )
      )
    ),
  Qe = () => {
    const [e, a] = r("");
    return (
      n(() => {
        const e = new Date();
        e.setMinutes(e.getMinutes() - 1);
        const t = e.toLocaleString("en-US", {
          month: "short",
          day: "numeric",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
          timeZone: "EST",
          hour12: !1,
        });
        a(t);
      }, []),
      t.createElement(
        "div",
        { className: "tw-h-[126px] tw-pl-24 tw-flex tw-items-center" },
        t.createElement(Je, null),
        t.createElement(
          "div",
          { className: "tw-flex tw-flex-col" },
          t.createElement(
            "p",
            { className: "tw-text-white tw-text-[20px] tw-font-medium tw-leading-[100%] tw-mb-1" },
            "Response Summary"
          ),
          t.createElement(
            "span",
            { className: "tw-text-white tw-text-[32px] tw-font-normal tw-leading-[100%] tw-mb-1" },
            "Threat Alert System"
          ),
          t.createElement(
            "p",
            { className: "tw-text-[#A1A1AA] tw-font-normal tw-text-[13px] tw-leading-[100%]" },
            "Generated ",
            e
          )
        )
      )
    );
  },
  et = () => {
    const e = 10,
      a = 45,
      r = 2,
      n = `\n  Investigator Alert Report - ${(() => {
        const e = new Date();
        return (
          e.setMinutes(e.getMinutes() - 1),
          e.toLocaleString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            timeZone: "EST",
            hour12: !1,
          })
        );
      })()}\n  \n  THREAT ASSESSMENT SUMMARY\n  OSINT feed analysis triggered multi-source verification system. Video surveillance data collected from Twitter, Telegram and auxiliary social media channels confirm escalating situation. Analysis covers primary affected zone with cross-referenced data points.\n  \n  KEY INTELLIGENCE GATHERED\n  - Video footage analysis completed through automated verification\n  - Social media correlation through multiple platforms\n  - Location-based intelligence mapping\n  - Real-time event tracking through OSINT feeds\n  \n  SURVEILLANCE METRICS\n  - 45+ primary source confirmations\n  - 3 independent verification channels\n  - 2 automated analysis cycles completed\n  - 25+ corroborating data points\n  - 78 related social media posts analyzed\n  \n  COMPLIANCE STATUS\n  Two protocol frameworks required verification:\n  1. Sourcing Protocol: Validated through compliance gateway\n  2. GDPR Requirements: Data protection measures active\n  \n  All intelligence gathering executed in compliance with National Anti-Terrorist Prosecutor's Office guidelines and validated through Nemo Guardrails system.\n  `;
    return t.createElement(
      "div",
      { className: "tw-p-6 tw-bg-[#09090B] tw-rounded-xl" },
      t.createElement(Qe, null),
      t.createElement(
        "div",
        { className: "tw-grid tw-grid-cols-3 tw-gap-4 tw-mb-8" },
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(L, { className: "tw-text-blue-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Policies Passed")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-blue-500" }, e)
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(P, { className: "tw-text-green-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Controls Passed")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-green-500" }, a)
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-4" },
          t.createElement(
            "div",
            { className: "tw-flex tw-items-center tw-gap-2 tw-mb-4" },
            t.createElement(D, { className: "tw-text-yellow-500" }),
            t.createElement("span", { className: "tw-text-white" }, "Controls Mitigated")
          ),
          t.createElement("div", { className: "tw-text-4xl tw-text-yellow-500" }, r)
        )
      ),
      t.createElement(
        "div",
        { className: "tw-bg-white/5 tw-border tw-border-white/10 tw-rounded-lg tw-p-6" },
        t.createElement("h3", { className: "tw-text-white tw-text-xl tw-mb-4" }, "Agentic Response Summary"),
        t.createElement("div", { className: "tw-text-gray-300 tw-whitespace-pre-line" }, n)
      )
    );
  },
  tt = [
    { id: "ctrl-1", title: "National Anti-Terrorist Prosecutor's Office", isAlert: !1, mandatory: !0, implemented: !0 },
    {
      id: "ctrl-2",
      title: "Criminal Code and Code of Criminal Procedure",
      isAlert: !1,
      mandatory: !1,
      implemented: !1,
    },
    { id: "ctrl-3", title: "Sourcing Protocol", isAlert: !0, mandatory: !0, implemented: !0, alertType: "authorize" },
    { id: "ctrl-4", title: "Europol Protocols", isAlert: !1, mandatory: !1, implemented: !0 },
    { id: "ctrl-5", title: "Preuves Numériques (Digital Evidence)", isAlert: !1, mandatory: !1, implemented: !0 },
    {
      id: "ctrl-6",
      title: "Perquisitions Protocols (Search/Seizure Protocols)",
      isAlert: !1,
      mandatory: !1,
      implemented: !0,
    },
    { id: "ctrl-7", title: "EU AI Act", isAlert: !1, mandatory: !1, implemented: !0 },
    { id: "ctrl-9", title: "GDPR", isAlert: !0, mandatory: !1, implemented: !0, alertType: "remediate" },
    {
      id: "ctrl-10",
      title: "Loi Informatique et Libertés (French Data Protection and Civil Liberties Law)",
      isAlert: !1,
      mandatory: !1,
      implemented: !0,
    },
    { id: "ctrl-11", title: "Droit de la Preuve (Law of Evidence)", isAlert: !1, mandatory: !1, implemented: !0 },
  ],
  at = () => {
    const [e, l] = r(!1),
      [i, o] = r(null),
      [s, c] = r(null),
      [d, m] = r(!1),
      [w, p] = r(!1),
      u = a(null),
      { state: g, startPipeline: h, overrideGuardrail: f, remediateGuardrail: E } = U(),
      [x, b] = r(!1),
      [v, y] = r(!1),
      [C, N] = r(!1),
      [k, M] = r(),
      A = () => {
        (f("ctrl-3", "Manual override approved"), b(!0), o(null));
      };
    n(() => {
      (o("ctrl-3"), c("ctrl-3-item-wrapper"), M(tt[2]));
    }, []);
    const [L, I] = t.useState([
      { name: "Agentic Workflow", current: !0 },
      { name: "Console", current: !1 },
      { name: "Policy Audit", current: !1 },
    ]);
    n(() => {
      const e = setTimeout(() => {
        p(!0);
      }, 750);
      return () => clearTimeout(e);
    }, []);
    const P = (e) => {
        if ((M(e), e.isAlert)) {
          const t = `${e.id}-item-wrapper`;
          (console.log("debug: handleControlClick", e.id, t),
            i && i !== e.id ? (o(e.id), c(t)) : i && i === e.id ? (o(null), m(!1)) : (o(e.id), c(t)));
        } else (o(null), m(!1));
      },
      S = (e) => {
        "reconfirm" === e.id && (o("ctrl-3"), c("ctrl-3-item-wrapper"));
      },
      H = () => {
        (o(null), m(!1));
      },
      D = () => {
        m(!0);
      },
      R = L.find((e) => e.current)?.name || L[0].name;
    return t.createElement(
      z,
      { outsideGridRender: () => t.createElement(Ze, null) },
      t.createElement(
        "div",
        {
          ref: u,
          className:
            "tw-transition-opacity tw-duration-150 tw-ease-in-out tw-h-full " + (w ? "tw-opacity-100" : "tw-opacity-0"),
        },
        "Agentic Workflow" === R &&
          t.createElement(
            "div",
            { className: "tw-text-white tw-flex tw-h-full tw-flex-col tw-overflow-visible tw-p-6" },
            t.createElement(
              "div",
              { className: "tw-w-full tw-flex tw-overflow-x-visible tw-h-full" },
              t.createElement(j, { data: tt, onControlClick: P }),
              t.createElement(
                "div",
                { className: " tw-grow tw-relative tw-flex tw-items-center" },
                t.createElement(ne, { backgroundColor: "transparent", textColor: "white", onNodeClick: S }),
                d &&
                  "ctrl-3" === k?.id &&
                  t.createElement(
                    "div",
                    { className: "tw-w-11/12 tw-h-full tw-absolute tw-left-0 tw-right-0 tw-m-auto tw-z-[1000]" },
                    t.createElement(We, null, t.createElement(ie, { onClose: () => m(!1) }))
                  ),
                d &&
                  "ctrl-9" === k?.id &&
                  t.createElement(
                    "div",
                    { className: "tw-w-11/12 tw-h-full tw-absolute tw-left-0 tw-right-0 tw-m-auto tw-z-[1000]" },
                    t.createElement(
                      We,
                      null,
                      t.createElement(oe, {
                        onClose: () => m(!1),
                        onClick: () => (E("ctrl-9", "Manual remediation approved"), o(null), m(!1), void y(!0)),
                      })
                    )
                  ),
                t.createElement("div", { className: "tw-absolute tw-bottom-0 tw-left-16" }, t.createElement(ue, null))
              ),
              t.createElement(
                "div",
                { className: "tw-relative tw-h-full" },
                t.createElement(De, {
                  isBlocked: !x || !v,
                  isPlaying: "running" === g.status,
                  onPlay: h,
                  onPause: () => null,
                  onCancel: () => null,
                  onFinal: () => N(!0),
                }),
                t.createElement(
                  "div",
                  { className: "tw-w-[264px] tw-relative" },
                  i &&
                    k?.isAlert &&
                    t.createElement(
                      We,
                      null,
                      t.createElement(le, { onOverride: A, onCancel: H, onDetails: D, control: k })
                    ),
                  !i && t.createElement(We, null, t.createElement(ce, null))
                )
              )
            ),
            i &&
              s &&
              t.createElement(
                t.Fragment,
                null,
                t.createElement(Xe, { t: 380 }, t.createElement(Ke, { startId: s, endId: `ripple-point-eq-${k?.id}` })),
                t.createElement(
                  Xe,
                  { t: 380 },
                  t.createElement(Ke, {
                    startId: `ripple-point-eq-${k?.id}`,
                    endId: "eq-control-dialog",
                    isEndpointInFlow: !1,
                  })
                )
              )
          ),
        "Console" === R &&
          t.createElement(
            "div",
            { className: "tw-relative tw-flex tw-w-full tw-flex-col tw-h-full tw-p-6" },
            t.createElement("div", { className: "tw-h-full tw-w-full" }, t.createElement(Ye, null))
          ),
        "Policy Audit" === R && t.createElement(He, null)
      ),
      t.createElement(
        "div",
        { className: "tw-absolute tw--top-10 tw-left-56 tw-transform tw--translate-y-[32px]  tw-flex tw-z-10" },
        t.createElement(we, { showCertApp: e, setShowCertApp: l }),
        t.createElement(pe, {
          tabs: L,
          onTabChange: (e) => {
            p(!1);
            const t = () => {
              (u.current?.removeEventListener("transitionend", t),
                I(L.map((t) => ({ ...t, current: t.name === e }))),
                setTimeout(() => {
                  requestAnimationFrame(() => {
                    requestAnimationFrame(() => {
                      p(!0);
                    });
                  });
                }, 200));
            };
            u.current?.addEventListener("transitionend", t);
          },
        })
      ),
      C
        ? t.createElement(
            "div",
            { className: "tw-fixed tw-inset-0 tw-z-[2000] tw-flex tw-items-center tw-justify-center tw-bg-black/50" },
            t.createElement(
              "div",
              {
                className: "tw-relative tw-bg-white tw-shadow-lg tw-max-h-[90vh] tw-overflow-auto",
                style: { width: "8.5in", height: "11in", transform: "scale(0.9)" },
              },
              t.createElement(
                "button",
                {
                  onClick: () => N(!1),
                  className:
                    "tw-absolute tw-top-4 tw-right-4 tw-z-10 tw-rounded-full tw-bg-gray-800 tw-p-2 tw-text-white hover:tw-bg-gray-700",
                },
                t.createElement(
                  "svg",
                  { className: "tw-h-6 tw-w-6", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor" },
                  t.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: 2,
                    d: "M6 18L18 6M6 6l12 12",
                  })
                )
              ),
              t.createElement("div", { className: "tw-h-full tw-w-full tw-overflow-auto" }, t.createElement(et, null))
            )
          )
        : null
    );
  },
  rt = () =>
    t.createElement(
      B,
      null,
      t.createElement("style", null, "\n        .modal-body {\n        padding: 0;}\n      "),
      t.createElement(at, null)
    ),
  nt = () =>
    t.createElement(
      "svg",
      {
        className: "tw-mt-[11px] tw-mr-3",
        width: "90",
        height: "90",
        viewBox: "0 0 90 90",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
      },
      t.createElement(
        "g",
        { "clip-path": "url(#clip0_726_174)" },
        t.createElement("path", {
          d: "M74.8813 5.7598H32.3797C30.0865 5.7598 27.8905 6.6706 26.2705 8.2906L8.29209 26.269C6.67209 27.889 5.76129 30.0886 5.76129 32.3782V66.2398C5.76129 71.0134 9.63129 74.8798 14.4013 74.8798H53.5189C49.3861 71.0026 46.8013 65.4982 46.8013 59.3998C46.8013 47.689 56.3305 38.1598 68.0413 38.1598C74.1397 38.1598 79.6441 40.7482 83.5213 44.8774V14.3998C83.5213 9.6298 79.6549 5.7598 74.8813 5.7598ZM30.9613 47.401H15.3625C14.0377 47.401 12.9613 46.3282 12.9613 44.9998C12.9613 43.6714 14.0341 42.5986 15.3625 42.5986H30.9613C32.2861 42.5986 33.3625 43.6714 33.3625 44.9998C33.3625 46.3282 32.2897 47.401 30.9613 47.401ZM47.7625 36.601H15.3625C14.0377 36.601 12.9613 35.5246 12.9613 34.1998C12.9613 32.875 14.0341 31.7986 15.3625 31.7986H47.7625C49.0873 31.7986 50.1637 32.8714 50.1637 34.1998C50.1637 35.5282 49.0909 36.601 47.7625 36.601Z",
          fill: "url(#paint0_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M68.04 43.92C59.5044 43.92 52.56 50.8644 52.56 59.4C52.56 67.9356 59.5044 74.88 68.04 74.88C76.5756 74.88 83.52 67.9356 83.52 59.4C83.52 50.8644 76.5756 43.92 68.04 43.92Z",
          fill: "url(#paint1_linear_726_174)",
        }),
        t.createElement("path", {
          d: "M77.1097 54.8399L77.333 54.5924L77.0855 54.3691L76.1392 53.5153L75.8918 53.292L75.6685 53.5395L65.0042 65.3591L60.908 61.2318L60.6732 60.9953L60.4366 61.2301L59.532 62.1279L59.2954 62.3627L59.5302 62.5993L64.8232 67.9324L65.0714 68.1824L65.3073 67.9209L77.1097 54.8399Z",
          fill: "black",
          stroke: "black",
          "stroke-width": "0.666667",
        })
      ),
      t.createElement(
        "defs",
        null,
        t.createElement(
          "linearGradient",
          {
            id: "paint0_linear_726_174",
            x1: "17.4953",
            y1: "8.72209",
            x2: "49.8151",
            y2: "86.0476",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "#E2CCFF" }),
          t.createElement("stop", { offset: "1", "stop-color": "#0D0D0D" })
        ),
        t.createElement(
          "linearGradient",
          {
            id: "paint1_linear_726_174",
            x1: "60.1618",
            y1: "49.4486",
            x2: "92.0893",
            y2: "99.8968",
            gradientUnits: "userSpaceOnUse",
          },
          t.createElement("stop", { "stop-color": "white" }),
          t.createElement("stop", { offset: "0.459251" }),
          t.createElement("stop", { offset: "0.643137" })
        ),
        t.createElement(
          "clipPath",
          { id: "clip0_726_174" },
          t.createElement("rect", { width: "90", height: "90", fill: "white" })
        )
      )
    ),
  lt = () => {
    const e = [
        {
          category: "1. Core Salesforce Platform Components",
          checks: [
            "Flow Builder with Case Creation Templates",
            "Process Builder with Loyalty Automation",
            "Custom Apex Classes for Business Logic",
            "Lightning Components for UI",
            "Experience Cloud Portal Configuration",
            "Custom Objects for Event Management",
            "Validation Rules and Triggers",
            "Platform Event Configurations",
          ],
        },
        {
          category: "2. Data Cloud Architecture",
          checks: [
            "Unified Profile Data Model",
            "CRM Data Stream Configuration",
            "S3 Data Ingestion Pipeline",
            "Identity Resolution Rules",
            "Real-time Sync Mechanisms",
            "Calculated Insights Framework",
            "Data Harmonization Rules",
            "Cross-object Relationship Maps",
          ],
        },
        {
          category: "3. Agentforce Implementation",
          checks: [
            "Atlas Reasoning Engine Configuration",
            "Agent Task Decomposition Rules",
            "Action Planning Framework",
            "Autonomous Operation Boundaries",
            "Platform-specific Guardrails",
            "Prompt Management System",
            "Agent Interaction Models",
            "Feedback Loop Implementation",
          ],
        },
        {
          category: "4. Integration Components",
          checks: [
            "Einstein Trust Layer Setup",
            "Databricks Connection Configuration",
            "External API Management",
            "Credit Card Loyalty Integration",
            "WhatsApp Channel Setup",
            "Messenger Integration",
            "Website Interaction Framework",
            "CRM Channel Orchestration",
          ],
        },
        {
          category: "5. Compliance Framework",
          checks: [
            "Data Residency Controls",
            "Cross-cloud Encryption",
            "Audit Trail System",
            "Data Masking Rules",
            "Access Control Framework",
            "Retention Policy Implementation",
            "Privacy Act 1988 Compliance Controls",
            "Security Monitoring System",
          ],
        },
      ],
      a = e.reduce((e, t) => e + t.checks.length, 0);
    return t.createElement(
      "div",
      { className: "component-container " },
      t.createElement(
        "div",
        { className: "tw-p-6 tw-px-32 tw-bg-[#09090B] tw-flex tw-flex-col" },
        t.createElement(
          "div",
          { className: "tw-h-[126px] tw-pl-24 tw-flex tw-items-center" },
          t.createElement(nt, null),
          t.createElement(
            "div",
            { className: "tw-flex tw-flex-col" },
            t.createElement(
              "p",
              { className: "tw-text-white tw-text-[20px] tw-font-medium tw-leading-[100%] tw-mb-1" },
              "Audit Certificate"
            ),
            t.createElement(
              "span",
              { className: "tw-text-white tw-text-[32px] tw-font-normal tw-leading-[100%] tw-mb-1" },
              "AI Ethics Principles and Privacy Act 1988"
            ),
            t.createElement(
              "p",
              { className: "tw-text-[#A1A1AA] tw-font-normal tw-text-[13px] tw-leading-[100%]" },
              "Last Completed 5 Sec Ago"
            )
          )
        ),
        t.createElement(
          "div",
          { className: "tw-bg-white/5 tw-p-6 tw-pt-8 rounded" },
          t.createElement(
            "div",
            { className: "tw-grid tw-grid-cols-3 tw-gap-4 tw-mb-6 tw-box-border" },
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background:
                      "linear-gradient(279.39deg,  rgba(59, 130, 246, 0.35) 3.45%, rgba(21, 21, 23, 0) 102.13%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    padding: "16px",
                    gap: "8px",
                  },
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(L, { size: 24, className: "tw-text-blue-500" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Controls Met")
                ),
                t.createElement(
                  "div",
                  null,
                  t.createElement("div", { className: "tw-text-[56px]  tw-text-blue-500" }, a)
                )
              )
            ),
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background: "linear-gradient(283.45deg, rgba(34, 197, 94, 0.35) 2.95%, rgba(21, 21, 23, 0) 62.89%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                    padding: "16px",
                    paddingBottom: 8,
                    gap: "8px",
                  },
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(R, { size: 24, className: "tw-text-green-500" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Audit Authority")
                ),
                t.createElement("div", { className: "tw-text-[32px]  tw-text-green-500" }, "OAIC")
              )
            ),
            t.createElement(
              "div",
              {
                style: {
                  border: "1px solid rgba(255, 255, 255, 0.05)",
                  borderRadius: "8px",
                  height: "142px",
                  filter: "drop-shadow(0px 1px 2px rgba(0, 0, 0, 0.05))",
                  overflow: "hidden",
                },
              },
              t.createElement(
                "div",
                {
                  style: {
                    background:
                      "linear-gradient(279.39deg, rgba(226, 204, 255, 0.35) 3.45%, rgba(21, 21, 23, 0) 102.13%)",
                    height: "100%",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-start",
                    paddingTop: "16px",
                    paddingBottom: 8,
                    gap: "8px",
                  },
                  className: "tw-px-9",
                },
                t.createElement(
                  "div",
                  {
                    className:
                      "tw-flex tw-items-start tw-gap-3 tw-border-b tw-border-white/5 tw-w-full tw-min-h-[40px]",
                  },
                  t.createElement(R, { size: 24, className: "tw-text-white" }),
                  t.createElement("div", { className: "tw-text-base tw-text-white tw-font-normal" }, "Registration")
                ),
                t.createElement(
                  "div",
                  { className: "tw-flex tw-flex-col tw-flex-grow tw-justify-center" },
                  t.createElement("span", { className: "tw-text-white tw-text-sm" }, "CID bafkr...aueq"),
                  t.createElement(
                    "span",
                    { className: "tw-text-white tw-text-sm" },
                    "HCS",
                    " ",
                    t.createElement(
                      "a",
                      { href: "https://hashscan.io/mainnet/transaction/1717101762.014321858", target: "_blank" },
                      "Oxe34...eb5e"
                    )
                  )
                )
              )
            )
          ),
          t.createElement(
            "div",
            { className: "tw-grid tw-grid-cols-2 tw-gap-4 tw-max-h-[800px] tw-overflow-auto" },
            e.map((e, a) =>
              t.createElement(
                "div",
                { key: a, className: "tw-p-4 tw-rounded-lg tw-border tw-border-[#27272A] tw-bg-[#D9D9D9]/5" },
                t.createElement(
                  "div",
                  { className: "tw-h-[40px]  tw-text-[#fafafa] tw-border-b tw-border-[#27272A]" },
                  e.category
                ),
                t.createElement(
                  "div",
                  { className: "tw-p-4" },
                  t.createElement(
                    "div",
                    { className: "tw-grid tw-gap-2" },
                    e.checks.map((e, a) =>
                      t.createElement(
                        "div",
                        { key: a, className: "tw-flex tw-items-center tw-gap-2" },
                        t.createElement(P, { size: 16, className: "tw-text-green-500" }),
                        t.createElement("span", { className: "tw-text-[14px] tw-text-[#A1A1AA]" }, e)
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    );
  };
export { rt as AgentPolicyPlaneApplication, lt as AgentProvisionCertificate };
//# sourceMappingURL=index.js.map
