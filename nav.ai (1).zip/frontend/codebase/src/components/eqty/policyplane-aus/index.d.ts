import React from "react";

declare const AgentPolicyPlaneApplication: () => React.JSX.Element;

declare const AgentProvisionCertificate: () => React.JSX.Element;

export { AgentPolicyPlaneApplication, AgentProvisionCertificate };
