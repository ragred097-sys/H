import { Card } from "react-bootstrap";

import type { ModuleSpecification } from "../../lib/Model";
import { getProviderLogo } from "../../utils/uiUtils";

export default function ModuleCard({ module }: { module: ModuleSpecification }) {
  return (
    <div className="p-2" key={module.id}>
      <Card className="mb-3 text-center text-light d-flex flex-column" style={{ minWidth: "400px", width: "auto" }}>
        <Card.Img
          variant="top"
          src={getProviderLogo(module.name)}
          style={{ height: "40px", objectFit: "contain" }}
          className="m-2"
        />
        <Card.Header>{module.name} </Card.Header>
        <Card.Body className="d-flex flex-column">
          <Card.Subtitle className="mb-2 text-muted"></Card.Subtitle>
        </Card.Body>
      </Card>
    </div>
  );
}
