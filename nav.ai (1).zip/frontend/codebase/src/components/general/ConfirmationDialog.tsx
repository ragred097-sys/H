import { Button, Modal } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import LoadingButton from "./LoadingButton/LoadingButton";
import { TranslationKeys } from "../../types/translation-keys";

export default function ConfirmationDialog({
  confirmationButtonLabel,
  confirmationQuestion,
  isConfirmationLoading,
  isWorkspaceDelete,
  onClose,
  onConfirm,
  show,
  variant,
}: {
  show: boolean;
  confirmationQuestion: React.ReactNode | string;
  confirmationButtonLabel?: string;
  onConfirm: () => void;
  onClose: () => void;
  variant?: string;
  isConfirmationLoading?: boolean;
  isWorkspaceDelete?: boolean;
}) {
  const { t } = useTranslation();
  return (
    <Modal show={show} centered onHide={onClose} backdrop={isWorkspaceDelete && "static"}>
      <Modal.Header closeButton className={isWorkspaceDelete ? "modal-header-danger" : ""}>
        <Modal.Title
          style={{
            ...{
              alignItems: "center",
              display: "flex",
              fontSize: "1.3em",
              height: "0.6em",
            },
            ...(isWorkspaceDelete ? { color: "rgb(255, 255, 255)" } : {}),
          }}
        >
          {t(TranslationKeys.HISTORY_CONFIRMATION)}
        </Modal.Title>
      </Modal.Header>
      <Modal.Body
        style={
          isWorkspaceDelete
            ? {
                alignItems: "center",
                display: "flex",
                flexDirection: "column",
              }
            : undefined
        }
      >
        {isWorkspaceDelete && (
          <i
            className="bi bi-exclamation-triangle-fill"
            style={{
              color: "rgb(220, 53, 69)",
              fontSize: "3em",
            }}
          ></i>
        )}
        {confirmationQuestion}
      </Modal.Body>
      <Modal.Footer>
        {isConfirmationLoading ? (
          <LoadingButton className={"btn btn-danger btn-sm"} />
        ) : (
          <Button variant={variant ? variant : "primary"} onClick={onConfirm} size="sm">
            {confirmationButtonLabel || "Ok"}
          </Button>
        )}
        <Button variant="secondary" onClick={onClose} size="sm">
          {t(TranslationKeys.HISTORY_CANCEL)}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
