import React from "react";

import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";

import { ColumnConfig, ConfigurableTable } from "./Table";
import { AccessRole } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";

interface RolesTableProps {
  roles: AccessRole[] | [];
  onEdit: (role: AccessRole) => void;
  onDelete: (role: AccessRole) => void;
  loading?: boolean;
}

const RolesTable: React.FC<RolesTableProps> = ({ loading, onDelete, onEdit, roles }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const goToDetails = (role: AccessRole) => {
    navigate(`/roles/${role.id}`);
  };

  // Table column configuration for cleaner data mapping
  const columnConfig: ColumnConfig<AccessRole>[] = [
    {
      extractor: (role: AccessRole) =>
        role.system ? (
          <div className="w-100 d-flex justify-content-center">
            <i className="bi bi-check-circle"></i>
          </div>
        ) : null,
      key: t(TranslationKeys.ROLES_SYSTEM),
    },
    {
      extractor: (role: AccessRole) => (
        <span style={{ cursor: "pointer" }} onClick={() => goToDetails(role)}>
          {role.name}
        </span>
      ),
      key: t(TranslationKeys.ROLES_ROLE),
    },
    {
      extractor: (role: AccessRole) => role.description,
      key: t(TranslationKeys.ROLES_DESCRIPTION),
    },
    {
      extractor: (role: AccessRole) =>
        !role.system ? (
          <div className="w-100 d-flex justify-content-center">
            <i
              className="bi bi-pencil-fill me-2"
              style={{ cursor: "pointer" }}
              onClick={() => onEdit(role)}
              title={t(TranslationKeys.ROLES_EDIT)}
            ></i>
            <i
              className="bi bi-trash-fill"
              style={{ color: "rgb(254, 47, 74)", cursor: "pointer" }}
              onClick={() => onDelete(role)}
              title={t(TranslationKeys.ROLES_DELETE)}
            ></i>
          </div>
        ) : null,
      key: t(TranslationKeys.TAGSTABLE_ACTION),
    },
  ];

  // Define sort value extraction callbacks for ConfigurableTable
  const columnSortExtractors = {
    [t(TranslationKeys.ROLES_DESCRIPTION)]: (role: AccessRole, _index: number) => role.description,
    [t(TranslationKeys.ROLES_ROLE)]: (role: AccessRole, _index: number) => role.name,
    [t(TranslationKeys.ROLES_SYSTEM)]: (role: AccessRole, _index: number) => (role.system ? 1 : 0), // Sort system roles first
  };

  if (roles?.length === 0) {
    return <p>{t(TranslationKeys.ROLES_NOROLE)}</p>;
  }

  return (
    <ConfigurableTable<AccessRole>
      loading={!!loading}
      data={roles}
      columnConfig={columnConfig}
      defaultSortColumn={t(TranslationKeys.ROLES_ROLE)}
      defaultSortOrder="asc"
      columnSortExtractors={columnSortExtractors}
    />
  );
};

export default RolesTable;
