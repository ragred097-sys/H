import React, { useRef, useState } from "react";

import { Identifiable, typeOf } from "../../lib/Model.ts";

interface DropZoneProps {
  onFilesDropped: (files: File[]) => void;
  onEntityDropped?: (data: Identifiable) => void;
  children: (props: { doAddFile: () => void }) => React.ReactNode;
}

const DropZone = ({ children, onEntityDropped, onFilesDropped }: DropZoneProps): React.ReactElement => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const openAddFileDialog = () => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const droppedFiles = event.target.files ? Array.from(event.target.files) : [];
    onFilesDropped(droppedFiles);
  };

  const handleDrop = (event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);

    if (event.dataTransfer.files && event.dataTransfer.files.length > 0) {
      const droppedFiles = Array.from(event.dataTransfer.files);
      onFilesDropped(droppedFiles);
    } else if (onEntityDropped) {
      const data = event.dataTransfer.getData("custom/entity");
      if (data) {
        const entity = JSON.parse(data);
        // if it hase a type we know it is a regular entity
        if (typeOf(entity)) {
          onEntityDropped(entity as unknown as Identifiable);
        }
      }
    }
  };

  const handlePaste = (event: React.ClipboardEvent<HTMLDivElement>) => {
    const pastedItems = event.clipboardData.files;
    if (pastedItems.length > 0) {
      const pastedFiles = Array.from(pastedItems);
      onFilesDropped(pastedFiles);
    }
  };

  return (
    <div
      onDragOver={(event) => {
        event.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDragEnd={() => setIsDragging(false)}
      onDrop={handleDrop}
      onPaste={handlePaste}
      style={{
        borderColor: isDragging ? "var(--primary-color)" : "transparent",
        borderStyle: isDragging ? "dashed" : undefined,
      }}
      // allow focus to use paste via keyboard
      tabIndex={0}
    >
      {children({ doAddFile: openAddFileDialog })}
      <input ref={inputRef} type="file" style={{ display: "none" }} onChange={handleFileSelect} multiple />
    </div>
  );
};

export default DropZone;
