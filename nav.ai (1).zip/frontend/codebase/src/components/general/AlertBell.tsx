import "bootstrap-icons/font/bootstrap-icons.css";

const NotificationBadge = ({ count }: { count: number }) => {
  return (
    <div className="pe-4 " data-testid="alert-bell">
      <div className="notification-badge-container">
        <i className="bi bi-bell text-light"></i>

        {count > 0 && <span className="badge">{count}</span>}
      </div>
    </div>
  );
};

export default NotificationBadge;
