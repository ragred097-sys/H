import { useMemo, useState } from "react";

import { Table } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { DataSource, Module, ModuleType } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { ModuleService } from "./../../services/ModuleService";
import ModuleTable from "./ModuleTable";
import { useNotification } from "./NotificationProvider";

export default function DataSourceTable({ data }: { data: DataSource[] | undefined }) {
  const [fileStores, setFileStores] = useState<Module[]>();
  const [embeddings, setEmbeddings] = useState<Module[]>();
  const [vectorStores, setVectorStores] = useState<Module[]>();
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  useMemo(() => {
    if (data) {
      ModuleService.getModulesByType(ModuleType.FILE_STORAGE)
        .then((res) => setFileStores(res))
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULEBYTYPEFILESTORAGE), err as Error);
        });
      ModuleService.getModulesByType(ModuleType.EMBEDDING_MODEL)
        .then((res) => setEmbeddings(res))
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULEBYTYPEEMBD), err as Error);
        });
      ModuleService.getModulesByType(ModuleType.VECTOR_STORE)
        .then((res) => setVectorStores(res))
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULEBYTYPEVECTOR), err as Error);
        });
    }
  }, [data]);

  const dataSourceTable = data?.map((d) => {
    return (
      <div>
        File Information
        <Table size="sm" bordered responsive striped style={{ fontSize: "0.8em" }}>
          <tbody>
            {d?.ingestedFiles?.map((f) => {
              return (
                <tr key={f.fileName}>
                  <td>{f.fileName}</td>
                  <td>{f.mimeType}</td>
                  <td>{f?.creator?.name}</td>
                </tr>
              );
            })}
          </tbody>
        </Table>
        <ModuleTable module={fileStores?.find((el) => el.id === d.fileStorageId)} />
        <ModuleTable module={embeddings?.find((el) => el.id === d.embeddingModelId)} />
        <ModuleTable module={vectorStores?.find((el) => el.id === d.vectorStoreId)} />
      </div>
    );
  });
  return <div className="ps-3 pt-3">{dataSourceTable}</div>;
}
