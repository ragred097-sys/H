export const Circle = () => {
  return (
    <svg width="36" height="35" viewBox="0 0 29 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="28.6294" height="28" rx="14" fill="var(--secondary-color)" />
      <g filter="url(#filter0_d_64808_14874)">
        <circle
          cx="7.33653"
          cy="7.33653"
          r="7.83653"
          transform="matrix(0.714921 -0.699205 0.714921 0.699205 3.22498 13.4342)"
          stroke="url(#paint0_linear_64808_14874)"
        />
        <circle
          cx="8.49493"
          cy="8.49493"
          r="8.99493"
          transform="matrix(0.714921 -0.699205 0.714921 0.699205 2.14722 14)"
          stroke="url(#paint1_linear_64808_14874)"
        />
        <path
          d="M18.3726 10.3728C20.7863 12.7335 20.9785 16.2663 18.6891 18.5054C16.3599 20.7834 12.3504 20.9037 9.97767 18.5831C7.60966 16.2672 7.76201 12.7716 10.0962 10.4887C12.4304 8.20583 16.0045 8.05682 18.3726 10.3728Z"
          fill="var(--secondary-color)"
          stroke="url(#paint2_linear_64808_14874)"
        />
      </g>
      <defs>
        <filter
          id="filter0_d_64808_14874"
          x="2.69373"
          y="2.61121"
          width="23.1997"
          height="22.7776"
          filterUnits="userSpaceOnUse"
          colorInterpolationFilters="sRGB"
        >
          <feFlood floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            in="SourceAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
            result="hardAlpha"
          />
          <feOffset />
          <feGaussianBlur stdDeviation="1" />
          <feComposite in2="hardAlpha" operator="out" />
          <feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0.683333 0 0 0 0 1 0 0 0 1 0" />
          <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_64808_14874" />
          <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_64808_14874" result="shape" />
        </filter>
        <linearGradient
          id="paint0_linear_64808_14874"
          x1="7.33653"
          y1="0"
          x2="7.33653"
          y2="14.6731"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#2EA8FF" />
          <stop offset="1" stopColor="#80CAFF" />
        </linearGradient>
        <linearGradient
          id="paint1_linear_64808_14874"
          x1="8.49493"
          y1="0"
          x2="8.49493"
          y2="16.9899"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#2EA8FF" />
          <stop offset="1" stopColor="#80CAFF" />
        </linearGradient>
        <linearGradient
          id="paint2_linear_64808_14874"
          x1="9.73874"
          y1="10.1391"
          x2="18.6461"
          y2="19.2467"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#2EA8FF" />
          <stop offset="1" stopColor="#80CAFF" />
        </linearGradient>
      </defs>
    </svg>
  );
};
