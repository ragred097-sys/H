import { useCallback, useEffect, useState } from "react";

import {
  Background,
  type Edge,
  MarkerType,
  MiniMap,
  type Node,
  type OnEdgesChange,
  type OnNodesChange,
  PanOnScrollMode,
  ReactFlow,
  applyEdgeChanges,
  applyNodeChanges,
  useNodesState,
  useReactFlow,
} from "@xyflow/react";

import { CustomAgentEntityEdge } from "./agent-workflow/CustomEdges";
import { CustomAgentEntityNode } from "./agent-workflow/CustomNodes";
import { layoutNodes } from "./agent-workflow/GraphTools";
import {
  Agent,
  AgentEntityActions,
  AgentEntityFlowRelation,
  Assistant,
  DataSource,
  SystemInstruction,
  TypeName,
  flowDirection,
} from "../../lib/Model";
import { TOOL_PREFIX } from "../../utils/constants";

const EDGE_TYPES = {
  removable: CustomAgentEntityEdge,
};

const NODE_TYPES = {
  customNode: CustomAgentEntityNode,
};

// function to construct edges
function getEdgesFor(
  agents: Assistant[],
  utilAgents: Agent[],
  flowSubject: TypeName.SystemInstruction | TypeName.DataSource,
  onRemoveEdge?: (relation: AgentEntityFlowRelation) => void
) {
  let edges: Edge[] = [];

  if (agents?.length || utilAgents?.length) {
    const propertyToFetchEntities = flowSubject === TypeName.DataSource ? "dataSourceIds" : "systemInstructionIds";

    agents.forEach((entity) => {
      const agentEntityLinks = (entity[propertyToFetchEntities] || [])?.map((toEntity) => {
        const newRelation = {
          from: {
            id: entity.id,
            type: TypeName.Assistant,
          },
          grantData: {
            agentGrant: entity?.accessPermission,
            agentId: entity?.creator?.id,
          },
          to: {
            id: toEntity,
            type: flowSubject,
          },
        };
        return {
          data: {
            onRemove: onRemoveEdge,
            subject: newRelation,
          },
          id: entity.id + "-" + toEntity,
          markerEnd: {
            color: "rgba(128,190,235,0.75)",
            height: 20,
            type: MarkerType.ArrowClosed,
            width: 50,
          },
          source: entity.id,
          style: {
            stroke: "rgba(128,190,235,0.75)",
            strokeWidth: 2,
          },
          target: toEntity,
          type: "removable",
        };
      });
      edges = agentEntityLinks?.length > 0 ? [...edges, ...agentEntityLinks] : [...edges];
    });

    utilAgents &&
      utilAgents.forEach((entity) => {
        const utilAgentEntityLinks = (entity["systemInstructionIds"] || [])?.map((toEntity) => {
          const newRelation = {
            from: {
              id: entity.id,
              type: TypeName.Agent,
            },
            grantData: {
              agentGrant: entity?.accessPermission,
              agentId: entity?.creator?.id,
            },
            to: {
              id: toEntity,
              type: flowSubject,
            },
          };
          return {
            data: {
              onRemove: onRemoveEdge,
              subject: newRelation,
            },
            id: entity.id + "-" + toEntity,
            markerEnd: {
              color: "rgba(128,190,235,0.75)",
              height: 20,
              type: MarkerType.ArrowClosed,
              width: 50,
            },
            source: entity.id,
            style: {
              stroke: "rgba(128,190,235,0.75)",
              strokeWidth: 2,
            },
            target: toEntity,
            type: "removable",
          };
        });
        edges = utilAgentEntityLinks?.length > 0 ? [...edges, ...utilAgentEntityLinks] : [...edges];
      });
  }

  return edges;
}

interface AgentEntityFlowProps {
  agents: Assistant[];
  utilAgents?: Agent[];
  entities: (SystemInstruction | DataSource)[];
  flowSubject: TypeName.SystemInstruction | TypeName.DataSource;
  direction?: flowDirection.HORIZONTAL | flowDirection.VERTICAL;
  onInfo?: (entity: SystemInstruction | DataSource) => void;
  onEdit?: (entity: SystemInstruction | DataSource) => void;
  onDelete?: (entity: SystemInstruction | DataSource) => void;
  onRemoveLink?: (relation: AgentEntityFlowRelation) => void;
  onLink?: (entity?: SystemInstruction | DataSource) => void;
  onUpload?: (entity: DataSource) => void;
  onViewDocuments?: (entity: DataSource) => void;
  onAddEntity?: (entity: Assistant | Agent) => void;
}

export default function AgentEntityFlow({
  agents,
  direction = flowDirection.HORIZONTAL,
  entities,
  flowSubject,
  onAddEntity,
  onDelete,
  onEdit,
  onInfo,
  onRemoveLink,
  onUpload,
  onViewDocuments,
  utilAgents,
}: AgentEntityFlowProps) {
  const { setEdges } = useReactFlow();
  const [nodes, setNodes] = useNodesState<Node>([]);
  const [edges, setLocalEdges] = useState<Edge[]>([]);

  // side effect to build nodes and edges
  useEffect(() => {
    let newNodes: Node[] = [];
    let newEdges: Edge[] = [];
    if (agents?.length || utilAgents?.length) {
      newNodes = [
        ...newNodes,
        ...agents.map((agent) => ({
          data: {
            actions: [AgentEntityActions.AddEntity],
            direction,
            onAddEntity,
            subject: agent,
            type: TypeName.Assistant,
          },
          id: agent.id,
          position: { x: 0, y: 0 },
          type: "customNode",
        })),
      ];
      if (utilAgents && utilAgents.length > 0) {
        newNodes = [
          ...newNodes,
          ...utilAgents.map((agent) => ({
            data: {
              actions: [AgentEntityActions.AddEntity],
              direction,
              onAddEntity,
              subject: agent,
              type: TypeName.Agent,
            },
            id: agent.id,
            position: { x: 0, y: 0 },
            type: "customNode",
          })),
        ];
      }

      const propertyToFetchEntities = flowSubject === TypeName.DataSource ? "dataSourceIds" : "systemInstructionIds";

      agents.forEach((agent) => {
        agent[propertyToFetchEntities]?.forEach((entityId) => {
          const entity = entities.find((e) => e.id === entityId);
          if (entity) {
            newNodes.push({
              data: {
                actions:
                  flowSubject === TypeName.DataSource
                    ? [
                        AgentEntityActions.ViewDocuments,
                        AgentEntityActions.Upload,
                        AgentEntityActions.Edit,
                        AgentEntityActions.Info,
                      ]
                    : entity?.name?.startsWith(TOOL_PREFIX)
                      ? [AgentEntityActions.Info]
                      : [AgentEntityActions.Edit, AgentEntityActions.Delete, AgentEntityActions.Info],
                direction,
                onDelete,
                onEdit,
                onInfo,
                onUpload,
                onViewDocuments,
                subject: entity,
                type: flowSubject,
              },
              id: entityId,
              position: { x: 0, y: 0 },
              type: "customNode",
            });
          }
        });
      });

      utilAgents &&
        utilAgents.forEach((agent) => {
          agent["systemInstructionIds"]?.forEach((entityId) => {
            const entity = entities.find((e) => e.id === entityId);
            if (entity) {
              newNodes.push({
                data: {
                  actions:
                    flowSubject === TypeName.DataSource
                      ? [
                          AgentEntityActions.ViewDocuments,
                          AgentEntityActions.Upload,
                          AgentEntityActions.Edit,
                          AgentEntityActions.Info,
                        ]
                      : entity?.name?.startsWith(TOOL_PREFIX)
                        ? [AgentEntityActions.Info]
                        : [AgentEntityActions.Edit, AgentEntityActions.Delete, AgentEntityActions.Info],
                  direction,
                  onDelete,
                  onEdit,
                  onInfo,
                  onUpload,
                  onViewDocuments,
                  subject: entity,
                  type: flowSubject,
                },
                id: entityId,
                position: { x: 0, y: 0 },
                type: "customNode",
              });
            }
          });
        });

      newEdges = getEdgesFor(agents, utilAgents ?? [], flowSubject, onRemoveLink);

      const layoutedNodes = layoutNodes(newNodes, newEdges, {
        horizontal: direction !== flowDirection.HORIZONTAL,
        marginX: 40,
        marginY: 5,
        nodeHeight: 90,
        nodeSpacing: 100,
        nodeWidth: 180,
        rankSpacing: 150,
      });
      setNodes(layoutedNodes);
      setLocalEdges(newEdges);
      setEdges(newEdges);
    }
  }, [agents, utilAgents, entities, setEdges]);

  // Sync edges with ReactFlow
  useEffect(() => {
    const newEdges = getEdgesFor(agents, utilAgents ?? [], flowSubject, onRemoveLink);
    setEdges(newEdges);
  }, [agents, utilAgents, setEdges]);

  // callback when node gets changed
  const onNodesChange: OnNodesChange = useCallback(
    (changes) => {
      setNodes((nds) => applyNodeChanges(changes, nds));
    },
    [setNodes]
  );

  // callback when edge gets changed
  const onEdgesChange: OnEdgesChange = useCallback(
    (changes) => {
      setEdges((eds) => applyEdgeChanges(changes, eds));
    },
    [setEdges]
  );

  return (
    <>
      <div
        style={{
          flexGrow: 1,
          height: "70%",
          margin: "0 auto",
          minHeight: 200,
          width: "100%",
        }}
      >
        <ReactFlow
          id={`agent-entity-flow-${flowSubject}`}
          fitView
          nodes={nodes}
          edges={edges}
          nodeTypes={NODE_TYPES}
          edgeTypes={EDGE_TYPES}
          onInit={(instance) => instance.fitView()}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          snapToGrid={true}
          snapGrid={[15, 15]}
          onlyRenderVisibleElements={false}
          panOnScroll={true}
          panOnScrollMode={PanOnScrollMode.Free}
          panOnDrag={true}
          selectionOnDrag={true}
          elementsSelectable={true}
          nodesConnectable={false}
        >
          <Background id={`agent-entity-flow-${flowSubject}-background`} />
          <MiniMap
            maskColor={`var(--bs-skeleton-gradient-color)`}
            bgColor={`var(--bs-accordion-skeleton-header-color)`}
            nodeColor={`white`}
            nodeStrokeWidth={3}
            zoomable
            pannable
          />
        </ReactFlow>
      </div>
    </>
  );
}
