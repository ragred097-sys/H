import { useEffect, useRef, useState } from "react";

import { Col, Form, Row } from "react-bootstrap";
import { Typeahead, TypeaheadRef } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";
import { useTranslation } from "react-i18next";

import { AccessRole, SYSTEM_USER_ID, User, UserAccessRoleMapping } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { Subject } from "../../utils/objectUtils";
import { AccessControlService } from "./../../services/AccessControlService";
import { UserService } from "./../../services/UserService";
import { useNotification } from "./NotificationProvider";
import { ColumnConfig, ConfigurableTable } from "./Table";

export default function DirectMembers({ role }: { role: AccessRole }) {
  const { openErrorNotification, openNotification } = useNotification();
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [addUserLoader, setAddUserLoader] = useState<boolean>(false);
  const [currentUserToAccessRoleMappings, setCurrentUserToAccessRoleMappings] = useState<UserAccessRoleMapping[]>([]);
  const [tableLoading, setTableLoading] = useState<boolean>(false);
  const typeaheadRef = useRef<TypeaheadRef>(null);
  const [selectedUserToAdd, setSelectedUserToAdd] = useState<User | null>(null);
  const [currentRoleSubject, setCurrentRoleSubject] = useState<undefined | Subject<AccessRole, "select">>();
  const [availableUsers, setAvailableUsers] = useState<User[]>([]);
  const { t } = useTranslation();

  const fetchUserToAccessRoleMappings = async (role: AccessRole) => {
    setTableLoading(true);
    try {
      const userToAccessRoleMappings = await AccessControlService.getUserToAccessRoleMappings(role);
      setCurrentUserToAccessRoleMappings(userToAccessRoleMappings);
    } catch (err) {
      openErrorNotification(t(TranslationKeys.ROLES_FETCHUSERROLEMAPPINGSERROR, { role: role.name }), err as Error);
    } finally {
      setTableLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const users = await UserService.getUsers();
      setAvailableUsers(users.filter((_user) => _user.id !== "0"));
    } catch (err) {
      openErrorNotification(t(TranslationKeys.ROLES_FETCHUSERSERROR), err as Error);
    }
  };

  useEffect(() => {
    fetchUsers();
    if (role) {
      setCurrentRoleSubject({
        action: "select",
        subject: role,
      });
      fetchUserToAccessRoleMappings(role);
    }
  }, [role]);

  const onDeleteUserToAccessRoleMapping = async (
    mapping: UserAccessRoleMapping
  ): Promise<UserAccessRoleMapping | undefined> => {
    setLoadingId(mapping.user.id);
    return AccessControlService.deleteUserToAccessRoleMapping(mapping)
      .then((deletedMapping) => {
        setCurrentUserToAccessRoleMappings((prevMappings) => prevMappings.filter((e) => e.id !== deletedMapping.id));
        openNotification(t(TranslationKeys.ROLES_DELETEUSERFROMROLESUCCESS), "primary");
        fetchUserToAccessRoleMappings(role);
        setLoadingId(null);
        return deletedMapping;
      })
      .catch((error) => {
        openErrorNotification(t(TranslationKeys.ROLES_DELETEUSERFROMROLEERROR), error as Error);
        setLoadingId(null);
        return undefined;
      });
  };

  const onCreateUserToAccessRoleMapping = async (
    selectedUserToAdd: User,
    accessRole: AccessRole
  ): Promise<UserAccessRoleMapping | undefined> => {
    setAddUserLoader(true);
    return AccessControlService.createUserToAccessRoleMapping({
      applicationAccessRole: accessRole,
      user: selectedUserToAdd,
    } as UserAccessRoleMapping)
      .then((createdMapping) => {
        setCurrentUserToAccessRoleMappings([...currentUserToAccessRoleMappings, createdMapping]);
        typeaheadRef.current?.clear();
        setSelectedUserToAdd(null);
        openNotification(t(TranslationKeys.ROLES_ADDUSERTOROLESUCCESS), "primary");
        setAddUserLoader(false);
        return createdMapping;
      })
      .catch((error) => {
        openErrorNotification(t(TranslationKeys.ROLES_ADDUSERTOROLEERROR), error as Error);
        setAddUserLoader(false);
        return undefined;
      });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e?.preventDefault();
    if (selectedUserToAdd) {
      onCreateUserToAccessRoleMapping(selectedUserToAdd, currentRoleSubject?.subject as AccessRole);
    }
  };

  // Table column configuration for cleaner data mapping
  const columnConfig: ColumnConfig<UserAccessRoleMapping>[] = [
    {
      extractor: (mapping: UserAccessRoleMapping) => mapping.user.name,
      key: t(TranslationKeys.ROLES_USERNAME),
    },
    {
      extractor: (mapping: UserAccessRoleMapping) => mapping.user.email,
      key: t(TranslationKeys.ROLES_EMAIL),
    },
    {
      extractor: (mapping: UserAccessRoleMapping) =>
        mapping.applicationAccessRole.system && mapping.creator.id == SYSTEM_USER_ID ? undefined : loadingId ==
          mapping.user.id ? (
          <button className="btn btn-danger" type="button" disabled>
            <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            &nbsp;{t(TranslationKeys.ROLES_LOADING)}
          </button>
        ) : (
          <button
            type="button"
            onClick={(e) => {
              e?.stopPropagation();
              onDeleteUserToAccessRoleMapping(mapping);
            }}
            className="text-light btn btn-danger btn-sm"
          >
            <i className="bi bi-trash-fill text-white me-1"></i>
            {t(TranslationKeys.ROLES_REMOVEUSER)}
          </button>
        ),
      key: "",
    },
  ];

  return (
    <div>
      <div className="d-flex align-items-center mb-2">
        <Form onSubmit={handleSubmit} className="p-2" style={{ width: "50%" }}>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="title">
                <Typeahead
                  id="user-typeahead"
                  labelKey={"name"}
                  renderMenuItemChildren={(option) => {
                    const data = option as User;
                    return (
                      <>
                        <i className="bi bi-person me-1" style={{ float: "left" }}></i>
                        <div className="col-lg-4">
                          {data.name}
                          <div>
                            <small>{data.email}</small>
                          </div>
                        </div>
                      </>
                    );
                  }}
                  ref={typeaheadRef}
                  options={availableUsers}
                  placeholder={t(TranslationKeys.ROLES_SELECTUSERPLACEHOLDER)}
                  onChange={(usersObj) => {
                    setSelectedUserToAdd(usersObj[0] as User);
                  }}
                />
              </Form.Group>
            </Col>
            <Col>
              {addUserLoader ? (
                <button className="btn btn-primary" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.ROLES_LOADING)}
                </button>
              ) : (
                <button type="submit" className="text-light btn btn-primary" disabled={selectedUserToAdd == null}>
                  <i className="bi bi-plus-lg text-white me-1"></i>
                  {t(TranslationKeys.ROLES_ADDUSER)}
                </button>
              )}
            </Col>
          </Row>
        </Form>
      </div>
      <ConfigurableTable<UserAccessRoleMapping>
        loading={tableLoading}
        data={currentUserToAccessRoleMappings}
        columnConfig={columnConfig}
        defaultSortColumn={t(TranslationKeys.ROLES_USERNAME)}
        defaultSortOrder="asc"
      />
      {!tableLoading && currentUserToAccessRoleMappings.length === 0 && (
        <div className="mt-3 text-center">{t(TranslationKeys.ROLES_NODATAFOUND)}</div>
      )}
    </div>
  );
}
