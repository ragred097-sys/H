import React from "react";

interface FieldsSkeletonProps {
  count: number;
}

const FieldsSkeleton: React.FC<FieldsSkeletonProps> = ({ count }) => (
  <>
    {Array.from({ length: count }).map((_, i) => (
      <div className="mb-3" key={i}>
        <div className="skeleton skeleton-cell" style={{ height: 20, marginBottom: 8, width: "40%" }} />
        <div className="skeleton" style={{ borderRadius: 4, height: 36, width: "100%" }} />
      </div>
    ))}
  </>
);

export default FieldsSkeleton;
