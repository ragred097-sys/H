import { useEffect, useState } from "react";

import { Button } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Agent, AgentWorkflow, Assistant, Workspace } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { ApplicationService } from "./../../services/ApplicationService";
import { WorkspaceService } from "./../../services/WorkspaceService";
import ConfirmationDialog from "./ConfirmationDialog";
import LoadingButton from "./LoadingButton/LoadingButton";
import { useNotification } from "./NotificationProvider";
import TableComponent from "./Table";

interface DeleteWorkspaceProps {
  workspace: Workspace | null;
  handleClose: () => void;
  onDelete?: (id: string) => void;
  updateTrigger?: () => void;
  handleWorkspaceClose: () => void;
}
function DeleteWorkSpace({ handleClose, handleWorkspaceClose, updateTrigger, workspace }: DeleteWorkspaceProps) {
  const [superAgents, setSuperAgents] = useState<AgentWorkflow[]>([]);
  const [assistants, setAssistants] = useState<Assistant[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);

  const [loading, setLoading] = useState({
    agents: false,
    superAgents: false,
    utilityAgents: false,
  });
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();

  useEffect(() => {
    fetchSuperAgents();
    fetchAssistants();
    fetchAgents();
    // eslint-disable-next-line
  }, []);
  async function fetchSuperAgents() {
    setLoading((prev) => ({ ...prev, agents: true }));
    try {
      if (workspace) {
        const result = await WorkspaceService.getWorkspaceAgentWorkflows(workspace);
        setSuperAgents(result);
      }
    } catch {
      //error
    } finally {
      setLoading((prev) => ({ ...prev, agents: false }));
    }
  }
  async function fetchAssistants() {
    setLoading((prev) => ({ ...prev, superAgents: true }));
    try {
      if (workspace) {
        const result = await WorkspaceService.getWorkspaceAssistants(workspace);
        setAssistants(result);
      }
    } catch {
      //error
    } finally {
      setLoading((prev) => ({ ...prev, superAgents: false }));
    }
  }
  async function fetchAgents() {
    setLoading((prev) => ({ ...prev, utilityAgents: true }));
    try {
      if (workspace) {
        const result = await WorkspaceService.getWorkspaceAgents(workspace);
        setAgents(result);
      }
    } catch {
      //error
    } finally {
      setLoading((prev) => ({ ...prev, utilityAgents: false }));
    }
  }
  async function handleDelete() {
    if ((superAgents.length > 0 || assistants.length > 0 || workspace?.sharedWithUsers?.length) && workspace?.id) {
      setShowConfirmation(true);
    } else {
      deleteWorkspace();
    }
  }
  async function deleteWorkspace() {
    try {
      setDeleteLoading(true);
      if (workspace?.id) {
        await ApplicationService.recursiveDelete(workspace?.__type_name, workspace?.id);
        openNotification(t(TranslationKeys.MESSAGES_DELETEWORKSPACESUCCESS), `primary`);
      }
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETEWORKSPACE), error as Error);
    } finally {
      setDeleteLoading(false);
      handleClose();
      updateTrigger?.();
    }
  }
  //soft delete
  async function softDelete() {
    if (!workspace?.id) {
      console.error("Workspace ID is missing.");
      return;
    } else {
      deleteWorkspace();
    }
  }
  //get the maximum number to set the row for all columns
  const maxRow = Math.max(
    workspace?.sharedWithUsers?.length || 0,
    assistants.length,
    superAgents.length,
    agents.length
  );
  //show modified entities in heading
  const tableHeadingEntities = {
    [t(TranslationKeys.MESSAGES_AGENTSWS, "Agents")]: assistants?.length !== 0,
    [t(TranslationKeys.MESSAGES_SHAREUSERSWS, "Shared with Users")]:
      Array.isArray(workspace?.sharedWithUsers) && workspace?.sharedWithUsers.length > 0,
    [t(TranslationKeys.MESSAGES_SUPERAGENTSWS, "Super Agents")]: superAgents?.length !== 0,
    [t(TranslationKeys.MESSAGES_UTILITYAGENTSWS, "Utility Agents")]: agents?.length !== 0,
  };
  const tableData = () => {
    const associatedDataTitles = columnsHeading();
    const data: { [key: string]: string[] }[] = [];
    associatedDataTitles.forEach((title) => {
      switch (title) {
        case t(TranslationKeys.MESSAGES_SHAREUSERSWS, "Shared with Users"):
          data.push({ [title]: workspace?.sharedWithUsers || [] });
          break;
        case t(TranslationKeys.MESSAGES_SUPERAGENTSWS, "Super Agents"):
          data.push({ [title]: superAgents.map((item) => item?.name) });
          break;
        case t(TranslationKeys.MESSAGES_AGENTSWS, "Agents"):
          data.push({ [title]: assistants.map((item) => item?.name) });
          break;
        case t(TranslationKeys.MESSAGES_UTILITYAGENTSWS, "Utility Agents"):
          data.push({ [title]: agents?.map((item) => item?.name) });
          break;
        default:
          break;
      }
    });
    return data;
  };
  const columnsHeading = () => {
    const tableHead = [
      workspace?.sharedWithUsers?.length && t(TranslationKeys.MESSAGES_SHAREUSERSWS, "Shared with Users"),
      superAgents.length && t(TranslationKeys.MESSAGES_SUPERAGENTSWS, "Super Agents"),
      assistants && assistants.length && t(TranslationKeys.MESSAGES_AGENTSWS, "Agents"),
      agents && agents.length && t(TranslationKeys.MESSAGES_UTILITYAGENTSWS, "Utility Agents"),
    ];
    return tableHead.filter(Boolean) as string[];
  };

  return (
    <div>
      <div className="d-flex flex-row">
        <p>{t(TranslationKeys.MESSAGES_DELETEWORKSPACECONFIRM, { workspaceName: workspace?.name })}</p>
      </div>
      {Object.values(tableHeadingEntities)?.some((value) => value === true) && (
        <>
          <p>
            {t(TranslationKeys.MESSAGES_DELETEWORKSPACEASSOCIATED, {
              entityItems: Object.entries(tableHeadingEntities)
                .filter(([, value]) => value)
                .map(([key]) => key)
                .reduce((acc, curr, index, arr) => {
                  if (arr.length === 1) return curr;
                  if (index === arr.length - 1) return `${acc} and ${curr}`;
                  return `${acc}, ${curr}`;
                }),
            })}
          </p>

          <TableComponent
            loading={loading.agents || loading.superAgents || loading.utilityAgents}
            maxRow={maxRow}
            tableColumnHeadings={columnsHeading()}
            tableData={tableData()}
          />
        </>
      )}
      <div className="d-flex flex-row justify-content-end mt-3">
        {deleteLoading && showConfirmation == false ? (
          <LoadingButton className={"btn btn-danger me-4"} />
        ) : (
          <Button className="me-4" variant="danger" type="button" onClick={() => handleDelete()}>
            {t(TranslationKeys.MESSAGES_DELETE)}
          </Button>
        )}
        <Button className="me-4" variant="secondary" type="button" onClick={handleWorkspaceClose}>
          {t(TranslationKeys.MESSAGES_CANCEL)}
        </Button>
      </div>
      {showConfirmation && (
        <ConfirmationDialog
          show={showConfirmation}
          confirmationQuestion={t(TranslationKeys.MESSAGES_CONFIRMDELETECHAT)}
          confirmationButtonLabel={t(TranslationKeys.MESSAGES_CONFIRMDELETEYES)}
          onConfirm={softDelete}
          onClose={() => {
            setShowConfirmation(false);
          }}
          variant="danger"
          isConfirmationLoading={deleteLoading}
          isWorkspaceDelete={true}
        />
      )}
    </div>
  );
}

export default DeleteWorkSpace;
