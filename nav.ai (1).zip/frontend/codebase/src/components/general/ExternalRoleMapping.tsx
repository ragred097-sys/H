import { useEffect, useState } from "react";

import { Col, Form, Row } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { AccessRole, ExternalRoleAccessRoleMapping, SYSTEM_USER_ID } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { Subject } from "../../utils/objectUtils";
import { AccessControlService } from "./../../services/AccessControlService";
import { useNotification } from "./NotificationProvider";
import { ColumnConfig, ConfigurableTable } from "./Table";

export default function ExternalRoleMapping({ role }: { role: AccessRole }) {
  const { openErrorNotification, openNotification } = useNotification();
  const [addRoleLoader, setAddRoleLoader] = useState<boolean>(false);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [tableLoading, setTableLoading] = useState<boolean>(false);
  const [currentExternalRoleToAccessRoleMappings, setCurrentExternalRoleToAccessRoleMappings] = useState<
    ExternalRoleAccessRoleMapping[]
  >([]);
  const [newExternalRoleToAccessRoleMapping, setNewExternalRoleToAccessRoleMapping] =
    useState<ExternalRoleAccessRoleMapping | null>(null);
  const [currentRoleSubject, setCurrentRoleSubject] = useState<undefined | Subject<AccessRole, "select">>();
  const { t } = useTranslation();

  const fetchExternalRoleMappings = async (role: AccessRole) => {
    setTableLoading(true);
    try {
      const externalRoleMappings = await AccessControlService.getExternalRoleToAccessRoleMappings(role);
      setCurrentExternalRoleToAccessRoleMappings(externalRoleMappings);
    } catch (err) {
      openErrorNotification(t(TranslationKeys.ROLES_FETCHEXTERNALROLEMAPPINGSERROR), err as Error);
    } finally {
      setTableLoading(false);
    }
  };

  useEffect(() => {
    if (role) {
      setCurrentRoleSubject({
        action: "select",
        subject: role,
      });
      fetchExternalRoleMappings(role);
    }
  }, [role]);

  const onCreateExternalRoleToAccessRoleMapping = async (
    mapping: ExternalRoleAccessRoleMapping | null
  ): Promise<ExternalRoleAccessRoleMapping | undefined | null> => {
    setAddRoleLoader(true);
    if (mapping != null) {
      return AccessControlService.createExternalRoleToAccessRoleMapping(mapping)
        .then((createdMapping) => {
          setCurrentExternalRoleToAccessRoleMappings([...currentExternalRoleToAccessRoleMappings, createdMapping]);
          setNewExternalRoleToAccessRoleMapping(null);
          openNotification(t(TranslationKeys.ROLES_CREATEEXTERNALROLEMAPPINGSUCCESS), "primary");
          fetchExternalRoleMappings(role);
          setAddRoleLoader(false);
          return createdMapping;
        })
        .catch((error) => {
          openErrorNotification(t(TranslationKeys.ROLES_CREATEEXTERNALROLEMAPPINGERROR), error as Error);
          setAddRoleLoader(false);
          return undefined;
        });
    }
    return null;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e?.preventDefault();
    onCreateExternalRoleToAccessRoleMapping(newExternalRoleToAccessRoleMapping);
  };

  const onDeleteExternalRoleToAccessRoleMapping = async (
    mapping: ExternalRoleAccessRoleMapping
  ): Promise<ExternalRoleAccessRoleMapping | undefined> => {
    setLoadingId(mapping.id);
    return AccessControlService.deleteExternalRoleToAccessRoleMapping(mapping)
      .then((deletedMapping) => {
        setCurrentExternalRoleToAccessRoleMappings((prevMappings) =>
          prevMappings.filter((e) => e.id !== deletedMapping.id)
        );
        openNotification(t(TranslationKeys.ROLES_DELETEEXTERNALROLEMAPPINGSUCCESS), "primary");
        fetchExternalRoleMappings(role);
        setLoadingId(null);
        return deletedMapping;
      })
      .catch((error) => {
        openErrorNotification(t(TranslationKeys.ROLES_DELETEEXTERNALROLEMAPPINGERROR), error as Error);
        setLoadingId(null);
        return undefined;
      });
  };

  // Determine if any row should show the action column
  const showActionColumn = currentExternalRoleToAccessRoleMappings.some(
    (mapping) => !(mapping.applicationAccessRole.system && mapping.creator.id === SYSTEM_USER_ID)
  );

  // Table column configuration for cleaner data mapping
  const columnConfig: ColumnConfig<ExternalRoleAccessRoleMapping>[] = [
    {
      extractor: (mapping: ExternalRoleAccessRoleMapping) => mapping.externalRoleName,
      key: t(TranslationKeys.ROLES_EXTERNALROLENAME),
    },
    {
      extractor: (mapping: ExternalRoleAccessRoleMapping) => mapping.creator.name,
      key: t(TranslationKeys.ROLES_CREATEDBY),
    },
    {
      extractor: (mapping: ExternalRoleAccessRoleMapping) => mapping.createdAt,
      key: t(TranslationKeys.ROLES_CREATEDAT),
    },
    ...(showActionColumn
      ? [
          {
            extractor: (mapping: ExternalRoleAccessRoleMapping) =>
              mapping.applicationAccessRole.system && mapping.creator.id === SYSTEM_USER_ID ? undefined : loadingId ==
                mapping.id ? (
                <button className="btn btn-danger" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.ROLES_LOADING)}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={(e) => {
                    e?.stopPropagation();
                    onDeleteExternalRoleToAccessRoleMapping(mapping);
                  }}
                  className="text-light btn btn-danger btn-sm"
                >
                  <i className="bi bi-trash-fill text-white me-1"></i>
                  {t(TranslationKeys.ROLES_REMOVEUSER)}
                </button>
              ),
            key: "",
          },
        ]
      : []),
  ];

  return (
    <div>
      <div className="d-flex align-items-center mb-2">
        <Form onSubmit={handleSubmit} className="p-2" style={{ width: "40%" }}>
          <Row>
            <Col>
              <Form.Group className="mb-3" controlId="title">
                <Form.Control
                  type="text"
                  placeholder={t(TranslationKeys.ROLES_NEWEXTERNALROLENAMEPLACEHOLDER)}
                  value={newExternalRoleToAccessRoleMapping?.externalRoleName || ""}
                  onChange={(e) => {
                    if (e?.target?.value) {
                      setNewExternalRoleToAccessRoleMapping((prevMapping) => {
                        return {
                          ...prevMapping,
                          applicationAccessRole: currentRoleSubject?.subject,
                          externalRoleName: e.target.value,
                        } as ExternalRoleAccessRoleMapping;
                      });
                    } else {
                      setNewExternalRoleToAccessRoleMapping(null);
                    }
                  }}
                />
              </Form.Group>
            </Col>
            <Col>
              {addRoleLoader ? (
                <button className="btn btn-primary" type="button" disabled>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  &nbsp;{t(TranslationKeys.ROLES_LOADING)}
                </button>
              ) : (
                <button
                  type="submit"
                  className="text-light btn btn-primary"
                  disabled={newExternalRoleToAccessRoleMapping == null}
                >
                  <i className="bi bi-plus-lg text-white me-1"></i>
                  {t(TranslationKeys.ROLES_ADD)}
                </button>
              )}
            </Col>
          </Row>
        </Form>
      </div>
      <ConfigurableTable<ExternalRoleAccessRoleMapping>
        loading={!!tableLoading}
        data={currentExternalRoleToAccessRoleMappings}
        columnConfig={columnConfig}
        defaultSortColumn={t(TranslationKeys.ROLES_EXTERNALROLENAME)}
      />
      {!tableLoading && currentExternalRoleToAccessRoleMappings.length === 0 && (
        <div className="text-center align-middle" style={{ height: "50px" }}>
          {t(TranslationKeys.ROLES_NODATAFOUND)}
        </div>
      )}
    </div>
  );
}
