import { LogoImage } from "./LogoImage";

const Logo = ({ height = "200px", width = "200px" }) => {
  return (
    <>
      <img src={LogoImage} style={{ height, width }} className="rotate-pulse blue-tinge" alt="Maximum GPT Logo" />
    </>
  );
};

export default Logo;
