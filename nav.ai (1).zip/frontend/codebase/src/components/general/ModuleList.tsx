import { useState } from "react";

import { Modal, Table } from "react-bootstrap";

import { ModuleSpecification, ModuleSpecificationParameter } from "../../lib/Model";
import { getProviderLogo } from "../../utils/uiUtils";

export default function ModuleList({ modules }: { modules: ModuleSpecification[] }) {
  const [openModal, setOpenModal] = useState(false);
  const [selectedModule, setSelectedModule] = useState<ModuleSpecification | null>();
  const handleOpen = (module: ModuleSpecification) => {
    setSelectedModule(module);
    setOpenModal(true);
  };
  const handleClose = () => {
    setOpenModal(false);
  };
  const moduleRows = modules.map((module) => {
    return (
      <tr onClick={() => handleOpen(module)} key={module.id}>
        <td>{module.name}</td>
        <td>{module.type}</td>
      </tr>
    );
  });
  const paramTable = (module: ModuleSpecification) => {
    if (module.parameters) {
      const keys = Object.keys(module.parameters[0] ?? {});
      const headers = keys.map((key) => <th key={key}>{key.toUpperCase()}</th>);

      const rows = module.parameters.map((param, i) => {
        const rowCells = keys.map((key) => (
          <td key={`${i}-${key}`}>{String(param[key as keyof ModuleSpecificationParameter])}</td>
        ));
        return <tr key={i}>{rowCells}</tr>;
      });

      return (
        <Table striped bordered hover size="sm" style={{ fontSize: "0.85em" }}>
          <thead>
            <tr>{headers}</tr>
          </thead>
          <tbody>{rows}</tbody>
        </Table>
      );
    }
  };

  return (
    <>
      <Table striped bordered hover size="sm">
        <tbody>{moduleRows}</tbody>
      </Table>
      {selectedModule ? (
        <Modal show={openModal} onHide={handleClose} backdrop="static" centered size="xl">
          <Modal.Header closeButton>
            <Modal.Title>
              <img src={getProviderLogo(selectedModule.name)} style={{ height: "1em" }} alt="provider logo" />
            </Modal.Title>
          </Modal.Header>
          <Modal.Body className="overflow-x-auto">{paramTable(selectedModule)}</Modal.Body>{" "}
        </Modal>
      ) : (
        <></>
      )}
    </>
  );
}
