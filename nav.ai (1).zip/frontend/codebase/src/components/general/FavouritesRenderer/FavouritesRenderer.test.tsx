import React from "react";

import "@testing-library/jest-dom";
import { act, render, screen, waitFor } from "@testing-library/react";

import { AccessPermissionSubject, AssigneeType, DocumentType, PermissionType, TypeName } from "../../../lib/Model";
import * as storeModule from "../../../stores/useStore";
import * as NotificationModule from "../NotificationProvider";
import { AccessControlService } from "./../../../services/AccessControlService";
import { AssistantService } from "./../../../services/AssistantService";
import { UserService } from "./../../../services/UserService";
import { WorkspaceService } from "./../../../services/WorkspaceService";
// Works with Vitest
import FavouritesRenderer from "./FavouritesRenderer";

beforeAll(() => {
  (import.meta as any).env = {
    VITE_BACKEND_BASE_URL: "http://0.0.0.0:5001/maximumgpt-dev/api/v1/",
  };
});

vi.mock("../../../lib/Backend", () => ({
  Backend: {
    getAssistants: vi.fn(),
    getGrants: vi.fn(),
    getUsers: vi.fn(),
    getWorkspaces: vi.fn(),
  },
}));

vi.mock("../../../utils/constants", () => ({
  MAX_ICON_SIZE: 2097152,
  MAX_IMAGE_SIZE: 5242880,
  TOOLS_PREFIX: "MockPrefix",
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

vi.mock("../AgentCard", () => {
  return {
    __esModule: true,
    default: ({ data, iconName }: any) => {
      return (
        <div data-testid={`agent-card-${iconName}`}>
          <span data-testid={`card-name-${iconName}`}>{data.name}</span>
        </div>
      );
    },
  };
});

const mockUsers = [
  { account_id: "user-1", id: "user-1", name: "Jane Smith" },
  { account_id: "989703ab-ab5fa5a-43dcls", id: "989703ab-ab5fa5a-43dcls", name: "John Doe" },
];

const mockWorkspaces = [
  {
    __type_name: TypeName.Workspace,
    accessPermission: PermissionType.WRITE,
    createdAt: "2025-04-07T22:48:47.051624",
    creator: { __type_name: TypeName.User, id: "current_user", name: "John Doe" },
    description: "",
    favorite: true,
    filteredOnTags: false,
    hidden: false,
    icon: "",
    id: "workspace-1",
    image: null,
    name: "test-utility-agent",
    tags: [],
  },
  {
    __type_name: TypeName.Workspace,
    accessPermission: PermissionType.WRITE,
    createdAt: "2025-04-08T22:48:47.051624",
    creator: { __type_name: TypeName.User, id: "current_user", name: "John Doe" },
    description: "",
    favorite: true,
    filteredOnTags: false,
    hidden: false,
    icon: "",
    id: "workspace-3",
    image: null,
    name: "test-utility-agent-2",
    tags: [],
  },
  {
    __type_name: TypeName.Workspace,
    accessPermission: PermissionType.WRITE,
    createdAt: "2025-06-07T22:48:47.051625",
    creator: { __type_name: TypeName.User, id: "user-1", name: "Bob Smith" },
    description: "",
    favorite: true,
    filteredOnTags: false,
    hidden: false,
    icon: "",
    id: "workspace-2",
    image: null,
    name: "test-delete-agent",
    tags: [],
  },
];

const mockAgents = [
  {
    __type_name: TypeName.Assistant,
    accessPermission: PermissionType.WRITE,
    attachmentStorages: [{ fileStorageId: "48faac89-d05f8b6dfc", type: DocumentType.IMAGE }],
    createdAt: "2025-05-28T08:13:46.232744",
    creator: { __type_name: TypeName.User, id: "current_user", name: "John Doe" },
    customSystemInstruction: "",
    dataSourceIds: ["e040f79a-e13a1395fd02"],
    description: "Your agent",
    favorite: true,
    greetingMessage: "hello",
    hidden: false,
    icon: "",
    id: "agent-1",
    image: "",
    llmIds: ["d902d10b-103-c36b24167"],
    modifiedAt: "2025-06-19T11:47:15.568518",
    modifier: { __type_name: TypeName.User, id: "current_user", name: "John Doe" },
    name: "test Agent",
    sampleQuestions: [],
    systemInstructionIds: ["2b3a9ad4-0-7d40a052a971"],
    tags: [{ __type_name: TypeName.Tag, id: "a998259c-6-0c780efcdaa", name: "Defense" }],
  },
  {
    __type_name: TypeName.Assistant,
    accessPermission: PermissionType.WRITE,
    attachmentStorages: [{ fileStorageId: "aaaac89-d05f8b6dfc", type: DocumentType.IMAGE }],
    createdAt: "2025-05-28T08:13:46.232744",
    creator: { __type_name: TypeName.User, id: "user-1", name: "Bob Smith" },
    customSystemInstruction: "",
    dataSourceIds: ["e040f79a-e13a1395fd02"],
    description: "Shared user's agent",
    favorite: true,
    greetingMessage: "hi",
    hidden: false,
    icon: "",
    id: "agent-2",
    image: "",
    llmIds: ["d902d10b-103-c36b24167"],
    modifiedAt: "2025-06-19T11:47:15.568518",
    modifier: { __type_name: TypeName.User, id: "user-1", name: "Jane Smith" },
    name: "Shared Agent",
    sampleQuestions: [],
    systemInstructionIds: ["2b3a9ad4-0-7d40a052a971"],
    tags: [],
  },
];

const mockGrants = [
  {
    accessLevel: PermissionType.READ,
    assigneeId: "user-1",
    assigneeType: "User" as AssigneeType,
    createdAt: "2025-05-28T07:40:32.617421",
    creator: { __type_name: TypeName.User, id: "989703ab-ab5fa5a-43dcls", name: "John Doe" },
    subjectId: "workspace-1",
    subjectType: "Workspace" as AccessPermissionSubject,
  },
  {
    accessLevel: PermissionType.READ,
    assigneeId: "user-1",
    assigneeType: "User" as AssigneeType,
    createdAt: "2025-06-01T07:40:32.617421",
    creator: { __type_name: TypeName.User, id: "989703ab-ab5fa5a-43dcls", name: "John Doe" },
    subjectId: "workspace-2",
    subjectType: "Workspace" as AccessPermissionSubject,
  },
];

describe("FavouritesRenderer", () => {
  let useStateSpy: ReturnType<typeof vi.spyOn>;
  const mockOpenErrorNotification = vi.fn();

  afterEach(() => {
    if (useStateSpy) useStateSpy.mockRestore();
    vi.clearAllMocks();
  });

  beforeEach(() => {
    vi.spyOn(WorkspaceService, "getWorkspaces").mockResolvedValue(
      mockWorkspaces.map((workspace) => ({
        ...workspace,
        image: workspace.image || "",
      }))
    );
    vi.spyOn(AssistantService, "getAssistants").mockResolvedValue(mockAgents);
    vi.spyOn(UserService, "getUsers").mockResolvedValue(mockUsers);
    vi.spyOn(AccessControlService, "getGrants").mockResolvedValue(mockGrants);

    vi.spyOn(NotificationModule, "useNotification").mockReturnValue({
      closeNotification: vi.fn(),
      openErrorNotification: mockOpenErrorNotification,
      openNotification: vi.fn(),
    });

    vi.spyOn(storeModule, "authStore").mockImplementation((selector: any) => {
      return selector({
        roles: [],
        user: { id: "current_user" },
      });
    });
  });

  it("shows CardSkeleton when loading is true", () => {
    useStateSpy = vi.spyOn(React, "useState").mockImplementationOnce(() => [true, vi.fn()]);
    render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    const cardSkeleton = screen.getAllByTestId("card-skeleton");
    expect(cardSkeleton).toHaveLength(1);
  });

  it("renders favorite workspaces when favWorkspaces has data", async () => {
    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      expect(screen.getByText("favourites.favoriteWorkspaces")).toBeInTheDocument();
      const favSection = screen.getByText("favourites.favoriteWorkspaces").closest(".mb-4");
      const workspaceNames = favSection
        ? Array.from(favSection.querySelectorAll('[data-testid="card-name-workspace"]')).map((el) => el.textContent)
        : [];
      expect(workspaceNames).toContain("test-utility-agent");
      expect(workspaceNames).toContain("test-delete-agent");
    });
  });

  it("renders favorite agents when favAssistants has data", async () => {
    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      expect(screen.getByText("favourites.favoriteAgents")).toBeInTheDocument();
      const agentNames = screen.getAllByTestId("card-name-agent").map((el) => el.textContent);
      expect(agentNames).toContain("test Agent");
      expect(agentNames).toContain("Shared Agent");
    });
  });

  it("renders latest workspaces sorted by createdAt descending", async () => {
    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      const latestSection = screen.getByText("favourites.latestWorkspaces").closest(".mb-4");
      const cards = latestSection
        ? Array.from(latestSection.querySelectorAll('[data-testid="card-name-workspace"]')).map((el) => el.textContent)
        : [];
      expect(cards[0]).toContain("test-utility-agent-2");
      expect(cards[1]).toContain("test-utility-agent");
    });
  });

  it("does not render any section if there are no favorites or latest", async () => {
    (WorkspaceService.getWorkspaces as ReturnType<typeof vi.fn>).mockResolvedValue([]);
    (AssistantService.getAssistants as ReturnType<typeof vi.fn>).mockResolvedValue([]);
    (UserService.getUsers as ReturnType<typeof vi.fn>).mockResolvedValue([]);
    (AccessControlService.getGrants as ReturnType<typeof vi.fn>).mockResolvedValue([]);

    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      expect(screen.queryByText("favourites.favoriteWorkspaces")).not.toBeInTheDocument();
      expect(screen.queryByText("favourites.favoriteAgents")).not.toBeInTheDocument();
      expect(screen.queryByText("favourites.latestWorkspaces")).not.toBeInTheDocument();
    });
  });

  it("calls fetchData on mount and when reloadTrigger changes", async () => {
    const spy = vi.spyOn(WorkspaceService, "getWorkspaces");

    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      expect(spy).toHaveBeenCalled();
    });

    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={true} />);
    });

    await waitFor(() => {
      expect(spy).toHaveBeenCalledTimes(2);
    });
  });

  it("shows error notification with correct error message if fetchData throws", async () => {
    const error = new Error("fail");

    (WorkspaceService.getWorkspaces as ReturnType<typeof vi.fn>).mockImplementation(() => {
      throw error;
    });

    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      expect(mockOpenErrorNotification).toHaveBeenCalledWith("errorMessages.getDatasets", error);
    });
  });

  it("renders shared favourite workspace and agent", async () => {
    await act(async () => {
      render(<FavouritesRenderer handleTriggerUpdate={vi.fn()} reloadTrigger={false} />);
    });

    await waitFor(() => {
      const currentUserId = "current_user";
      const sharedWorkspaces = mockWorkspaces.filter((w) => w.favorite && w.creator.id !== currentUserId);
      const sharedAgents = mockAgents.filter((a) => a.favorite && a.creator.id !== currentUserId);

      const workspaceNames = screen.getAllByTestId("card-name-workspace").map((el) => el.textContent);
      const agentNames = screen.getAllByTestId("card-name-agent").map((el) => el.textContent);

      const renderedSharedWorkspaces = sharedWorkspaces.filter((w) => workspaceNames.includes(w.name));
      const renderedSharedAgents = sharedAgents.filter((a) => agentNames.includes(a.name));

      expect(renderedSharedWorkspaces.length).toBe(1);
      expect(renderedSharedAgents.length).toBe(1);
    });
  });
});
