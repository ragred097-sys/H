import { useEffect, useState } from "react";

import { useTranslation } from "react-i18next";

import { AgentWorkflow, Assistant, TypeName, User, Workspace } from "../../../lib/Model";
import { authStore } from "../../../stores/useStore";
import { TranslationKeys } from "../../../types/translation-keys";
import AgentCard from "../AgentCard/AgentCard";
import CardSkeleton from "../CardSkeleton";
import { useNotification } from "../NotificationProvider";
import { AccessControlService } from "./../../../services/AccessControlService";
import { AssistantService } from "./../../../services/AssistantService";
import { UserService } from "./../../../services/UserService";
import { WorkspaceService } from "./../../../services/WorkspaceService";

const MAX_CARDS = 3;

interface StateUpdates {
  workspaces: Workspace[];
  agents: Assistant[];
  users: User[];
  [key: string]: Workspace[] | User[] | Assistant[];
}

export default function FavouritesRenderer({
  handleTriggerUpdate,
  launchControl,
  reloadTrigger,
}: {
  launchControl?: (agent: Assistant | AgentWorkflow) => void;
  handleTriggerUpdate: () => void;
  reloadTrigger: boolean;
}) {
  const { t } = useTranslation();
  const { openErrorNotification } = useNotification();
  const userId = authStore((state) => state.user?.id);
  const [loading, setLoading] = useState(true);
  const [favWorkspaces, setFavWorkspaces] = useState<Workspace[]>([]);
  const [favAssistants, setFavAssistants] = useState<Assistant[]>([]);
  const [latestWorkspaces, setLatestWorkspaces] = useState<Workspace[]>([]);

  useEffect(() => {
    if (userId) {
      fetchData();
    }
  }, [userId, reloadTrigger]);

  const fetchData = async () => {
    try {
      const requests = {
        agents: AssistantService.getAssistants(),
        users: UserService.getUsers(),
        workspaces: WorkspaceService.getWorkspaces(),
      };

      setLoading(true);
      Promise.allSettled(Object.entries(requests).map(([, promise]) => promise)).then(async (results) => {
        const stateUpdates = Object.keys(requests).reduce((acc: StateUpdates, key, index) => {
          acc[key] =
            results[index].status === "fulfilled"
              ? (results[index] as PromiseFulfilledResult<Workspace[] | Assistant[] | User[]>).value
              : [];
          return acc;
        }, {} as StateUpdates);

        const workspaces: Workspace[] = stateUpdates.workspaces || [];
        const users: User[] = stateUpdates.users || [];
        const agents: Assistant[] = stateUpdates.agents || [];

        const filteredWorkspaces = await Promise.all(
          workspaces?.filter((workspace) => workspace.favorite)?.slice(0, MAX_CARDS)
        );
        const myFavoriteWorkSpaces = await Promise.all(
          filteredWorkspaces
            ?.filter((workspace) => workspace.creator.id === userId)
            ?.map(async (workspace) => {
              const grants = await AccessControlService.getGrants(workspace); // Fetch grants for the workspace
              // Get "Shared With" users
              const sharedWithIds = grants
                ?.filter((grant) => grant.assigneeType === TypeName.User)
                ?.map((grant) => grant.assigneeId);

              const sharedWithUsers = users
                ?.filter((user) => sharedWithIds.includes(user.id))
                ?.map((user) => user.name);

              return {
                ...workspace,
                sharedWithUsers, // Attach sharedWithUsers to myWorkspaces
              };
            })
        );
        /* (favorite workspaces that are shared with me) */
        const sharedFavoriteWorkSpaces = await Promise.all(
          filteredWorkspaces
            ?.filter((workSpace) => workSpace.creator.id !== userId)
            ?.map((workSpace) => {
              // Get "Shared By" user
              const sharedBy = workSpace.creator.name;
              return {
                ...workSpace,
                sharedBy,
              };
            })
        );
        /*  list three favorite workspaces */
        const favWorkspacesObj = [...myFavoriteWorkSpaces, ...sharedFavoriteWorkSpaces];

        const myWorkSpaces = await Promise.all(
          workspaces
            ?.filter((workspace) => workspace.creator.id === userId)
            ?.map(async (workspace) => {
              const grants = await AccessControlService.getGrants(workspace);
              // Get "Shared With" users
              const sharedWithIds = grants
                ?.filter((grant) => grant.assigneeType === TypeName.User)
                ?.map((grant) => grant.assigneeId);

              const sharedWithUsers = users
                ?.filter((user) => sharedWithIds.includes(user.id))
                ?.map((user) => user.name);

              return {
                ...workspace,
                sharedWithUsers, // Attach sharedWithUsers to my-workspaces
              };
            })
        );
        /* list three latest workspaces */
        const latestWorkspacesObj = myWorkSpaces
          ?.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          ?.slice(0, MAX_CARDS);

        /* filter 3 favorite agents */
        const filteredAgents = await Promise.all(agents.filter((agent) => agent.favorite)?.slice(0, MAX_CARDS));
        /* my favorite agents */
        const myAgents = await Promise.all(
          filteredAgents
            ?.filter((agent) => agent.creator.id === userId)
            ?.map(async (agent) => {
              const grants = await AccessControlService.getGrants(agent); //fetch grants for agents

              // Get "Shared With" users
              const sharedWithIds = grants
                ?.filter((grant) => grant.assigneeType === TypeName.User)
                ?.map((grant) => grant.assigneeId);

              const sharedWithUsers = users
                ?.filter((user) => sharedWithIds.includes(user.id))
                ?.map((user) => user.name);

              return {
                ...agent,
                sharedWithUsers,
              };
            })
        );

        /* agents shared with me */
        const sharedAgents = await Promise.all(
          filteredAgents
            ?.filter((agent) => agent.creator.id !== userId)
            ?.map((agent) => {
              // Get "Shared By" user
              const sharedBy = agent.creator.name;
              return {
                ...agent,
                sharedBy,
              };
            })
        );
        const favAgentsObj = [...myAgents, ...sharedAgents];
        setFavAssistants(favAgentsObj);
        setFavWorkspaces(favWorkspacesObj);
        setLatestWorkspaces(latestWorkspacesObj);
        setLoading(false);
      });
    } catch (err) {
      setLoading(false);
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETDATASETS), err as Error);
    }
  };

  return (
    <>
      {loading ? (
        <CardSkeleton />
      ) : (
        <div className="d-flex flex-column align-items-center w-100">
          {!!favWorkspaces?.length && (
            <div className="d-flex flex-column align-items-center w-100 mb-4">
              <h5 className="text-center mb-3">{t(TranslationKeys.FAVOURITES_FAVORITEWORKSPACES)}</h5>
              <div className="d-flex flex-wrap justify-content-center align-items-center">
                {favWorkspaces?.map((el, index) => (
                  <div key={index} className="ps-2 pe-2">
                    <AgentCard
                      data={el}
                      iconName={"workspace"}
                      launchControl={launchControl}
                      updateTrigger={handleTriggerUpdate}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {!!favAssistants?.length && (
            <div className="d-flex flex-column align-items-center w-100 mb-4">
              <h5 className="text-center mb-3">{t(TranslationKeys.FAVOURITES_FAVORITEAGENTS)}</h5>
              <div className="d-flex flex-wrap justify-content-center align-items-center">
                {favAssistants?.map((el, index) => (
                  <div key={index} className="ps-2 pe-2">
                    <AgentCard
                      data={el}
                      iconName={"agent"}
                      launchControl={launchControl}
                      updateTrigger={handleTriggerUpdate}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {!!latestWorkspaces?.length && (
            <div className="d-flex flex-column align-items-center w-100 mb-4">
              <h5 className="text-center mb-3">{t(TranslationKeys.FAVOURITES_LATESTWORKSPACES)}</h5>
              <div className="d-flex flex-wrap justify-content-center align-items-center">
                {latestWorkspaces?.map((el, index) => (
                  <div key={index} className="ps-2 pe-2">
                    <AgentCard
                      data={el}
                      iconName={"workspace"}
                      launchControl={launchControl}
                      updateTrigger={handleTriggerUpdate}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
}
