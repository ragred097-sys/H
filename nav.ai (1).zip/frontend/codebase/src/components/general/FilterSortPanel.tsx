import React, { useEffect, useState } from "react";

import { Button, Dropdown, Form } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import i18n from "../../i18n";
import { FilterSortPanelProps } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { translateParamOrThrow } from "../../utils/translationUtils";

type ToggleSource = "filter" | "sort";

const FilterSortPanel: React.FC<FilterSortPanelProps> = ({
  defaultFilter,
  defaultSort,
  filterOptions,
  onApply,
  showFilter = true,
  showSort = true,
  sortByOptions,
  sortOrderOptions = [
    { key: "asc", label: i18n.t(TranslationKeys.FILTERSORT_ASC, { defaultValue: "Ascending" }) },
    { key: "desc", label: i18n.t(TranslationKeys.FILTERSORT_DESC, { defaultValue: "Descending" }) },
  ],
  variant = "dark",
}) => {
  const { t } = useTranslation();

  const [filterDropdownOpen, setFilterDropdownOpen] = useState(false);
  const [sortDropdownOpen, setSortDropdownOpen] = useState(false);

  const [tempFilter, setTempFilter] = useState<Record<string, boolean>>(defaultFilter);
  const [tempSort, setTempSort] = useState({ ...defaultSort });

  // Reset draft when dropdown opens
  useEffect(() => {
    if (filterDropdownOpen) {
      setTempFilter(defaultFilter);
    }
  }, [filterDropdownOpen, defaultFilter]);

  useEffect(() => {
    if (sortDropdownOpen) {
      setTempSort(defaultSort);
    }
  }, [sortDropdownOpen, defaultSort]);

  const handleFilterChange = (key: string, value: boolean) => {
    setTempFilter((prev) => ({ ...prev, [key]: value }));
  };

  const handleSortChange = (field: "sortBy" | "order", value: string) => {
    setTempSort((prev) => ({ ...prev, [field]: value }));
  };

  const handleApply = (src: ToggleSource) => {
    onApply(tempFilter, tempSort);
    if (src === "filter") {
      setFilterDropdownOpen(false);
    }
    if (src === "sort") {
      setSortDropdownOpen(false);
    }
  };

  return (
    <div className="d-flex gap-3 align-items-start">
      {showFilter && filterOptions.length > 0 && (
        <Dropdown show={filterDropdownOpen} onToggle={(isOpen) => setFilterDropdownOpen(isOpen)}>
          <Dropdown.Toggle as={Button} variant={variant} id="dropdown-filter-toggle">
            {t(TranslationKeys.FILTERSORT_FILTER)} <i className="bi bi-filter"></i>
          </Dropdown.Toggle>

          <Dropdown.Menu style={{ padding: "1rem", width: "220px" }}>
            {filterOptions.map((option) => (
              <Form.Check
                key={option.key}
                type="checkbox"
                label={t(translateParamOrThrow(option.key, "FILTERSORT_"), { defaultValue: `${option.label}` })}
                checked={tempFilter[option.key]}
                onChange={(e) => handleFilterChange(option.key, e.target.checked)}
              />
            ))}
            <div className="mt-2 d-flex justify-content-end">
              <Button
                size="sm"
                variant="primary"
                onClick={() => {
                  handleApply("filter");
                }}
              >
                {t(TranslationKeys.FILTERSORT_APPLY)}
              </Button>
            </div>
          </Dropdown.Menu>
        </Dropdown>
      )}

      {showSort && sortByOptions.length > 0 && (
        <Dropdown show={sortDropdownOpen} onToggle={(isOpen) => setSortDropdownOpen(isOpen)}>
          <Dropdown.Toggle as={Button} variant={variant} id="dropdown-sort-toggle">
            {t(TranslationKeys.FILTERSORT_SORT)} <i className="bi bi-arrow-down-up"></i>
          </Dropdown.Toggle>

          <Dropdown.Menu style={{ padding: "1rem", width: "220px" }}>
            <strong className="fw-bold mb-3">{t(TranslationKeys.FILTERSORT_SORTBY)}</strong>
            {sortByOptions.map((opt) => (
              <Form.Check
                type="radio"
                name="sortBy"
                key={opt.key}
                label={t(translateParamOrThrow(opt.key, "FILTERSORT_"), { defaultValue: `${opt.label}` })}
                checked={tempSort?.sortBy === opt.key}
                onChange={() => handleSortChange("sortBy", opt.key)}
              />
            ))}

            <hr />
            <strong className="fw-bold mb-3">{t(TranslationKeys.FILTERSORT_ORDER)}</strong>
            {sortOrderOptions.map((opt) => (
              <Form.Check
                type="radio"
                name="order"
                key={opt.key}
                label={t(translateParamOrThrow(opt.key, "FILTERSORT_"), { defaultValue: `${opt.label}` })}
                checked={tempSort?.order === opt.key}
                onChange={() => handleSortChange("order", opt.key)}
              />
            ))}

            <div className="mt-2 d-flex justify-content-end">
              <Button
                size="sm"
                variant="primary"
                onClick={() => {
                  handleApply("sort");
                }}
              >
                {t(TranslationKeys.FILTERSORT_APPLY)}
              </Button>
            </div>
          </Dropdown.Menu>
        </Dropdown>
      )}
    </div>
  );
};

export default FilterSortPanel;
