import { useEffect, useState } from "react";

import { Button, ListGroup, Tab, Table, Tabs } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import {
  Agent,
  AgentWorkflow,
  Assistant,
  AssistantGovernanceConfiguration,
  Conversation,
  DataSource,
  Module,
  ModuleType,
  SystemInstruction,
  Tag,
  TypeName,
  Workspace,
} from "../../lib/Model";
import { GovernanceService } from "../../services/GovernanceService";
import { TranslationKeys } from "../../types/translation-keys";
import { formatTimestamp } from "../../utils/dateUtils";
import { isEqtyEnabled } from "../../utils/eqty";
import { sanitizeURL } from "../../utils/stringUtils";
import { getTranslatedTypeName } from "../../utils/translationUtils";
import { getProviderLogo } from "../../utils/uiUtils";
import NewSystemPromptForm from "../forms/NewSystemPromptForm";
import WorkflowRenderer from "../renderers/WorkflowRenderer";
import { DataSourceService } from "./../../services/DataSourceService";
import { ModuleService } from "./../../services/ModuleService";
import { SystemInstructionService } from "./../../services/SystemInstructionService";
import DataSourceTable from "./DataSourceTable";
import ModuleTable from "./ModuleTable";
import { useNotification } from "./NotificationProvider";

export default function AgentDetail({
  conversation,
  data,
  launchControl,
  recovery,
}: {
  data: Workspace | Assistant | DataSource | Tag | SystemInstruction | Module | AgentWorkflow | Agent;
  launchControl?: (agent: Assistant | AgentWorkflow) => void;
  conversation?: Conversation;
  recovery?: boolean;
}) {
  const [dataSources, setDataSources] = useState<DataSource[]>();
  const [llms, setLlms] = useState<Module[]>();
  const [convoDataSources, setConvoDataSources] = useState<DataSource>();
  const [instructions, setInstructions] = useState<SystemInstruction[]>();
  const [functionTools, setFunctionTools] = useState<Module[]>([]);
  const [governanceConfiguration, setGovernanceConfiguration] = useState<AssistantGovernanceConfiguration>();
  const [indicatorUuid, setindicatorUuid] = useState<string | null>(null);
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();

  useEffect(() => {
    const fetchDsDetails = async () => {
      if ("dataSourceIds" in data && data.dataSourceIds) {
        try {
          const fetchedDs = await Promise.all(
            data.dataSourceIds.map((ds: string) => DataSourceService.getDatasourceById(ds))
          );
          setDataSources(fetchedDs);
        } catch (error) {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETDATASOURCEDETAILS), error as Error);
          console.error("Error fetching data source details:", error);
        }
      }
    };
    if ("fileStorageId" in data && !recovery) {
      DataSourceService.getDatasourceById(data.id)
        .then((res) => setDataSources([res]))
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETDATASOURCEDETAILS), err as Error);
        });
    }
    if ("llmIds" in data && data?.llmIds) {
      ModuleService.getModulesByType(ModuleType.LLM)
        .then((res) => {
          const filteredLlms = res.filter((el) => data.llmIds.includes(el.id));
          setLlms(filteredLlms);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETMODULETYPE), err as Error);
        });
    }
    if ("systemInstructionIds" in data && data.systemInstructionIds) {
      const instructions: SystemInstruction[] = [];
      for (const sysInstId of data.systemInstructionIds) {
        SystemInstructionService.getSystemInstruction(sysInstId)
          .then((res) => {
            instructions.push(res);
            setInstructions(instructions);
          })
          .catch((err) => {
            openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETSYSINSTRUCTION), err as Error);
          });
      }
    }
    const fetchFunctionTools = async () => {
      if ("functionToolIds" in data && data?.functionToolIds) {
        try {
          const fetchTools = await Promise.all(data?.functionToolIds?.map((id) => ModuleService.getModuleById(id)));
          setFunctionTools(fetchTools);
        } catch (error) {
          // Error handling could be added here if needed
        }
      }
    };
    const fetchGovernance = async () => {
      if (
        isEqtyEnabled() &&
        data?.id &&
        [TypeName.Assistant, TypeName.Agent, TypeName.AgentWorkflow].includes(data.__type_name as TypeName)
      ) {
        GovernanceService.getAgenticGovernanceConfiguration(data as Assistant | Agent | AgentWorkflow)
          .then((res) => {
            setGovernanceConfiguration(res);
          })
          .catch((err) => {
            openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCECONFIGURATION), err as Error);
          });
      }
    };
    fetchFunctionTools();
    fetchDsDetails();
    fetchGovernance();
  }, [data]);

  useEffect(() => {
    if (conversation) {
      if (conversation?.dataSourceIds?.length) {
        DataSourceService.getDatasourceById(conversation.dataSourceIds[0]).then((res) => setConvoDataSources(res));
      }
    }
  }, [conversation]);

  useEffect(() => {
    setindicatorUuid(governanceConfiguration?.thumbs_indicator_uuid ?? null);
  }, [governanceConfiguration?.thumbs_indicator_uuid]);

  const Published = () => {
    if ("public" in data && data?.public === true) {
      return <>Published</>;
    }
    return <>Draft</>;
  };

  const handleLaunch = (
    data: DataSource | Module | Assistant | Workspace | SystemInstruction | Tag | AgentWorkflow
  ) => {
    if ("url" in data && data.url) {
      const sanitizedURL = sanitizeURL(data.url as string);
      if (sanitizedURL !== null) window.open(sanitizedURL as string, "_blank");
    }
    if (data.__type_name === TypeName.Assistant && launchControl) {
      launchControl(data! as Assistant);
    }
    if (data.__type_name === TypeName.AgentWorkflow && launchControl) {
      launchControl(data! as AgentWorkflow);
    }
  };

  return (
    <div className="">
      <Tabs defaultActiveKey="overview">
        <Tab
          eventKey="overview"
          title={t(TranslationKeys.WORKSPACEINFOCARD_OVERVIEWTAB, { type: getTranslatedTypeName(data?.__type_name) })}
        >
          <div>
            <p className="text-muted ps-2 pt-2 ">
              {t(TranslationKeys.WORKSPACEINFOCARD_ALLABOUT, { name: data?.name })}
            </p>

            {data.__type_name === TypeName.AgentWorkflow ? <WorkflowRenderer workFlowID={data.id} /> : null}
            <Table size="sm" responsive borderless striped style={{ fontSize: "0.9em" }}>
              <tbody>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_TYPE)}</td>

                  <td>{data?.__type_name}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_NAME)}</td>
                  <td>{data?.name}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_DESCRIPTION)}</td>
                  <td>{data?.description}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_CREATEDON)}</td>
                  <td>{formatTimestamp(data.createdAt)}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_CREATEDBY)}</td>
                  <td>{data?.creator.name}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_STATUS)}</td>
                  <td>{Published()}</td>
                </tr>
                <tr>
                  <td className="pe-3">{t(TranslationKeys.WORKSPACEINFOCARD_ID)}</td>
                  <td>{data?.id}</td>
                </tr>
              </tbody>
            </Table>
            <div className="d-flex flex-row">
              {"image" in data && data.image ? (
                <img
                  src={data.image}
                  style={{
                    borderRadius: "var(--bs-border-radius)",
                    height: "12em",
                    maxWidth: "16em",
                    objectFit: "cover",
                  }}
                  className="ps-2"
                  alt="Cover Image"
                />
              ) : (
                <></>
              )}
            </div>
            {"parameters" in data && data.parameters ? <ModuleTable module={data} /> : <></>}
            {launchControl || "url" in data ? (
              <div className="text-end pt-3">
                <Button className="button" onClick={() => handleLaunch(data)}>
                  {t(TranslationKeys.WORKSPACEINFOCARD_LAUNCH)}
                </Button>
              </div>
            ) : (
              <></>
            )}
          </div>
        </Tab>
        {conversation ? (
          <Tab eventKey="conversationInfo" title={t(TranslationKeys.WORKSPACEINFOCARD_CONVERSATIONDETAILSTAB)}>
            <p className="text-muted ps-2 pt-2 ">{t(TranslationKeys.WORKSPACEINFOCARD_CONVERSATIONINFO)}</p>
            <Table size="sm" responsive borderless striped style={{ fontSize: "0.9em" }}>
              <tbody>
                <tr>
                  <td className="w-25">{t(TranslationKeys.WORKSPACEINFOCARD_CONVERSATIONNAME)}</td>
                  <td>{conversation.name}</td>
                </tr>
                <tr>
                  <td className="w-25">{t(TranslationKeys.WORKSPACEINFOCARD_CONVERSATIONCREATED)}</td>
                  <td>{formatTimestamp(conversation.createdAt)}</td>
                </tr>
                <tr>
                  <td colSpan={2} className="w-25">
                    {t(TranslationKeys.WORKSPACEINFOCARD_CONVERSATIONSPECIFICDATA)}
                  </td>
                </tr>
                <tr>
                  <td colSpan={2} className="w-25">
                    {convoDataSources ? (
                      <DataSourceTable data={[convoDataSources]} />
                    ) : (
                      <>{t(TranslationKeys.WORKSPACEINFOCARD_NOCONVERSATIONDATA)}</>
                    )}
                  </td>
                </tr>
              </tbody>
            </Table>
          </Tab>
        ) : null}
        {dataSources && data?.__type_name !== TypeName.AgentWorkflow ? (
          <Tab eventKey="referenceData" title={t(TranslationKeys.WORKSPACEINFOCARD_REFERENCEDATATAB)}>
            <p className="text-muted ps-2 pt-2 ">{t(TranslationKeys.WORKSPACEINFOCARD_REFERENCEDATAINFO)}</p>
            <DataSourceTable data={dataSources} />
          </Tab>
        ) : (
          <></>
        )}
        {llms && llms.length > 0 ? (
          <Tab eventKey="llms" title={t(TranslationKeys.WORKSPACEINFOCARD_MODELSTAB)}>
            <p className="text-muted ps-2 pt-2 ">
              {t(TranslationKeys.WORKSPACEINFOCARD_MODELSINFO, { name: data.name })}
            </p>
            {llms.map((llm) => {
              return (
                <Table striped borderless responsive size="sm" key={llm.id}>
                  <tbody>
                    <tr>
                      <td>
                        <img src={getProviderLogo(llm.name)} style={{ height: "1em" }} alt="Provider Logo" />
                      </td>
                      <td>{llm.name}</td>
                    </tr>
                  </tbody>
                </Table>
              );
            })}
          </Tab>
        ) : (
          <></>
        )}
        {instructions ? (
          <Tab eventKey="editpromptKey" title={t(TranslationKeys.WORKSPACEINFOCARD_SYSTEMPROMPTSTAB)}>
            {instructions.map((el) => (
              <NewSystemPromptForm key={el.id} initialData={el} readOnly={true} />
            ))}
          </Tab>
        ) : (
          <></>
        )}
        {
          // @ts-expect-error this is fine
          data.customSystemInstruction ? (
            <Tab eventKey="tools" title={t(TranslationKeys.WORKSPACEINFOCARD_TOOLSTAB)}>
              <p>{t(TranslationKeys.WORKSPACEINFOCARD_CUSTOMTOOLS)}</p>
              <pre
                style={{
                  fontFamily: "Courier, monospace",
                  whiteSpace: "pre-wrap",
                }}
              >
                {
                  // @ts-expect-error yes yes
                  data.customSystemInstruction
                }
              </pre>
            </Tab>
          ) : (
            <></>
          )
        }
        {
          // @ts-expect-error this is fine
          data.sampleQuestions ? (
            <Tab eventKey="suggestedPrompts" title={t(TranslationKeys.WORKSPACEINFOCARD_SUGGESTEDPROMPTSTAB)}>
              <p>{t(TranslationKeys.WORKSPACEINFOCARD_SAMPLEPROMPTS)}</p>
              <ListGroup variant="flush" as="ol" numbered>
                {// @ts-expect-error yes yes
                data?.sampleQuestions?.map((el: string) => {
                  return (
                    <ListGroup.Item as="li" style={{ backgroundColor: "transparent", border: "0" }}>
                      {el}
                    </ListGroup.Item>
                  );
                })}
              </ListGroup>
            </Tab>
          ) : (
            <></>
          )
        }
        {functionTools?.length > 0 ? (
          <Tab eventKey="functionToolsInfo" title={t(TranslationKeys.WORKSPACEINFOCARD_FUNCTIONTOOLSTAB)}>
            {functionTools?.map((functionTool) =>
              functionTool?.parameters?.map((el) => (
                <Table key={functionTool?.id} size="sm" responsive borderless striped style={{ fontSize: "0.9em" }}>
                  <tbody>
                    <tr>
                      <td className="w-25">{el?.name}</td>
                      <td>{el?.value}</td>
                    </tr>
                  </tbody>
                </Table>
              ))
            )}
          </Tab>
        ) : null}
        {governanceConfiguration ? (
          <Tab eventKey="governance" title="Governance">
            <p>Governance configuration for this agent</p>
            <Table key={data.id} size="sm" responsive borderless striped style={{ fontSize: "0.9em" }}>
              <tbody>
                <tr>
                  <td className="w-25">Thumbs Up/Down Indicator</td>
                  <td>{indicatorUuid ?? t(TranslationKeys.AGENTREVIEW_NOTSET)}</td>
                </tr>
              </tbody>
            </Table>
          </Tab>
        ) : null}
      </Tabs>
    </div>
  );
}
