import { Table } from "react-bootstrap";
import { useNavigate } from "react-router-dom";

interface AgentDirectoryTableProps {
  data: string[];
  cubeName: string;
}

const AgentsDirectoryTable = ({ cubeName, data }: AgentDirectoryTableProps) => {
  const navigate = useNavigate();
  const columns = 6;
  const rows = [];

  for (let i = 0; i < data.length; i += columns) {
    rows.push(data.slice(i, i + columns));
  }
  const handleCellClick = (tag: string) => {
    const tagToLowerCase = tag.toLocaleLowerCase();
    navigate(`/tags/${tagToLowerCase}`, {
      state: {
        cubeName: cubeName,
        tagName: tag,
      },
    });
  };
  return (
    <Table bordered className="mb-4 transparent-table">
      <tbody>
        {rows.map((row, rowIndex) => (
          <tr key={rowIndex}>
            {row.map((item, colIndex) => (
              <td
                key={colIndex}
                className="text-center align-middle fixed-width-cell"
                onClick={() => handleCellClick(item)}
              >
                {item}
              </td>
            ))}
            {/* cell with no data */}
            {row.length < columns &&
              Array.from({ length: columns - row.length }).map((_, i) => (
                <td key={`empty-${i}`} className="fixed-width-cell"></td>
              ))}
          </tr>
        ))}
      </tbody>
    </Table>
  );
};

export default AgentsDirectoryTable;
