import React from "react";

import "../../App.scss";

interface Props {
  length?: number;
}
const CardSkeleton: React.FC<Props> = ({ length = 2 }) => {
  return (
    <div className="d-flex flex-row" data-testid="card-skeleton">
      {Array.from({ length }).map((_, i) => (
        <div key={i} className="skeleton-card me-2 mt-0">
          <div className="card-skeleton title animate-wave rounded-1 mx-3" />
          <div className="d-flex align-items-center mt-3">
            <div className="card-skeleton image ms-4 animate-wave"></div>
            <div className="card-skeleton description ms-4 rounded animate-wave"></div>
          </div>
        </div>
      ))}
    </div>
  );
};
export default CardSkeleton;
