// LoaderContext.tsx
import React, { ReactNode, createContext, useContext, useState } from "react";

import { Spinner } from "react-bootstrap";

interface GlobalLoaderContextType {
  readonly loading: boolean;
  setLoading: React.Dispatch<React.SetStateAction<boolean>>;
}

export const GlobalLoaderContext = createContext<GlobalLoaderContextType | undefined>(undefined);

const Loader = () => {
  return (
    <div className="loader-container">
      <Spinner animation="border" className="text-light" role="status">
        <span className="visually-hidden">Loading...</span>
      </Spinner>
    </div>
  );
};

export const useGlobalLoader = (): GlobalLoaderContextType => {
  const context = useContext(GlobalLoaderContext);
  if (!context) {
    throw new Error("useGlobalLoader must be used within a LoaderProvider");
  }
  return context;
};

interface LoaderProviderProps {
  children: ReactNode;
}

export const LoaderProvider = ({ children }: LoaderProviderProps): React.ReactElement => {
  const [loading, setLoading] = useState(false);

  return (
    <GlobalLoaderContext.Provider value={{ loading, setLoading }}>
      {children}
      {loading && <Loader />}
    </GlobalLoaderContext.Provider>
  );
};
