import React, { ReactNode, createContext, useContext, useState } from "react";

import { AxiosError } from "axios";

import { Toast, ToastContainer } from "react-bootstrap";

export type NotificationSeverity = "primary" | "neutral" | "danger" | "success" | "warning";

interface NotificationContextProps {
  openNotification: (message: string, severity?: NotificationSeverity, autoHide?: boolean) => void;
  openErrorNotification: (message: string, error?: Error, autoHide?: boolean) => void;
  closeNotification: () => void;
}

const NotificationContext = createContext<NotificationContextProps | undefined>(undefined);

interface NotificationProviderProps {
  children: ReactNode | ReactNode[];
}

interface Notification {
  open: boolean;
  message: string;
  error?: Error;
  severity: NotificationSeverity;
  autoHide: boolean;
}

const NotificationProvider: React.FunctionComponent<NotificationProviderProps> = ({ children }) => {
  const [notification, setNotification] = useState<Notification>({
    autoHide: true,
    message: "",
    open: false,
    severity: "danger",
  });

  /**
   * Used to show error notification toast
   * @param message - Message to show on toast
   * @param error - Error from catch
   */
  const openErrorNotification = (message: string, error: Error | undefined, autoHide: boolean = true) => {
    setNotification({
      autoHide: autoHide,
      error: error,
      message: message,
      open: true,
      severity: "danger",
    });
  };

  /**
   * Used to show success notification toast
   * @param message - Message to show on toast
   * @param severity - Severity is sent to change the toast style as per notification type
   */
  const openNotification = (message: string, severity: NotificationSeverity = "primary") => {
    setNotification({
      autoHide: severity !== "danger",
      message: message,
      open: true,
      severity: severity,
    });
  };

  const closeNotification = () => {
    setNotification({ ...notification, open: false });
  };

  let message = notification.message;
  if (notification.error) {
    if (notification.error instanceof AxiosError && notification.error.response?.data?.message) {
      message = message + ": " + notification.error.response.data.message;
    } else {
      message = message + ": " + notification.error.message;
    }
  }

  return (
    <NotificationContext.Provider value={{ closeNotification, openErrorNotification, openNotification }}>
      {children}
      <ToastContainer className="p-3" position={"top-center"} style={{ zIndex: 2000 }}>
        <Toast
          onClose={closeNotification}
          bg={notification.severity == "danger" ? "danger" : "success"}
          show={notification.open}
          delay={5000}
          autohide={notification.autoHide}
        >
          <Toast.Body className={"text-white d-flex"}>
            <div
              style={{
                fontSize: "0.9rem",
                width: "95%",
              }}
            >
              {message}{" "}
            </div>
            <i
              onClick={closeNotification}
              className="bi bi-x"
              style={{
                cursor: "pointer",
                float: "right",
                fontSize: "1.1rem",
              }}
            ></i>
          </Toast.Body>
        </Toast>
      </ToastContainer>
    </NotificationContext.Provider>
  );
};

const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error("useNotification must be used inside a NotificationProvider");
  }
  return context;
};

export { NotificationProvider, useNotification };
