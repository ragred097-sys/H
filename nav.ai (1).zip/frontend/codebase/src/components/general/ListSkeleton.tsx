import React from "react";

import "../../App.scss";

interface Props {
  length?: number;
  styleInline?: React.CSSProperties;
}
const ListSkeleton: React.FC<Props> = ({ length = 3, styleInline = {} }) => {
  return (
    <div className="pt-2" style={styleInline}>
      <div className="list">
        {Array.from({ length }).map((_, index) => (
          <div key={index} className="skeleton skeleton-list"></div>
        ))}
      </div>
    </div>
  );
};
export default ListSkeleton;
