import React, { useEffect, useRef, useState } from "react";

import CreatableSelect from "react-select/creatable";

import { useTranslation } from "react-i18next";
import { ActionMeta, MultiValue } from "react-select";

import { Tag } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";

export type TagOrCustom = Tag | CustomTag;

export type CustomTag = {
  tempId: number;
  name: string;
};

interface MultiSelectDropdownProps {
  options: Tag[];
  selectedTags: TagOrCustom[];
  setSelectedTags: React.Dispatch<React.SetStateAction<TagOrCustom[]>>;
  customStyle?: boolean;
}

const DropdownSelect: React.FC<MultiSelectDropdownProps> = ({
  customStyle,
  options,
  selectedTags,
  setSelectedTags,
}) => {
  const { t } = useTranslation();
  const lastKeyRef = useRef<string | null>(null);
  const [theme, setTheme] = useState<string>("light"); // Default theme value

  useEffect(() => {
    // Fetch the current value of the data-bs-theme attribute.
    const currentTheme = document.documentElement.getAttribute("data-bs-theme");
    if (currentTheme) {
      setTheme(currentTheme);
    }
  }, []);
  const toOption = (tag: TagOrCustom) => ({
    __isCustom__: !("id" in tag),
    label: tag.name,
    value: "id" in tag ? tag.id.toString() : `temp-${tag.tempId}`,
  });

  const fromOption = (option: { label: string; value: string }): TagOrCustom => {
    const match = options.find((opt) => opt.id.toString() === option.value);
    if (match) return match;

    if (option.value.startsWith("temp-")) {
      const tempId = parseInt(option.value.replace("temp-", ""), 10);
      return {
        name: option.label,
        tempId,
      };
    }
    return {
      name: option.label,
      tempId: Date.now(),
    };
  };

  const handleChange = (
    newValue: MultiValue<{ label: string; value: string; __isCustom__: boolean }>,
    _actionMeta: ActionMeta<{ label: string; value: string; __isCustom__: boolean }>
  ) => {
    lastKeyRef.current = null;
    if (
      _actionMeta.action === "create-option" &&
      lastKeyRef.current !== "Enter" &&
      _actionMeta.option.__isCustom__ == true
    ) {
      return; // block other tab.
    }

    const converted = newValue.map(fromOption);
    setSelectedTags(converted);
  };

  const selectOptions = options.map((tag) => ({
    __isCustom__: false,
    label: tag.name,
    value: tag.id.toString(),
  }));

  const selectedOptions = selectedTags?.map(toOption);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    lastKeyRef.current = e.key;
  };

  const customStyles = {
    control: (base: any, state: any) => ({
      ...base,
      alignItems: "center",
      backgroundColor: getComputedStyle(document.documentElement).getPropertyValue("--bs-body-bg"),
      borderColor: state.isFocused ? "rgb(134,182.5,254)" : theme == "dark" ? "rgb(73, 80, 87)" : "rgb(206, 212, 218)",
      borderRadius: customStyle ? "var(--bs-border-radius)" : "6px",
      boxShadow: state.isFocused ? "0 0 0 0.2rem rgba(38, 143, 255, 0.25)" : "none",
      flexWrap: "wrap",
      maxHeight: "5em",
      overflowY: "scroll",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      width: "100%",
    }),
    dropdownIndicator: () => ({
      display: "none",
    }),
    input: (base: any) => ({
      ...base,
      background: "transparent",
      border: "none",
      color: getComputedStyle(document.documentElement).getPropertyValue("--bs-body-color"),
      flex: 1,
      outline: "none",
    }),
    menu: (base: any) => ({
      ...base,
      backgroundColor: theme == "dark" ? "rgb(33, 37, 41)" : "rgb(255, 255, 255)",
      marginBottom: "4em",
      zIndex: 9999,
    }),
    multiValue: (base: any) => ({
      ...base,
      alignSelf: "center",
      backgroundColor: "rgb(146, 146, 146)",
      borderRadius: "0.3em",
      cursor: "pointer",
      fontSize: "1em",
      fontWeight: "normal",
      justifyContent: "center",
      margin: "0em 0.3em",
      marginBottom: "0.2em",
      marginTop: "0.2em",
      padding: "0em 0.3em",
    }),
    multiValueLabel: (base: any) => ({
      ...base,
      color: "rgb(255, 255, 255)",
      fontWeight: "normal",
    }),
    multiValueRemove: (base: any) => ({
      ...base,
      ":hover": {
        color: "rgb(220, 53, 69)",
        cursor: "pointer",
      },
      color: "rgb(255, 255, 255)",
    }),
    option: (base: any, state: any) => ({
      ...base,
      backgroundColor: state.isSelected
        ? "rgb(206, 206, 206)"
        : state.isFocused
          ? "rgba(134, 182, 254, 0.2)"
          : "transparent",
      color: getComputedStyle(document.documentElement).getPropertyValue("--bs-body-color"),
    }),
    placeholder: (base: any) => ({
      ...base,
      color: getComputedStyle(document.documentElement).getPropertyValue("--bs-secondary-color"),
    }),
  };

  return (
    <CreatableSelect
      isMulti
      components={{
        DropdownIndicator: () => null,
        IndicatorSeparator: () => null,
      }}
      options={selectOptions}
      value={selectedOptions}
      onChange={handleChange}
      placeholder={t(TranslationKeys.AGENTFORM_TAGSPLACEHOLDER)}
      formatCreateLabel={(inputValue) => t(TranslationKeys.AGENTFORM_CREATETAG, { tag: inputValue })}
      styles={customStyles}
      classNamePrefix="react-select"
      onKeyDown={handleKeyDown}
    />
  );
};

export default DropdownSelect;
