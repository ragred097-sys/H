import React from "react";

import { Accordion, Button, Card, Table } from "react-bootstrap";

import type { Module } from "../../lib/Model";
import { getProviderLogo } from "../../utils/uiUtils";
import { ModuleService } from "./../../services/ModuleService";

const RenderParams = ({ modelDetails, refresh }: { modelDetails: Module; refresh: () => void }) => {
  const handleDelete = async (module: Module) => {
    const response = await ModuleService.deleteModule(module);
    console.debug(response);
    refresh();
  };
  const params = modelDetails.parameters;
  const paramTable = params?.map((param, i) => {
    return (
      <React.Fragment key={i}>
        <tr>
          <td>{param.name}</td>
        </tr>
        <tr>
          <td>{param.value}</td>
        </tr>
      </React.Fragment>
    );
  });
  return (
    <Accordion>
      <Accordion.Item eventKey="0" style={{ fontSize: "0.875rem" }}>
        <Accordion.Header>Details</Accordion.Header>
        <Accordion.Body>
          <Table striped bordered hover size="sm" className="fs-7">
            <thead>
              <tr>
                <td>Module ID</td>
              </tr>
              <tr>
                <td>{modelDetails.id}</td>
              </tr>
            </thead>
            <tbody>{paramTable}</tbody>
          </Table>
          <Button variant="danger" size="sm" onClick={() => handleDelete(modelDetails)}>
            Delete
          </Button>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
  );
};

export default function ModelCard({ modelDetails, refresh }: { modelDetails: Module; refresh: () => void }) {
  const logo = getProviderLogo(modelDetails.name);
  return (
    <div className="p-2" key={modelDetails.id}>
      <Card className="mb-3 text-center text-light d-flex flex-column" style={{ minWidth: "400px", width: "auto" }}>
        <Card.Img variant="top" src={logo} style={{ height: "40px", objectFit: "contain" }} className="p-2" />
        <Card.Header>{modelDetails.name}</Card.Header>
        <Card.Body className="d-flex flex-column">
          <Card.Subtitle className="mb-2 text-muted"></Card.Subtitle>
          <RenderParams modelDetails={modelDetails} refresh={refresh} />
        </Card.Body>
      </Card>
    </div>
  );
}
