import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";

import {
  Card,
  Container,
  Button,
  Dropdown,
  Modal,
  TooltipProps,
} from "react-bootstrap";
import {
  PermissionType,
  TypeName,
  type Agent,
  type AgentWorkflow,
  type Assistant,
  type DataSource,
  type Favoritable,
  type IconName,
  type Module,
  type SystemInstruction,
  type Workspace,
} from "../../lib/Model";
import { useMemo, useState, RefAttributes } from "react";
import AgentDetail from "./AgentDetail";
import NewSystemPromptForm from "../forms/NewSystemPromptForm";
import NewAgentForm from "../forms/NewAgentForm/NewAgentForm";
import WorkspaceForm from "../forms/WorkSpaceForm";
import { NewDataSourceForm } from "../forms/NewDatasourceForm/NewDataSourceForm.tsx";
import { Backend } from "../../lib/Backend";
import { Tooltip, OverlayTrigger } from "react-bootstrap";
import { Bookmark, BookmarkFill } from "react-bootstrap-icons";
import { ShareForm } from "../forms/ShareForm";
import { JSX } from "react/jsx-runtime";
import AgentLineage from "../eqty/lineage/AgentLineage";
import AgentWorkflowLineage from "../eqty/lineage/AgentWorkflowLineage";
import { DefaultIcon, getTranslatedTypeName } from "../../lib/Utils";
import { useNotification } from "./NotificationProvider";
import AgentWorkflowForm from "../forms/AgentWorkflowForm";
import { ToolFormComponent } from "../../components/forms/ToolFormComponent";
import { templatePrefix, toolPrefix } from "../../lib/utils/Constants";

import {
  AgentDirtyFields,
  dirtyFieldsDefaultValues,
  handleAgentDirtyDataTitles,
} from "../../lib/utils/AgentFormFields";
import ConfirmUnsavedModal from "./UnsavedChangesModal";
import { ADMIN_ROLE } from "../../lib/utils/Constants";
import { authStore } from "../../stores/useStore.ts";
import { ModuleForm } from "../forms/ModuleForm.tsx";
import { TranslationKeys } from "../../types/translation-keys.ts";
import { isEqtyEnabled } from "../../lib/utils/eqty";

export default function AgentCard({
  workspace,
  data,
  iconName = "agent",
  launchControl,
  updateTrigger,
  showHideButton,
}: {
  workspace?: Workspace;
  data:
    | Assistant
    | Workspace
    | DataSource
    | SystemInstruction
    | AgentWorkflow
    | Module
    | Agent;
  iconName: IconName;
  onEdit?: () => void;
  enableEdit?: boolean;
  onLaunch?: () => void;
  launchControl?: (agent: Assistant | AgentWorkflow) => void;
  updateTrigger: () => void;
  showHideButton?: boolean; // Optional prop to control visibility of hide button
}) {
  const userId = authStore((state) => state.user?.id);

  const [height, setHeight] = useState<string>("10.7em");
  const [showDetail, setShowDetail] = useState(false);
  const [editTarget, setEditTarget] = useState<
    SystemInstruction | Workspace | DataSource | Module | AgentWorkflow | Agent
  >();
  const [sharingTarget, setSharingTarget] = useState<
    SystemInstruction | Workspace | DataSource | Module | AgentWorkflow | Agent
  >();
  const [showEdit, setShowEdit] = useState(false);
  const [showSharing, setShowSharing] = useState(false);
  const [showEqty, setShowEqty] = useState(false);
  const [isLineageAvailable, setIsLineageAvailable] = useState(false);
  const [isGovernanceCompliant, setIsGovernanceCompliant] = useState<boolean | null>(null);
  const [isFormDirty, setIsFormDirty] = useState(false);
  const [isConfirmClose, setIsConfirmClose] = useState(false);
  const [dirtyFields, setDirtyFields] = useState<AgentDirtyFields>(
    dirtyFieldsDefaultValues
  );
  const navigate = useNavigate();
  const { openErrorNotification } = useNotification();
  const userRoles = authStore((state) => state.roles);
  const { t } = useTranslation();
  const handleShow = () => {
    setShowDetail(true);
  };
  const handleClose = () => {
    setShowDetail(false);
  };
  const handleEdit = (
    data:
      | SystemInstruction
      | Workspace
      | DataSource
      | Module
      | AgentWorkflow
      | Agent
  ) => {
    setEditTarget(data);
    setShowEdit(true);
  };

  const handleSharing = (
    data:
      | SystemInstruction
      | Workspace
      | DataSource
      | Module
      | AgentWorkflow
      | Agent
  ) => {
    setSharingTarget(data);
    setShowSharing(true);
  };

  const renderTooltip = (
    isGovernanceCompliant: boolean | null
  ) => (
    props: JSX.IntrinsicAttributes &
      TooltipProps &
      RefAttributes<HTMLDivElement>
  ) => (
    <Tooltip id="button-tooltip" {...props}>
      {isGovernanceCompliant !== false ? t(TranslationKeys.AGENTCARD_VERIFIEDBYEQTY) : t(TranslationKeys.AGENTCARD_UNVERIFIEDBYEQTY)}
    </Tooltip>
  );

  const handleLaunch = (
    target:
      | Assistant
      | AgentWorkflow
      | Workspace
      | DataSource
      | SystemInstruction
      | Module
      | Agent
  ) => {
    if (target.__type_name === TypeName.Workspace) {
      navigate(`/workspace/${target.id}`);
    }
    if (target.__type_name === TypeName.Assistant && launchControl) {
      launchControl(data! as Assistant);
    }
    if (target.__type_name === TypeName.AgentWorkflow && launchControl) {
      launchControl(data! as AgentWorkflow);
    }
    if (target.__type_name === TypeName.AgentFunction) {
      navigate(`/agent/${target.id}`);
    }
  };

  // Toggle bookmark for a specific card
  const toggleBookmark = (
    data:
      | Assistant
      | Workspace
      | DataSource
      | SystemInstruction
      | Module
      | AgentWorkflow
  ) => {
    try {
      if (data.favorite) {
        // If currently bookmarked, delete the bookmark
        const favoritable: Favoritable = {
          favorite: false,
          id: data.id,
          name: data.name,
          __type_name: data.__type_name,
        };
        Backend.deleteUserFavorite(favoritable).then(() => updateTrigger());
        data.favorite = false;
      } else {
        // If not bookmarked, create the bookmark
        const favoritable: Favoritable = {
          favorite: true,
          id: data.id,
          name: data.name,
          __type_name: data.__type_name,
        };
        Backend.createUserFavorite(favoritable).then(() => updateTrigger());
        data.favorite = true;
      }
    } catch (error) {
      console.error(`Failed to toggle bookmark for card ${data.id}:`, error);
    }
  };

  // Toggle show/hide for a specific card
  const toggleShowEntity = (
    data: Assistant | Workspace | AgentWorkflow | Agent
  ) => {
    try {
      const hideEntity: any = {
        subjectId: data.id,
        subjectType: data.__type_name,
      };
      if (data.hidden) {
        Backend.deleteHiddenEntity(userId, hideEntity).then(() =>
          updateTrigger()
        );
      } else {
        Backend.hideEntity(userId, hideEntity).then(() => updateTrigger());
      }
    } catch (error) {
      console.error(`Failed to hide/unhide entity ${data.name}:`, error);
    }
  };

  const isWorkspace = (data: unknown): data is Workspace => {
    return Boolean(
      data &&
        typeof data === "object" &&
        "__type_name" in data &&
        data.__type_name === TypeName.Workspace
    );
  };

  const isAssistant = (data: unknown): data is Assistant => {
    return Boolean(
      data &&
        typeof data === "object" &&
        "__type_name" in data &&
        data.__type_name === TypeName.Assistant
    );
  };

  const isSuperAgent = (data: unknown): data is AgentWorkflow => {
    return (
      typeof data === "object" &&
      data !== null &&
      "__type_name" in data &&
      (data as { __type_name?: string }).__type_name === TypeName.AgentWorkflow
    );
  };

  function openShareForm(data: boolean) {
    setShowSharing(data);
  }
  useMemo(() => {
    if ("image" in data && data.image) {
      setHeight("20em");
    }
    if (isEqtyEnabled() && data.id && [TypeName.Assistant, TypeName.Agent, TypeName.AgentWorkflow].includes(data.__type_name as TypeName)) {
      Backend.isAgenticLineageAvailable(data as Assistant | Agent | AgentWorkflow)
        .then((isLineageAvailable) => {
          setIsLineageAvailable(isLineageAvailable);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_LINEAGENOTAVL), err as Error);
        });
      Backend.isAgenticGovernanceCompliant(data as Assistant | Agent | AgentWorkflow)
        .then((isCompliant) => {
          setIsGovernanceCompliant(isCompliant);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCESTATUS), err as Error);
          console.error("Error fetching governance status in agent card:", err);
        });
    }
  }, [data.id]);
  //data received from child
  const handleFormDirtyState = (dirtyState: boolean) => {
    setIsFormDirty(dirtyState);
  };

  return (
    <>
      <Card
        className="mb-3 text-center text-light d-flex flex-column card"
        key={data.id}
        style={{
          borderRadius: "var(--bs-border-radius)",
          width: "24em",
          height: height,
          border: "0px",
        }}
      >
        {"image" in data && data.image ? (
          <Card.Header
            className="justify-items-center align-items-center"
            style={{
              padding: 0,
              margin: 0,
              border: "0px",
              borderTopLeftRadius: "var(--bs-border-radius)",
              borderTopRightRadius: "var(--bs-border-radius)",
              overflow: "hidden",
              height: "200px",
            }}
          >
            <img
              src={data.image}
              style={{
                display: "block",
                width: "100%",
                height: "100%",
                objectFit: "cover",
                margin: "0 auto",
                position: "relative",
                top: "50%",
                transform: "translateY(-50%)",
              }}
              alt="Cover Image"
            />
          </Card.Header>
        ) : (
          <></>
        )}
        <Card.Body
          className="d-flex flex-column"
          style={{ border: "0px", padding: "0px", cursor: "pointer" }}
          onClick={() => handleLaunch(data)}
        >
          <Container className="h-100 p-0 d-flex flex-column">
            <div
              className="d-flex"
              style={{
                padding: "0rem 0.75rem 0rem 1rem",
                gap: "0.4em",
                height: "2.5rem"
            }}
            >
              <div
                className="text-start d-flex align-items-center"
                style={{
                  flexGrow: 1,
                  height:"100%"
              }}
              >
                <div
                  className="d-flex align-items-center"
                  style={{
                    width: "13em",
                    fontSize: "1.3em",
                    paddingLeft: "2px",
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis",
                  }}
                >
                  <OverlayTrigger
                    placement="top"
                    overlay={<Tooltip id="card-name" style={{position:"fixed"}}>{data?.name}</Tooltip>}
                  >
                    <span
                      style={{
                        display: "inline-block",
                        width: "100%",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {data?.name?.length > 24
                        ? data?.name?.slice(0, 25) + "..."
                        : data?.name}
                    </span>
                  </OverlayTrigger>
                </div>
              </div>
              <div
              className="d-flex flex-row align-items-center"
              style={{ 
                height:"100%",
                gap:"0.6rem",
                  }}>
                  {/* Bookmark Icon */}
                  {data.__type_name !== TypeName.Agent && (
                    <div className="bookmark-icon">
                      <OverlayTrigger
                        placement="top"
                        overlay={
                          <Tooltip style={{position:"fixed"}}>
                            {data.favorite
                              ? t(TranslationKeys.AGENTCARD_REMOVEBOOKMARK)
                              : t(TranslationKeys.AGENTCARD_ADDBOOKMARK)}
                          </Tooltip>
                        }
                      >
                        <span
                          onClick={(event) => {
                            event.stopPropagation(); // Prevent navigation
                            toggleBookmark(data);
                          }}
                          className={`bookmark-icon-toggle d-inline-block ${data.favorite ? "bookmarked" : "unbookmarked"
                            }`}
                        >
                          {data.favorite ? (
                            <BookmarkFill size={20} />
                          ) : (
                            <Bookmark size={20} />
                          )}
                        </span>
                      </OverlayTrigger>
                    </div>
                  )}

                {(data.__type_name == TypeName.Assistant ||
                  data.__type_name == TypeName.AgentWorkflow ||
                  data.__type_name == TypeName.Workspace ||
                  data.__type_name == TypeName.Agent) && (
                      showHideButton && "hidden" in data && (
                        <div className="hide-icon d-flex align-items-center pt-1">
                          <OverlayTrigger
                            placement="top"
                            overlay={
                              <Tooltip>
                                {data.hidden
                                  ? t("agentCard.unhideEntity")
                                  : t("agentCard.hideEntity")}
                              </Tooltip>
                            }
                          >
                            <span
                              onClick={(event) => {
                                event.stopPropagation();
                                toggleShowEntity(data);
                              }}
                              className={`hide-icon-toggle d-inline-block`}
                            >
                              {data.hidden ? (
                                <i className="bi bi-eye-slash"></i>
                              ) : (
                                <i className="bi bi-eye"></i>
                              )}
                            </span>
                          </OverlayTrigger>
                        </div>
                      )
                    )
                }

                <div
                  className="d-flex align-items-center h-100"
                  onClick={(event) => event.stopPropagation()}
                >
                  <Dropdown align="start" drop="end">
                    <Dropdown.Toggle
                      variant="transparent"
                      id="dropdown-basic"
                      className="no-caret p-0 m-0"
                    >
                      <i className="bi bi-three-dots-vertical"></i>
                    </Dropdown.Toggle>

                    <Dropdown.Menu>
                      <Dropdown.Item onClick={handleShow}>
                        {t(TranslationKeys.AGENTCARD_INFO)}
                      </Dropdown.Item>

                      {data.__type_name !== TypeName.Module &&
                        "accessPermission" in data &&
                        data.accessPermission === PermissionType.WRITE ? (
                        <Dropdown.Item onClick={() => handleEdit(data)}>
                          {t(TranslationKeys.AGENTCARD_EDIT)}
                        </Dropdown.Item>
                      ) : (
                        <>
                          {userRoles?.some(
                            (role) => role.name === ADMIN_ROLE
                          ) && (
                              <Dropdown.Item onClick={() => handleEdit(data)}>
                                {t(TranslationKeys.AGENTCARD_EDIT)}
                              </Dropdown.Item>
                            )}
                        </>
                      )}

                      {data.__type_name !== TypeName.Module &&
                        "accessPermission" in data &&
                        data?.creator?.id === userId && (
                          <Dropdown.Item onClick={() => handleSharing(data)}>
                            {t(TranslationKeys.AGENTCARD_SHARE)}
                          </Dropdown.Item>
                        )}
                    </Dropdown.Menu>
                  </Dropdown>
                </div>
              </div>
            </div>
            <div
              className="d-flex px-3"
              style={{
                gap: "0.8rem",
                alignItems: "center",
                flexGrow: 1,
              }}
            >
              <Button
                variant="transparent"
                onClick={() => handleLaunch(data)}
                style={{ border: "0px", padding: "0px" }}
              >
                <div
                  className="d-flex justify-content-center align-items-center rounded-circle fs-1 text-start "
                  style={{
                    background:
                      "linear-gradient(to bottom right, var(--secondary-color), var(--primary-color))",
                    width: "1.8em",
                    height: "1.8em",
                  }}
                >
                  {!("icon" in data && data.icon) && (
                    <DefaultIcon iconName={iconName} />
                  )}
                  {"icon" in data && data.icon && (
                    <img
                      className="icon"
                      id="icon"
                      src={data.icon}
                      alt="Card Icon"
                    />
                  )}
                </div>
              </Button>
              <p
                className="text-muted text-start mb-0"
                style={{
                  overflow: "hidden",
                  display: "-webkit-box",
                  WebkitBoxOrient: "vertical",
                  WebkitLineClamp: 3,
                  textOverflow: "ellipsis",
                  width: "16em",
                  height: "4.7em",
                  flexGrow: 1,
                }}
              >
                {data.description}
              </p>
            </div>
            <div className="d-flex justify-content-between align-items-center"
            style={{
              height:"2rem",
            }}
            >
              <div className="text-start share-icon ellipsis">
                {(isWorkspace(data) ||
                  isAssistant(data) ||
                  isSuperAgent(data)) &&
                  ((data.sharedWithUsers && data.sharedWithUsers.length > 0) ||
                    (data.sharedBy && data.sharedBy !== "N/A")) && (
                    <>
                      <i className="bi bi-share"></i>
                      {data.sharedWithUsers &&
                        data.sharedWithUsers.length > 0 && (
                          <OverlayTrigger
                            placement="top"
                            overlay={
                              <Tooltip id="shared-with-tooltip">
                                {data.sharedWithUsers.join(", ")}{" "}
                                {/* Full list of users */}
                              </Tooltip>
                            }
                          >
                            <span className="ms-0">
                              Shared with{" "}
                              {data.sharedWithUsers
                                .slice(0, 2)
                                .join(", ")
                                .slice(0, 26) +
                                (data.sharedWithUsers.slice(0, 2).join(", ")
                                  .length > 26
                                  ? "..."
                                  : "")}
                            </span>
                          </OverlayTrigger>
                        )}
                      {data.sharedBy && data.sharedBy !== "N/A" && (
                        <span className="ms-0">
                          {t(TranslationKeys.AGENTCARD_SHAREDBY)}{" "}
                          {data.sharedBy.length > 30
                            ? `${data.sharedBy.slice(0, 26)}...`
                            : data.sharedBy}
                        </span>
                      )}
                    </>
                  )}
              </div>
              <div className="text-end">
                {data.__type_name === TypeName.Assistant ||
                data.__type_name === TypeName.Agent ||
                data.__type_name === TypeName.AgentWorkflow ? (
                  <OverlayTrigger
                    placement="right"
                    delay={{ show: 250, hide: 400 }}
                    overlay={renderTooltip(isGovernanceCompliant)}
                  >
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowEqty(isLineageAvailable);
                      }}
                    >
                      <Button
                        style={{
                          borderColor: "transparent",
                        }}
                        variant="transparent"
                        disabled={!isLineageAvailable}
                      >
                        <i
                          className={`bi bi-shield${isGovernanceCompliant === null ? "" : "-fill"}${isGovernanceCompliant !== false ? "-check" : "-exclamation"}`}
                          style={{ color: (isGovernanceCompliant !== false ? "green" : "red") }}
                        ></i>
                      </Button>
                    </div>
                  </OverlayTrigger>
                ) : null}
              </div>
            </div>
          </Container>
        </Card.Body>
      </Card>
      {/* DETAIL MODAL */}
      <Modal
        show={showDetail}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop semi-fat-modal"
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>{data.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AgentDetail data={data} launchControl={launchControl} />
        </Modal.Body>
      </Modal>

      {showEdit && editTarget?.__type_name === TypeName.AgentWorkflow ? (
        <AgentWorkflowForm
          show={showEdit}
          onHide={() => setShowEdit(false)}
          workspace={workspace}
          initialData={editTarget as AgentWorkflow}
          handleClose={() => setShowEdit(false)}
          updateTrigger={updateTrigger}
        />
      ) : (
        <Modal
          show={showEdit}
          onHide={() => {
            if (
              editTarget?.__type_name === TypeName.Assistant ||
              editTarget?.__type_name === TypeName.Agent ||
              editTarget?.__type_name === TypeName.DataSource
            ) {
              if (isFormDirty) {
                // Show alert if form is dirty
                setIsConfirmClose(true);
              } else {
                setShowEdit(false);
              }
            } else {
              setShowEdit(false);
            }
          }}
          backdrop="static"
          size="xl"
          centered
          className="text-light custom-modal-backdrop"
        >
          <Modal.Header
            closeButton
            style={{ fontSize: "1.2em", fontWeight: 600 }}
          >
            {editTarget?.name}
          </Modal.Header>
          {/* EDIT MODAL */}
          <Modal.Body>
            {editTarget?.__type_name === TypeName.SystemInstruction ? (
              editTarget.name?.startsWith("Nav.AI") ? (
                <ToolFormComponent
                  initialData={editTarget as SystemInstruction}
                  toolForm={
                    editTarget.name?.startsWith(toolPrefix)
                      ? toolPrefix
                      : templatePrefix
                  }
                  onToolCreated={() => {
                    updateTrigger();
                    setShowEdit(false);
                  }}
                  updateTrigger={updateTrigger}
                />
              ) : (
                <NewSystemPromptForm
                  initialData={editTarget as SystemInstruction}
                  handleClose={() => setShowEdit(false)}
                  updateTrigger={updateTrigger}
                />
              )
            ) : editTarget?.__type_name === TypeName.Assistant ? (
              <>
                <NewAgentForm
                  initialData={editTarget as Assistant}
                  handleClose={() => setShowEdit(false)}
                  updateTrigger={updateTrigger}
                  onUpdateAgentFormDirty={handleFormDirtyState}
                  onUpdateAgentDirtyData={(data: AgentDirtyFields) =>
                    handleAgentDirtyDataTitles(data, setDirtyFields)
                  }
                />
              </>
            ) : editTarget?.__type_name === TypeName.Workspace ? (
              <WorkspaceForm
                initialData={editTarget as Workspace}
                handleClose={() => setShowEdit(false)}
                updateTrigger={updateTrigger}
              />
            ) : editTarget?.__type_name === TypeName.DataSource ? (
              <>
                <NewDataSourceForm
                  initialDataSourceId={editTarget.id}
                  handleClose={() => setShowEdit(false)}
                  updateTrigger={updateTrigger}
                  onUpdateAgentFormDirty={handleFormDirtyState}
                />
              </>
            ) : editTarget?.__type_name === TypeName.Module ? (
              <>
                <ModuleForm
                  defaultValues={editTarget as Module}
                  handleClose={() => setShowEdit(false)}
                  updateTrigger={updateTrigger}
                />
              </>
            ) : editTarget?.__type_name === TypeName.Agent ? (
              <>
                <NewAgentForm
                  initialData={editTarget as Agent}
                  handleClose={() => setShowEdit(false)}
                  updateTrigger={updateTrigger}
                  onUpdateAgentFormDirty={handleFormDirtyState}
                  onUpdateAgentDirtyData={(data: AgentDirtyFields) =>
                    handleAgentDirtyDataTitles(data, setDirtyFields)
                  }
                  isUtilityAgent={true}
                />
              </>
            ) : (
              <>{JSON.stringify(editTarget)}</>
            )}
          </Modal.Body>
        </Modal>
      )}
      {/* Sharing Modal */}
      <Modal
        show={showSharing}
        onHide={() => setShowSharing(false)}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop "
      >
        <Modal.Header closeButton>
          {t(TranslationKeys.AGENTCARD_SHAREWITH, {
            type: getTranslatedTypeName(sharingTarget?.__type_name),
            name: sharingTarget?.name || "",
          })}
        </Modal.Header>
        <Modal.Body>
          <ShareForm
            // @ts-expect-error to be fixed
            data={sharingTarget}
            openShareForm={openShareForm}
            updateTrigger={updateTrigger}
          />
        </Modal.Body>
      </Modal>
      {/* EQTY Modal */}
      <Modal
        show={showEqty}
        onHide={() => setShowEqty(false)}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop eqty-modal"
        fullscreen
      >
        <Modal.Header closeButton></Modal.Header>
        <Modal.Body>
          {data.__type_name === TypeName.Assistant || data.__type_name === TypeName.Agent ? (
            <AgentLineage agent={data as Assistant} />
          ) : (
            <AgentWorkflowLineage workflow={data as AgentWorkflow} />
          )}
        </Modal.Body>
      </Modal>

      {isConfirmClose && (
        <ConfirmUnsavedModal
          isConfirmClose={isConfirmClose}
          dirtyFields={dirtyFields}
          setIsConfirmClose={setIsConfirmClose}
          setShowEdit={setShowEdit}
        />
      )}
    </>
  );
}
