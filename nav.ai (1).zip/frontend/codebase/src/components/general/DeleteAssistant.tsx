import { useState } from "react";

import { Button } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Assistant, SystemInstruction } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { ApplicationService } from "./../../services/ApplicationService";
import ConfirmationDialog from "./ConfirmationDialog";
import LoadingButton from "./LoadingButton/LoadingButton";
import { useNotification } from "./NotificationProvider";
import TableComponent from "./Table";

interface DeleteAssistantProps {
  assistant: Assistant | null;
  dataSources?: string[];
  systemPrompts?: string[];
  handleClose?: () => void;
  onDelete?: (id: string) => void;
  updateTrigger?: () => void;
  systemInstructions: SystemInstruction[];
  templates: SystemInstruction[];
  templatesList: string[];
  handleAssistantClose?: () => void;
}
function DeleteAssistant({
  assistant,
  dataSources,
  handleAssistantClose,
  handleClose,
  systemInstructions,
  systemPrompts,
  templates,
  templatesList,
  updateTrigger,
}: DeleteAssistantProps) {
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();

  async function handleDelete() {
    if (
      systemInstructions?.length > 0 ||
      (assistant?.dataSourceIds && assistant.dataSourceIds.length > 0) ||
      templates?.length > 0
    ) {
      setShowConfirmation(true);
    } else {
      deleteAssistant();
    }
  }
  const deleteAssistant = async () => {
    if (assistant?.id) {
      setDeleteLoading(true);
      ApplicationService.recursiveDelete(assistant?.__type_name, assistant?.id)
        .then(() => {
          openNotification(t(TranslationKeys.MESSAGES_DELETEAGENTSUCCESS), "primary");
          setDeleteLoading(false);
        })
        .catch((err) => {
          setDeleteLoading(false);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETEASSISTANT), err as Error);
        })
        .finally(() => {
          setDeleteLoading(false);
          if (handleClose) handleClose();
          if (updateTrigger) updateTrigger();
        });
    }
  };
  //soft delete system-prompt and dataset
  async function softDelete() {
    if (!assistant?.id) {
      console.error("assistant ID is missing.");
      return;
    } else {
      deleteAssistant();
    }
  }
  //get the maximum number to set the row for all columns
  const maxRow = Math.max(
    systemInstructions?.length || 0,
    assistant?.dataSourceIds?.length || 0,
    templates?.length || 0
  );
  //show modified entities in heading
  const tableHeadingEntities = {
    [t(TranslationKeys.MESSAGES_DATASOURCES)]:
      Array.isArray(assistant?.dataSourceIds) && assistant?.dataSourceIds.length > 0,
    [t(TranslationKeys.MESSAGES_SYSTEMPROMPTS)]: systemInstructions.length > 0,
    [t(TranslationKeys.WORKSPACEDETAIL_NAVAITEMPLATES)]: templates?.length > 0,
  };
  const tableData = () => {
    const associatedDataTitles = columnsHeading();
    const data: { [key: string]: string[] }[] = [];
    associatedDataTitles.forEach((title) => {
      switch (title) {
        case t(TranslationKeys.MESSAGES_SYSTEMPROMPTS):
          data.push({ [title]: systemPrompts || [] });
          break;
        case t(TranslationKeys.MESSAGES_DATASOURCES):
          data.push({ [title]: dataSources || [] });
          break;
        case t(TranslationKeys.WORKSPACEDETAIL_NAVAITEMPLATES):
          data.push({ [title]: templatesList || [] });
          break;
        default:
          break;
      }
    });
    return data;
  };
  const columnsHeading = () => {
    const tableHead = [
      systemInstructions?.length && t(TranslationKeys.MESSAGES_SYSTEMPROMPTS),
      assistant?.dataSourceIds?.length && t(TranslationKeys.MESSAGES_DATASOURCES),
      templates?.length && t(TranslationKeys.WORKSPACEDETAIL_NAVAITEMPLATES),
    ];
    return tableHead.filter(Boolean) as string[];
  };

  return (
    <div>
      <div className="d-flex flex-row">
        <p>{t(TranslationKeys.MESSAGES_DELETEAGENTCONFIRM, { agentName: assistant?.name })}</p>
      </div>
      {Object.values(tableHeadingEntities)?.some((value) => value === true) && (
        <>
          <p>
            {t(TranslationKeys.MESSAGES_DELETEAGENTASSOCIATED, {
              entityItems: Object.entries(tableHeadingEntities)
                .filter(([, value]) => value)
                .map(([key]) => key)
                .reduce((acc, curr, index, arr) => {
                  if (arr.length === 1) return curr;
                  if (index === arr.length - 1) return `${acc} and ${curr}`;
                  return `${acc}, ${curr}`;
                }),
            })}
          </p>

          <TableComponent
            loading={false}
            maxRow={maxRow}
            tableColumnHeadings={columnsHeading()}
            tableData={tableData()}
          />
        </>
      )}
      <div className="d-flex flex-row justify-content-end mt-3">
        {deleteLoading && showConfirmation == false ? (
          <LoadingButton className={"btn btn-danger me-4"} />
        ) : (
          <Button className="me-4" variant="danger" type="button" onClick={() => handleDelete()}>
            {t(TranslationKeys.MESSAGES_DELETE)}
          </Button>
        )}
        <Button className="me-4" variant="secondary" type="button" onClick={handleAssistantClose}>
          {t(TranslationKeys.MESSAGES_CANCEL)}
        </Button>
      </div>
      {showConfirmation && (
        <ConfirmationDialog
          show={showConfirmation}
          confirmationQuestion={t(TranslationKeys.MESSAGES_CONFIRMDELETECHAT)}
          confirmationButtonLabel={t(TranslationKeys.MESSAGES_CONFIRMDELETEYES)}
          onConfirm={softDelete}
          onClose={() => {
            setShowConfirmation(false);
          }}
          variant="danger"
          isConfirmationLoading={deleteLoading}
          isWorkspaceDelete={true}
        />
      )}
    </div>
  );
}

export default DeleteAssistant;
