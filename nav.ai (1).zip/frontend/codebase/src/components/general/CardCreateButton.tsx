import { Card } from "react-bootstrap";

export const CardCreateButton = ({ data, onClickCreate }: { data: string; onClickCreate: any }) => {
  return (
    <Card
      className="mb-3 text-center text-light card"
      onClick={onClickCreate}
      style={{
        border: "none",
        borderRadius: "var(--bs-border-radius)",
        cursor: "pointer",
        display: "flex",
        height: "10.7em",
        justifyContent: "center",
        marginRight: "0.5em",
        width: "24em",
      }}
    >
      <div style={{ display: "flex", flexDirection: "row", justifyContent: "center" }}>
        <i
          className="bi bi-plus-square-fill"
          style={{
            fontSize: "2em",
            marginRight: "0.5em",
          }}
        ></i>
        <h4
          style={{
            paddingTop: "0.35em",
          }}
        >
          {data}
        </h4>
      </div>
    </Card>
  );
};
