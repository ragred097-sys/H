import { useCallback, useEffect, useState } from "react";

import { useTranslation } from "react-i18next";
// <-- Add this
import { useLocation, useNavigate, useParams } from "react-router-dom";

import { AgentWorkflow, Assistant, TypeName } from "../../lib/Model";
import { authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import Breadcrumbs from "../chat/BreadCrumbs";
import Agents from "../layout/Agents";
import { Workspace } from "../layout/Workspace";
import { RenderLandingCards } from "../renderers/RenderLandingCards";
import { AccessControlService } from "./../../services/AccessControlService";
import { AgentWorkflowService } from "./../../services/AgentWorkflowService";
import { UserService } from "./../../services/UserService";
import { WorkspaceService } from "./../../services/WorkspaceService";
import CardSkeleton from "./CardSkeleton";

const AgentDirectoryDetails = () => {
  const location = useLocation();
  const tagName = location?.state?.tagName;
  const { tag } = useParams();
  const userId = authStore((state) => state.user?.id);
  const navigate = useNavigate();
  const { t } = useTranslation(); // <-- Add this
  //states
  const [loading, setLoading] = useState(false);
  const [superAgents, setSuperAgents] = useState<AgentWorkflow[]>([]); // For assistants created by the user
  const [sharedSuperAgents, setSharedSuperAgents] = useState<AgentWorkflow[]>([]);
  const fetchAgentWorkflows = useCallback(async () => {
    try {
      setLoading(true);
      const [superAgentsData, users] = await Promise.all([
        AgentWorkflowService.getAgentWorkflows(),
        UserService.getUsers(), // Fetch all users
      ]);
      if (userId) {
        const superAgentsArray: AgentWorkflow[] = await Promise.all(
          superAgentsData
            .filter((superagent) => superagent.creator.id === userId)
            .map(async (superAgent) => {
              const grants = await AccessControlService.getGrants(superAgent);
              const sharedWithIds = grants
                .filter((grant) => grant.assigneeType === TypeName.User)
                .map((grant) => grant.assigneeId);

              const sharedWithUsers = users.filter((user) => sharedWithIds.includes(user.id)).map((user) => user.name);
              return {
                ...superAgent,
                sharedWithUsers,
              };
            })
        );

        const sharedSuperAgents = await Promise.all(
          superAgentsData
            .filter((superAgent) => superAgent.creator.id !== userId)
            .map((superAgent) => {
              const sharedBy = superAgent.creator.name;
              return {
                ...superAgent,
                sharedBy, // Attach sharedBy to sharedSuperagents
              };
            })
        );
        setSuperAgents(
          superAgentsArray.filter((item) => item?.tags?.some((tagInItem) => tagInItem.name.toLowerCase() === tag))
        );
        setSharedSuperAgents(
          sharedSuperAgents.filter((item: AgentWorkflow) =>
            item?.tags?.some((tagInItem) => tagInItem.name.toLowerCase() === tag)
          )
        );
      }
    } catch {
      //   openErrorNotification("Error fetching super agents", error as Error);
    } finally {
      setLoading(false);
    }
  }, [userId, tag]);
  useEffect(() => {
    fetchAgentWorkflows();
  }, [fetchAgentWorkflows]);

  async function launchSuperAgent(agent: Assistant | AgentWorkflow) {
    if ("id" in agent) {
      try {
        const workspacesData = await WorkspaceService.getWorkspaces();
        let wsId: string | undefined;
        if (userId) {
          // Process "My Workspaces"
          const myWorkspaces = await Promise.all(
            workspacesData
              .filter((workspace) => workspace.creator.id === userId)
              .map(async (workspace) => {
                return workspace;
              })
          );

          // Process "Shared Workspaces"
          const sharedWorkspaces = await Promise.all(
            workspacesData
              .filter((workspace) => workspace.creator.id !== userId)
              .map(async (workspace) => {
                return workspace;
              })
          );

          // Combine myWorkspaces and sharedWorkspaces
          const allWorkspaces = [...myWorkspaces, ...sharedWorkspaces];

          for (const workspace of allWorkspaces) {
            const superAgentsInWorkspace = await WorkspaceService.getWorkspaceAgentWorkflows(workspace); // Fetch super agents in the workspace
            if (superAgentsInWorkspace.some((workspaceSuperAgent) => workspaceSuperAgent.id === agent.id)) {
              wsId = workspace.id;
              break;
            }
          }
        }

        if (wsId) {
          navigate(`/workspace/${wsId}/superagent/${agent.id}`);
        } else {
          navigate(`/workspace/${"empty"}/superagent/${agent.id}`);
        }
      } catch (error) {
        console.error("Failed to fetch workspace ID for the agent:", error);
      }
    }
  }
  return (
    <>
      <Breadcrumbs tagName={tagName} />
      <div>
        <h3>{`${tagName}`}</h3>
        <div>
          <h4 className="mt-4 mb-3">{t(TranslationKeys.NAV_WORKSPACES)}</h4>
          <div className="d-flex flex-wrap">
            <Workspace filterOnTags={tagName} />
          </div>
          <h4 className="mt-3 mb-3">{t(TranslationKeys.NAV_AGENTS)}</h4>
          <div className="d-flex flex-wrap">
            <Agents filterOnTags={tagName} />
          </div>
          <h4 className="mt-3 mb-3">{t(TranslationKeys.NAV_SUPERAGENTS)}</h4>
          <div className="d-flex flex-wrap">
            {loading ? (
              <CardSkeleton />
            ) : [...superAgents, ...sharedSuperAgents].length > 0 ? (
              <RenderLandingCards
                agents={[...superAgents, ...sharedSuperAgents]}
                type="agent"
                launchControl={launchSuperAgent}
                updateTrigger={() => {
                  fetchAgentWorkflows();
                }}
              />
            ) : (
              <div>
                <p>{t(TranslationKeys.CUBES_NOSUPERAGENT, { tagName: tagName })}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};
export default AgentDirectoryDetails;
