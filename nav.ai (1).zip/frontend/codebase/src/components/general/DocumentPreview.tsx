import React, { useEffect, useState } from "react";

import { AttachedFile } from "./AttachedFile";
import pdfIcon from "../../assets/images/pdfIcon.png";
import pptIcon from "../../assets/images/pptxIcon.png";
import wordIcon from "../../assets/images/wordIcon.png";
import excelIcon from "../../assets/images/xslxIcon.png";
import { Attachment, DocumentPreviewProps, DocumentType, TypeName } from "../../lib/Model";

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({ document, onRemove }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const fileType = {
    excel: "application/vnd.ms-excel",
    pdf: "application/pdf",
    ppt: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    wordDoc: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  };
  useEffect(() => {
    let mounted = true;
    if (document && (document as Attachment)?.__type_name == TypeName.Attachment) {
      const doc = document as Attachment;
      if (doc.type === "IMAGE") {
        setPreview(doc.thumbnail as string);
      } else if (doc.type === "TEXT") {
        if (doc.mimeType === fileType.ppt) {
          setPreview(pptIcon);
        } else if (doc.mimeType === fileType.pdf) {
          setPreview(pdfIcon);
        } else if (doc.mimeType === fileType.wordDoc) {
          setPreview(wordIcon);
        } else if (doc.mimeType === fileType.excel) {
          setPreview(excelIcon);
        }
      }
    } else {
      const doc = document as AttachedFile;
      const loadPreview = async () => {
        const url = await doc.getPreviewUrl();
        if (mounted) {
          setPreview(url);
        }
      };

      loadPreview();
    }
    return () => {
      mounted = false;
    };
  }, [document]);

  const getFileIcon = () => {
    switch (document.type) {
      case DocumentType.VIDEO:
        return "bi-camera-video";
      case DocumentType.AUDIO:
        return "bi-file-music";
      case DocumentType.TEXT:
        return "bi-file-pdf";
      default:
        return "bi-file-earmark";
    }
  };

  return (
    <div className="position-relative" style={{ height: "50px", width: "50px" }}>
      {preview ? (
        <img src={preview} alt={document.name} className="w-100 h-100 object-fit-cover rounded" />
      ) : (
        <div className="w-100 h-100 d-flex align-items-center justify-content-center bg-secondary rounded">
          <i className={`bi ${getFileIcon()} text-light`}></i>
        </div>
      )}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}
        className="position-absolute top-0 end-0 btn btn-sm p-0 rounded-circle"
        style={{
          backgroundColor: "rgba(0,0,0,0.5)",
          border: "none",
          height: "20px",
          width: "20px",
        }}
      >
        <i className="bi bi-x text-white" style={{ fontSize: "12px" }}></i>
      </button>
    </div>
  );
};
