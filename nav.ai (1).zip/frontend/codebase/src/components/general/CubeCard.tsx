import { BaseSyntheticEvent, useEffect, useRef, useState } from "react";

import { motion } from "framer-motion";

import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";

import { Cube, TagInsideCategory } from "../../lib/Model";
import { authStore } from "../../stores/useStore";
import { TranslationKeys } from "../../types/translation-keys";
import { ADMIN_ROLE } from "../../utils/constants";
import { TagService } from "./../../services/TagService";
import { useNotification } from "./NotificationProvider";

interface CubeCardProps {
  data: TagInsideCategory; //single tag data
  cubeCategoryData: Cube; //tag category
  handleUpdate?: () => void;
}
const CubesCard = ({ cubeCategoryData, data, handleUpdate }: CubeCardProps) => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { openErrorNotification, openNotification } = useNotification();
  const cardRef = useRef<HTMLDivElement>(null); // Ref for the main card div
  const removeButtonRef = useRef<HTMLButtonElement>(null); // Ref for the remove button

  const [showActions, setShowActions] = useState(false);
  //check for access
  const [hasAccess, setHasAccess] = useState<boolean>(false);
  const userRoles = authStore((state) => state.roles);

  useEffect(() => {
    setHasAccess(userRoles?.some((role) => role.name == ADMIN_ROLE));
  }, [userRoles]);
  const removeTagFromCategory = async () => {
    try {
      const response = await TagService.deleteTag(data, cubeCategoryData as Cube);
      if (response) {
        handleUpdate?.();
        openNotification(t(TranslationKeys.MESSAGES_DELETETAGFROMCATEGORY), "primary");
      }
    } catch (error) {
      openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETETAGFROMCATEGORY), error as Error);
    }
  };

  const handleCardClick = () => {
    const tagToLowerCase = data?.name.toLowerCase();
    navigate(`/tags/${tagToLowerCase}`, {
      state: {
        tagName: data?.name,
      },
    });
  };

  const handleRemoveButtonClick = (e: BaseSyntheticEvent) => {
    e.stopPropagation();
    e.preventDefault();
    removeTagFromCategory();
  };

  return (
    <>
      <motion.div
        ref={cardRef}
        className="cube-card mt-4"
        onHoverStart={() => setShowActions(true)}
        onHoverEnd={() => setShowActions(false)}
        whileHover={{
          scale: 1.1,
        }}
        onClick={handleCardClick}
        style={{ cursor: "pointer" }}
      >
        {showActions && hasAccess && (
          <>
            <motion.button
              ref={removeButtonRef}
              className="btn btn-danger cube-button right-1/2 transform -translate-x-1/2 flex space-x-2"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.8 }}
              initial={{ opacity: 0, x: "100%" }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: "-100%" }}
              onClick={handleRemoveButtonClick}
              style={{ zIndex: "10" }}
            >
              <i className="bi bi-x-square-fill text-danger"></i>
            </motion.button>
          </>
        )}
        <div
          className="cube-body"
          style={{
            padding: "1em", //to avoid overlapping of cross icon and cube name
          }}
        >
          <h6
            className="cube-text mb-0"
            style={{
              display: "-webkit-box",
              overflow: "hidden",
              textOverflow: "ellipsis",
              WebkitBoxOrient: "vertical",
              WebkitLineClamp: 2,
            }}
          >
            {data?.name}
          </h6>
        </div>
      </motion.div>
    </>
  );
};
export default CubesCard;
