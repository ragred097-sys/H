import { useEffect, useState } from "react";

import { Tab, Tabs } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";

import { type AccessRole } from "../../lib/Model";
import { authStore } from "../../stores/useStore.ts";
import { TranslationKeys } from "../../types/translation-keys";
import { ADMIN_ROLE } from "../../utils/constants";
import Breadcrumbs from "../chat/BreadCrumbs.tsx";
import { AccessControlService } from "./../../services/AccessControlService";
import DirectMembers from "./DirectMembers";
import ExternalRoleMapping from "./ExternalRoleMapping";
import { useNotification } from "./NotificationProvider";

function RoleDetail() {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const { roleId } = useParams() as { roleId: string };
  const [currentRole, setCurrentRole] = useState<AccessRole | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hasAccess, setHasAccess] = useState<boolean>(false);
  const userRoles = authStore((state) => state.roles);

  useEffect(() => {
    setHasAccess(userRoles?.some((role) => role.name == ADMIN_ROLE));
  }, [userRoles]);

  useEffect(() => {
    const fetchRoleById = async () => {
      try {
        const selectedRole = await AccessControlService.getAccessRoleById(roleId);
        if (selectedRole) {
          setCurrentRole(selectedRole);
        } else {
          setError(t(TranslationKeys.ROLES_NOTFOUND));
        }
      } catch (err) {
        openErrorNotification(t(TranslationKeys.ROLES_FETCHERROR), err as Error);
        setError(t(TranslationKeys.ROLES_FETCHDETAILSERROR));
      }
    };
    if (roleId) {
      fetchRoleById();
    }
  }, [roleId]);

  if (error) {
    return (
      <>
        {t(TranslationKeys.ROLES_ERRORLOADING)} {error}
      </>
    );
  }
  if (!currentRole) {
    return <>{t(TranslationKeys.ROLES_NOTFOUNDWITHID, { id: roleId })}</>;
  }

  return (
    <div>
      <Breadcrumbs currentRole={currentRole} roleId={roleId} />
      <h2 className="mt-4 d-flex align-items-center mb-4">{currentRole.name}</h2>
      {hasAccess ? (
        <Tabs defaultActiveKey="direct-members" className="mb-3">
          <Tab eventKey="direct-members" title={t(TranslationKeys.ROLES_DIRECTMEMBERS)}>
            <DirectMembers role={currentRole} />
          </Tab>
          <Tab eventKey="external-role-mapping" title={t(TranslationKeys.ROLES_EXTERNALROLEMAPPING)}>
            <ExternalRoleMapping role={currentRole} />
          </Tab>
        </Tabs>
      ) : (
        <span>{t(TranslationKeys.ROLES_NOACCESS)}</span>
      )}
    </div>
  );
}

export default RoleDetail;
