import React, { useRef, useState } from "react";

import { Alert, Button, Form, ProgressBar, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { TranslationKeys } from "../../types/translation-keys";
import { MAX_IMAGE_SIZE } from "../../utils/constants";

interface FooterBannerUploadProps {
  value: string;
  onChange: (val: string) => void;
  label?: string;
  placeholder?: string;
  maxFileSize?: number;
  acceptedFormats?: string[];
}

const FooterBannerUpload: React.FC<FooterBannerUploadProps> = ({
  acceptedFormats = ["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg"],
  label,
  maxFileSize = MAX_IMAGE_SIZE || 5, // Default to 5MB
  onChange,
  placeholder,
  value,
}) => {
  const { t } = useTranslation();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [inputUrl, setInputUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Unified change handler
  const handleChange = (newValue: string) => {
    onChange(newValue);
    setInputUrl("");
    setError(null);
    setIsLoading(false);
    setUploadProgress(0);
  };

  // File validation
  const validateFile = (file: File): string | null => {
    const extension = file.name.split(".").pop()?.toLowerCase();
    if (!extension || !acceptedFormats.includes(extension)) {
      return t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_INVALIDFORMAT, {
        formats: acceptedFormats.join(", "),
      });
    }
    if (file.size / (1024 * 1024) > maxFileSize) {
      return t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_FILETOOLARGE, {
        fileSize: (file.size / (1024 * 1024)).toFixed(1),
        maxSize: maxFileSize,
      });
    }
    return null;
  };

  // File upload handler
  const handleFile = (file: File) => {
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      return;
    }
    setError(null);
    setIsLoading(true);
    setUploadProgress(0);

    const reader = new FileReader();
    reader.onprogress = (e) => e.lengthComputable && setUploadProgress((e.loaded / e.total) * 100);
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      setTimeout(() => handleChange(dataUrl), 300);
    };
    reader.onerror = () => {
      setError(t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_FAILEDTOREADFILE));
      setIsLoading(false);
    };
    reader.readAsDataURL(file);
  };

  // Event handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
    setError(null);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    if (!e.currentTarget.contains(e.relatedTarget as Node)) setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length === 1) handleFile(files[0]);
    else if (files.length > 1) setError(t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_UPLOADONLYONEIMAGE));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setInputUrl(url);
    setError(null);
    if (url.startsWith("data:image/")) handleChange(url);
  };

  const handleRemove = () => {
    handleChange("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Style utilities
  const getStateColor = () => {
    if (isLoading) return "var(--bs-info)";
    if (error) return "var(--bs-danger)";
    if (isDragOver) return "var(--bs-success)";
    return "var(--bs-border-color)";
  };

  const getStateBg = () => {
    const color = getStateColor();
    const opacity = isLoading ? "5%" : error ? "5%" : isDragOver ? "8%" : "100%";
    return isDragOver || error || isLoading
      ? `color-mix(in srgb, ${color} ${opacity}, var(--bs-body-bg))`
      : "var(--bs-body-bg)";
  };

  // Check if value is a valid image
  const hasImage = value && (value.startsWith("data:image/") || value.match(/\.(jpg|jpeg|png|gif|bmp|webp)$/i));

  return (
    <div>
      {label && <Form.Label>{label}</Form.Label>}

      {error && (
        <Alert
          variant="danger"
          className="mb-3 py-2 px-3 border-0 rounded-3"
          style={{ backgroundColor: "color-mix(in srgb, var(--bs-danger) 10%, var(--bs-body-bg))", fontSize: "14px" }}
        >
          <i className="bi bi-exclamation-circle me-2"></i>
          {error}
        </Alert>
      )}

      {hasImage ? (
        <div className="d-flex flex-column align-items-center mb-3">
          <div className="position-relative" style={{ maxWidth: 320 }}>
            <img
              src={value}
              alt={t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_IMAGEUPLOADED)}
              className="img-fluid rounded-3 border shadow-sm"
              style={{
                display: "block",
                maxHeight: 100,
                maxWidth: "100%",
                objectFit: "contain",
              }}
            />
            <Button
              variant="danger"
              size="sm"
              className="position-absolute top-0 end-0 m-2 rounded-circle d-flex align-items-center justify-content-center"
              style={{
                height: 22,
                padding: 0,
                width: 22,
              }}
              onClick={handleRemove}
              aria-label={t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_REMOVEIMAGE)}
            >
              <i className="bi bi-x fs-6"></i>
            </Button>
          </div>
          <div className="mt-2 text-success small text-center">
            <i className="bi bi-check-circle me-1"></i>
            {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_IMAGEUPLOADED)}
          </div>
        </div>
      ) : (
        <>
          <div
            className="mb-3"
            style={{
              alignItems: "center",
              background: getStateBg(),
              border: `2px ${error ? "solid" : "dashed"} ${getStateColor()}`,
              borderRadius: 16,
              cursor: isLoading ? "wait" : "pointer",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              minHeight: 140,
              transition: "all 0.3s ease-in-out",
            }}
            onClick={() => !isLoading && fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {isLoading ? (
              <div className="text-center">
                <Spinner animation="border" size="sm" style={{ color: getStateColor() }} className="mb-2" />
                <div style={{ fontSize: 16, fontWeight: 600 }}>
                  {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_PROCESSINGIMAGE)}
                </div>
                {uploadProgress > 0 && (
                  <div style={{ color: "var(--bs-secondary-color)", fontSize: 14, marginTop: 4 }}>
                    {Math.round(uploadProgress)}% complete
                  </div>
                )}
                {uploadProgress > 0 && (
                  <ProgressBar
                    now={uploadProgress}
                    className="mt-2"
                    style={{ height: "6px", width: "200px" }}
                    variant="info"
                  />
                )}
              </div>
            ) : (
              <div className="text-center">
                <div
                  className="mb-3"
                  style={{
                    alignItems: "center",
                    background: `color-mix(in srgb, ${getStateColor()} 15%, transparent)`,
                    borderRadius: "50%",
                    display: "flex",
                    height: 64,
                    justifyContent: "center",
                    margin: "0 auto",
                    width: 64,
                  }}
                >
                  <i
                    className={isDragOver ? "bi bi-cloud-arrow-down" : "bi bi-cloud-upload"}
                    style={{
                      color: getStateColor(),
                      fontSize: 28,
                      transition: "all 0.2s ease-in-out",
                    }}
                  />
                </div>

                <div style={{ fontSize: 18, fontWeight: 600, marginBottom: 6 }}>
                  {isDragOver
                    ? t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_DROPIMAGEHERE)
                    : t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_CLICKTOUPLOAD)}
                </div>

                <div style={{ color: "var(--bs-secondary-color)", fontSize: 14, lineHeight: 1.4 }}>
                  {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_SUPPORTS, {
                    formats: acceptedFormats.join(", ").toUpperCase(),
                  })}
                  <br />
                  {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_MAXSIZE, {
                    maxSize: maxFileSize / (1024 * 1024),
                  })}
                </div>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept={acceptedFormats.map((fmt) => `.${fmt}`).join(",")}
              onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
              style={{ display: "none" }}
              disabled={isLoading}
            />
          </div>

          <div className="d-flex align-items-center mb-2">
            <div className="flex-grow-1 position-relative">
              <Form.Control
                type="url"
                style={{
                  background: "var(--bs-body-bg)",
                  borderColor: getStateColor(),
                  borderRadius: 12,
                  color: "var(--bs-body-color)",
                  fontSize: 15,
                  height: 44,
                  paddingLeft: 40,
                }}
                placeholder={
                  placeholder || t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_PLEASEENTERVALIDURL)
                }
                value={inputUrl}
                onChange={handleInputChange}
                disabled={isLoading}
              />

              <i
                className="bi bi-link-45deg position-absolute"
                style={{
                  color: "var(--bs-secondary-color)",
                  fontSize: 18,
                  left: 12,
                  top: "50%",
                  transform: "translateY(-50%)",
                }}
              />
            </div>
          </div>

          <div className="text-muted small">
            <i className="bi bi-info-circle me-1"></i>
            {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_UPLOADHELP)}
          </div>

          <div className="text-muted small">
            <i className="bi bi-info-circle me-1"></i>
            {t(TranslationKeys.APPLICATIONSETTINGS_FOOTERBANNERUPLOAD_UPLOADNOTE)}
          </div>
        </>
      )}
    </div>
  );
};

export default FooterBannerUpload;
