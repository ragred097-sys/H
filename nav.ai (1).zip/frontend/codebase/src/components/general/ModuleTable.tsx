import React from "react";

import { Table } from "react-bootstrap";

import { Module } from "../../lib/Model";

export default function ModuleTable({ module }: { module: Module | undefined }) {
  if (module?.id) {
    const paramTable = module?.parameters?.map((param, i) => {
      // Do not show key information
      if (!param.name.toLowerCase().includes("key"))
        return (
          <React.Fragment key={i}>
            <tr>
              <td>{param.name}</td>

              <td>{param.value}</td>
            </tr>
          </React.Fragment>
        );
    });
    const headerCols = Array.from(new Set(module?.parameters.flatMap(Object.keys)));
    return (
      <>
        {module?.name}
        <Table striped bordered hover size="sm" style={{ fontSize: "0.9em" }}>
          <thead>
            <tr>
              {headerCols.map((col) => (
                <td key={col}>{col}</td>
              ))}
            </tr>
          </thead>
          <tbody>{paramTable}</tbody>
        </Table>
      </>
    );
  } else {
    return <p>No Additional Details</p>;
  }
}
