import { v4 as uuidv4 } from "uuid";

import i18n from "../../i18n";
import { DocumentType, Named } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { MAX_FILE_SIZE } from "../../utils/constants";
import { determineDocumentType } from "../../utils/fileUtils";
import { createDeepDataObject, objectRender } from "../../utils/objectUtils";

export class AttachedFile implements Named {
  public readonly id: string;
  public readonly name: string;
  public readonly size: number;
  public readonly file: File;
  public readonly type: DocumentType;
  private _previewUrl: string | null = null;
  private _previewPromise: Promise<string | null>;

  constructor(file: File) {
    if (!file) {
      throw new Error("File is required");
    }

    if (file.size > MAX_FILE_SIZE) {
      throw new Error(`File size exceeds maximum limit of ${MAX_FILE_SIZE / 1024 / 1024}MB`);
    }

    this.id = uuidv4();
    this.name = file.name;
    this.size = file.size;
    this.file = file;
    const determinedType = determineDocumentType(file);
    if (!determinedType) {
      throw new Error(i18n.t(TranslationKeys.ATTACHEDFILE_UNSUPPORTEDFILETYPE) + file.name);
    }
    this.type = determinedType;

    // Create promise for preview URL
    this._previewPromise = this.initializePreview(file);
  }

  private async initializePreview(file: File): Promise<string | null> {
    if (this.type === DocumentType.IMAGE) {
      return URL.createObjectURL(file);
    }

    const deepDataObject = await createDeepDataObject(file);
    const preview = objectRender(deepDataObject);
    this._previewUrl = preview ?? null;
    return this._previewUrl;
  }

  public async getPreviewUrl(): Promise<string | null> {
    return await this._previewPromise;
  }

  public dispose(): void {
    if (this._previewUrl) {
      URL.revokeObjectURL(this._previewUrl);
    }
  }

  public toJSON() {
    return {
      id: this.id,
      name: this.name,
      size: this.size,
      type: this.type,
    };
  }
}
