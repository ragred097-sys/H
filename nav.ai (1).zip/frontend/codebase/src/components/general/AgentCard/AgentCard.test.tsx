import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Mock } from "vitest";

import { MemoryRouter } from "react-router-dom";

import AgentCard from "./AgentCard";
import { Assistant, DataSource, PermissionType, Workspace } from "../../../lib/Model";
import { UserService } from "../../../services/UserService";
import { authStore } from "../../../stores/useStore";

// MOCK

vi.mock("../../../lib/Backend", () => ({
  Backend: {
    getCurrentAuthenticatedUser: vi.fn(),
  },
}));
vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));
const mockOpenNotification = vi.fn();
vi.mock("../../general/NotificationProvider", () => {
  return {
    NotificationProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    useNotification: () => ({
      openNotification: mockOpenNotification,
    }),
  };
});
vi.mock("../../../services/UserService", () => ({
  UserService: {
    createUserFavorite: vi.fn(),
    deleteHiddenEntity: vi.fn(),
    deleteUserFavorite: vi.fn(),
    hideEntity: vi.fn(),
  },
}));
const mockNavigate = vi.fn();
vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual<typeof import("react-router-dom")>("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});
// MOCK DATA
const mockWorkspace: Workspace = {
  __type_name: "Workspace",
  accessPermission: PermissionType.WRITE,
  createdAt: "",
  creator: {
    id: "user1",
    name: "user1",
  },
  description: "",
  favorite: false,
  icon: "icon-url",
  id: "ws1",
  image: "",
  name: "WS",
  sharedBy: "N/A",
  tags: [],
};
vi.mock("../../../stores/useStore", () => ({
  authStore: vi.fn(),
}));

// Set default store response
(authStore as unknown as Mock).mockImplementation((selector: any) =>
  selector({ roles: [{ name: "ADMIN" }], user: { id: "user1" } })
);
describe("AgentCard", async () => {
  const updateTrigger = vi.fn();
  const launchControl = vi.fn();
  beforeEach(() => {
    vi.clearAllMocks();
  });
  it("should navigate to /workspace/id when data.__type_name is Workspace", async () => {
    const data = { __type_name: "Workspace", description: "desc", id: "ws1", name: "WS" };
    render(
      <MemoryRouter>
        <AgentCard
          workspace={mockWorkspace}
          data={data as any}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={false}
        />
      </MemoryRouter>
    );
    const cardBody = screen.getByTestId(`card-body`);
    await userEvent.click(cardBody);
    expect(mockNavigate).toHaveBeenCalledWith("/workspace/ws1");
  });
  it("should call launchControl for Assistant type when clicked", async () => {
    const data = { __type_name: "Assistant", description: "desc", id: "a1", name: "Assistant1" };
    render(
      <MemoryRouter>
        <AgentCard
          workspace={mockWorkspace}
          data={data as Assistant}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={false}
        />
      </MemoryRouter>
    );
    await userEvent.click(screen.getByText(/Assistant1/));
    expect(launchControl).toHaveBeenCalledWith(data);
  });
  it("should toggle bookmark: call createUserFavorite when not favorite", async () => {
    (UserService.createUserFavorite as Mock).mockResolvedValueOnce(undefined);
    const data = { __type_name: "DataSource", description: "", favorite: false, id: "d1", name: "Data1" };
    render(
      <MemoryRouter>
        <AgentCard
          workspace={undefined}
          data={data as any}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={false}
        />
      </MemoryRouter>
    );
    const bookmarkButton = screen.getByTestId("bookmark-button");
    await userEvent.click(bookmarkButton);
    expect(UserService.createUserFavorite).toHaveBeenCalledWith({
      __type_name: "DataSource",
      favorite: true,
      id: "d1",
      name: "Data1",
    });
    await waitFor(() => {
      expect(updateTrigger).toHaveBeenCalled();
      expect((data as DataSource).favorite);
    });
  });
  it("should hide entity when showHideButton and hidden = false", async () => {
    (UserService.hideEntity as Mock).mockResolvedValueOnce(undefined);

    const data = {
      __type_name: "Assistant",
      creator: {
        id: "user1",
        name: "user1",
      },
      description: "",
      favorite: false,
      hidden: false,
      id: "a1",
      name: "Assistant1",
    };
    render(
      <MemoryRouter>
        <AgentCard
          workspace={mockWorkspace}
          data={data as Assistant}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={true}
        />
      </MemoryRouter>
    );
    const hideBtn = screen.getByTestId("hide-button");
    await userEvent.click(hideBtn);
    expect(UserService.hideEntity).toHaveBeenCalledWith("user1", {
      subjectId: "a1",
      subjectType: "Assistant",
    });
    await waitFor(() => expect(updateTrigger).toHaveBeenCalled());
  });
  it("should unhide entity when hidden = true", async () => {
    (UserService.deleteHiddenEntity as Mock).mockResolvedValueOnce(undefined);
    const data: Assistant = {
      __type_name: "Assistant",
      accessPermission: PermissionType.READ,
      attachmentStorages: [],
      createdAt: "",
      creator: { id: "user1", name: "user1" },
      customSystemInstruction: "",
      dataSourceIds: [],
      description: "",
      favorite: false,
      hidden: true,
      icon: "",
      id: "a2",
      image: "",
      llmIds: [],
      name: "Assistant2",
      sampleQuestions: [],
      systemInstructionIds: null,
      tags: [],
    };
    render(
      <MemoryRouter>
        <AgentCard
          workspace={mockWorkspace}
          data={data as Assistant}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={true}
        />
      </MemoryRouter>
    );
    const hideBtn = screen.getByTestId("hide-button");
    await userEvent.click(hideBtn);
    expect(UserService.deleteHiddenEntity).toHaveBeenCalledWith("user1", {
      subjectId: data.id,
      subjectType: data?.__type_name,
    });
    await waitFor(() => expect(updateTrigger).toHaveBeenCalled());
  });
  it("does not render bookmark when data.__type_name is Module", () => {
    const moduleData = {
      __type_name: "Module",
      description: "",
      favorite: false,
      id: "m1",
      name: "Module1",
    };

    <MemoryRouter>
      <AgentCard
        workspace={mockWorkspace}
        data={moduleData as any}
        iconName="agent"
        updateTrigger={updateTrigger}
        launchControl={launchControl}
      />
    </MemoryRouter>;

    expect(screen.queryByTestId("bookmark-button")).toBeNull();
  });
  it("does not render bookmark when data.__type_name is Agent", () => {
    const agentData = {
      __type_name: "Agent",
      description: "",
      favorite: false,
      id: "a1",
      name: "Agent1",
    };

    render(
      <MemoryRouter>
        <AgentCard
          workspace={mockWorkspace}
          data={agentData as any}
          iconName="agent"
          updateTrigger={updateTrigger}
          launchControl={launchControl}
          showHideButton={false}
        />
      </MemoryRouter>
    );
    const bookmark = screen.queryByTestId("bookmark-button");
    expect(bookmark).toBeNull();
  });
});
