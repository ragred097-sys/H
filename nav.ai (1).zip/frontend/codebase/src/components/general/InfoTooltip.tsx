import React, { useEffect, useRef, useState } from "react";

import { v4 as uuidv4 } from "uuid";

import { Button, OverlayTrigger, Tooltip, TooltipProps } from "react-bootstrap";

const generateUniqueId = (): string => `tooltip-${uuidv4()}`;

interface InfoTooltipProps {
  message: string;
  tooltipProps?: TooltipProps;
}

const InfoTooltip: React.FC<InfoTooltipProps> = ({ message, tooltipProps }) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const tooltipId = generateUniqueId();

  const renderTooltip = (props: any) => (
    <Tooltip id={tooltipId} {...props} {...tooltipProps} className="custom-tooltip">
      {message}
    </Tooltip>
  );

  const handleClick = () => {
    setShowTooltip(!showTooltip);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (buttonRef.current && !buttonRef.current.contains(event.target as Node)) {
      setShowTooltip(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  return (
    <OverlayTrigger trigger="click" show={showTooltip} onToggle={handleClick} placement="right" overlay={renderTooltip}>
      <Button className="d-inline m-0 p-0" ref={buttonRef} variant="plain" onClick={handleClick}>
        <i className="bi bi-info-circle-fill" style={{ fontSize: "0.8rem" }}></i>
      </Button>
    </OverlayTrigger>
  );
};

export default InfoTooltip;
