import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";

import { ChatDragOverlay } from "./ChatDragOverlay";

describe("ChatDragOverlay", () => {
  it('renders "Release to attach" text', () => {
    render(<ChatDragOverlay hasDocuments={true} />);
    expect(screen.getByText("Release to attach")).toBeInTheDocument();
  });

  it("applies correct styles when hasDocuments is false", () => {
    render(<ChatDragOverlay hasDocuments={false} />);
    const overlay = screen.getByText("Release to attach").parentElement;
    expect(overlay).toHaveStyle({ top: "35%" });
    expect(overlay).toHaveStyle({ borderRadius: "25px" });
    expect(overlay).toHaveStyle({ zIndex: "10" });
    expect(overlay).toHaveStyle({ height: "180px" });
  });

  it("applies correct styles when hasDocuments is true", () => {
    render(<ChatDragOverlay hasDocuments={true} />);
    const overlay = screen.getByText("Release to attach").parentElement;
    expect(overlay).toHaveStyle({ top: "0" });
  });

  it("renders the paperclip icon", () => {
    render(<ChatDragOverlay hasDocuments={false} />);
    const icon = document.querySelector(".bi-paperclip");
    expect(icon).toBeTruthy();
  });
});
