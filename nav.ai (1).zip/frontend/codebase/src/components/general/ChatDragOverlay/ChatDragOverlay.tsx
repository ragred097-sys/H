// Constants
const DRAG_OVERLAY_STYLES = {
  animation: "fadeIn 0.2s ease-in",
  borderRadius: "25px",
  height: "180px",
  zIndex: 10,
} as const;

export const ChatDragOverlay: React.FC<{ hasDocuments: boolean }> = ({ hasDocuments }) => (
  <div
    className="position-absolute w-100 d-flex flex-column justify-content-center align-items-center"
    style={{
      ...DRAG_OVERLAY_STYLES,
      top: hasDocuments ? "0" : "35%",
      transform: "translateY(-50%)",
    }}
  >
    <i className="bi bi-paperclip text-light" style={{ fontSize: "2rem" }}></i>
    <span className="text-light">Release to attach</span>
  </div>
);
