export function GradientCircleButton({ dim = "44px", fontSize = "28px" }) {
  return (
    <div
      className="btn rounded-circle"
      style={{
        alignItems: "center",
        background: "linear-gradient(135deg, var(--secondary-color), var(--primary-color))",
        border: "none",
        display: "flex",
        fontSize: fontSize,
        height: dim,
        justifyContent: "center",
        width: dim,
      }}
    >
      <i className="bi bi-plus d-flex flex-row align-items-center"></i>
    </div>
  );
}
