import { ReactNode } from "react";

import { Form, FormLabelProps } from "react-bootstrap";

const RequiredLabel = ({ label, labelProps }: { label: string | ReactNode; labelProps?: FormLabelProps }) => (
  <Form.Label {...labelProps}>
    {label} <span className="text-danger">*</span>
  </Form.Label>
);

export { RequiredLabel };
