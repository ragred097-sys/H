import { DocumentPreview } from "./DocumentPreview";
import { DocumentPreviewListProps } from "../../lib/Model";
import { rightPaneChatIconState } from "../../stores/useStore";

export const DocumentPreviewList: React.FC<DocumentPreviewListProps> = ({ documents, onRemove }) => {
  const { isAttachmentOpen } = rightPaneChatIconState();

  return (
    <div
      className="d-flex flex-wrap gap-2 p-2"
      style={{
        borderBottom: "1px solid rgba(255,255,255,0.1)",
        margin: "0 1.5rem",
        maxHeight: "70px",
        overflowY: "auto",
        transition: "width 0.3s ease-in-out, margin-left 0.3s ease-in-out",
        width: isAttachmentOpen ? "60%" : "100%",
      }}
    >
      {documents.map((doc, index: number) => (
        <DocumentPreview key={index} document={doc} onRemove={() => onRemove(index)} />
      ))}
    </div>
  );
};
