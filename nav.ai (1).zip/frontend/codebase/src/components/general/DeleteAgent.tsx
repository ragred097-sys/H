import { useState } from "react";

import { Button } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Agent } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { ApplicationService } from "./../../services/ApplicationService";
import ConfirmationDialog from "./ConfirmationDialog";
import LoadingButton from "./LoadingButton/LoadingButton";
import { useNotification } from "./NotificationProvider";
import TableComponent from "./Table";

interface DeleteAgentProps {
  agent: Agent | null;
  systemPrompts?: string[];
  handleClose?: () => void;
  onDelete?: (id: string) => void;
  updateTrigger?: () => void;
  handleAgentClose?: () => void;
}
function DeleteAgent({ agent, handleAgentClose, handleClose, systemPrompts, updateTrigger }: DeleteAgentProps) {
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();

  async function handleDelete() {
    if (agent?.systemInstructionIds && agent.systemInstructionIds.length > 0) {
      setShowConfirmation(true);
    } else {
      deleteAgent();
    }
  }
  const deleteAgent = async () => {
    if (agent?.id) {
      setDeleteLoading(true);
      ApplicationService.recursiveDelete(agent?.__type_name, agent?.id)
        .then(() => {
          openNotification(t(TranslationKeys.MESSAGES_DELETEUTILITYAGENTSUCCESS), "primary");
          setDeleteLoading(false);
        })
        .catch((err) => {
          setDeleteLoading(false);
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_DELETEUTILITYAGENT), err as Error);
        })
        .finally(() => {
          setDeleteLoading(false);
          if (handleClose) handleClose();
          if (updateTrigger) updateTrigger();
        });
    }
  };
  //soft delete system-prompt and dataset
  async function softDelete() {
    if (!agent?.id) {
      console.error("agent ID is missing.");
      return;
    } else {
      deleteAgent();
    }
  }
  //get the maximum number to set the row for all columns
  const maxRow = Math.max(agent?.systemInstructionIds?.length || 0);
  //show modified entities in heading
  const tableHeadingEntities = {
    "system prompt": Array.isArray(agent?.systemInstructionIds) && agent?.systemInstructionIds.length > 0,
  };
  const tableData = () => {
    const associatedDataTitles = columnsHeading();
    const data: { [key: string]: string[] }[] = [];
    associatedDataTitles.forEach((title) => {
      switch (title) {
        case t(TranslationKeys.MESSAGES_SYSTEMPROMPTS):
          data.push({ [title]: systemPrompts || [] });
          break;
        default:
          break;
      }
    });
    return data;
  };
  const columnsHeading = () => {
    const tableHead = [agent?.systemInstructionIds?.length && t(TranslationKeys.MESSAGES_SYSTEMPROMPTS)];
    return tableHead.filter(Boolean) as string[];
  };

  return (
    <div>
      <div className="d-flex flex-row">
        <p>{t(TranslationKeys.MESSAGES_DELETEUTILITYAGENTCONFIRM, { agentName: agent?.name })}</p>
      </div>
      {Object.values(tableHeadingEntities)?.some((value) => value === true) && (
        <>
          <p>
            {t(TranslationKeys.MESSAGES_DELETEUTILITYAGENTASSOCIATED, {
              entityItems: Object.entries(tableHeadingEntities)
                .filter(([, value]) => value)
                .map(([key]) => key)
                .reduce((acc, curr, index, arr) => {
                  if (arr.length === 1) return curr;
                  if (index === arr.length - 1) return `${acc} and ${curr}`;
                  return `${acc}, ${curr}`;
                }),
            })}
          </p>

          <TableComponent
            loading={false}
            maxRow={maxRow}
            tableColumnHeadings={columnsHeading()}
            tableData={tableData()}
          />
        </>
      )}
      <div className="d-flex flex-row justify-content-end mt-3">
        {deleteLoading && showConfirmation == false ? (
          <LoadingButton className={"btn btn-danger me-4"} />
        ) : (
          <Button className="me-4" variant="danger" type="button" onClick={() => handleDelete()}>
            {t(TranslationKeys.MESSAGES_DELETE)}
          </Button>
        )}
        <Button className="me-4" variant="secondary" type="button" onClick={handleAgentClose}>
          {t(TranslationKeys.MESSAGES_CANCEL)}
        </Button>
      </div>
      {showConfirmation && (
        <ConfirmationDialog
          show={showConfirmation}
          confirmationQuestion={t(TranslationKeys.MESSAGES_CONFIRMDELETECHAT)}
          confirmationButtonLabel={t(TranslationKeys.MESSAGES_CONFIRMDELETEYES)}
          onConfirm={softDelete}
          onClose={() => {
            setShowConfirmation(false);
          }}
          variant="danger"
          isConfirmationLoading={deleteLoading}
          isWorkspaceDelete={true}
        />
      )}
    </div>
  );
}

export default DeleteAgent;
