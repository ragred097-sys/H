import { Modal } from "react-bootstrap";

import { Assistant, Workspace } from "../../lib/Model";
import { AgentDirtyFields } from "../../utils/agentFormFields";
import NewAssetForm from "../forms/AssetForm";
import NewAgentForm from "../forms/NewAgentForm/NewAgentForm";

interface editCreateAgentModalProps {
  header: string;
  initialData?: Assistant;
  updateTrigger?: () => void;
  showEdit: boolean;
  isFormDirty: boolean;
  isNewAssetForm: boolean;
  workspace?: Workspace;
  triggerUpdate?: () => void;
  isUtilityAgent?: boolean;
  setShowEdit: React.Dispatch<React.SetStateAction<boolean>>;
  setIsFormDirty: React.Dispatch<React.SetStateAction<boolean>>;
  setIsConfirmClose: React.Dispatch<React.SetStateAction<boolean>>;
  setDirtyFields: React.Dispatch<React.SetStateAction<AgentDirtyFields>>;
}
export default function EditCreateAgentModal({
  header,
  initialData,
  isFormDirty,
  isNewAssetForm,
  isUtilityAgent,
  setDirtyFields,
  setIsConfirmClose,
  setIsFormDirty,
  setShowEdit,
  showEdit,
  triggerUpdate,
  updateTrigger,
  workspace,
}: editCreateAgentModalProps) {
  const handleFormDirtyState = (dirtyState: boolean) => {
    setIsFormDirty((prev) => {
      if (prev === dirtyState) return prev; // Don't update if unchanged
      return dirtyState;
    });
  };
  //dirty new agent modified data
  const handleUpdateAgentDirtyDataTitles = (data: AgentDirtyFields) => {
    setDirtyFields((prevState) => {
      const newDirtyFields: AgentDirtyFields = data;
      // Only update state if the new state differs from the previous state
      if (JSON.stringify(prevState) === JSON.stringify(newDirtyFields)) {
        return prevState; // No change, so return the current state
      }
      return newDirtyFields; // If there's a change, update the state
    });
  };
  return (
    <>
      <Modal
        show={showEdit}
        onHide={() => {
          if (isFormDirty) {
            // Show alert if form is dirty
            setIsConfirmClose(true);
          } else {
            setShowEdit(false);
          }
        }}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop"
      >
        <Modal.Header closeButton>{header}</Modal.Header>
        <Modal.Body>
          {isNewAssetForm ? (
            <NewAssetForm
              handleClose={() => setShowEdit(false)}
              workspace={workspace}
              triggerUpdate={triggerUpdate}
              onCreateAgentFormDirty={handleFormDirtyState}
              onCreateAgentDirtyData={handleUpdateAgentDirtyDataTitles}
              isUtilityAgent={isUtilityAgent}
            />
          ) : (
            <NewAgentForm
              initialData={initialData}
              handleClose={() => setShowEdit(false)}
              showDelete={false}
              updateTrigger={updateTrigger}
              onUpdateAgentFormDirty={handleFormDirtyState}
              onUpdateAgentDirtyData={handleUpdateAgentDirtyDataTitles}
              isUtilityAgent={isUtilityAgent}
            />
          )}
        </Modal.Body>
      </Modal>
    </>
  );
}
