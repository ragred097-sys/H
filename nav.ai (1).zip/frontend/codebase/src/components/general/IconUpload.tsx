// IconUpload.tsx
import React, { useState } from "react";

import ReactDOMServer from "react-dom/server";

import { Form } from "react-bootstrap";
import {
  ArrowRight,
  Bell,
  Bookmark,
  Camera,
  Cloud,
  FileText,
  Flag,
  Gear,
  Heart,
  HeartFill,
  House,
  MusicNote,
  Person,
  Search,
  Star,
} from "react-bootstrap-icons";

// Icons Mapping
const Icons = {
  ArrowRight,
  Bell,
  Bookmark,
  Camera,
  Cloud,
  FileText,
  Flag,
  Gear,
  Heart,
  HeartFill,
  House,
  MusicNote,
  Person,
  Search,
  Star,
};

// List of predefined icon names
const predefinedIcons: (keyof typeof Icons)[] = [
  "House",
  "Camera",
  "Cloud",
  "Heart",
  "Star",
  "Bell",
  "Bookmark",
  "ArrowRight",
  "Search",
  "Flag",
  "Gear",
  "MusicNote",
  "FileText",
  "HeartFill",
  "Person",
];

// Reusable component for uploading and selecting icons
interface IconUploadProps {
  onIconChange: (icon: string | null) => void; // Callback to notify parent component about the selected icon
  showSavedIcon?: boolean; // Flag to conditionally render the "Saved Icon" section
  savedIcon?: string | null; // Saved icon for rendering when the flag is true
}

const IconUpload: React.FC<IconUploadProps> = ({ onIconChange, savedIcon, showSavedIcon = false }) => {
  const [icon, setIcon] = useState<string | null>(null); // Store uploaded icon or serialized icon as string
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [, setUploadedIcon] = useState<string | null>(null); // Store base64 icon
  const [, setPredefinedIcon] = useState<keyof typeof Icons | null>(null); // Store selected predefined icon

  // Helper function to serialize predefined icons to Base64
  const serializeIconToBase64 = (IconComponent: React.ElementType): string => {
    const svgString = ReactDOMServer.renderToString(
      <IconComponent size={40} fill="currentColor" style={{ fill: "white" }} />
    );
    return `data:image/svg+xml;base64,${btoa(svgString)}`;
  };

  const handleIconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setUploadedIcon(reader.result as string); // Store base64 string
        setIcon(reader.result as string); // Set icon preview
        onIconChange(reader.result as string); // Notify parent component
      };
      reader.readAsDataURL(file);
    }
  };

  const handleIconSelect = (iconName: keyof typeof Icons) => {
    setPredefinedIcon(iconName);
    const base64Icon = serializeIconToBase64(Icons[iconName]); // Serialize to base64
    setIcon(base64Icon); // Set icon preview
    onIconChange(base64Icon); // Notify parent component
  };

  return (
    <div>
      {/* File Upload */}
      <Form.Group controlId="icon" className="pe-2">
        <Form.Label>Upload Custom Icon</Form.Label>
        <Form.Control type="file" size="sm" onChange={handleIconChange} />
      </Form.Group>

      {/* Pre-defined Icons */}
      <div className="mt-3">
        <Form.Group controlId="predefinedIconSelect">
          <Form.Label>Or Select a Pre-defined Icon</Form.Label>
          <Form.Select size="sm" onChange={(e) => handleIconSelect(e.target.value as keyof typeof Icons)}>
            <option value="">Select an Icon</option>
            {predefinedIcons.map((iconName) => (
              <option key={iconName} value={iconName}>
                {iconName}
              </option>
            ))}
          </Form.Select>
        </Form.Group>
      </div>

      <div className="d-flex align-items-start gap-3 mt-3">
        {/* Icon Preview */}
        {icon && (
          <div>
            <h6>Icon:</h6>
            <img
              src={icon}
              style={{ height: "150px", padding: "5px", width: "150px" }}
              alt="Uploaded or Predefined Icon Preview"
            />
          </div>
        )}

        {/* Saved Icon */}
        {showSavedIcon && savedIcon && (
          <div>
            <h6>Old Icon:</h6>
            <img src={savedIcon} style={{ height: "150px", padding: "5px", width: "150px" }} alt="Saved Icon" />
          </div>
        )}
      </div>
    </div>
  );
};

export default IconUpload;
