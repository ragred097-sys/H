import "@testing-library/jest-dom";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

import ModuleDropdown from "./ModuleDropdown";
import { Module } from "../../../lib/Model";

const modules: Module[] = [
  {
    __type_name: "Module",
    createdAt: "",
    creator: {
      id: "uid1",
      name: "sampleUser1",
    },
    default: false,
    description: "",
    favorite: false,
    id: "1",
    name: "Module A",
    parameters: [],
    specId: "spec1",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "",
    creator: {
      id: "uid2",
      name: "sampleUser2",
    },
    default: true,
    description: "",
    favorite: false,
    id: "2",
    name: "Module B",
    parameters: [],
    specId: "spec2",
    supportedInputs: [],
    tags: [],
  },
  {
    __type_name: "Module",
    createdAt: "",
    creator: {
      id: "uid3",
      name: "sampleUser3",
    },
    default: false,
    description: "",
    favorite: false,
    id: "3",
    name: "Module C",
    parameters: [],
    specId: "spec3",
    supportedInputs: [],
    tags: [],
  },
];

describe("ModuleDropdown", () => {
  it("renders with placeholder when no value is selected", () => {
    const modulesModified: Module[] = [
      {
        __type_name: "Module",
        createdAt: "",
        creator: {
          id: "uid1",
          name: "sampleUser1",
        },
        default: false,
        description: "",
        favorite: false,
        id: "1",
        name: "Module A",
        parameters: [],
        specId: "spec1",
        supportedInputs: [],
        tags: [],
      },
      {
        __type_name: "Module",
        createdAt: "",
        creator: {
          id: "uid2",
          name: "sampleUser2",
        },
        default: false,
        description: "",
        favorite: false,
        id: "2",
        name: "Module B",
        parameters: [],
        specId: "spec2",
        supportedInputs: [],
        tags: [],
      },
      {
        __type_name: "Module",
        createdAt: "",
        creator: {
          id: "uid3",
          name: "sampleUser3",
        },
        default: false,
        description: "",
        favorite: false,
        id: "3",
        name: "Module C",
        parameters: [],
        specId: "spec3",
        supportedInputs: [],
        tags: [],
      },
    ];
    render(<ModuleDropdown name="module" options={modulesModified} />);
    expect(screen.getByText("Select...")).toBeInTheDocument();
  });

  it("renders with controlled value if provided", () => {
    render(<ModuleDropdown name="module" options={modules} value={"3"} />);
    expect(screen.getByText("Module C")).toBeInTheDocument();
  });

  it("calls onChange and setValue when default is selected on mount", () => {
    const onChange = vi.fn();
    const setValue = vi.fn();

    render(<ModuleDropdown name="module" options={modules} onChange={onChange} setValue={setValue} />);

    expect(onChange).toHaveBeenCalledWith("2");
    expect(setValue).toHaveBeenCalledWith("module", "2", { shouldDirty: false });
  });

  it("handles user selection", async () => {
    const onChange = vi.fn();
    const setValue = vi.fn();

    render(<ModuleDropdown name="module" options={modules} onChange={onChange} setValue={setValue} />);

    fireEvent.click(screen.getByRole("button"));
    fireEvent.click(screen.getByText("Module C"));

    await waitFor(() => {
      expect(onChange).toHaveBeenCalledWith("3");
      expect(setValue).toHaveBeenCalledWith("module", "3", { shouldDirty: true });
    });
  });

  it("calls registerProps.onChange if provided", () => {
    const registerOnChange = vi.fn();

    render(<ModuleDropdown name="module" options={modules} registerProps={{ onChange: registerOnChange }} />);

    fireEvent.click(screen.getByRole("button"));
    fireEvent.click(screen.getByText("Module A"));

    expect(registerOnChange).toHaveBeenCalledWith(
      expect.objectContaining({
        target: expect.objectContaining({
          name: "module",
          value: "1",
        }),
      })
    );
  });
});
