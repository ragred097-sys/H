import React, { useEffect, useState } from "react";

import { Dropdown } from "react-bootstrap";
import { FieldValues, Path, PathValue, UseFormSetValue } from "react-hook-form";

import { Module } from "../../../lib/Model";
import { DEFAULT } from "../../../utils/constants";

import "./ModuleDropdown.scss";

interface ModuleDropdownProps<TFieldValues extends FieldValues> {
  name: Path<TFieldValues>;
  options: Module[];
  value?: string | number;
  onChange?: (value: string | number) => void;
  setValue?: UseFormSetValue<TFieldValues>;
  placeholder?: string;
  className?: string;
  registerProps?: React.InputHTMLAttributes<HTMLInputElement>;
}

function ModuleDropdown<TFieldValues extends FieldValues>({
  className = "",
  name,
  onChange,
  options,
  placeholder = "Select...",
  registerProps = {},
  setValue,
  value: controlledValue,
}: ModuleDropdownProps<TFieldValues>) {
  const currentTheme = document.documentElement.getAttribute("data-bs-theme");

  const getInitialOption = () =>
    options?.find((opt) => opt.id === controlledValue) || options?.find((opt) => opt.default) || null;

  const [selected, setSelected] = useState<Module | null>(null);

  useEffect(() => {
    const defaultOption = getInitialOption();
    if (defaultOption) {
      setSelected(defaultOption);
      setValue?.(name, defaultOption.id as PathValue<TFieldValues, Path<TFieldValues>>, { shouldDirty: false });
      onChange?.(defaultOption.id);
    }
  }, [options]);

  const handleSelect = (val: string | null) => {
    const found = options.find((o) => o.id.toString() === val);
    if (found) {
      setSelected(found);
      onChange?.(found.id);

      if (registerProps?.onChange) {
        registerProps.onChange({
          target: {
            name: name as string,
            value: found.id,
          },
        } as React.ChangeEvent<HTMLInputElement>);
      }

      setValue?.(name, found.id as PathValue<TFieldValues, Path<TFieldValues>>, { shouldDirty: true });
    }
  };

  return (
    <div className={`module-dropdown-wrapper ${currentTheme} ${className}`}>
      <input type="hidden" name={name as string} value={selected?.id ?? ""} {...registerProps} />
      <Dropdown onSelect={handleSelect}>
        <Dropdown.Toggle
          variant={currentTheme === "dark" ? "dark" : "light"}
          className={`text-start module-dropdown-toggle`}
        >
          <span className="select-placeholder-text">
            {selected?.name || placeholder} {selected?.default ? DEFAULT : ""}
          </span>
        </Dropdown.Toggle>

        <Dropdown.Menu>
          {options?.map((option, idx) => (
            <Dropdown.Item
              key={idx}
              eventKey={option.id.toString()}
              className={
                option.id === selected?.id && option.default
                  ? "module-default-option selected"
                  : option.default
                    ? "module-default-option"
                    : ""
              }
              active={option.id === selected?.id}
            >
              {option.name} {option.default ? DEFAULT : ""}
            </Dropdown.Item>
          ))}
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default ModuleDropdown;
