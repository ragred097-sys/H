import React from "react";

import { AgentWorkflow, Assistant } from "../../lib/Model";

interface FileUploadButtonProps {
  onFileSelect: (files: File[]) => void;
  agentData: Assistant | AgentWorkflow;
}

const FileUploadButton: React.FC<FileUploadButtonProps> = ({ agentData, onFileSelect }) => {
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onFileSelect(Array.from(files)); // Convert FileList to File[]
      event.target.value = "";
    }
  };

  return (
    <label>
      <i
        className="bi bi-cloud-upload"
        style={{
          cursor: "pointer",
          marginRight: "1em",
        }}
      ></i>
      <input
        type="file"
        onChange={handleFileChange}
        style={{ display: "none" }}
        disabled={agentData?.attachmentStorages?.length == 0}
      ></input>
    </label>
  );
};

export default FileUploadButton;
