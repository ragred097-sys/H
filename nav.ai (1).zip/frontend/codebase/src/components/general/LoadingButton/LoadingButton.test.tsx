import { render, screen } from "@testing-library/react";

import LoadingButton from "./LoadingButton";

describe("LoadingButton", () => {
  // Test case 1: Ensures the button renders and is disabled
  test("renders a disabled button", () => {
    render(<LoadingButton className="test-class" />);
    const buttonElement = screen.getByRole("button");
    expect(buttonElement).toBeInTheDocument(); // button is present
    expect(buttonElement).toBeDisabled();
  });

  // Test case 2: Checks Loading...
  test('displays "Loading..." text', () => {
    render(<LoadingButton className="test-class" />);
    const loadingText = screen.getByText("Loading...");
    expect(loadingText).toBeInTheDocument(); // Loading... should be visible
  });

  // Test case 3: check for the class prop
  test("applies the provided className", () => {
    const customClassName = "btn btn-primary my-custom-loading-btn";
    render(<LoadingButton className={customClassName} />);
    const buttonElement = screen.getByRole("button");
    expect(buttonElement).toHaveClass("btn");
    expect(buttonElement).toHaveClass("btn-primary");
    expect(buttonElement).toHaveClass("my-custom-loading-btn");
  });

  // Test case 4: check is spinner present
  test("renders a spinner", () => {
    render(<LoadingButton className="test-class" />);
    // The spinner has role="status" and is visually hidden for accessibility
    const spinnerElement = screen.getByRole("status", { hidden: true });
    expect(spinnerElement).toBeInTheDocument();
    expect(spinnerElement).toHaveClass("spinner-border");
    expect(spinnerElement).toHaveClass("spinner-border-sm");
  });

  // Test case 5: check for undefined classname
  test("handles an empty className gracefully", () => {
    render(<LoadingButton className="" />);
    const buttonElement = screen.getByRole("button");
    expect(buttonElement).not.toHaveClass("undefined");
    expect(buttonElement).toHaveAttribute("class", ""); //check for empty classname
  });

  // Test case 6: check for the button type
  test('sets the type attribute to "button"', () => {
    render(<LoadingButton className="test-class" />);
    const buttonElement = screen.getByRole("button");
    expect(buttonElement).toHaveAttribute("type", "button");
  });
});
