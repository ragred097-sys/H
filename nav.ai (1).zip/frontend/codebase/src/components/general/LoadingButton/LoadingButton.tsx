interface loadingButtonprops {
  className: string;
}
const LoadingButton = ({ className }: loadingButtonprops) => {
  return (
    <button className={className ? className : ""} type="button" disabled>
      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
      &nbsp;Loading...
    </button>
  );
};
export default LoadingButton;
