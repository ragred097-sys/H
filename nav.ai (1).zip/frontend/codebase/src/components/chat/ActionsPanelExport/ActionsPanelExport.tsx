import { useCallback, useState } from "react";

import {
  AlignmentType,
  Document,
  ExternalHyperlink,
  ImageRun,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  TextRun,
} from "docx";
import { Workbook } from "exceljs";
import { toPng } from "html-to-image";
import pptxgen from "pptxgenjs";

import { Button, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { ActionsPanelExportProps, IStyles } from "./ActionsPanelExport.models";
import pptxIcon from "../../../assets/images/pptxIcon.png";
import docxIcon from "../../../assets/images/wordIcon.png";
import xslxIcon from "../../../assets/images/xslxIcon.png";
import { TranslationKeys } from "../../../types/translation-keys";

// Styles
const actionButtonStyle = { borderRadius: "var(--bs-border-radius)", width: "18em" };
const iconStyle = { height: "25px", width: "25px" };
const blueDotStyle = { height: "6px", marginBottom: "-0.1em", width: "6px", zIndex: "400" };
const actionContainerStyle = {
  backgroundColor: "transparent",
  border: "0.125rem solid var(--border-color)",
  borderBottomLeftRadius: "35%",
  borderRight: "none",
  borderTop: "none",
  height: "6em",
  marginBottom: "0.625rem",
  marginLeft: "1.5rem",
  marginTop: "-5.1em",
  width: "3.75rem",
};

// Utilities
export const generateFilename = (agentName: string, chatName: string, ext: string): string => {
  const timestamp = new Date().toISOString().slice(0, -5).replace(/[T:]/g, "-");
  const clean = (str: string) => str.replace(/[^a-z0-9]/gi, "_").toLowerCase();
  return `${clean(agentName)}-${clean(chatName)}-${timestamp}.${ext}`;
};

const downloadFile = (blob: Blob, filename: string): void => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};

// Helper function to convert HTML to plain text
export const htmlToText = (html: string): string => {
  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = html;
  return tempDiv.textContent || tempDiv.innerText || "";
};

// Simple content extraction
async function extractChatContent() {
  const chatContainer = document.getElementById("chat-container");
  if (!chatContainer) return [];

  const messages = Array.from(chatContainer.querySelectorAll("#messagePart")) as HTMLElement[];

  const conversations = [];
  let currentUser = null;
  const allUserMessages = Array.from(document.querySelectorAll(".chat-bubble")).map((el) => el.textContent?.trim());

  for (let i = 0; i < messages.length; i++) {
    const message = messages[i];
    const chatBubble = message.querySelector(".chat-bubble")?.textContent?.trim();
    const { images, text } = await processMessagePart(message);
    const isUser = allUserMessages?.includes(chatBubble);

    if (isUser) {
      // If there is an earlier user message not yet paired with a bot response, add it with empty bot reply
      if (currentUser) {
        conversations.push({
          bot: { images: [], text: "" },
          user: currentUser,
        });
      }
      // Save this user message to pair with a future bot reply
      currentUser = { images, text };
    } else {
      // This is a bot message
      if (currentUser) {
        // If there's a saved user message, pair it with this bot message
        conversations.push({
          bot: { images, text },
          user: currentUser,
        });
        currentUser = null;
      } else {
        // If no user message before this, pair with an empty user message
        conversations.push({
          bot: { images, text },
          user: { images: [], text: "" },
        });
      }
    }
  }
  // If there’s an unpaired user message after the loop ends, add it with empty bot reply
  if (currentUser) {
    conversations.push({
      bot: { images: [], text: "" },
      user: currentUser,
    });
  }
  return conversations;
}
function inlineSVGStyles(svg: SVGElement) {
  const allElements = svg.querySelectorAll("*");
  const computedStyle = window.getComputedStyle(svg);
  for (const attr of computedStyle) {
    svg.style.setProperty(attr, computedStyle.getPropertyValue(attr));
  }

  allElements.forEach((el) => {
    const computed = getComputedStyle(el);
    for (const key of computed) {
      (el as SVGAElement).style.setProperty(key, computed.getPropertyValue(key));
    }
  });
}

// Process individual message parts
async function processMessagePart(messageElement: HTMLElement) {
  const images: string[] = [];
  const visualSelectors =
    'img, .leaflet-container, [id*="map"], .chart-container,.gantt-container, canvas, svg, [class*="chart"], [class*="graph"], [class*="plot"], [class*="visualization"]';

  // --- 1. Get Images from the Original Element ---
  // Find all visual elements in the original, interactive DOM
  const allVisuals = Array.from(messageElement.querySelectorAll(visualSelectors));

  // Filter this list to get only the top-level parent elements.
  // This ensures we capture '.leaflet-container' and not the 'img' tiles inside it.
  const topLevelVisuals = allVisuals.filter((el) => {
    return !allVisuals.some((parent) => parent !== el && parent.contains(el));
  });

  // Iterate and capture these top-level elements as images
  for (const visualEl of topLevelVisuals) {
    // Skip tables - they should be processed as text content, not images
    if (visualEl.tagName.toUpperCase() === "TABLE" || visualEl.closest("table")) {
      continue;
    }

    try {
      if (visualEl.classList.contains("gantt-container")) {
        const clonedEl = visualEl.cloneNode(true) as HTMLElement;
        try {
          document.head.querySelectorAll("style, link[rel='stylesheet']").forEach((style) => {
            clonedEl.appendChild(style.cloneNode(true));
          });
          const svgs = clonedEl.querySelectorAll("svg");
          svgs.forEach(inlineSVGStyles);
          // Style it to make it visible off-screen
          clonedEl.style.left = "-9999px";
          clonedEl.style.top = "0";
          clonedEl.style.display = "block";
          clonedEl.style.visibility = "visible";
          clonedEl.style.maxHeight = "none";
          clonedEl.style.overflow = "visible";
          clonedEl.style.fill = "white";
          // Append it to the body temporarily
          document.body.appendChild(clonedEl);
          // Wait a tick to ensure it's rendered (especially if it has dynamic content)
          await new Promise((resolve) => setTimeout(resolve, 500));
          const canvas = await toPng(clonedEl as HTMLElement, {
            backgroundColor: "#FFFFFF",
            cacheBust: true,
          });
          images.push(canvas);
        } catch (error) {
          // Silently fail if an element can't be converted to an image.
        } finally {
          // Clean up cloned element
          document.body.removeChild(clonedEl);
        }
      } else {
        const imageData = await toPng(visualEl as HTMLElement, {
          backgroundColor: "white",
          pixelRatio: 2,
          quality: 1.0,
          skipFonts: true,
        });
        images.push(imageData);
      }
    } catch {
      // Silently fail if an element can't be converted to an image.
    }
  }

  // --- 2. Get HTML Content by Cleaning a Cloned Element ---
  const clonedElement = messageElement.cloneNode(true) as HTMLElement;
  // From the clone, remove all visual elements entirely so they don't become text.
  clonedElement.querySelectorAll(visualSelectors).forEach((el) => el.remove());
  // Get the HTML content for processing
  const htmlContent = clonedElement.innerHTML;

  return { images, text: htmlContent };
}

function buildRuns(element: Element, currentStyles: IStyles = {}): (TextRun | ExternalHyperlink)[] {
  const runs: (TextRun | ExternalHyperlink)[] = [];

  // Do not process children of these block elements here, they are handled by the main loop
  if (["UL", "OL", "TABLE", "H1", "H2", "H3", "H4", "H5", "H6"].includes(element.tagName.toUpperCase())) {
    return [];
  }

  element.childNodes.forEach((child) => {
    if (child.nodeType === Node.TEXT_NODE) {
      if (child.textContent) {
        runs.push(new TextRun({ text: child.textContent, ...currentStyles }));
      }
    } else if (child.nodeType === Node.ELEMENT_NODE) {
      const el = child as Element;
      const tagName = el.tagName.toUpperCase();

      const newStyles = { ...currentStyles };
      if (tagName === "STRONG" || tagName === "B") newStyles.bold = true;
      if (tagName === "EM" || tagName === "I") newStyles.italics = true;
      if (tagName === "STRIKE" || tagName === "S" || tagName === "DEL") newStyles.strike = true;
      if (tagName === "CODE") newStyles.font = "Courier New";
      if (tagName === "BR") {
        runs.push(new TextRun({ text: "\n", ...currentStyles }));
        return;
      }

      if (tagName === "A") {
        const href = el.getAttribute("href");
        if (href) {
          newStyles.style = "Hyperlink";
          const childrenRuns = buildRuns(el, newStyles);
          runs.push(
            new ExternalHyperlink({
              children: childrenRuns.filter((r): r is TextRun => r instanceof TextRun),
              link: href,
            })
          );
        } else {
          runs.push(...buildRuns(el, newStyles));
        }
      } else {
        runs.push(...buildRuns(el, newStyles));
      }
    }
  });

  return runs;
}

// --- Helper function to convert HTML to DOCX format ---
function htmlToDocx(htmlContent: string): (Paragraph | Table)[] {
  if (!htmlContent) return [];

  const docxElements: (Paragraph | Table)[] = [];

  // Create a temporary div to parse HTML and find the main content
  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = htmlContent;
  const contentContainer = tempDiv.querySelector(".markdown-content") || tempDiv;

  Array.from(contentContainer.children).forEach((child) => {
    const el = child as Element;
    const tagName = el.tagName.toUpperCase();

    if (tagName.startsWith("H") && !isNaN(parseInt(tagName.charAt(1)))) {
      const level = parseInt(tagName.charAt(1));
      docxElements.push(
        new Paragraph({
          spacing: { after: 100 },
          style: `Heading${level}`,
          text: el.textContent || "",
        })
      );
    } else if (tagName === "UL" || tagName === "OL") {
      processList(el, docxElements, 0);
    } else if (tagName === "TABLE") {
      const rows: TableRow[] = [];

      const processCell = (cell: Element): (Paragraph | Table)[] => {
        const children = htmlToDocx(cell.innerHTML);
        // If the cell only contains inline content (no block elements), wrap it.
        if (children.length === 0 && cell.textContent?.trim()) {
          return [new Paragraph({ children: buildRuns(cell) })];
        }
        // If we have children but they're all paragraphs, return them as-is
        if (children.length > 0 && children.every((child) => child instanceof Paragraph)) {
          return children;
        }
        // Otherwise, wrap the content in a paragraph
        return [new Paragraph({ children: buildRuns(cell) })];
      };

      Array.from(el.querySelectorAll("tr")).forEach((row) => {
        const isHeader =
          row.parentElement?.tagName.toUpperCase() === "THEAD" ||
          Array.from(row.children).every((c) => c.tagName.toUpperCase() === "TH");

        const cells = Array.from(row.querySelectorAll("th, td")).map((cell) => {
          return new TableCell({
            children: processCell(cell),
          });
        });

        rows.push(
          new TableRow({
            children: cells,
            tableHeader: isHeader,
          })
        );
      });

      if (rows.length > 0) {
        docxElements.push(
          new Table({
            borders: {
              bottom: { color: "000000", size: 1, style: "single" },
              insideHorizontal: { color: "000000", size: 1, style: "single" },
              insideVertical: { color: "000000", size: 1, style: "single" },
              left: { color: "000000", size: 1, style: "single" },
              right: { color: "000000", size: 1, style: "single" },
              top: { color: "000000", size: 1, style: "single" },
            },
            rows,
          })
        );
      }
    } else if (tagName === "PRE" || (tagName === "CODE" && el.parentElement?.tagName.toUpperCase() === "PRE")) {
      // Code block: black background, white monospace text
      docxElements.push(
        new Paragraph({
          children: [new TextRun({ color: "FFFFFF", font: "Courier New", size: 20, text: el.textContent || "" })],
          shading: { fill: "000000" },
          spacing: { after: 100 },
        })
      );
    } else if (tagName === "BLOCKQUOTE") {
      docxElements.push(
        new Paragraph({
          border: { left: { color: "888888", size: 6, space: 1, style: "single" } },
          children: buildRuns(el),
          spacing: { after: 100 },
        })
      );
    } else if (tagName === "P") {
      const runs = buildRuns(el);
      if (runs.length > 0) {
        docxElements.push(new Paragraph({ children: runs, spacing: { after: 100 } }));
      }
    } else if (tagName === "DIV" || tagName === "SPAN") {
      // Recursively process children for div/span
      Array.from(el.childNodes).forEach((childNode) => {
        if (childNode.nodeType === Node.ELEMENT_NODE) {
          docxElements.push(...htmlToDocx((childNode as Element).outerHTML));
        } else if (childNode.nodeType === Node.TEXT_NODE && childNode.textContent?.trim()) {
          docxElements.push(new Paragraph({ children: [new TextRun(childNode.textContent)], spacing: { after: 100 } }));
        }
      });
    } else if (tagName === "HR") {
      // Add a horizontal rule as a styled paragraph
      docxElements.push(
        new Paragraph({
          border: { bottom: { color: "888888", size: 6, space: 1, style: "single" } },
          spacing: { after: 100 },
        })
      );
    }
  });

  return docxElements;
}

// Helper function to process nested lists
function processList(list: Element, docxElements: (Paragraph | Table)[], level: number) {
  Array.from(list.children).forEach((item) => {
    if (item.tagName.toUpperCase() !== "LI") return; // Only process li elements

    // 1. Process the direct content of the list item (text, links, etc.)
    // We create a temporary holder to avoid processing nested lists' content at this stage.
    const contentHolder = document.createElement("div");
    Array.from(item.childNodes).forEach((child) => {
      // If the child is not a list, add it to our holder.
      if (
        child.nodeType === Node.TEXT_NODE ||
        (child.nodeType === Node.ELEMENT_NODE && !["UL", "OL"].includes((child as Element).tagName.toUpperCase()))
      ) {
        contentHolder.appendChild(child.cloneNode(true));
      }
    });

    const runs = buildRuns(contentHolder);
    // Only add a paragraph if there's actual content, not just whitespace.
    if (runs.length > 0 && contentHolder.textContent?.trim()) {
      docxElements.push(
        new Paragraph({
          bullet: { level },
          children: runs,
          spacing: { after: 50 },
        })
      );
    }

    // 2. Now, recursively process any nested lists within this list item
    Array.from(item.children).forEach((childElement) => {
      const el = childElement as Element;
      if (el.tagName.toUpperCase() === "UL" || el.tagName.toUpperCase() === "OL") {
        processList(el, docxElements, level + 1);
      }
    });
  });
}

// Export handlers
export async function exportToWord(agentName: string, chatName: string, username: string, t: any) {
  const conversations = await extractChatContent();
  const doc = new Document({
    sections: [
      {
        children: [
          // Title
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [new TextRun({ bold: true, color: "2F5496", font: "Helvetica", size: 48, text: chatName })],
            spacing: { after: 300 },
          }),

          // Metadata
          new Paragraph({
            children: [
              new TextRun({ text: `${t(TranslationKeys.ACTIONSPANELEXPORT_AGENT)}: ` }),
              new TextRun({ text: agentName }),
            ],
            spacing: { after: 50 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `${t(TranslationKeys.ACTIONSPANELEXPORT_GENERATEDAT)}: ${new Date().toLocaleString()}`,
              }),
            ],
            spacing: { after: 50 },
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: `${t(TranslationKeys.ACTIONSPANELEXPORT_GENERATEDBY)}: ${
                  username || t(TranslationKeys.ACTIONSPANELEXPORT_USER)
                }`,
              }),
            ],
            spacing: { after: 200 },
          }),

          // Conversations
          ...conversations.flatMap((conv) => [
            new Paragraph({
              children: [new TextRun({ bold: true, size: 24, text: `${t(TranslationKeys.ACTIONSPANELEXPORT_USER)}:` })],
              spacing: { before: 400 },
            }),
            ...htmlToDocx(conv.user.text),

            // User images
            ...conv.user.images.map(
              (img: string) =>
                new Paragraph({
                  children: [
                    new ImageRun({
                      data: img.split(",")[1],
                      transformation: { height: 300, width: 400 },
                      type: "png",
                    }),
                  ],
                })
            ),

            new Paragraph({
              children: [new TextRun({ bold: true, size: 24, text: `${agentName}:` })],
              spacing: { before: 100 },
            }),
            ...htmlToDocx(conv.bot.text),

            // Bot images
            ...conv.bot.images.map(
              (img: string) =>
                new Paragraph({
                  children: [
                    new ImageRun({
                      data: img.split(",")[1],
                      transformation: { height: 300, width: 400 },
                      type: "png",
                    }),
                  ],
                })
            ),
          ]),
        ],
      },
    ],
    styles: {
      characterStyles: [
        {
          id: "Hyperlink",
          name: "Hyperlink",
          run: {
            color: "0000FF",
            underline: {
              color: "0000FF",
              type: "single",
            },
          },
        },
      ],
      default: {
        document: {
          run: {
            color: "000000",
            font: "Helvetica",
            size: 22, // 11pt
          },
        },
      },
      paragraphStyles: [
        {
          basedOn: "Normal",
          id: "Heading1",
          name: "Heading 1",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 32 },
        },
        {
          basedOn: "Normal",
          id: "Heading2",
          name: "Heading 2",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 28 },
        },
        {
          basedOn: "Normal",
          id: "Heading3",
          name: "Heading 3",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 24 },
        },
        {
          basedOn: "Normal",
          id: "Heading4",
          name: "Heading 4",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 22 },
        },
        {
          basedOn: "Normal",
          id: "Heading5",
          name: "Heading 5",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 22 },
        },
        {
          basedOn: "Normal",
          id: "Heading6",
          name: "Heading 6",
          next: "Normal",
          quickFormat: true,
          run: { bold: true, color: "000000", font: "Helvetica", size: 22 },
        },
      ],
    },
  });

  const buffer = await Packer.toBuffer(doc);
  downloadFile(new Blob([buffer]), generateFilename(agentName, chatName, "docx"));
}

export async function exportToExcel(agentName: string, chatName: string, username: string, t: any) {
  const conversations = await extractChatContent();
  const workbook = new Workbook();
  const worksheet = workbook.addWorksheet(t(TranslationKeys.ACTIONSPANELEXPORT_CHATTRANSCRIPT));

  // Helper function to add images to a specific column
  const addImagesToColumn = (images: string[], column: string, startRow: number) => {
    images.forEach((imageData, imgIndex) => {
      try {
        const base64Data = imageData.split(",")[1];
        if (!base64Data) return;

        const imageId = workbook.addImage({
          base64: base64Data,
          extension: "png",
        });

        const imageRow = startRow + imgIndex;
        const row = worksheet.getRow(imageRow);

        const rowHeight = 60; // Reduced for more compact display
        row.height = Math.max(row.height || 15, rowHeight);

        worksheet.addImage(imageId, `${column}${imageRow}:${column}${imageRow}`);
      } catch (error) {
        console.warn(`Failed to add image to Excel column ${column}:`, error);
      }
    });
  };

  // Headers
  worksheet.columns = [
    { header: t(TranslationKeys.ACTIONSPANELEXPORT_USERREQUEST), key: "user", width: 50 },
    { header: t(TranslationKeys.ACTIONSPANELEXPORT_BOTRESPONSE), key: "bot", width: 50 },
    { header: t(TranslationKeys.ACTIONSPANELEXPORT_USERIMAGES), key: "userImages", width: 30 },
    { header: t(TranslationKeys.ACTIONSPANELEXPORT_BOTIMAGES), key: "botImages", width: 30 },
    { header: t("actionsPanelExport.exchange") || "Exchange", key: "exchange", width: 10 },
  ];

  // Add metadata in separate columns (F, G, H) to avoid interfering with main data
  worksheet.getCell("F1").value = `${t(TranslationKeys.ACTIONSPANELEXPORT_AGENT)}:`;
  worksheet.getCell("G1").value = agentName;
  worksheet.getCell("F2").value = `${t(TranslationKeys.ACTIONSPANELEXPORT_CHAT)}:`;
  worksheet.getCell("G2").value = chatName;
  worksheet.getCell("F3").value = `${t(TranslationKeys.ACTIONSPANELEXPORT_GENERATEDAT)}:`;
  worksheet.getCell("G3").value = new Date().toLocaleString();
  worksheet.getCell("F4").value = `${t(TranslationKeys.ACTIONSPANELEXPORT_GENERATEDBY)}:`;
  worksheet.getCell("G4").value = username || t(TranslationKeys.ACTIONSPANELEXPORT_USER);

  let currentRow = 2; // Start from row 2 (after headers)

  // Add conversations with images
  for (let i = 0; i < conversations.length; i++) {
    const conv = conversations[i];
    const textRow = currentRow;

    // Add text content
    worksheet.getCell(`A${textRow}`).value = htmlToText(conv.user.text);
    worksheet.getCell(`B${textRow}`).value = htmlToText(conv.bot.text);

    // Check if bot response contains a table and add a note
    if (conv.bot.text.includes("<table") || conv.bot.text.includes("TABLE")) {
      worksheet.getCell(`B${textRow}`).value =
        htmlToText(conv.bot.text) + "\n\n[Table content included - see exported DOCX/PPTX for formatted table]";
    }
    worksheet.getCell(`C${textRow}`).value =
      conv.user.images.length > 0 ? `${conv.user.images.length} ${t(TranslationKeys.ACTIONSPANELEXPORT_IMAGES)}` : "";
    worksheet.getCell(`D${textRow}`).value =
      conv.bot.images.length > 0 ? `${conv.bot.images.length} ${t(TranslationKeys.ACTIONSPANELEXPORT_IMAGES)}` : "";
    worksheet.getCell(`E${textRow}`).value = i + 1;

    // Add images
    addImagesToColumn(conv.user.images, "C", textRow);
    addImagesToColumn(conv.bot.images, "D", textRow);

    // Advance to the next available row
    const rowsForThisTurn = Math.max(1, conv.user.images.length, conv.bot.images.length);
    currentRow += rowsForThisTurn;
  }

  const buffer = await workbook.xlsx.writeBuffer();
  downloadFile(new Blob([buffer]), generateFilename(agentName, chatName, "xlsx"));
}

export async function exportToPowerPoint(agentName: string, chatName: string, username: string, t: any) {
  const conversations = await extractChatContent();
  const pres = new pptxgen();

  username = username || t(TranslationKeys.ACTIONSPANELEXPORT_USER);
  pres.title = `${agentName} - ${chatName} - ${username}`;

  // Helper function to convert HTML to PowerPoint content with rich formatting
  const htmlToPowerPointContent = (htmlContent: string): any[] => {
    if (!htmlContent) return [];

    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = htmlContent;
    const contentContainer = tempDiv.querySelector(".markdown-content") || tempDiv;

    const content: any[] = [];

    // Recursive function to process elements and find tables
    const processElement = (element: Element): void => {
      const tagName = element.tagName.toUpperCase();

      if (tagName.startsWith("H") && !isNaN(parseInt(tagName.charAt(1)))) {
        const level = parseInt(tagName.charAt(1));
        const fontSize = Math.max(20 - (level - 1) * 2, 14);
        content.push({
          bold: true,
          fontSize,
          text: element.textContent || "",
          type: "heading",
        });
      } else if (tagName === "UL" || tagName === "OL") {
        const listItems = processListToPowerPoint(element, 0, tagName === "OL");
        content.push(...listItems);
      } else if (tagName === "TABLE") {
        content.push({
          data: processTableToPowerPoint(element),
          type: "table",
        });
      } else if (tagName === "PRE" || (tagName === "CODE" && element.parentElement?.tagName.toUpperCase() === "PRE")) {
        // Handle code blocks
        const codeText = element.textContent || "";
        content.push({
          language: element.querySelector("code")?.className?.replace("language-", "") || "text",
          text: codeText,
          type: "code-block",
        });
      } else if (tagName === "P") {
        const textOptions = buildPowerPointTextOptions(element);
        if (textOptions.length > 0) {
          content.push({
            options: textOptions,
            type: "text",
          });
        }
      } else if (tagName === "HR") {
        // Add a horizontal rule
        content.push({
          type: "hr",
        });
      } else if (tagName === "DIV") {
        // For div elements, process all children recursively
        // First, check if this div has any direct text content (not just in children)
        const hasDirectText = Array.from(element.childNodes).some(
          (node) => node.nodeType === Node.TEXT_NODE && node.textContent?.trim()
        );

        if (hasDirectText) {
          const textOptions = buildPowerPointTextOptions(element);
          if (textOptions.length > 0) {
            content.push({
              options: textOptions,
              type: "text",
            });
          }
        }

        // Process all children recursively
        Array.from(element.children).forEach((child) => {
          processElement(child);
        });
      } else if (tagName === "SPAN") {
        // For span elements, process their content
        const textOptions = buildPowerPointTextOptions(element);
        if (textOptions.length > 0) {
          content.push({
            options: textOptions,
            type: "text",
          });
        }
      }
    };

    // Process all top-level children
    Array.from(contentContainer.children).forEach((child) => {
      processElement(child);
    });

    return content;
  };

  // Helper function to build PowerPoint text options with formatting
  const buildPowerPointTextOptions = (element: Element): any[] => {
    const textOptions: any[] = [];

    const processNode = (node: Node, currentFormat: any = {}): void => {
      if (node.nodeType === Node.TEXT_NODE) {
        if (node.textContent?.trim()) {
          textOptions.push({
            options: { ...currentFormat },
            text: node.textContent,
          });
        }
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const el = node as Element;
        const tagName = el.tagName.toUpperCase();
        const newFormat = { ...currentFormat };

        // Handle basic formatting tags
        if (tagName === "STRONG" || tagName === "B") newFormat.bold = true;
        if (tagName === "EM" || tagName === "I") newFormat.italic = true;
        if (tagName === "U") newFormat.underline = true;
        if (tagName === "CODE") newFormat.fontFace = "Courier New";
        if (tagName === "A") {
          newFormat.underline = true;
          newFormat.color = "0066CC";
        }
        if (tagName === "BR") {
          textOptions.push({
            options: { ...currentFormat },
            text: "\n",
          });
          return;
        }

        // Handle inline styles
        const style = el.getAttribute("style");
        if (style) {
          const styleObj = parseInlineStyles(style);
          if (styleObj.color) newFormat.color = cssColorToHex(styleObj.color);
          if (styleObj.backgroundColor) newFormat.fill = { color: cssColorToHex(styleObj.backgroundColor) };
          if (styleObj.fontSize) {
            const fontSize = styleObj.fontSize;
            if (fontSize.includes("px")) {
              newFormat.fontSize = parseInt(fontSize);
            } else if (fontSize.includes("pt")) {
              newFormat.fontSize = parseInt(fontSize) * 1.33; // Convert pt to px roughly
            } else if (fontSize.includes("em")) {
              newFormat.fontSize = parseInt(fontSize) * 16; // Convert em to px roughly
            } else {
              newFormat.fontSize = parseInt(fontSize);
            }
          }
          if (styleObj.fontFamily) newFormat.fontFace = styleObj.fontFamily.split(",")[0].replace(/['"]/g, "");
          if (styleObj.textAlign) newFormat.align = styleObj.textAlign;
          if (styleObj.fontWeight === "bold" || parseInt(styleObj.fontWeight) >= 600) newFormat.bold = true;
          if (styleObj.fontStyle === "italic") newFormat.italic = true;
          if (styleObj.textDecoration === "underline") newFormat.underline = true;
        }

        el.childNodes.forEach((child) => processNode(child, newFormat));
      }
    };

    element.childNodes.forEach((child) => processNode(child));
    return textOptions;
  };

  // Helper function to parse inline CSS styles
  const parseInlineStyles = (styleString: string): any => {
    const styles: any = {};
    const stylePairs = styleString.split(";");

    stylePairs.forEach((pair) => {
      const [property, value] = pair.split(":").map((s) => s.trim());
      if (property && value) {
        styles[property] = value;
      }
    });

    return styles;
  };

  // Helper function to convert CSS color to hex
  const cssColorToHex = (color: string): string => {
    if (!color) return "000000";

    // Handle RGB format
    const rgbMatch = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (rgbMatch) {
      const r = parseInt(rgbMatch[1]);
      const g = parseInt(rgbMatch[2]);
      const b = parseInt(rgbMatch[3]);
      return ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase();
    }

    // Handle hex format
    if (color.startsWith("#")) {
      return color.slice(1).toUpperCase();
    }

    // Handle named colors (basic mapping)
    const colorMap: { [key: string]: string } = {
      black: "000000",
      blue: "0000FF",
      brown: "A52A2A",
      cyan: "00FFFF",
      gold: "FFD700",
      gray: "808080",
      green: "00FF00",
      grey: "808080",
      lime: "00FF00",
      magenta: "FF00FF",
      maroon: "800000",
      navy: "000080",
      olive: "808000",
      orange: "FFA500",
      pink: "FFC0CB",
      purple: "800080",
      red: "FF0000",
      silver: "C0C0C0",
      teal: "008080",
      white: "FFFFFF",
      yellow: "FFFF00",
    };

    return colorMap[color.toLowerCase()] || "000000";
  };

  // Helper function to process lists to PowerPoint format
  const processListToPowerPoint = (list: Element, level: number, isOrdered: boolean): any[] => {
    const items: any[] = [];
    let itemNumber = 1;

    Array.from(list.children).forEach((item) => {
      if (item.tagName.toUpperCase() !== "LI") return;

      const indent = level * 0.3;
      const bullet = isOrdered ? `${itemNumber}. ` : "• ";

      // Process the list item content, excluding nested lists
      const contentHolder = document.createElement("div");
      Array.from(item.childNodes).forEach((child) => {
        if (
          child.nodeType === Node.TEXT_NODE ||
          (child.nodeType === Node.ELEMENT_NODE && !["UL", "OL"].includes((child as Element).tagName.toUpperCase()))
        ) {
          contentHolder.appendChild(child.cloneNode(true));
        }
      });

      const textOptions = buildPowerPointTextOptions(contentHolder);
      if (textOptions.length > 0) {
        items.push({
          indent,
          text: [{ options: { bold: true }, text: bullet }, ...textOptions],
          type: "list-item",
        });
        itemNumber++;
      }

      // Process nested lists
      Array.from(item.children).forEach((childElement) => {
        const el = childElement as Element;
        if (el.tagName.toUpperCase() === "UL" || el.tagName.toUpperCase() === "OL") {
          const nestedItems = processListToPowerPoint(el, level + 1, el.tagName.toUpperCase() === "OL");
          items.push(...nestedItems);
        }
      });
    });

    return items;
  };

  // Helper function to process tables to PowerPoint format
  const processTableToPowerPoint = (table: Element): any[][] => {
    const rows = Array.from(table.querySelectorAll("tr"));
    const tableData: any[][] = [];

    rows.forEach((row) => {
      const cells = Array.from(row.querySelectorAll("th, td"));
      const rowData = cells.map((cell) => {
        const isHeader = row.parentElement?.tagName.toUpperCase() === "THEAD" || cell.tagName.toUpperCase() === "TH";

        // Extract text content, handling potential nested elements
        let cellText = "";
        if (cell.children.length > 0) {
          // If cell has children, get text from all child nodes
          cellText = Array.from(cell.childNodes)
            .map((node) => node.textContent || "")
            .join(" ")
            .trim();
        } else {
          cellText = cell.textContent || "";
        }

        return {
          options: isHeader ? { bold: true, color: "000000", fill: "F2F2F2" } : { color: "000000" },
          text: cellText,
        };
      });
      tableData.push(rowData);
    });

    return tableData;
  };

  // Helper function to chunk content into slides
  const chunkContentToSlides = (content: any[]): any[][] => {
    // Reduced from 10 to 8
    const slides: any[][] = [];
    let currentSlide: any[] = [];
    let estimatedHeight = 0;

    for (let i = 0; i < content.length; i++) {
      const item = content[i];

      // Special handling for tables - they get their own slide
      if (item.type === "table") {
        if (currentSlide.length > 0) {
          slides.push(currentSlide);
          currentSlide = [];
          estimatedHeight = 0;
        }
        slides.push([item]);
        continue;
      }

      // Estimate height for this item
      let itemHeight = 0.5; // Default height
      if (item.type === "text") {
        const textContent = item.options.map((opt: any) => opt.text).join("");
        const estimatedLines = Math.ceil(textContent.length / 70);
        itemHeight = estimatedLines * 0.3 + 0.35;
      } else if (item.type === "list-item") {
        const textContent = item.text.map((textItem: any) => textItem.text).join("");
        const estimatedLines = Math.ceil(textContent.length / 80);
        itemHeight = estimatedLines * 0.25 + 0.3;
      } else if (item.type === "code-block") {
        const lines = item.text.split("\n");
        itemHeight = lines.length * 0.25 + 0.45;
      } else if (item.type === "heading") {
        itemHeight = 0.5;
      } else if (item.type === "hr") {
        itemHeight = 0.3;
      }

      // Check if adding this item would exceed slide height (5.2 - 0.8 = 4.4 available)
      if (estimatedHeight + itemHeight > 4.0) {
        // Conservative limit
        slides.push(currentSlide);
        currentSlide = [];
        estimatedHeight = 0;
      }

      currentSlide.push(item);
      estimatedHeight += itemHeight;
    }

    if (currentSlide.length > 0) {
      slides.push(currentSlide);
    }

    return slides;
  };

  // Helper function to render content on a slide
  const renderContentOnSlide = (slide: any, content: any[], startY: number = 0.8): number => {
    let currentY = startY;
    const maxY = 5.2; // Reduced from 5.5 to provide more margin

    content.forEach((item) => {
      if (currentY > maxY) return; // Skip if we're out of space

      switch (item.type) {
        case "heading":
          slide.addText(item.text, {
            bold: item.bold,
            fontSize: item.fontSize,
            h: 0.4,
            w: 9,
            x: 0.5,
            y: currentY,
          });
          currentY += 0.5;
          break;

        case "text": {
          // Calculate height based on content length and formatting
          const textContent = item.options.map((opt: any) => opt.text).join("");
          const estimatedLines = Math.ceil(textContent.length / 70); // Reduced from 80 for more conservative estimate
          const textHeight = Math.min(estimatedLines * 0.3 + 0.2, maxY - currentY - 0.2); // Added margin

          // Create rich text array for PowerPoint
          const richTextArray = item.options.map((opt: any) => ({
            options: {
              bold: opt.options.bold || false,
              color: opt.options.color || "000000",
              fontFace: opt.options.fontFace || "Arial",
              fontSize: opt.options.fontSize || 12,
              italic: opt.options.italic || false,
              underline: opt.options.underline || false,
              ...opt.options,
            },
            text: opt.text,
          }));

          slide.addText(richTextArray, {
            fontSize: 12,
            h: textHeight,
            w: 9,
            wrap: true,
            x: 0.5,
            y: currentY,
          });
          currentY += textHeight + 0.15; // Increased spacing
          break;
        }

        case "list-item": {
          // Create rich text array for list items
          const listRichTextArray = item.text.map((textItem: any) => ({
            options: {
              bold: textItem.options.bold || false,
              color: textItem.options.color || "000000",
              fontFace: textItem.options.fontFace || "Arial",
              fontSize: textItem.options.fontSize || 11,
              italic: textItem.options.italic || false,
              underline: textItem.options.underline || false,
              ...textItem.options,
            },
            text: textItem.text,
          }));

          // Calculate height for list items based on content
          const listTextContent = item.text.map((textItem: any) => textItem.text).join("");
          const listEstimatedLines = Math.ceil(listTextContent.length / 80);
          const listHeight = Math.min(listEstimatedLines * 0.25 + 0.2, maxY - currentY - 0.2);

          slide.addText(listRichTextArray, {
            fontSize: 11,
            h: listHeight,
            w: 9 - item.indent,
            wrap: true,
            x: 0.5 + item.indent,
            y: currentY,
          });
          currentY += listHeight + 0.1;
          break;
        }

        case "code-block": {
          // Calculate height based on number of lines
          const lines = item.text.split("\n");
          const lineHeight = 0.25;
          const codeHeight = Math.min(lines.length * lineHeight + 0.2, maxY - currentY - 0.2);

          slide.addText(item.text, {
            align: "left",
            color: "2D2D2D", // Dark gray text fill: { color: 'F5F5F5' }, // Light gray background fontFace: 'Courier New',
            fontSize: 10,
            h: codeHeight,
            valign: "top",
            w: 9,
            wrap: true,
            x: 0.5,
            y: currentY,
          });
          currentY += codeHeight + 0.25; // Increased spacing
          break;
        }

        case "hr": {
          // Add a horizontal rule
          slide.addShape("line", {
            h: 0,
            line: { color: "CCCCCC", width: 2 },
            w: 9,
            x: 0.5,
            y: currentY + 0.1,
          });
          currentY += 0.3;
          break;
        }

        case "table": {
          if (item.data.length > 0) {
            slide.addTable(item.data, {
              align: "left",
              border: { color: "000000", pt: 1 },
              fill: "FFFFFF",
              fontSize: 11,
              valign: "middle",
              w: 9,
              x: 0.5,
              y: currentY,
            });
            // Calculate height based on number of rows
            const tableHeight = Math.min(item.data.length * 0.4 + 0.3, maxY - currentY - 0.2);
            currentY += tableHeight + 0.2; // Added spacing
          }
          break;
        }
      }
    });

    return currentY;
  };

  // Title slide
  const titleSlide = pres.addSlide();
  titleSlide.addText(chatName, {
    align: "center",
    bold: true,
    fontSize: 32,
    h: 1,
    w: 8,
    x: 1,
    y: 2,
  });
  titleSlide.addText(`${agentName} - ${username || t(TranslationKeys.ACTIONSPANELEXPORT_USER)}`, {
    align: "center",
    fontSize: 16,
    h: 0.5,
    w: 8,
    x: 1,
    y: 3.5,
  });

  // Process conversations
  conversations.forEach((conv, i) => {
    const conversationNumber = i + 1;

    // User content slides
    const userContent = htmlToPowerPointContent(conv.user.text);
    if (userContent.length > 0) {
      const userSlides = chunkContentToSlides(userContent);
      userSlides.forEach((slideContent, slideIndex) => {
        const slide = pres.addSlide();
        slide.addText(
          `${t(TranslationKeys.ACTIONSPANELEXPORT_EXCHANGE)} ${conversationNumber} - ${username} ${
            userSlides.length > 1 ? `${t(TranslationKeys.ACTIONSPANELEXPORT_PART, { number: slideIndex + 1 })}` : ""
          }`,
          {
            bold: true,
            fontSize: 18,
            h: 0.4,
            w: 9,
            x: 0.5,
            y: 0.3,
          }
        );

        renderContentOnSlide(slide, slideContent);
      });
    }

    // User images slide
    if (conv.user.images.length > 0) {
      const slide = pres.addSlide();
      slide.addText(
        `${t(TranslationKeys.ACTIONSPANELEXPORT_EXCHANGE)} ${conversationNumber} - ${username} ${t(
          TranslationKeys.ACTIONSPANELEXPORT_USERIMAGES
        )}`,
        {
          bold: true,
          fontSize: 18,
          h: 0.4,
          w: 9,
          x: 0.5,
          y: 0.3,
        }
      );

      conv.user.images.forEach((img: string, imgIndex: number) => {
        try {
          const imagesPerRow = 2;
          const imageWidth = 4;
          const imageHeight = 3;
          const row = Math.floor(imgIndex / imagesPerRow);
          const col = imgIndex % imagesPerRow;

          slide.addImage({
            data: img,
            h: imageHeight,
            w: imageWidth,
            x: 0.5 + col * (imageWidth + 0.5),
            y: 0.8 + row * (imageHeight + 0.3),
          });
        } catch (error) {
          console.warn(`Failed to add user image to PowerPoint:`, error);
        }
      });
    }

    // Bot content slides
    const botContent = htmlToPowerPointContent(conv.bot.text);
    if (botContent.length > 0) {
      const botSlides = chunkContentToSlides(botContent);
      botSlides.forEach((slideContent, slideIndex) => {
        const slide = pres.addSlide();
        slide.addText(
          `${t(TranslationKeys.ACTIONSPANELEXPORT_EXCHANGE)} ${conversationNumber} - ${agentName} ${
            botSlides.length > 1 ? ` ${t(TranslationKeys.ACTIONSPANELEXPORT_PART, { number: slideIndex + 1 })}` : ""
          }`,
          {
            bold: true,
            fontSize: 18,
            h: 0.4,
            w: 9,
            x: 0.5,
            y: 0.3,
          }
        );

        renderContentOnSlide(slide, slideContent);
      });
    }

    // Bot images slide
    if (conv.bot.images.length > 0) {
      const slide = pres.addSlide();
      slide.addText(
        `${t(TranslationKeys.ACTIONSPANELEXPORT_EXCHANGE)} ${conversationNumber} - ${agentName} ${t(
          TranslationKeys.ACTIONSPANELEXPORT_BOTIMAGES
        )}`,
        {
          bold: true,
          fontSize: 18,
          h: 0.4,
          w: 9,
          x: 0.5,
          y: 0.3,
        }
      );

      conv.bot.images.forEach((img: string, imgIndex: number) => {
        try {
          const imagesPerRow = 2;
          const imageWidth = 4;
          const imageHeight = 3;
          const row = Math.floor(imgIndex / imagesPerRow);
          const col = imgIndex % imagesPerRow;

          slide.addImage({
            data: img,
            h: imageHeight,
            w: imageWidth,
            x: 0.5 + col * (imageWidth + 0.5),
            y: 0.8 + row * (imageHeight + 0.3),
          });
        } catch (error) {
          console.warn(`Failed to add bot image to PowerPoint:`, error);
        }
      });
    }
  });

  await pres.writeFile({ fileName: generateFilename(agentName, chatName, "pptx") });
}

// Main component
export const ActionsPanelExport: React.FC<ActionsPanelExportProps> = ({
  currentAgentName,
  currentChatName,
  isShared = false,
  username,
}) => {
  const { t } = useTranslation();
  const [loadingType, setLoadingType] = useState<string | null>(null);

  const exportActions = [
    { handler: exportToWord, icon: docxIcon, label: t(TranslationKeys.ACTIONSPANELEXPORT_EXPORTTOWORD), type: "docx" },
    {
      handler: exportToPowerPoint,
      icon: pptxIcon,
      label: t(TranslationKeys.ACTIONSPANELEXPORT_EXPORTTOPOWERPOINT),
      type: "pptx",
    },
    {
      handler: exportToExcel,
      icon: xslxIcon,
      label: t(TranslationKeys.ACTIONSPANELEXPORT_EXPORTTOEXCEL),
      type: "xlsx",
    },
  ];

  const handleExport = useCallback(
    async (action: any) => {
      setLoadingType(action.type);
      try {
        await action.handler(currentAgentName, currentChatName, username, t);
      } catch (error) {
        let errorMsg = "";
        if (action.type === "docx") errorMsg = t(TranslationKeys.ACTIONSPANELEXPORT_ERROREXPORTINGWORD);
        else if (action.type === "pptx") errorMsg = t(TranslationKeys.ACTIONSPANELEXPORT_ERROREXPORTINGPOWERPOINT);
        else if (action.type === "xlsx") errorMsg = t(TranslationKeys.ACTIONSPANELEXPORT_ERROREXPORTINGEXCEL);
        else errorMsg = t("errorMessages.unknownError");
        console.error(`${errorMsg}`, error);
        // Optionally, show a toast or alert here
      } finally {
        setLoadingType(null);
      }
    },
    [currentAgentName, currentChatName, username, t]
  );

  const renderButton = (action: any) => {
    const isLoading = loadingType === action.type;
    return (
      <Button
        key={action.type}
        className="action-button d-flex align-items-center m-2"
        style={actionButtonStyle}
        variant="transparent"
        size="sm"
        onClick={() => handleExport(action)}
        disabled={isLoading}
      >
        <img src={action.icon} alt={action.label} style={iconStyle} />
        <span className="ps-2 pe-2">{action.label}</span>
        {isLoading && <Spinner animation="border" size="sm" className="ms-2" />}
      </Button>
    );
  };

  if (isShared) {
    return (
      <div className="d-flex flex-row gap-3 justify-content-center align-items-center">
        {exportActions.map(renderButton)}
      </div>
    );
  }

  return (
    <div>
      {exportActions.map((action) => (
        <div className="d-flex align-items-center flex-row" key={action.type}>
          <div style={actionContainerStyle} />
          <div className="rounded-circle bg-primary" style={blueDotStyle} />
          {renderButton(action)}
        </div>
      ))}
    </div>
  );
};
