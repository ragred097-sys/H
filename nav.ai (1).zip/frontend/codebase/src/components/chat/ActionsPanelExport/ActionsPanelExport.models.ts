export interface ActionsPanelExportProps {
  currentAgentName: string;
  currentChatName: string;
  username: string;
  isShared?: boolean;
}

// Types
export type ActionsPanelExportMessageContent =
  | { type: "text"; data: string }
  | { type: "image"; data: string }
  | { type: "heading"; level: number; data: string }
  | { type: "bold"; data: string }
  | { type: "italic"; data: string }
  | { type: "link"; data: string; url: string }
  | { type: "hr"; data: string }
  | { type: "list"; ordered: boolean; items: Array<{ type: "listitem" | "task"; data: string; checked?: boolean }> }
  | { type: "blockquote"; data: string }
  | { type: "newline"; data: string }
  | { type: "listitem"; data: string }
  | { type: "task"; data: string; checked: boolean };

export interface ActionsPanelExportMessage {
  type: "user" | "bot";
  content: ActionsPanelExportMessageContent[];
}

export interface IStyles {
  bold?: boolean;
  italics?: boolean;
  strike?: boolean;
  style?: string;
  font?: string;
}
