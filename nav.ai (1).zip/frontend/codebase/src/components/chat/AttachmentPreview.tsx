import React, { useEffect, useState } from "react";

import { OverlayTrigger, Tooltip } from "react-bootstrap";

import pdfIcon from "../../assets/images/pdfIcon.png";
import pptIcon from "../../assets/images/pptxIcon.png";
import wordIcon from "../../assets/images/wordIcon.png";
import excelIcon from "../../assets/images/xslxIcon.png";
import { Attachment, DocumentType } from "../../lib/Model.ts";

interface AttachmentPreviewProps {
  attachment: Attachment;
}

const AttachmentInfo: React.FC<AttachmentPreviewProps> = ({ attachment }) => {
  return attachment.name;
};

const AttachmentPreview: React.FC<AttachmentPreviewProps> = ({ attachment }) => {
  const [preview, setPreview] = useState<string | null>(null);
  const fileType = {
    excel: "application/vnd.ms-excel",
    pdf: "application/pdf",
    ppt: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    wordDoc: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  };
  useEffect(() => {
    if (attachment) {
      if (attachment.type === DocumentType.IMAGE) {
        if (attachment.thumbnail) setPreview(attachment?.thumbnail);
      } else if (attachment.type === DocumentType.TEXT) {
        if (attachment.mimeType === fileType.ppt) {
          setPreview(pptIcon);
        } else if (attachment.mimeType === fileType.pdf) {
          setPreview(pdfIcon);
        } else if (attachment.mimeType === fileType.wordDoc) {
          setPreview(wordIcon);
        } else if (attachment.mimeType === fileType.excel) {
          setPreview(excelIcon);
        }
      } else if (attachment.type === DocumentType.VIDEO) {
        setPreview(attachment.thumbnail as string);
      } else {
        setPreview("");
      }
    }
  }, [attachment]);

  const getFileIcon = () => {
    switch (attachment.type) {
      case DocumentType.VIDEO:
        return "bi-camera-video";
      case DocumentType.AUDIO:
        return "bi-file-earmark-music";
      case DocumentType.TEXT:
        return "bi-file-earmark-text";
      default:
        return "bi-file-earmark";
    }
  };
  return (
    <OverlayTrigger
      placement="top-end"
      delay={{ hide: 500, show: 750 }}
      overlay={
        <Tooltip style={{ zIndex: 3000 }}>
          <AttachmentInfo attachment={attachment} />
        </Tooltip>
      }
    >
      {preview ? (
        <img
          src={preview}
          alt={attachment.name}
          style={{
            height: "100%",
            objectFit: "contain",
            width: "100%",
          }}
        />
      ) : (
        <div className="w-100 h-100 d-flex align-items-center justify-content-center bg-secondary rounded">
          <i className={`bi ${getFileIcon()} text-light`} style={{ fontSize: "24px" }}></i>
        </div>
      )}
    </OverlayTrigger>
  );
};

export default AttachmentPreview;
