import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { AnimatePresence, motion } from "framer-motion";

import { Button, Collapse, Form, Modal, Offcanvas, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { AuthContextProps, useAuth } from "react-oidc-context";
import { useLocation, useNavigate, useParams } from "react-router-dom";

import i18n from "../../../i18n";
import {
  Agent,
  AgentWorkflow,
  Assistant,
  Attachment,
  ChatMode,
  Conversation,
  Message,
  MessagePart,
  MessagePartType,
  MessageRole,
  Module,
  ModuleType,
  TypeName,
  WorkflowConsoleRendererProps,
  Workspace,
  getMessagePartTypeFor,
  typeOf,
} from "../../../lib/Model";
import { AgentService } from "../../../services/AgentService";
import { AgentWorkflowService } from "../../../services/AgentWorkflowService";
import { AssistantService } from "../../../services/AssistantService";
import { ConversationService } from "../../../services/ConversationService";
import { GovernanceService } from "../../../services/GovernanceService";
import { ModuleService } from "../../../services/ModuleService";
import { WorkspaceService } from "../../../services/WorkspaceService";
import { AgentFormForAttachment, rightPaneChatIconState, workflowStore } from "../../../stores/useStore";
import { TranslationKeys } from "../../../types/translation-keys";
import { AgentDirtyFields, dirtyFieldsDefaultValues, handleAgentDirtyDataTitles } from "../../../utils/agentFormFields";
import { DESCRIBE_SYSTEM_PROMPT } from "../../../utils/constants";
import { createChat, updateAgentWithAttachmentStorageForVss } from "../../../utils/crudUtils";
import { isEqtyEnabled } from "../../../utils/eqty";
import { fileToBase64 } from "../../../utils/fileUtils";
import { cleanUpPartialMessages, cleanUpPartialRenderers } from "../../../utils/messageUtils";
import AgentInference from "../../eqty/lineage/AgentInference";
import FileCarousel from "../../fileCarousel/FileCarousel";
import AgentWorkflowForm from "../../forms/AgentWorkflowForm";
import NewAgentForm from "../../forms/NewAgentForm/NewAgentForm";
import UserPromptForm from "../../forms/UserPromptForm/UserPromptForm";
import { AttachedFile } from "../../general/AttachedFile";
import CardSkeleton from "../../general/CardSkeleton";
import FavouritesRenderer from "../../general/FavouritesRenderer/FavouritesRenderer";
import ModuleDropdown from "../../general/ModuleDropdown/ModuleDropdown";
import { useNotification } from "../../general/NotificationProvider";
import ConfirmUnsavedModal from "../../general/UnsavedChangesModal";
import { MessageRenderer } from "../../renderers/MessageRenderer/MessageRenderer";
import AssistantSidebar from "../AssistantSidebar";
import Breadcrumbs from "../BreadCrumbs";
import { ChatCanvas } from "../ChatCanvas";
import { ConversationContext } from "../ConversationContext";
import MasterActions from "../MasterActions";

const nvModuleSpecId = "c7bf8553-f4b5-4f2e-a168-b1ff3bd23cd4";

export default function Chat({ clearChat }: { clearChat?: boolean }) {
  // State Variables
  const { t } = useTranslation();

  const [currentAgent, setCurrentAgent] = useState<Assistant | AgentWorkflow | null>(null);
  const [currentRootAgent, setCurrentRootAgent] = useState<Assistant | Agent | null>(null);
  const [currentChat, setCurrentChat] = useState<Conversation | null>(null);
  const [currentWorkspace, setCurrentWorkspace] = useState<Workspace | null>();
  const [newChatTitle, setNewChatTitle] = useState(currentChat?.name || "");
  const [editTitle, setEditTitle] = useState(false);
  const [mediaMode, setMediaMode] = useState(false);
  const [attachmentsMode, setAttachmentsMode] = useState(false);
  const [selectedAttachment, setSelectedAttachment] = useState<string>();
  const [rtxOn, setRtxOn] = useState(false);
  const [triggerUpdate, setTriggerUpdate] = useState(false);
  const [chats, setChats] = useState<Conversation[]>();
  const [showChats, setShowChats] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [chatData, setChatData] = useState<Message[]>([]);
  const [streamingContent, setStreamingContent] = useState<string>("");
  const [selectedLlm, setSelectedLlm] = useState<Module>();
  const [splash, setSplash] = useState(true);
  const [userMessage, setUserMessage] = useState<string>("");
  const [documents, setDocuments] = useState<(Attachment | AttachedFile)[]>([]);
  const [responding, setResponding] = useState(false);
  const [refreshChat, setRefreshChat] = useState(false);
  const [showInference, setShowInference] = useState(false);
  const [isLineageAvailable, setIsLineageAvailable] = useState<boolean>(false);
  const [isThumbsAvailable, setIsThumbsAvailable] = useState<boolean>(false);
  const [isGovernanceCompliant, setIsGovernanceCompliant] = useState<boolean | null>(null);
  const [thumb, setThumb] = useState<number | null>(null);
  const [isThumbInitialized, setIsThumbInitialized] = useState(false);
  const [showMasterActions, setShowMasterActions] = useState(false);
  const [chatTitle, setChatTitle] = useState<string>("");
  const [chatMode, setChatMode] = useState<ChatMode>();
  const [llms, setLLms] = useState<Module[]>();
  const [loading, setLoading] = useState({
    assistant: false,
    messages: false,
    workspaces: false,
  });
  const [isFormDirty, setIsFormDirty] = useState(false);
  const [isConfirmClose, setIsConfirmClose] = useState(false);
  const [dirtyFields, setDirtyFields] = useState<AgentDirtyFields>(dirtyFieldsDefaultValues);
  const { openErrorNotification } = useNotification();
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const updateUserMessage = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setUserMessage(e.target.value);
  }, []);
  const messageAccumulatorRef = useRef<string>(""); //ref to store aborted message chunks
  const navigate = useNavigate();
  const { agentData, openForm, setAgentData, setOpenForm } = AgentFormForAttachment();
  const {
    isChatUploadOpen,
    isSharedChatOpen,
    isSuperAgentConsoleOpen,
    setIsAgentDetailOpen,
    setIsAttachmentOpen,
    setIsChatHistoryOpen,
  } = rightPaneChatIconState();

  const SHIELD_CONFIG: Record<string, { icon: string; color: string }> = {
    false: { color: "red", icon: "bi-shield-fill-exclamation" },
    null: { color: "green", icon: "bi-shield-check" },
    true: { color: "green", icon: "bi-shield-fill-check" },
  };
  const THUMB_CONFIG: Record<number, { icon: string; color: string; transform: string }> = {
    [-1]: { color: "darkred", icon: "bi-hand-thumbs-down", transform: "none" },
    [0]: { color: "#BDB76B", icon: "bi-hand-thumbs-up", transform: "rotate(-90deg)" },
    [1]: { color: "green", icon: "bi-hand-thumbs-up", transform: "none" },
  };

  const thumbButton = (value: number) => {
    const config = THUMB_CONFIG[value];
    const isActive = thumb === value;
    return (
      <Button
        style={{ borderColor: "transparent", paddingLeft: "0.15rem", paddingRight: "0.15rem" }}
        variant="transparent"
        size="sm"
        className="mb-1"
        onClick={() => setThumb(isActive ? null : value)}
      >
        <i
          className={`bi ${config.icon}${isActive ? "-fill" : ""}`}
          style={{
            color: config.color,
            display: "inline-block",
            transform: config.transform,
          }}
        ></i>
      </Button>
    );
  };

  const resetWorkflowConsole = workflowStore((state) => state.resetWorkflowConsole);
  const setWorkflowConfig = workflowStore((state) => state.setWorkflowConfig);
  const setWorkflowConsole = workflowStore((state) => state.setWorkflowConsole);

  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();
  const chatFromHistory = location.state?.chat;
  const conversationId = location.state?.conversationId;
  const { agentId, agentID, workflowId, wsId } = useParams();
  const bufferRef = useRef<string>("");
  const isFlushingRef = useRef(false);

  // Canvas overlay stuff
  const closeDetailsOverlay = useCallback(() => {
    (setShowDetails(false), setIsAgentDetailOpen(false));
  }, []);
  const openChatOverLay = useCallback(() => {
    setShowChats((prev) => !prev);
    setIsChatHistoryOpen(true);
  }, []);
  const closeChatOverlay = useCallback(() => {
    setShowChats(false);
    setIsChatHistoryOpen(false);
  }, []);
  const openDetailsOverLay = useCallback(() => {
    (setShowDetails((prev) => !prev), setIsAgentDetailOpen(true));
  }, []);
  const updateCurrentChat = useCallback(async (currentChat: React.SetStateAction<Conversation | undefined>) => {
    setCurrentChat(currentChat as Conversation);
  }, []);

  const launchExistingChat = useCallback(
    (chat: Conversation) => {
      setCurrentChat(chat);

      // Don't change the mode if we're in standalone mode
      if (chatMode !== ChatMode.Standalone) {
        setChatMode(ChatMode.Agent);
      }

      setStreamingContent("");
      setSplash(false);

      // Set loading state for messages
      setLoading((prevState) => ({ ...prevState, messages: true }));

      // Important! Clear the isLoading state when launching existing chat
      setIsLoading(false);

      ConversationService.getMessages(chat)
        .then((res) => {
          setChatData(cleanUpPartialMessages(res));
          setLoading((prevState) => ({ ...prevState, messages: false }));
        })
        .catch((error) => {
          setLoading((prevState) => ({ ...prevState, messages: false }));
          console.error("Error fetching messages:", error);
        });
      closeChatOverlay();
    },
    [closeChatOverlay, setChatData, setLoading, chatMode]
  );
  const launchAgent = (agent: Assistant | AgentWorkflow) => {
    navigate(`/workspace/${wsId}/${agent.id}`);
  };
  //close the attachment window, if following windows are open
  useEffect(() => {
    if (showChats || showDetails || openForm || isChatUploadOpen || isSharedChatOpen || isSuperAgentConsoleOpen) {
      setAttachmentsMode(false);
    }
  }, [showChats, showDetails, openForm, isChatUploadOpen, isSharedChatOpen, isSuperAgentConsoleOpen]);

  useEffect(() => {
    // Only reset when needed dependencies change, not on every render
    if (wsId || agentId || workflowId) {
      resetWorkflowConsole();
    }

    if (wsId === "empty" || wsId === undefined || wsId === "undefined") {
      //for chat history "undefined" for favorite agent on home screen
    } else {
      setLoading((prevState) => ({ ...prevState, workspaces: true }));
      WorkspaceService.getWorkspace(wsId as string)
        .then((ws) => {
          setCurrentWorkspace(ws);
          setLoading((prevState) => ({ ...prevState, workspaces: false }));
        })
        .catch((error) => {
          setLoading((prevState) => ({ ...prevState, workspaces: false }));
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETWORKSPACE), error as Error);
        });
    }
    if (agentId) {
      setLoading((prevState) => ({ ...prevState, assistant: true }));
      AssistantService.getAssistant(agentId as string)
        .then((agent) => {
          setCurrentAgent(agent);
          setLoading((prevState) => ({ ...prevState, assistant: false }));
          if (conversationId) {
            launchExistingChat(chatFromHistory);
          }
        })
        .catch(async (error) => {
          if (error.response?.status === 404) {
            try {
              const agentDetails = await AgentWorkflowService.getAgentWorkflow(agentId as string);
              setCurrentAgent(agentDetails);
            } catch (workflowError) {
              openErrorNotification((workflowError as Error)?.message, workflowError as Error);
            }
          } else {
            openErrorNotification(error?.message, error as Error);
          }
          setLoading((prevState) => ({ ...prevState, assistant: false }));
        });
    }
    if (isEqtyEnabled()) {
      if (conversationId) {
        GovernanceService.isConversationLineageAvailable(conversationId as string).then((isLineageAvailable) => {
          setIsLineageAvailable(isLineageAvailable);
        });
        GovernanceService.getConversationThumb(conversationId as string).then((thumb) => {
          setThumb(thumb);
          setIsThumbInitialized(true);
        });
      } else {
        setIsLineageAvailable(true); // new conversation, we always have a lineage
      }
    }
    if (workflowId) {
      console.debug("Entering Super Agent Mode for Workflow:", workflowId);
      setChatMode(ChatMode.SuperAgent);
      AgentWorkflowService.getAgentWorkflow(workflowId as string).then((res) => {
        setCurrentAgent(res);
        setWorkflowConfig(res);
        if (res?.rootAgent) {
          if (res?.rootAgent?.type === TypeName.Agent) {
            AgentService.getAgent(res.rootAgent.id as string)
              .then((agent) => {
                setCurrentRootAgent(agent);
              })
              .catch(() => { });
          }
          if (res?.rootAgent?.type === TypeName.Assistant) {
            AssistantService.getAssistant(res.rootAgent.id as string)
              .then((agent) => {
                setCurrentRootAgent(agent);
              })
              .catch(() => { });
          }
        }
        if (conversationId) {
          launchExistingChat(chatFromHistory);
        }
      });
    }
  }, [
    wsId,
    conversationId,
    workflowId,
    agentId,
    chatFromHistory,
    resetWorkflowConsole,
    setWorkflowConfig,
    openErrorNotification,
    t,
    launchExistingChat,
  ]);
  useEffect(() => {
    if (isEqtyEnabled() && currentAgent) {
      GovernanceService.isAgenticGovernanceCompliant(currentAgent)
        .then((isGovernanceCompliant) => {
          setIsGovernanceCompliant(isGovernanceCompliant);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCESTATUS), err as Error);
          console.error("Error fetching governance status in chat:", err);
        });
      GovernanceService.isAgenticThumbsConfigured(currentAgent)
        .then((isThumbsConfigured) => {
          setIsThumbsAvailable(isThumbsConfigured);
        })
        .catch((err) => {
          openErrorNotification(t(TranslationKeys.ERRORMESSAGES_GETGOVERNANCESTATUS), err as Error);
          console.error("Error fetching governance status in chat:", err);
        });
    }
  }, [currentAgent, openErrorNotification, t]);

  useEffect(() => {
    if (isEqtyEnabled() && currentChat?.id && isThumbInitialized) {
      GovernanceService.setConversationThumb(currentChat.id as string, thumb);
    }
  }, [currentChat?.id, isThumbInitialized, thumb]);
  useMemo(() => {
    ModuleService.getModulesByType(ModuleType.LLM)
      .then((res) => {
        setLLms(res);
        const defaultLLM = res?.find((model) => model.default);
        if (chatMode === "standalone" || chatMode === "agent_function") {
          if (defaultLLM) {
            setSelectedLlm(defaultLLM);
          } else {
            //default not found then select first item
            setSelectedLlm(res[0]);
          }
        }
      })
      .catch((err) => openErrorNotification(err?.message, err as Error));
  }, [chatMode]);

  useEffect(() => {
    if (chatData.some((c) => c.parts.some((p) => p.content.includes("transcript")))) setShowMasterActions(true);
  }, [chatData]);

  // fetch User
  const auth: AuthContextProps = useAuth();
  const userDetails = {
    email: auth.user?.profile.email,
    firstName: auth.user?.profile.given_name,
    lastName: auth.user?.profile.family_name,
    name: auth.user?.profile.name,
  };

  // Combined effect to handle clearChat prop
  useEffect(() => {
    if (clearChat) {
      // Reset chat-related states
      setCurrentAgent(null);
      setCurrentChat(null);
      setChatData([]);
      setDocuments([]);
      setStreamingContent("");
      setSplash(true);
      setUserMessage("");
      setResponding(false);
      setSelectedAttachment(undefined);
      setMediaMode(false);
      setShowMasterActions(false);
      setChatTitle(""); // Reset chat title

      // Reset loading states
      setLoading({
        assistant: false,
        messages: false,
        workspaces: false,
      });
      setIsLoading(false);

      // Reset chat mode to standalone
      setChatMode(ChatMode.Standalone);
    }
  }, [clearChat]);

  // check for media

  useEffect(() => {
    if (scrollRef.current && chatData.length > 0) {
      // Only scroll for complete messages, not during streaming
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatData]);
  // check for new chat, show splash if so
  useEffect(() => {
    if (currentChat?.dataSourceIds && currentChat.dataSourceIds.length > 0) {
      setMediaMode(true);
      setSplash(false);
    } else {
      setMediaMode(false);
    }
  }, [currentChat, currentChat?.dataSourceIds, refreshChat]);

  // check mode chat was loaded into
  useMemo(() => {
    if (!agentId && !wsId) {
      setChatMode(ChatMode.Standalone);
    } else if (wsId && !agentId) {
      setChatMode(ChatMode.Workspace);
    } else if (agentID) {
      setChatMode(ChatMode.AgentFunction);
    } else {
      setChatMode(ChatMode.Agent);
    }
  }, [wsId, agentId, agentID]);

  // get agent and workspace details
  useEffect(() => {
    if (agentId) {
      AssistantService.getAssistant(agentId).then((res) => {
        setCurrentAgent(res);
        ModuleService.getModuleById(res.llmIds[0]).then((llmMod) => {
          if (llmMod && llmMod.specId === nvModuleSpecId) {
            setRtxOn(true);
          } else {
            setRtxOn(false);
          }
          setSelectedLlm(llmMod);
          setIsLoading(false); // Mark loading as complete
        });
      });
    }
    if (workflowId) {
      AgentWorkflowService.getAgentWorkflow(workflowId as string).then((response) => {
        setCurrentAgent(response);
        if (response?.rootAgent?.type === TypeName.Agent) {
          AgentService.getAgent(response?.rootAgent?.id).then((res) => {
            ModuleService.getModuleById(res.llmId).then((llmMod) => {
              if (llmMod && llmMod.specId === nvModuleSpecId) {
                setRtxOn(true);
              } else {
                setRtxOn(false);
              }
              setSelectedLlm(llmMod);
              setIsLoading(false); // Mark loading as complete
            });
          });
        }
        if (response?.rootAgent?.type === TypeName.Assistant) {
          AssistantService.getAssistant(response?.rootAgent?.id).then((res) => {
            ModuleService.getModuleById(res.llmIds[0]).then((llmMod) => {
              if (llmMod && llmMod.specId === nvModuleSpecId) {
                setRtxOn(true);
              } else {
                setRtxOn(false);
              }
              setSelectedLlm(llmMod);
              setIsLoading(false); // Mark loading as complete
            });
          });
        }
      });
    }
    if (wsId === "empty" || wsId === undefined || wsId === "undefined") {
      //for chat history "undefined" for favorite agent on home
    } else {
      WorkspaceService.getWorkspace(wsId).then(setCurrentWorkspace);
    }
    ConversationService.getConversations().then(setChats);
  }, [agentId, wsId, triggerUpdate, refreshChat, agentID, workflowId]);

  // Handlers

  const toggleActions = () => {
    setShowMasterActions(!showMasterActions);
  };
  const handleShowEditName = () => {
    setNewChatTitle(currentChat?.name as string);
    setEditTitle(true);
  };
  const handleRefresh = () => {
    console.debug("refreshing chat");
    setRefreshChat(!refreshChat);
  };

  const updateChatName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewChatTitle(e.target.value);
  };
  const handleNameChange = async () => {
    const payload = { ...currentChat, name: newChatTitle };
    ConversationService.updateConversation(payload as Conversation)
      .then((res) => {
        if (res.id) {
          setEditTitle(false);
          handleRefresh();
        }
      })
      .catch((err) => openErrorNotification(err?.message, err as Error));
  };

  const handleTriggerUpdate = useCallback(() => setTriggerUpdate((prev) => !prev), []);
  //data received from child
  const handleFormDirtyState = (dirtyState: boolean) => {
    setIsFormDirty(dirtyState);
  };

  //setrefresh chat
  useEffect(() => {
    if (currentChat) {
      ConversationService.getConversation(currentChat?.id as string)
        .then((res) => {
          setCurrentChat(res);
        })
        .catch((err) => openErrorNotification(err?.message, err as Error));
    }
    //this is needed to refresh chat data
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshChat]);

  // Render Conversation
  const RenderConvo = useMemo(
    () => (
      <MessageRenderer
        chatData={chatData}
        streamingContent={streamingContent}
        chatTitle={currentChat?.name || "New Chat"}
        userName={userDetails.firstName}
        botAvatar={currentAgent?.icon}
        isThumbsAvailable={isThumbsAvailable}
      />
    ),
    [chatData, currentAgent?.icon, currentChat?.name, isThumbsAvailable, streamingContent, userDetails.firstName]
  );

  // nVIDIA Stuff
  const updateSelectedAttachment = useCallback(async (selectedAttachment: React.SetStateAction<string | undefined>) => {
    setSelectedAttachment(selectedAttachment);
  }, []);

  // Submit user message
  const handleSubmit = useCallback(async () => {
    const controller = new AbortController();
    abortControllerRef.current = controller;
    try {
      setSplash(false);

      const messageParts: MessagePart[] = [];

      if (!userMessage.trim()) {
        if (documents.length > 0) {
          messageParts.push({
            content: DESCRIBE_SYSTEM_PROMPT,
            type: MessagePartType.TEXT,
          });
        } else {
          return;
        }
      }

      // Set splash to false IMMEDIATELY when starting submission,
      // before any network requests
      setSplash(false);
      setResponding(true);

      if (rtxOn && currentAgent) {
        // This is a VSS hack to set the video attachment storage on the agent
        if (currentAgent && "attachmentStorages" in currentAgent) {
          if (currentAgent?.__type_name === TypeName.Assistant) {
            await updateAgentWithAttachmentStorageForVss(currentAgent as Assistant);
          } else {
            const llmId =
              currentRootAgent && currentRootAgent?.__type_name === TypeName?.Assistant
                ? (currentRootAgent as Assistant)?.llmIds[0]
                : (currentRootAgent as Agent)?.llmId;
            await updateAgentWithAttachmentStorageForVss(currentAgent as AgentWorkflow, llmId);
          }
        }
      }

      // Only add text part if there's actual content
      if (userMessage.trim()) {
        messageParts.push({
          content: userMessage.trim(),
          type: MessagePartType.TEXT,
        });
      }

      // Process attachments if present
      if (rtxOn && selectedAttachment) {
        messageParts.push({
          content: selectedAttachment,
          type: MessagePartType.ATTACHMENT_REFERENCE,
        });
      }

      // Process documents before clearing them
      const documentsToProcess = [...documents]; // Create a copy to ensure we process all documents
      const fileProcessingPromises = documentsToProcess?.map((document) => {
        if (document instanceof AttachedFile) {
          return fileToBase64(document.file).then((base64) => {
            messageParts.push({
              content: base64,
              type: getMessagePartTypeFor(document.type),
            });
          });
        } else if (typeOf(document) === TypeName.Attachment) {
          messageParts.push({
            content: document.id,
            type: MessagePartType.ATTACHMENT_REFERENCE,
          });
          return Promise.resolve();
        } else {
          return Promise.resolve();
        }
      });

      // Wait for all file processing to complete before sending message
      await Promise.all(fileProcessingPromises);

      let activeConversation = currentChat;

      if (!activeConversation) {
        activeConversation =
          (await createChat(
            chatMode as string,
            currentAgent as Assistant,
            userMessage as string,
            selectedLlm?.id as string
          )) ?? null;

        setCurrentChat(activeConversation);
        handleTriggerUpdate();
      }

      if (activeConversation?.id) {
        setStreamingContent("");

        await ConversationService.sendUserMessage(
          activeConversation,
          messageParts,
          (chunk) => {
            messageAccumulatorRef.current += chunk;
            bufferRef.current += chunk;

            if (!isFlushingRef.current) {
              isFlushingRef.current = true;
              requestAnimationFrame(() => {
                const currentBuffer = bufferRef.current; // Clone the buffer to avoid mutation issues
                if (currentBuffer) {
                  setStreamingContent((prev) => prev + currentBuffer);
                  bufferRef.current = "";
                }
                isFlushingRef.current = false;
              });
            }
          },
          (message) => {
            if (bufferRef.current) {
              const currentBuffer = bufferRef.current;
              setStreamingContent((prev) => prev + currentBuffer);
              bufferRef.current = "";
            }
            setStreamingContent("");
            setChatData((prev) => [...prev, message]);
            messageAccumulatorRef.current = "";
          },
          (agentTool) => {
            setWorkflowConsole(
              (prevConsole) => [...prevConsole, agentTool] as WorkflowConsoleRendererProps[]
            );
          },
          controller.signal
        );

        // Only clear documents and message after successful processing
        setUserMessage("");
        setDocuments([]);
      }
    } catch (error: unknown) {
      if (
        typeof error === "object" &&
        error !== null &&
        "name" in error &&
        (error as { name?: string }).name === "AbortError"
      ) {
        setStreamingContent(""); //to avoid duplicates
        bufferRef.current = "";

        const contentToUse = cleanUpPartialRenderers(messageAccumulatorRef.current);

        if (contentToUse) {
          const message: Message = {
            conversationId: currentChat?.id ?? "",
            id: `${Date.now()}`, // Generate a temp ID
            overrides: [],
            parts: [
              {
                content: contentToUse,
                sequence: 0,
                type: MessagePartType.TEXT,
              },
            ],
            role: MessageRole.ASSISTANT,
            timestamp: "",
          };
          setChatData((prev) => [...prev, message]);
        }
        setUserMessage("");
        messageAccumulatorRef.current = "";
      } else {
        openErrorNotification(
          t(TranslationKeys.ERRORMESSAGES_SENDPROMPT),
          error instanceof Error ? error : new Error(String(error))
        );
      }
    } finally {
      setResponding(false);
      abortControllerRef.current = null;
    }
  }, [
    userMessage,
    rtxOn,
    currentAgent,
    selectedAttachment,
    documents,
    currentChat,
    currentRootAgent,
    chatMode,
    selectedLlm?.id,
    handleTriggerUpdate,
    setWorkflowConsole,
    openErrorNotification,
    t,
  ]);
  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);
  const cancelRequest = () => {
    abortControllerRef.current?.abort();
  };

  useEffect(() => {
    setDocuments([]); // Clear documents when LLM changes
  }, [selectedLlm]);

  const toggleAttachments = () => {
    setIsAttachmentOpen(!attachmentsMode);
    setAttachmentsMode(!attachmentsMode);
  };
  const memoizedConversationContext = React.useMemo(() => {
    return new ConversationContext(currentChat);
  }, [currentChat]);

  // Calculate if prompt suggestions are present (same logic as UserPromptForm)
  const showPromptSuggestions =
    (currentRootAgent?.__type_name === TypeName.Assistant &&
      Array.isArray((currentRootAgent as Assistant).sampleQuestions) &&
      (currentRootAgent as Assistant).sampleQuestions.length > 0) ||
    (Array.isArray((currentAgent as Assistant)?.sampleQuestions) &&
      (currentAgent as Assistant).sampleQuestions.length > 0);

  return (
    <>
      {chatMode != "standalone" ? (
        <div
          style={{
            transition: "width 0.3 ease",
            width: attachmentsMode ? "70%" : "100%",
          }}
        >
          <Breadcrumbs
            currentWorkspace={currentWorkspace as Workspace}
            currentChat={currentChat ?? null}
            handleShowEditName={handleShowEditName}
            currentAgent={currentAgent as Assistant}
          />
        </div>
      ) : null}
      <div className="d-flex flex-row w-75">
        {(currentChat?.dataSourceIds?.length ?? 0 > 0) ? (
          <>
            <Button variant="transparent" onClick={() => setMediaMode(!mediaMode)} style={{ paddingBottom: "0.6em" }}>
              {mediaMode ? (
                <i className="bi bi-arrows-collapse-vertical"></i>
              ) : (
                <i className="bi bi-arrows-expand-vertical"></i>
              )}
            </Button>
          </>
        ) : null}
      </div>

      {/* Attachments Toggler */}

      <div
        className="chat-parent"
        style={{
          width: attachmentsMode ? "60%" : "100%",
        }}
      >
        {(currentChat?.dataSourceIds?.length ?? 0 > 0) ? (
          <div className={`media-container ${mediaMode ? "expanded" : ""}`}>
            <FileCarousel conversation={currentChat} rtxOn={rtxOn} setSelectedAttachment={updateSelectedAttachment} />
          </div>
        ) : null}

        <div className="chat-container" id="chat-container" style={{ position: "relative" }}>
          <AnimatePresence mode="wait">
            {/* Show welcome screen for both new chats AND when loading an existing conversation */}
            {(!conversationId || !chatData.length) && splash ? (
              <motion.div
                initial={{ opacity: 1 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                style={{
                  height: "100%",
                  left: 0,
                  position: "absolute",
                  top: 0,
                  width: "100%",
                  zIndex: 2,
                }}
              >
                <div className="d-flex justify-content-center align-items-center flex-column">
                  <p className="gradient-text" style={{ fontSize: "40px", lineHeight: "40px", marginBottom: "1rem" }}>
                    {t(TranslationKeys.CHAT_WELCOME, { name: userDetails.firstName })}
                  </p>
                  <div className="text-light text-center" style={{ fontSize: "24px", lineHeight: "24px" }}>
                    {loading.assistant || isLoading ? (
                      <span className="greeting-loading d-flex align-items-center justify-content-center pt-4">
                        <Spinner animation="border" variant="light" className="me-2" />
                      </span>
                    ) : rtxOn && chatMode !== "standalone" ? (
                      t(TranslationKeys.CHAT_STARTBYUPLOADINGVIDEO)
                    ) : chatMode === ChatMode.SuperAgent && currentRootAgent?.__type_name === TypeName.Assistant ? (
                      (currentRootAgent as Assistant)?.greetingMessage || t(TranslationKeys.CHAT_HOWCANIHELP)
                    ) : chatMode === "standalone" ? (
                      t(TranslationKeys.CHAT_HOWCANIHELP)
                    ) : (
                      (currentAgent as Assistant)?.greetingMessage || t(TranslationKeys.CHAT_HOWCANIHELP)
                    )}
                  </div>

                  {chatMode === "standalone" && (
                    <div
                      style={{
                        alignItems: "center",
                        display: "flex",
                        justifyContent: "center",
                        marginTop: "1.5rem",
                        minHeight: "200px",
                        width: "100%",
                      }}
                    >
                      {loading.workspaces || loading.assistant || isLoading ? (
                        <CardSkeleton />
                      ) : (
                        <FavouritesRenderer
                          reloadTrigger={triggerUpdate}
                          launchControl={launchAgent}
                          handleTriggerUpdate={handleTriggerUpdate}
                        />
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            ) : null}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            {!splash && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5 }}
                style={{
                  position: "absolute",
                  ...(showMasterActions == false ? { height: "100%" } : {}),
                  left: 0,
                  overflowY: showMasterActions == true ? "scroll" : "hidden",
                  top: 0,
                  width: "100%",
                  zIndex: 1,
                }}
              >
                <div
                  style={
                    !mediaMode
                      ? {
                        display: "flex",
                        justifyContent: "center",
                        marginLeft: "-2em",
                        width: "100%",
                      }
                      : undefined
                  }
                >
                  <AnimatePresence mode="wait">
                    {!splash && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.5 }}
                        style={
                          mediaMode
                            ? undefined
                            : {
                              width: "75%",
                            }
                        }
                      >
                        {!splash ? (
                          <div className="sticky-header">
                            <div className="d-flex flex-row ps-2">
                              <div className="start-conversation-dot rounded-circle" />
                              <div className="conversation-line-connector" />
                              {!clearChat && (
                                <span className="chat-title">
                                  {chatTitle || t(TranslationKeys.CHAT_CURRENTSESSION)}
                                  <Button
                                    style={{ borderColor: "transparent" }}
                                    variant="transparent"
                                    size="sm"
                                    className="mb-1"
                                    onClick={() => setShowInference(isLineageAvailable)}
                                    disabled={!isLineageAvailable}
                                  >
                                    <i
                                      className={`bi ${SHIELD_CONFIG[String(isGovernanceCompliant)].icon} ps-2`}
                                      style={{ color: SHIELD_CONFIG[String(isGovernanceCompliant)].color }}
                                    ></i>
                                  </Button>
                                  {isThumbsAvailable ? <>{[1, 0, -1].map((value) => thumbButton(value))}</> : null}
                                </span>
                              )}
                            </div>
                          </div>
                        ) : null}
                        {loading && loading.messages ? (
                          <div className="mt-3 ms-1 d-flex align-items-center justify-content-center">
                            <CardSkeleton />
                          </div>
                        ) : (
                          <div
                            className={`pt-2 scrollable-content ${showMasterActions ? "expanded" : ""}`}
                            ref={scrollRef}
                            style={{
                              // Dynamic height for collapsed: subtract more if prompt suggestions are present
                              height: `calc(100vh - ${showPromptSuggestions ? "23rem" : "20rem"})`,
                            }}
                          >
                            <div>{RenderConvo}</div>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <AnimatePresence>
                  {chatData.length > 5 && showMasterActions && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 1.5 }}
                    >
                      <Collapse in={showMasterActions}>
                        <div className={`d-flex w-100 ${!mediaMode ? "justify-content-center" : ""}`}>
                          <div
                            className={`actions-panel ${showMasterActions ? "expanded" : "collapsed"}`}
                            style={
                              !mediaMode
                                ? {
                                  marginRight: "4em",
                                  width: "75%",
                                }
                                : undefined
                            }
                          >
                            <MasterActions
                              actionsPanelExportProps={{
                                currentAgentName: currentAgent?.name ?? i18n.t(TranslationKeys.NEWCHAT_UNNAMEDAGENT),
                                currentChatName: currentChat?.name ?? i18n.t(TranslationKeys.NEWCHAT_UNNAMEDCHAT),
                                username: userDetails?.firstName ?? i18n.t(TranslationKeys.NEWCHAT_UNNAMEDUSER),
                              }}
                            />
                          </div>
                        </div>
                      </Collapse>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
      <div
        className={`chat-input d-flex ${mediaMode ? "slide-start" : "slide-center"
          } d-flex flex-column justify-content-center`}
      >
        {chatMode === "standalone" ? (
          <div
            className="d-flex"
            style={{
              transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
              width: "80%",
            }}
          >
            <div style={{ marginLeft: "auto" }}>
              <ModuleDropdown
                name="aiModel"
                options={llms as Module[]}
                value={selectedLlm?.id}
                onChange={(id) => {
                  const chosenLlm = llms?.find((el) => el.id === id);
                  setSelectedLlm(chosenLlm);
                }}
                className={`d-flex ${mediaMode ? "slide-start" : "slide-center"
                  } mb-1 position-relative module-dropdown-custom`}
              />
            </div>
          </div>
        ) : null}
        <div
          className="d-flex justify-content-center"
          style={{
            flexShrink: 1,
            marginLeft: "auto",
            marginRight: "auto",
            overflowX: "auto",
            scrollbarWidth: "none",
            width: "80%",
            paddingRight: "3em",
          }}
        >
          {loading.assistant ||
            loading.workspaces ||
            // Only show loading in standalone mode during initial load, not when viewing history
            (isLoading && chatMode !== ChatMode.Standalone) ||
            // Only require an agent in non-standalone modes
            (!currentAgent && chatMode !== ChatMode.Standalone && chatMode !== undefined) ? (
            <div
              className="input-placeholder d-flex justify-content-center align-items-center"
              style={{
                background: "rgba(50, 50, 50, 0.4)",
                borderRadius: "8px",
                height: "56px",
                padding: "0 16px",
                width: "50%",
              }}
            >
              <Spinner animation="border" variant="light" size="sm" className="me-2" />
              <span className="text-light">{t(TranslationKeys.CHAT_LOADINGCHATINTERFACE)}</span>
            </div>
          ) : (
            <UserPromptForm
              key={selectedLlm?.id}
              openChatOverLay={openChatOverLay}
              openDetailsOverLay={openDetailsOverLay}
              chatData={chatData}
              currentAgent={currentAgent as Assistant}
              userMessage={userMessage}
              updateUserMessage={updateUserMessage}
              responding={responding}
              handleSubmit={handleSubmit}
              setCurrentChat={updateCurrentChat}
              currentChat={currentChat as Conversation}
              refreshChat={handleRefresh}
              rtxOn={rtxOn}
              userMessageSetter={(msg) => {
                setUserMessage(msg);
              }}
              toggleActions={toggleActions}
              toggleAttachments={toggleAttachments}
              documents={documents}
              documentHandler={(docs) => {
                setDocuments(docs);
              }}
              selectedLlm={selectedLlm}
              isMasterActionOpen={showMasterActions}
              attachmentsMode={attachmentsMode}
              currentRootAgent={currentRootAgent}
              chatMode={chatMode}
              onCancel={cancelRequest}
            />
          )}
        </div>
      </div>

      {/* ATTACHMENTS CANVAS */}
      <Offcanvas
        show={attachmentsMode}
        onHide={() => {
          setAttachmentsMode(!attachmentsMode);
          setIsAttachmentOpen(!attachmentsMode);
        }}
        placement="end"
        backdrop={false}
        enforceFocus={false}
        style={{
          background: `linear-gradient(
      135deg,
      var(--bg-stop) 50%,
      color-mix(in srgb, var(--bg-stop) 80%, var(--primary-color)) 100%
    )`,
          zIndex: 2050,
        }}
      >
        <Offcanvas.Header closeButton style={{ paddingBottom: "0em", paddingTop: "0.7rem" }}></Offcanvas.Header>
        <Offcanvas.Body>
          <AssistantSidebar
            assistant={currentAgent as Assistant | AgentWorkflow}
            conversationContext={memoizedConversationContext}
            documentHandler={(docs) => {
              setDocuments(docs);
            }}
            documents={documents}
          />
        </Offcanvas.Body>
      </Offcanvas>

      {/* OVERLAYS */}
      <ChatCanvas
        title={t(TranslationKeys.CHAT_CONVERSATIONHISTORY)}
        showChats={() => showChats}
        closeChatOverlay={closeChatOverlay}
        chats={chats as Conversation[]}
        handleTriggerUpdate={handleTriggerUpdate}
        launchExistingChat={launchExistingChat}
        showDetails={() => showDetails}
        closeDetailsOverlay={closeDetailsOverlay}
        currentAgent={currentAgent as Assistant}
        currentChat={currentChat as Conversation}
      />
      {/* MODALS */}

      {/* Edit Title */}
      <Modal
        size="sm"
        show={editTitle}
        onHide={() => setEditTitle(false)}
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
      >
        <Modal.Body>
          <Form>
            <Form.Label>{t(TranslationKeys.CHAT_RENAMECHAT)}</Form.Label>
            <Form.Control type="text" value={newChatTitle} onChange={updateChatName} />
            <div className="text-end pt-2">
              <Button onClick={handleNameChange}>{t(TranslationKeys.CHAT_SAVE)}</Button>
            </div>
          </Form>
        </Modal.Body>
      </Modal>
      {/* Inference Modal */}
      <Modal
        fullscreen
        show={showInference}
        onHide={() => setShowInference(false)}
        centered
        className="text-light eqty-modal custom-modal-backdrop"
      >
        <Modal.Header closeButton>{/* <Modal.Title>EQTY Compliance Grid</Modal.Title> */}</Modal.Header>
        <Modal.Body>
          <AgentInference
            agent={currentAgent as Assistant}
            messages={chatData}
            conversation={currentChat as Conversation}
          />
        </Modal.Body>
      </Modal>
      {/* attachment mode edit agent form */}
      <Modal
        show={openForm}
        onHide={() => {
          if (isFormDirty) {
            // Show confirmation popup if form is dirty
            setIsConfirmClose(true);
          } else {
            setOpenForm(false);
            setAgentData(undefined);
          }
        }}
        backdrop="static"
        size="xl"
        centered
        className="text-light custom-modal-backdrop"
      >
        <Modal.Header closeButton>
          <Modal.Title>{`${agentData?.name}`}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {agentData?.__type_name === TypeName.Assistant && (
            <NewAgentForm
              initialData={agentData as Assistant}
              handleClose={() => setOpenForm(false)}
              updateTrigger={() => {
                setAttachmentsMode(false);
                setTriggerUpdate(!triggerUpdate);
              }}
              onUpdateAgentFormDirty={handleFormDirtyState}
              onUpdateAgentDirtyData={(data: AgentDirtyFields) => handleAgentDirtyDataTitles(data, setDirtyFields)}
            />
          )}
        </Modal.Body>
      </Modal>
      {agentData?.__type_name === TypeName.AgentWorkflow && (
        <AgentWorkflowForm
          show={openForm}
          onHide={() => {
            setAgentData(undefined);
            setOpenForm(false);
          }}
          initialData={agentData as AgentWorkflow}
          handleClose={() => setOpenForm(false)}
          updateTrigger={() => {
            setAttachmentsMode(false);
            setTriggerUpdate(!triggerUpdate);
          }}
        />
      )}
      {isConfirmClose && (
        <ConfirmUnsavedModal
          isConfirmClose={isConfirmClose}
          dirtyFields={dirtyFields}
          setIsConfirmClose={setIsConfirmClose}
          setShowEdit={setOpenForm}
        />
      )}
    </>
  );
}
