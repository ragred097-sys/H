import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Mock, vi } from "vitest";

import { BrowserRouter, MemoryRouter, Route, Routes } from "react-router-dom";

import { PermissionType, TypeName } from "../../../lib/Model";
import { GovernanceService } from "../../../services/GovernanceService";
import { createChat } from "../../../utils/crudUtils";
import { NotificationProvider } from "../../general/NotificationProvider";
import * as NotificationModule from "../../general/NotificationProvider";
import { AgentWorkflowService } from "./../../../services/AgentWorkflowService";
import { AssistantService } from "./../../../services/AssistantService";
import { ConversationService } from "./../../../services/ConversationService";
import { ModuleService } from "./../../../services/ModuleService";
import { WorkspaceService } from "./../../../services/WorkspaceService";
import Chat from "./NewChat";

vi.mock("../../../lib/Backend");
vi.mock("../../../services/ConversationService", () => ({
  ConversationService: {
    getConversations: vi.fn(),
    sendUserMessage: vi.fn(),
  },
}));

vi.mock("react-oidc-context", () => ({
  useAuth: () => ({
    user: {
      profile: {
        email: "test@example.com",
        family_name: "User",
        given_name: "Test",
        name: "Test User",
      },
    },
  }),
}));

vi.mock("../../../utils/crudUtils", () => ({
  createChat: vi.fn(),
}));

vi.mock("react-oidc-context", () => ({
  useAuth: () => ({
    user: {
      profile: {
        email: "test@example.com",
        family_name: "User",
        given_name: "Test",
        name: "Test User",
      },
    },
  }),
}));

vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    t: (key: string) => key,
  }),
}));

const mockSuperAgent = {
  __type_name: "AgentWorkflow",
  accessPermission: PermissionType.WRITE,
  agents: [
    {
      id: "agent-1",
      type: TypeName.Assistant as const,
    },
    {
      id: "another-agent-id",
      type: TypeName.Assistant as const,
    },
  ],
  attachmentStorages: [],
  createdAt: "2025-05-30T06:56:22.935361",
  creator: {
    __type_name: "User",
    id: "userId-1",
    name: "ishika chandwadkar",
  },
  description: "test-super-agent",
  favorite: false,
  hidden: false,
  icon: "",
  id: "superagent-1",
  image: "",
  modifiedAt: "2025-06-17T06:44:45.241522",
  modifier: {
    __type_name: "User",
    id: "userId-1",
    name: "ishika chandwadkar",
  },
  name: "test-super-agent",
  rootAgent: {
    id: "agent-1",
    type: TypeName.Assistant as const,
  },
  tags: [],
};

const mockModules = [
  { id: "1", name: "GPT4.1 on Azure (AIP-HPS)", supportedInputs: [] },
  { id: "2", name: "gemini-2.0-flash", supportedInputs: ["TEXT"] },
  { id: "3", name: "NVIDIA - llama-3.1-nemotron-70b-instruct #2", supportedInputs: ["IMAGE", "TEXT"] },
];

const mockAgent = {
  __type_name: "Assistant",
  accessPermission: PermissionType.WRITE,
  attachmentStorages: [],
  createdAt: "2025-01-01T00:00:00Z",
  creator: { __type_name: "User", id: "user-1", name: "Test User" },
  customSystemInstruction: "",
  dataSourceIds: [],
  description: "Test Agent Description",
  favorite: false,
  greetingMessage: undefined,
  hidden: false,
  icon: "icon.png",
  id: "agent-1",
  image: "",
  llmIds: ["1"],
  modifiedAt: "2025-01-01T00:00:00Z",
  modifier: { __type_name: "User", id: "user-1", name: "Test User" },
  name: "Test Agent",
  sampleQuestions: [],
  systemInstructionIds: [],
  tags: [],
};

const mockAgentWithGreeting = {
  ...mockAgent,
  greetingMessage: "Hello from the agent!",
  id: "agent-2",
  name: "Test Agent 2",
};

const mockModel123 = {
  __type_name: "Module",
  createdAt: "2025-01-01T00:00:00Z",
  creator: { __type_name: "User", id: "user-1", name: "Test User" },
  default: false,
  favorite: false,
  id: "1",
  modifiedAt: "2025-01-01T00:00:00Z",
  modifier: { __type_name: "User", id: "user-1", name: "Test User" },
  name: "GPT4.1 on Azure (AIP-HPS)",
  parameters: [],
  specId: "spec-123",
  supportedInputs: [],
  tags: [],
};

const mockWorkspace = {
  __type_name: "Workspace",
  accessPermission: PermissionType.WRITE,
  createdAt: "2025-01-01T00:00:00Z",
  creator: { __type_name: "User", id: "user-1", name: "Test User" },
  favorite: false,
  hidden: false,
  icon: "",
  id: "ws-1",
  image: "",
  modifiedAt: "2025-01-01T00:00:00Z",
  modifier: { __type_name: "User", id: "user-1", name: "Test User" },
  name: "Workspace",
  tags: [],
};
const mockWorkspace2 = {
  __type_name: "Workspace",
  accessPermission: PermissionType.WRITE,
  createdAt: "2025-01-01T00:00:00Z",
  creator: { __type_name: "User", id: "user-1", name: "Test User" },
  favorite: false,
  hidden: false,
  icon: "",
  id: "ws-2",
  image: "",
  modifiedAt: "2025-01-01T00:00:00Z",
  modifier: { __type_name: "User", id: "user-1", name: "Test User" },
  name: "Workspace",
  tags: [],
};

const mockCreateChat = (id: string, llmIds: string[], userId = "user-1") => ({
  createdAt: new Date().toISOString(),
  creator: { id: userId, name: "Test User" },
  id,
  llmIds,
  name: "Test Chat",
  tags: [],
});

beforeAll(() => {
  Object.defineProperty(window, "matchMedia", {
    value: vi.fn().mockImplementation((query) => ({
      addEventListener: vi.fn(),
      addListener: vi.fn(),
      dispatchEvent: vi.fn(),
      matches: false,
      media: query,
      onchange: null,
      removeEventListener: vi.fn(),
      removeListener: vi.fn(),
    })),
    writable: true,
  });
});

describe("Chat Component", () => {
  let mockOpenErrorNotification: Mock;

  beforeEach(() => {
    vi.clearAllMocks();

    vi.spyOn(ModuleService, "getModulesByType").mockResolvedValue([]);
    vi.spyOn(ConversationService, "getConversations").mockResolvedValue([]);
    vi.spyOn(GovernanceService, "isAgenticGovernanceCompliant").mockResolvedValue(true);
    vi.spyOn(GovernanceService, "isAgenticThumbsConfigured").mockResolvedValue(true);
    vi.spyOn(AgentWorkflowService, "getAgentWorkflow").mockResolvedValue(mockSuperAgent);
    vi.spyOn(AssistantService, "getAssistant").mockResolvedValue(mockAgent);
    vi.spyOn(WorkspaceService, "getWorkspace").mockResolvedValue(mockWorkspace);
    vi.spyOn(ModuleService, "getModuleById").mockResolvedValue(mockModel123);

    mockOpenErrorNotification = vi.fn();
    vi.spyOn(NotificationModule, "useNotification").mockReturnValue({
      closeNotification: vi.fn(),
      openErrorNotification: mockOpenErrorNotification,
      openNotification: vi.fn(),
    });
  });

  it("renders welcome message in standalone mode", async () => {
    render(
      <NotificationProvider>
        <MemoryRouter>
          <Chat clearChat={true} />
        </MemoryRouter>
      </NotificationProvider>
    );

    await waitFor(() => {
      expect(screen.getByText("chat.welcome")).toBeInTheDocument();
    });
  });

  it("renders the greeting message in standalone mode", async () => {
    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByText("chat.howCanIhelp")).toBeInTheDocument();
    });
  });

  it("renders LLM dropdown in standalone mode with default 'gpt' selected", async () => {
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue(mockModules);

    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByRole("combobox")).toBeInTheDocument();
    });

    const select = screen.getByRole("combobox") as HTMLSelectElement;
    expect(select.value).toBe("1");
    const options = screen.getAllByRole("option").map((opt) => opt.textContent);
    expect(options).toContain("GPT4.1 on Azure (AIP-HPS)");
    expect(options).toContain("gemini-2.0-flash");
    expect(options).toContain("NVIDIA - llama-3.1-nemotron-70b-instruct #2");
  });

  it("allows selecting a different LLM in standalone mode and calls handleSelectlm", async () => {
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue(mockModules);
    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByRole("combobox")).toBeInTheDocument();
    });

    const select = screen.getByRole("combobox") as HTMLSelectElement;
    expect(select.value).toBe("1");

    await act(async () => {
      select.value = "2";
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });

    expect(select.value).toBe("2");
  });

  it("disables the LLM model select dropdown after user sends a message in standalone mode", async () => {
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue(mockModules);

    (ConversationService.sendUserMessage as unknown as Mock).mockImplementation(
      async (_conversation, _messageParts, _onChunk, onMessage) => {
        onMessage({
          conversationId: "conv-1",
          id: "msg-1",
          parts: [{ content: "hello", sequence: 0, type: "TEXT" }],
          role: "USER",
        });
        return;
      }
    );
    (createChat as Mock).mockResolvedValue(mockCreateChat("conv-1", ["1"]));

    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByRole("combobox")).toBeInTheDocument();
    });

    const textbox = screen.getByRole("textbox");
    fireEvent.change(textbox, { target: { value: "hello" } });

    const form = textbox.closest("form");
    if (form) {
      fireEvent.submit(form);
    } else {
      const sendButton = screen.getByRole("button", { name: "" });
      fireEvent.click(sendButton);
    }

    await waitFor(() => {
      const select = screen.getByRole("combobox");
      expect(select).toBeDisabled();
    });
  });

  it("should NOT render loading spinner when isLoading is true and chatMode is Standalone", async () => {
    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    expect(screen.queryByRole("status")).not.toBeInTheDocument();
    expect(screen.queryByText(/loading/i)).not.toBeInTheDocument();
  });

  it("renders the UserPromptForm component", async () => {
    await act(async () => {
      render(
        <BrowserRouter>
          <Chat clearChat={true} />
        </BrowserRouter>
      );
    });

    expect(screen.getByRole("textbox")).toBeInTheDocument();
  });

  it("renders welcome message and greeting when launching an agent", async () => {
    (AssistantService.getAssistant as unknown as Mock).mockResolvedValue(mockAgent);
    (ModuleService.getModuleById as unknown as Mock).mockResolvedValue(mockModel123);
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue([
      { id: "1", name: "GPT4.1 on Azure (AIP-HPS)", supportedInputs: [] },
    ]);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue(mockWorkspace);

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-1/agent-1"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/:agentId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByText("chat.welcome")).toBeInTheDocument();
      expect(screen.getByText("chat.howCanIhelp")).toBeInTheDocument();
    });
  });

  it("renders custom greeting message if agent provides one when launching an agent", async () => {
    (AssistantService.getAssistant as unknown as Mock).mockResolvedValue(mockAgentWithGreeting);
    (ModuleService.getModuleById as unknown as Mock).mockResolvedValue(mockModel123);
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue([
      { id: "1", name: "GPT4.1 on Azure (AIP-HPS)", supportedInputs: [] },
    ]);
    (ConversationService.getConversations as unknown as Mock).mockResolvedValue([]);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue(mockWorkspace2);

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-1/agent-1"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/:agentId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByText("chat.welcome")).toBeInTheDocument();
      expect(screen.getByText("Hello from the agent!")).toBeInTheDocument();
    });
  });

  it("renders loading spinner and loading text in chat input when loading is true and not in standalone mode", async () => {
    (AssistantService.getAssistant as unknown as Mock).mockImplementation(
      () =>
        new Promise((resolve) => {
          setTimeout(() => {
            resolve({
              __type_name: "Assistant",
              greetingMessage: undefined,
              icon: "icon.png",
              id: "agent-1",
              llmIds: ["1"],
              name: "Test Agent",
              sampleQuestions: [],
            });
          }, 100);
        })
    );
    (ModuleService.getModuleById as unknown as Mock).mockResolvedValue(mockModel123);
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue([
      { id: "1", name: "GPT4.1 on Azure (AIP-HPS)", supportedInputs: [] },
    ]);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue({ id: "ws-1", name: "Workspace" });

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-1/agent-1"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/:agentId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    expect(document.querySelector(".spinner-border")).toBeInTheDocument();
    const loadingText = screen.getByText("chat.loadingChatInterface");
    expect(loadingText).toHaveClass("text-light");
  });

  it("selects the correct LLM model for the agent when launching an agent chat", async () => {
    (AssistantService.getAssistant as unknown as Mock).mockResolvedValue({
      __type_name: "Assistant",
      greetingMessage: undefined,
      icon: "icon.png",
      id: "agent-3",
      llmIds: ["model-123"],
      name: "Agent With Model",
      sampleQuestions: [],
    });
    (ModuleService.getModuleById as unknown as Mock).mockResolvedValue({
      id: "model-123",
      name: "Test Model",
      specId: "spec-123",
      supportedInputs: [],
    });
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue([
      { id: "model-123", name: "Test Model", supportedInputs: [] },
      { id: "model-456", name: "Other Model", supportedInputs: [] },
    ]);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue({ id: "ws-3", name: "Workspace" });

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-3/agent-3"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/:agentId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByRole("textbox")).toBeInTheDocument();
    });

    const textbox = screen.getByRole("textbox");
    fireEvent.change(textbox, { target: { value: "Hello agent" } });

    (ConversationService.sendUserMessage as unknown as Mock).mockImplementation(
      async (_conversation, _messageParts, _onChunk, onMessage) => {
        onMessage({
          conversationId: "conv-2",
          id: "msg-2",
          parts: [{ content: "Hello agent", sequence: 0, type: "TEXT" }],
          role: "USER",
        });
        return;
      }
    );
    (createChat as Mock).mockResolvedValue(mockCreateChat("conv-2", ["model-123"]));

    const form = textbox.closest("form");
    if (form) {
      fireEvent.submit(form);
    }

    await waitFor(() => {
      expect(screen.getByText("Hello agent")).toBeInTheDocument();
    });

    expect(ModuleService.getModuleById).toHaveBeenCalledWith("model-123");
  });

  it("renders welcome message and greeting when launching a super agent (AgentWorkflow)", async () => {
    (AgentWorkflowService.getAgentWorkflow as unknown as Mock).mockResolvedValue(mockSuperAgent);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue({ id: "ws-1", name: "Workspace" });
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue(mockModules);
    (AssistantService.getAssistant as unknown as Mock).mockResolvedValue(mockAgent);

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-1/workflow/b25bc059-d2c3-4474-a2b1-c62356b7d1ee"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/workflow/:workflowId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByText("chat.welcome")).toBeInTheDocument();
      expect(screen.getByText("chat.howCanIhelp")).toBeInTheDocument();
    });
  });

  it("renders custom greeting message if super agent (AgentWorkflow) provides one when launching a super agent", async () => {
    (AgentWorkflowService.getAgentWorkflow as unknown as Mock).mockResolvedValue(mockSuperAgent);
    (WorkspaceService.getWorkspace as unknown as Mock).mockResolvedValue({ id: "ws-1", name: "Workspace" });
    (ModuleService.getModulesByType as unknown as Mock).mockResolvedValue(mockModules);
    (AssistantService.getAssistant as unknown as Mock).mockResolvedValue(mockAgentWithGreeting);

    await act(async () => {
      render(
        <MemoryRouter initialEntries={["/workspace/ws-1/workflow/9ed8cb73-54a7-481b-8bb9-411ed237d4e3"]}>
          <Routes>
            <Route path="/workspace/:workspaceId/workflow/:workflowId" element={<Chat clearChat={false} />} />
          </Routes>
        </MemoryRouter>
      );
    });

    await waitFor(() => {
      expect(screen.getByText("chat.welcome")).toBeInTheDocument();
      expect(screen.getByText("Hello from the agent!")).toBeInTheDocument();
    });
  });
});
