import React from "react";

import { OverlayTrigger, Tooltip } from "react-bootstrap";

import { AttachedFile } from "./AttachedFile.ts";
import { fileToBase64 } from "../../utils/fileUtils";

interface AttachedFilePreviewProps {
  attachedFile: AttachedFile;
}

export const AttachedFilePreview: React.FC<AttachedFilePreviewProps> = ({ attachedFile }) => {
  const [base64Src, setBase64Src] = React.useState<string | null>(null);

  React.useEffect(() => {
    fileToBase64(attachedFile.file).then((base64) => setBase64Src(base64));
  }, [attachedFile]);

  return (
    <OverlayTrigger
      placement="top-end"
      delay={{ hide: 500, show: 750 }}
      overlay={<Tooltip style={{ zIndex: 3000 }}>{attachedFile.name}</Tooltip>}
    >
      <img
        src={base64Src || ""}
        alt={attachedFile.name}
        style={{
          height: "100%",
          objectFit: "contain",
          width: "100%",
        }}
      />
    </OverlayTrigger>
  );
};
