import { v4 as uuidv4 } from "uuid";

import i18n from "../../i18n";
import { Attachment, AttachmentContext, Conversation, DocumentType, Named } from "../../lib/Model.ts";
import { ConversationService } from "../../services/ConversationService.ts";
import { TranslationKeys } from "../../types/translation-keys";
import { determineDocumentType } from "../../utils/fileUtils";

export class UploadingAttachment implements Named {
  public id: string = uuidv4();
  public name: string;
  public size: number;
  public file: File;
  public type: DocumentType;

  public storeAsAttachment: boolean;

  // only used, when storing as attachment
  public uploading: boolean;
  public error: Error | null = null;

  constructor(
    conversation: Conversation,
    attachmentContext: AttachmentContext,
    file: File,
    onSuccess: (id: string, attachment: Attachment) => void,
    onError: (id: string, error: Error) => void
  ) {
    this.uploading = true;
    this.name = file.name;
    this.size = file.size;
    this.file = file;
    const documentType = determineDocumentType(file);

    if (!documentType) {
      throw new Error(i18n.t(TranslationKeys.ERRORMESSAGES_UNSUPPORTEDFILE, { fileName: file.name, type: file.type }));
    }
    this.type = documentType;

    // check if we have a storage configured for the given mime-type
    this.storeAsAttachment =
      attachmentContext.attachmentStorages.some((storage) => storage.type.valueOf() === this.type.valueOf()) || false;

    if (this.storeAsAttachment) {
      ConversationService.createConversationAttachment(conversation, file)
        .then((attachment) => {
          this.uploading = false;
          onSuccess(this.id, attachment);
        })
        .catch((error: Error) => {
          this.uploading = false;
          this.error = error;
          onError(this.id, error);
        });
    } else {
      throw new Error(i18n.t(TranslationKeys.ERRORMESSAGES_UNSUPPORTEDFILE, { fileName: file.name, type: file.type }));
    }
  }
}
