import React from "react";

import { AttachmentGallery } from "./AttachmentGallery";
import { ConversationContext } from "./ConversationContext";
import { AgentWorkflow, Assistant, Attachment, AttachmentContext } from "../../lib/Model";
import { AttachedFile } from "../general/AttachedFile";

function AssistantSidebar({
  assistant,
  conversationContext,
  documentHandler,
  documents,
}: {
  assistant: Assistant | AgentWorkflow;
  conversationContext: ConversationContext;
  documentHandler: (docs: (Attachment | AttachedFile)[]) => void;
  documents: (Attachment | AttachedFile)[];
}) {
  return (
    <div
      style={{
        overflowY: "scroll",
      }}
    >
      <>
        <React.Fragment>
          <>
            <AttachmentGallery
              conversationContext={conversationContext}
              attachmentContext={assistant as AttachmentContext}
              documentHandler={documentHandler}
              documents={documents}
            />
          </>
        </React.Fragment>
      </>
    </div>
  );
}
export default AssistantSidebar;
