import { Offcanvas } from "react-bootstrap";

import { ChatHistory } from "./ChatHistoryList";
import { Assistant, Conversation } from "../../lib/Model";
import AgentDetail from "../general/AgentDetail";

export const ChatCanvas = ({
  chats,
  closeChatOverlay,
  closeDetailsOverlay,
  currentAgent,
  currentChat,
  handleTriggerUpdate,
  launchExistingChat,
  showChats,
  showDetails,
  title,
}: {
  title: string;
  showChats: () => void;
  closeChatOverlay: () => void;
  chats: Conversation[];
  handleTriggerUpdate: () => void;
  launchExistingChat: (chat: Conversation) => void;
  showDetails: () => void;
  closeDetailsOverlay: () => void;
  currentAgent: Assistant;
  currentChat: Conversation;
}) => {
  return (
    <>
      <div>
        <Offcanvas
          show={showChats}
          onHide={closeChatOverlay}
          placement="end"
          className="text-light"
          style={{
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            width: "33%",
            zIndex: 1055,
          }}
        >
          <Offcanvas.Header closeButton>
            <Offcanvas.Title>{title}</Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            <ChatHistory
              chats={chats}
              currentAgent={currentAgent}
              triggerUpdate={handleTriggerUpdate}
              onLaunchChat={(chat) => {
                launchExistingChat(chat);
              }}
            />
          </Offcanvas.Body>
        </Offcanvas>
        <Offcanvas
          show={showDetails}
          onHide={closeDetailsOverlay}
          placement="end"
          className="text-light w-50"
          style={{ backgroundColor: "rgba(0, 0, 0, 0.8)", zIndex: 1056 }}
        >
          <Offcanvas.Header closeButton>
            <Offcanvas.Title>Agent Details</Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            {currentAgent !== null && currentAgent !== undefined ? (
              <AgentDetail data={currentAgent} conversation={currentChat} />
            ) : (
              <div className="text-center text-muted">No agent details available</div>
            )}
          </Offcanvas.Body>
        </Offcanvas>
      </div>
    </>
  );
};
