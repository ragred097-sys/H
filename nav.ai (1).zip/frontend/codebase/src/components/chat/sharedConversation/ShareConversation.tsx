import { useEffect, useState } from "react";

import { Button, Form, InputGroup, Modal, Spinner } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";

import { ShareConversationState, SharedConversation } from "../../../lib/Model";
import { TranslationKeys } from "../../../types/translation-keys";
import { getSharedURL } from "../../../utils/stringUtils";
import { useNotification } from "../../general/NotificationProvider";
import { ConversationService } from "./../../../services/ConversationService";

interface ShareConversationProps {
  show: boolean;
  handleClose: () => void;
  conversationId: string;
}

const ShareConversation = ({ conversationId, handleClose, show }: ShareConversationProps) => {
  const { t } = useTranslation();
  const { openNotification } = useNotification();
  const [shareLink, setShareLink] = useState("");
  const [isCheckingShared, setCheckingShared] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [shareState, setShareState] = useState<ShareConversationState>(ShareConversationState.NEW);
  const [currentSharedConversation, setCurrentSharedConversation] = useState<SharedConversation>();

  useEffect(() => {
    if (show && conversationId) {
      ConversationService.getSharedConversationByConversationId(conversationId)
        .then((sharedConversation) => {
          setShareState(sharedConversation ? ShareConversationState.ALREADY_SHARED : ShareConversationState.NEW);
          if (sharedConversation) {
            setCurrentSharedConversation(sharedConversation);
            setShareLink(getSharedURL(sharedConversation.id));
          }
        })
        .catch(() => setShareState(ShareConversationState.NEW))
        .finally(() => {
          setCheckingShared(false);
        });
    }
    if (show) {
      setShareLink(getSharedURL());
    }
  }, [show, conversationId]);

  const handleShare = async () => {
    setIsLoading(true);
    try {
      let sharedConversation = null;
      if (shareState === ShareConversationState.ALREADY_SHARED && currentSharedConversation) {
        sharedConversation = await ConversationService.updateSharedConversation(currentSharedConversation);
        setShareState(ShareConversationState.UPDATED);
      } else {
        sharedConversation = await ConversationService.createSharedConversation(conversationId);
        setShareState(ShareConversationState.CREATED);
      }

      if (sharedConversation) {
        setShareLink(getSharedURL(sharedConversation.id));
        navigator.clipboard.writeText(getSharedURL(sharedConversation.id)); //copy the link automatically when created
        openNotification(t(TranslationKeys.SHARECONVERSATION_COPIED));
      }
    } catch (error) {
      console.error("Error generating link:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(shareLink).then(() => openNotification(t(TranslationKeys.SHARECONVERSATION_COPIED)));
  };

  const handleModalClose = () => {
    setShareLink("");
    setIsLoading(false);
    setShareState(ShareConversationState.NEW);
    handleClose();
  };

  const renderTitle = () => {
    switch (shareState) {
      case ShareConversationState.NEW:
        return <>{t(TranslationKeys.SHARECONVERSATION_TITLE_NEW)}</>;
      case ShareConversationState.CREATED:
        return <>{t(TranslationKeys.SHARECONVERSATION_TITLE_CREATED)}</>;
      case ShareConversationState.ALREADY_SHARED:
        return <>{t(TranslationKeys.SHARECONVERSATION_TITLE_ALREADYSHARED)}</>;
      case ShareConversationState.UPDATED:
        return <>{t(TranslationKeys.SHARECONVERSATION_TITLE_UPDATED)}</>;
      default:
        return "";
    }
  };
  const renderDescription = () => {
    switch (shareState) {
      case ShareConversationState.NEW:
        return <>{t(TranslationKeys.SHARECONVERSATION_DESCRIPTION_NEW)}</>;
      case ShareConversationState.CREATED:
        return (
          <>
            {t(TranslationKeys.SHARECONVERSATION_DESCRIPTION_CREATED)}{" "}
            <Link to="/shared-chat">{t(TranslationKeys.BREADCRUMBS_SHAREDCHAT)}</Link>
          </>
        );
      case ShareConversationState.ALREADY_SHARED:
        return <>{t(TranslationKeys.SHARECONVERSATION_DESCRIPTION_NEW)}</>;
      case ShareConversationState.UPDATED:
        return (
          <>
            {t(TranslationKeys.SHARECONVERSATION_DESCRIPTION_UPDATED)}{" "}
            <Link to="/shared-chat">{t(TranslationKeys.BREADCRUMBS_SHAREDCHAT)}</Link>
          </>
        );
      default:
        return "";
    }
  };

  const renderActionButton = () => {
    if (shareState === ShareConversationState.CREATED || shareState === ShareConversationState.UPDATED) {
      return (
        <Button variant="secondary" onClick={handleCopy}>
          {t(TranslationKeys.SHARECONVERSATION_COPYLINK)}
        </Button>
      );
    } else {
      return (
        <Button variant="primary" onClick={handleShare} disabled={isLoading}>
          {isLoading ? (
            <Spinner animation="border" size="sm" />
          ) : shareState === ShareConversationState.ALREADY_SHARED ? (
            t(TranslationKeys.SHARECONVERSATION_UPDATELINK)
          ) : (
            t(TranslationKeys.SHARECONVERSATION_CREATELINK)
          )}
        </Button>
      );
    }
  };

  return (
    <Modal show={show} size="lg" onHide={handleModalClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>{renderTitle()}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        {isCheckingShared ? (
          <div className="w-100 d-flex justify-content-center align-items-center" style={{ height: "5rem" }}>
            <Spinner animation="border" role="status">
              <span className="visually-hidden">{t(TranslationKeys.PROFILE_LOADING)}</span>
            </Spinner>
          </div>
        ) : (
          <>
            <p className="mb-3 text-muted">{renderDescription()}</p>
            <div className="d-flex gap-3">
              <Form.Group className="mb-3 flex-grow-1">
                <InputGroup>
                  <Form.Control type="text" readOnly value={shareLink} />
                </InputGroup>
              </Form.Group>
              <Form.Group className="mb-3">{renderActionButton()}</Form.Group>
            </div>
            {shareState === ShareConversationState.ALREADY_SHARED && (
              <p className="mb-3 text-muted">
                {t(TranslationKeys.SHARECONVERSATION_DESCRIPTION_ALREADYSHARED)}{" "}
                <Link to="/shared-chat">{t(TranslationKeys.BREADCRUMBS_SHAREDCHAT)}</Link>
              </p>
            )}
          </>
        )}
      </Modal.Body>
    </Modal>
  );
};

export default ShareConversation;
