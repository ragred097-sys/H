import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { Mock, vi } from "vitest";

import { MemoryRouter } from "react-router-dom";

import { getSharedURL } from "../../../utils/stringUtils";
import { NotificationProvider } from "../../general/NotificationProvider";
import { ConversationService } from "./../../../services/ConversationService";
import ShareConversation from "./ShareConversation";

// Mock ConversationService
vi.mock("../../../services/ConversationService", () => ({
  ConversationService: {
    createSharedConversation: vi.fn(),
    getSharedConversationByConversationId: vi.fn(),
    updateSharedConversation: vi.fn(),
  },
}));

// Mock i18next
vi.mock("react-i18next", () => ({
  initReactI18next: {
    init: () => {},
    type: "3rdParty",
  },
  useTranslation: () => ({
    i18n: {
      changeLanguage: vi.fn(() => new Promise(() => {})),
    },
    t: (key: string) => key,
  }),
}));
const mockOpenNotification = vi.fn();

vi.mock("../../general/NotificationProvider", () => {
  return {
    NotificationProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    useNotification: () => ({
      openNotification: mockOpenNotification,
    }),
  };
});
//reinitialize before every test case
beforeEach(() => {
  Object.defineProperty(navigator, "clipboard", {
    value: {
      writeText: vi.fn().mockResolvedValue(undefined),
    },
    writable: true,
  });
});
const mockActionButton = {
  SHARECONVERSATION_COPIED: "shareConversation.copied",
  SHARECONVERSATION_COPYLINK: "shareConversation.copyLink",
  SHARECONVERSATION_CREATELINK: "shareConversation.createLink",
  SHARECONVERSATION_UPDATELINK: "shareConversation.updateLink",
};
describe("ShareConversation", () => {
  const handleClose = vi.fn();
  const conversationId = "conv-123";
  function renderComponent() {
    return render(
      <NotificationProvider>
        <MemoryRouter>
          <ShareConversation show={true} handleClose={handleClose} conversationId={conversationId} />
        </MemoryRouter>
      </NotificationProvider>
    );
  }

  it("shows loading spinner initially", async () => {
    (ConversationService.getSharedConversationByConversationId as Mock).mockResolvedValue(null);
    renderComponent();
    expect(screen.getByRole("status")).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByRole("status")).not.toBeInTheDocument());
  });

  it("render new state and create a share link", async () => {
    (ConversationService.createSharedConversation as Mock).mockResolvedValue(null); //simulate no shared conversation
    (ConversationService.createSharedConversation as Mock).mockResolvedValue({
      id: conversationId,
    }); //successful creation
    renderComponent();
    // wait until the "create link" button appears on screen
    await waitFor(() => {
      screen.getByText("shareConversation.createLink");
      screen.getByText(mockActionButton.SHARECONVERSATION_CREATELINK);
    });
    fireEvent.click(
      screen.getByRole("button", {
        name: mockActionButton.SHARECONVERSATION_CREATELINK,
      })
    );

    await waitFor(() => {
      // ensure backend is called with correct conversation ID
      expect(ConversationService.createSharedConversation).toHaveBeenCalledWith(conversationId);
      // clipboard was updated with the correct shared URL
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith(getSharedURL(conversationId));
    });
    //the generated share link should now be visible in an input field
    expect(screen.getByDisplayValue(getSharedURL(conversationId))).toBeInTheDocument();
  });

  it("render already shared state and update the link", async () => {
    (ConversationService.getSharedConversationByConversationId as Mock).mockResolvedValue({ id: conversationId });
    (ConversationService.updateSharedConversation as Mock).mockResolvedValue({
      id: conversationId,
    });
    renderComponent();
    //Wait until the "update link" button appears,
    await waitFor(() => {
      screen.getByText("shareConversation.updateLink");
      screen.getByText(mockActionButton.SHARECONVERSATION_UPDATELINK);
    });
    //simulate clicking the update-link button
    fireEvent.click(
      screen.getByRole("button", {
        name: mockActionButton.SHARECONVERSATION_UPDATELINK,
      })
    );
    // backend update called and clipboard updated
    await waitFor(() => {
      expect(ConversationService.updateSharedConversation).toHaveBeenCalled();
      expect(navigator.clipboard.writeText).toHaveBeenCalledWith(getSharedURL(conversationId));
      expect(mockOpenNotification).toHaveBeenCalledWith(mockActionButton.SHARECONVERSATION_COPIED);
    });
    //the updated share URL is visible in the input field
    expect(screen.getByDisplayValue(getSharedURL(conversationId))).toBeInTheDocument();
  });

  it("renders copy link button when state is CREATED and copies the link", async () => {
    // Mock
    (ConversationService.getSharedConversationByConversationId as Mock).mockResolvedValue(null);
    (ConversationService.createSharedConversation as Mock).mockResolvedValue({
      id: conversationId,
    });

    renderComponent();
    //wait until the "Create Link" button appears, then click it
    await waitFor(() =>
      screen.getByRole("button", {
        name: mockActionButton.SHARECONVERSATION_CREATELINK,
      })
    );
    fireEvent.click(
      screen.getByRole("button", {
        name: mockActionButton.SHARECONVERSATION_CREATELINK,
      })
    );

    // Wait for state to update to CREATED and button changes to "Copy Link"
    await waitFor(() => {
      expect(
        screen.getByRole("button", {
          name: mockActionButton.SHARECONVERSATION_COPYLINK,
        })
      ).toBeInTheDocument();
    });
    // click copy link button
    fireEvent.click(
      screen.getByRole("button", {
        name: mockActionButton.SHARECONVERSATION_COPYLINK,
      })
    );
    expect(mockOpenNotification).toHaveBeenCalledWith(mockActionButton.SHARECONVERSATION_COPIED);
    //check that clipboard was written with the correct URL
    expect(navigator.clipboard.writeText).toHaveBeenCalledWith(getSharedURL(conversationId));
  });

  it("resets state when modal closes", async () => {
    (ConversationService.getSharedConversationByConversationId as Mock).mockResolvedValue(null);
    //render the component and ensure modal "Create Link" button becomes visible
    renderComponent();
    await waitFor(() => {
      screen.getByText("shareConversation.createLink");
      screen.getByText(mockActionButton.SHARECONVERSATION_CREATELINK);
    });
    //simulate user clicking the "Close" icon/button
    fireEvent.click(screen.getByLabelText(/Close/i));
    //verify the close handler is called
    expect(handleClose).toHaveBeenCalled();
  });
});
