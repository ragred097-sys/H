import { useState } from "react";

import { Button } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { Assistant, Conversation } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";
import { formatTimestamp } from "../../utils/dateUtils";
import ConfirmationDialog from "../general/ConfirmationDialog";
import { useNotification } from "../general/NotificationProvider";
import { ColumnConfig, ConfigurableTable } from "../general/Table";
import { ConversationService } from "./../../services/ConversationService";

const ChatHistory = ({
  agents,
  chats,
  currentAgent,
  loading,
  onLaunchChat,
  triggerUpdate,
}: {
  chats: Conversation[] | undefined;
  currentAgent?: Assistant;
  agents?: Assistant[];
  triggerUpdate?: () => void;
  onLaunchChat?: (chat: Conversation) => void;
  loading?: boolean;
}) => {
  const [showDelete, setShowDelete] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [currentChat, setCurrentChat] = useState<Conversation>();
  const [confirmationLoading, setConfirmationLoading] = useState(false);
  const { openErrorNotification, openNotification } = useNotification();
  const { t } = useTranslation();

  if (chats) {
    // Filter chats if currentAgent is provided
    const filteredChats = currentAgent
      ? chats.filter((chat) =>
          chat.assistantId ? chat.assistantId === currentAgent.id : chat.agentWorkflowId === currentAgent.id
        )
      : chats;

    // -------------------------------------------
    // Table column configuration for cleaner data mapping
    // -------------------------------------------
    const getAssistantName = (chat: Conversation): string => {
      if (!agents) return "";

      const assistantId = chat.assistantId || chat.agentWorkflowId;
      if (!assistantId) return "";

      const assistant = agents.find((a) => a.id === assistantId);
      return assistant?.name || "";
    };

    const buildLaunchButton = (chat: Conversation) => (
      <div className="w-100 d-flex justify-content-center">
        <Button
          className="text-light"
          variant="transparent"
          size="sm"
          onClick={() => onLaunchChat && onLaunchChat(chat)}
        >
          <i className="bi bi-rocket-takeoff"></i>
        </Button>
      </div>
    );

    const buildDeleteButton = (chat: Conversation) => (
      <div className="w-100 d-flex justify-content-center">
        <Button
          variant="transparent"
          size="sm"
          className="text-light"
          onClick={() => {
            setCurrentChat(chat);
            setShowConfirmation(true);
            setShowDelete(true);
          }}
        >
          <i className="bi bi-trash3 text-danger"></i>
        </Button>
      </div>
    );

    // Base column configuration
    const baseColumnConfig: ColumnConfig<Conversation>[] = [
      {
        extractor: (chat: Conversation) => chat.name ?? "",
        key: t(TranslationKeys.HISTORY_CHATNAME),
      },
      {
        extractor: (chat: Conversation) => formatTimestamp(chat.createdAt),
        key: t(TranslationKeys.HISTORY_DATECREATED),
      },
      {
        extractor: (chat: Conversation) => buildLaunchButton(chat),
        key: t(TranslationKeys.HISTORY_LAUNCH),
      },
      {
        extractor: (chat: Conversation) => buildDeleteButton(chat),
        key: t(TranslationKeys.HISTORY_DELETE),
      },
    ];

    // Add agent column if no current agent is selected
    const columnConfig = currentAgent
      ? baseColumnConfig
      : [
          baseColumnConfig[0], // name
          {
            extractor: (chat: Conversation) => getAssistantName(chat),
            key: t(TranslationKeys.HISTORY_AGENT),
          },
          ...baseColumnConfig.slice(1), // date, launch, delete
        ];

    const handleDeleteChat = async (convo: Conversation, triggerUpdate?: () => void) => {
      setConfirmationLoading(true);
      try {
        await ConversationService.deleteConversation(convo);
        openNotification(t(TranslationKeys.HISTORY_DELETESUCCESS), `primary`);
        if (triggerUpdate) {
          triggerUpdate();
        }
        setShowConfirmation(false);
      } catch (error) {
        openErrorNotification(t(TranslationKeys.ERRORMESSAGES_CHATHISTORYDELETE), error as Error);
      } finally {
        setConfirmationLoading(false);
      }
    };

    return (
      <>
        <ConfigurableTable<Conversation>
          loading={loading ?? false}
          data={filteredChats}
          columnConfig={columnConfig}
          defaultSortColumn={t(TranslationKeys.HISTORY_DATECREATED)}
          defaultSortOrder="desc"
        />

        {showDelete && (
          <ConfirmationDialog
            show={showConfirmation}
            confirmationQuestion={t(TranslationKeys.MESSAGES_CONFIRMDELETECHAT)}
            confirmationButtonLabel={t(TranslationKeys.MESSAGES_CONFIRMDELETEYES)}
            onConfirm={() => handleDeleteChat(currentChat as Conversation, triggerUpdate)}
            onClose={() => setShowConfirmation(false)}
            variant="danger"
            isConfirmationLoading={confirmationLoading}
          />
        )}
      </>
    );
  }

  return null; // Graceful fallback for undefined chats
};

export { ChatHistory };
