import { v4 as uuidv4 } from "uuid";

import { DocumentType, Named } from "../../lib/Model.ts";
import { determineDocumentType } from "../../utils/fileUtils";

export class AttachedFile implements Named {
  public id: string = uuidv4();
  public name: string;
  public size: number;
  public file: File;
  public type: DocumentType;

  constructor(file: File) {
    this.name = file.name;
    this.size = file.size;
    this.file = file;
    const documentType = determineDocumentType(file);

    if (!documentType) {
      throw new Error(`Unable to attach file '${file.name}': Unsupported type '${file.type}'`);
    }

    this.type = documentType;
  }
}
