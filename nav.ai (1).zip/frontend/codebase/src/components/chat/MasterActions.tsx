import { useEffect, useState } from "react";

import { Tab, Tabs } from "react-bootstrap";

import { ActionsPanel } from "./ActionsPanel";
import { ActionsPanelExport } from "./ActionsPanelExport/ActionsPanelExport";
import { ActionsPanelExportProps } from "../../lib/Model";

export default function MasterActions({
  actionsPanelExportProps,
}: {
  actionsPanelExportProps: ActionsPanelExportProps;
}) {
  const [activeActionPanel, setActiveActionPanel] = useState<string>("export");
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  const [theme, setTheme] = useState<string>("light"); // Default theme value

  useEffect(() => {
    // Fetch the current value of the data-bs-theme attribute.
    const currentTheme = document.documentElement.getAttribute("data-bs-theme");
    if (currentTheme) {
      setTheme(currentTheme);
    }
  }, []);

  useEffect(() => {
    const handleSize = () => {
      setScreenWidth(window.innerWidth);
    };
    window.addEventListener("resize", handleSize);
    return () => {
      window.removeEventListener("resize", handleSize);
    };
  }, []);
  return (
    <Tabs
      defaultActiveKey="export"
      className="mb-3 "
      variant="transparent"
      transition={false}
      style={{ position: "relative" }}
      onSelect={(key) => {
        setActiveActionPanel(key as string);
      }}
    >
      <Tab
        eventKey="export"
        title={
          <span className="d-flex flex-row">
            <div
              id="bigBlueDot"
              className="rounded-circle bg-primary"
              style={{
                height: "0.75rem",
                marginLeft: "0.2em",
                marginRight: "2em",
                marginTop: "0.4em",
                width: "0.75rem",
                zIndex: 2,
              }}
            ></div>
            <span
              className={activeActionPanel === "export" ? "fs-5" : "fs-5"}
              style={
                activeActionPanel == "export"
                  ? {
                      color: "var(--primary-color)",
                      textDecoration: "underline",
                    }
                  : {
                      color: theme == "dark" ? "rgb(174, 163, 163)" : "whitesmoke",
                      textDecoration: "none",
                    }
              }
            >
              Export Actions
            </span>
          </span>
        }
      >
        <div>
          <ActionsPanelExport {...actionsPanelExportProps} />
        </div>
      </Tab>

      <Tab
        eventKey="agent"
        title={
          <span
            className={activeActionPanel === "agent" ? "fs-5" : "fs-5"}
            style={
              activeActionPanel === "agent"
                ? {
                    color: "var(--primary-color)",
                    marginLeft: screenWidth <= 855 ? "2.5em" : "",
                    textDecoration: "underline",
                  }
                : {
                    color: theme == "dark" ? "rgb(174, 163, 163)" : "whitesmoke",
                    marginLeft: screenWidth <= 855 ? "2.5em" : "",
                    textDecoration: "none",
                  }
            }
          >
            Agent Actions
          </span>
        }
      >
        <ActionsPanel />
      </Tab>
    </Tabs>
  );
}
