import { useEffect, useState } from "react";

import { Accordion, Button, Modal } from "react-bootstrap";
import { useTranslation } from "react-i18next";

import { ConnectorIcon } from "./ConnectorIcon";
import playIcon from "../../assets/images/playIcon.svg";
import { TranslationKeys } from "../../types/translation-keys";
import { renderEqtyPolicyPlane } from "../../utils/eqty";
import { AgentPolicyPlaneApplication as AgentPolicyPlaneApplicationAUS } from "../eqty/policyplane-aus";
import { AgentPolicyPlaneApplication as AgentPolicyPlaneApplicationEU } from "../eqty/policyplane-eu";
import { AgentPolicyPlaneApplication as AgentPolicyPlaneApplicationUS } from "../eqty/policyplane-us";

export const ActionsPanel = () => {
  const [showActionWarning, setShowActionWarning] = useState(false);
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  const { t } = useTranslation();

  const placeholderText = [
    {
      action: t(TranslationKeys.ACTIONSPANEL_NOTIFYFIRSTRESPONDERS),
      actionType: "danger",
      status: t(TranslationKeys.ACTIONSPANEL_PERMISSIONSNEEDED),
    },
    {
      action: t(TranslationKeys.ACTIONSPANEL_SENDSMSTOCITIZENS),
      actionType: "success",
      status: t(TranslationKeys.ACTIONSPANEL_ACTIONAPPROVED),
    },
    {
      action: t(TranslationKeys.ACTIONSPANEL_NOTIFYHOSPITALS),
      actionType: "success",
      status: t(TranslationKeys.ACTIONSPANEL_ACTIONAPPROVED),
    },
  ];

  const badgeColour = (actionType: string) => {
    if (actionType === "danger") return "#F77275";
    if (actionType === "success") return "#B4D7AD";
  };

  useEffect(() => {
    const handleSize = () => {
      setScreenWidth(window.innerWidth);
    };
    window.addEventListener("resize", handleSize);
    return () => {
      window.removeEventListener("resize", handleSize);
    };
  }, []);

  const renderActions = () => {
    return placeholderText.map((item) => {
      return (
        <div className="d-flex align-items-center flex-row" key={item.action}>
          <></>
          <div
            style={{
              backgroundColor: "transparent",
              border: "0.125rem solid var(--border-color)",
              borderBottomLeftRadius: "35%",
              borderRight: "none",
              borderTop: "none",
              height: "6.2em",
              marginBottom: "0.625rem",
              marginLeft: "1.5rem",
              marginTop: "-5.3em",
              width: "3.75rem",
            }}
          ></div>
          <div
            id="blueDot"
            className="rounded-circle bg-primary"
            style={{
              height: "6px",
              marginBottom: "-0.1em",
              width: "6px",
              zIndex: "1000",
            }}
          ></div>
          <Button
            className="action-button d-flex align-items-center ms-3 m-2"
            style={{ borderRadius: "var(--bs-border-radius)", width: "18em" }}
            variant="transparent"
            size="sm"
          >
            <div
              onMouseEnter={() => setHoveredButton(item.action)}
              onMouseLeave={() => setHoveredButton(null)}
              style={{ display: "inline-block", position: "relative" }}
            >
              {hoveredButton === item.action ? (
                <img src={playIcon} style={{ height: "2em" }} alt="play button" />
              ) : (
                <ConnectorIcon />
              )}
            </div>

            <span className="ps-2 pe-2">{item.action}</span>
          </Button>
          <Button
            variant="transparent"
            onClick={
              item.actionType === "danger"
                ? () => setShowActionWarning(true)
                : () => console.debug("Not implemented yet")
            }
          >
            <div
              style={{
                backgroundColor: badgeColour(item.actionType),
                borderRadius: "15px",
                fontSize: "10px",
                paddingBottom: "0.3em",
                paddingLeft: "0.8em",
                paddingRight: "1em",
                paddingTop: "0.3em",
                width: "1Butt",
              }}
              className={item.actionType === "danger" ? "text-light" : "text-dark"}
            >
              {item.status}
            </div>
          </Button>
        </div>
      );
    });
  };

  return (
    <div>
      <Accordion
        defaultActiveKey="0"
        flush
        alwaysOpen
        bsPrefix="transparent
      "
      >
        <Accordion.Item eventKey="0">
          <Accordion.Header></Accordion.Header>
          <Accordion.Body>
            {screenWidth <= 855 && <div className="converation-masteractions-connector" />}
            {renderActions()}
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>

      {/* MODALS */}
      <Modal
        show={showActionWarning}
        fullscreen
        backdrop="static"
        centered
        className="text-light custom-modal-backdrop"
        onHide={() => setShowActionWarning(false)}
        style={{ height: "100vh", width: "100vw" }}
      >
        <Modal.Header closeButton>
          <Modal.Title>{t(TranslationKeys.ACTIONSPANEL_EQTYCOMPLIANCEGRID)}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {renderEqtyPolicyPlane(
            new Map([
              ["us", () => <AgentPolicyPlaneApplicationUS />],
              ["aus", () => <AgentPolicyPlaneApplicationAUS />],
              ["eu", () => <AgentPolicyPlaneApplicationEU />],
            ])
          )}
        </Modal.Body>
      </Modal>
    </div>
  );
};
