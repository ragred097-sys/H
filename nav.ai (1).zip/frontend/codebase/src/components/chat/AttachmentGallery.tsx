import React, { useState } from "react";

import { OverlayTrigger, Spinner, Tooltip } from "react-bootstrap";
import { useDropzone } from "react-dropzone";
import { useTranslation } from "react-i18next";

import { AgentWorkflow, Assistant, Attachment, AttachmentContext, Module, TypeName, typeOf } from "../../lib/Model.ts";
import { AgentFormForAttachment } from "../../stores/useStore.ts";
import { TranslationKeys } from "../../types/translation-keys.ts";
import { formatBytes } from "../../utils/fileUtils";
import { translateParamOrThrow } from "../../utils/translationUtils";
import { AttachedFile } from "../general/AttachedFile.tsx";
import FileUploadButton from "../general/FileUploadButton.tsx";
import { useNotification } from "../general/NotificationProvider.tsx";
import { AgentService } from "./../../services/AgentService";
import { AssistantService } from "./../../services/AssistantService";
import { ConversationService } from "./../../services/ConversationService";
import { ModuleService } from "./../../services/ModuleService";
import { AttachedFilePreview } from "./AttachedFilePreview.tsx";
import AttachmentPreview from "./AttachmentPreview.tsx";
import { ConversationContext } from "./ConversationContext.ts";
import { UploadingAttachment } from "./UploadingAttachment.ts";

interface Props {
  attachmentContext: AttachmentContext;
  conversationContext: ConversationContext;
  documentHandler: (docs: (Attachment | AttachedFile)[]) => void; // function to handle documents
  documents: (Attachment | AttachedFile)[];
}

export function AttachmentGallery({
  attachmentContext, //assistant data
  conversationContext,
  documentHandler, // function to handle documents
  documents,
}: Props) {
  const { openErrorNotification } = useNotification();
  const { t } = useTranslation();
  const [attachments, setAttachments] = React.useState<(Attachment | UploadingAttachment)[]>([]);
  const [module, setModule] = useState<Module>();
  const [loading, setLoading] = useState(false);
  const { setAgentData, setOpenForm } = AgentFormForAttachment();

  React.useEffect(() => {
    setAttachments([]);
    if (conversationContext?.getConversation()) {
      conversationContext.getOrCreateConversation().then((conversation) => {
        if (attachmentContext?.attachmentStorages?.length > 0) {
          ConversationService.getConversationAttachments(conversation)
            .then((attachments) => {
              setAttachments(attachments);
            })
            .catch((error) => {
              openErrorNotification("Error fetching attachments", error);
            });
        }
      });
    }
    if ((attachmentContext as AgentWorkflow | Assistant)?.__type_name == TypeName.AgentWorkflow) {
      setLoading(true);
      if ((attachmentContext as AgentWorkflow)?.rootAgent?.type === TypeName.Assistant) {
        AssistantService.getAssistant((attachmentContext as AgentWorkflow)?.rootAgent?.id).then((response) =>
          getModel(response?.llmIds[0])
        );
      } else {
        AgentService.getAgent((attachmentContext as AgentWorkflow)?.rootAgent?.id).then((response) =>
          getModel(response?.llmId)
        );
      }
    } else {
      setLoading(true);
      getModel((attachmentContext as Assistant)?.llmIds[0]);
    }
  }, [conversationContext]);

  const getModel = async (modelId: string) => {
    try {
      setLoading(true);
      const res = await ModuleService.getModuleById(modelId);
      setModule(res);
    } catch (error) {
      //error
    } finally {
      setLoading(false);
    }
  };

  const onAttachmentDragStart = (event: React.DragEvent, attachment: Attachment) => {
    event.dataTransfer.setData("custom/entity", JSON.stringify(attachment));
    // event.dataTransfer.effectAllowed="copyMove";
  };

  const onCreateAttachments = (files: File[]) => {
    const storedAttachments = attachments?.map(
      (attachment) => `${attachment.name.replace(/[^a-zA-Z0-9]/g, "")}-${attachment.size}`
    );
    const currentAttachment = `${files[0].name.replace(/[^a-zA-Z0-9]/g, "")}-${files[0].size}`;
    const isAttachmentAlreadyExist = storedAttachments?.includes(currentAttachment);
    if (!isAttachmentAlreadyExist) {
      conversationContext
        .getOrCreateConversation()
        .then((conversation) => {
          try {
            const attachmentFactories = files.map(
              (file) =>
                new UploadingAttachment(
                  conversation,
                  attachmentContext,
                  file,
                  (id, attachment) => {
                    // replace factory with attachment
                    setAttachments((prevValue) => prevValue.map((item) => (item.id === id ? attachment : item)));
                  },
                  () => {
                    // trigger rerender
                    setAttachments((prevValue) => [...prevValue]);
                  }
                )
            );
            setAttachments((prevValue) => [...prevValue, ...attachmentFactories]);
          } catch (error) {
            openErrorNotification((error as Error).message, error as Error);
          }
        })
        .catch((error) => {
          openErrorNotification(error.message);
        });
    }
  };

  const onRemoveAttachment = (attachment: Attachment | UploadingAttachment) => {
    if (attachment instanceof UploadingAttachment) {
      // just remove it from the list
      setAttachments((prevValue) => prevValue.filter((_attachment) => _attachment.id !== attachment.id));
    } else {
      conversationContext
        .getOrCreateConversation()
        .then((conversation) => {
          // delete it from the server
          ConversationService.deleteConversationAttachment(conversation, attachment)
            .then((attachment) => {
              setAttachments((prevValue) => prevValue.filter((_attachment) => _attachment.id !== attachment.id));
            })
            .catch((error) => {
              openErrorNotification("Error removing attachments", error);
            });
        })
        .catch((error) => {
          openErrorNotification("Error creating conversation", error);
        });
    }
  };
  const onDrop = (acceptedFiles: File[]) => {
    // handle new files
    console.log("on drop called", acceptedFiles);
    if (acceptedFiles) {
      onCreateAttachments(acceptedFiles);
    }
  };

  const { getInputProps, getRootProps } = useDropzone({
    multiple: true,
    noClick: true,
    onDrop,
  });
  const renderAgentDetails = () => {
    return (
      <div
        style={{
          height: "6em",
          position: "relative",
        }}
      >
        <div
          className="d-flex flex-row align-items-center"
          style={{
            padding: "0.5em",
          }}
        >
          {(attachmentContext as Assistant | AgentWorkflow)?.icon ? (
            <div>
              <img
                className="attachment-agent-image"
                src={(attachmentContext as Assistant | AgentWorkflow)?.icon}
                style={{
                  borderRadius: "50%",
                  objectFit: "cover",
                }}
                alt={t(TranslationKeys.ATTACHMENTS_COVERIMAGE)}
              />
            </div>
          ) : (
            <div
              className="attachment-agent-image d-flex justify-content-center align-items-center rounded-circle "
              style={{
                background: "linear-gradient(to bottom right, var(--secondary-color), var(--primary-color))",
              }}
            >
              <i className="bi bi-robot" style={{ fontSize: "2em" }}></i>
            </div>
          )}
          <div
            style={{
              flex: 1,
              overflowY: "hidden",
              padding: "0em 0.8em",
            }}
          >
            <p
              style={{
                display: "-webkit-box",
                fontSize: "1.1em",
                margin: 0,
                overflow: "hidden",
                textOverflow: "ellipsis",
                WebkitBoxOrient: "vertical",
                WebkitLineClamp: 3,
              }}
            >
              {(attachmentContext as Assistant | AgentWorkflow)?.name}
            </p>
          </div>
          {/* Pencil icon at  right */}
          <i
            className="bi bi-pencil-fill"
            style={{
              cursor: "pointer",
              right: "0.5em",
            }}
            onClick={() => {
              setOpenForm(true);
              setAgentData(attachmentContext as Assistant | AgentWorkflow);
            }}
          ></i>
        </div>
      </div>
    );
  };
  const handleAttachmentClick = (attachment: Attachment | UploadingAttachment) => {
    if (attachment instanceof UploadingAttachment && attachment?.uploading) {
      // If the attachment is still uploading, do not proceed with the click action
      return;
    }
    if (typeOf(attachment) === TypeName.Attachment) {
      const newAttachment = attachment as Attachment;
      const isPresent = documents.some((doc) => doc.id === newAttachment.id || doc.name === newAttachment.name);

      if (isPresent) {
        // Remove the attachment if already present
        documentHandler(documents.filter((doc) => doc.id !== newAttachment.id && doc.name !== newAttachment.name));
      } else {
        // Add the attachment if not present
        documentHandler([...documents, newAttachment]);
      }
    }
  };

  return (
    <>
      <div>
        {/* agent details */}
        {renderAgentDetails()}
        {/* show supported types by ai model */}
        {loading ? (
          <Spinner size="sm" animation="border" role="status">
            <span className="visually-hidden">Loading...</span>
          </Spinner>
        ) : (
          attachmentContext?.attachmentStorages?.length > 0 && (
            <div className="d-flex flex-row align-items-center justify-content-between">
              <div className="d-flex flex-column">
                <span>{t(TranslationKeys.ATTACHMENTS_SUPPORTEDFILETYPES)}</span>
                <span> {`${module?.name}`}</span>
              </div>
              {attachmentContext?.attachmentStorages?.length == 0 ? (
                <span>{t(TranslationKeys.ATTACHMENTS_NOSUPPORTEDTYPES)}</span>
              ) : (
                <div>
                  {attachmentContext?.attachmentStorages?.map((storage, i) => (
                    <span key={i}>
                      {/* {storage?.type} */}
                      {t(translateParamOrThrow(storage?.type, "ATTACHMENTS_SUPPORTEDTYPESVALUES_"), {
                        defaultValue: `${storage?.type}`,
                      })}
                      {i < attachmentContext?.attachmentStorages?.length - 1 && ","}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )
        )}
        <hr></hr>
        {/* attachment view */}
        <div
          style={{
            alignItems: "center",
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <div className="d-flex justify-content-between align-items-center w-100 mb-1">
            <h4>{t(TranslationKeys.ATTACHMENTS_ATTACHMENTS)}</h4>
            <OverlayTrigger
              placement="top-end"
              delay={{ hide: 500, show: 750 }}
              overlay={<Tooltip style={{ zIndex: 3000 }}>{t(TranslationKeys.ATTACHMENTS_UPLOADATTACHMENT)}</Tooltip>}
            >
              <span style={{ display: "inline-block" }}>
                <FileUploadButton
                  onFileSelect={onCreateAttachments}
                  agentData={attachmentContext as AgentWorkflow | Assistant}
                />
              </span>
            </OverlayTrigger>
          </div>
        </div>
        <div
          {...getRootProps({
            className: "d-flex flex-wrap justify-content-start mt-1",
            style: {
              alignContent: "flex-start",
              gap: "0.8rem",
              height: "calc(100vh - 250px)",
            },
          })}
        >
          <input {...getInputProps()} />
          {attachmentContext?.attachmentStorages?.length == 0 ? (
            <p>{t(TranslationKeys.ATTACHMENTS_NOSTORAGE)}</p>
          ) : (
            attachments.length === 0 && <p>{t(TranslationKeys.ATTACHMENTS_NOATTACHMENT)}</p>
          )}
          {attachments.map((attachment) => {
            const isAttached = documents.some(
              (doc) => (doc.id && doc.id === attachment.id) || (doc.name && doc.name === attachment.name)
            );
            return (
              <div
                key={attachment.id}
                draggable={attachment instanceof UploadingAttachment ? !attachment.error : true}
                style={{
                  backgroundColor:
                    attachment instanceof UploadingAttachment && attachment.error
                      ? "var(--bs-danger)"
                      : "var(--bs-nav-active-color)",
                  border: isAttached ? "2px solid var(--primary-color)" : "1px solid var(--bs-border-color)",
                  borderRadius: "var(--bs-border-radius)",
                  boxShadow: isAttached ? "0 0 0 2px var(--primary-color)" : undefined,
                  cursor: "pointer",
                  height: "60px",
                  overflow: "hidden",
                  position: "relative",
                  width: "80px",
                }}
                onDragStart={(event) => {
                  if (attachment instanceof UploadingAttachment && !attachment?.uploading) {
                    onAttachmentDragStart(event, attachment as unknown as Attachment);
                  } else {
                    onAttachmentDragStart(event, attachment as Attachment);
                  }
                }}
                onClick={() => handleAttachmentClick(attachment)}
              >
                {attachment instanceof UploadingAttachment ? (
                  attachment.storeAsAttachment ? (
                    <div
                      draggable={!attachment.error}
                      className={`d-flex flex-column justify-content-center align-items-center`}
                      style={{ padding: 1 }}
                    >
                      {attachment.uploading && (
                        <Spinner size="sm" animation="border" role="status">
                          <span className="visually-hidden">Loading...</span>
                        </Spinner>
                      )}
                      {attachment.error && (
                        <OverlayTrigger
                          placement="top-end"
                          delay={{ hide: 500, show: 750 }}
                          overlay={<Tooltip style={{ zIndex: 3000 }}>{attachment.error.message}</Tooltip>}
                        >
                          <i className="bi bi-info-lg text-light"></i>
                        </OverlayTrigger>
                      )}
                      <span>{formatBytes(attachment.size)}</span>
                    </div>
                  ) : (
                    <AttachedFilePreview attachedFile={attachment} />
                  )
                ) : (
                  <AttachmentPreview attachment={attachment} />
                )}
                {(!(attachment as UploadingAttachment).storeAsAttachment ||
                  (attachment as UploadingAttachment).error) && (
                  <OverlayTrigger
                    placement="top-end"
                    delay={{ hide: 500, show: 750 }}
                    overlay={<Tooltip style={{ zIndex: 3000 }}>Remove Attachment from this Conversation</Tooltip>}
                  >
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveAttachment(attachment);
                      }}
                      style={{
                        alignItems: "center",
                        backgroundColor: "#fff",
                        border: "none",
                        borderRadius: "50%",
                        cursor: "pointer",
                        display: "flex",
                        height: "16px",
                        justifyContent: "center",
                        margin: 0,
                        overflow: "hidden",
                        padding: 0,
                        position: "absolute",
                        right: "2px",
                        top: "2px",
                        width: "16px",
                        zIndex: 2,
                      }}
                    >
                      <i
                        className="bi bi-trash3-fill text-danger"
                        style={{
                          alignItems: "center",
                          color: "var(--bs-danger)",
                          display: "flex",
                          fontSize: "12px",
                          justifyContent: "center",
                          lineHeight: 1,
                        }}
                      ></i>
                    </button>
                  </OverlayTrigger>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}
