import { Breadcrumb } from "react-bootstrap";
import { useTranslation } from "react-i18next";
import { useLocation, useNavigate } from "react-router-dom";

import { AccessRole, Assistant, Conversation, Workspace } from "../../lib/Model";
import { TranslationKeys } from "../../types/translation-keys";

interface BreadcrumbsProps {
  currentWorkspace?: Workspace | null;
  currentChat?: Conversation | null;
  currentAgent?: Assistant;
  handleShowEditName?: () => void;
  isAgentConversationOpen?: boolean;
  currentRole?: AccessRole;
  roleId?: string;
  tagName?: string;
}

export default function Breadcrumbs({
  currentAgent,
  currentChat,
  currentRole,
  currentWorkspace,
  handleShowEditName,
  isAgentConversationOpen = true,
  roleId,
  tagName,
}: BreadcrumbsProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();

  const renderBreadCrumbs = () => {
    switch (true) {
      case location.pathname.includes("/workspace/"):
        return (
          <>
            <Breadcrumb.Item onClick={() => navigate("/workspace")}>
              {t(TranslationKeys.BREADCRUMBS_MYWORKSPACES)}
            </Breadcrumb.Item>
            <Breadcrumb.Item onClick={() => navigate(`/workspace/${currentWorkspace?.id}`)}>
              {currentWorkspace && currentWorkspace.name ? currentWorkspace?.name : "..."}
            </Breadcrumb.Item>
            {isAgentConversationOpen && (
              <>
                <Breadcrumb.Item>{currentAgent?.name}</Breadcrumb.Item>
                <Breadcrumb.Item>
                  {currentChat ? (
                    <>
                      {currentChat?.name}{" "}
                      <i className="bi bi-pencil-square ps-2 fs-6 " onClick={handleShowEditName}>
                        <br />
                      </i>
                    </>
                  ) : (
                    <>{t(TranslationKeys.BREADCRUMBS_NEWCHAT)}</>
                  )}
                </Breadcrumb.Item>
              </>
            )}
          </>
        );
      case location.pathname.includes("/history"):
        return (
          <>
            <Breadcrumb.Item
              onClick={() => {
                navigate("/history");
              }}
            >
              {t(TranslationKeys.BREADCRUMBS_HISTORY)}
            </Breadcrumb.Item>
          </>
        );
      case location.pathname.includes("/recyclebin"):
        return (
          <>
            <Breadcrumb.Item onClick={() => {}}>{t(TranslationKeys.NAV_RECYCLEBIN)}</Breadcrumb.Item>
          </>
        );
      case location.pathname.includes("/tools"):
        return (
          <>
            <Breadcrumb.Item onClick={() => {}}>{t(TranslationKeys.BREADCRUMBS_TOOLS)}</Breadcrumb.Item>
          </>
        );
      case location.pathname.includes("/workspace"):
        return (
          <>
            <Breadcrumb.Item onClick={() => navigate("/workspace")}>
              {t(TranslationKeys.BREADCRUMBS_MYWORKSPACES)}
            </Breadcrumb.Item>
          </>
        );
      case location.pathname.includes("/learnvantage"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/learnvantage")}>
            {t(TranslationKeys.BREADCRUMBS_LEARNVANTAGE)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/datasources"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/datasources")}>
            {t(TranslationKeys.BREADCRUMBS_DATASETS)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/agents"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/agents")}>{t(TranslationKeys.BREADCRUMBS_AGENTS)}</Breadcrumb.Item>
        );
      case location.pathname.includes("/utilityagents"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/utilityagents")}>
            {t(TranslationKeys.BREADCRUMBS_UTILITYAGENTS)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/superagents"):
        return <Breadcrumb.Item>{t(TranslationKeys.BREADCRUMBS_MYSUPERAGENTS)}</Breadcrumb.Item>;
      case location.pathname.includes("/settings"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/settings")}>
            {t(TranslationKeys.BREADCRUMBS_SETTINGS)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/registry"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/registry")}>
            {t(TranslationKeys.BREADCRUMBS_REGISTRY)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/application-settings"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/application-settings")}>
            {t(TranslationKeys.APPLICATIONSETTINGS_APPLICATIONSETTINGSSECTION)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/profile"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/profile")}>
            {t(TranslationKeys.BREADCRUMBS_MYPROFILE)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/roles"):
        return (
          <>
            <Breadcrumb.Item onClick={() => navigate("/roles")}>{t(TranslationKeys.BREADCRUMBS_ROLES)}</Breadcrumb.Item>
            {currentRole && currentRole.name && (
              <Breadcrumb.Item onClick={() => navigate(`/roles/${roleId}`)}>{currentRole?.name}</Breadcrumb.Item>
            )}
          </>
        );
      case location.pathname.includes("/tags"):
        return (
          <>
            <Breadcrumb.Item
              onClick={() => {
                if (tagName) {
                  navigate(`/tags`);
                }
              }}
            >
              {t(TranslationKeys.BREADCRUMBS_TAGS)}
            </Breadcrumb.Item>
            {tagName && <Breadcrumb.Item>{tagName}</Breadcrumb.Item>}
          </>
        );
      case location.pathname.includes("/manage-tags"):
        return (
          <Breadcrumb.Item onClick={() => navigate("/manage-tags")}>
            {t(TranslationKeys.BREADCRUMBS_MANAGETAGS)}
          </Breadcrumb.Item>
        );
      case location.pathname.includes("/shared-chat"):
        return (
          <Breadcrumb.Item onClick={() => {}}>{t(TranslationKeys.SHAREDCHATLINKS_SHAREDCHATLINKS)}</Breadcrumb.Item>
        );
      case location.pathname === "/":
        return (
          <>
            <Breadcrumb.Item onClick={() => navigate("/workspace")}>
              {t(TranslationKeys.BREADCRUMBS_MYWORKSPACES)}
            </Breadcrumb.Item>
            <Breadcrumb.Item>
              {currentChat ? (
                <>
                  {currentChat?.name}{" "}
                  <i className="bi bi-pencil-square ps-2 fs-6 " onClick={handleShowEditName}>
                    <br />
                  </i>
                </>
              ) : (
                <>{t(TranslationKeys.BREADCRUMBS_NEWCHAT)}</>
              )}
            </Breadcrumb.Item>
          </>
        );
      default:
        break;
    }
  };
  return (
    <Breadcrumb className="custom-breadcrumb pt-2 w-100">
      <Breadcrumb.Item
        className="breadcrumb-item-hover"
        onClick={() => {
          navigate("/");
        }}
      >
        <i className={`bi bi-house-door nav-bar-color icon-hover`} />
      </Breadcrumb.Item>
      {renderBreadCrumbs()}
    </Breadcrumb>
  );
}
