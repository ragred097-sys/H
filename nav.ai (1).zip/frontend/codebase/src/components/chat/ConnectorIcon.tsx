export const ConnectorIcon = (props: React.HTMLProps<HTMLDivElement>) => {
  return (
    <div
      className="circle-border connector-icon d-flex justify-content-center align-items-center text-center"
      {...props}
    >
      <svg width="1.5em" height="1.5em" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M7.5 9.97408V4.16699C7.5 3.50395 7.76339 2.86807 8.23223 2.39923C8.70107 1.93038 9.33696 1.66699 10 1.66699C10.663 1.66699 11.2989 1.93038 11.7678 2.39923C12.2366 2.86807 12.5 3.50395 12.5 4.16699V5.00283M12.5 10.0016V15.8337C12.5 16.4967 12.2366 17.1326 11.7678 17.6014C11.2989 18.0703 10.663 18.3337 10 18.3337C9.33696 18.3337 8.70107 18.0703 8.23223 17.6014C7.76339 17.1326 7.5 16.4967 7.5 15.8337V14.9878"
          stroke="white"
          strokeLinecap="round"
        />
        <path
          d="M9.99935 12.5H4.15935C2.78268 12.5 1.66602 11.3808 1.66602 10C1.66602 8.61917 2.78268 7.5 4.15935 7.5H4.99477M9.99935 7.5H15.8281C16.4917 7.49945 17.1284 7.76252 17.5981 8.23135C18.0678 8.70017 18.332 9.33637 18.3327 10C18.3327 11.3808 17.2114 12.5 15.8281 12.5H15.0268"
          stroke="white"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};
