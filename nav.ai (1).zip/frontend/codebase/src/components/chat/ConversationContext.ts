import { AgentWorkflow, Assistant, Conversation, DataSource, Module } from "../../lib/Model.ts";
import { AgentWorkflowService } from "../../services/AgentWorkflowService.ts";
import { AssistantService } from "../../services/AssistantService.ts";
import { ConversationService } from "../../services/ConversationService.ts";
import { DataSourceService } from "../../services/DataSourceService.ts";
import { ModuleService } from "../../services/ModuleService.ts";

export interface ConversationContextListener {
  onCreate(conversation: Conversation): void;

  onUpdate(conversation: Conversation): void;

  onDelete(conversation: Conversation): void;
}

export class ConversationContext {
  private conversation: Conversation | null = null;
  private readonly moduleId: string | null;
  private readonly assistantId: string | null;
  private readonly agentWorkflowId: string | null;
  private readonly dataSourceId: string | null;
  // cached results
  private _module: Module | null = null;
  private _assistant: Assistant | null = null;
  private _agentWorkflow: AgentWorkflow | null = null;
  private _dataSource: DataSource | null = null;

  private listeners: ConversationContextListener[] = [];

  constructor(
    conversation: Conversation | null = null,
    moduleId: string | null = null,
    assistantId: string | null = null,
    agentWorkflowId: string | null = null,
    dataSourceId: string | null = null
  ) {
    // do some assertion
    if ([conversation, moduleId, assistantId, dataSourceId].filter((param) => param !== null).length > 1) {
      throw new Error(
        "Not more than one of 'conversation', 'moduleId', 'assistantId', or 'dataSourceId' must be non-null."
      );
    }
    this.conversation = conversation || null;
    this.moduleId = moduleId || null;
    this.assistantId = conversation?.assistantId ? conversation.assistantId : assistantId || null;
    this.agentWorkflowId = conversation?.agentWorkflowId ? conversation.agentWorkflowId : agentWorkflowId || null;
    this.dataSourceId = conversation ? conversation.dataSourceIds?.at(0) || null : dataSourceId || null;
  }

  public async getOrCreateConversation(): Promise<Conversation> {
    if (!this.conversation) {
      this.conversation = await this.createConversation();
      const conversation = this.conversation;
      this.listeners.forEach((listener) => listener.onCreate(conversation));
    }
    return Promise.resolve(this.conversation);
  }

  public getConversation(): Conversation | null {
    return this.conversation;
  }

  public async getModule(): Promise<Module | null> {
    if (this._module) {
      return Promise.resolve(this._module);
    } else if (this.conversation && this.conversation.llmIds.length > 0) {
      this._module = await ModuleService.getModuleById(this.conversation.llmIds[0]);
      return Promise.resolve(this._module);
    } else if (this.moduleId) {
      this._module = await ModuleService.getModuleById(this.moduleId);
      return Promise.resolve(this._module);
    } else if (this.assistantId) {
      this._module = await this.getAssistant().then((assistant) => {
        if (assistant) {
          return ModuleService.getModuleById(assistant.llmIds[0]);
        } else {
          return null;
        }
      });
      return Promise.resolve(this._module);
    } else if (this.agentWorkflowId) {
      this._module = await this.getAgentWorkflow().then((agentWorkflow) => {
        //TODO
        if (agentWorkflow) {
          //Backend.agentWorkflow.rootAgentId
          //return Backend.getModuleById(assistant.llmIds[0]);
          return null;
        } else {
          return null;
        }
      });
      return Promise.resolve(this._module);
    } else {
      return Promise.resolve(null);
    }
  }

  public setModule(module: Module): void {
    if (this.moduleId) {
      if (this.moduleId !== module.id) {
        // context was initialized for a specific module. changing the module ist not allowed in that case
        throw new Error("Module must not be changed");
      } else {
        this._module = module;
      }
    } else {
      this._module = module;
      if (this.conversation) {
        // we have already a conversation? update it!
        if (this.conversation.llmIds.at(0) !== module.id) {
          ConversationService.updateConversation({ ...this.conversation, llmIds: [module.id] }).then(
            (updatedConversation) => {
              this.conversation = updatedConversation;
              this.listeners.forEach((listener) => listener.onUpdate(updatedConversation));
            }
          );
        }
      }
    }
  }

  public async getAssistant(): Promise<Assistant | null> {
    if (this._assistant) {
      return Promise.resolve(this._assistant);
    } else if (this.assistantId) {
      this._assistant = await AssistantService.getAssistant(this.assistantId);
      return Promise.resolve(this._assistant);
    } else {
      return Promise.resolve(null);
    }
  }

  public async getAgentWorkflow(): Promise<AgentWorkflow | null> {
    if (this._agentWorkflow) {
      return Promise.resolve(this._agentWorkflow);
    } else if (this.agentWorkflowId) {
      this._agentWorkflow = await AgentWorkflowService.getAgentWorkflow(this.agentWorkflowId);
      return Promise.resolve(this._agentWorkflow);
    } else {
      return Promise.resolve(null);
    }
  }

  public refresh(): void {
    this._module = null;
    this._assistant = null;
    this._agentWorkflow = null;
    this._dataSource = null;
  }

  public async getDataSource(): Promise<DataSource | null> {
    if (this._dataSource) {
      return Promise.resolve(this._dataSource);
    } else if (this.dataSourceId) {
      this._dataSource = await DataSourceService.getDatasourceById(this.dataSourceId);
      return Promise.resolve(this._dataSource);
    } else {
      return Promise.resolve(null);
    }
  }

  public addListener(listener: ConversationContextListener): ConversationContext {
    this.listeners.push(listener);
    return this;
  }

  public removeListener(listener: ConversationContextListener): ConversationContext {
    this.listeners = this.listeners.filter((l) => l !== listener);
    return this;
  }

  private async createConversation(): Promise<Conversation> {
    return Promise.all([this.getModule(), this.getAssistant(), this.getAgentWorkflow()]).then((result) => {
      const module: Module | null = result[0];
      const assistant: Assistant | null = result[1];
      const agentWorkflow: AgentWorkflow | null = result[2];

      if (assistant) {
        return ConversationService.createAssistantConversation(assistant, undefined);
      } else if (agentWorkflow) {
        return AgentWorkflowService.createAgentWorkflowConversation(agentWorkflow, undefined);
      } else if (module) {
        return ConversationService.createConversation([module.id], undefined);
      } else {
        throw new Error("No module selected");
      }
    });
  }

  renameConversation(name: string) {
    if (this.conversation) {
      if (this.conversation.name !== name) {
        ConversationService.updateConversation({ ...this.conversation, name: name }).then((updatedConversation) => {
          this.conversation = updatedConversation;
          this.listeners.forEach((listener) => listener.onUpdate(updatedConversation));
        });
      }
    }
  }
}
