import { useCallback, useEffect, useMemo, useState } from "react";

import { Carousel, Spinner } from "react-bootstrap";

import "@react-pdf-viewer/core/lib/styles/index.css";
import "@react-pdf-viewer/default-layout/lib/styles/index.css";

import { Conversation, DataObject, DataSource, DeepDataObject } from "../../lib/Model";
import { DOCX_FORMATS, EXCEL_FORMATS, VIDEO_FORMATS } from "../../utils/constants";
import { formatTimestamp } from "../../utils/dateUtils";
import { dedupeArrayByKey, oldObjectRender } from "../../utils/objectUtils";
import RenderExcel from "../renderers/RenderExcel";
import RenderWordDoc from "../renderers/RenderWordDoc";
import { ConversationService } from "./../../services/ConversationService";
import { DataSourceService } from "./../../services/DataSourceService";
import { FileCard } from "./FileCard";

function chunkArray<T>(array: T[], size: number): T[][] {
  const result: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
}

export default function FileCarousel({
  conversation,
  rtxOn,
  setSelectedAttachment,
}: {
  conversation?: Conversation | null;
  rtxOn: boolean;
  setSelectedAttachment: (vssUuid: string) => void;
}) {
  const [index, setIndex] = useState(0);
  const [dataSource, setDataSource] = useState<DataSource>();
  const [files, setFiles] = useState<DataObject[]>([]);
  const [fileArrayBuffer, setFileArrayBuffer] = useState<DeepDataObject[]>([]);
  const [selectedFile, setSelectedFile] = useState<DeepDataObject | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const chunkSize = 3;

  const fetchDataSource = async (dataSourceId: string) => {
    try {
      const res = await DataSourceService.getDatasourceById(dataSourceId);
      setDataSource(res);
    } catch (error) {
      console.error("Error fetching data source:", error);
      setError("Failed to fetch data source");
    }
  };

  const fetchFiles = async () => {
    try {
      if (rtxOn && conversation) {
        const res = await ConversationService.getVideoAttachments(conversation);
        setFiles(res);
      } else if (dataSource?.ingestedFiles) {
        const dedupedFiles = dedupeArrayByKey(dataSource.ingestedFiles, "fileName");
        setFiles(dedupedFiles);
      }
    } catch (error) {
      console.error("Error fetching files:", error);
      setError("Failed to fetch files");
    }
  };

  const fetchFileArrayBuffer = async () => {
    try {
      const results = await Promise.all(
        files.map(async (obj) => {
          const content = rtxOn
            ? await ConversationService.getVideoAttachmentContent(obj.id, conversation as Conversation)
            : await DataSourceService.getDataObjectContent(obj);
          return {
            arrayBuffer: content,
            fileInfo: obj,
          };
        })
      );
      setFileArrayBuffer(results);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching file details:", error);
      setError("Failed to fetch file details");
    }
  };

  useEffect(() => {
    if (conversation?.dataSourceIds && conversation.dataSourceIds.length > 0 && !rtxOn) {
      setLoading(true);
      fetchDataSource(conversation.dataSourceIds[0] as string);
    }
  }, [conversation?.dataSourceIds, rtxOn]);

  useEffect(() => {
    fetchFiles();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation, dataSource?.ingestedFiles, rtxOn]);

  useEffect(() => {
    if (files.length > 0) {
      fetchFileArrayBuffer();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [files, rtxOn]);

  useEffect(() => {
    setFiles([]);
    setFileArrayBuffer([]);
    setSelectedFile(null);
  }, [conversation]);

  const handleSelect = useCallback((selectedIndex: number) => {
    setIndex(selectedIndex);
  }, []);

  const fileChunks = useMemo(() => chunkArray(fileArrayBuffer, chunkSize), [chunkSize, fileArrayBuffer]);

  useEffect(() => {
    setSelectedFile(fileArrayBuffer[0]);
  }, [fileArrayBuffer]);

  const selectedContent = useMemo(() => {
    if (!selectedFile) {
      return <p>Content Preview</p>;
    }
    if (rtxOn) {
      setSelectedAttachment(selectedFile.fileInfo.id);
    }

    const fileUrl =
      selectedFile.fileInfo.mimeType === "application/pdf"
        ? URL.createObjectURL(new Blob([selectedFile.arrayBuffer], { type: "application/pdf" }))
        : oldObjectRender(selectedFile);

    return (
      <div className="h-100 d-flex flex-column w-100">
        {VIDEO_FORMATS.includes(selectedFile.fileInfo.mimeType) ? (
          <video
            src={fileUrl}
            controls
            style={{
              borderRadius: "var(--bs-border-radius)",
              maxWidth: "100%",
            }}
            muted
            autoPlay
          />
        ) : selectedFile.fileInfo.mimeType === "application/pdf" ? (
          <div style={{ flex: 1, height: "100%", minHeight: 0, width: "100%" }}>
            <iframe
              src={`${fileUrl}#zoom=page-fit&view=FitH`}
              style={{
                border: "none",
                borderRadius: "var(--bs-border-radius)",
                display: "block",
                height: "100%",
                width: "100%",
              }}
              title="PDF Viewer"
            />
          </div>
        ) : DOCX_FORMATS.includes(selectedFile.fileInfo.mimeType) ? (
          <RenderWordDoc selectedFile={selectedFile} />
        ) : EXCEL_FORMATS.includes(selectedFile.fileInfo.mimeType) ? (
          <RenderExcel file={selectedFile} />
        ) : (
          <img
            src={fileUrl}
            alt="Selected file"
            style={{
              borderRadius: "var(--bs-border-radius)",
              maxHeight: "100%",
              transform: "scale(0.8)",
              transformOrigin: "top left",
            }}
          />
        )}
        <p className="text-start me-4 pt-2" style={{ flexShrink: 0, fontSize: "10px", height: "45px" }}>
          File Name: {rtxOn ? selectedFile.fileInfo.name : selectedFile.fileInfo.fileName} <br />
          File Type: {selectedFile.fileInfo.mimeType} <br />
          Uploaded: {formatTimestamp(selectedFile.fileInfo.createdAt)} <br />
          Uploaded By: {selectedFile.fileInfo.creator.name} <br />
        </p>
      </div>
    );
  }, [rtxOn, selectedFile, setSelectedAttachment]);

  if (error) {
    return <div>Error: {error}</div>;
  }

  if (!loading)
    return (
      <div className="d-flex flex-column h-100">
        <Carousel
          activeIndex={index}
          indicators={false}
          onSelect={handleSelect}
          interval={null}
          nextIcon={<i className="bi bi-arrow-right-circle text-white fs-4 pb-4"></i>}
          prevIcon={<i className="bi bi-arrow-left-circle text-white fs-4 pb-4"></i>}
        >
          {fileChunks.map((chunk, idx) => (
            <Carousel.Item key={idx} style={{ height: "8em" }}>
              <div className="d-flex justify-content-center">
                {chunk.map((el) => (
                  <FileCard key={el.fileInfo.id} file={el} setSelectedFile={setSelectedFile} />
                ))}
              </div>
            </Carousel.Item>
          ))}
          {fileChunks.length === 0 && (
            <Carousel.Item>
              <Carousel.Caption>
                <h3>No files uploaded</h3>
                <p>Please upload some files to see them here.</p>
              </Carousel.Caption>
            </Carousel.Item>
          )}
        </Carousel>
        <div className="overflow-auto d-flex align-items-start h-100 justify-content-center">{selectedContent}</div>
      </div>
    );

  return (
    <div className="d-flex justify-content-center align-items-center flex-column" style={{ height: "70vh" }}>
      <Spinner />
    </div>
  );
}
