import { memo } from "react";

import { DeepDataObject } from "../../lib/Model";
import { VIDEO_FORMATS } from "../../utils/constants";
import { oldObjectRender } from "../../utils/objectUtils";

export const FileCard = memo(
  ({ file, setSelectedFile }: { file: DeepDataObject; setSelectedFile: (file: DeepDataObject) => void }) => {
    const handleDownload = (e: React.MouseEvent) => {
      e.stopPropagation(); // Prevent card selection

      const blob = new Blob([file.arrayBuffer], { type: file.fileInfo.mimeType });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = file.fileInfo.fileName ? file.fileInfo.fileName : file.fileInfo.name;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    };

    return (
      <div
        className="p-2 mb-5 d-flex justify-content-center"
        onClick={() => setSelectedFile(file)}
        style={{ cursor: "pointer" }}
      >
        <div className="d-flex flex-column align-items-center" style={{ width: "120px" }}>
          {VIDEO_FORMATS.includes(file.fileInfo.mimeType) ? (
            <video
              src={oldObjectRender(file)}
              className="file-card"
              style={{
                borderRadius: "4px",
                height: "4em",
                maxWidth: "7em",
                objectFit: "cover",
              }}
            />
          ) : (
            <img
              src={oldObjectRender(file)}
              alt="file icon placeholder"
              style={{
                borderRadius: "4px",
                height: "4em",
                maxWidth: "7em",
                objectFit: "cover",
              }}
            />
          )}
          <p
            className="text-center mt-2 mb-1"
            style={{
              display: "-webkit-box",
              fontSize: "0.8em",
              lineHeight: "1.2",
              overflow: "hidden",
              textOverflow: "ellipsis",
              WebkitBoxOrient: "vertical",
              WebkitLineClamp: 2,
              width: "100%",
            }}
          >
            {file.fileInfo.fileName ? file.fileInfo.fileName : file.fileInfo.name}{" "}
            <i onClick={handleDownload} className="bi bi-download"></i>
          </p>
        </div>
      </div>
    );
  }
);
