import { Component, ErrorInfo, ReactNode } from "react";

import { Alert, Button } from "react-bootstrap";

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { error, hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Caught in Error Boundary:", error, errorInfo);
  }

  handleReload = () => {
    this.setState({ error: undefined, hasError: false });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        this.props.fallback || (
          <Alert variant="danger m-3 text-center">
            <Alert.Heading className="mb-3">Something went wrong.</Alert.Heading>
            <Button variant="danger" onClick={this.handleReload}>
              Reload
            </Button>
          </Alert>
        )
      );
    }

    return this.props.children;
  }
}
