# Commit Message Quick Reference

## 📝 Format

```
type(scope): subject
```

## 📋 Types

| Type       | Description                           | Example                                   |
| ---------- | ------------------------------------- | ----------------------------------------- |
| `feat`     | A new feature                         | `feat(auth): add user login`              |
| `fix`      | A bug fix                             | `fix(ui): resolve button alignment`       |
| `docs`     | Documentation changes                 | `docs: update README`                     |
| `style`    | Code style changes (formatting, etc.) | `style: fix indentation`                  |
| `refactor` | Code refactoring                      | `refactor(api): extract validation logic` |
| `perf`     | Performance improvements              | `perf: optimize database queries`         |
| `test`     | Adding or fixing tests                | `test(utils): add date helper tests`      |
| `build`    | Build system or dependency changes    | `build: update webpack config`            |
| `ci`       | CI configuration changes              | `ci: add GitHub Actions workflow`         |
| `chore`    | Other changes (maintenance, etc.)     | `chore: update dependencies`              |
| `revert`   | Reverting a previous commit           | `revert: "feat: add user login"`          |

## 📏 Rules

- **Header max length**: 100 characters
- **Type**: Required, lowercase
- **Scope**: Optional, lowercase, in parentheses
- **Subject**: Required, any case (flexible for proper nouns, brand names, etc.)
- **No period**: Don't end the subject with a period

## ✅ Good Examples

```bash
feat(auth): add OAuth integration
fix(ui): resolve mobile responsive issues
docs: add API documentation
style(css): improve button styling
refactor: extract user validation logic
perf(db): optimize query performance
test: add unit tests for auth service
build: configure webpack for production
ci: add automated testing pipeline
chore: update eslint configuration

# Examples with proper nouns and technical terms
feat: add React Query integration
fix: resolve TypeScript compilation errors
docs: update README with Docker instructions
build: configure Webpack for production
feat: integrate Stripe payment API
fix: resolve CSS Grid layout issues
chore: update ESLint and Prettier configs
```

## ❌ Bad Examples

```bash
added new feature          # No type
FIX: bug in auth          # Type should be lowercase
feat: Add New Feature.    # Period at end (not allowed)
very long commit message that exceeds the maximum allowed length of 100 characters and will be rejected
```

## 🛠️ Testing Your Commit Message

Before committing, test your message:

```bash
# Test a commit message
./validate-commit-msg.sh "feat(ui): add dark mode toggle"

# Or use the npm script
pnpm commit-msg:test "fix: resolve login issue"
```

## 🚀 Quick Commit Workflow

```bash
# 1. Stage your changes
git add .

# 2. Test your commit message (optional)
./validate-commit-msg.sh "feat: add new feature"

# 3. Commit (will be validated automatically)
git commit -m "feat: add new feature"

# 4. Push (will run additional checks)
git push
```
