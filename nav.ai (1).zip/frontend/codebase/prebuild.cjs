// This script ensures that we can modify the context path for docker deployments using ENV variables inside Dockefiles.
const fs = require("fs");

const webcontextpath = process.env.VITE_APP_CONTEXT_PATH;

const packageJsonPath = "./package.json";
const packageJson = require(packageJsonPath);
packageJson.homepage = webcontextpath;

fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2));
