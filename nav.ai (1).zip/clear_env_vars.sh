#!/bin/bash

# Unset database-related environment variables
unset DB_PROVIDER
unset DB_POSTGRES_HOST
unset DB_POSTGRES_PASSWORD
unset DB_POSTGRES_PORT
unset DB_POSTGRES_USERNAME
unset DB_POSTGRES_DBNAME

# Unset application-related environment variables
unset APP_PORT
unset VITE_APP_CONTEXT_PATH
unset VITE_BACKEND_BASE_URL
unset VITE_APP_TOOLS_PREFIX
unset VITE_REDIRECT_URI
unset VITE_NVIDIA_VSS_BASE_URL
unset VITE_LOCAL_PROXY
unset DEFAULT_THEME
unset DEFAULT_PRIMARY_COLOR
unset DEFAULT_SECONDARY_COLOR
unset DEFAULT_EQTY_POLICY_PLANE

# Unset EQTY-related environment variables
unset EQTY_PROJECT
unset EQTY_GOV_URL
unset EQTY_ORG_ID
unset EQTY_API_KEY
unset EQTY_INDEX_USERID
unset EQTY_INDEX_PASSWD

# Unset authentication-related environment variables
unset AUTH_OPENID_AUTHORITY_URL
unset AUTH_OPENID_CLIENT_ID
unset AUTH_OPENID_CLIENT_SECRET
unset AUTH_OPENID_REDIRECT_URI
unset AUTH_PROVIDER

# Unset API-related environment variables
unset API_PORT
unset API_THREADS
unset APP_ENABLE_CORS
unset APP_APPLICATION_ROOT
unset APP_LOG_LEVEL
unset PYTHONPATH
unset FLASK_APP

# Unset MinIO-related environment variables
unset MINIO_ROOT_USER
unset MINIO_ROOT_PASSWORD
unset MINIO_ADDRESS
unset MINIO_CONSOLE_ADDRESS
unset MINIO_API_KEY
unset MINIO_SECRET_KEY
unset MINIO_CONVO_BUCKET
unset MINIO_REFERENCE_BUCKET

# Unset user-related environment variables
unset USER_VERSION
unset FRONTEND_COMMIT
unset BACKEND_COMMIT
unset FRONTEND_DEPLOYMENT_DATETIME
unset BACKEND_DEPLOYMENT_DATETIME
unset FRONTEND_BUILD_NUMBER
unset BACKEND_BUILD_NUMBER
unset FRONTEND_BUILD_DATETIME
unset BACKEND_BUILD_DATETIME

echo "All specified environment variables have been unset."
