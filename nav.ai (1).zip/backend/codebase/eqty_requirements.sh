#!/bin/bash
pip install -r requirements.txt
# curl https://sh.rustup.rs -sSf | sh -s -- -y --default-toolchain=1.79.0
pip install --index-url "http://accenture:eqtypartner@eqty-pypi.westus2.cloudapp.azure.com/simple/" --trusted-host eqty-pypi.westus2.cloudapp.azure.com eqty==2.1.3