# Maximum GPT Backend

## Run it quickly!

MaximumGPT is a python Flask application that works with minimal setup efforts. All you need to do is the following:
- Install python 3.12 or higher with pip.
- Navigate to <root-folder> of the project
- run `pip install -r requirements.txt`
- run `pip install -r requirements_pandasai.txt`

Now, set a few mandatory ENV variables to run with minimum configuration (e.g. in your dockerfile, in your IDE run configuration or by using an .env file in the maxgpt/api folder)

- **AUTH_PROVIDER=OPENID**

  one of [MSAL | OPENID], see Application Configuration > Authentication for details

- **DB_PROVIDER=SQL_LITE**

  one of [SQL_LITE | POSTGRES], see Persistence Application Configuration > Persistence for details

- **FLASK_APP=api/_main.py**
- **PYTHONPATH=<root-folder>/maxgpt**

  Setting PYTHONPATH is only required when running the app in your IDE and when you are not using PyCharm or IntelliJ.

A couple of optional environment variables are useful to set as well:

- APP_ENABLE_CORS=true

  Allow any origin for http requests, avoding CORS issues

- APP_LOG_LEVEL=DEBUG

  Default is INFO but setting it to DEBUG provides more dev relevant information

If you have the ENV variables in place, change your working directory to <root-folder>/maxgpt and run the application.

- run `python run.py`

The backend is now available at http://<your-host>:5002/. For example: http://127.0.0.1:5002/ by default.

At this point, you can follow the setup guide for application administrators to configure MaximumGPT modules (TBD) and the data expert guide to learn how to configure valuable data sources and assistants and how to work with conversations (TBD).

## Deploy it!

As for performance, security and stability reasons, you should not deploy the flask application using the embedded development server as in the section above.
To run MaximumGPT in production mode, do the following:

### In Unix
- Set ENV variable similar to the section above
- Change your working directory to <root-folder>/maxgpt
- run `python run.py --mode=PRODUCTION` (starts with 1 worker by default, use env variable API_THREADS to increase)

And if you just want to drop it in your docker engine, use the Dockerfile in the root of the project as template, build it and drop it in your engine. It follow the same workflow for deploying the application in production.

## Application Configuration

### Network configurations to run behind proxy servers

* **APP_ENABLE_CORS** - Either true or false. If true, CORS filters are accepting request from every origin
* **APP_APPLICATION_ROOT** - The context path of the application if it runs behind a proxy server. Must start with a / but end without.

### Authentication

MaximumGPT is supporting 4 types of authentication of which 2 are targeting development environments while the others are preferred to be used in production setups.
* **AUTH_PROVIDER** - A value of (_LOCAL_DEV | MSAL | OPENID | NONE)
  *  **NONE** - No authentication
  *  **_LOCAL_DEV** - No authentication required but a fake user is created if not existing yet
  * **MSAL** - Authentication with Azure EntraID
    * _AUTH_MSAL_TENANT_ID_ - The id of your Azure tenant
    * _AUTH_MSAL_APP_CLIENT_ID_ - The id of the client application inside your tenant
    * _AUTH_MSAL_API_SCOPE_ - The api scope required by your app. Defaults to 'user_impersonation'
    * _AUTH_MSAL_REDIRECT_URI_ - The redirect URL to which the authority should delegate requests after login. 
    * _AUTH_MSAL_AUTHORITY_ - The endpoint of your id authority. Defaults to 'https://login.microsoftonline.com/' + AUTH_MSAL_TENANT_ID.
  * **OPENID** - Using OpenID protocol to authenticate users. For example to attach the application to an existing KeyCloak instance.
    * _AUTH_OPENID_AUTHORITY_URL_ - The endpoint of your realm (e.g. https://host:port/realms/myRealm)
    * _AUTH_OPENID_CLIENT_ID_ - The id of the client application/instance inside the given realm
    * _AUTH_OPENID_CLIENT_SECRET_ - The client secret of the client application/instance inside the given realm (if needed)
    * _AUTH_OPENID_REDIRECT_URI_ - The redirect URL to which the authority should delegate requests after login
    * _AUTH_OPENID_RESPONSE_TYPE_ - Defaults to code _code_
    * _AUTH_OPENID_RESPONSE_SCOPE_ - Defaults to _openid profile email_
    * _AUTH_OPENID_VERIFY_EXPIRATION_ - Defines if access tokens will be verified for expiration. Defaults to False.


### Persistence

* **DB_PROVIDER** - Defines which application persistence to use. Currently available are SQL_LITE and POSTGRES. Defaults to SQL_LITE if not present.
    * In case DB_PROVIDER = **POSTGRES**, you need to specify all of the following variables:
      * **DB_POSTGRES_DBNAME** - Name of the postgres database
      * **DB_POSTGRES_HOST** - The ip address of the database host
      * **DB_POSTGRES_PASSWORD** - The password for the provided user to authenticate against the provided database
      * **DB_POSTGRES_PORT** - The port on which the postgresql server is listening for incoming connection
      * **DB_POSTGRES_USERNAME** - The username with access to the provided database
    * In case DB_PROVIDER = **SQL_LITE**, you can specify the following variables (optionally):
      * **DB_SQL_LITE_PATH** - The absolute path to the file where sqlite will store database data (Default - <working dir>/Persistence.db)

### Logging and Debugging

The root log level can be set using the ENV variable _APP_LOG_LEVEL_, which you can set to any of the levels available in 
pythons logging package (e.g. DEBUG | WARN | INFO | ERROR | ... )

To enable SQL tracing and log every sql statement to the log, you can set the env variable _APP_ENABLE_SQL_TRACE_ to true.

#### (Optional) Remote Debugging Configuration

If you want to remotely debug your application when it is hosted on a different machine than yours, enable the remote debugging
features with the following configurations. Please be aware that this feature should be restricted for error analysis if not possible
otherwise. You should disable this feature as soon as you finished your analysis.

* _DEBUGPY_ENABLED_ - True to activate. Default: False
* _DEBUGPY_HOST_ - The host running your application
* _DEBUGPY_PORT_ - The port to open for remote debugging clients to connect to
* _DEBUGPY_SUSPEND_ - If True, the application does not start before a remote debugging client is attached. If False, the remote debugging client can be attached at any time of the application runtime. Default: False

# Webservice API

The application comes with a fully documented OpenAPI spec plus a swagger-ui to test the API.
Once the application started, open your browser at http://<your-host>:5001/<context-path> (for example: http://127.0.0.1:5001/) and you will be forwarded to the swagger-ui interface.
Inside this UI, you will also find a link to the swagger.json specification file.
![image](./doc/img/userguide_swagger.png)

# EQTY Integration

Running the eqty_requirements.sh script will install the EQTY package required for enabling decorators in the backend code.

Additionally, add the following .env file for running the backend:

```
EQTY_PROJECT=maximumgpt
EQTY_GOV_URL=https://governance-studio.eqtylab.io
EQTY_ORG_ID=accenture
```

# Unit Testing

Set PATH=<root-folder>/tests/unittests:$PATH

- Create a test case (name will start with 'test_')
- Go to the project root directory
- OR
  - Run `pytest -v -s tests/unittests/test_name.py` to run a single set of tests
  - Run `(export EQTY_PROJECT="NavAIUnitTests"; export EQTY_GOV_URL="foo"; pytest -v -s tests/unittests/test_name.py)` to run a single set of tests with EQTY enabled
  - Run `pytest` (this will automatically find and execute all the tests in the project by looking for files that start with "test_" or function start with "test_")
  - Run `(export EQTY_PROJECT="NavAIUnitTests"; export EQTY_GOV_URL="foo"; pytest)` to run the tests with EQTY enabled
- To generate a report, run `pytest --html=report.html`
