from unittest import mock
from unittest.mock import MagicMock
from maxgpt.navai.api.impl.grants import EntityShareEndpoint, EntityPermissionsEndpoint
import pytest
import werkzeug.exceptions

def test_share_workspace(app, mock_security_functions):
    """Test sharing a workspace with users and roles."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [
                {"userId": "user_1", "permissionType": "READ"},
                {"userId": "user_2", "permissionType": "WRITE"}
            ],
            "rolePermissions": [
                {"roleId": "role_1", "permissionType": "READ"},
                {"roleId": "role_2", "permissionType": "WRITE"}
            ]
        }, query_string={"entityType": "WORKSPACE", "entityId": "workspace_1"}):
            workspace_id = "workspace_1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace.creator_id = "mock_user_id"
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock current user to be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        response = endpoint.post()

                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions updated successfully"

def test_update_workspace_sharing(app, mock_security_functions):
    """Test updating workspace sharing permissions."""
    with app.app_context():
        with app.test_request_context(method='PUT', json={
            "userPermissions": [
                {"userId": "user_1", "permissionType": "WRITE"},
                {"userId": "user_2", "permissionType": "READ"}
            ],
            "rolePermissions": [
                {"roleId": "role_1", "permissionType": "WRITE"},
                {"roleId": "role_2", "permissionType": "READ"}
            ]
        }):
            workspace_id = "workspace_1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace.creator_id = "mock_user_id"
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock current user to be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityPermissionsEndpoint()
                        response = endpoint.put("WORKSPACE", workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions updated successfully"
                        assert response_data["details"]["entity"]["id"] == workspace_id
                        assert len(response_data["details"]["users_updated"]) == 2
                        assert len(response_data["details"]["roles_updated"]) == 2

def test_remove_workspace_sharing(app, mock_security_functions):
    """Test removing workspace sharing permissions."""
    with app.app_context():
        with app.test_request_context(method='DELETE', json={
            "userIds": ["user_1", "user_2"],
            "roleIds": ["role_1", "role_2"]
        }):
            workspace_id = "workspace_1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace.creator_id = "mock_user_id"
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock current user to be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityPermissionsEndpoint()
                        response = endpoint.delete("WORKSPACE", workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions deleted successfully"
                        assert response_data["details"]["entity"]["id"] == workspace_id
                        assert len(response_data["details"]["users_updated"]) == 2
                        assert len(response_data["details"]["roles_updated"]) == 2

def test_share_workspace_unauthorized(app, mock_security_functions):
    """Test sharing a workspace without proper permissions."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [{"userId": "user_1", "permissionType": "READ"}],
            "rolePermissions": []
        }, query_string={"entityType": "WORKSPACE", "entityId": "workspace_1"}):
            workspace_id = "workspace_1"
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace.creator_id = "creator_id"
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock current user to NOT be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "not_creator_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        
                        # Expect a 403 Forbidden exception
                        with pytest.raises(werkzeug.exceptions.Forbidden) as exc_info:
                            endpoint.post()
                        
                        # Verify the error message
                        assert "403 Forbidden" in str(exc_info.value)

def test_share_workspace_not_found(app, mock_security_functions):
    """Test sharing a non-existent workspace."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [{"userId": "user_1", "permissionType": "READ"}],
            "rolePermissions": []
        }, query_string={"entityType": "WORKSPACE", "entityId": "non_existent_workspace"}):
            workspace_id = "non_existent_workspace"
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace_query.get.return_value = None
                
                # Mock current user
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        
                        # Expect a 404 Not Found exception
                        with pytest.raises(werkzeug.exceptions.NotFound) as exc_info:
                            endpoint.post()
                        
                        # Verify the error message
                        assert "404 Not Found" in str(exc_info.value) 