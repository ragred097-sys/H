from unittest import mock
from unittest.mock import MagicMock
from maxgpt.navai.api.impl.grants import EntityShareEndpoint, EntityPermissionsEndpoint
from flask import jsonify
import pytest
import werkzeug.exceptions

def test_share_assistant(app, mock_security_functions):
    """Test sharing an assistant with users and roles."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [
                {"userId": "user_1", "permissionType": "READ"},
                {"userId": "user_2", "permissionType": "WRITE"}
            ],
            "rolePermissions": [
                {"roleId": "role_1", "permissionType": "READ"},
                {"roleId": "role_2", "permissionType": "WRITE"}
            ]
        }, query_string={"entityType": "ASSISTANT", "entityId": "assistant_1"}):
            assistant_id = "assistant_1"
            
            # Mock the AssistantModel.query.get() method
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant = MagicMock()
                mock_assistant.id = assistant_id
                mock_assistant.creator_id = "mock_user_id"
                mock_assistant_query.get.return_value = mock_assistant
                
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        response = endpoint.post()
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions updated successfully"

def test_update_assistant_sharing(app, mock_security_functions):
    """Test updating assistant sharing permissions."""
    with app.app_context():
        with app.test_request_context(method='PUT', json={
            "userPermissions": [
                {"userId": "user_1", "permissionType": "WRITE"},
                {"userId": "user_2", "permissionType": "READ"}
            ],
            "rolePermissions": [
                {"roleId": "role_1", "permissionType": "WRITE"},
                {"roleId": "role_2", "permissionType": "READ"}
            ]
        }):
            assistant_id = "assistant_1"
            
            # Mock the AssistantModel.query.get() method
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant = MagicMock()
                mock_assistant.id = assistant_id
                mock_assistant.creator_id = "mock_user_id"
                mock_assistant_query.get.return_value = mock_assistant
                
                # Mock current user to be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityPermissionsEndpoint()
                        response = endpoint.put("ASSISTANT", assistant_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions updated successfully"

def test_remove_assistant_sharing(app, mock_security_functions):
    """Test removing assistant sharing permissions."""
    with app.app_context():
        with app.test_request_context(method='DELETE', json={
            "userIds": ["user_1", "user_2"],
            "roleIds": ["role_1", "role_2"]
        }):
            assistant_id = "assistant_1"
            
            # Mock the AssistantModel.query.get() method
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant = MagicMock()
                mock_assistant.id = assistant_id
                mock_assistant.creator_id = "mock_user_id"
                mock_assistant_query.get.return_value = mock_assistant
                
                # Mock current user to be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    # Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityPermissionsEndpoint()
                        response = endpoint.delete("ASSISTANT", assistant_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["message"] == "Permissions deleted successfully"

def test_share_assistant_unauthorized(app, mock_security_functions):
    """Test sharing an assistant without proper permissions (not creator)."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [{"userId": "user_1", "permissionType": "READ"}],
            "rolePermissions": []
        }, query_string={"entityType": "ASSISTANT", "entityId": "assistant_1"}):
            assistant_id = "assistant_1"
            
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant = MagicMock()
                mock_assistant.id = assistant_id
                mock_assistant.creator_id = "creator_id"
                mock_assistant_query.get.return_value = mock_assistant
                
                #Mock current user to NOT be the creator
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "not_creator_id"
                    mock_get_user.return_value = mock_user
                    
                    #Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        
                        with pytest.raises(werkzeug.exceptions.Forbidden) as exc_info:
                            endpoint.post()
                        
                        # Verify the error message
                        assert "403 Forbidden" in str(exc_info.value)

def test_share_assistant_not_found(app, mock_security_functions):
    """Test sharing a non-existent assistant."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "userPermissions": [{"userId": "user_1", "permissionType": "READ"}],
            "rolePermissions": []
        }, query_string={"entityType": "ASSISTANT", "entityId": "non_existent_assistant"}):
            assistant_id = "non_existent_assistant"
            
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant_query.get.return_value = None
                
                #Mock current user
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    
                    #Mock the database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = EntityShareEndpoint()
                        
                        with pytest.raises(werkzeug.exceptions.NotFound) as exc_info:
                            endpoint.post()
                        
                        #Verify the error message
                        assert "404 Not Found" in str(exc_info.value)