import pytest
from unittest import mock 
from maxgpt.navai.api.impl.tags import NavAITagsEndpoint, TagsNavAIEndpoint, ns
from werkzeug.exceptions import NotFound 


def test_get_tag_entities_success(app, mock_tags, mock_tag_entities, mock_security_function_permission):
    """Test getting all entity types associated with a specific tag ID (success)."""
    with app.app_context():
        with app.test_request_context('/navai/tag/1', method='GET'):
            _ = mock_security_function_permission
            tag_id = mock_tags['base_tag'].to_dict()['id']
            with mock.patch('maxgpt.services.database.session'), \
                 mock.patch('maxgpt.navai.api.impl.tags.TagModel.query') as mock_query, \
                 mock.patch('maxgpt.api.internal.utils._get_tag_assistants', return_value=mock_tag_entities['assistant']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_agents', return_value=mock_tag_entities['agent']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_agent_workflows', return_value=mock_tag_entities['workflow']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_conversations', return_value=mock_tag_entities['conversation']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_data_sources', return_value=mock_tag_entities['data_source']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_system_instructions', return_value=mock_tag_entities['system_instruction']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_modules', return_value=mock_tag_entities['module']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_workspaces', return_value=mock_tag_entities['workspace']), \
                 mock.patch('maxgpt.api.internal.utils._get_tag_widgets', return_value=mock_tag_entities['widget']):
                mock_query.filter.return_value.first.return_value = mock_tags['base_tag']
                endpoint = NavAITagsEndpoint()
                response = endpoint.get(tag_id)
                assert response.status_code == 200
                data = response.get_json()
                #check a few keys and types 
                assert isinstance(data, dict)
                assert "assistant" in data
                assert isinstance(data["assistant"], list)


def test_get_tag_entities_not_found(app, mock_security_function_permission):
    """Test getting all entity types for a non-existent tag (should 404)."""
    with app.app_context():
        with app.test_request_context('/navai/tag/nonexistent', method='GET'):
            _ = mock_security_function_permission
            tag_id = 'nonexistent_tag_id'
            with mock.patch('maxgpt.services.database.session'), \
                 mock.patch('maxgpt.navai.api.impl.tags.TagModel.query') as mock_query, \
                 mock.patch('maxgpt.navai.api.impl.tags.ns.abort', side_effect=NotFound) as mock_abort:
                mock_query.filter.return_value.first.return_value = None
                endpoint = NavAITagsEndpoint()
                with pytest.raises(NotFound):
                    endpoint.get(tag_id)
                mock_abort.assert_called_once()
                


def test_get_all_tags_with_entity_counts(app, mock_tags, mock_security_function_permission):
    """Test getting all tags with entity counts."""
    with app.app_context():
        with app.test_request_context('/navai/tags', method='GET'):
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database.session'), \
                 mock.patch('maxgpt.navai.api.impl.tags.TagModel.query') as mock_query, \
                 mock.patch('maxgpt.api.internal.utils.get_entity_count_for_tag', return_value=5):
                mock_query.filter.return_value.all.return_value = mock_tags['all_tags']
                endpoint = TagsNavAIEndpoint()
                response = endpoint.get()
                assert response.status_code == 200
                data = response.get_json()
                assert isinstance(data, list)
                assert len(data) == len(mock_tags['all_tags'])
                # Just check the first tag for expected keys
                if data:
                    tag = data[0]
                    assert "id" in tag
                    assert "entity_count" in tag
