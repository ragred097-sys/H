from unittest import mock
from maxgpt.api.impl.application_settings import (
    ApplicationSettingsEndpoint,
    ApplicationSettingFactoryEndpoint,
    ApplicationSettingEndpoint
)

def test_get_all_application_settings(app, mock_security_functions, mock_application_settings):
    """Test GET /application/settings/ returns all application settings for any authenticated user."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query:
                mock_query.all.return_value = mock_application_settings['all_settings']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = ApplicationSettingsEndpoint()
                    response = endpoint.get()
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert isinstance(response_data, list)
                    assert len(response_data) == 2
                    assert response_data[0]["id"] == "setting-1"
                    assert response_data[1]["id"] == "setting-2"


def test_create_application_setting_admin(app, mock_security_functions, mock_application_settings):
    """Test POST /application/setting/ creates a new application setting (admin only)."""
    post_data = {
        "preferenceId": "pref-app-1",
        "value": "test-value"
    }
    with app.app_context():
        with app.test_request_context(method='POST', json=post_data):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.security.ShallowUser.to_dict', 
                        return_value={'id': 'user123', 'name': 'Test User'}):

                with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                    mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                    mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_pref_query:
                    admin_user = mock.MagicMock()
                    admin_role = mock.MagicMock()
                    admin_role.id = "administrator"
                    admin_role.name = "administrator"
                    admin_user.effective_app_roles = [admin_role]
                    admin_user.get_id.return_value = "admin"
                    admin_user.get_display_name.return_value = "Admin User"
                    mock_user_query.filter.return_value.first.return_value = admin_user
                    mock_role = mock.MagicMock()
                    mock_role.application_access_role.name = "administrator"
                    mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                    mock_pref_query.get.return_value = mock_application_settings['mock_preference']
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.add = mock.MagicMock()
                        mock_db_session.commit = mock.MagicMock()
                        with mock.patch('maxgpt.services.database_model.ApplicationSettingModel', autospec=True) as mock_setting_model:
                            setting = mock_application_settings['base_setting']
                            setting.creator = admin_user
                            setting.modifier = admin_user
                            setting.creator_id = admin_user.get_id()
                            setting.modifier_id = admin_user.get_id()
                            mock_setting_model.return_value = setting
                            endpoint = ApplicationSettingFactoryEndpoint()
                            response = endpoint.post()
                            response_data = response.get_json()
                            assert response.status_code == 200
                            assert response_data["preferenceId"] == "pref-app-1"
                            assert response_data["value"] == "test-value"
                            assert "id" in response_data


def test_get_application_setting_by_id_admin(app, mock_security_functions, mock_application_settings):
    """Test GET /application/setting/{preference_id}/ returns the setting for admin."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database.session') as mock_db_session:
                admin_user = mock.MagicMock()
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                admin_user.effective_app_roles = [admin_role]
                admin_user.get_id.return_value = "admin"
                admin_user.get_display_name.return_value = "Admin User"
                mock_user_query.filter.return_value.first.return_value = admin_user

                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                setting = mock_application_settings['base_setting']
                setting.creator = admin_user
                mock_query.filter_by.return_value.first.return_value = setting
                endpoint = ApplicationSettingEndpoint()
                response = endpoint.get("pref-app-1")
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data["preferenceId"] == "pref-app-1"
                assert response_data["id"] == "setting-1"


def test_update_application_setting_admin(app, mock_security_functions, mock_application_settings):
    """Test PUT /application/setting/{preference_id}/ updates the setting (admin only)."""
    put_data = {"value": "updated-value"}
    with app.app_context():
        with app.test_request_context(method='PUT', json=put_data):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query:
                admin_user = mock.MagicMock()
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                admin_user.effective_app_roles = [admin_role]
                admin_user.get_id.return_value = "admin"
                mock_user_query.filter.return_value.first.return_value = admin_user

                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                mock_query.filter_by.return_value.first.return_value = mock_application_settings['base_setting']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    mock_application_settings['base_setting'].value = "updated-value"
                    mock_application_settings['base_setting'].to_dict.return_value["value"] = "updated-value"
                    endpoint = ApplicationSettingEndpoint()
                    response = endpoint.put("pref-app-1")
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert response_data["value"] == "updated-value"


def test_delete_application_setting_admin(app, mock_security_functions, mock_application_settings):
    """Test DELETE /application/setting/{preference_id}/ deletes the setting (admin only)."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query:
                admin_user = mock.MagicMock()
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                admin_user.effective_app_roles = [admin_role]
                admin_user.get_id.return_value = "admin"
                mock_user_query.filter.return_value.first.return_value = admin_user

                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                mock_query.filter_by.return_value.first.return_value = mock_application_settings['base_setting']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.delete = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    endpoint = ApplicationSettingEndpoint()
                    response = endpoint.delete("pref-app-1")
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert response_data["id"] == "setting-1"
                    mock_db_session.delete.assert_called_once_with(mock_application_settings['base_setting'])


def test_create_application_setting_non_admin_forbidden(app, mock_security_functions, mock_application_settings):
    post_data = {
        "preferenceId": "pref-app-1",
        "value": "test-value"
    }
    with app.app_context():
        with app.test_request_context(method='POST', json=post_data):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_pref_query:
                # Patch non-admin user
                user = mock.MagicMock()
                user.get_id.return_value = "user"
                user.get_display_name.return_value = "Normal User"
                user.effective_app_roles = []
                mock_user_query.filter.return_value.first.return_value = user
                mock_role_query.join.return_value.filter.return_value.all.return_value = []
                mock_pref_query.get.return_value = mock_application_settings['mock_preference']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.add = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    with mock.patch('maxgpt.services.database_model.ApplicationSettingModel', autospec=True) as mock_setting_model:
                        setting = mock_application_settings['base_setting']
                        setting.creator = user
                        setting.modifier = user
                        setting.creator_id = user.get_id()
                        setting.modifier_id = user.get_id()
                        mock_setting_model.return_value = setting
                        endpoint = ApplicationSettingFactoryEndpoint()
                        import pytest
                        with pytest.raises(Exception) as excinfo:
                            endpoint.post()
                        assert "401" in str(excinfo.value)


def test_get_application_setting_by_id_non_admin_forbidden(app, mock_security_functions, mock_application_settings):
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database.session') as mock_db_session:
                user = mock.MagicMock()
                user.get_id.return_value = "user"
                user.get_display_name.return_value = "Normal User"
                user.effective_app_roles = []
                mock_user_query.filter.return_value.first.return_value = user
                mock_role_query.join.return_value.filter.return_value.all.return_value = []
                setting = mock_application_settings['base_setting']
                setting.creator = user
                setting.modifier = user
                setting.creator_id = user.get_id()
                setting.modifier_id = user.get_id()
                mock_query.filter_by.return_value.first.return_value = setting
                endpoint = ApplicationSettingEndpoint()
                import pytest
                with pytest.raises(Exception) as excinfo:
                    endpoint.get("pref-app-1")
                assert "401" in str(excinfo.value)


def test_update_application_setting_non_admin_forbidden(app, mock_security_functions, mock_application_settings):
    put_data = {"value": "updated-value"}
    with app.app_context():
        with app.test_request_context(method='PUT', json=put_data):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query:
                user = mock.MagicMock()
                user.get_id.return_value = "user"
                user.get_display_name.return_value = "Normal User"
                user.effective_app_roles = []
                mock_user_query.filter.return_value.first.return_value = user
                mock_role_query.join.return_value.filter.return_value.all.return_value = []
                setting = mock_application_settings['base_setting']
                setting.creator = user
                setting.modifier = user
                setting.creator_id = user.get_id()
                setting.modifier_id = user.get_id()
                mock_query.filter_by.return_value.first.return_value = setting
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    import pytest
                    with pytest.raises(Exception) as excinfo:
                        endpoint = ApplicationSettingEndpoint()
                        endpoint.put("pref-app-1")
                    assert "401" in str(excinfo.value)


def test_delete_application_setting_non_admin_forbidden(app, mock_security_functions, mock_application_settings):
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query, \
                 mock.patch('maxgpt.services.database_model.ApplicationSettingModel.query') as mock_query:
                user = mock.MagicMock()
                user.get_id.return_value = "user"
                user.get_display_name.return_value = "Normal User"
                user.effective_app_roles = []
                mock_user_query.filter.return_value.first.return_value = user
                mock_role_query.join.return_value.filter.return_value.all.return_value = []
                setting = mock_application_settings['base_setting']
                setting.creator = user
                setting.modifier = user
                setting.creator_id = user.get_id()
                setting.modifier_id = user.get_id()
                mock_query.filter_by.return_value.first.return_value = setting
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.delete = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    import pytest
                    with pytest.raises(Exception) as excinfo:
                        endpoint = ApplicationSettingEndpoint()
                        endpoint.delete("pref-app-1")
                    assert "401" in str(excinfo.value)

