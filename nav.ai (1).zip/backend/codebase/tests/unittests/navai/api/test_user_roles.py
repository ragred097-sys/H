from unittest import mock
from unittest.mock import MagicMock
from maxgpt.navai.api.impl.user_roles import NavAIBatchUserRolesEndpoint
import pytest
import werkzeug.exceptions

def test_get_user_access_roles(app, mock_security_functions):
    """Test getting access roles for multiple users."""
    with app.app_context():
        with app.test_request_context(method='POST', json={'userIds': ['user_1', 'user_2']}):
            # Mock the current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "current_user"
                mock_get_user.return_value = mock_user
                
                # Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock the UserApplicationAccessRoleRelationModel query
                    with mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_mapping_query:
                        # Create mock mappings
                        mock_mapping1 = MagicMock()
                        mock_mapping1.user_id = "user_1"
                        mock_mapping1.application_access_role = MagicMock()
                        mock_mapping1.application_access_role.id = "role_1"
                        mock_mapping1.application_access_role.name = "Role 1"
                        mock_mapping1.application_access_role.description = "Test Role 1"
                        mock_mapping1.application_access_role.deleted_at = None
                        
                        mock_mapping2 = MagicMock()
                        mock_mapping2.user_id = "user_2"
                        mock_mapping2.application_access_role = MagicMock()
                        mock_mapping2.application_access_role.id = "role_2"
                        mock_mapping2.application_access_role.name = "Role 2"
                        mock_mapping2.application_access_role.description = "Test Role 2"
                        mock_mapping2.application_access_role.deleted_at = None
                        
                        def filter_by_side_effect(**kwargs):
                            if kwargs.get('user_id') == 'user_1':
                                return MagicMock(all=MagicMock(return_value=[mock_mapping1]))
                            elif kwargs.get('user_id') == 'user_2':
                                return MagicMock(all=MagicMock(return_value=[mock_mapping2]))
                            else:
                                return MagicMock(all=MagicMock(return_value=[]))
                        mock_mapping_query.filter_by.side_effect = filter_by_side_effect
                        
                        endpoint = NavAIBatchUserRolesEndpoint()
                        response = endpoint.post()
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert "user_1" in response_data
                        assert "user_2" in response_data
                        assert len(response_data["user_1"]) == 1
                        assert len(response_data["user_2"]) == 1
                        assert response_data["user_1"][0]["id"] == "role_1"
                        assert response_data["user_2"][0]["id"] == "role_2"

def test_get_user_access_roles_unauthorized(app, mock_security_functions):
    """Test getting access roles without authentication."""
    with app.app_context():
        with app.test_request_context(method='POST', json={'userIds': ['user_1', 'user_2']}):
            # Mock the current user to be None
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_get_user.return_value = None
                
                # Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = NavAIBatchUserRolesEndpoint()
                    
                    # Expect a 401 Unauthorized exception
                    with pytest.raises(werkzeug.exceptions.Unauthorized) as exc_info:
                        endpoint.post()
                    assert "401 Unauthorized" in str(exc_info.value)

def test_get_user_access_roles_no_user_ids(app, mock_security_functions):
    """Test getting access roles without providing user IDs."""
    with app.app_context():
        with app.test_request_context(method='POST', json={}):
            # Mock the current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "current_user"
                mock_get_user.return_value = mock_user
                
                # Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = NavAIBatchUserRolesEndpoint()
                    
                    # Expect a 400 Bad Request exception
                    with pytest.raises(werkzeug.exceptions.BadRequest) as exc_info:
                        endpoint.post()
                    assert "400 Bad Request" in str(exc_info.value)

def test_get_user_access_roles_empty_result(app, mock_security_functions):
    """Test getting access roles when no mappings exist."""
    with app.app_context():
        with app.test_request_context(method='POST', json={'userIds': ['user_1', 'user_2']}):
            # Mock the current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "current_user"
                mock_get_user.return_value = mock_user
                
                # Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock the UserApplicationAccessRoleRelationModel query to return empty list
                    with mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_mapping_query:
                        def filter_by_side_effect(**kwargs):
                            return MagicMock(all=MagicMock(return_value=[]))
                        mock_mapping_query.filter_by.side_effect = filter_by_side_effect
                        
                        endpoint = NavAIBatchUserRolesEndpoint()
                        response = endpoint.post()
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data == {'user_1': [], 'user_2': []}