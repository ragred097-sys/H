from unittest import mock 
from unittest.mock import MagicMock

from maxgpt.api.impl.system_instruction import SystemInstructionFactoryEndpoint, SystemInstructionsEndpoint, SystemInstructionEndpoint
from maxgpt.services.database_model import SystemInstructionModel, PermissionType

def test_get_system_instruction(app, mock_security_function_permission, mock_workspaces, mock_system_instructions):
    """Test the get_system_instruction endpoint functionality."""
    with app.app_context():  
        with app.test_request_context(): 
            _ = mock_security_function_permission  
            
            # Mock user query
            with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_user_query:
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user

                # Mock workspace permissions
                with mock.patch('maxgpt.api.impl.system_instruction.fetch_with_permissions') as mock_fetch:
                    mock_fetch.return_value = mock_system_instructions['all_system_instructions']

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        
                        endpoint = SystemInstructionsEndpoint() 
                        response = endpoint.get()

                        response_data = response.get_json()
                        print("Response Data:", response_data)
                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert len(response_data) == 2, "Expected 2 instruction in response"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Instruction 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Instruction 2"

def test_create_system_instruction(app, mock_security_functions,mock_system_instructions):
    """Test creating a new preference."""

    with app.app_context():
        with app.test_request_context(method='POST', json={
            "id": "new-uuid",
            "name": "New System_instruction",
            "description": "SystemInstruction description",
            "message": "Message for new instruction ",
            "tags": [],
             
            
        }):
            # Create mock user
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }

            mock_system_instructions['new_system_instruction'].creator = mock_user

            with mock.patch('maxgpt.services.security.ShallowUser.to_dict', 
                            return_value={'id': 'user123', 'name': 'Test User'}):

                with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_user_query:
                    mock_user_query.filter.return_value.first.return_value = mock_user

                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                        mock_get_current_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database_model.SystemInstructionModel') as mock_system_instruction_model:
                            mock_system_instruction_model.return_value = mock_system_instructions['new_system_instruction']

                            # with mock.patch('maxgpt.api.impl.workspace.with_favorite', 
                            #               return_value=mock_workspaces['new_workspace'].to_dict()):
                            with mock.patch('maxgpt.api.impl.system_instruction.with_access_permission', 
                                          return_value=mock_system_instructions['new_system_instruction'].to_dict()):

                                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                    mock_db_session.add = mock.MagicMock()
                                    mock_db_session.commit = mock.MagicMock()

                                    # Create and test endpoint
                                    endpoint = SystemInstructionFactoryEndpoint()
                                    response = endpoint.post()

                                    assert response.status_code == 200
                                    response_data = response.get_json()
                                    print("**************Response DATA*********************", response_data)
                                    
                                    # Validate basic fields
                                    assert response_data["name"] == "New System_instruction"
                                    assert "description" in response_data
                                    assert response_data["id"] == "new-uuid"
                                    assert response_data["message"] == "Message for new instruction "
                                    
                                    
                                    assert response_data["__type_name"] == "SystemInstruction"
                                    
                                    # Validate tags
                                    assert "tags" in response_data
                                    assert isinstance(response_data["tags"], list)
                                    assert len(response_data["tags"]) == 0
                                    
                                    # Check optional fields
                                    if "creator" in response_data:
                                        assert response_data["creator"]["id"] == "user123"
                                        assert response_data["creator"]["name"] == "Test User"
                                    
                                    if "accessPermission" in response_data:
                                        assert response_data["accessPermission"] in ["READ", "WRITE", "ADMIN"]

def test_update_system_instruction(app, mock_security_functions, mock_system_instructions):
    """Test update(PUT) of a system instruction."""
    with app.app_context():
        with app.test_request_context(method='PUT', json={
            "message": "Updated message",
            "name": "Updated Name"
        }):
            mock_instruction = mock_system_instructions['new_system_instruction']
            mock_instruction.deleted_at = None
            mock_instruction.id = "new-uuid"

            # Patch permission to WRITE using PermissionType enum
            with mock.patch('maxgpt.api.impl.system_instruction.get_user_access_for', return_value=PermissionType.WRITE):
                with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_query:
                    mock_query.get.return_value = mock_instruction
                    
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user123"
                        mock_get_current_user.return_value = mock_user
                        
                        with mock.patch('maxgpt.api.impl.system_instruction.with_access_permission', return_value=mock_instruction.to_dict()):
                            with mock.patch('maxgpt.api.impl.system_instruction.with_hidden', side_effect=lambda x, y: x):
                                with mock.patch('maxgpt.api.impl.system_instruction.with_favorite', side_effect=lambda x, y: x):
                                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                        mock_db_session.commit = mock.MagicMock()
                                        # Patch Session.object_session
                                        with mock.patch('flask_sqlalchemy.session.Session.object_session', return_value=mock_db_session):
                                            endpoint = SystemInstructionEndpoint()
                                            response = endpoint.put("new-uuid")
                                            
                                            assert response.status_code == 200
                                            response_data = response.get_json()
                                            assert response_data["message"] == "Message for new instruction " or response_data["message"] == "Updated message"
                                            assert response_data["name"] == "New System_instruction" or response_data["name"] == "Updated Name"

def test_delete_system_instruction(app, mock_security_functions, mock_system_instructions):
    """Test deletion of a system instruction."""
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            mock_instruction = mock_system_instructions['new_system_instruction']
            mock_instruction.deleted_at = None
            mock_instruction.id = "new-uuid"

            with mock.patch('maxgpt.api.impl.system_instruction.get_user_access_for', return_value=PermissionType.WRITE):
                with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_query:
                    mock_query.get.return_value = mock_instruction
                    
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user123"
                        mock_get_current_user.return_value = mock_user
                        
                        with mock.patch('maxgpt.api.impl.system_instruction.with_access_permission', return_value=mock_instruction.to_dict()):
                            with mock.patch('maxgpt.api.impl.system_instruction.with_hidden', side_effect=lambda x, y: x):
                                with mock.patch('maxgpt.api.impl.system_instruction.with_favorite', side_effect=lambda x, y: x):
                                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                        mock_db_session.commit = mock.MagicMock()
                                        mock_db_session.delete = mock.MagicMock()
                                        
                                        endpoint = SystemInstructionEndpoint()
                                        response = endpoint.delete("new-uuid")
                                        
                                        assert response.status_code == 200
                                        response_data = response.get_json()
                                        assert response_data["id"] == "new-uuid"