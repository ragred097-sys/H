from unittest import mock
from maxgpt.api.impl.preferences import PreferencesEndpoint, UserEndpoint, PreferenceFactoryEndpoint
from maxgpt.services.database_model import PreferenceScope
from maxgpt.core import DataType
from maxgpt.api import EntityType 
from werkzeug.exceptions import BadRequest, NotFound

def test_get_preferences(app, mock_security_functions, mock_preferences):
    """Test getting all preferences."""
    # Dummy reference to avoid "unused variable" warning
    _ = mock_security_functions

    with app.app_context():
        with app.test_request_context():
            # Mock the PreferenceModel.query.all() method to return mock preferences
            with mock.patch('maxgpt.api.impl.preferences.SessionContext.is_administrator', return_value=True), \
                 mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database.session'):

                mock_query.order_by.return_value.all.return_value = mock_preferences['all_preferences']

                endpoint = PreferencesEndpoint()
                response = endpoint.get()

                # Assertions
                assert response.status_code == 200
                response_data = response.get_json()
                assert response_data is not None
                assert len(response_data) == 2
                assert response_data[0]["id"] == "1"
                assert response_data[0]["name"] == "Preference 1"
                assert response_data[1]["id"] == "2"
                assert response_data[1]["name"] == "Preference 2"

def test_get_preference_by_id(app, mock_security_functions, mock_preferences):
    """Test getting a preference by its ID."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                mock_query.get.return_value = mock_preferences['base_preference']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    endpoint = UserEndpoint()
                    response = endpoint.get("1")
                    
                    # Assertions
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "1"
                    assert response_data["name"] == "Preference 1"
                    assert response_data["label"] == "Test Preference 1"
                    assert response_data["description"] == "Test Description 1"

def test_delete_preference(app, mock_security_functions, mock_preferences):
    """Test deleting a preference."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                mock_query.get.return_value = mock_preferences['base_preference']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = UserEndpoint()
                    response = endpoint.delete("1")
                    
                    # Assertions
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "1"
                    assert response_data["name"] == "Preference 1"
                    
                    # Verify the preference was deleted from the database
                    mock_db_session.delete.assert_called_once_with(mock_preferences['base_preference'])

def test_create_preference(app, mock_security_functions, mock_preferences):
    """Test creating a new preference.""" 
    
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "name": "New Preference",
            "label": "Test New Preference",
            "description": "Test Description",
            "type": "text",
            "scope": "user"
        }):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions  
            with mock.patch('maxgpt.services.database_model.PreferenceModel') as mock_preference_model:
                # Configure the mock to return our mock instance
                mock_preference_model.return_value = mock_preferences['new_preference']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock the session.add() method
                    mock_db_session.add = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    
                    # Create and call endpoint
                    endpoint = PreferenceFactoryEndpoint()
                    response = endpoint.post()
                    
                    # Assertions
                    assert response.status_code == 200
                    response_data = response.get_json()
                    print("**************Response DATA*********************",response_data)
                    # Verify response data
                    assert response_data["name"] == "New Preference"
                    assert response_data["label"] == "Test New Preference"
                    assert response_data["description"] == "Test Description"
                    assert response_data["type"] == DataType.TEXT.value
                    assert response_data["scope"] == PreferenceScope.USER.value
                    assert response_data["__type_name"] == EntityType.PREFERENCE.value

def test_update_preference(app, mock_security_functions, mock_preferences):
    """Test updating an existing preference."""  
    with app.app_context():
        # Prepare update data
        update_data = {
            "name": "Updated Preference",
            "label": "Updated Test Preference",
            "description": "Updated Description"
        }
        
        with app.test_request_context(method='PUT', json=update_data):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions 
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                # Configure the mock to return our existing preference
                mock_query.get.return_value = mock_preferences['updated_preference']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock the session.commit() method
                    mock_db_session.commit = mock.MagicMock()
                    
                    # Create and call endpoint
                    endpoint = UserEndpoint()
                    response = endpoint.put("1")  
                    
                    # Assertions
                    assert response.status_code == 200
                    response_data = response.get_json()
                    
                    # Verify response data
                    assert response_data["id"] == "1"
                    assert response_data["name"] == "Updated Preference"
                    assert response_data["label"] == "Updated Test Preference"
                    assert response_data["description"] == "Updated Description"
                    assert response_data["type"] == DataType.TEXT.value
                    assert response_data["scope"] == PreferenceScope.USER.value
                    assert response_data["__type_name"] == EntityType.PREFERENCE.value

def test_update_preference_invalid_type_change(app, mock_security_functions, mock_preferences):
    """Test that updating a preference's type is not allowed.""" 
    with app.app_context():
        # Try to update the type
        update_data = {
            "type": "integer"  # Attempting to change type from TEXT to INTEGER
        }
        
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions
            
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                # Configure the mock preference with TEXT type
                mock_preferences['base_preference'].type = DataType.TEXT
                mock_query.get.return_value = mock_preferences['base_preference']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                # Create and call endpoint
                    endpoint = UserEndpoint()

                    # The endpoint should raise a BadRequest exception
                    try:
                        endpoint.put("1")
                        assert False, "Expected BadRequest exception was not raised"
                    except BadRequest as e:
                        assert e.code == 400

def test_update_preference_invalid_scope_change(app, mock_security_functions, mock_preferences):
    """Test that updating a preference's scope is not allowed."""  
    with app.app_context(): 
        update_data = {
            "scope": "application"  # Attempting to change scope from USER to APPLICATION
        } 
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions
            
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                # Return the existing preference
                mock_preferences['base_preference'].scope = PreferenceScope.USER  # Ensure original scope is USER
                mock_query.get.return_value = mock_preferences['base_preference']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    # Create and call endpoint
                    endpoint = UserEndpoint() 
                    try:
                        endpoint.put("1")
                        assert False, "Expected BadRequest exception was not raised"
                    except BadRequest as e:
                        assert e.code == 400 

def test_update_nonexistent_preference(app, mock_security_functions):  
    with app.app_context(): 
        with app.test_request_context():
            _ = mock_security_functions
            
            with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_query:
                # Return None to simulate non-existent preference
                mock_query.get.return_value = None
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set() 
                    endpoint = UserEndpoint()

                    # Should raise 404 Not Found for nonexistent preference
                    try:
                        endpoint.get("3")
                        assert False, "Expected NotFound exception was not raised"
                    except NotFound as e:
                        assert e.code == 404 

 

 