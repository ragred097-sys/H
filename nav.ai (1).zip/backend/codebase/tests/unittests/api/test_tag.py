import json
from unittest import mock
from maxgpt.api.impl.tag import TagsEndpoint, tagEndpoint, TagFactoryEndpoint
from werkzeug.exceptions import NotFound
import pytest
from flask import Response

def test_get_tags(app, mock_tags, mock_security_function_permission):
    """Test to retrieve all tags accessible to the current user."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query:
                mock_tag_query.filter.return_value.all.return_value = mock_tags['all_tags']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = TagsEndpoint()
                    response = endpoint.get()
                    response_data = json.loads(response.data)
                    print("Response Data", response_data)
                    assert response.status_code == 200
                    assert response_data is not None, "Response data is None"
                    assert len(response_data) == 2
                    assert response_data[0]["id"] == "tag_1"
                    assert response_data[0]["name"] == "Tag 1"
                    assert response_data[0]["description"] == "Test Tag 1"
                    assert response_data[1]["id"] == "tag_2"
                    assert response_data[1]["name"] == "Tag 2"
                    assert response_data[1]["description"] == "Test Tag 2"

def test_options_method(app):
    """Test the OPTIONS method for the tags endpoint."""
    with app.app_context():
        with app.test_request_context():
            endpoint = TagsEndpoint()
            response = endpoint.options()
            assert response[1] == 200
            assert response[0] == ''

def test_empty_tags_list(app, mock_security_function_permission):
    """Test the behavior when no tags are available."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query:
                mock_tag_query.all.return_value = []
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = TagsEndpoint()
                    response = endpoint.get()
                    response_data = json.loads(response.data)
                    assert response.status_code == 200
                    assert response_data is not None, "Response data is None"
                    assert len(response_data) == 0
                    assert isinstance(response_data, list)

def test_delete_tag(app, mock_security_functions, mock_tags):
    """Test deleting a tag."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                mock_query.filter.return_value.first.return_value = mock_tags['base_tag']
                # Patch the role query chain to return a mock role with .name = "administrator"
                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = tagEndpoint()
                    response = endpoint.delete("1")
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "tag_1"
                    assert response_data["name"] == "Tag 1"

def test_get_tag_by_id(app, mock_tags, mock_security_function_permission):
    """Test to retrieve a specific tag by ID."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query:
                mock_tag_query.filter.return_value.first.return_value = mock_tags['base_tag']
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = tagEndpoint()
                    tag_id = "tag_1"
                    response = endpoint.get(tag_id)
                    response_data = json.loads(response.data)
                    print("Response Data", response_data)
                    assert response.status_code == 200
                    assert response_data is not None, "Response data is None"
                    assert response_data["id"] == "tag_1"
                    assert response_data["name"] == "Tag 1"
                    assert response_data["description"] == "Test Tag 1"

def test_update_tag(app, mock_tags, mock_security_function_permission):
    """Test updating an existing tag."""
    with app.app_context():
        update_data = {
            "name": "Updated Tag 1",
            "description": "Updated Description for Tag 1"
        }
        tag_id = "tag_1"
        with app.test_request_context(method='PUT', json=update_data, content_type='application/json'):
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                mock_tag = mock_tags['base_tag']
                # First .first() returns the tag to update, second (duplicate name check) returns None
                mock_tag_query.filter.return_value.first.side_effect = [mock_tag, None]
                # Patch the role query chain to return a mock role with .name = "administrator"
                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                mock_tag.deleted_at = None
                # Set to_dict to return the updated values after update
                mock_tag.to_dict.return_value = {
                    "id": "tag_1",
                    "name": "Updated Tag 1",
                    "description": "Updated Description for Tag 1"
                }
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    endpoint = tagEndpoint()
                    response = endpoint.put(tag_id)
                    assert response.status_code == 200
                    response_data = json.loads(response.data)
                    assert response_data["id"] == "tag_1"
                    assert response_data["name"] == "Updated Tag 1"
                    assert response_data["description"] == "Updated Description for Tag 1"
                    assert mock_db_session.commit.call_count >= 1, "Database commit was not called"

def test_update_nonexistent_tag(app, mock_security_function_permission):
    """Test updating a tag that doesn't exist."""
    with app.app_context():
        update_data = {
            "name": "Updated Tag",
            "description": "Updated Description"
        }
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                mock_tag_query.get.return_value = None
                # Patch the role query chain to return a mock role with .name = "administrator"
                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    with mock.patch('maxgpt.api.impl.tag.ns.abort', side_effect=NotFound) as mock_abort:
                        endpoint = tagEndpoint()
                        non_existent_id = "nonexistent_tag_id"
                        with pytest.raises(NotFound):
                            endpoint.put(non_existent_id)
                        mock_abort.assert_called_once()
                        args, _ = mock_abort.call_args
                        assert args[0] == 404
                        assert "nonexistent_tag_id" in args[1] 

def test_create_tag(app, mock_security_functions, mock_tags):
    """Test creating a new tag."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "name": "New Tag",
            "description": "New Tag Description"
        }):
            _ = mock_security_functions
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }
            serializable_response = {
                '__type_name': 'Tag', 
                'id': 'new-tag-id',
                'name': 'New Tag',
                'description': 'New Tag Description',
                'createdAt': '2025-04-22T10:00:00',
                'creator': {
                    'id': 'user123',
                    'name': 'Test User'
                }
            }
            with mock.patch.object(TagFactoryEndpoint, 'post', autospec=True) as mock_post:
                mock_post.return_value = Response(
                    json.dumps(serializable_response),
                    status=200,
                    mimetype='application/json'
                )
                endpoint = TagFactoryEndpoint()
                response = mock_post(endpoint)
                response_data = json.loads(response.data)
                print("**************Response DATA*********************", response_data)
                assert response.status_code == 200
                assert response_data["id"] == "new-tag-id"
                assert response_data["name"] == "New Tag"
                assert response_data["description"] == "New Tag Description"
                assert response_data["__type_name"] == "Tag"
                assert response_data["creator"]["id"] == "user123"
                assert response_data["creator"]["name"] == "Test User"
