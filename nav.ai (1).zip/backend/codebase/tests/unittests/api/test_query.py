from unittest import mock
from flask import Response as FlaskResponse
from maxgpt.api.impl.query import MessageEndpoint
from maxgpt.services.database_model import DataSourceModel, database as db
from maxgpt.core.query_process import QueryProcess


def test_query_message_endpoint(app, mock_data_sources, mock_security_functions):
    """Test the MessageEndpoint POST method for streaming LLM response."""

    mock_data_source = mock_data_sources[0]

    with app.app_context():
        with app.test_request_context(method='POST', json={
            "parts": [{"type": "TEXT", "content": "Hello, world!"}],
            "llmId": "llm-123",
            "dataSourceId": mock_data_source.to_dict()["id"],
            "overrides": [{"name": "override_llm_response_mode", "value": "tree_summarize"}]
        }):
            _ = mock_security_functions

            with mock.patch.object(DataSourceModel, 'query') as mock_query, \
                 mock.patch.object(QueryProcess, 'execute', return_value=iter(["chunk1 ", "chunk2"])) as mock_execute, \
                 mock.patch.object(db, 'session', new=mock.MagicMock()):

                mock_query.get.return_value = mock_data_source

                endpoint = MessageEndpoint()
                response = endpoint.post()
 
                assert response.status_code == 200

                streamed_data = "".join(response.response)
                assert "chunk1 " in streamed_data
                assert "chunk2" in streamed_data


def test_query_message_endpoint_datasource_not_found(app, mock_security_functions):
    """Test MessageEndpoint POST when datasource does not exist."""

    with app.app_context():
        with app.test_request_context(method='POST', json={
            "parts": [{"type": "TEXT", "content": "Hello, world!"}],
            "llmId": "llm-123",
            "dataSourceId": "nonexistent-id",
            "overrides": [{"name": "override_llm_response_mode", "value": "tree_summarize"}]
        }):
            _ = mock_security_functions

            with mock.patch.object(DataSourceModel, 'query') as mock_query, \
                 mock.patch.object(QueryProcess, 'execute', return_value=iter(["chunk1 ", "chunk2"])), \
                 mock.patch.object(db, 'session', new=mock.MagicMock()):

                mock_query.get.return_value = None

                endpoint = MessageEndpoint()

                try:
                    endpoint.post()
                    assert False, "Expected abort(404) but it did not happen"
                except Exception as e:
                    assert hasattr(e, 'data')
                    assert e.data['message'] == 'A data source with identifier "nonexistent-id" does not exist'
