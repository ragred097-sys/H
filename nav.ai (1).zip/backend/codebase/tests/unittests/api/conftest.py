import pytest
from unittest import mock
from unittest.mock import MagicMock

@pytest.fixture
def apprd_mock(app, mock_security_function_permission):
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database.session') as mock_db_session:
                mock_scalars = MagicMock()
                mock_scalars.return_value = set()
                mock_db_session.scalars.return_value = mock_scalars
                mock_db_session.add = MagicMock()
                mock_db_session.commit = MagicMock()
                mock_db_session.delete = mock.MagicMock()
                yield
