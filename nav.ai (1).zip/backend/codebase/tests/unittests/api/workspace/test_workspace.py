from unittest import mock 
from unittest.mock import MagicMock
from maxgpt.api.impl.workspace import WorkspaceSystemInstructionsEndpoint
from maxgpt.api.impl.workspace import WorkspacesEndpoint, WorkspaceEndpoint, WorkspaceFactoryEndpoint, WorkspaceAgentEndpoint
import pytest
from flask import Response, jsonify


def test_get_workspaces(app, mock_security_function_permission, mock_workspaces):
    """Test the get_workspaces endpoint functionality, including search."""
    with app.app_context():  
        with app.test_request_context(): 
            _ = mock_security_function_permission  
            # Mock user query
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user
                # Mock workspace permissions
                with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                    mock_fetch.return_value = mock_workspaces['all_workspaces']
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_scalars = mock.MagicMock()
                        mock_scalars.all.return_value = []
                        mock_db_session.scalars.return_value = mock_scalars
                        endpoint = WorkspacesEndpoint() 
                        # Default: all workspaces
                        response = endpoint.get()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert len(response_data) == 2, "Expected 2 workspaces in response"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Workspace 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Workspace 2"
                        # Search by name
                        with app.test_request_context('/workspaces/?search=Workspace%201'):
                            response = endpoint.get()
                            response_data = response.get_json()
                            assert response.status_code == 200
                            assert response_data is not None
                            assert len(response_data) == 1, "Expected 1 workspace in response after search by name"
                            assert response_data[0]["id"] == "1"
                            assert response_data[0]["name"] == "Workspace 1"
                        # Search by description
                        with app.test_request_context('/workspaces/?search=Test%20description'):
                            response = endpoint.get()
                            response_data = response.get_json()
                            assert response.status_code == 200
                            assert response_data is not None
                            assert len(response_data) == 1, "Expected 1 workspace in response after search by description"
                            assert response_data[0]["id"] == "1"
                            assert response_data[0]["name"] == "Workspace 1"
                        # Search no match
                        with app.test_request_context('/workspaces/?search=NonExistent'):
                            response = endpoint.get()
                            response_data = response.get_json()
                            assert response.status_code == 200
                            assert response_data is not None
                            assert len(response_data) == 0, "Expected 0 workspaces in response after search no match"
                        # Search invalid regex
                        with app.test_request_context('/workspaces/?search=('):
                            response = endpoint.get()
                            response_data = response.get_json()
                            assert response.status_code == 200
                            assert response_data is not None
                            assert len(response_data) == 0, "Expected 0 workspaces in response after invalid regex"


def test_get_workspace_by_id(app, mock_workspaces, mock_security_function_permission):
    """Test to get a workspace by its ID."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission 
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_query:
                mock_workspace = mock_workspaces['base_workspace']
                mock_workspace.to_dict.return_value = {"id": "1", "name": "Workspace 1"}
                mock_query.filter.return_value.first.return_value = mock_workspace
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = mock.MagicMock()
                    mock_scalars.return_value = set()
                    mock_db_session.scalars.return_value = mock_scalars
                    
                    with mock.patch('maxgpt.api.impl.workspace.SessionContext') as mock_session_context:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user1"
                        mock_session_context.get_current_user.return_value = mock_user
                        
                        with mock.patch('maxgpt.api.impl.workspace.get_user_access_for', return_value="READ"):
                            with mock.patch('maxgpt.api.impl.workspace.PermissionType.rank', side_effect=lambda x: 1 if x == "READ" else 0):
                                with mock.patch('maxgpt.api.impl.workspace.with_favorite', return_value={"id": "1", "name": "Workspace 1"}):
                                    with mock.patch('maxgpt.api.impl.workspace.with_access_permission', return_value={"id": "1", "name": "Workspace 1"}):
                                        endpoint = WorkspaceEndpoint()
                                        response = endpoint.get("1")

                                        assert response.status_code == 200
                                        response_data = response.get_json()
                                        assert response_data["id"] == "1"
                                        assert response_data["name"] == "Workspace 1"


def test_update_workspace(app, mock_security_functions, mock_workspaces):
    update_data = {
        "name": "Updated workspace",
        "description": "Updated Test description",
        "image": "Updated image"
    }

    with app.app_context():
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions

            mock_workspace = mock_workspaces['update_workspace']
            mock_workspace.deleted_at = None
            mock_workspace.tag_relations = []
            mock_workspace.to_dict.return_value = {
                "id": "1",
                "name": "Updated workspace",
                "description": "Updated Test description",
                "image": "Updated image",
                "icon": None,
                "filtered_on_tags": False
            }

        
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions 
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_query:
                mock_query.get.return_value = mock_workspaces['update_workspace']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    
                    with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
                        mock_object_session.return_value = mock_db_session
                        
                        
                        endpoint = WorkspaceEndpoint()
                        response: Response = endpoint.put("1")
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["id"] == "1"
                        assert response_data["name"] == "Updated workspace"
                        assert response_data["description"] == "Updated Test description"
                        assert response_data["image"] == "Updated image"



def test_create_workspace(app, mock_security_functions, mock_workspaces):
    """Test creating a new preference."""

    with app.app_context():
        with app.test_request_context(method='POST', json={
            "id": "new-uuid",
            "name": "New Workspace",
            "description": "Workspace description",
            "tags": [],
            "icon": "newicon",
            "image": "newimage",
            "filteredOnTags": True
        }):
            # Create mock user
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }

            mock_workspaces['new_workspace'].creator = mock_user

            with mock.patch('maxgpt.services.security.ShallowUser.to_dict', 
                            return_value={'id': 'user123', 'name': 'Test User'}):

                with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                    mock_user_query.filter.return_value.first.return_value = mock_user

                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                        mock_get_current_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database_model.WorkspaceModel') as mock_workspace_model:
                            mock_workspace_model.return_value = mock_workspaces['new_workspace']

                            with mock.patch('maxgpt.api.impl.workspace.with_favorite', 
                                          return_value=mock_workspaces['new_workspace'].to_dict()):
                                with mock.patch('maxgpt.api.impl.workspace.with_access_permission', 
                                              return_value=mock_workspaces['new_workspace'].to_dict()):

                                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                        mock_db_session.add = mock.MagicMock()
                                        mock_db_session.commit = mock.MagicMock()

                                        # Create and test endpoint
                                        endpoint = WorkspaceFactoryEndpoint()
                                        response = endpoint.post()

                                        assert response.status_code == 200
                                        response_data = response.get_json()
                                        print("**************Response DATA*********************", response_data)
                                        
                                        # Validate basic fields
                                        assert response_data["name"] == "New Workspace"
                                        assert "description" in response_data
                                        assert response_data["id"] == "new-uuid"
                                        assert response_data["icon"] == "newicon"
                                        assert response_data["image"] == "newimage"
                                        assert response_data["filteredOnTags"] == True
                                        
                                        assert response_data["__type_name"] == "Workspace"
                                        
                                        # Validate tags
                                        assert "tags" in response_data
                                        assert isinstance(response_data["tags"], list)
                                        assert len(response_data["tags"]) == 0
                                        
                                        # Check optional fields
                                        if "creator" in response_data:
                                            assert response_data["creator"]["id"] == "user123"
                                            assert response_data["creator"]["name"] == "Test User"
                                        
                                        if "accessPermission" in response_data:
                                            assert response_data["accessPermission"] in ["READ", "WRITE", "ADMIN"]
                                            
                                        if "favorite" in response_data:
                                            assert isinstance(response_data["favorite"], bool)




def test_get_workspace_system_instructions(app, mock_system_instructions,mock_security_functions):
   with app.app_context():
           with app.test_request_context():
               # Dummy reference to avoid "unused variable" warning
               _ = mock_security_functions
               
               workspace_id = "1"
               
               # Mock the WorkspaceModel.query.get() method
               with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query: 
                   mock_workspace_query.id = workspace_id
                   mock_workspace_query.get.return_value = mock_workspace_query
                   
                   # Mock the database session and assistant IDs query
                   with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                       mock_scalars = MagicMock()
                       mock_scalars.all.return_value = []
                       mock_db_session.scalars.return_value = mock_scalars
                       
                       # Mock fetch_with_permissions to return our mock assistants
                       with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                           mock_fetch.return_value = mock_system_instructions[ 'all_system_instructions']
                           
                           endpoint = WorkspaceSystemInstructionsEndpoint()
                           response = endpoint.get(workspace_id)
                           
                           # Assertions
                           assert response.status_code == 200
                           response_data = response.get_json()
                           assert response_data is not None
                           assert len(response_data) == 2
                           assert response_data[0]["id"] == "1"
                           assert response_data[0]["name"] == "Instruction 1"
                           assert response_data[1]["id"] == "2"
                           assert response_data[1]["name"] == "Instruction 2"
  
       
def test_delete_workspace_system_instructions(app, mock_system_instructions, mock_security_functions):
     with app.app_context():
        with app.test_request_context(json={"systemInstructionIds": ["1"]}):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1" 
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:  
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                     mock_scalars = MagicMock()
                     mock_scalars.all.return_value = []
                     mock_db_session.scalars.return_value = mock_scalars
                     
                   
                     with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                         # Return a list with just the first assistant
                         mock_fetch.return_value = mock_system_instructions["all_system_instructions"]

                         endpoint = WorkspaceSystemInstructionsEndpoint()
                         response = endpoint.delete(workspace_id)

                         # Assertions
                         assert response.status_code == 200
                         response_data = response.get_json()
                         assert response_data is not None
                         assert response_data[0]["id"] == "1"
                         assert response_data[0]["name"] == "Instruction 1" 
    
def test_create_workspace_system_instruction_link(app, mock_system_instructions, mock_security_functions):
     with app.app_context():
        with app.test_request_context(method='POST', json={
            "systemInstructionIds": ["1", "2"]
        }):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1"
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    # Mock fetch_with_permissions to return our mock assistants
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_system_instructions['all_system_instructions']
                        
                        endpoint = WorkspaceSystemInstructionsEndpoint()
                        response = endpoint.post(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Instruction 1"
                        assert response_data[1]["id"] == "2" 
                        assert response_data[1]["name"] == "Instruction 2" 


def test_get_workspace_agents(app, mock_security_function_permission, mock_agents):
    """Test getting all agents linked to a workspace."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            
            workspace_id = "1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = mock.MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock the database session and agent IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = mock.MagicMock()
                    mock_scalars.all.return_value = ["agent1", "agent2", "agent3"]
                    mock_db_session.scalars.return_value = mock_scalars
                    
                    # Mock fetch_with_permissions to return our mock agents
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_agents['all_agents']
                        
                        endpoint = WorkspaceAgentEndpoint()
                        response = endpoint.get(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Agent 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Agent 2"


def test_post_workspace_agents(app, mock_security_function_permission, mock_agents):
    """Test adding agents to a workspace."""
    with app.app_context():
        with app.test_request_context(json={'agentIds': ['1', '2']}):
            _ = mock_security_function_permission
            
            workspace_id = "1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = mock.MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock database session for checking existing relations
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value.all.return_value = []
                    mock_db_session.add = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    
                    # Mock fetch_with_permissions to return agent objects
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_agents['all_agents']
                        
                        endpoint = WorkspaceAgentEndpoint()
                        response = endpoint.post(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Agent 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Agent 2"
                        
                        # Verify database operations
                        assert mock_db_session.add.call_count == 2
                        assert mock_db_session.commit.call_count == 3  #Commit called 3 times: Inside endpoint, decorator, via nested decorator


def test_delete_workspace_agents(app, mock_security_function_permission, mock_agents):
    """Test deleting multiple agents from a workspace."""
    with app.app_context():
        with app.test_request_context(json={"agentIds": ["1", "2"]}):
            permission_mock = mock_security_function_permission

            workspace_id = "1"

            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = mock.MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace

                # Mock the database session for checking existing relations
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock scalars to return existing agent IDs in the workspace
                    mock_scalars = mock.MagicMock()
                    mock_scalars.return_value = ["1"]  # Only agent 1 is already in the workspace
                    mock_db_session.scalars.return_value = mock_scalars

                    # Mock SessionContext.get_current_user
                    with mock.patch('maxgpt.api.impl.workspace.SessionContext') as mock_session_context:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user1"
                        mock_session_context.get_current_user.return_value = mock_user

                        # Mock fetch_with_permissions to return our mock agents
                        with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                            mock_fetch.return_value = [mock_agents['second_agent']]

                            endpoint = WorkspaceAgentEndpoint()
                            response = endpoint.delete(workspace_id)

                            # Assertions
                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data is not None
                            assert len(response_data) == 1
                            assert response_data[0]["id"] == "2"
                            assert response_data[0]["name"] == "Agent 2"

                            # Verify delete statement execution
                            mock_db_session.execute.assert_called()
                            assert mock_db_session.commit.call_count > 0  


def test_delete_workspace(app, mock_security_functions, mock_workspaces):
    """Test deleting a workspace."""
    with app.app_context():
        with app.test_request_context('/workspace/1', method='DELETE'):
            _ = mock_security_functions

            mock_workspace = mock_workspaces['base_workspace']
            mock_workspace.deleted_at = None
            mock_workspace.to_dict.return_value = {
                "id": "1",
                "name": "Workspace 1"
            }
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_query:
                # Ensure the mock returns a valid workspace object
                mock_query.get.return_value = mock_workspaces['base_workspace']
               
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # Mock the delete and commit operations
                    mock_db_session.delete = mock.MagicMock()
                    mock_db_session.commit = mock.MagicMock()
                    endpoint = WorkspaceEndpoint()
                    response = endpoint.delete("1")

                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "1"
                    assert response_data["name"] == "Workspace 1"

