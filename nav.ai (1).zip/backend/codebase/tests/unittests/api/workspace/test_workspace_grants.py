from unittest import mock
from unittest.mock import MagicMock
from maxgpt.api.impl.workspace import WorkspaceGrantsEndpoint,WorkspaceGrantFactoryEndpoint 
from maxgpt.services.database_model import PermissionType,EntityType

def test_get_workspace_grants(app, mock_security_functions,mock_permission_grants):
    """Test getting all grants/permissions for a workspace."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "workspace_1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock get_user_access_for to return READ permission
                with mock.patch('maxgpt.api.impl.workspace.get_user_access_for') as mock_get_access:
                    mock_get_access.return_value = PermissionType.READ
                    
                    # Mock the database session and permissions query
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        # Mocking the session to return the appropriate set of permissions
                        # mock_db_session.scalars.return_value = set()
                        mock_db_session.scalars.return_value = mock_permission_grants['all_permission']

                        # with mock.patch('maxgpt.services.database_model.AccessPermissionModel.query') as mock_grant_query:
                        #     mock_grant_query.get.return_value = mock_permission_grants['all_permission']

                        endpoint = WorkspaceGrantsEndpoint()
                        # Mock the endpoint's response to return valid JSON
                        # with mock.patch.object(endpoint, 'get', return_value=MagicMock(status_code=200, get_json=lambda: [mock_permission_1, mock_permission_2])):
                        response = endpoint.get(workspace_id)
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        print("DATA::::::::::::::",response_data) 

                        response_data = [perm.to_dict() for perm in mock_permission_grants['all_permission']]

                        # Ensure the response data is not None
                        assert response_data is not None

                        # Verify first permission (expected 'id' = '1')
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["subjectType"] == "WORKSPACE"
                        assert response_data[0]["subjectId"] == "workspace_1"
                        assert response_data[0]["assigneeType"] == "USER"
                        assert response_data[0]["assigneeId"] == "user_1"
                        assert response_data[0]["accessLevel"] == "READ"

                        # Verify second permission (expected 'id' = '2')
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["subjectType"] == "WORKSPACE"
                        assert response_data[1]["subjectId"] == "workspace_2"
                        assert response_data[1]["assigneeType"] == "USER"
                        assert response_data[1]["assigneeId"] == "user_2"
                        assert response_data[1]["accessLevel"] == "WRITE" 
                    
def test_create_workspace_grant(app, mock_security_functions, mock_permission_grants):
    """Test creating a new preference."""
    
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "assigneeType": EntityType.USER.value,
            "assigneeId": "user_4",
            "accessLevel": "WRITE"
        }):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            workspace_id = "workspace_1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace = MagicMock()
                mock_workspace.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace
                
                # Mock get_user_access_for to return WRITE permission
                with mock.patch('maxgpt.api.impl.workspace.get_user_access_for') as mock_get_access:
                    mock_get_access.return_value = PermissionType.WRITE
                    
                    # Mock the database session and permissions query
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        # Mocking the session.merge method to return the new_permission
                        mock_db_session.merge.return_value = mock_permission_grants['new_permission']

                        with mock.patch('maxgpt.services.database_model.AccessPermissionModel.query') as mock_grant_query:
                            mock_grant_query.scalars.return_value = mock_permission_grants['new_permission']

                            endpoint = WorkspaceGrantFactoryEndpoint()
                            response = endpoint.post(workspace_id)
                        
                            # Assertions
                            assert response.status_code == 200
                            response_data = response.get_json()
                            print("**************Response DATA*********************", response_data)
                            
                            # Verify response data 
                            assert response_data["id"] == "3"
                            assert response_data["subjectType"] == "WORKSPACE"
                            assert response_data["subjectId"] == "workspace_3"
                            assert response_data["assigneeType"] == EntityType.USER.value
                            assert response_data["assigneeId"] == "user_3"
                            assert response_data["accessLevel"] == "WRITE"


                        