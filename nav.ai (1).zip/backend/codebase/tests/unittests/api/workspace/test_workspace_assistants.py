from unittest import mock
from unittest.mock import MagicMock
from maxgpt.api.impl.workspace import WorkspaceAssistantsEndpoint
from werkzeug.exceptions import NotFound

def test_get_workspace_assistants(app, mock_security_functions, mock_assistants):
    """Test getting all assistants linked to a workspace."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1"
            
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query: 
                mock_workspace_query.id = workspace_id
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                    mock_scalars = MagicMock()
                    mock_scalars.all.return_value = []
                    mock_db_session.scalars.return_value = mock_scalars
                    
                    # Mock fetch_with_permissions to return our mock assistants
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_assistants
                        
                        endpoint = WorkspaceAssistantsEndpoint()
                        response = endpoint.get(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Assistant 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Assistant 2"


def test_create_workspace_assistant(app, mock_security_functions, mock_assistants):
    """Test creating a new workspace-assistant relationship."""
    
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "assistantIds": ["1", "2"]
        }):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1"
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    # Mock fetch_with_permissions to return our mock assistants
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_assistants
                        
                        endpoint = WorkspaceAssistantsEndpoint()
                        response = endpoint.post(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Assistant 1"
                        assert response_data[1]["id"] == "2" 
                        assert response_data[1]["name"] == "Assistant 2" 


def test_delete_workspace_assistants(app, mock_security_functions, mock_assistants):
    """Test deleting assistants linked to a workspace."""
    with app.app_context():
        with app.test_request_context(json={"assistantIds": ["1"]}):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1" 
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:  
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                    mock_db_session.scalars.return_value = set() 
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        # Return a list with just the first assistant
                        mock_fetch.return_value = [mock_assistants[0]]
                        
                        endpoint = WorkspaceAssistantsEndpoint()
                        response = endpoint.delete(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 1
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Assistant 1"


def test_get_workspace_assistants_nonexistent_workspace(app, mock_security_functions):
    """Test getting assistants for a non-existent workspace."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "999"
            
            # Mock the WorkspaceModel.query.get() method to return None
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace_query.get.return_value = None
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = MagicMock()
                    mock_scalars.all.return_value = []
                    mock_db_session.scalars.return_value = mock_scalars
                
                    endpoint = WorkspaceAssistantsEndpoint() 
                    try:
                        endpoint.get(workspace_id)    
                    except NotFound as e:
                        assert e.code == 404 

