from unittest import mock
from maxgpt.api.impl.workspace import WorkspaceAgentWorkflowEndpoint

def test_get_agent_workflows(app, mock_agent_workflows, mock_security_functions):
    """Test case for the GET method of the WorkspaceAgentWorkflowEndpoint."""
    with app.app_context():
           with app.test_request_context():
               # Dummy reference to avoid "unused variable" warning
               _ = mock_security_functions
               
               workspace_id = "1"
               
               # Mock the WorkspaceModel.query.get() method
               with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query: 
                   mock_workspace_query.id = workspace_id
                   mock_workspace_query.get.return_value = mock_workspace_query
                   
                   # Mock the database session and assistant IDs query
                   with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                       mock_scalars = mock.MagicMock()
                       mock_scalars.all.return_value = []
                       mock_db_session.scalars.return_value = mock_scalars
                       
                       # Mock fetch_with_permissions to return our mock assistants
                       with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                           mock_fetch.return_value = mock_agent_workflows
                           
                           endpoint = WorkspaceAgentWorkflowEndpoint()
                           response = endpoint.get(workspace_id)
                           
                           # Assertions
                           assert response.status_code == 200
                           response_data = response.get_json()
                           assert response_data is not None
                           assert len(response_data) == 2
                           assert response_data[0]["id"] == "1"
                           assert response_data[0]["name"] == "Agent workflow 1"
                           assert response_data[1]["id"] == "2"
                           assert response_data[1]["name"] == "Agent workflow 2"


def test_delete_agent_workflows(app, mock_agent_workflows, mock_security_functions):
    """Test case for the DELETE method of the WorkspaceAgentWorkflowEndpoint."""
    with app.app_context():
        with app.test_request_context(json={"agentWorkflowIds": ["1"]}):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1" 
            # Mock the WorkspaceModel.query.get() method
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:  
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                     mock_scalars = mock.MagicMock()
                     mock_scalars.all.return_value = []
                     mock_db_session.scalars.return_value = mock_scalars
                     
                   
                     with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                         # Return a list with just the first assistant
                         mock_fetch.return_value = mock_agent_workflows

                         endpoint = WorkspaceAgentWorkflowEndpoint()
                         response = endpoint.delete(workspace_id)

                         # Assertions
                         assert response.status_code == 200
                         response_data = response.get_json()
                         assert response_data is not None
                         assert response_data[0]["id"] == "1"
                         assert response_data[0]["name"] == "Agent workflow 1" 

def test_create_workspace_agent_workflow_link(app, mock_agent_workflows, mock_security_functions):
    """Test case for the POST method of the WorkspaceAgentWorkflowEndpoint."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "agentWorkflowIds": ["1", "2"]
        }):
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            
            workspace_id = "1"
            
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_workspace_query:
                mock_workspace_query.get.return_value = mock_workspace_query
                
                # Mock the database session and assistant IDs query
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    # Mock fetch_with_permissions to return our mock assistants
                    with mock.patch('maxgpt.api.impl.workspace.fetch_with_permissions') as mock_fetch:
                        mock_fetch.return_value = mock_agent_workflows
                        
                        endpoint = WorkspaceAgentWorkflowEndpoint()
                        response = endpoint.post(workspace_id)
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None
                        assert len(response_data) == 2
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Agent workflow 1"
                        assert response_data[1]["id"] == "2" 
                        assert response_data[1]["name"] == "Agent workflow 2" 