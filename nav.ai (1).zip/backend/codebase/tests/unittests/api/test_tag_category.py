from unittest import mock
from maxgpt.api.impl.tag_category import TagCategoriesFactoryEndpoint, TagCategoryEndpoint, TagCategoryFactoryEndpoint
from flask import Response, json, jsonify

def test_get_tag_categories(app, mock_security_function_permission, mock_tag_categories):
    """Test the get_tag_categories endpoint functionality."""
    with app.app_context():  
        with app.test_request_context(): 
            _ = mock_security_function_permission  
            
            # Mock user query
            with mock.patch('maxgpt.services.database_model.TagCategoryModel.query') as mock_user_query:
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user


                with mock.patch('maxgpt.services.database_model.TagCategoryModel.query') as mock_query:
    # Return the mock tag categories on .filter(...).all()
                    mock_query.filter.return_value.all.return_value = mock_tag_categories['all_tag_category']


                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        
                        endpoint = TagCategoryEndpoint() 
                        response = endpoint.get()

                        response_data = response.get_json()
                        print("Response Data:", response_data)
                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert len(response_data) == 2, "Expected 2 instruction in response"
                        assert response_data[0]["id"] == "tc1"
                        assert response_data[0]["name"] == "Category One"
                        assert response_data[1]["id"] == "tc2"
                        assert response_data[1]["name"] == "Category Two"

def test_get_tag_category_by_id(app, mock_tag_categories, mock_security_function_permission):
    """Test to get a tag category by its ID."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            
            with mock.patch('maxgpt.services.database_model.TagCategoryModel.query') as mock_query:
                # Mock the filter().first() chain to return the mock tag category object
                mock_query.filter.return_value.first.return_value = mock_tag_categories['all_tag_category'][0]

                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()

                    endpoint = TagCategoryFactoryEndpoint()

                    # Call get with an ID, e.g. "tc1"
                    response = endpoint.get("tc1")

                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "tc1"
                    assert response_data["name"] == "Category One"

def test_delete_tag_category(app, mock_security_functions, mock_tag_categories):
    """Test deleting a tag category with proper admin privileges."""

    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions  # Activate mocked user + permissions

            with mock.patch('maxgpt.services.database_model.TagCategoryModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:

                # Set up the mock tag category to return
                mock_tag_category = mock_tag_categories['tag_category_1']
                mock_tag_category.deleted_at = None
                mock_query.get.return_value = mock_tag_category

                # Set up role check to return admin role
                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                # Patch DB session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()

                    from maxgpt.api.impl.tag_category import TagCategoryFactoryEndpoint
                    endpoint = TagCategoryFactoryEndpoint()
                    response = endpoint.delete("tc1")

                    assert response.status_code == 200
                    response_data = response.get_json()

                    assert response_data["id"] == "tc1"
                    assert response_data["name"] == "Category One"
                    assert mock_db_session.commit.call_count >= 1

def test_update_tag_category(app, mock_tag_categories, mock_security_functions):
    """Test updating an existing tag category."""
    with app.app_context():
        update_data = {
            "name": "Updated Tag Category",
            "description": "Updated Description for Tag Category"
        }
        tag_category_id = "tc1"

        with app.test_request_context(method='PUT', json=update_data, content_type='application/json'):
            _ = mock_security_functions

            with mock.patch('maxgpt.services.database_model.TagCategoryModel.query') as mock_query, \
                 mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:

                mock_tag_category = mock_tag_categories['tag_category_1']
                mock_tag_category.deleted_at = None

                # Mock query.get to return the tag category
                mock_query.get.return_value = mock_tag_category

                # Simulate admin role
                mock_role = mock.MagicMock()
                mock_role.application_access_role.name = "administrator"
                mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]

                # Simulate .to_dict() after update
                mock_tag_category.to_dict.return_value = {
                    "id": "tc1",
                    "name": "Updated Tag Category",
                    "description": "Updated Description for Tag Category"
                }

                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()

                    from maxgpt.api.impl.tag_category import TagCategoryFactoryEndpoint
                    endpoint = TagCategoryFactoryEndpoint()
                    response = endpoint.put(tag_category_id)

                    assert response.status_code == 200
                    response_data = json.loads(response.data)

                    assert response_data["id"] == "tc1"
                    assert response_data["name"] == "Updated Tag Category"
                    assert response_data["description"] == "Updated Description for Tag Category"
                    assert mock_db_session.commit.call_count >= 1, "Database commit was not called"

def test_create_tag_category(app, mock_security_functions, mock_users):
    """Test creating a new tag category."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "name": "New Category",
            "description": "New Category Description"
        }):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.database_model.TagModel.query') as mock_tag_query, \
                mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
               mock_tag_query.get.return_value = None
               # Patch the role query chain to return a mock role with .name = "administrator"
               mock_role = mock.MagicMock()
               mock_role.application_access_role.name = "administrator"
               mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]


            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }

            serializable_response = {
                '__type_name': 'TagCategory',
                'id': 'new-cat-id',
                'name': 'New Category',
                'description': 'New Category Description',
                'creator': {
                    'id': 'user123',
                    'name': 'Test User'
                }
            }

            with mock.patch.object(TagCategoriesFactoryEndpoint, 'post', autospec=True) as mock_post:
                mock_post.return_value = Response(
                    json.dumps(serializable_response),
                    status=200,
                    mimetype='application/json'
                )

                endpoint = TagCategoriesFactoryEndpoint()
                response = mock_post(endpoint)
                response_data = json.loads(response.data)

                print("************** Tag Category Response *********************", response_data)

                assert response.status_code == 200
                assert response_data["id"] == "new-cat-id"
                assert response_data["name"] == "New Category"
                assert response_data["description"] == "New Category Description"
                assert response_data["__type_name"] == "TagCategory"
                assert response_data["creator"]["id"] == "user123"
                assert response_data["creator"]["name"] == "Test User"
