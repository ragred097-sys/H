from unittest import mock 
from maxgpt.api.impl.data_source import DataSourcesEndpoint,DatasourceEndpoint
 
 
def test_get_data_sources(app,mock_security_function_permission):
    """_summary_

    Args:
        app (_type_): This Flask APP
        mock_users (_type_):  Fixture For data_sources
        mock_security_function_permission (_type_):The mock_security_functions fixture is necessary to simulate the 
                                         authenticated user for the request. Although it's not directly used 
                                         within the body of this test function, it's required to avoid authentication 
                                         errors and ensure that the request passes the authentication check.
    """
    with app.app_context():  # Ensure the application context is active
        with app.test_request_context():  
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_function_permission
            # Mock the UserModel.query.filter 
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                # Mock the query result
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user

                # Mock the UserFavoriteModel.query.filter method
                with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_favorite_query:
                    # Mock the query result
                    mock_favorite_query.filter.return_value.scalars.return_value = set()

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        # Instantiate the DataSourcesEndpoint 
                        endpoint = DataSourcesEndpoint() 
                        response = endpoint.get()
                        
                        # Assert the response status code and data
                        response_data = response.get_json() 
                        print("Response Data", response_data)
                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert len(response_data) == 2  # We have 2 mock data sources
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "DataSource 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "DataSource 2"


def test_get_datasource_by_id(app, mock_data_sources, mock_security_function_permission):
    """Test to get a user by their ID."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_function_permission 
            with mock.patch('maxgpt.services.database_model.DataSourceModel.query') as mock_query:
                mock_data_source = mock_data_sources[0]
                mock_query.get_or_404.return_value = mock_data_source
                with mock.patch('maxgpt.api.impl.data_source.data_source_to_dict', return_value={"id": "1", "name": "DataSource 1"}):
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        endpoint = DatasourceEndpoint()

                        # Test GET with an existing user ID
                        response = endpoint.get("1")

                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["id"] == "1"
                        assert response_data["name"] == "DataSource 1"

def test_get_data_source_by_id_not_found(app,mock_security_function_permission):
    """Test to get a non-existent data source."""
    with app.app_context():
        with app.test_request_context():
            # Mock the DataSourceModel.query.get_or_404 to raise NotFound (simulating not found)
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database_model.DataSourceModel.query') as mock_query:
                # Patch the filter().filter().first() chain to return None
                mock_query.filter.return_value.filter.return_value.first.return_value = None
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    endpoint = DatasourceEndpoint()
                    
                    # Test GET with a non-existent data source ID
                    # This should raise a NotFound exception (404 error)
                    try:
                        endpoint.get("999")
                        assert False, "Expected a NotFound error with 404 status code, but got a response"
                    except Exception as e:
                        print("INSIDE EXCEPTION ", e)
                        assert hasattr(e, 'code')
                        assert e.code == 404


