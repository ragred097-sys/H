import pytest
from unittest import mock
from maxgpt.api.impl.shared_conversation import SharedConversationEndpoint, SharedConversationsEndpoint, SharedConversationMessagesEndpoint, SharedConversationFactoryEndpoint
from werkzeug.exceptions import NotFound, Forbidden
from maxgpt.services.database_model import SharedConversationModel, ConversationModel, MessageModel
from datetime import datetime

def test_get_shared_conversations(app, mock_security_functions, mock_shared_conversations):
    """Test getting all shared conversations for a user."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                    mock_shared_conversation = mock.MagicMock(spec=SharedConversationModel)
                    mock_shared_conversation.to_dict.return_value = {
                        'id': 'shared_conv_1',
                        'conversationId': 'conv_1',
                        'creator_id': 'user_1'
                    }
                    
                    mock_query.filter.return_value.order_by.return_value.all.return_value = [
                        mock_shared_conversation
                    ]

                    with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                        mock_conversation = mock.MagicMock(spec=ConversationModel)
                        mock_conversation.created_at = datetime.now()
                        mock_conversation.name = 'Test Conversation'
                        mock_convo_query.filter_by.return_value.first.return_value = mock_conversation

                        endpoint = SharedConversationsEndpoint()
                        response = endpoint.get()
                        response_data = response.get_json()
                        
                        assert response.status_code == 200
                        assert isinstance(response_data, list)
                        assert len(response_data) == 1
                        assert response_data[0]['id'] == 'shared_conv_1'
                        assert 'conversationName' in response_data[0]
                        assert response_data[0]['conversationName'] == 'Test Conversation'


def test_get_shared_conversation_by_id(app, mock_security_functions, mock_shared_conversations):
    """Test getting a shared conversation by its ID."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                    mock_query.get.side_effect = lambda id: (
                        mock_shared_conversations['base_shared_conversation'] if id == 'shared_conv_1' else None
                    )
                    endpoint = SharedConversationEndpoint()
                    response = endpoint.get('shared_conv_1')
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert response_data['id'] == 'shared_conv_1'
                    assert response_data['conversationId'] == 'conv_1'

def test_get_shared_conversation_by_id_not_found(app, mock_security_functions, mock_shared_conversations):
    """Test getting a non-existent shared conversation."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                    mock_query.get.return_value = None
                    endpoint = SharedConversationEndpoint()
                    with pytest.raises(NotFound):
                        endpoint.get('non_existent_id') 

def test_get_shared_conversation_messages(app, mock_security_functions, mock_shared_conversations):
    """Test getting messages for a shared conversation."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_shared_query:
                    mock_shared_query.get.return_value = mock_shared_conversations['base_shared_conversation']
                    
                    with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                        mock_convo_query.get.return_value = ConversationModel(id='conv_1', creator_id='user_1')
                        
                        with mock.patch('maxgpt.services.database_model.MessageModel.query') as mock_message_query:
                            mock_message = mock.MagicMock(spec=MessageModel)
                            mock_message.to_dict.return_value = {'id': 'msg_1', 'role': 'user', 'content': 'Hello', 'conversation_id': 'conv_1'}
                            mock_message_query.filter.return_value.filter.return_value.order_by.return_value.all.return_value = [mock_message]
                            
                            endpoint = SharedConversationMessagesEndpoint()
                            response = endpoint.get('shared_conv_1')
                            response_data = response.get_json()
                            
                            assert response.status_code == 200
                            assert isinstance(response_data, list)
                            assert len(response_data) == 1
                            assert response_data[0]['id'] == 'msg_1'

def test_get_shared_conversation_messages_not_found(app, mock_security_functions):
    """Test getting messages for a non-existent shared conversation."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                    mock_query.get.return_value = None
                    endpoint = SharedConversationMessagesEndpoint()
                    with pytest.raises(NotFound):
                        endpoint.get('non_existent_id') 

def test_create_shared_conversation(app, mock_security_functions):
    """Test creating a new shared conversation successfully."""
    _ = mock_security_functions
    with app.app_context():
        json_data = {'conversationId': 'conv_1'}
        with app.test_request_context(method='POST', json=json_data):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database.session') as mock_session:
                    mock_conversation = ConversationModel(id='conv_1', creator_id='user_1')
                    with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                        mock_convo_query.get.return_value = mock_conversation

                        with mock.patch('maxgpt.api.impl.shared_conversation.SharedConversationModel') as mock_shared_convo_model:
                            instance = mock_shared_convo_model.return_value
                            instance.to_dict.return_value = {
                                'id': 'new_shared_conv',
                                'conversationId': 'conv_1'
                            }

                            endpoint = SharedConversationFactoryEndpoint()
                            response = endpoint.post()
                            response_data = response.get_json()

                            assert response.status_code == 200
                            assert response_data['id'] == 'new_shared_conv'
                            assert response_data['conversationId'] == 'conv_1'
                            
                            mock_session.add.assert_called_once_with(instance)


def test_create_shared_conversation_not_found(app, mock_security_functions):
    """Test creating a shared conversation for a non-existent conversation."""
    _ = mock_security_functions
    with app.app_context():
        json_data = {'conversationId': 'non_existent_conv'}
        with app.test_request_context(method='POST', json=json_data):
            with mock.patch('maxgpt.services.database.session'):
                with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                    mock_convo_query.get.return_value = None

                    endpoint = SharedConversationFactoryEndpoint()
                    with pytest.raises(NotFound):
                        endpoint.post()


def test_create_shared_conversation_forbidden(app, mock_security_functions):
    """Test creating a shared conversation for a conversation belonging to another user."""
    _ = mock_security_functions
    with app.app_context():
        json_data = {'conversationId': 'conv_2'}
        with app.test_request_context(method='POST', json=json_data):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database.session'):
                    mock_conversation = ConversationModel(id='conv_2', creator_id='another_user')
                    with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                        mock_convo_query.get.return_value = mock_conversation

                        endpoint = SharedConversationFactoryEndpoint()
                        with pytest.raises(Forbidden):
                            endpoint.post()


def test_create_shared_conversation_db_error(app, mock_security_functions):
    """Test database error during shared conversation creation."""
    _ = mock_security_functions
    with app.app_context():
        json_data = {'conversationId': 'conv_1'}
        with app.test_request_context(method='POST', json=json_data):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session') as mock_session:
                    mock_session.add.side_effect = Exception("DB error")
                    
                    mock_conversation = ConversationModel(id='conv_1', creator_id='user_1')
                    with mock.patch('maxgpt.services.database_model.ConversationModel.query') as mock_convo_query:
                        mock_convo_query.get.return_value = mock_conversation

                        with mock.patch('maxgpt.api.impl.shared_conversation.SharedConversationModel') as mock_shared_convo_model:
                            instance = mock_shared_convo_model.return_value
                            endpoint = SharedConversationFactoryEndpoint()
                            with pytest.raises(Exception, match="DB error"):
                                endpoint.post()
                            
                            mock_session.add.assert_called_once_with(instance)


def test_delete_shared_conversation(app, mock_security_functions, mock_shared_conversations):
    """Test deleting a shared conversation successfully."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session') as mock_session:
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    mock_shared_convo.creator_id = 'user_1'  # Ensure ownership matches
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo
                        mock_query.filter_by.return_value.delete.return_value = None

                        endpoint = SharedConversationEndpoint()
                        response = endpoint.delete('shared_conv_1')
                        response_data = response.get_json()

                        assert response.status_code == 200
                        assert response_data['id'] == 'shared_conv_1'
                        mock_query.filter_by.assert_called_once_with(id='shared_conv_1')


def test_delete_shared_conversation_not_found(app, mock_security_functions):
    """Test deleting a non-existent shared conversation."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session'):
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = None

                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(NotFound):
                            endpoint.delete('non_existent_id')


def test_delete_shared_conversation_forbidden(app, mock_security_functions, mock_shared_conversations):
    """Test deleting a shared conversation belonging to another user."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_2' # Different user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session'):
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    mock_shared_convo.creator_id = 'user_1'  # Ensure ownership does not match
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo

                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(Forbidden):
                            endpoint.delete('shared_conv_1')


def test_delete_shared_conversation_db_error(app, mock_security_functions, mock_shared_conversations):
    """Test database error during shared conversation deletion."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session') as mock_session:
                    mock_session.commit.side_effect = Exception("DB error")
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo
                        
                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(Exception, match="DB error"):
                            endpoint.delete('shared_conv_1')

                        mock_session.rollback.assert_called_once()


def test_update_shared_conversation(app, mock_security_functions, mock_shared_conversations):
    """Test updating a shared conversation successfully."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='PUT'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session') as mock_session:
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    mock_shared_convo.creator_id = 'user_1'
                    mock_shared_convo.created_at = datetime(2024, 1, 1) # Set a fixed past datetime
                    original_timestamp = mock_shared_convo.created_at

                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo
                        
                        endpoint = SharedConversationEndpoint()
                        response = endpoint.put('shared_conv_1')
                        response_data = response.get_json()

                        assert response.status_code == 200
                        assert response_data['id'] == 'shared_conv_1'
                        assert mock_shared_convo.created_at > original_timestamp


def test_update_shared_conversation_not_found(app, mock_security_functions):
    """Test updating a non-existent shared conversation."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='PUT'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session'):
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = None

                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(NotFound):
                            endpoint.put('non_existent_id')


def test_update_shared_conversation_forbidden(app, mock_security_functions, mock_shared_conversations):
    """Test updating a shared conversation belonging to another user."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='PUT'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_2'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session'):
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    mock_shared_convo.creator_id = 'user_1'
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo

                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(Forbidden):
                            endpoint.put('shared_conv_1')


def test_update_shared_conversation_db_error(app, mock_security_functions, mock_shared_conversations):
    """Test database error during shared conversation update."""
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context(method='PUT'):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                with mock.patch('maxgpt.services.database_model.database.session') as mock_session:
                    mock_session.commit.side_effect = Exception("DB error")
                    mock_shared_convo = mock_shared_conversations['base_shared_conversation']
                    mock_shared_convo.creator_id = 'user_1'
                    with mock.patch('maxgpt.services.database_model.SharedConversationModel.query') as mock_query:
                        mock_query.get.return_value = mock_shared_convo
                        
                        endpoint = SharedConversationEndpoint()
                        with pytest.raises(Exception, match="DB error"):
                            endpoint.put('shared_conv_1')

                        mock_session.rollback.assert_called_once()

def test_options_shared_conversations(app):
    with app.app_context():
        with app.test_request_context(method='OPTIONS'):
            endpoint = SharedConversationsEndpoint()
            response = endpoint.options()
            assert response == ('', 200)

def test_options_shared_conversation_factory(app):
    with app.app_context():
        with app.test_request_context(method='OPTIONS'):
            endpoint = SharedConversationFactoryEndpoint()
            response = endpoint.options()
            assert response == ('', 200)

def test_options_shared_conversation(app):
    with app.app_context():
        with app.test_request_context(method='OPTIONS'):
            endpoint = SharedConversationEndpoint()
            response = endpoint.options('some_id')
            assert response == ('', 200)

def test_options_shared_conversation_messages(app):
    with app.app_context():
        with app.test_request_context(method='OPTIONS'):
            endpoint = SharedConversationMessagesEndpoint()
            response = endpoint.options('some_id')
            assert response == ('', 200)

def test_create_shared_conversation_missing_conversation_id(app, mock_security_functions):
    _ = mock_security_functions
    with app.app_context():
        json_data = {}  
        with app.test_request_context(method='POST', json=json_data):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = 'user_1'
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', return_value=mock_user):
                endpoint = SharedConversationFactoryEndpoint()
                with pytest.raises(Exception): 
                    endpoint.post() 