from unittest import mock
from unittest.mock import MagicMock
from maxgpt.api.impl.assistant import (
    AssistantsEndpoint, 
    AssistantFactoryEndpoint, 
    AssistantEndpoint
)
from maxgpt.services.database_model import PermissionType 
from maxgpt.modules import ModuleType 
import pytest
import werkzeug.exceptions 


def test_get_assistants(app, mock_security_function_permission, mock_assistants):
    """Test getting all assistants with search functionality."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            
            # Mock fetch_with_permissions to return our mock assistants
            with mock.patch('maxgpt.api.impl.assistant.fetch_with_permissions') as mock_fetch:
                mock_fetch.return_value = mock_assistants['all_assistants']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    endpoint = AssistantsEndpoint()
                    
                    # Default: all assistants
                    response = endpoint.get()
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert response_data is not None, "Response data is None"
                    assert len(response_data) == 2, "Expected 2 assistants in response"
                    assert response_data[0]["id"] == "1"
                    assert response_data[0]["name"] == "Assistant 1"
                    assert response_data[1]["id"] == "2"
                    assert response_data[1]["name"] == "Assistant 2"
                    
                    # Search by name
                    with app.test_request_context('/assistants/?search=Assistant%201'):
                        response = endpoint.get()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None
                        assert len(response_data) == 1, "Expected 1 assistant in response after search by name"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Assistant 1"
                    
                    # Search by description
                    with app.test_request_context('/assistants/?search=Test%20Assistant%201'):
                        response = endpoint.get()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None
                        assert len(response_data) == 1, "Expected 1 assistant in response after search by description"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Assistant 1"
                    
                    # Search no match
                    with app.test_request_context('/assistants/?search=NonExistent'):
                        response = endpoint.get()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None
                        assert len(response_data) == 0, "Expected 0 assistants in response after search no match"
                    
                    # Search invalid regex
                    with app.test_request_context('/assistants/?search=('):
                        response = endpoint.get()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None
                        assert len(response_data) == 0, "Expected 0 assistants in response after invalid regex"


def test_create_assistant(app, mock_security_functions, mock_assistants, mock_data_sources_for_assistant, mock_system_instructions_for_assistant):
    """Test creating a new assistant."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "name": "New Assistant",
            "description": "Test assistant description",
            "llmIds": ["1"],
            "customSystemInstruction": "Custom instruction",
            "greetingMessage": "Hello!",
            "sampleQuestions": ["Question 1", "Question 2"],
            "tags": [{"id": "tag1"}],
            "systemInstructionIds": ["sys1"],
            "dataSourceIds": ["ds1"],
            "image": "base64_image",
            "icon": "base64_icon",
                            "attachmentStorages": [
                    {"type": "TEXT", "fileStorageId": "storage1"}
                ]
        }):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                with mock.patch('maxgpt.services.security.ShallowUser.to_dict', 
                        return_value={'id': 'user123', 'name': 'Test User'}):
                 
                    mock_llm = MagicMock()
                    mock_llm.get_id.return_value = "1"
                    mock_llm.get_spec.return_value = MagicMock(get_module_type=lambda: ModuleType.LLM)

                    with mock.patch('maxgpt.modules.ModuleRegistry.get_module') as mock_get_module:
                        mock_get_module.return_value = mock_llm
 
                        with mock.patch('maxgpt.services.database_model.AssistantModel') as mock_assistant_model:
                            mock_assistant = mock_assistants['new_assistant']
                            mock_assistant_model.return_value = mock_assistant
 
                            with mock.patch('maxgpt.services.database_model.DataSourceModel.query') as mock_ds_query:
                                mock_ds = mock_data_sources_for_assistant['data_source_1']
                                mock_ds_query.get.return_value = mock_ds
 
                                with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_si_query:
                                    mock_si = mock_system_instructions_for_assistant['system_instruction_1']
                                    mock_si_query.get_or_404.return_value = mock_si

                                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                        mock_db_session.scalars.return_value = set()
                                        mock_db_session.add = MagicMock()
                                        mock_db_session.commit = MagicMock()

                                        with mock.patch('maxgpt.api.impl.assistant.with_access_permission') as mock_with_permission:
                                            with mock.patch('maxgpt.api.impl.assistant.with_hidden') as mock_with_hidden:
                                                with mock.patch('maxgpt.api.impl.assistant.with_favorite') as mock_with_favorite:
                                                    mock_with_permission.return_value = mock_assistant.to_dict()
                                                    mock_with_hidden.return_value = mock_assistant.to_dict()
                                                    mock_with_favorite.return_value = mock_assistant.to_dict()

                                                    endpoint = AssistantFactoryEndpoint()
                                                    response = endpoint.post()

                                                    assert response.status_code == 200
                                                    response_data = response.get_json()
                                                    assert response_data["name"] == "New Assistant"
                                                    assert response_data["description"] == "Test assistant description"


def test_get_assistant_by_id(app, mock_security_functions, mock_assistants, mock_shallow_user):
    """Test getting a specific assistant."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_get_user.return_value = mock_shallow_user
                
                mock_assistant = mock_assistants['base_assistant']
                
                with mock.patch('maxgpt.api.impl.assistant.get_assistant') as mock_get_assistant:
                    mock_get_assistant.return_value = (mock_assistant, PermissionType.READ)
                    
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        
                        with mock.patch('maxgpt.api.impl.assistant.with_access_permission') as mock_with_permission:
                            with mock.patch('maxgpt.api.impl.assistant.with_hidden') as mock_with_hidden:
                                with mock.patch('maxgpt.api.impl.assistant.with_favorite') as mock_with_favorite:
                                    mock_with_permission.return_value = mock_assistant.to_dict()
                                    mock_with_hidden.return_value = mock_assistant.to_dict()
                                    mock_with_favorite.return_value = mock_assistant.to_dict()
                                    
                                    endpoint = AssistantEndpoint()
                                    response = endpoint.get("assistant-1")
                                    
                                    assert response.status_code == 200
                                    response_data = response.get_json()
                                    assert response_data["id"] == "1"
                                    assert response_data["name"] == "Assistant 1"


def test_get_assistant_not_found(app, mock_security_functions):
    """Test getting a non-existent assistant."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_functions
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_assistant_query:
                mock_assistant_query.get.return_value = None
                
                #Mock current user
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "mock_user_id"
                    mock_get_user.return_value = mock_user
                    with mock.patch('maxgpt.api.impl.assistant.get_assistant') as mock_get_assistant:
                        mock_get_assistant.side_effect = werkzeug.exceptions.NotFound("Assistant not found")
                        #Mock the database session
                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            endpoint = AssistantEndpoint()
                            
                            with pytest.raises(werkzeug.exceptions.NotFound) as exc_info:
                                endpoint.get("non-existent")
                             
                            assert "404 Not Found" in str(exc_info.value)


def test_update_assistant(app, mock_security_functions, mock_assistants, mock_data_sources_for_assistant, mock_system_instructions_for_assistant, mock_shallow_user):
    """Test updating an assistant."""
    with app.app_context():
        with app.test_request_context(method='PUT', json={
            "name": "Updated Assistant",
            "description": "Updated description",
            "llmIds": ["1"],
            "customSystemInstruction": "Updated instruction",
            "greetingMessage": "Updated greeting",
            "sampleQuestions": ["Updated question"],
            "tags": [{"id": "tag2"}],
            "systemInstructionIds": ["sys2"],
            "dataSourceIds": ["ds2"]
        }):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_get_user.return_value = mock_shallow_user
                
                mock_assistant = mock_assistants['updated_assistant']
                
                with mock.patch('maxgpt.api.impl.assistant.get_assistant') as mock_get_assistant:
                    mock_get_assistant.return_value = (mock_assistant, PermissionType.WRITE)
                    
                    # Mock ModuleRegistry.get_module
                    mock_llm = MagicMock()
                    mock_llm.get_id.return_value = "1"
                    mock_llm.get_spec.return_value = MagicMock(get_module_type=lambda: ModuleType.LLM)
                    
                    with mock.patch('maxgpt.modules.ModuleRegistry.get_module') as mock_get_module:
                        mock_get_module.return_value = mock_llm
                        
                        # Mock database models
                        with mock.patch('maxgpt.services.database_model.DataSourceModel.query') as mock_ds_query:        
                            mock_ds = mock_data_sources_for_assistant['data_source_2']
                            mock_ds_query.get.return_value = mock_ds

                            with mock.patch('maxgpt.services.database_model.SystemInstructionModel.query') as mock_si_query:
                                mock_si = mock_system_instructions_for_assistant['system_instruction_2']
                                mock_si_query.get_or_404.return_value = mock_si

                                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                    mock_db_session.scalars.return_value = set()
                                    mock_db_session.commit = MagicMock()
 
                                    with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
                                        mock_object_session.return_value = mock_db_session

                                        with mock.patch('maxgpt.api.impl.assistant.with_access_permission') as mock_with_permission:
                                            with mock.patch('maxgpt.api.impl.assistant.with_hidden') as mock_with_hidden:
                                                with mock.patch('maxgpt.api.impl.assistant.with_favorite') as mock_with_favorite:
                                                    mock_with_permission.return_value = mock_assistant.to_dict()
                                                    mock_with_hidden.return_value = mock_assistant.to_dict()
                                                    mock_with_favorite.return_value = mock_assistant.to_dict()

                                                    endpoint = AssistantEndpoint()
                                                    response = endpoint.put("assistant-1")

                                                    assert response.status_code == 200
                                                    response_data = response.get_json()
                                                    assert response_data["name"] == "Updated Assistant"
                                                    assert response_data["description"] == "Updated description"


def test_delete_assistant_hard_delete(app, mock_security_functions, mock_assistants, mock_shallow_user):
    """Test hard deleting an assistant."""
    with app.app_context():
        with app.test_request_context(method='DELETE', query_string="hardDelete=true"):
            _ = mock_security_functions
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_get_user.return_value = mock_shallow_user

                mock_assistant = mock_assistants['base_assistant']

                with mock.patch('maxgpt.api.impl.assistant.get_assistant') as mock_get_assistant:
                    mock_get_assistant.return_value = (mock_assistant, PermissionType.WRITE)

                    # Patch AgentWorkflowModel.query.filter().filter().first() to return None
                    with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_workflow_query:
                        mock_filter = MagicMock()
                        mock_filter.filter.return_value = mock_filter
                        mock_filter.first.return_value = None
                        mock_workflow_query.filter.return_value = mock_filter

                        # Mock UserFavoriteModel.query.filter
                        with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_fav_query:     
                            mock_fav_query.filter.return_value.delete = MagicMock()

                            # Mock UserHiddenEntityModel.query.filter
                            with mock.patch('maxgpt.services.database_model.UserHiddenEntityModel.query') as mock_hidden_query:
                                mock_hidden_query.filter.return_value.delete = MagicMock()

                                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                    mock_db_session.commit = MagicMock()
                                    mock_db_session.delete = MagicMock()

                                    with mock.patch('maxgpt.api.impl.assistant.with_access_permission') as mock_with_permission:
                                        with mock.patch('maxgpt.api.impl.assistant.with_hidden') as mock_with_hidden:    
                                            with mock.patch('maxgpt.api.impl.assistant.with_favorite') as mock_with_favorite:
                                                mock_with_permission.return_value = mock_assistant.to_dict()
                                                mock_with_hidden.return_value = mock_assistant.to_dict()
                                                mock_with_favorite.return_value = mock_assistant.to_dict()

                                                endpoint = AssistantEndpoint()
                                                response = endpoint.delete("assistant-1")

                                                assert response.status_code == 200
                                                response_data = response.get_json()
                                                assert response_data["id"] == "1" 
                                                mock_db_session.delete.assert_called_once_with(mock_assistant)

 