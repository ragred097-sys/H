import pytest
from unittest import mock
from unittest.mock import MagicMock

import json
from datetime import datetime

from maxgpt.services.eqty.util import is_eqty_enabled
from maxgpt.services.database_model import PermissionType
from maxgpt.api.impl.agent import AgentEndpoint, AgentsEndpoint, get_agent


class TestGetAgent:
    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    def test_get_agent_not_found(self, mock_query):
        """Test getting non-existent agent returns 404."""
        mock_query.filter.return_value.filter.return_value.first.return_value = None

        with pytest.raises(Exception) as exc_info:
            get_agent("1", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'does not exist' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    def test_get_agent_unauthorized(self, mock_query, mock_access, mock_agents):
        """Test getting agent without sufficient permissions returns 401."""
        mock_query.filter.return_value.filter.return_value.first.return_value = mock_agents['base_agent']
        mock_access.return_value = PermissionType.READ
            
        # Try to get with WRITE permission when only READ granted
        with pytest.raises(Exception) as exc_info:
                get_agent("1", PermissionType.WRITE)
        assert '401' in str(exc_info.value)
        assert 'Not authorized' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    def test_get_agent_success(self, mock_query, mock_access, mock_agents):
        """Test successfully getting an agent."""
        mock_agent = mock_agents['base_agent']
        mock_query.filter.return_value.filter.return_value.first.return_value = mock_agent
        mock_access.return_value = PermissionType.WRITE
        
        agent, grant = get_agent("test-id", PermissionType.READ)
        assert agent == mock_agent
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    def test_get_deleted_agent(self, mock_query, mock_access, mock_agents):
        """Test getting a deleted agent when include_deleted is True."""
        mock_agent = mock_agents['base_agent']
        mock_agent.deleted_at = datetime.now()
        mock_query.filter.return_value.first.return_value = mock_agent
        mock_access.return_value = PermissionType.WRITE
            
        agent, grant = get_agent("test-id", PermissionType.READ, include_deleted=True)
        assert agent == mock_agent
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    def test_refuse_deleted_agent(self, mock_query, mock_access):
        """Test refusing to get a deleted agent when include_deleted is False."""
        mock_query.filter.return_value.filter.return_value.first.return_value = None
        mock_access.return_value = PermissionType.WRITE

        with pytest.raises(Exception) as exc_info:
            get_agent("1", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'does not exist' in str(exc_info.value.data["message"])


@pytest.mark.usefixtures("apprd_mock")
class TestAgentEndpoint:
    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    @mock.patch('maxgpt.api.impl.agent.SessionContext')
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value="READ")
    @mock.patch('maxgpt.api.impl.agent.PermissionType.rank', side_effect=lambda x: 1 if x == "READ" else 0)
    @mock.patch('maxgpt.api.impl.agent.with_favorite', return_value={"id": "1", "name": "Agent 1"})
    @mock.patch('maxgpt.api.impl.agent.with_access_permission', return_value={"id": "1", "name": "Agent 1"})
    @mock.patch('maxgpt.api.impl.agent.with_hidden', return_value={"id": "1", "name": "Agent 1"})
    def test_get_agent_by_id(self, mock_hidden, mock_access_perm, mock_favorite, mock_rank, 
                            mock_access, mock_session_context, mock_query,
                            app, mock_agents, mock_security_function_permission):
        """Test to get an agent by its ID."""
        mock_agent = mock_agents['base_agent']
        mock_agent.to_dict.return_value = {"id": "1", "name": "Agent 1"}
        mock_query.filter.return_value.first.return_value = mock_agent

        mock_user = mock.MagicMock()
        mock_user.get_id.return_value = "user1"
        mock_session_context.get_current_user.return_value = mock_user

        endpoint = AgentEndpoint()
        response = endpoint.get("1")

        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data["id"] == "1"
        assert response_data["name"] == "Agent 1"

    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value=PermissionType.WRITE)
    @mock.patch('maxgpt.api.impl.agent.UserFavoriteModel.query')
    @mock.patch('maxgpt.api.impl.agent.UserHiddenEntityModel.query')
    @mock.patch('maxgpt.api.impl.agent.SessionContext.get_current_user')
    @mock.patch('maxgpt.services.database.session')
    @mock.patch('maxgpt.api.impl.agent.with_favorite', side_effect=lambda d, _: d)
    @mock.patch('maxgpt.api.impl.agent.with_access_permission', side_effect=lambda d, p: d)
    @mock.patch('maxgpt.api.impl.agent.with_hidden', side_effect=lambda d, _: d)
    def test_delete_agent(self, mock_hidden, mock_access, mock_favorite, mock_db_session, mock_session_context,
                         mock_hidden_query, mock_fav_query, mock_get_access, mock_workflow_query, mock_query,
                         app, mock_security_functions, mock_agents):
        """Test deleting an agent."""
        mock_agent = mock_agents['base_agent']
        mock_agent.deleted_at = None
        mock_agent.to_dict.return_value = {
            "id": "1",
            "name": "Agent 1"
        }

        mock_query.filter.return_value.filter.return_value.first.return_value = mock_agent
        mock_workflow_query.filter.return_value.first.return_value = None
        mock_fav_query.filter.return_value.delete.return_value = 1
        mock_hidden_query.filter.return_value.delete.return_value = 1

        mock_user = mock.MagicMock()
        mock_user.get_id.return_value = "user1"
        mock_session_context.return_value = mock_user

        mock_db_session.delete = mock.MagicMock()
        mock_db_session.commit = mock.MagicMock()

        endpoint = AgentEndpoint()
        response = endpoint.delete("1")

        assert response.status_code == 200
        response_data = response.get_json()
        assert response_data["id"] == "1"
        assert response_data["name"] == "Agent 1"

    @mock.patch('maxgpt.services.database_model.AgentModel.query')
    @mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value=PermissionType.WRITE)
    @mock.patch('maxgpt.api.impl.agent.AgentTagRelationModel')
    @mock.patch('maxgpt.api.impl.agent.SystemInstructionModel.query.get_or_404')
    @mock.patch('maxgpt.api.impl.agent.ModuleModel.query.get_or_404')
    @mock.patch('maxgpt.api.impl.agent.AgentSystemInstructionRelationModel')
    @mock.patch('maxgpt.api.impl.agent.AgentModuleRelation')
    @mock.patch('maxgpt.api.impl.agent.Session.object_session', return_value=mock.MagicMock())
    @mock.patch('maxgpt.api.impl.agent.SessionContext.get_current_user')
    @mock.patch('maxgpt.services.database.session')
    @mock.patch('maxgpt.api.impl.agent.with_favorite', side_effect=lambda a, _: a)
    @mock.patch('maxgpt.api.impl.agent.with_access_permission', side_effect=lambda a, p: a)
    @mock.patch('maxgpt.api.impl.agent.with_hidden', side_effect=lambda a, _: a)
    def test_update_agent(self, mock_hidden, mock_access, mock_favorite, mock_db_session, mock_get_user, mock_object_session, 
                         mock_module_rel, mock_instruction_rel, mock_module_get, mock_instruction_get, mock_tag_rel, 
                         mock_access_for, mock_query, app, mock_security_functions, mock_agents):
        """Test updating an agent."""
        with app.test_request_context(
            '/agent/1', 
            method='PUT', 
            json={
                "name": "Updated Agent",
                "description": "Updated Description", 
                "image": "updated_image.png",
                "icon": "updated_icon.png",
                "tags": [{"id": "tag123"}],
                "systemInstructionIds": [],
                "functionToolIds": [],
                "customSystemInstruction": "Custom instruction text"
            }
        ):
            mock_agent = mock_agents['base_agent']
            mock_agent.deleted_at = None
            mock_agent.tag_relations = []
            mock_agent.system_instructions = []
            mock_agent.function_tools = []
            mock_agent.to_dict.return_value = {
                "id": "1",
                "name": "Updated Agent",
                "description": "Updated Description",
                "icon": "updated_icon.png", 
                "image": "updated_image.png",
                "tags": [{"id": "tag123"}]
            }

            mock_query.filter.return_value.filter.return_value.first.return_value = mock_agent

            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user1"
            mock_get_user.return_value = mock_user

            mock_db_session.scalars.return_value = iter([])  # Simulate empty favorites/hidden

            endpoint = AgentEndpoint()
            response = endpoint.put("1")

            assert response


@pytest.mark.usefixtures("apprd_mock")
@mock.patch('maxgpt.api.impl.agent.fetch_with_permissions')
@mock.patch('maxgpt.services.data_model.user.UserModel.query')
class TestAgentsEndpoint:
    def test_get_agents(self, mock_user_query, mock_fetch, mock_agents):
        """Test the get_agents endpoint functionality."""

        # Mock user query
        mock_user = mock.MagicMock()
        mock_user_query.filter.return_value.first.return_value = mock_user

        # Mock agent permissions
        mock_fetch.return_value = mock_agents['all_agents']
        endpoint = AgentsEndpoint()
        response = endpoint.get()

        response_data = response.get_json()
        assert response.status_code == 200
        assert response_data is not None, "Response data is None"
        assert isinstance(response_data, list)
        assert len(response_data) >= 2, "Expected at least 2 agents in response"
        assert response_data[0]["id"] == "1"
        assert response_data[0]["name"] == "Agent 1"
        assert response_data[1]["id"] == "2"
        assert response_data[1]["name"] == "Agent 2"


if is_eqty_enabled():

    from maxgpt.api.impl.agent import (
        AgentGovernanceConfigurationEndpoint,
        AgentGovernanceStatusEndpoint,
        AgentLineageEndpoint,
        AgentLineageExistsEndpoint,
        DEFAULT_GOVERNANCE_CONFIGURATION,
        DEFAULT_GOVERNANCE_STATUS,
        OVERRIDE_GOVERNANCE_CONFIGURATION
    )
    from werkzeug.exceptions import NotFound, Unauthorized

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentLineageExistsEndpoint:
        @mock.patch('maxgpt.api.impl.agent.get_agent')
        def test_get_lineage_exists_success(self, mock_get_agent, mock_agents):
            """Test that the endpoint returns True when the agent has lineage."""
            mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.READ)
            endpoint = AgentLineageExistsEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() is True

        def test_lineage_exists_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AgentLineageExistsEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentLineageEndpoint:
        @mock.patch('maxgpt.api.impl.agent.get_named_lock')
        @mock.patch('maxgpt.api.impl.agent.generate_manifest_and_purge')
        @mock.patch('maxgpt.api.impl.agent.build_agent_lineage')
        @mock.patch('maxgpt.api.impl.agent.get_agent')
        def test_get_lineage_success(self, mock_get_agent, mock_build_lineage, mock_generate_manifest, mock_get_lock, mock_agents):
            """Test that the endpoint returns the manifest when lineage is built successfully."""
            manifest = {"foo": "bar"}
            mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.READ)
            mock_build_lineage.return_value = None
            mock_generate_manifest.return_value = manifest
            mock_lock = mock.MagicMock()
            mock_get_lock.return_value.__enter__.return_value = mock_lock
            endpoint = AgentLineageEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() == manifest

        @mock.patch('maxgpt.api.impl.agent.get_agent')
        def test_get_lineage_agent_not_found(self, mock_get_agent):
            """Test that the endpoint raises 404 if the agent is not found."""
            mock_get_agent.side_effect = NotFound("Agent not found")
            endpoint = AgentLineageEndpoint()
            with pytest.raises(NotFound):
                endpoint.get("nonexistent")

        @mock.patch('maxgpt.api.impl.agent.get_agent')
        def test_get_lineage_unauthorized(self, mock_get_agent):
            """Test that the endpoint raises 401 if unauthorized."""
            mock_get_agent.side_effect = Unauthorized("Not authorized")
            endpoint = AgentLineageEndpoint()
            with pytest.raises(Unauthorized):
                endpoint.get("unauthorized")

        def test_lineage_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AgentLineageEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentGovernanceConfigurationEndpoint:
        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_with_existing(self, mock_query, mock_get_agent, mock_agents):
            mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.READ)
            mock_governance = MagicMock()
            mock_governance.configuration = '{"foo": "bar"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AgentGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"foo": "bar"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_without_existing(self, mock_query, mock_get_agent, mock_agents):
            mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AgentGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            expected = json.dumps({**DEFAULT_GOVERNANCE_CONFIGURATION, **OVERRIDE_GOVERNANCE_CONFIGURATION})
            assert response.status_code == 200
            assert json.loads(response.get_data(as_text=True)) == json.loads(expected)
            assert response.mimetype == 'application/json'

        ORIGINAL_DATA = {"foo": "bar"}
        UPDATED_DATA = {"baz": 123}

        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_update_existing(self, mock_query, mock_get_agent, app, mock_agents):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.WRITE)
                mock_governance = MagicMock()
                mock_governance.configuration = json.dumps(self.ORIGINAL_DATA)
                mock_query.filter.return_value.first.return_value = mock_governance

                endpoint = AgentGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                expected = {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.ORIGINAL_DATA,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == expected
                assert response.mimetype == 'application/json'
                assert mock_governance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel')
        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_create_new(self, mock_query, mock_get_agent, mock_model, app, mock_agents):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.WRITE)
                # No existing governance
                mock_query.filter.return_value.first.return_value = None
                # Patch the model constructor and session.add
                mock_instance = MagicMock()
                mock_instance.configuration = '{}'
                mock_instance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)
                mock_model.return_value = mock_instance

                endpoint = AgentGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.mimetype == 'application/json'
                assert mock_instance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        def test_governance_configuration_options(self):
            endpoint = AgentGovernanceConfigurationEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentGovernanceStatusEndpoint:
        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_with_existing_governance(self, mock_query, mock_get_agent, mock_agents):
            """Test getting governance status when governance record exists."""
            mock_get_agent.return_value = (mock_agents['base_agent'], PermissionType.READ)
            # Mock governance query
            mock_governance = MagicMock()
            mock_governance.status = '{"test": "status"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AgentGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"test": "status"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.agent.get_agent')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_without_existing_governance(self, mock_query, mock_get_agent):
            """Test getting governance status when no governance record exists."""
            # Mock governance query returning None
            mock_get_agent.return_value = (MagicMock(), PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AgentGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == json.dumps(DEFAULT_GOVERNANCE_STATUS)
            assert response.mimetype == 'application/json'

        def test_governance_status_options(self):
            """Test the OPTIONS request handler."""
            endpoint = AgentGovernanceStatusEndpoint()
            response, status_code = endpoint.options("1")
                    
            assert status_code == 200
            assert response == ''

else:

    def test_eqty_is_disabled(app):
        """Verify that the endpoint does not exist when EQTY is disabled."""
        with pytest.raises(ImportError):
            from maxgpt.api.impl.agent import AgentGovernanceStatusEndpoint
