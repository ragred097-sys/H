import pytest
from unittest import mock
from unittest.mock import MagicMock

import json
from datetime import datetime

from maxgpt.services.database_model import PermissionType
from maxgpt.services.eqty.util import is_eqty_enabled
from maxgpt.api.impl.assistant import get_assistant


class TestGetAssistant:
    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.services.database_model.AssistantModel.query')
    def test_get_assistant_not_found(self, mock_query):
        """Test getting non-existent assistant returns 404."""
        mock_query.filter.return_value.filter.return_value.first.return_value = None

        with pytest.raises(Exception) as exc_info:
            get_assistant("1", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'does not exist' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.assistant.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AssistantModel.query')
    def test_get_assistant_unauthorized(self, mock_query, mock_access, mock_assistants):
        """Test getting assistant without sufficient permissions returns 401."""
        mock_query.filter.return_value.filter.return_value.first.return_value = mock_assistants[0]
        mock_access.return_value = PermissionType.READ
            
        # Try to get with WRITE permission when only READ granted
        with pytest.raises(Exception) as exc_info:
                get_assistant("1", PermissionType.WRITE)
        assert '401' in str(exc_info.value)
        assert 'Not authorized' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.assistant.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AssistantModel.query')
    def test_get_assistant_success(self, mock_query, mock_access, mock_assistants):
        """Test successfully getting an assistant."""
        mock_assistant = mock_assistants[0]
        mock_query.filter.return_value.filter.return_value.first.return_value = mock_assistant
        mock_access.return_value = PermissionType.WRITE
        
        assistant, grant = get_assistant("test-id", PermissionType.READ)
        assert assistant == mock_assistant
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.assistant.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AssistantModel.query')
    def test_get_deleted_assistant(self, mock_query, mock_access, mock_assistants):
        """Test getting a deleted assistant when include_deleted is True."""
        mock_assistant = mock_assistants[0]
        mock_assistant.deleted_at = datetime.now()
        mock_query.filter.return_value.first.return_value = mock_assistant
        mock_access.return_value = PermissionType.WRITE
            
        assistant, grant = get_assistant("test-id", PermissionType.READ, include_deleted=True)
        assert assistant == mock_assistant
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.assistant.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AssistantModel.query')
    def test_refuse_deleted_assistant(self, mock_query, mock_access):
        """Test refusing to get a deleted assistant when include_deleted is False."""
        mock_query.filter.return_value.filter.return_value.first.return_value = None
        mock_access.return_value = PermissionType.WRITE

        with pytest.raises(Exception) as exc_info:
            get_assistant("1", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'does not exist' in str(exc_info.value.data["message"])


# TODO: Add tests for the assistant endpoint


if is_eqty_enabled():

    from maxgpt.api.impl.assistant import (
        AssistantGovernanceConfigurationEndpoint,
        AssistantGovernanceStatusEndpoint,
        AssistantLineageEndpoint,
        AssistantLineageExistsEndpoint,
        DEFAULT_GOVERNANCE_CONFIGURATION,
        DEFAULT_GOVERNANCE_STATUS,
        OVERRIDE_GOVERNANCE_CONFIGURATION
    )
    from werkzeug.exceptions import NotFound, Unauthorized

    @pytest.mark.usefixtures("apprd_mock")
    class TestAssistantLineageExistsEndpoint:
        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        def test_get_lineage_exists_success(self, mock_get_assistant, mock_assistants):
            """Test that the endpoint returns True when the assistant has lineage."""
            mock_get_assistant.return_value = (mock_assistants[0], PermissionType.READ)
            endpoint = AssistantLineageExistsEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() is True

        def test_lineage_exists_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AssistantLineageExistsEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAssistantLineageEndpoint:
        @mock.patch('maxgpt.api.impl.assistant.get_named_lock')
        @mock.patch('maxgpt.api.impl.assistant.generate_manifest_and_purge')
        @mock.patch('maxgpt.api.impl.assistant.build_assistant_lineage')
        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        def test_get_lineage_success(self, mock_get_assistant, mock_build_lineage, mock_generate_manifest, mock_get_lock, mock_assistants):
            """Test that the endpoint returns the manifest when lineage is built successfully."""
            manifest = {"foo": "bar"}
            mock_get_assistant.return_value = (mock_assistants[0], PermissionType.READ)
            mock_build_lineage.return_value = None
            mock_generate_manifest.return_value = manifest
            mock_lock = mock.MagicMock()
            mock_get_lock.return_value.__enter__.return_value = mock_lock
            endpoint = AssistantLineageEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() == manifest

        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        def test_get_lineage_assistant_not_found(self, mock_get_assistant):
            """Test that the endpoint raises 404 if the assistant is not found."""
            mock_get_assistant.side_effect = NotFound("Assistant not found")
            endpoint = AssistantLineageEndpoint()
            with pytest.raises(NotFound):
                endpoint.get("nonexistent")

        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        def test_get_lineage_unauthorized(self, mock_get_assistant):
            """Test that the endpoint raises 401 if unauthorized."""
            mock_get_assistant.side_effect = Unauthorized("Not authorized")
            endpoint = AssistantLineageEndpoint()
            with pytest.raises(Unauthorized):
                endpoint.get("unauthorized")

        def test_lineage_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AssistantLineageEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAssistantGovernanceConfigurationEndpoint:
        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_with_existing(self, mock_query, mock_get_assistant, mock_assistants):
            mock_get_assistant.return_value = (mock_assistants[0], PermissionType.READ)
            mock_governance = MagicMock()
            mock_governance.configuration = '{"foo": "bar"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AssistantGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"foo": "bar"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_without_existing(self, mock_query, mock_get_assistant, mock_assistants):
            mock_get_assistant.return_value = (mock_assistants[0], PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AssistantGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            expected = json.dumps({**DEFAULT_GOVERNANCE_CONFIGURATION, **OVERRIDE_GOVERNANCE_CONFIGURATION})
            assert response.status_code == 200
            assert json.loads(response.get_data(as_text=True)) == json.loads(expected)
            assert response.mimetype == 'application/json'

        ORIGINAL_DATA = {"foo": "bar"}
        UPDATED_DATA = {"baz": 123}

        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_update_existing(self, mock_query, mock_get_assistant, app, mock_assistants):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_assistant.return_value = (mock_assistants[0], PermissionType.WRITE)
                mock_governance = MagicMock()
                mock_governance.configuration = json.dumps(self.ORIGINAL_DATA)
                mock_query.filter.return_value.first.return_value = mock_governance

                endpoint = AssistantGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                expected = {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.ORIGINAL_DATA,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == expected
                assert response.mimetype == 'application/json'
                assert mock_governance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel')
        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_create_new(self, mock_query, mock_get_assistant, mock_model, app, mock_assistants):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_assistant.return_value = (mock_assistants[0], PermissionType.WRITE)
                # No existing governance
                mock_query.filter.return_value.first.return_value = None
                # Patch the model constructor and session.add
                mock_instance = MagicMock()
                mock_instance.configuration = '{}'
                mock_instance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)
                mock_model.return_value = mock_instance

                endpoint = AssistantGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.mimetype == 'application/json'
                assert mock_instance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        def test_governance_configuration_options(self):
            endpoint = AssistantGovernanceConfigurationEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAssistantGovernanceStatusEndpoint:
        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_with_existing_governance(self, mock_query, mock_get_assistant, mock_assistants):
            """Test getting governance status when governance record exists."""
            mock_get_assistant.return_value = (mock_assistants[0], PermissionType.READ)
            # Mock governance query
            mock_governance = MagicMock()
            mock_governance.status = '{"test": "status"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AssistantGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"test": "status"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.assistant.get_assistant')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_without_existing_governance(self, mock_query, mock_get_assistant):
            """Test getting governance status when no governance record exists."""
            # Mock governance query returning None
            mock_get_assistant.return_value = (MagicMock(), PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AssistantGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == json.dumps(DEFAULT_GOVERNANCE_STATUS)
            assert response.mimetype == 'application/json'

        def test_governance_status_options(self):
            """Test the OPTIONS request handler."""
            endpoint = AssistantGovernanceStatusEndpoint()
            response, status_code = endpoint.options("1")
                    
            assert status_code == 200
            assert response == ''

else:

    def test_eqty_is_disabled(app):
        """Verify that the endpoint does not exist when EQTY is disabled."""
        with pytest.raises(ImportError):
            from maxgpt.api.impl.assistant import AssistantGovernanceStatusEndpoint
