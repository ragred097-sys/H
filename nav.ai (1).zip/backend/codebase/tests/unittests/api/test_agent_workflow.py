from unittest import mock 
from unittest.mock import MagicMock
import pytest

import json
from datetime import datetime
from flask import Response

from maxgpt.api.impl.agent_workflows import AgentWorkflowsEndpoint, AgentWorkflowEndpoint, AgentWorkflowFactoryEndpoint, get_agent_workflow
from maxgpt.services.database_model import PermissionType
from maxgpt.services.persistence import database
from maxgpt.services.eqty.util import is_eqty_enabled


class TestGetAgentWorkflow:
    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_get_agent_workflow_not_found(self, mock_query):
        """Test getting non-existent agent_workflow returns 404."""
        mock_query.get.return_value = None

        with pytest.raises(Exception) as exc_info:
            get_agent_workflow("test-id", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'does not exist' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent_workflows.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_get_agent_workflow_unauthorized(self, mock_query, mock_access, mock_agent_workflows):
        """Test getting agent_workflow without sufficient permissions returns 401."""
        mock_query.get.return_value = mock_agent_workflows[0]
        mock_access.return_value = PermissionType.READ
            
        # Try to get with WRITE permission when only READ granted
        with pytest.raises(Exception) as exc_info:
                get_agent_workflow("1", PermissionType.WRITE)
        assert '401' in str(exc_info.value)
        assert 'Not authorized' in str(exc_info.value.data["message"])

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent_workflows.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_get_agent_workflow_success(self, mock_query, mock_access, mock_agent_workflows):
        """Test successfully getting an agent_workflow."""
        mock_agent_workflow = mock_agent_workflows[0]
        mock_query.get.return_value = mock_agent_workflow
        mock_access.return_value = PermissionType.WRITE
        
        agent_workflow, grant = get_agent_workflow("test-id", PermissionType.READ)
        assert agent_workflow == mock_agent_workflow
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent_workflows.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_get_deleted_agent_workflow(self, mock_query, mock_access, mock_agent_workflows):
        """Test getting a deleted agent_workflow when include_deleted is True."""
        mock_agent_workflow = mock_agent_workflows[0]
        mock_agent_workflow.deleted_at = datetime.now()
        mock_query.get.return_value = mock_agent_workflow
        mock_access.return_value = PermissionType.WRITE
            
        agent_workflow, grant = get_agent_workflow("test-id", PermissionType.READ, include_deleted=True)
        assert agent_workflow == mock_agent_workflow
        assert grant == PermissionType.WRITE

    @pytest.mark.usefixtures("apprd_mock")
    @mock.patch('maxgpt.api.impl.agent_workflows.get_user_access_for')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_refuse_deleted_agent_workflow(self, mock_query, mock_access, mock_agent_workflows):
        """Test refusing to get a deleted agent_workflow when include_deleted is False."""
        mock_agent_workflow = mock_agent_workflows[0]
        mock_agent_workflow.deleted_at = datetime.now()
        mock_query.get.return_value = mock_agent_workflow
        mock_access.return_value = PermissionType.WRITE

        with pytest.raises(Exception) as exc_info:
            get_agent_workflow("1", PermissionType.READ)
        assert '404' in str(exc_info.value)
        assert 'has been deleted' in str(exc_info.value.data["message"])
        assert 'and cannot be modified' not in str(exc_info.value.data["message"])

        with pytest.raises(Exception) as exc_info:
            get_agent_workflow("1", PermissionType.WRITE)
        assert '404' in str(exc_info.value)
        assert 'and cannot be modified' in str(exc_info.value.data["message"])


@pytest.mark.usefixtures("apprd_mock")
class TestAgentWorkflowEndpoint:
    def test_get_agent_workflows(self, app, mock_security_function_permission, mock_agentworkflows):
        """Test the get_agent_workflows endpoint functionality."""
        @mock.patch('maxgpt.services.data_model.user.UserModel.query')
        @mock.patch('maxgpt.api.impl.agent_workflows.fetch_with_permissions')
        def test_get_agent_workflows(self, mock_fetch, mock_user_query, app, mock_security_function_permission, mock_agentworkflows):
            mock_user = mock.MagicMock()
            mock_user_query.filter.return_value.first.return_value = mock_user
            mock_fetch.return_value = mock_agentworkflows['all_agent_workflows']

            database.session.scalars.return_value.all.return_value = []
            
            endpoint = AgentWorkflowsEndpoint()
            # Default: all agent workflows
            response = endpoint.get()
            response_data = response.get_json()
            assert response.status_code == 200
            assert response_data is not None, "Response data is None"
            assert response_data[0]["id"] == "1"
            assert response_data[0]["name"] == "Agent Workflow 1" 
            assert response_data[1]["id"] == "2"
            assert response_data[1]["name"] == "Agent Workflow 2"
            # Search by name
            with app.test_request_context('/agent-workflows/?search=Agent%20Workflow%201'):
                response = endpoint.get()
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data is not None
                assert len(response_data) == 1
                assert response_data[0]["id"] == "1"
                assert response_data[0]["name"] == "Agent Workflow 1"
            # Search by description
            with app.test_request_context('/agent-workflows/?search=Description%201'):
                response = endpoint.get()
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data is not None
                assert len(response_data) == 1
                assert response_data[0]["id"] == "1"
                assert response_data[0]["name"] == "Agent Workflow 1"
            # Search no match
            with app.test_request_context('/agent-workflows/?search=NonExistent'):
                response = endpoint.get()
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data is not None
                assert len(response_data) == 0
            # Search invalid regex
            with app.test_request_context('/agent-workflows/?search=('):
                response = endpoint.get()
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data is not None
                assert len(response_data) == 0
                            
    def test_update_agent_workflow(self, app, mock_security_functions, mock_agentworkflows):
        """Test PUT method of agent workflow"""
        update_data = {
            "name": "Updated agent workflow",
            "description": "Updated Test description",
            "image": "Updated image",
            "agents": [
                {
                    "id": "agent1",
                    "type": "Agent",
                    "canHandOffTo": []
                }
            ],
            "rootAgent": {
                "id": "agent1",
                "type": "Agent"
            }
        }
        mock_agent_workflow = mock_agentworkflows['update_agent_workflow']
        mock_agent_workflow.deleted_at = None
        mock_agent_workflow.tag_relations = []
        mock_agent_workflow.agent_relations = []
        mock_agent_workflow.assistant_relations = []
        mock_agent_workflow.data_source_relations = []
        mock_agent_workflow.handoff_relations = []

        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions 
            with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_query:
                mock_query.get.return_value = mock_agentworkflows['update_agent_workflow']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    
                    with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
                        mock_object_session.return_value = mock_db_session
                        
                        with mock.patch('maxgpt.api.impl.agent_workflows.with_hidden', return_value=mock_agentworkflows['update_agent_workflow'].to_dict()):
                            endpoint = AgentWorkflowEndpoint()
                            response: Response = endpoint.put("1")
                            
                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["id"] == "1"
                            assert response_data["name"] == "Updated agent workflow"
                            assert len(response_data["agents"]) == 1
                            assert response_data["agents"][0]["type"] == "Agent"


    @mock.patch('maxgpt.services.security.ShallowUser.to_dict', return_value={'id': 'user123', 'name': 'Test User'})
    @mock.patch('maxgpt.services.data_model.user.UserModel.query')
    @mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel')
    @mock.patch('maxgpt.api.impl.agent_workflows.with_favorite')
    @mock.patch('maxgpt.api.impl.agent_workflows.with_access_permission')
    @mock.patch('maxgpt.api.impl.agent_workflows.with_hidden')
    def test_create_agent_workflow(self, mock_hidden, mock_access_permission, mock_favorite,
                                 mock_agent_workflow_model, mock_get_current_user,
                                 mock_user_query, mock_shallow_user_to_dict,
                                 app, mock_security_functions, mock_agentworkflows):
        """Test POST method of agent workflow."""
        with app.test_request_context(method='POST', json={
            "id": "new-uuid", 
            "name": "New Agent Workflow",
            "description": "Agent Workflow description",
            "tags": [],
            "icon": "newicon",
            "image": "newimage",
            "agents": [
                {
                    "id": "agent1",
                    "type": "Agent", 
                    "canHandOffTo": []
                }
            ],
            "rootAgent": {
                "id": "agent1",
                "type": "Agent"
            }
        }):
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }

            mock_agentworkflows['new_agent_workflow'].creator = mock_user
            
            mock_user_query.filter.return_value.first.return_value = mock_user
            mock_get_current_user.return_value = mock_user
            mock_agent_workflow_model.return_value = mock_agentworkflows['new_agent_workflow']
            mock_favorite.return_value = mock_agentworkflows['new_agent_workflow'].to_dict()
            mock_access_permission.return_value = mock_agentworkflows['new_agent_workflow'].to_dict()
            mock_hidden.return_value = mock_agentworkflows['new_agent_workflow'].to_dict()

            endpoint = AgentWorkflowFactoryEndpoint()
            response = endpoint.post()

            assert response.status_code == 200
            response_data = response.get_json()
            
            assert response_data["name"] == "New Agent Workflow"
            assert response_data["id"] == "new-uuid"
            
            #Validate agents and root agent
            assert "agents" in response_data
            assert isinstance(response_data["agents"], list)
            assert response_data["agents"][0]["id"] == "agent1"
            assert response_data["agents"][0]["type"] == "Agent"
            
            assert response_data["rootAgent"]["id"] == "agent1"
            assert response_data["rootAgent"]["type"] == "Agent"

    @mock.patch('maxgpt.api.impl.agent_workflows.with_access_permission')
    @mock.patch('maxgpt.api.impl.agent_workflows.with_favorite')
    @mock.patch('maxgpt.api.impl.agent_workflows.with_hidden')
    @mock.patch('sqlalchemy.orm.session.Session.object_session')
    @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query')
    def test_delete_agent_workflow(self, mock_query, mock_object_session, mock_hidden, mock_favorite, mock_access_permission, app, mock_security_functions, mock_agentworkflows):
        """Test DELETE method of agent workflow"""
        mock_agent_workflow = mock_agentworkflows['base_agent_workflow']
        mock_agent_workflow.deleted_at = None
        mock_agent_workflow.to_dict.return_value = {
            '__type_name': 'AgentWorkflow',
            'id': '1',
            'name': 'Agent Workflow 1',
            'description': 'Description 1',
            'tags': [],
            'agents': [],
            'rootAgent': None,
            'icon': 'icon1',
            'image': 'image1',
            'permission': PermissionType.READ.value
        }

        mock_query.get.return_value = mock_agent_workflow
        mock_object_session.return_value = database.session
        mock_hidden.return_value = mock_agent_workflow.to_dict()
        mock_favorite.return_value = mock_agent_workflow.to_dict()
        mock_access_permission.return_value = mock_agent_workflow.to_dict()

        with app.test_request_context(method='DELETE'):
            endpoint = AgentWorkflowEndpoint()
            response = endpoint.delete("1")
            
            assert response.status_code == 200
            response_data = response.get_json()
            assert response_data["id"] == "1"
            assert response_data["name"] == "Agent Workflow 1"


if is_eqty_enabled():

    from maxgpt.api.impl.agent_workflows import (
        AgentWorkflowGovernanceConfigurationEndpoint,
        AgentWorkflowGovernanceStatusEndpoint,
        AgentWorkflowLineageEndpoint,
        AgentWorkflowLineageExistsEndpoint,
        DEFAULT_GOVERNANCE_CONFIGURATION,
        DEFAULT_GOVERNANCE_STATUS,
        OVERRIDE_GOVERNANCE_CONFIGURATION
    )
    from werkzeug.exceptions import NotFound, Unauthorized

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentWorkflowLineageExistsEndpoint:
        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        def test_get_lineage_exists_success(self, mock_get_agent_workflow, mock_agent_workflows):
            """Test that the endpoint returns True when the agent_workflow has lineage."""
            mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.READ)
            endpoint = AgentWorkflowLineageExistsEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() is True

        def test_lineage_exists_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AgentWorkflowLineageExistsEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentWorkflowLineageEndpoint:
        @mock.patch('maxgpt.api.impl.agent_workflows.get_named_lock')
        @mock.patch('maxgpt.api.impl.agent_workflows.generate_manifest_and_purge')
        @mock.patch('maxgpt.api.impl.agent_workflows.build_agent_workflow_lineage')
        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        def test_get_lineage_success(self, mock_get_agent_workflow, mock_build_lineage, mock_generate_manifest, mock_get_lock, mock_agent_workflows):
            """Test that the endpoint returns the manifest when lineage is built successfully."""
            manifest = {"foo": "bar"}
            mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.READ)
            mock_build_lineage.return_value = None
            mock_generate_manifest.return_value = manifest
            mock_lock = mock.MagicMock()
            mock_get_lock.return_value.__enter__.return_value = mock_lock
            endpoint = AgentWorkflowLineageEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_json() == manifest

        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        def test_get_lineage_agent_workflow_not_found(self, mock_get_agent_workflow):
            """Test that the endpoint raises 404 if the agent_workflow is not found."""
            mock_get_agent_workflow.side_effect = NotFound("AgentWorkflow not found")
            endpoint = AgentWorkflowLineageEndpoint()
            with pytest.raises(NotFound):
                endpoint.get("nonexistent")

        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        def test_get_lineage_unauthorized(self, mock_get_agent_workflow):
            """Test that the endpoint raises 401 if unauthorized."""
            mock_get_agent_workflow.side_effect = Unauthorized("Not authorized")
            endpoint = AgentWorkflowLineageEndpoint()
            with pytest.raises(Unauthorized):
                endpoint.get("unauthorized")

        def test_lineage_options(self):
            """Test that the endpoint options returns 200."""
            endpoint = AgentWorkflowLineageEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentWorkflowGovernanceConfigurationEndpoint:
        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_with_existing(self, mock_query, mock_get_agent_workflow, mock_agent_workflows):
            mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.READ)
            mock_governance = MagicMock()
            mock_governance.configuration = '{"foo": "bar"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AgentWorkflowGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"foo": "bar"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_configuration_without_existing(self, mock_query, mock_get_agent_workflow, mock_agent_workflows):
            mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AgentWorkflowGovernanceConfigurationEndpoint()
            response = endpoint.get("1")
            expected = json.dumps({**DEFAULT_GOVERNANCE_CONFIGURATION, **OVERRIDE_GOVERNANCE_CONFIGURATION})
            assert response.status_code == 200
            assert json.loads(response.get_data(as_text=True)) == json.loads(expected)
            assert response.mimetype == 'application/json'

        ORIGINAL_DATA = {"foo": "bar"}
        UPDATED_DATA = {"baz": 123}

        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_update_existing(self, mock_query, mock_get_agent_workflow, app, mock_agent_workflows):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.WRITE)
                mock_governance = MagicMock()
                mock_governance.configuration = json.dumps(self.ORIGINAL_DATA)
                mock_query.filter.return_value.first.return_value = mock_governance

                endpoint = AgentWorkflowGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                expected = {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.ORIGINAL_DATA,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == expected
                assert response.mimetype == 'application/json'
                assert mock_governance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel')
        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_put_governance_configuration_create_new(self, mock_query, mock_get_agent_workflow, mock_model, app, mock_agent_workflows):
            with app.test_request_context(method='PUT', json=self.UPDATED_DATA):
                mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.WRITE)
                # No existing governance
                mock_query.filter.return_value.first.return_value = None
                # Patch the model constructor and session.add
                mock_instance = MagicMock()
                mock_instance.configuration = '{}'
                mock_instance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)
                mock_model.return_value = mock_instance

                endpoint = AgentWorkflowGovernanceConfigurationEndpoint()
                response = endpoint.put("1")
                assert response.status_code == 200
                assert json.loads(response.get_data(as_text=True)) == {
                    **DEFAULT_GOVERNANCE_CONFIGURATION,
                    **self.UPDATED_DATA,
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                }
                assert response.mimetype == 'application/json'
                assert mock_instance.status == json.dumps(DEFAULT_GOVERNANCE_STATUS)

        def test_governance_configuration_options(self):
            endpoint = AgentWorkflowGovernanceConfigurationEndpoint()
            response, status_code = endpoint.options("1")
            assert status_code == 200
            assert response == ''

    @pytest.mark.usefixtures("apprd_mock")
    class TestAgentWorkflowGovernanceStatusEndpoint:
        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_with_existing_governance(self, mock_query, mock_get_agent_workflow, mock_agent_workflows):
            """Test getting governance status when governance record exists."""
            mock_get_agent_workflow.return_value = (mock_agent_workflows[0], PermissionType.READ)
            # Mock governance query
            mock_governance = MagicMock()
            mock_governance.status = '{"test": "status"}'
            mock_query.filter.return_value.first.return_value = mock_governance

            endpoint = AgentWorkflowGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == '{"test": "status"}'
            assert response.mimetype == 'application/json'

        @mock.patch('maxgpt.api.impl.agent_workflows.get_agent_workflow')
        @mock.patch('maxgpt.services.database_model.AssistantGovernanceModel.query')
        def test_get_governance_status_without_existing_governance(self, mock_query, mock_get_agent_workflow):
            """Test getting governance status when no governance record exists."""
            # Mock governance query returning None
            mock_get_agent_workflow.return_value = (MagicMock(), PermissionType.READ)
            mock_query.filter.return_value.first.return_value = None

            endpoint = AgentWorkflowGovernanceStatusEndpoint()
            response = endpoint.get("1")

            assert response.status_code == 200
            assert response.get_data(as_text=True) == json.dumps(DEFAULT_GOVERNANCE_STATUS)
            assert response.mimetype == 'application/json'

        def test_governance_status_options(self):
            """Test the OPTIONS request handler."""
            endpoint = AgentWorkflowGovernanceStatusEndpoint()
            response, status_code = endpoint.options("1")
                    
            assert status_code == 200
            assert response == ''

else:

    def test_eqty_is_disabled(app):
        """Verify that the endpoint does not exist when EQTY is disabled."""
        with pytest.raises(ImportError):
            from maxgpt.api.impl.agent_workflows import AgentWorkflowGovernanceStatusEndpoint
