import pytest
from unittest import mock
from unittest.mock import MagicMock
from maxgpt.navai.api.impl.recursive_operation import RecursiveOperationEndpoint

def test_recursive_delete_workspace(app, mock_security_functions, mock_workspaces):
    """Test for recursive DELETE operation on a Workspace entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Workspace/1', method='DELETE'):
            _ = mock_security_functions

            mock_workspace = mock_workspaces['base_workspace']
            mock_workspace.deleted_at = None
            mock_workspace.creator_id = "test_user"
            mock_workspace.to_dict.return_value = {
                "id": "1",
                "name": "Workspace 1"
            }
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_query:
                mock_query.get.return_value = mock_workspace

                mock_user = MagicMock()
                mock_user.get_id.return_value = "test_user"
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_get_user.return_value = mock_user

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.delete = MagicMock()
                        mock_db_session.commit = MagicMock()
                        endpoint = RecursiveOperationEndpoint()
                        response = endpoint.delete("workspace", "1")

                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["details"]["entity"]["id"] == "1"
                        assert response_data["details"]["entity"]["type"] == "workspace"
                        assert response_data["message"].startswith("Successfully deleted workspace")

def test_recursive_delete_assistant(app, mock_security_functions, mock_assistants):
    """Test for recursive DELETE operation on an Assistant entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Assistant/1', method='DELETE'):
            _ = mock_security_functions

            mock_assistant = mock_assistants[0]
            mock_assistant.creator_id = "test_user"
            mock_assistant.deleted_at = None
            mock_assistant.deleted_by = None
            mock_assistant.to_dict.return_value = {
                "id": "1",
                "name": "Assistant 1"
            }
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_query:
                mock_query.get.return_value = mock_assistant

                with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_aw_query:
                    mock_aw_query.filter.return_value.first.return_value = None

                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "test_user"
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                        mock_get_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.delete = MagicMock()
                            mock_db_session.commit = MagicMock()
                            endpoint = RecursiveOperationEndpoint()
                            response = endpoint.delete("assistant", "1")

                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["details"]["entity"]["id"] == "1"
                            assert response_data["details"]["entity"]["type"] == "assistant"
                            assert response_data["message"].startswith("Successfully deleted assistant")

def test_recursive_delete_agent(app, mock_security_functions, mock_agents):
    """Test for recursive DELETE operation on an Agent entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Agent/1', method='DELETE'):
            _ = mock_security_functions

            mock_agent = mock_agents['base_agent']
            mock_agent.creator_id = "test_user"
            mock_agent.deleted_at = None
            mock_agent.deleted_by = None
            mock_agent.to_dict.return_value = {
                "id": "1",
                "name": "Agent 1"
            }
            with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
                mock_query.get.return_value = mock_agent

                with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_aw_query:
                    mock_aw_query.filter.return_value.first.return_value = None

                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "test_user"
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                        mock_get_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.delete = MagicMock()
                            mock_db_session.commit = MagicMock()
                            endpoint = RecursiveOperationEndpoint()
                            response = endpoint.delete("agent", "1")

                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["details"]["entity"]["id"] == "1"
                            assert response_data["details"]["entity"]["type"] == "agent"
                            assert response_data["message"].startswith("Successfully deleted agent")

def test_recursive_delete_agent_workflow(app, mock_security_functions, mock_agent_workflows):
    """Test for recursive DELETE operation on an AgentWorkflow entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/AgentWorkflow/1', method='DELETE'):
            _ = mock_security_functions

            mock_workflow = mock_agent_workflows[0]
            mock_workflow.creator_id = "test_user"
            mock_workflow.deleted_at = None
            mock_workflow.deleted_by = None
            mock_workflow.to_dict.return_value = {
                "id": "1",
                "name": "Agent workflow 1"
            }
            with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_query:
                mock_query.get.return_value = mock_workflow

                mock_user = MagicMock()
                mock_user.get_id.return_value = "test_user"
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_get_user.return_value = mock_user

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.delete = MagicMock()
                        mock_db_session.commit = MagicMock()
                        endpoint = RecursiveOperationEndpoint()
                        response = endpoint.delete("agentworkflow", "1")

                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["details"]["entity"]["id"] == "1"
                        assert response_data["details"]["entity"]["type"] == "agentworkflow"
                        assert response_data["message"].startswith("Successfully deleted agentworkflow")

def test_recursive_restore_workspace(app, mock_security_functions, mock_workspaces):
    """Test for recursive restore operation on a Workspace entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Workspace/1', method='PATCH'):
            _ = mock_security_functions

            mock_workspace = mock_workspaces['base_workspace']
            mock_workspace.deleted_at = "20205-01-01T00:00:00"
            mock_workspace.creator_id = "test_user"
            mock_workspace.to_dict.return_value = {
                "id": "1",
                "name": "Workspace 1"
            }
            with mock.patch('maxgpt.services.database_model.WorkspaceModel.query') as mock_query:
                mock_query.get.return_value = mock_workspace

                mock_user = MagicMock()
                mock_user.get_id.return_value = "test_user"
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_get_user.return_value = mock_user

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.delete = MagicMock()
                        mock_db_session.commit = MagicMock()
                        endpoint = RecursiveOperationEndpoint()
                        response = endpoint.patch("workspace", "1")

                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["details"]["entity"]["id"] == "1"
                        assert response_data["details"]["entity"]["type"] == "workspace"
                        assert response_data["message"].startswith("Successfully restored workspace")

def test_recursive_restore_assistant(app, mock_security_functions, mock_assistants):
    """Test for recursive restore operation on an Assistant entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Assistant/1', method='PATCH'):
            _ = mock_security_functions

            mock_assistant = mock_assistants[0]
            mock_assistant.creator_id = "test_user"
            mock_assistant.deleted_at = "2025-01-01T00:00:00"
            mock_assistant.deleted_by = "test_user"
            mock_assistant.to_dict.return_value = {
                "id": "1",
                "name": "Assistant 1"
            }
            with mock.patch('maxgpt.services.database_model.AssistantModel.query') as mock_query:
                mock_query.get.return_value = mock_assistant

                with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_aw_query:
                    mock_aw_query.filter.return_value.first.return_value = None

                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "test_user"
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                        mock_get_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.delete = MagicMock()
                            mock_db_session.commit = MagicMock()
                            endpoint = RecursiveOperationEndpoint()
                            response = endpoint.patch("assistant", "1")

                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["details"]["entity"]["id"] == "1"
                            assert response_data["details"]["entity"]["type"] == "assistant"
                            assert response_data["message"].startswith("Successfully restored assistant")

def test_recursive_restore_agent(app, mock_security_functions, mock_agents):
    """Test for recursive restore operation on an Agent entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/Agent/1', method='PATCH'):
            _ = mock_security_functions

            mock_agent = mock_agents['base_agent']
            mock_agent.creator_id = "test_user"
            mock_agent.deleted_at = "2025-01-01T00:00:00"
            mock_agent.deleted_by = "test_user"
            mock_agent.to_dict.return_value = {
                "id": "1",
                "name": "Agent 1"
            }
            with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
                mock_query.get.return_value = mock_agent

                with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_aw_query:
                    mock_aw_query.filter.return_value.first.return_value = None

                    mock_user = MagicMock()
                    mock_user.get_id.return_value = "test_user"
                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                        mock_get_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.delete = MagicMock()
                            mock_db_session.commit = MagicMock()
                            endpoint = RecursiveOperationEndpoint()
                            response = endpoint.patch("agent", "1")

                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["details"]["entity"]["id"] == "1"
                            assert response_data["details"]["entity"]["type"] == "agent"
                            assert response_data["message"].startswith("Successfully restored agent")

def test_recursive_restore_agent_workflow(app, mock_security_functions, mock_agent_workflows):
    """Test for recursive restore operation on an AgentWorkflow entity"""
    with app.app_context():
        with app.test_request_context('/navai/recursive/AgentWorkflow/1', method='PATCH'):
            _ = mock_security_functions

            mock_workflow = mock_agent_workflows[0]
            mock_workflow.creator_id = "test_user"
            mock_workflow.deleted_at = "2025-01-01T00:00:00"
            mock_workflow.deleted_by = "test_user"
            mock_workflow.to_dict.return_value = {
                "id": "1",
                "name": "Agent workflow 1"
            }
            with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_query:
                mock_query.get.return_value = mock_workflow

                mock_user = MagicMock()
                mock_user.get_id.return_value = "test_user"
                with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                    mock_get_user.return_value = mock_user

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.delete = MagicMock()
                        mock_db_session.commit = MagicMock()
                        endpoint = RecursiveOperationEndpoint()
                        response = endpoint.patch("agentworkflow", "1")

                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["details"]["entity"]["id"] == "1"
                        assert response_data["details"]["entity"]["type"] == "agentworkflow"
                        assert response_data["message"].startswith("Successfully restored agentworkflow") 