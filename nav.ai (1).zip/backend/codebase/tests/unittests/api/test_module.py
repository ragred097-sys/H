import pytest
from unittest import mock
from maxgpt.api.impl.module import ModulesEndpoint, ModuleEndpoint
from flask import Response
import werkzeug


def test_get_modules(app, mock_security_function_permission, mock_modules):
    """Test the get_modules endpoint functionality."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission

            with mock.patch('maxgpt.api.impl.module.ModuleRegistry.get_modules') as mock_get_modules:
                mock_get_modules.return_value = mock_modules['all_modules']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = mock.MagicMock()
                    mock_scalars.all.return_value = []
                    mock_db_session.scalars.return_value = mock_scalars
                    
                    endpoint = ModulesEndpoint()
                    response = endpoint.get()
                    
                    response_data = response.get_json()
                    assert response.status_code == 200
                    assert response_data is not None
                    assert response_data[0]["id"] == "1"
                    assert response_data[0]["name"] == "Module 1"
                    assert response_data[0]["capabilities"] == [{'name': 'cap1', 'label': 'Capability 1', 'value': 'val1'}]
                    assert response_data[1]["id"] == "2"
                    assert response_data[1]["name"] == "Module 2"
                    assert response_data[1]["capabilities"] == [{'name': 'cap2', 'label': 'Capability 2', 'value': 'val2'}]

def test_get_module_by_id(app, mock_modules, mock_security_function_permission):
    """Test to get a module by its ID."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission

            with mock.patch('maxgpt.modules.ModuleRegistry.get_module') as mock_get_module:
                mock_get_module.return_value = mock_modules['base_module']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = mock.MagicMock()
                    mock_scalars.return_value = set()
                    mock_db_session.scalars.return_value = mock_scalars
                    
                    with mock.patch('maxgpt.api.impl.module.SessionContext') as mock_session_context:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user1"
                        mock_session_context.get_current_user.return_value = mock_user
                        
                        endpoint = ModuleEndpoint()
                        response = endpoint.get("1")

                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["id"] == "1"
                        assert response_data["name"] == "Module 1"
                        assert response_data["capabilities"] == [{'name': 'cap1', 'label': 'Capability 1', 'value': 'val1'}]

def test_get_module_by_id_not_found(app, mock_security_function_permission):
    """Test getting a module by a non-existent ID returns 404."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission

            with mock.patch('maxgpt.modules.ModuleRegistry.get_module') as mock_get_module:
                mock_get_module.return_value = None
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = mock.MagicMock()
                    mock_scalars.return_value = set()
                    mock_db_session.scalars.return_value = mock_scalars

                    with mock.patch('maxgpt.api.impl.module.SessionContext') as mock_session_context:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user1"
                        mock_session_context.get_current_user.return_value = mock_user

                        endpoint = ModuleEndpoint()
                        with pytest.raises(Exception) as excinfo:
                            endpoint.get("nonexistent-id")
                        assert "404" in str(excinfo.value)

def test_update_module(app, mock_security_functions, mock_modules):
    """Test update(PUT) for a module."""
    update_data = {
        "name": "Updated Module",
        "description": "Updated Test Description",
        "specId": "spec-1",
        "tags": [],
        "supportedInputs": ["TEXT"],
        "parameters": [{"name": "param1", "value": "updated_value1"}],
        "capabilities": [{"name": "cap1", "label": "Capability 1", "value": "updated_val1"}]
    }
    with app.app_context():
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions

            with mock.patch('maxgpt.api.impl.module.SessionContext') as mock_session_context:
                mock_user = mock.MagicMock()
                mock_user.get_id.return_value = "user1"
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                mock_user.effective_app_roles = [admin_role]
                mock_session_context.get_current_user.return_value = mock_user
                
                with mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                    mock_role = mock.MagicMock()
                    mock_role.application_access_role.name = "administrator"
                    mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                    
                    with mock.patch('maxgpt.modules.ModuleRegistry.update_module') as mock_update_module:
                        mock_update_module.return_value = mock_modules['update_module']
                        
                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.commit = mock.MagicMock()
                            
                            endpoint = ModuleEndpoint()
                            response: Response = endpoint.put("1")
                            
                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["id"] == "1"
                            assert response_data["name"] == "Updated Module"
                            assert response_data["description"] == "Updated Test Description"
                            assert response_data["capabilities"] == [{"name": "cap1", "label": "Capability 1", "value": "updated_val1"}]

def test_delete_module(app, mock_security_functions, mock_modules):
    """Test deletion of a module."""
    with app.app_context():
        with app.test_request_context('/module/1', method='DELETE'):
            _ = mock_security_functions
            mock_module = mock_modules['base_module']
            mock_module.to_dict.return_value = {
                "id": "1",
                "name": "Module 1"
            }

            with mock.patch('maxgpt.api.impl.module.SessionContext') as mock_session_context:
                mock_user = mock.MagicMock()
                mock_user.get_id.return_value = "user1"
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                mock_user.effective_app_roles = [admin_role]
                mock_session_context.get_current_user.return_value = mock_user
                
                with mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                    mock_role = mock.MagicMock()    
                    mock_role.application_access_role.name = "administrator"
                    mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                    
                    with mock.patch('maxgpt.services.database_model.ModuleModel.query') as mock_query:
                        mock_query.get.return_value = mock_modules['base_module']
                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                            mock_db_session.delete = mock.MagicMock()
                            mock_db_session.commit = mock.MagicMock()
                            
                            with mock.patch('maxgpt.api.impl.module.ModuleRegistry.delete_module') as mock_delete_module:
                                mock_delete_module.return_value = mock_modules['base_module']
                                
                                endpoint = ModuleEndpoint()
                                response = endpoint.delete("1")
                                
                                assert response.status_code == 200
                                response_data = response.get_json()
                                assert response_data["id"] == "1"
                                assert response_data["name"] == "Module 1" 

def test_create_module(app, mock_security_functions, mock_modules):
    """Test creating a new module via POST endpoint."""
    post_data = {
        "name": "New Module",
        "description": "Module description",
        "specId": "spec-new",
        "tags": [],
        "supportedInputs": ["AUDIO"],
        "parameters": [{"name": "param_new", "value": "new_value"}],
        "capabilities": [{"name": "cap_new", "label": "Capability New", "value": "new_val"}]
    }
    with app.app_context():
        with app.test_request_context(method='POST', json=post_data):
            _ = mock_security_functions
            with mock.patch('maxgpt.api.impl.module.SessionContext') as mock_session_context:
                mock_user = mock.MagicMock()
                mock_user.get_id.return_value = "user1"
                admin_role = mock.MagicMock()
                admin_role.id = "administrator"
                admin_role.name = "administrator"
                mock_user.effective_app_roles = [admin_role]
                mock_session_context.get_current_user.return_value = mock_user
                with mock.patch('maxgpt.services.database_model.UserApplicationAccessRoleRelationModel.query') as mock_role_query:
                    mock_role = mock.MagicMock()
                    mock_role.application_access_role.name = "administrator"
                    mock_role_query.join.return_value.filter.return_value.all.return_value = [mock_role]
                    with mock.patch('maxgpt.modules.ModuleSpecRegistry.get_module_spec') as mock_get_module_spec:
                        mock_spec = mock.Mock()
                        mock_spec.get_id.return_value = "spec-new"
                        mock_get_module_spec.return_value = mock_spec
                        with mock.patch('maxgpt.modules.ModuleRegistry.create_module') as mock_create_module:
                            mock_create_module.return_value = mock_modules['new_module']
                            with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                mock_db_session.commit = mock.MagicMock()
                                from maxgpt.api.impl.module import ModuleFactoryEndpoint
                                endpoint = ModuleFactoryEndpoint()
                                response = endpoint.post()
                                response_data = response.get_json()
                                assert response.status_code == 200
                                assert response_data["id"] == "new-uuid"
                                assert response_data["name"] == "New Module"
                                assert response_data["description"] == "Module description"
                                assert response_data["capabilities"] == [{"name": "cap_new", "label": "Capability New", "value": "new_val"}] 