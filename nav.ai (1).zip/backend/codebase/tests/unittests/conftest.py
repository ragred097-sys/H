import pytest
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from unittest import mock
from maxgpt.services.data_model.user import UserModel
from maxgpt.services.database_model import (
    AgentWorkflowModel,
    DataSourceModel,
    FavoriteSubject,
    TagCategoryModel,
    UserSettingModel,
    UserFavoriteModel,
    PreferenceModel,
    PreferenceScope,
    PermissionType,
    AssistantModel,
    WorkspaceModel,
    SystemInstructionModel,
    AgentModel,
    AccessPermissionModel,
    TagModel,
    SharedConversationModel, 
    database
) 
from maxgpt.core import DataType
from maxgpt.api import EntityType
from maxgpt.api.internal.utils import CustomJSONProvider 
from datetime import datetime
 
# Initialize SQLAlchemy
db = SQLAlchemy()

# Fixture to create a minimal Flask app instance with SQLAlchemy
@pytest.fixture
def app():
    # Create a Flask app
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'  # Use an in-memory database for testing
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Disable modification tracking
    app.config['TESTING'] = True  # Enable testing mode

    # Initialize SQLAlchemy with the app
    db.init_app(app)

    # Register models with SQLAlchemy (if not already done)
    from maxgpt.services.data_model.user import UserModel  # Import your models
    with app.app_context():
        db.create_all()  # Create tables for testing

    yield app  # Provide the app to the test

    # Clean up after the test
    with app.app_context():
        db.session.remove()
        db.drop_all()  # Drop all tables


# @pytest.fixture
# def mock_user():
#     mock_user = mock.MagicMock()
#     mock_user.get_id.return_value = 123 
#     return mock_user

@pytest.fixture
def mock_user():
    mock_user = mock.MagicMock()
    mock_user.get_id.return_value = 123
    # Simulate admin role for endpoints requiring admin privileges
    admin_role = mock.MagicMock()
    admin_role.id = "administrator"
    admin_role.name = "administrator"  # Needed for propagate_principal
    mock_user.effective_app_roles = [admin_role]
    return mock_user

# Fixture to mock Auth
@pytest.fixture
def mock_security_functions(mock_user):
    with mock.patch("maxgpt.services.internal.session_context.SessionContext.get_current_user") as mock_get_current_user:
        mock_get_current_user.return_value = mock_user
        with mock.patch('maxgpt.services.security.OpenIDAuthenticator.authenticate_user') as mock_auth: 
            yield mock_get_current_user

@pytest.fixture
def mock_security_function_permission(mock_user, mock_data_sources):
    with mock.patch("maxgpt.services.internal.session_context.SessionContext.get_current_user") as mock_get_current_user:
        mock_get_current_user.return_value = mock_user
        with mock.patch('maxgpt.services.security.OpenIDAuthenticator.authenticate_user') as mock_auth:
            with mock.patch("maxgpt.api.impl.data_source.fetch_with_permissions") as mock_fetch_with_permissions:
                mock_fetch_with_permissions.return_value = mock_data_sources
                yield mock_get_current_user, mock_fetch_with_permissions

@pytest.fixture
def mock_users(app):
    with app.app_context():  # Ensure app context is active
        # Mocking UserModel objects and their 'to_dict' method
        mock_user_1 = mock.MagicMock(spec=UserModel)
        print("MOCKED",mock_user_1)
        mock_user_1.to_dict.return_value = {
            "id": "1",
            "name": "User 1",
            "email": "user1@example.com",
            "createdAt": "2025-02-22T10:00:00Z",
        }

        mock_user_2 = mock.MagicMock(spec=UserModel)
        mock_user_2.to_dict.return_value = {
            "id": "2",
            "name": "User 2",
            "email": "user2@example.com",
            "createdAt": "2025-02-22T10:05:00Z",
        }

        return [mock_user_1, mock_user_2]


# Mocked data for testing
@pytest.fixture
def mock_data_sources(app):
    with app.app_context():  
        # Mocking DataSourceModel objects and their 'to_dict' method
        mock_data_source_1 = mock.MagicMock(spec=DataSourceModel)
        mock_data_source_1.to_dict.return_value = {
            "id": "1",
            "name": "DataSource 1",
            "description": "Test DataSource 1",
            "filterTag": None,
            "embeddingModelId": "embedding_model_1",
            "vectorStoreId": "vector_store_1",
            "fileStorageId": None,
            "tags": []
        } 
        mock_data_source_1.permission = PermissionType.READ

        mock_data_source_2 = mock.MagicMock(spec=DataSourceModel)
        mock_data_source_2.to_dict.return_value = {
            "id": "2",
            "name": "DataSource 2",
            "description": "Test DataSource 2",
            "filterTag": None,
            "embeddingModelId": "embedding_model_2",
            "vectorStoreId": "vector_store_2",
            "fileStorageId": None,
            "tags": []
        }
        mock_data_source_2.permission = PermissionType.READ

        return [mock_data_source_1, mock_data_source_2]


@pytest.fixture
def mock_user_favorites(app, mock_user):
    with app.app_context():
        # Create mock user favorites
        user_id = mock_user.get_id()
        
        # Create mock favorite object
        mock_favorite_1 = mock.MagicMock(spec=UserFavoriteModel)
        mock_favorite_1.to_dict.return_value = {
            "id": "fav1",
            "user_id": "28502f0c-300c-432a-b828-0ed68a771000",
            "subjectId": "8b4bd245-851f-4a91-82d4-1a4e53fc5609",
            "subject_type": "Workspace 1",
            "created_at": "2025-03-04T04:55:55.749113"
        }
        
        mock_favorite_2 = mock.MagicMock(spec=UserFavoriteModel)
        mock_favorite_2.to_dict.return_value = {
            "id": "fav2",
            "user_id": "28502f0c-300c-432a-b828-0ed68a771400",
            "subjectId": "8b4bd245-851f-4a91-82d4-1a4e53fc5611",
            "subject_type": "Workspace 2",
            "created_at": "2025-03-04T04:59:55.749113"
        }
        
        # Mock the query functionality
        with mock.patch.object(UserFavoriteModel, 'query') as mock_query:
            mock_filter_by = mock.MagicMock()
            mock_all = mock.MagicMock()
            
            # Configure the chain of method calls
            mock_query.filter_by.return_value = mock_filter_by
            mock_filter_by.all.return_value = [mock_favorite_1, mock_favorite_2]
            
            yield [mock_favorite_1, mock_favorite_2]

@pytest.fixture
def mock_user_favorite_post(app, mock_user):
    """Fixture to create mock data for testing the POST /<user_id>/favorite/ endpoint."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        user_id = mock_user.get_id()
        # Creating mock favorites data with consistent structure
        mock_favorites = [
            {
                "id": "fav1",
                "user_id": "28502f0c-300c-432a-b828-0ed68a771000",
                "subjectId": "8b4bd245-851f-4a91-82d4-1a4e53fc5609",
                "subject_type": FavoriteSubject.WORKSPACE.value,
                "created_at": "2025-03-04T04:55:55.749113"
            },
            {
                "id": "fav2",
                "user_id": "28502f0c-300c-432a-b828-0ed68a771400",
                "subjectId": "8b4bd245-851f-4a91-82d4-1a4e53fc5611",
                "subject_type": FavoriteSubject.WORKSPACE.value,
                "created_at": "2025-03-04T04:59:55.749113"
            }
        ]
        
        # Create MagicMock objects with to_dict method for each favorites
        mock_favorite_objects = [
            mock.MagicMock(spec=UserFavoriteModel, to_dict=mock.MagicMock(return_value=favorite)) 
            for favorite in mock_favorites
        ]
        
        return mock_favorite_objects

    
@pytest.fixture
def mock_favorites(app):
    """Fixture to create mock user favorites for testing."""
    with app.app_context(): 
        from maxgpt.services.database_model import UserFavoriteModel, FavoriteSubject
        
        # Mocking UserFavoriteModel objects and their 'to_dict' method
        mock_favorite_1 = mock.MagicMock(spec=UserFavoriteModel)
        mock_favorite_1.user_id = 'user123'
        mock_favorite_1.subject_type = FavoriteSubject.ASSISTANT
        mock_favorite_1.subject_id = 'assistant_1'
        mock_favorite_1.to_dict.return_value = {
            'userId': 'user123',
            'subjectType': 'ASSISTANT',
            'subjectId': 'assistant_1',
            'createdAt': '2024-03-20T10:00:00Z'
        } 

        return mock_favorite_1  

@pytest.fixture
def mock_preferences(app):
    """Fixture to create multiple mock preferences for testing."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_preference_1 = mock.MagicMock(spec=PreferenceModel)
        mock_preference_1.to_dict.return_value = {
            "id": "1",
            "name": "Preference 1",
            "label": "Test Preference 1",
            "description": "Test Description 1",
            "scope": PreferenceScope.USER.value,
            "type": DataType.TEXT.value
        }

        mock_preference_2 = mock.MagicMock(spec=PreferenceModel)
        mock_preference_2.to_dict.return_value = {
            "id": "2",
            "name": "Preference 2",
            "label": "Test Preference 2",
            "description": "Test Description 2",
            "scope": PreferenceScope.APPLICATION.value,
            "type": DataType.INTEGER.value
        }
        # Create a mock for the new preference that will be returned
        mock_new_preference = mock.MagicMock(spec=PreferenceModel)
        mock_new_preference.to_dict.return_value = {
            '__type_name': EntityType.PREFERENCE,
            "id": "new-uuid",
            "name": "New Preference",
            "label": "Test New Preference",
            "description": "Test Description",
            "type": DataType.TEXT,
            "scope": PreferenceScope.USER
        }
        # Create updated mock preference
        updated_preference = mock.MagicMock(spec=PreferenceModel)
        updated_preference.to_dict.return_value = {
            '__type_name': EntityType.PREFERENCE,
            "id": "1",
            "name": "Updated Preference",
            "label": "Updated Test Preference",
            "description": "Updated Description",
            "type": DataType.TEXT,
            "scope": PreferenceScope.USER
        }

        return {
            'base_preference': mock_preference_1,
            'second_preference': mock_preference_2,
            'new_preference': mock_new_preference,
            'updated_preference': updated_preference,
            'all_preferences': [mock_preference_1, mock_preference_2]  # For get_all endpoint
        }



@pytest.fixture
def mock_workspaces(app):
    app.json = CustomJSONProvider(app)
   
    with app.app_context(): 
        mock_workspace_1 = mock.MagicMock(spec=WorkspaceModel)
        mock_workspace_1.to_dict.return_value = {     
            '__type_name': EntityType.WORKSPACE,     
            "id": "1",
            "name": "Workspace 1",
            "description": "Test description",
            "tags": [],
            "icon": "icon1",
            "image": "image1",
            "filteredOnTags": False
        } 
        mock_workspace_1.permission = PermissionType.READ
        mock_workspace_1.name = "Workspace 1"
        mock_workspace_1.description = "Test description"

        mock_workspace_2 = mock.MagicMock(spec=WorkspaceModel)
        mock_workspace_2.to_dict.return_value = {    
            '__type_name': EntityType.WORKSPACE,    
            "id": "2",
            "name": "Workspace 2",
            "description": "Other description",
            "tags": [],
            "icon": "icon2",
            "image": "image2",
            "filteredOnTags": True
        }
        mock_workspace_2.permission = PermissionType.READ
        mock_workspace_2.name = "Workspace 2"
        mock_workspace_2.description = "Other description"

        mock_new_workspace = mock.MagicMock(spec=WorkspaceModel)
        mock_new_workspace.to_dict.return_value = {
            '__type_name': EntityType.WORKSPACE,    
            "id": "new-uuid",
            "name": "New Workspace",
            "description": " Workspace description",
            "tags": [],
            "icon": "newicon",
            "image": "newimage",
            "filteredOnTags": True
        }

        update_workspace = mock.MagicMock(spec=WorkspaceModel)
        update_workspace.to_dict.return_value = {
            '__type_name': EntityType.WORKSPACE,    
            "id": "1",
            "name": "Updated workspace",
            "description": "Updated Test Description",
            "tags": [],
            "icon": "updated icon",
            "image": "Updated image",
            "filteredOnTags": True
        }
        
        return {
            'base_workspace': mock_workspace_1,
            'second_workspace': mock_workspace_2,
            'new_workspace': mock_new_workspace,
            'update_workspace': update_workspace,
            'all_workspaces': [mock_workspace_1, mock_workspace_2]  
        }
    

@pytest.fixture
def mock_user_setting(app, mock_user):
    """Fixture to create a mock user setting with dummy IDs."""
    # Use a dummy preference ID and value
    with app.app_context():
        user_setting1 = mock.MagicMock(spec=UserSettingModel) 
        user_setting1.to_dict.return_value = {
            "userId": "1",
            "preferenceId": "setting_1",
            "value": "value"
        }
        user_setting2 = mock.MagicMock(spec=UserSettingModel) 
        user_setting2.to_dict.return_value = {
            "userId": "1",
            "preferenceId": "setting_1",
            "value": "new_value"
        }
       
        return [user_setting1,user_setting2]
    
@pytest.fixture
def mock_assistants(app):
    """Fixture to create mock assistants for testing."""
    app.json = CustomJSONProvider(app)
    with app.app_context(): 
        mock_assistant_1 = mock.MagicMock(spec=AssistantModel)
        mock_assistant_1.id = "1"
        mock_assistant_1.to_dict.return_value = {
            "id": "1",
            "name": "Assistant 1",
            "description": "Test Assistant 1",
            "type": DataType.TEXT.value,
            "__type_name": EntityType.ASSISTANT.value,
            "permission": PermissionType.READ.value
        }
        mock_assistant_1.permission = PermissionType.READ
        mock_assistant_1.name = "Assistant 1"
        mock_assistant_1.description = "Test Assistant 1"

        # Create second mock assistant
        mock_assistant_2 = mock.MagicMock(spec=AssistantModel)
        mock_assistant_2.id = "2"
        mock_assistant_2.to_dict.return_value = {
            "id": "2",
            "name": "Assistant 2",
            "description": "Test Assistant 2",
            "type": DataType.TEXT.value,
            "__type_name": EntityType.ASSISTANT.value,
            "permission": PermissionType.READ.value
        }
        mock_assistant_2.permission = PermissionType.READ
        mock_assistant_2.name = "Assistant 2"
        mock_assistant_2.description = "Test Assistant 2"

        # Create new assistant for POST tests
        mock_new_assistant = mock.MagicMock(spec=AssistantModel)
        mock_new_assistant.id = "new-assistant-id"
        mock_new_assistant.name = "New Assistant"
        mock_new_assistant.description = "Test assistant description"
        mock_new_assistant.llms = []
        mock_new_assistant.data_sources = []
        mock_new_assistant.system_instructions = []
        mock_new_assistant.tag_relations = []
        mock_new_assistant.to_dict.return_value = {
            "id": "new-assistant-id",
            "name": "New Assistant",
            "description": "Test assistant description",
            "llmIds": ["1"],
            "customSystemInstruction": "Custom instruction",
            "greetingMessage": "Hello!",
            "sampleQuestions": ["Question 1", "Question 2"],
            "tags": [{"id": "tag1"}],
            "systemInstructionIds": ["sys1"],
            "dataSourceIds": ["ds1"],
            "image": "base64_image",
            "icon": "base64_icon"
        }

        # Create updated assistant for PUT tests
        mock_updated_assistant = mock.MagicMock(spec=AssistantModel)
        mock_updated_assistant.id = "assistant-1"
        mock_updated_assistant.name = "Updated Assistant"
        mock_updated_assistant.description = "Updated description"
        mock_updated_assistant.llms = []
        mock_updated_assistant.data_sources = []
        mock_updated_assistant.system_instructions = []
        mock_updated_assistant.tag_relations = []
        mock_updated_assistant.to_dict.return_value = {
            "id": "assistant-1",
            "name": "Updated Assistant",
            "description": "Updated description"
        }

        return {
            'base_assistant': mock_assistant_1,
            'second_assistant': mock_assistant_2,
            'new_assistant': mock_new_assistant,
            'updated_assistant': mock_updated_assistant, 
            'all_assistants': [mock_assistant_1, mock_assistant_2]
        }

@pytest.fixture
def mock_system_instructions(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        """Fixture to create mock system_instructions for testing."""
        # Mocking SystemInstructionModel objects and their 'to_dict' method

        # Mock system instruction 1
        mock_system_instruction_1 = mock.MagicMock(spec=SystemInstructionModel)
        mock_system_instruction_1.to_dict.return_value = {
            '__type_name': EntityType.SYSTEM_INSTRUCTION,
            "id": "1",
            "name": "Instruction 1",
            "description": "This is the first system instruction",
            "message": "Message for instruction 1",
            "tags": [],
            "permission": PermissionType.READ.value
        }
        mock_system_instruction_1.permission = PermissionType.READ

        # Mock system instruction 2 
        mock_system_instruction_2 = mock.MagicMock(spec=SystemInstructionModel)
        mock_system_instruction_2.to_dict.return_value = {
            '__type_name': EntityType.SYSTEM_INSTRUCTION,
            "id": "2",
            "name": "Instruction 2",
            "description": "This is the second system instruction",
            "message": "Message for instruction 2",
            "tags": [],
            "permission": PermissionType.READ.value
            
        }
        mock_system_instruction_2.permission = PermissionType.READ
        mock_new_system_instruction = mock.MagicMock(spec=SystemInstructionModel)
        mock_new_system_instruction.to_dict.return_value = {
            '__type_name': EntityType.SYSTEM_INSTRUCTION,    
            "id": "new-uuid",
            "name": "New System_instruction",
            "description": "SystemInstruction description",
            "message": "Message for new instruction ",
            "tags": [],
            
        }

        return {
            'all_system_instructions':[mock_system_instruction_1, mock_system_instruction_2],
            'new_system_instruction': mock_new_system_instruction

        }
    

    
@pytest.fixture
def mock_agent_workflows(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        """Fixture to create mock AgentWorkflowModel for testing."""
        
        # Mock AgentWorkflowModel 1
        mock_agent_workflow_1 = mock.MagicMock(spec=AgentWorkflowModel)
        mock_agent_workflow_1.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            "id": "1",
            "name": "Agent workflow 1",
            "message": "Message for agent workflow 1",
            "tags": [],
            "agents": None,
            "rootAgent": None,
            "icon": "updated icon 1",
            "image": "Updated image 1",
            "permission": PermissionType.READ.value
        }
        mock_agent_workflow_1.permission = PermissionType.READ
        mock_agent_workflow_1.deleted_at = None
        mock_agent_workflow_1.name = "Agent Workflow 1"
        mock_agent_workflow_1.description = "Description 1"

        # Mock AgentWorkflowModel 2 
        mock_agent_workflow_2 = mock.MagicMock(spec=AgentWorkflowModel)
        mock_agent_workflow_2.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            "id": "2",
            "name": "Agent workflow 2",
            "description": "This is the second Agent workflow",
            "tags": [],
            "agents": None,
            "rootAgent":None ,
            "icon": "updated icon 2",
            "image": "Updated image 2",
            "permission": PermissionType.READ.value
        }
        mock_agent_workflow_2.permission = PermissionType.READ
        mock_agent_workflow_2.deleted_at = None
        mock_agent_workflow_2.name = "Agent Workflow 2"
        mock_agent_workflow_2.description = "This is the second Agent workflow"
        
        return [mock_agent_workflow_1, mock_agent_workflow_2]


@pytest.fixture
def mock_agents(app):
    app.json = CustomJSONProvider(app)
    
    with app.app_context():
        mock_base_agent = mock.MagicMock(spec=AgentModel)
        mock_base_agent.to_dict.return_value = {
            '__type_name': EntityType.AGENT,
            "id": "1",
            "name": "Agent 1",
            "description": "Test Agent 1",
            "status": "active",
            "createdAt": "2025-02-22T10:00:00Z",
            "updatedAt": "2025-02-22T10:00:00Z",
            "tags": ["tag1", "tag2"],
            "image": "image1",
            "icon": "icon1",
            "ownerId": "user1"
        }
        mock_base_agent.name = "Agent 1",
        mock_base_agent.description = "Test Agent 1",
        mock_base_agent.image = "image1",
        mock_base_agent.icon = "icon1",
        mock_base_agent.permission = PermissionType.READ
        mock_base_agent.id = "1"
    
        mock_second_agent = mock.MagicMock(spec=AgentModel)
        mock_second_agent.to_dict.return_value = {
            '__type_name': EntityType.AGENT,
            "id": "2",
            "name": "Agent 2",
            "description": "Test Agent 2",
            "status": "active",
            "createdAt": "2025-02-22T11:00:00Z",
            "updatedAt": "2025-02-22T11:00:00Z",
            "tags": ["tag3", "tag4"],
            "icon": "icon2",
            "ownerId": "user1"
        }
        mock_second_agent.permission = PermissionType.READ
        mock_second_agent.id = "2"
        
        mock_new_agent = mock.MagicMock(spec=AgentModel)
        mock_new_agent.to_dict.return_value = {
            '__type_name': EntityType.AGENT,
            "id": "new-uuid",
            "name": "New Agent",
            "description": "Agent description",
            "status": "active",
            "createdAt": "2025-02-23T10:00:00Z",
            "updatedAt": "2025-02-23T10:00:00Z",
            "tags": [],
            "icon": "newicon",
            "ownerId": "user1"
        }
        
        mock_update_agent = mock.MagicMock(spec=AgentModel)
        mock_update_agent.to_dict.return_value = {
            '__type_name': EntityType.AGENT,
            "id": "1",
            "name": "Updated Agent",
            "description": "Updated Test Description",
            "status": "inactive",
            "createdAt": "2025-02-22T10:00:00Z",
            "updatedAt": "2025-02-24T10:00:00Z",
            "tags": ["updated_tag"],
            "icon": "updated icon",
            "ownerId": "user1"
        }
        
        return {
            'base_agent': mock_base_agent,
            'second_agent': mock_second_agent,
            'new_agent': mock_new_agent,
            'update_agent': mock_update_agent,
            'all_agents': [mock_base_agent, mock_second_agent]
        } 

@pytest.fixture
def mock_tags(app):
    with app.app_context():
        # Base tag mock
        mock_tag_1 = mock.MagicMock(spec=TagModel)
        mock_tag_1.to_dict.return_value = {
            "id": "tag_1",
            "name": "Tag 1",
            "description": "Test Tag 1"
        }
        mock_tag_1.permission = PermissionType.READ

        # Second tag mock
        mock_tag_2 = mock.MagicMock(spec=TagModel)
        mock_tag_2.to_dict.return_value = {
            "id": "tag_2",
            "name": "Tag 2",
            "description": "Test Tag 2"
        }
        mock_tag_2.permission = PermissionType.READ

        # New tag mock
        mock_new_tag = mock.MagicMock(spec=TagModel)
        mock_new_tag.to_dict.return_value = {
            '__type_name': EntityType.TAG,
            "id": "new-tag-id",
            "name": "New Tag",
            "description": "New Tag Description"
        }
        mock_new_tag.permission = PermissionType.WRITE

        # Updated tag mock 
        updated_tag = mock.MagicMock(spec=TagModel)
        updated_tag.to_dict.return_value = {
            '__type_name': EntityType.TAG,
            "id": "tag_1",
            "name": "Updated Tag 1",
            "description": "Updated Description for Tag 1"
        }
        updated_tag.permission = PermissionType.WRITE

        return {
            'base_tag': mock_tag_1,
            'second_tag': mock_tag_2,
            'new_tag': mock_new_tag,
            'updated_tag': updated_tag,
            'all_tags': [mock_tag_1, mock_tag_2]  # For get_all endpoint
        }


@pytest.fixture
def mock_permission_grants(app):
    app.json = CustomJSONProvider(app)

    with app.app_context():
        # Mock Permission 1
        mock_permission_1 = mock.MagicMock(spec=AccessPermissionModel)
        mock_permission_1.to_dict.return_value = { 
            "id": "1",
            "subjectType": "WORKSPACE",
            "subjectId": "workspace_1",
            "assigneeType": "USER",
            "assigneeId": "user_1",
            "accessLevel": "READ"
        }

        # Mock Permission 2
        mock_permission_2 = mock.MagicMock(spec=AccessPermissionModel)
        mock_permission_2.to_dict.return_value = {
            "id": "2",
            "subjectType": "WORKSPACE",
            "subjectId": "workspace_2",
            "assigneeType": "USER",
            "assigneeId": "user_2",
            "accessLevel": "WRITE"
        }

        # Mock Permission 3
        new_mock_permission_3 = mock.MagicMock(spec=AccessPermissionModel)
        new_mock_permission_3.to_dict.return_value = {
            "id": "3",
            "subjectType": "WORKSPACE",
            "subjectId": "workspace_3",
            "assigneeType": EntityType.USER.value, 
            "assigneeId": "user_3",
            "accessLevel": "WRITE"
        } 
        all_permissions = [mock_permission_1, mock_permission_2, new_mock_permission_3]
        sorted_permissions = sorted(all_permissions, key=lambda perm: perm.to_dict()['id'])

        return {
            'base_permission': mock_permission_1,
            'second_permission': mock_permission_2,
            'new_permission': new_mock_permission_3, 
            'all_permission': sorted_permissions
        }

@pytest.fixture   
def mock_tag_categories(app):
    """Fixture to create mock tag categories for testing."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_tag_category_1 = mock.MagicMock(spec=TagCategoryModel)
        mock_tag_category_1.id = "tc1"
        mock_tag_category_1.name = "Category One"
        mock_tag_category_1.description = "Mock tag category one"
        mock_tag_category_1.to_dict.return_value = {
            "id": "tc1",
            "name": "Category One",
            "description": "Mock tag category one"
        }
        mock_tag_category_1.permission = PermissionType.READ
        mock_tag_category_2 = mock.MagicMock(spec=TagCategoryModel)
        mock_tag_category_2.id = "tc2"
        mock_tag_category_2.to_dict.return_value = {
            "id": "tc2",
            "name": "Category Two",
            "description": "Mock category two"
        }
        mock_tag_category_2.permission = PermissionType.READ
        mock_new_tag_category = mock.MagicMock(spec=TagCategoryModel)
        mock_new_tag_category.to_dict.return_value = {
            '__type_name': EntityType.TAG_CATEGORY,    
            "id": "new-tc",
            "name": "New Category",
            "description": "new Category description"
            
        }
         # Create updated mock preference
        mock_updated_tag_category = mock.MagicMock(spec=TagCategoryModel)
        mock_updated_tag_category.to_dict.return_value = {
            '__type_name': EntityType.TAG_CATEGORY,
            "id": "tc_update",
            "name": "Updated tag_category",
            "description": "Updated Category Description"
        }


        return{
            'all_tag_category':[mock_tag_category_1, mock_tag_category_2],
            'new_tag_category': mock_new_tag_category,
            'update_tag_category': mock_updated_tag_category,
            'tag_category_1':mock_tag_category_1,
            'tag_category_2':mock_tag_category_2

        } 


@pytest.fixture
def mock_shared_conversations(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_shared_conv_1 = mock.MagicMock(spec=SharedConversationModel)
        mock_shared_conv_1.to_dict.return_value = {
            '__type_name': EntityType.SHARED_CONVERSATION.value,
            'id': 'shared_conv_1',
            'conversationId': 'conv_1',
            'creator_id': 'user_123',
            'created_at': '2025-04-01T10:00:00Z',
            'modifier_id': 'user_123',
            'modified_at': '2025-04-01T10:00:00Z'
        }

        mock_shared_conv_2 = mock.MagicMock(spec=SharedConversationModel)
        mock_shared_conv_2.to_dict.return_value = {
            '__type_name': EntityType.SHARED_CONVERSATION.value,
            'id': 'shared_conv_2',
            'conversationId': 'conv_2',
            'creator_id': 'user_123',
            'created_at': '2025-04-02T10:00:00Z',
            'modifier_id': 'user_123',
            'modified_at': '2025-04-02T10:00:00Z'
        }

        return {
            'base_shared_conversation': mock_shared_conv_1,
            'second_shared_conversation': mock_shared_conv_2,
            'all_shared_conversations': [mock_shared_conv_1, mock_shared_conv_2],
        }


@pytest.fixture
def mock_tag_entities():
    # Returns a dict of entity type to list of mock entities with .to_dict()
    return {
        "assistant": [mock.MagicMock(to_dict=lambda: {"id": "a1"})],
        "agent": [mock.MagicMock(to_dict=lambda: {"id": "ag1"})],
        "workflow": [mock.MagicMock(to_dict=lambda: {"id": "w1"})],
        "conversation": [mock.MagicMock(to_dict=lambda: {"id": "c1"})],
        "data_source": [mock.MagicMock(to_dict=lambda: {"id": "d1"})],
        "system_instruction": [mock.MagicMock(to_dict=lambda: {"id": "s1"})],
        "module": [mock.MagicMock(to_dict=lambda: {"id": "m1"})],
        "workspace": [mock.MagicMock(to_dict=lambda: {"id": "ws1"})],
        "widget": [mock.MagicMock(to_dict=lambda: {"id": "wd1"})],
    }

@pytest.fixture
def mock_modules(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        from maxgpt.services.database_model import ModuleModel
        from maxgpt.modules import ModuleType
        from maxgpt.services.database_model import DocumentType
        from maxgpt.api import EntityType
        
        # Use plain mock.Mock() instead of spec=ModuleModel to allow get_id/get_spec
        mock_module_1 = mock.Mock()
        mock_module_1.to_dict.return_value = {
            '__type_name': EntityType.MODULE,
            'id': '1',
            'name': 'Module 1',
            'description': 'Test Module 1',
            'specId': 'spec-1',
            'tags': [],
            'supportedInputs': [DocumentType.TEXT.value],
            'parameters': [{'name': 'param1', 'value': 'value1'}],
            'capabilities': [{'name': 'cap1', 'label': 'Capability 1', 'value': 'val1'}],
        }
        mock_module_1.permission = PermissionType.READ
        mock_module_1.get_id.return_value = '1'
        mock_module_1.get_name.return_value = 'Module 1'
        mock_module_1.get_spec.return_value = mock.Mock(get_id=mock.Mock(return_value='spec-1'), get_module_type=mock.Mock(return_value=ModuleType.LLM))

        mock_module_2 = mock.Mock()
        mock_module_2.to_dict.return_value = {
            '__type_name': EntityType.MODULE,
            'id': '2',
            'name': 'Module 2',
            'description': 'Test Module 2',
            'specId': 'spec-2',
            'tags': [],
            'supportedInputs': [DocumentType.IMAGE.value],
            'parameters': [{'name': 'param2', 'value': 'value2'}],
            'capabilities': [{'name': 'cap2', 'label': 'Capability 2', 'value': 'val2'}],
        }
        mock_module_2.permission = PermissionType.READ
        mock_module_2.get_id.return_value = '2'
        mock_module_2.get_name.return_value = 'Module 2'
        mock_module_2.get_spec.return_value = mock.Mock(get_id=mock.Mock(return_value='spec-2'), get_module_type=mock.Mock(return_value=ModuleType.LLM))

        mock_new_module = mock.Mock()
        mock_new_module.to_dict.return_value = {
            '__type_name': EntityType.MODULE,
            'id': 'new-uuid',
            'name': 'New Module',
            'description': 'Module description',
            'specId': 'spec-new',
            'tags': [],
            'supportedInputs': [DocumentType.AUDIO.value],
            'parameters': [{'name': 'param_new', 'value': 'new_value'}],
            'capabilities': [{'name': 'cap_new', 'label': 'Capability New', 'value': 'new_val'}],
        }
        mock_new_module.get_id.return_value = 'new-uuid'
        mock_new_module.get_name.return_value = 'New Module'
        mock_new_module.get_spec.return_value = mock.Mock(get_id=mock.Mock(return_value='spec-new'), get_module_type=mock.Mock(return_value=ModuleType.LLM))

        update_module = mock.Mock()
        update_module.to_dict.return_value = {
            '__type_name': EntityType.MODULE,
            'id': '1',
            'name': 'Updated Module',
            'description': 'Updated Test Description',
            'specId': 'spec-1',
            'tags': [],
            'supportedInputs': [DocumentType.TEXT.value],
            'parameters': [{'name': 'param1', 'value': 'updated_value1'}],
            'capabilities': [{'name': 'cap1', 'label': 'Capability 1', 'value': 'updated_val1'}],
        }
        update_module.get_id.return_value = '1'
        update_module.get_name.return_value = 'Updated Module'
        update_module.get_spec.return_value = mock.Mock(get_id=mock.Mock(return_value='spec-1'), get_module_type=mock.Mock(return_value=ModuleType.LLM))

        return {
            'base_module': mock_module_1,
            'second_module': mock_module_2,
            'new_module': mock_new_module,
            'update_module': update_module,
            'all_modules': [mock_module_1, mock_module_2]
        }

@pytest.fixture
def mock_agentworkflows(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_base = mock.MagicMock(spec=AgentWorkflowModel)
        mock_base.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            'id': '1',
            'name': 'Agent Workflow 1',
            'description': 'Description 1',
            'tags': [],
            'agents': [],
            'rootAgent': None,
            'icon': 'icon1',
            'image': 'image1',
            'permission': PermissionType.READ.value
        }
        mock_base.permission = PermissionType.READ

        mock_update = mock.MagicMock(spec=AgentWorkflowModel)
        mock_update.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            'id': '1',
            'name': 'Updated agent workflow',
            'description': 'Updated Test description',
            'tags': [],
            'agents': [
                {'id': 'agent1', 'type': 'Agent', 'canHandOffTo': []}
            ],
            'rootAgent': {'id': 'agent1', 'type': 'Agent'},
            'icon': 'icon1',
            'image': 'Updated image',
            'permission': PermissionType.WRITE.value
        }
        mock_update.permission = PermissionType.WRITE
        mock_update.deleted_at = None
        mock_update.tag_relations = []
        mock_update.agent_relations = []
        mock_update.assistant_relations = []
        mock_update.data_source_relations = []
        mock_update.handoff_relations = []

        mock_new = mock.MagicMock(spec=AgentWorkflowModel)
        mock_new.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            'id': 'new-uuid',
            'name': 'New Agent Workflow',
            'description': 'Agent Workflow description',
            'tags': [],
            'agents': [
                {'id': 'agent1', 'type': 'Agent', 'canHandOffTo': []}
            ],
            'rootAgent': {'id': 'agent1', 'type': 'Agent'},
            'icon': 'newicon',
            'image': 'newimage',
            'permission': PermissionType.WRITE.value
        }
        mock_new.permission = PermissionType.WRITE

        mock_second = mock.MagicMock(spec=AgentWorkflowModel)
        mock_second.to_dict.return_value = {
            '__type_name': EntityType.AGENT_WORKFLOW,
            'id': '2',
            'name': 'Agent Workflow 2',
            'description': 'Description 2',
            'tags': [],
            'agents': [],
            'rootAgent': None,
            'icon': 'icon2',
            'image': 'image2',
            'permission': PermissionType.READ.value
        }
        mock_second.permission = PermissionType.READ

        return {
            'base_agent_workflow': mock_base,
            'update_agent_workflow': mock_update,
            'new_agent_workflow': mock_new,
            'second_agent_workflow': mock_second,
            'all_agent_workflows': [mock_base, mock_second]
        }

@pytest.fixture
def mock_module_specs(app):
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_module_spec_1 = mock.MagicMock()
        mock_module_spec_1.to_dict.return_value = {
            'id': 'spec-1',
            'name': 'Module Spec 1',
            'description': 'Test Module Spec 1',
            'type': 'LLM',
            'parameters': [
                {
                    'name': 'param1',
                    'type': 'string',
                    'default': 'default1',
                    'description': 'Parameter 1',
                    'optional': False
                }
            ]
        }
        mock_module_spec_2 = mock.MagicMock()
        mock_module_spec_2.to_dict.return_value = {
            'id': 'spec-2',
            'name': 'Module Spec 2',
            'description': 'Test Module Spec 2',
            'type': 'VECTOR_STORE',
            'parameters': [
                {
                    'name': 'param2',
                    'type': 'int',
                    'default': 0,
                    'description': 'Parameter 2',
                    'optional': True
                }
            ]
        }
        return {
            'base_module_spec': mock_module_spec_1,
            'second_module_spec': mock_module_spec_2,
            'all_module_specs': [mock_module_spec_1, mock_module_spec_2]
        }

@pytest.fixture
def mock_application_settings(app):
    """Fixture to create mock application settings for testing."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        from maxgpt.services.database_model import ApplicationSettingModel, PreferenceModel, PreferenceScope
        mock_preference = mock.MagicMock(spec=PreferenceModel)
        mock_preference.id = "pref-app-1"
        mock_preference.scope = PreferenceScope.APPLICATION
        mock_preference.to_dict.return_value = {
            "id": "pref-app-1",
            "name": "App Preference",
            "label": "App Pref Label",
            "description": "App Pref Desc",
            "scope": PreferenceScope.APPLICATION.value,
            "type": DataType.TEXT.value
        }
        mock_setting_1 = mock.MagicMock(spec=ApplicationSettingModel)
        mock_setting_1.id = "setting-1"
        mock_setting_1.preference_id = "pref-app-1"
        mock_setting_1.value = "test-value"
        mock_setting_1.to_dict.return_value = {
            "id": "setting-1",
            "preferenceId": "pref-app-1",
            "value": "test-value"
        }
        mock_setting_updated = mock.MagicMock(spec=ApplicationSettingModel)
        mock_setting_updated.id = "setting-1"
        mock_setting_updated.preference_id = "pref-app-1"
        mock_setting_updated.value = "updated-value"
        mock_setting_updated.to_dict.return_value = {
            "id": "setting-1",
            "preferenceId": "pref-app-1",
            "value": "updated-value"
        }
        mock_setting_2 = mock.MagicMock(spec=ApplicationSettingModel)
        mock_setting_2.id = "setting-2"
        mock_setting_2.preference_id = "pref-app-2"
        mock_setting_2.value = "another-value"
        mock_setting_2.to_dict.return_value = {
            "id": "setting-2",
            "preferenceId": "pref-app-2",
            "value": "another-value"
        }
        return {
            'base_setting': mock_setting_1,
            'updated_setting': mock_setting_updated,
            'second_setting': mock_setting_2,
            'all_settings': [mock_setting_1, mock_setting_2],
            'mock_preference': mock_preference
        }

@pytest.fixture
def mock_data_sources_for_assistant(app):
    """Fixture to create mock data sources specifically for assistant tests."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_data_source_1 = mock.MagicMock(spec=DataSourceModel)
        mock_data_source_1.id = "ds1"
        mock_data_source_1.name = "Test Data Source 1"
        mock_data_source_1.description = "Test Data Source 1 Description"
        mock_data_source_1.to_dict.return_value = {
            "id": "ds1",
            "name": "Test Data Source 1",
            "description": "Test Data Source 1 Description",
            "filterTag": None,
            "embeddingModelId": "embedding_model_1",
            "vectorStoreId": "vector_store_1",
            "fileStorageId": None,
            "tags": []
        }

        mock_data_source_2 = mock.MagicMock(spec=DataSourceModel)
        mock_data_source_2.id = "ds2"
        mock_data_source_2.name = "Test Data Source 2"
        mock_data_source_2.description = "Test Data Source 2 Description"
        mock_data_source_2.to_dict.return_value = {
            "id": "ds2",
            "name": "Test Data Source 2",
            "description": "Test Data Source 2 Description",
            "filterTag": None,
            "embeddingModelId": "embedding_model_2",
            "vectorStoreId": "vector_store_2",
            "fileStorageId": None,
            "tags": []
        }

        return {
            'data_source_1': mock_data_source_1,
            'data_source_2': mock_data_source_2,
            'all_data_sources': [mock_data_source_1, mock_data_source_2]
        }


@pytest.fixture
def mock_system_instructions_for_assistant(app):
    """Fixture to create mock system instructions specifically for assistant tests."""
    app.json = CustomJSONProvider(app)
    with app.app_context():
        mock_system_instruction_1 = mock.MagicMock(spec=SystemInstructionModel)
        mock_system_instruction_1.id = "sys1"
        mock_system_instruction_1.name = "System Instruction 1"
        mock_system_instruction_1.description = "Test System Instruction 1"
        mock_system_instruction_1.message = "Message for instruction 1"
        mock_system_instruction_1.to_dict.return_value = {
            "id": "sys1",
            "name": "System Instruction 1",
            "description": "Test System Instruction 1",
            "message": "Message for instruction 1",
            "tags": []
        }

        mock_system_instruction_2 = mock.MagicMock(spec=SystemInstructionModel)
        mock_system_instruction_2.id = "sys2"
        mock_system_instruction_2.name = "System Instruction 2"
        mock_system_instruction_2.description = "Test System Instruction 2"
        mock_system_instruction_2.message = "Message for instruction 2"
        mock_system_instruction_2.to_dict.return_value = {
            "id": "sys2",
            "name": "System Instruction 2",
            "description": "Test System Instruction 2",
            "message": "Message for instruction 2",
            "tags": []
        }

        return {
            'system_instruction_1': mock_system_instruction_1,
            'system_instruction_2': mock_system_instruction_2,
            'all_system_instructions': [mock_system_instruction_1, mock_system_instruction_2]
        }

@pytest.fixture
def mock_shallow_user():
    """Fixture to create a mock ShallowUser for testing."""
    mock_user = mock.MagicMock()
    mock_user.get_id.return_value = "user123"
    mock_user.get_display_name.return_value = "Test User"
    mock_user.to_dict.return_value = {
        'id': 'user123', 
        'name': 'Test User'
    }
    return mock_user

@pytest.fixture
def apprd_mock(app, mock_security_function_permission):
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch('maxgpt.services.database.session') as mock_db_session:
                mock_scalars = mock.MagicMock()
                mock_scalars.return_value = set()
                mock_db_session.scalars.return_value = mock_scalars
                mock_db_session.add = mock.MagicMock()
                mock_db_session.commit = mock.MagicMock()
                mock_db_session.delete = mock.MagicMock()
                yield
