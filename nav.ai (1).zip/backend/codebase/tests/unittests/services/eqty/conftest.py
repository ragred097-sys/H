import pytest
from unittest import mock
from unittest.mock import MagicMock

import sys
import json

from maxgpt.services.eqty import util, indicator

@pytest.fixture
def mock_appdb(app):
    with app.app_context():
        with mock.patch('maxgpt.services.database.session') as mock_db_session:
            mock_scalars = MagicMock()
            mock_scalars.return_value = set()
            mock_db_session.scalars.return_value = mock_scalars
            mock_db_session.add = MagicMock()
            mock_db_session.commit = MagicMock()
            yield

@pytest.fixture
def eqty_mock(monkeypatch):
    """Mock eqty module and its methods"""
    config_mock = mock.MagicMock()
    config_mock.create_random_did.return_value = 'random_did'

    eqty_mock = mock.MagicMock()
    eqty_mock.init.return_value = config_mock
    eqty_mock.login.return_value = 'logged_in'
    eqty_mock.Config = mock.Mock()

    monkeypatch.setitem(sys.modules, 'eqty', eqty_mock)
    monkeypatch.setattr(util, 'eqty', eqty_mock)
    monkeypatch.setenv('EQTY_PROJECT', 'proj')
    monkeypatch.setenv('EQTY_GOV_URL', 'http://gov')
    monkeypatch.setenv('EQTY_API_KEY', 'key')
    monkeypatch.setattr(util, 'EQTY_PROJECT', 'proj')
    monkeypatch.setattr(util, 'EQTY_GOV_URL', 'http://gov')
    monkeypatch.setattr(util, 'EQTY_ORG_ID', 'orgid')

    yield eqty_mock

@pytest.fixture
def manifest_mock(monkeypatch, tmp_path):
    eqty_mock = mock.MagicMock()
    monkeypatch.setattr(util, 'eqty', eqty_mock)

    # Patch tempfile.TemporaryDirectory to use tmp_path
    temp_dir_mock = mock.MagicMock()
    temp_dir_mock.__enter__.return_value = str(tmp_path)
    temp_dir_mock.__exit__.return_value = False
    monkeypatch.setattr(util.tempfile, 'TemporaryDirectory', mock.Mock(return_value=temp_dir_mock))

    # Patch open to write/read manifest
    manifest_data = {'foo': 'bar'}
    manifest_path = tmp_path / 'manifest.json'
    with open(manifest_path, 'w') as f:
        json.dump(manifest_data, f)
    open_mock = mock.mock_open(read_data=json.dumps(manifest_data))
    monkeypatch.setattr('builtins.open', open_mock)
    monkeypatch.setattr(util.json, 'loads', lambda s: manifest_data)

    yield eqty_mock

@pytest.fixture
def post_mock(monkeypatch):
    uuid = '1234'
    name = 'test_indicator'
    observations = [{'foo': 1}, {'foo': 2}]
    # Mock requests.post
    post_mock = mock.Mock()
    # First two calls: individual observations
    monkeypatch.setattr(indicator.requests, 'post', post_mock)
    # Patch logging
    monkeypatch.setattr(indicator.logging, 'debug', lambda *a, **k: None)
    monkeypatch.setattr(indicator.logging, 'error', lambda *a, **k: None)
    # Patch EQTY_GOV_URL and GOV_API
    monkeypatch.setattr(indicator, 'EQTY_GOV_URL', 'http://gov')
    monkeypatch.setattr(indicator, 'GOV_API', 'api')

    yield post_mock