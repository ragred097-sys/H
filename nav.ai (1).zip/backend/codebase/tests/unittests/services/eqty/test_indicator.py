import pytest
from unittest import mock

from maxgpt.services.eqty import indicator
from maxgpt.services.eqty.util import is_eqty_enabled

if is_eqty_enabled():

    class TestEvaluateIndicator:
        EVALUATION_ARGS = [ '1234', 'test_indicator', [{'foo': 1}, {'foo': 2}]]

        def test_evaluate_indicator_success(self, monkeypatch, post_mock):
            """Test the happy path of evaluating an indicator with two observations"""
            post_mock.side_effect = [
                mock.Mock(status_code=200, json=mock.Mock(return_value={'complianceStatus': 'compliant'}), raise_for_status=mock.Mock()),
                mock.Mock(status_code=200, json=mock.Mock(return_value={'complianceStatus': 'not_compliant'}), raise_for_status=mock.Mock()),
                # Third call: batch
                mock.Mock(status_code=200, json=mock.Mock(return_value={'result': 'ok'}), raise_for_status=mock.Mock())
            ]
            compliant, evaluation = indicator.evaluate_indicator(*self.EVALUATION_ARGS)
            assert compliant == [True, False]
            assert evaluation == {'result': 'ok'}
            assert post_mock.call_count == 3

        def test_evaluate_indicator_json_decode_error(self, monkeypatch, post_mock):
            """Test the error path of evaluating an indicator with two observations"""
            post_mock.side_effect = [
                mock.Mock(status_code=200, json=mock.Mock(return_value={'complianceStatus': 'compliant'}), raise_for_status=mock.Mock()),
                # Second call: batch raises JSONDecodeError
                mock.Mock(status_code=200, json=mock.Mock(side_effect=indicator.JSONDecodeError('msg', 'doc', 0)), raise_for_status=mock.Mock(), text='bad json')
            ]
            error_msgs = []
            monkeypatch.setattr(indicator.logging, 'error', lambda msg: error_msgs.append(msg))
            with pytest.raises(indicator.JSONDecodeError):
                indicator.evaluate_indicator(*self.EVALUATION_ARGS)
            assert any('invalid JSON' in msg for msg in error_msgs)
