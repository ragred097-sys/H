import pytest
from unittest import mock

from datetime import datetime
from typing import Optional

from maxgpt.services.database_model import (
    AgentModel,
    AgentSystemInstructionRelationModel,
    AssistantModel,
    AssistantSystemInstructionRelationModel,
    AssistantModuleRelationModel,
    AgentWorkflowAgentRelationModel,
    AgentWorkflowModel,
    ModuleModel,
    SystemInstructionModel,
    AgentWorkflowRootAgentType,
)

from maxgpt.services.eqty.util import is_eqty_enabled

if is_eqty_enabled():

    from eqty.sdk.asset import AssetType
    from maxgpt.services.eqty import lineage
    from maxgpt.services.eqty.util import generate_manifest_and_purge

    def _find_node(manifest: dict, node_name: str) -> Optional[dict]:
        return next(filter(
                lambda node: node["enrichments"]["metadata"]["metadata"]["name"] == node_name,
                manifest["derived"]["lineage"]["nodes"]
            ), None)

    def _assert_node(manifest: dict, node_name: str, asset_type: Optional[AssetType] = None):
        node = _find_node(manifest, node_name)
        assert node, f"Node {node_name} not found in manifest"
        node_metadata = node["enrichments"]["metadata"]["metadata"]
        if asset_type:
            assert node_metadata["type"] == "Data", f"{node_name} is not a data node"
            assert node_metadata["assetType"] == asset_type.value, \
                f"{node_name} has incorrect asset type ({node_metadata['assetType']} instead of {asset_type.value})"
        else:
            assert node_metadata["type"] == "Computation", f"{node_name} is not a computation node"
    
    def _assert_edge(manifest: dict, source_node_name: str, target_node_name: str):
        source_node = _find_node(manifest, source_node_name)
        target_node = _find_node(manifest, target_node_name)
        
        def is_edge(edge: dict) -> bool:
            return (
                edge["edge"]["source_id"] == source_node["node"]["id"] and
                edge["edge"]["target_id"] == target_node["node"]["id"]
            )
        
        assert source_node, f"Source node {source_node_name} not found in manifest"
        assert target_node, f"Target node {target_node_name} not found in manifest"
        assert next(filter(is_edge, manifest["derived"]["lineage"]["edges"]), None) is not None, \
            f"Edge from {source_node_name} to {target_node_name} not found in manifest"


    @pytest.mark.usefixtures("mock_appdb")
    class TestAgentLineage:
        @mock.patch('maxgpt.services.database_model.AgentModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.SystemInstructionModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.ModuleModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.data_model.user.UserModel')
        @mock.patch('maxgpt.services.database_model.SystemInstructionModel.query')
        def test_build_agent_lineage_minimal(
            self,
            mock_sim_query,
            mock_user,
            mock_module_creator,
            mock_system_instruction_creator,
            mock_agent_creator,
        ):
            mock_user.get_id.return_value = '3'
            mock_user.get_display_name.return_value = 'test_user'
            mock_module_creator.return_value = mock_user
            mock_system_instruction_creator.return_value = mock_user
            mock_agent_creator.return_value = mock_user
            mock_sim_query.filter.return_value.all.return_value = [
                SystemInstructionModel(
                    id='2',
                    name='Test system instruction',
                    description='Test system instruction description',
                    created_at=datetime.now(),
                    creator_id='3',
                )
            ]
            mock_agent = AgentModel(
                name='Test agent',
                description='Test agent description',
                image='test_image',
                icon='test_icon',
                llm=ModuleModel(
                    id='0',
                    name='Test LLM',
                    description='Test LLM description',
                    created_at=datetime.now(),
                    creator_id='3',
                ),
                system_instructions=[
                    AgentSystemInstructionRelationModel(
                        agent_id='1',
                        system_instruction_id='2',
                    )
                ],
                created_at=datetime.now(),
                creator_id='3',
            )
            assert lineage.build_agent_lineage(mock_agent) is not None
            manifest = generate_manifest_and_purge()
            # Uncomment this to grab the manifest and save it to a file
            # with open('manifest.json', 'w') as f:
            #     f.write(json.dumps(manifest))

            _assert_node(manifest, "Configuration", AssetType.DOCUMENT)
            _assert_node(manifest, "Test LLM", AssetType.MODEL)
            _assert_node(manifest, "Test system instruction", AssetType.DOCUMENT)
            _assert_node(manifest, "Test agent", AssetType.MODEL)
            _assert_node(manifest, "agent_registration", AssetType.CODE)
            _assert_node(manifest, "Assemble agent")

            _assert_edge(manifest, "Configuration", "Assemble agent")
            _assert_edge(manifest, "Test LLM", "Assemble agent")
            _assert_edge(manifest, "Test system instruction", "Assemble agent")
            _assert_edge(manifest, "agent_registration", "Assemble agent")
            _assert_edge(manifest, "Assemble agent", "Test agent")


    @pytest.mark.usefixtures("mock_appdb")
    class TestAgentWorkflowLineage:
        @mock.patch('maxgpt.services.database_model.AgentWorkflowModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.AgentModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.ModuleModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.data_model.user.UserModel')
        @mock.patch('maxgpt.services.database_model.AgentModel.query')
        def test_build_agent_workflow_lineage_minimal(
            self,
            mock_agent_query,
            mock_user,
            mock_module_creator,
            mock_agent_creator,
            mock_agent_workflow_creator,
        ):
            mock_agent = AgentModel(
                name='Workflow agent',
                description='Workflow agent description',
                image='workflow_test_image',
                icon='workflow_test_icon',
                llm=ModuleModel(
                    id='0',
                    name='Workflow LLM',
                    description='Workflow LLM description',
                    created_at=datetime.now(),
                    creator_id='3',
                ),
                system_instructions=[
                    AgentSystemInstructionRelationModel(
                        agent_id='1',
                        system_instruction_id='2',
                    )
                ],
                created_at=datetime.now(),
                creator_id='3',
            )
            mock_agent_query.get.return_value = mock_agent
            mock_user.get_id.return_value = '3'
            mock_user.get_display_name.return_value = 'test_user'
            mock_module_creator.return_value = mock_user
            mock_agent_creator.return_value = mock_user
            mock_agent_workflow_creator.return_value = mock_user
            agent_workflow = AgentWorkflowModel(
                id='test-1',
                name='Test agent workflow',
                description='Test agent workflow description',
                image='test_image',
                first_receiver_type=AgentWorkflowRootAgentType.AGENT,
                first_receiver_id=mock_agent.id,
                agent_relations=[
                    AgentWorkflowAgentRelationModel(
                        agent_workflow_id='test-1',
                        agent_id=mock_agent.id,
                    )
                ],
                assistant_relations=[],
                data_source_relations=[],
                handoff_relations=[],
                icon='test_icon',
                created_at=datetime.now(),
                creator_id='3',
            )
            assert lineage.build_agent_workflow_lineage(agent_workflow) is not None
            manifest = generate_manifest_and_purge()
            # # Uncomment this to grab the manifest and save it to a file
            # with open('manifest.json', 'w') as f:
            #     f.write(json.dumps(manifest))

            _assert_node(manifest, "Test agent workflow", AssetType.MODEL)
            _assert_node(manifest, "Configuration", AssetType.DOCUMENT)
            _assert_node(manifest, "workflow_registration", AssetType.CODE)
            _assert_node(manifest, "Workflow agent", AssetType.MODEL)
            _assert_node(manifest, "Workflow LLM", AssetType.MODEL)
            _assert_node(manifest, "Handoffs", AssetType.DATASET)
            _assert_node(manifest, "agent_registration", AssetType.CODE)
            _assert_node(manifest, "Assemble workflow")
            _assert_node(manifest, "Assemble agent")

            _assert_edge(manifest, "workflow_registration", "Assemble workflow")
            _assert_edge(manifest, "Assemble agent", "Workflow agent")
            _assert_edge(manifest, "Configuration", "Assemble agent")
            _assert_edge(manifest, "Handoffs", "Assemble workflow")
            _assert_edge(manifest, "Workflow LLM", "Assemble agent")
            _assert_edge(manifest, "Assemble workflow", "Test agent workflow")
            _assert_edge(manifest, "agent_registration", "Assemble agent")
            _assert_edge(manifest, "Workflow agent", "Assemble workflow")


    @pytest.mark.usefixtures("mock_appdb")
    class TestAssistantLineage:
        @mock.patch('maxgpt.services.database_model.AssistantModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.SystemInstructionModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.ModuleModel.creator', new_callable=mock.PropertyMock)
        @mock.patch('maxgpt.services.database_model.ModuleModel.query')
        @mock.patch('maxgpt.services.data_model.user.UserModel')
        @mock.patch('maxgpt.services.database_model.SystemInstructionModel.query')
        def test_build_assistant_lineage_minimal(
            self,
            mock_instr_query,
            mock_user,
            mock_module_query,
            mock_module_creator,
            mock_system_instruction_creator,
            mock_assistant_creator,
        ):
            mock_user.get_id.return_value = 'assistant-3'
            mock_user.get_display_name.return_value = 'test_user'
            mock_module_creator.return_value = mock_user
            mock_system_instruction_creator.return_value = mock_user
            mock_assistant_creator.return_value = mock_user
            mock_instr_query.filter.return_value.all.return_value = [
                SystemInstructionModel(
                    id='assistant-2',
                    name='Assistant instruction',
                    description='Assistant instruction description',
                    created_at=datetime.now(),
                    creator_id='assistant-3',
                )
            ]
            mock_module_query.filter.return_value.all.return_value = [
                ModuleModel(
                    id='assistant-0',
                    name='Assistant Test LLM',
                    description='Assistant Test LLM description',
                    created_at=datetime.now(),
                    creator_id='assistant-3',
                )
            ]
            assistant = AssistantModel(
                id='assistant-1',
                name='Test assistant',
                description='Test assistant description',
                greeting_message='Test assistant greeting message',
                image='assistant_test_image',
                icon='assistant_test_icon',
                llms=[
                    AssistantModuleRelationModel(
                        assistant_id='assistant-1',
                        module_id='assistant-0',
                    )
                ],
                system_instructions=[
                    AssistantSystemInstructionRelationModel(
                        assistant_id='assistant-1',
                        system_instruction_id='assistant-2',
                    )
                ],
                created_at=datetime.now(),
                creator_id='assistant-3',
            )
            assert lineage.build_assistant_lineage(assistant) is not None
            manifest = generate_manifest_and_purge()
            # Uncomment this to grab the manifest and save it to a file
            # with open('manifest.json', 'w') as f:
            #     f.write(json.dumps(manifest))

            _assert_node(manifest, "Assistant instruction", AssetType.DOCUMENT)
            _assert_node(manifest, "Assistant Test LLM", AssetType.MODEL)
            _assert_node(manifest, "agent_registration", AssetType.CODE)
            _assert_node(manifest, "Test assistant", AssetType.MODEL)
            _assert_node(manifest, "Configuration", AssetType.DOCUMENT)
            _assert_node(manifest, "Assemble agent")

            _assert_edge(manifest, "Assistant instruction", "Assemble agent")
            _assert_edge(manifest, "Assistant Test LLM", "Assemble agent")
            _assert_edge(manifest, "agent_registration", "Assemble agent")
            _assert_edge(manifest, "Configuration", "Assemble agent")
            _assert_edge(manifest, "Assemble agent", "Test assistant")
