import types
from unittest import mock
from datetime import datetime, timezone
from enum import Enum
import re

from maxgpt.services.eqty import util
from maxgpt.services.eqty import indicator

if util.is_eqty_enabled():

    def test_get_eqty_version():
        assert re.match(r'^\d+\.\d+\.\d+$', util.get_eqty_version())


    class TestInitEqty:
        def test_init_eqty_with_env_and_api_key(self, eqty_mock):
            result = util.init_eqty(custom_dir='/tmp/eqty')
            eqty_mock.init.assert_called_once_with(project='proj', custom_dir='/tmp/eqty')
            config_mock = eqty_mock.init.return_value
            config_mock.add_environment.assert_called_once_with('http://gov', name='proj', org_id='orgid')
            eqty_mock.login.assert_called_once()
            assert result == 'logged_in'

        def test_init_eqty_without_api_key(self, monkeypatch, eqty_mock):
            monkeypatch.delenv('EQTY_API_KEY', raising=False)
            result = util.init_eqty(custom_dir='/tmp/eqty')
            eqty_mock.init.assert_called_once_with(project='proj', custom_dir='/tmp/eqty')
            config_mock = eqty_mock.init.return_value
            config_mock.add_environment.assert_not_called()
            config_mock.create_random_did.assert_called_once()
            assert result == 'random_did'

        def test_init_eqty_with_custom_dir_none(self, monkeypatch, eqty_mock):
            config_mock = eqty_mock.init.return_value
            monkeypatch.delenv('EQTY_API_KEY', raising=False)
            result = util.init_eqty()
            eqty_mock.init.assert_called_once_with(project='proj', custom_dir=None)
            config_mock.add_environment.assert_not_called()
            config_mock.create_random_did.assert_called_once()
            assert result == 'random_did'


    class TestGenerateManifestAndPurge:
        def test_generate_manifest_and_purge_success(self, manifest_mock):
            result = util.generate_manifest_and_purge()
            manifest_mock.generate_manifest.assert_called_once()
            manifest_mock.purge_integrity_store.assert_called_once()
            assert result == {'foo': 'bar'}

        def test_generate_manifest_and_purge_manifest_exception(self, manifest_mock):
            # Simulate eqty.generate_manifest raising an exception
            manifest_mock.generate_manifest.side_effect = Exception('fail')
            try:
                _ = util.generate_manifest_and_purge()
            except Exception as e:
                assert str(e) == 'fail'
                manifest_mock.purge_integrity_store.assert_called_once()


    class TestMakeSerializable:
        class DummyModel:
            def to_dict(self):
                return {'foo': 'bar'}

        class DummyEnum(Enum):
            A = 1
            B = 2

        def test_make_serializable_basic_types(self):
            assert util.make_serializable(123) == 123
            assert util.make_serializable('abc') == 'abc'
            assert util.make_serializable([1, 2, 3]) == [1, 2, 3]
            assert util.make_serializable((1, 2)) == (1, 2)
            assert util.make_serializable({1, 2}) == {1, 2}
            assert util.make_serializable({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

        def test_make_serializable_datetime(self):
            dt = datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            assert util.make_serializable(dt) == '2020-01-01T12:00:00+00:00'

        def test_make_serializable_enum(self):
            assert util.make_serializable(TestMakeSerializable.DummyEnum.A) == 'A'

        def test_make_serializable_model(self, monkeypatch):
            monkeypatch.setattr(util.database, 'Model', TestMakeSerializable.DummyModel)
            model = TestMakeSerializable.DummyModel()
            assert util.make_serializable(model) == {'foo': 'bar'}

        def test_make_serializable_asset(self, monkeypatch):
            class DummyAsset:
                def __init__(self, value):
                    self.value = value
            monkeypatch = mock.MagicMock()
            monkeypatch.setattr(util, 'eqty', types.SimpleNamespace(Asset=DummyAsset))
            asset = DummyAsset(42)
            # Patch util.eqty.Asset to DummyAsset for isinstance check
            orig_eqty = getattr(util, 'eqty', None)
            util.eqty = types.SimpleNamespace(Asset=DummyAsset)
            assert util.make_serializable(asset) == 42
            if orig_eqty is not None:
                util.eqty = orig_eqty

        def test_make_serializable_nested(self, monkeypatch):
            monkeypatch.setattr(util.database, 'Model', TestMakeSerializable.DummyModel)
            dt = datetime(2020, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
            data = {
                'model': TestMakeSerializable.DummyModel(),
                'enum': TestMakeSerializable.DummyEnum.B,
                'dt': dt,
                'list': [TestMakeSerializable.DummyEnum.A, dt],
                'tuple': (TestMakeSerializable.DummyEnum.B, dt),
                'set': {TestMakeSerializable.DummyEnum.A, dt},
                'dict': {'x': TestMakeSerializable.DummyEnum.A, 'y': dt}
            }
            result = util.make_serializable(data)
            assert result['model'] == {'foo': 'bar'}
            assert result['enum'] == 'B'
            assert result['dt'] == '2020-01-01T12:00:00+00:00'
            assert result['list'][0] == 'A'
            assert result['list'][1] == '2020-01-01T12:00:00+00:00'
            assert result['tuple'][0] == 'B'
            assert result['tuple'][1] == '2020-01-01T12:00:00+00:00'
            assert 'A' in result['set']
            assert '2020-01-01T12:00:00+00:00' in result['set']
            assert result['dict']['x'] == 'A'
            assert result['dict']['y'] == '2020-01-01T12:00:00+00:00'

else:

    def test_get_eqty_version():
        assert util.get_eqty_version() is None
