import pytest
from unittest import mock
from maxgpt.api.impl import module_spec
from maxgpt.modules.modules import ModuleType, ModuleSpecRegistry
from maxgpt.services.database_model import database as db
from types import SimpleNamespace

def test_get_module_specs(app, mock_security_function_permission, mock_module_specs):
    """Test the get_module_specs endpoint functionality."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__assert_initialized', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, 'get_module_specs', return_value=mock_module_specs['all_module_specs']), \
                 mock.patch.object(ModuleSpecRegistry, 'initialize', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__initialized', True), \
                 mock.patch.object(db, 'session', new=mock.MagicMock()):
                endpoint = module_spec.ModuleSpecificationsEndpoint()
                response = endpoint.get()
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data is not None, "Response data is None"
                assert response_data[0]["id"] == "spec-1"
                assert response_data[0]["name"] == "Module Spec 1"
                assert response_data[1]["id"] == "spec-2"
                assert response_data[1]["name"] == "Module Spec 2"

def test_get_module_spec_by_id(app, mock_security_function_permission, mock_module_specs):
    """Test the GET module_spec by ID endpoint"""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__assert_initialized', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, 'get_module_spec', return_value=mock_module_specs['base_module_spec']), \
                 mock.patch.object(ModuleSpecRegistry, 'initialize', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__initialized', True), \
                 mock.patch.object(db, 'session', new=mock.MagicMock()):
                endpoint = module_spec.ModuleSpecificationEndpoint()
                response = endpoint.get("spec-1")
                response_data = response.get_json()
                assert response.status_code == 200
                assert response_data["id"] == "spec-1"
                assert response_data["name"] == "Module Spec 1"

def test_get_module_spec_by_id_not_found(app, mock_security_function_permission):
    """Test the GET module_spec by ID endpoint for module-spec not found(404) case"""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            with mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__assert_initialized', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, 'get_module_spec', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, 'initialize', return_value=None), \
                 mock.patch.object(ModuleSpecRegistry, '_ModuleSpecRegistry__initialized', True), \
                 mock.patch.object(db, 'session', new=mock.MagicMock()):
                endpoint = module_spec.ModuleSpecificationEndpoint()
                try:
                    endpoint.get("nonexistent-spec")
                    assert False, "Expected an abort with 404 but got a response"
                except Exception as e:
                    assert hasattr(e, 'code')
                    assert e.code == 404

@pytest.mark.usefixtures("apprd_mock")
@mock.patch.object(ModuleSpecRegistry, 'get_module_specs')
def test_all_module_types_have_registered_specs(mock_get_module_specs):
    """
    Ensure each ModuleType has at least one registered ModuleSpec.
    """
    specs = [
        SimpleNamespace(get_module_type=lambda t=t: t, get_id=lambda: f"spec-{i}", get_name=lambda: f"{t.name} Spec")
        for i, t in enumerate(ModuleType)
    ]
    specs_by_type = {s.get_module_type(): [s] for s in specs}
    mock_get_module_specs.side_effect = lambda t=None: specs if t is None else specs_by_type.get(t, [])

    missing = [t.name for t in ModuleType if not ModuleSpecRegistry.get_module_specs(t)]
    assert not missing, f"Missing registered specs for module types: {', '.join(missing)}"
