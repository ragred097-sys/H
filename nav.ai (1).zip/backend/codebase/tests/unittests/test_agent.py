from unittest import mock
from unittest.mock import MagicMock

from flask import request
from maxgpt.api.impl.agent import AgentEndpoint, AgentsEndpoint, AgentFactoryEndpoint
import pytest

from maxgpt.services.database_model import PermissionType
from maxgpt.services.internal.session_context import SessionContext

def test_get_agent_by_id(app, mock_agents, mock_security_function_permission):
    """Test to get an agent by its ID."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission

            with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
                mock_agent = mock_agents['base_agent']
                mock_agent.to_dict.return_value = {"id": "1", "name": "Agent 1"}
                mock_query.filter.return_value.first.return_value = mock_agent

                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_scalars = MagicMock()
                    mock_scalars.return_value = set()
                    mock_db_session.scalars.return_value = mock_scalars

                    with mock.patch('maxgpt.api.impl.agent.SessionContext') as mock_session_context:
                        mock_user = mock.MagicMock()
                        mock_user.get_id.return_value = "user1"
                        mock_session_context.get_current_user.return_value = mock_user

                        with mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value="READ"):
                            with mock.patch('maxgpt.api.impl.agent.PermissionType.rank', side_effect=lambda x: 1 if x == "READ" else 0):
                                with mock.patch('maxgpt.api.impl.agent.with_favorite', return_value={"id": "1", "name": "Agent 1"}):
                                    with mock.patch('maxgpt.api.impl.agent.with_access_permission', return_value={"id": "1", "name": "Agent 1"}):
                                        with mock.patch('maxgpt.api.impl.agent.with_hidden', return_value={"id": "1", "name": "Agent 1"}):
                                            endpoint = AgentEndpoint()
                                            response = endpoint.get("1")

                                            assert response.status_code == 200
                                            response_data = response.get_json()
                                            assert response_data["id"] == "1"
                                            assert response_data["name"] == "Agent 1"

def test_get_agents(app, mock_security_function_permission, mock_agents):
    """Test the get_agents endpoint functionality."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission

            # Mock user query
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user

                # Mock agent permissions
                with mock.patch('maxgpt.api.impl.agent.fetch_with_permissions') as mock_fetch:
                    mock_fetch.return_value = mock_agents['all_agents']

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_scalars = mock.MagicMock()
                        mock_scalars.all.return_value = []
                        mock_db_session.scalars.return_value = mock_scalars

                        endpoint = AgentsEndpoint()
                        response = endpoint.get()

                        response_data = response.get_json()
                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert isinstance(response_data, list)
                        assert len(response_data) >= 2, "Expected at least 2 agents in response"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Agent 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Agent 2"

# def test_create_agent(app, mock_security_functions, mock_agents):
#     """Test creating a new agent."""
#     with app.app_context():
#         with app.test_request_context(method='POST', json={
#             "name": "New Agent",
#             "description": "Agent description",
#             "tags": [],
#             "icon": "newicon",
#             "image": "newimage"
#         }):
#             _ = mock_security_functions

#             mock_user = mock.MagicMock()
#             mock_user.get_id.return_value = "user123"
#             mock_user.get_display_name.return_value = "Test User"
#             mock_user.to_dict.return_value = {
#                 '__type_name': 'User',
#                 'id': "user123",
#                 'name': "Test User"
#             }
#             mock_agents['new_agent'].creator = mock_user

#             with mock.patch('maxgpt.services.database_model.AgentModel') as mock_agent_model:
#                 mock_agent_model.return_value = mock_agents['new_agent']

#                 with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
#                     mock_get_current_user.return_value = mock_user

#                     with mock.patch('maxgpt.api.impl.agent.with_favorite', return_value=mock_agents['new_agent'].to_dict()):
#                         with mock.patch('maxgpt.api.impl.agent.with_access_permission', return_value=mock_agents['new_agent'].to_dict()):
#                             with mock.patch('maxgpt.api.impl.agent.with_hidden', return_value=mock_agents['new_agent'].to_dict()):
#                                 with mock.patch('maxgpt.services.database.session') as mock_db_session:
#                                     mock_db_session.add = mock.MagicMock()
#                                     mock_db_session.commit = mock.MagicMock()

#                                     endpoint = AgentFactoryEndpoint()
#                                     response = endpoint.post()

#                                     assert response.status_code == 200
#                                     response_data = response.get_json()
#                                     assert response_data["name"] == "New Agent"
#                                     assert "description" in response_data
#                                     assert response_data["icon"] == "newicon"
#                                     assert response_data["image"] == "newimage"
#                                     assert "id" in response_data
#                                     # Validate tags
#                                     assert "tags" in response_data
#                                     assert isinstance(response_data["tags"], list)
#                                     # Check optional fields
#                                     if "creator" in response_data:
#                                         assert response_data["creator"]["id"] == "user123"
#                                         assert response_data["creator"]["name"] == "Test User"

# def test_update_agent(app, mock_security_functions, mock_agents):
#     update_data = {
#         "name": "Updated agent",
#         "description": "Updated Test description",
#         "image": "Updated image"
#     }

#     with app.app_context():
#         with app.test_request_context(method='PUT', json=update_data):
#             _ = mock_security_functions

#             mock_agent = mock_agents['update_agent']
#             mock_agent.deleted_at = None
#             mock_agent.tag_relations = []
#             mock_agent.custom_system_instruction = None
#             mock_agent.to_dict.return_value = {
#                 "id": "1",
#                 "name": "Updated agent",
#                 "description": "Updated Test description",
#                 "image": "Updated image",
#                 "icon": None
#             }

#         with app.test_request_context(method='PUT', json=update_data):
#             _ = mock_security_functions
#             with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
#                 mock_query.get.return_value = mock_agents['update_agent']

#                 with mock.patch('maxgpt.services.database.session') as mock_db_session:
#                     mock_db_session.commit = mock.MagicMock()

#                     with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
#                         mock_object_session.return_value = mock_db_session

#                         endpoint = AgentEndpoint()
#                         response = endpoint.put("1")
#                         assert response.status_code == 200
#                         response_data = response.get_json()
#                         assert response_data["id"] == "1"
#                         assert response_data["name"] == "Updated agent"
#                         assert response_data["description"] == "Updated Test description"
#                         assert response_data["image"] == "Updated image"

# def test_delete_agent(app, mock_security_functions, mock_agents):
#     """Test deleting an agent."""
#     with app.app_context():
#         with app.test_request_context('/agent/1', method='DELETE'):
#             _ = mock_security_functions

#             mock_agent = mock_agents['base_agent']
#             mock_agent.deleted_at = None
#             mock_agent.to_dict.return_value = {
#                 "id": "1",
#                 "name": "Agent 1"
#             }
#             with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
#                 # Ensure the mock returns a valid agent object
#                 mock_query.get.return_value = mock_agents['base_agent']
               
#                 with mock.patch('maxgpt.services.database.session') as mock_db_session:
#                     # Mock the delete and commit operations
#                     mock_db_session.delete = mock.MagicMock()
#                     mock_db_session.commit = mock.MagicMock()
#                     endpoint = AgentEndpoint()
#                     response = endpoint.delete("1")

#                     assert response.status_code == 200
#                     response_data = response.get_json()
#                     assert response_data["id"] == "1"
#                     assert response_data["name"] == "Agent 1"

def test_delete_agent(app, mock_security_functions, mock_agents):
    """Test deleting an agent."""
    with app.app_context():
        with app.test_request_context('/agent/1', method='DELETE'):
            _ = mock_security_functions  # Prevent unused variable warning

            mock_agent = mock_agents['base_agent']
            mock_agent.deleted_at = None
            mock_agent.to_dict.return_value = {
                "id": "1",
                "name": "Agent 1"
            }

            with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
                mock_query.get.return_value = mock_agent

                with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_workflow_query:
                    mock_workflow_query.filter.return_value.first.return_value = None

                    with mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value=PermissionType.WRITE):
                        
                        with mock.patch('maxgpt.api.impl.agent.UserFavoriteModel.query') as mock_fav_query:
                            mock_fav_query.filter.return_value.delete.return_value = 1

                            with mock.patch('maxgpt.api.impl.agent.UserHiddenEntityModel.query') as mock_hidden_query:
                                mock_hidden_query.filter.return_value.delete.return_value = 1

                                mock_user = mock.MagicMock()
                                mock_user.get_id.return_value = "user1"

                                with mock.patch('maxgpt.api.impl.agent.SessionContext.get_current_user', return_value=mock_user):
                                    
                                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                        mock_db_session.delete = mock.MagicMock()
                                        mock_db_session.commit = mock.MagicMock()

                                        with mock.patch('maxgpt.api.impl.agent.with_favorite', side_effect=lambda d, _: d), \
                                             mock.patch('maxgpt.api.impl.agent.with_access_permission', side_effect=lambda d, p: d), \
                                             mock.patch('maxgpt.api.impl.agent.with_hidden', side_effect=lambda d, _: d):

                                            endpoint = AgentEndpoint()
                                            response = endpoint.delete("1")

                                            assert response.status_code == 200
                                            response_data = response.get_json()
                                            assert response_data["id"] == "1"
                                            assert response_data["name"] == "Agent 1"

def test_update_agent(app, mock_security_functions, mock_agents):
    """Test updating an agent."""
    with app.app_context():
        with app.test_request_context(
            '/agent/1', 
            method='PUT', 
            json={
                "name": "Updated Agent",
                "description": "Updated Description",
                "image": "updated_image.png",
                "icon": "updated_icon.png",
                "tags": [{"id": "tag123"}],
                "systemInstructionIds": [],
                "functionToolIds": [],
                "customSystemInstruction": "Custom instruction text"
            }
        ):
            _ = mock_security_functions  # to avoid unused warning

            mock_agent = mock_agents['base_agent']
            mock_agent.deleted_at = None
            mock_agent.tag_relations = []
            mock_agent.system_instructions = []
            mock_agent.function_tools = []
            mock_agent.to_dict.return_value = {
                "id": "1",
                "name": "Updated Agent",
                "description": "Updated Description",
                "icon": "updated_icon.png",
                "image": "updated_image.png",
                "tags": [{"id": "tag123"}]
            }

            with mock.patch('maxgpt.services.database_model.AgentModel.query') as mock_query:
                mock_query.get.return_value = mock_agent

                with mock.patch('maxgpt.api.impl.agent.get_user_access_for', return_value=PermissionType.WRITE), \
                     mock.patch('maxgpt.api.impl.agent.AgentTagRelationModel'), \
                     mock.patch('maxgpt.api.impl.agent.SystemInstructionModel.query.get_or_404'), \
                     mock.patch('maxgpt.api.impl.agent.ModuleModel.query.get_or_404'), \
                     mock.patch('maxgpt.api.impl.agent.AgentSystemInstructionRelationModel'), \
                     mock.patch('maxgpt.api.impl.agent.AgentModuleRelation'), \
                     mock.patch('maxgpt.api.impl.agent.Session.object_session', return_value=mock.MagicMock()), \
                     mock.patch('maxgpt.api.impl.agent.SessionContext.get_current_user') as mock_get_user, \
                     mock.patch('maxgpt.services.database.session') as mock_db_session, \
                     mock.patch('maxgpt.api.impl.agent.with_favorite', side_effect=lambda a, _: a), \
                     mock.patch('maxgpt.api.impl.agent.with_access_permission', side_effect=lambda a, p: a), \
                     mock.patch('maxgpt.api.impl.agent.with_hidden', side_effect=lambda a, _: a):

                    mock_user = mock.MagicMock()
                    mock_user.get_id.return_value = "user1"
                    mock_get_user.return_value = mock_user

                    mock_db_session.scalars.return_value = iter([])  # Simulate empty favorites/hidden

                    endpoint = AgentEndpoint()
                    response = endpoint.put("1")

                    assert response

