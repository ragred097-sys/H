from unittest import mock 
from maxgpt.api.impl.agent_workflows import AgentWorkflowsEndpoint, AgentWorkflowEndpoint, AgentWorkflowFactoryEndpoint
import pytest
from flask import Response
from maxgpt.services.database_model import PermissionType

def test_get_agent_workflows(app, mock_security_function_permission, mock_agentworkflows):
    """Test the get_agent_workflows endpoint functionality."""
    with app.app_context():
        with app.test_request_context():
            _ = mock_security_function_permission
            
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                mock_user = mock.MagicMock()
                mock_user_query.filter.return_value.first.return_value = mock_user

                with mock.patch('maxgpt.api.impl.agent_workflows.fetch_with_permissions') as mock_fetch:
                    mock_fetch.return_value = mock_agentworkflows['all_agent_workflows']

                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_scalars = mock.MagicMock()
                        mock_scalars.all.return_value = []
                        mock_db_session.scalars.return_value = mock_scalars
                        
                        endpoint = AgentWorkflowsEndpoint()
                        response = endpoint.get()

                        response_data = response.get_json()

                        assert response.status_code == 200
                        assert response_data is not None, "Response data is None"
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "Agent Workflow 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "Agent Workflow 2"
                        
def test_update_agent_workflow(app, mock_security_functions, mock_agentworkflows):
    """Test PUT method of agent workflow"""
    update_data = {
        "name": "Updated agent workflow",
        "description": "Updated Test description",
        "image": "Updated image",
        "agents": [
            {
                "id": "agent1",
                "type": "Agent",
                "canHandOffTo": []
            }
        ],
        "rootAgent": {
            "id": "agent1",
            "type": "Agent"
        }
    }

    with app.app_context():
        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions

            mock_agent_workflow = mock_agentworkflows['update_agent_workflow']
            mock_agent_workflow.deleted_at = None
            mock_agent_workflow.tag_relations = []
            mock_agent_workflow.agent_relations = []
            mock_agent_workflow.assistant_relations = []
            mock_agent_workflow.data_source_relations = []
            mock_agent_workflow.handoff_relations = []

        with app.test_request_context(method='PUT', json=update_data):
            _ = mock_security_functions 
            with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_query:
                mock_query.get.return_value = mock_agentworkflows['update_agent_workflow']
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    
                    with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
                        mock_object_session.return_value = mock_db_session
                        
                        with mock.patch('maxgpt.api.impl.agent_workflows.with_hidden', return_value=mock_agentworkflows['update_agent_workflow'].to_dict()):
                            endpoint = AgentWorkflowEndpoint()
                            response: Response = endpoint.put("1")
                            
                            assert response.status_code == 200
                            response_data = response.get_json()
                            assert response_data["id"] == "1"
                            assert response_data["name"] == "Updated agent workflow"
                            assert len(response_data["agents"]) == 1
                            assert response_data["agents"][0]["type"] == "Agent"


def test_create_agent_workflow(app, mock_security_functions, mock_agentworkflows):
    """Test POST method of agent workflow."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "id": "new-uuid",
            "name": "New Agent Workflow",
            "description": "Agent Workflow description",
            "tags": [],
            "icon": "newicon",
            "image": "newimage",
            "agents": [
                {
                    "id": "agent1",
                    "type": "Agent",
                    "canHandOffTo": []
                }
            ],
            "rootAgent": {
                "id": "agent1",
                "type": "Agent"
            }
        }):
            
            mock_user = mock.MagicMock()
            mock_user.get_id.return_value = "user123"
            mock_user.get_display_name.return_value = "Test User"
            mock_user.to_dict.return_value = {
                '__type_name': 'User',
                'id': "user123",
                'name': "Test User"
            }

            mock_agentworkflows['new_agent_workflow'].creator = mock_user

            with mock.patch('maxgpt.services.security.ShallowUser.to_dict', 
                            return_value={'id': 'user123', 'name': 'Test User'}):

                with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                    mock_user_query.filter.return_value.first.return_value = mock_user

                    with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                        mock_get_current_user.return_value = mock_user

                        with mock.patch('maxgpt.services.database_model.AgentWorkflowModel') as mock_agent_workflow_model:
                            mock_agent_workflow_model.return_value = mock_agentworkflows['new_agent_workflow']

                            with mock.patch('maxgpt.api.impl.agent_workflows.with_favorite', 
                                          return_value=mock_agentworkflows['new_agent_workflow'].to_dict()):
                                with mock.patch('maxgpt.api.impl.agent_workflows.with_access_permission', 
                                              return_value=mock_agentworkflows['new_agent_workflow'].to_dict()):
                                    with mock.patch('maxgpt.api.impl.agent_workflows.with_hidden',
                                                  return_value=mock_agentworkflows['new_agent_workflow'].to_dict()):

                                        with mock.patch('maxgpt.services.database.session') as mock_db_session:
                                            mock_db_session.add = mock.MagicMock()
                                            mock_db_session.commit = mock.MagicMock()

                                            endpoint = AgentWorkflowFactoryEndpoint()
                                            response = endpoint.post()

                                            assert response.status_code == 200
                                            response_data = response.get_json()
                                            
                                            assert response_data["name"] == "New Agent Workflow"
                                            assert response_data["id"] == "new-uuid"
                                            
                                            #Validate agents and root agent
                                            assert "agents" in response_data
                                            assert isinstance(response_data["agents"], list)
                                            assert response_data["agents"][0]["id"] == "agent1"
                                            assert response_data["agents"][0]["type"] == "Agent"
                                            
                                            assert response_data["rootAgent"]["id"] == "agent1"
                                            assert response_data["rootAgent"]["type"] == "Agent"

def test_delete_agent_workflow(app, mock_security_functions, mock_agentworkflows):
    """Test DELETE method of agent workflow"""
    with app.app_context():
        with app.test_request_context(method='DELETE'):
            _ = mock_security_functions

            mock_agent_workflow = mock_agentworkflows['base_agent_workflow']
            mock_agent_workflow.deleted_at = None
            mock_agent_workflow.to_dict.return_value = {
                '__type_name': 'AgentWorkflow',
                'id': '1',
                'name': 'Agent Workflow 1',
                'description': 'Description 1',
                'tags': [],
                'agents': [],
                'rootAgent': None,
                'icon': 'icon1',
                'image': 'image1',
                'permission': PermissionType.READ.value
            }

            with mock.patch('maxgpt.services.database_model.AgentWorkflowModel.query') as mock_query:
                mock_query.get.return_value = mock_agent_workflow

                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.commit = mock.MagicMock()
                    mock_db_session.delete = mock.MagicMock()

                    with mock.patch('sqlalchemy.orm.session.Session.object_session') as mock_object_session:
                        mock_object_session.return_value = mock_db_session

                        with mock.patch('maxgpt.api.impl.agent_workflows.with_hidden', return_value=mock_agent_workflow.to_dict()):
                            with mock.patch('maxgpt.api.impl.agent_workflows.with_favorite', return_value=mock_agent_workflow.to_dict()):
                                with mock.patch('maxgpt.api.impl.agent_workflows.with_access_permission', return_value=mock_agent_workflow.to_dict()):
                                    endpoint = AgentWorkflowEndpoint()
                                    response = endpoint.delete("1")
                                    
                                    assert response.status_code == 200
                                    response_data = response.get_json()
                                    assert response_data["id"] == "1"
                                    assert response_data["name"] == "Agent Workflow 1"