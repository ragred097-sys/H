from unittest import mock
from unittest.mock import MagicMock

import json
import io

from maxgpt.services.database_model import AssistantModel

from maxgpt.navai.api.impl.data_migration_tool import DMTExportEndpoint, DMTImportEndpoint, __Secret_Key__
from maxgpt.navai.api.impl.utils import decrypt_json, encrypt_json
from flask import make_response, jsonify

def test_export_good_path(app, mock_security_function_permission):
    """Test data migration for assistant."""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "entityId": "1",
            "entityType": "Assistant"
        }):
            _ = mock_security_function_permission
            #Mock current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "mock_user_id"
                mock_get_user.return_value = mock_user
                
                #Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    # patch get_assistant_by_id to return a dict
                    with mock.patch('maxgpt.navai.api.impl.data_migration_tool.get_assistant_by_id') as mock_get_assistant:
                        mock_get_assistant.return_value = {
                            "__type_name": "Assistant",
                            "name": "Jack",
                            "description": "Jack in the box",
                            "tags": [],
                            "customSystemInstruction": None,
                            "greetingMessage": None,
                            "sampleQuestions": [],
                            "attachmentStorages": [
                                {"type": "VIDEO"},
                                {"type": "AUDIO"},
                                {"type": "IMAGE"},
                                {"type": "TEXT"},
                            ],
                            "icon": None,
                            "image": None,
                            "favorite": False,
                            "hidden": False,
                            "llms": [
                                {"name": "GPT4o on Azure (AIP-NAVAI)", "description": None}
                            ],
                            "data_sources": [],
                            "system_instructions": [],
                        }

                        endpoint = DMTExportEndpoint()
                        response = endpoint.post()
                        response_data = response.get_json()
                        assert response.status_code == 200
                        
                        # Assert it’s a file download
                        content_disposition = response.headers.get("Content-Disposition")
                        assert content_disposition is not None
                        assert "attachment" in content_disposition
                        assert "filename=" in content_disposition

                        # Assert file content
                        response.direct_passthrough = False
                        file_data = response.get_data(as_text=True)
                        decrypted_text = decrypt_json(file_data, __Secret_Key__)
                        response_json = json.loads(decrypted_text)
                        assert response_json["name"] == "Jack"

def test_export_unsupported_entity(app, mock_security_function_permission):
    """Should return 422 if entity type is not supported"""
    with app.app_context():
        with app.test_request_context(method='POST', json={
            "entityId": "1",
            "entityType": "AlienEntity"
        }):
            _ = mock_security_function_permission
            #Mock current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "mock_user_id"
                mock_get_user.return_value = mock_user
                
                #Mock the database session
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = DMTExportEndpoint()
                   
                    response = endpoint.post()
                    if isinstance(response, tuple):
                        data, status = response
                        response = make_response(jsonify(data), status)

                    assert response.status_code == 422
                    data = response.get_json()
                    assert data["message"] == "Unsupported entityType"

def test_import_preview_good_path(app, mock_security_function_permission):
    """Test importing a valid encrypted file in preview mode."""

    # Fake data you expect after decryption
    fake_entity = {
        "__type_name": "Assistant",
        "attachmentStorages": [
            {"type": "VIDEO"},
            {"type": "AUDIO"},
            {"type": "IMAGE"},
            {"type": "TEXT"}
        ],
        "customSystemInstruction": None,
        "data_sources": [
            {
                "name": "my first data source",
                "description": "description attached to this data source"
            }
        ],
        "description": "Jack in the Box",
        "favorite": False,
        "greetingMessage": "Greetings fellow humans",
        "hidden": False,
        "icon": None,
        "image": None,
        "llms": [],
        "name": "Jack",
        "sampleQuestions": [
            "Would you like to know about quantum teleportation via void space and particle connection via quantum entanglement? Well, I sure can answer.",
            "Tell me, what evidence do you have regarding my blanket being the best blanket??!!!"
        ],
        "system_instructions": [
            {
                "description": "Informing the agent of its name",
                "name": "Naming",
                "message": "You are my helpful agent and your name is Mike"
            }
        ],
        "tags": []
    }

    # Encrypt test data
    payload = json.dumps(fake_entity)
    encrypted_data = encrypt_json(payload, __Secret_Key__)

    with app.app_context():
        with app.test_request_context(
            method='POST',
            query_string={'preview': 'true'},
            data={
                "file": (io.BytesIO(encrypted_data.encode("utf-8")), "test.txt")
            }
        ):
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                mock_user = MagicMock()
                mock_user.get_id.return_value = "mock_user_id"
                mock_get_user.return_value = mock_user

                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    endpoint = DMTImportEndpoint()
                    response = endpoint.post()

                    # Flask-RESTX might return tuple (resp, code)
                    if isinstance(response, tuple):
                        data, status = response
                        response = make_response(jsonify(data), status)

                    # Always check what you got back
                    resp_text = response.get_data(as_text=True)
                    print("Status Code:", response.status_code)
                    print("Response Text:", resp_text) 

                    assert response.status_code == 200, f"Unexpected response: {resp_text}"
                    resp_json = response.get_json()
                    assert resp_json["__type_name"] == "Assistant"
                    assert resp_json["description"] == "Jack in the Box"
                    assert resp_json["attachmentStorages"][0]["type"] == "VIDEO"

def test_import_good_path(app, mock_security_function_permission):
    """Test importing a valid Assistant entity with a proper payload."""

    fake_entity = {
        "__type_name": "Assistant",
        "accessPermission": "WRITE",
        "attachmentStorages": [
            {"fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f", "type": "VIDEO"},
            {"fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f", "type": "AUDIO"},
            {"fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f", "type": "IMAGE"},
            {"fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f", "type": "TEXT"}
        ],
        "customSystemInstruction": None,
        "dataSourceIds": [],
        "description": "Jack in the Box",
        "favorite": False,
        "greetingMessage": "Greetings fellow humans",
        "hidden": False,
        "icon": None,
        "image": None,
        "llmIds": "01ab5eec-c6bc-4e13-abc0-5e4924f5d43b",  # required by import_assistant
        "name": "Jack",
        "sampleQuestions": [
            "Would you like to know about quantum teleportation via void space and particle connection via quantum entanglement? Well, I sure can answer.",
            "Tell me, what evidence do you have regarding my blanket being the best blanket??!!!"
        ],
        "system_instructions": [
            {
                "description": "Informing the agent of its name",
                "name": "Naming",
                "message": "You are my helpful agent and your name is Jack"
            },
            {
                "description": "Experience information",
                "name": "Specialized in Law",
                "message": "You have a master degree in Law and have worked for the general attorney of your district for the past 4 years"
            }
        ],
        "systemInstructionIds": [
            "d0024d30-24a7-4b25-9277-a6b56c31ae3b"
        ],
        "tags": []
    }

    with app.app_context():
        with app.test_request_context(method="POST", json=fake_entity):
            with mock.patch("maxgpt.services.internal.session_context.SessionContext.get_current_user") as mock_get_user, \
                 mock.patch("maxgpt.services.database.session") as mock_db_session, \
                 mock.patch("maxgpt.navai.api.impl.data_migration_tool.get_llm_by_id") as mock_llm:

                # Mock user context
                mock_user = MagicMock()
                mock_user.get_id.return_value = "mock_user_id"
                mock_get_user.return_value = mock_user

                # Mock DB session to avoid real commits
                mock_db_session.commit.return_value = None

                # Mock LLM lookup
                mock_llm.return_value = MagicMock(get_id=lambda: "01ab5eec-c6bc-4e13-abc0-5e4924f5d43b")

                endpoint = DMTImportEndpoint()
                response = endpoint.post()

                if isinstance(response, tuple):
                    data, status = response
                    response = make_response(jsonify(data), status)

                resp_text = response.get_data(as_text=True)
                assert response.status_code == 200, f"Unexpected: {resp_text}"
                assert "success" in resp_text.lower()

                # Assertions on DB interactions
                add_calls = mock_db_session.add.call_args_list
                assert any(isinstance(call.args[0], AssistantModel) for call in add_calls), \
                    "No AssistantModel was added to the session"
                assistant_added = next(
                    (call.args[0] for call in add_calls if isinstance(call.args[0], AssistantModel)), 
                    None
                )
                assert assistant_added is not None
                assert assistant_added.name == "Jack"
                assert assistant_added.description == "Jack in the Box"
