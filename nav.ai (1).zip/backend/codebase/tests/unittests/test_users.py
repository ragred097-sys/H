from unittest import mock
from maxgpt.api.impl.user import UserFavoriteEndpoint, UserSettingFactoryEndpoint, UsersEndpoint,UserEndpoint, UserSettingEndpoint, UserFavoritesEndpoint
from maxgpt.services.database_model import FavoriteSubject, PreferenceScope  


def test_get_users(app, mock_users, mock_security_functions): 
    """_summary_

    Args:
        app (_type_): This Flask APP
        mock_users (_type_): User Fixture 
        mock_security_functions (_type_):The mock_security_functions fixture is necessary to simulate the 
                                         authenticated user for the request. Although it's not directly used 
                                         within the body of this test function, it's required to avoid authentication 
                                         errors and ensure that the request passes the authentication check.
    """
    # Dummy reference to avoid "unused variable" warning
    _ = mock_security_functions
    with app.app_context():  
        with app.test_request_context():   
            print("Inside Context") 
            # Mock the UserModel.query.all() method to return mock users
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_user_query:
                mock_user_query.all.return_value = mock_users
                print("NAME IS ::", app.app_context)
                print("******************************************************")
                with mock.patch('maxgpt.services.database.session') as mock_db_session: 
                        mock_db_session.scalars.return_value = set() 
                        endpoint = UsersEndpoint() 
                        # Call the get method of the endpoint
                        response = endpoint.get() 
                        # Debugging: Print the response
                        print("Response:", response)
                        print("Response Data:", response.get_json()) 
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data is not None, "Response data is None"
                        assert len(response_data) == 2  # We have 2 mock users
                        assert response_data[0]["id"] == "1"
                        assert response_data[0]["name"] == "User 1"
                        assert response_data[1]["id"] == "2"
                        assert response_data[1]["name"] == "User 2"    

def test_get_user_by_id(app, mock_users, mock_security_functions): 
    with app.app_context():
        with app.test_request_context():
            # Mock the UserModel.query.get() to return a mocked user
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_query:
                mock_query.get.return_value = mock_users[0]
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    # Create the endpoint
                    endpoint = UserEndpoint()
                    
                    # Test GET with an existing user ID
                    response = endpoint.get("1")
                    
                    # Assertions
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data["id"] == "1"
                    assert response_data["name"] == "User 1"
                    assert response_data["email"] == "user1@example.com" 


def test_get_user_by_me(app, mock_users, mock_security_functions):
    """Test to get a user using 'me' as the ID."""
    with app.app_context():
        with app.test_request_context():
            # Mock the current user
            current_user_mock = mock.MagicMock()
            current_user_mock.get_id.return_value = "1"
            
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user', 
                           return_value=current_user_mock):
                
                # Mock the UserModel.query.get() to return a mocked user
                # Dummy reference to avoid "unused variable" warning
                _ = mock_security_functions
                with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_query:
                    mock_query.get.return_value = mock_users[0]
                    
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                        
                        # Create the endpoint
                        endpoint = UserEndpoint()
                        
                        # Test GET with 'me' as the user ID
                        response = endpoint.get("me")
                        
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["id"] == "1"
                        assert response_data["name"] == "User 1"
                        assert response_data["email"] == "user1@example.com"

def test_get_user_not_found(app, mock_security_functions):
    """Test to get a non-existent user."""
    with app.app_context():
        with app.test_request_context():
            # Dummy reference to avoid "unused variable" warning
            _ = mock_security_functions
            # Mock the UserModel.query.get() to return None (user not found)
            with mock.patch('maxgpt.services.data_model.user.UserModel.query') as mock_query:
                mock_query.get.return_value = None
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    # Create the endpoint
                    endpoint = UserEndpoint()
                    
                    # Test GET with a non-existent user ID
                    # This should raise an exception with a 404 status code
                    try:
                        response = endpoint.get("999")
                        print("Response got :",response)
                        assert False, "Expected an abort with 404 but got a response"
                    except Exception as e:
                        # Check if it's the appropriate exception
                        assert hasattr(e, 'code')
                        assert e.code == 404

def test_delete_user_setting(app, mock_user_setting, mock_security_functions):
    """Test to delete a user setting."""
    with app.app_context():
        with app.test_request_context(headers={'Content-Type': 'application/json'}):
            # Mock SessionContext.get_current_user to simulate current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                # Return the mock user from the fixtures
                mock_get_current_user.return_value = mock_security_functions  # Use the mock user
                mock_security_functions.get_id.return_value = "1"
                print("USER IS",mock_get_current_user.get_id())
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                # Mock UserSettingModel.query.get() to simulate retrieving the user setting
                        with mock.patch('maxgpt.services.database_model.UserSettingModel.query') as mock_query:
                            mock_query.get.return_value = mock_user_setting[0]  # Return the mocked user setting
                            # Mock the database session delete method to avoid actual database operations
                            with mock.patch('maxgpt.services.database.session.delete') as mock_delete:
                                # Simulate that the user setting will be deleted
                                mock_delete.return_value = None
 
                                with mock.patch('flask.request.get_json') as mock_get_json:
                                    mock_get_json.return_value = {}
                                    # Create the endpoint instance
                                    endpoint = UserSettingEndpoint()
   
                                    # Test DELETE with an existing user setting
                                    response = endpoint.delete("1", "setting_1")  # Use dummy user ID and preference ID
   
                                    # Assertions
                                    assert response.status_code == 200  # Expect 200 OK
                                    response_data = response.get_json()  # Get the JSON response
   
                                    # Verify that the deleted setting matches the mocked user setting
                                    assert response_data["userId"] == "1"
                                    assert response_data["preferenceId"] == "setting_1"
                                    assert response_data["value"] == "value"
def test_get_user_settings_by_user_id_preference(app, mock_user_setting, mock_security_functions):
    """Returns the settings for the given user-id and preference_id."""
    with app.app_context():
        with app.test_request_context(headers={'Content-Type': 'application/json'}):
            # Mock SessionContext.get_current_user to simulate current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                # Return the mock user from the fixtures
                mock_get_current_user.return_value = mock_security_functions  # Use the mock user
                mock_security_functions.get_id.return_value = "1"
                print("USER IS",mock_get_current_user.get_id())
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                # Mock UserSettingModel.query.get() to simulate retrieving the user setting
                        with mock.patch('maxgpt.services.database_model.UserSettingModel.query') as mock_query:
                            mock_query.get.return_value = mock_user_setting [0] # Return the mocked user setting
                            with mock.patch('flask.request.get_json') as mock_get_json:
                                mock_get_json.return_value = {}
                                # Create the endpoint instance
                                endpoint = UserSettingEndpoint()

                                # Test GET with an existing user setting
                                response = endpoint.get("1", "setting_1")  # Use dummy user ID and preference ID

                                # Assertions
                                assert response.status_code == 200  # Expect 200 OK
                                response_data = response.get_json()  # Get the JSON response

                                # Verify that the retrieved setting matches the mocked user setting
                                assert response_data["userId"] == "1"
                                assert response_data["preferenceId"] == "setting_1"
                                assert response_data["value"] == "value"
 

def test_get_user_settings_by_user_id(app, mock_user_setting, mock_security_functions):
    """Returns the settings for the given user-id if accessible."""
    with app.app_context():
        with app.test_request_context(headers={'Content-Type': 'application/json'}):
            # Mock SessionContext.get_current_user to simulate current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                # Return the mock user from the fixtures
                mock_get_current_user.return_value = mock_security_functions  # Use the mock user
                mock_security_functions.get_id.return_value = "1"
                print("USER IS",mock_get_current_user.get_id())
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                # Mock UserSettingModel.query.get() to simulate retrieving the user setting
                        with mock.patch('maxgpt.services.database_model.UserSettingModel.query') as mock_query:
                            mock_query.get.return_value = mock_user_setting[0]  # Return the mocked user setting
                            with mock.patch('flask.request.get_json') as mock_get_json:
                                mock_get_json.return_value = {}
                                # Create the endpoint instance
                                endpoint = UserSettingEndpoint()

                                # Test GET with an existing user setting
                                response = endpoint.get("1",None)  # Use dummy user ID and preference ID

                                # Assertions
                                assert response.status_code == 200  # Expect 200 OK
                                response_data = response.get_json()  # Get the JSON response

                                # Verify that the retrieved setting matches the mocked user setting
                                assert response_data["userId"] == "1"
                                assert response_data["preferenceId"] == "setting_1"
                                assert response_data["value"] == "value"
                            
def test_put_user_setting(app, mock_user_setting, mock_security_functions):
    """Test to update a user setting."""
    with app.app_context():
        with app.test_request_context(headers={'Content-Type': 'application/json'}):
            # Mock SessionContext.get_current_user to simulate current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_current_user:
                # Return the mock user from the fixtures
                mock_get_current_user.return_value = mock_security_functions  # Use the mock user
                mock_security_functions.get_id.return_value = "1"
                print("USER IS",mock_get_current_user.get_id())
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        mock_db_session.scalars.return_value = set()
                # Mock UserSettingModel.query.get() to simulate retrieving the user setting
                        with mock.patch('maxgpt.services.database_model.UserSettingModel.query') as mock_query:
                            mock_query.get.return_value = mock_user_setting[1]  # Return the mocked user setting
                            
                               # Mock the database session commit method to avoid actual database operations
                            with mock.patch('maxgpt.services.database.session.commit') as mock_commit:
                                with mock.patch('flask.request.get_json') as mock_get_json:
                                    mock_get_json.return_value = {}
                                    # Simulate PUT request with updated setting
                                with mock.patch('flask.request.get_json') as mock_get_json:
                                    mock_get_json.return_value = {"userId": "1","preferenceId": "setting_1","value":"new_value"}
                                
                                    # Create the endpoint instance
                                    endpoint = UserSettingEndpoint()
                                
                                    # Test PUT with an existing user setting
                                    response = endpoint.put("1", "value")  # Use dummy user ID and preference ID
                                    # Assertions
                                    assert response.status_code == 200  # Expect 200 OK
                                    response_data = response.get_json()  # Get the JSON response
                                    # Verify that the setting was updated
                                    assert response_data["userId"] == "1"
                                    assert response_data["preferenceId"] == "setting_1"
                                    assert response_data["value"] == "new_value"  # New value after update

def test_delete_user_favorite_success(app, mock_security_functions, mock_favorites):
    """Test successful deletion of a user favorite."""
    with app.app_context():
        with app.test_request_context(method='DELETE', query_string={'subjectType': FavoriteSubject.ASSISTANT.value, 'subjectId': 'assistant_1'}):
            # Mock the current user
            current_user_mock = mock.MagicMock()
            current_user_mock.get_id.return_value = "user123"
           
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user',
                           return_value=current_user_mock):
               
                with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_query:
                    mock_query.get.return_value = mock_favorites
                   
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        endpoint = UserFavoriteEndpoint()
                        response = endpoint.delete("user123")
                       
                        # Assertions
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data['userId'] == 'user123'
                        assert response_data['subjectId'] == 'assistant_1'
                       
                        # Verify the favorite was deleted from the database
                        mock_db_session.delete.assert_called_once_with(mock_favorites)


#GET UserFavorites
def test_get_user_favorites_for_specific_user(app, mock_user, mock_user_favorites, mock_security_functions):
    with app.app_context():
        with app.test_request_context():
            user_id = mock_user.get_id()
            mock_security_functions.return_value = mock_user
            
            with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_favorite_query:
                mock_filter_by = mock.MagicMock()
                mock_filter_by.all.return_value = mock_user_favorites
                mock_favorite_query.filter_by.return_value = mock_filter_by
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    endpoint = UserFavoritesEndpoint()
                    response = endpoint.get(user_id)
                    
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data is not None
                    assert len(response_data) == 2
                    assert response_data[0]["user_id"] == "28502f0c-300c-432a-b828-0ed68a771000"
                    assert response_data[0]["subjectId"] == "8b4bd245-851f-4a91-82d4-1a4e53fc5609"
                    assert response_data[1]["subjectId"] == "8b4bd245-851f-4a91-82d4-1a4e53fc5611"
                    
                    mock_favorite_query.filter_by.assert_called_once_with(user_id=user_id)


def test_get_user_favorites_for_me(app, mock_user_favorites, mock_security_functions):
    _ = mock_security_functions
    with app.app_context():
        with app.test_request_context():
            user_id = "me"
            
            with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_favorite_query:
                mock_filter_by = mock.MagicMock()
                mock_filter_by.all.return_value = mock_user_favorites
                mock_favorite_query.filter_by.return_value = mock_filter_by
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    endpoint = UserFavoritesEndpoint()
                    response = endpoint.get(user_id)
                    
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data is not None
                    assert len(response_data) == 2
                    assert response_data[0]["id"] == "fav1"
                    assert response_data[1]["id"] == "fav2"
                    assert response_data[0]["subject_type"] == "Workspace 1"
                    assert response_data[1]["subject_type"] == "Workspace 2"


def test_get_user_favorites_empty_list(app, mock_user, mock_security_functions):
    with app.app_context():
        with app.test_request_context():
            user_id = "me"
            
            with mock.patch('maxgpt.services.database_model.UserFavoriteModel.query') as mock_favorite_query:
                mock_filter_by = mock.MagicMock()
                mock_filter_by.all.return_value = []
                mock_favorite_query.filter_by.return_value = mock_filter_by
                
                with mock.patch('maxgpt.services.database.session') as mock_db_session:
                    mock_db_session.scalars.return_value = set()
                    
                    endpoint = UserFavoritesEndpoint()
                    response = endpoint.get(user_id)
                    
                    assert response.status_code == 200
                    response_data = response.get_json()
                    assert response_data is not None
                    assert len(response_data) == 0

#POST User Favorite
def test_post_user_favorite(app, mock_user, mock_security_functions, mock_user_favorite_post):
    """Test creating a new user favorite."""
    with app.app_context():
        user_id = mock_user.get_id()
        
        with app.test_request_context(method='POST', json={
            "user_id": "28502f0c-300c-432a-b828-0ed68a771000",
            "createdAt": "2025-03-04T04:59:55.749113",
            "subjectId": "cb55e965-bc1a-41e8-9cb2-128a3e0214f1",
            "subjectType": "Workspace"
        }):
            # Ensure mock security functions are referenced
            _ = mock_security_functions

            with (
                mock.patch('maxgpt.services.database_model.UserFavoriteModel') as mock_UserFavorite_model,
                mock.patch('maxgpt.services.database.session') as mock_db_session
            ):
                # Configure mocks
                mock_UserFavorite_model.return_value = mock_user_favorite_post[0]
                mock_db_session.add = mock.MagicMock()
                mock_db_session.commit = mock.MagicMock()

                # Execute endpoint
                endpoint = UserFavoriteEndpoint()
                response = endpoint.post(user_id)
                
                # Verify response
                assert response.status_code == 200
                response_data = response.get_json()
                
                assert response_data["userId"] == user_id
                assert response_data["subjectId"] == 'cb55e965-bc1a-41e8-9cb2-128a3e0214f1'
                assert response_data["subjectType"] == FavoriteSubject.WORKSPACE.value

def test_post_user_setting(app, mock_security_functions):
    """Test to create a new user preference."""
    with app.app_context():
        # Setup request context with test data
        with app.test_request_context(method='POST', json={
            "userId":"1",
            "preferenceId":"setting_1",
            "value": "new_value"
        }):
            _ = mock_security_functions
           
            # Mock the current user
            with mock.patch('maxgpt.services.internal.session_context.SessionContext.get_current_user') as mock_get_user:
                # Setup mock user
                mock_user = mock.MagicMock()
                mock_user.get_id.return_value = "1"
                mock_get_user.return_value = mock_user
               
                # Mock the preference query
                with mock.patch('maxgpt.services.database_model.PreferenceModel.query') as mock_preference_query:
                    # Setup mock preference
                    mock_preference = mock.MagicMock()
                    mock_preference.id = "setting_1"
                    mock_preference.scope = PreferenceScope.USER
                    mock_preference_query.get.return_value = mock_preference
                   
                    # Mock database session
                    with mock.patch('maxgpt.services.database.session') as mock_db_session:
                        # Create and call endpoint
                        endpoint = UserSettingFactoryEndpoint()
                        response = endpoint.post("1")
                       
                        # Verify response
                        assert response.status_code == 200
                        response_data = response.get_json()
                        assert response_data["userId"] == "1"
                        assert response_data["preferenceId"] == "setting_1"
                        assert response_data["value"] == "new_value"
                       
                    
