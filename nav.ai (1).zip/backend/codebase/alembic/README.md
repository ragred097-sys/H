# 🛠️ Alembic Migration System

This project uses [**Alembic**](https://alembic.sqlalchemy.org/en/latest/) to manage database schema migrations. Alembic is a lightweight database migration tool for usage with the SQLAlchemy Database Toolkit for Python.

---

## 📦 Requirements

- Python 3.12 
- SQLAlchemy
- Alembic

Install via pip:

"pip install alembic" or
 run `pip install -r requirements.txt`

 ## Generating Migrations

 - Run `alembic revision --autogenerate -m "Migration Name"` - generates a new migration, later run:
 - `alembic upgrade head` - Upgrade to Latest Version (HEAD) as well as applies all the migration scripts
 - `alembic upgrade <revision_id> `-  Upgrade to a Specific Revision

 
 ## Downgrade Migration

 - Run`alembic downgrade -1` - Downgrade One Revision
 - Run`alembic downgrade <revision_id> `- Downgrade specific Revision

## Downgrade and Upgrade Between Specific Versions
* Step 1: List All Revisions
Use this command to list the full migration history and find the revision ID:

`alembic history --verbose`

* Step 2: Downgrade to a Specific Revision
Once you’ve identified the target revision (e.g., 20250715_def2), run:

`alembic downgrade 20250715_def2`
This will revert all migrations applied after that revision.

* Step 3: Upgrade Back to Latest (or Any Other Revision)
To apply all migrations from the downgraded state up to the latest:

`alembic upgrade head`
Or upgrade to a specific revision:

`alembic upgrade 20250731_abc1`







 


