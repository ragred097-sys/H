import abc
import asyncio
import enum

from .persistence import database, initialize_database
from .security import AbstractAuthenticator, AuthenticationProviderRegistry

__all__ = [
    'AbstractAuthenticator',
    'database',
    'initialize_database',
    'AuthenticationProviderRegistry',
    'Tag',
    'DefaultApplicationAccessRole',
    'ApplicationAccessRole'
]

from ..api import EntityType


class DefaultApplicationAccessRole(enum.Enum):
    MAXGPT_ADMINISTRATOR = "administrator"
    MAXGPT_DATA_ENGINEER = "data_engineer"
    MAXGPT_USER = "user"

class ApplicationAccessRole:
    @abc.abstractmethod
    def get_id(self):
        pass

    @abc.abstractmethod
    def get_name(self):
        pass

    @abc.abstractmethod
    def get_system(self):
        pass

    @abc.abstractmethod
    def get_description(self):
        pass

    def to_dict(self):
        return {
            '__type_name': EntityType.ACCESS_ROLE,
            'id': self.get_id(),
            'name': self.get_name(),
            'description': self.get_description(),
            'system': self.get_system(),
        }

class Tag:
    @abc.abstractmethod
    def get_id(self):
        pass

    @abc.abstractmethod
    def get_name(self):
        pass

    @abc.abstractmethod
    def get_description(self):
        pass

    def to_dict(self):
        return {
            '__type_name': EntityType.TAG,
            'id': self.get_id(),
            'name': self.get_name(),
            'description': self.get_description(),
        }

def ensure_event_loop():
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop