from typing import Set

from flask import request

from maxgpt.services import ApplicationAccessRole, DefaultApplicationAccessRole
from maxgpt.services.security import AuthenticatedUser


class SessionContext:
    @staticmethod
    def get_current_user() -> AuthenticatedUser:
        return request.current_user

    @staticmethod
    def set_current_user(user: AuthenticatedUser):
        request.current_user = user

    @staticmethod
    def get_effective_app_roles() -> Set[ApplicationAccessRole]:
        return request.effective_app_roles

    @staticmethod
    def set_effective_app_roles(roles: Set[ApplicationAccessRole]):
        request.effective_app_roles = roles

    @staticmethod
    def is_administrator() -> bool:
        return request.effective_app_roles and DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value in [r.id for r in request.effective_app_roles]

    @staticmethod
    def is_data_engineer() -> bool:
        return request.effective_app_roles and DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value in [r.id for r in request.effective_app_roles]
