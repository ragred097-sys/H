from maxgpt.api import EntityType
from maxgpt.services import Tag


class ShallowTag(Tag):
    def __init__(self, tag_id: str, tag_name: str):
        self._id = tag_id
        self._name = tag_name

    def get_id(self):
        return self._id

    def get_name(self):
        return self._name

    def get_description(self):
        return None

    def to_dict(self):
        return {
            '__type_name': EntityType.TAG,
            'id': self.get_id(),
            'name': self.get_name(),
        }


