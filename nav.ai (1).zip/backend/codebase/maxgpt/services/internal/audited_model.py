from sqlalchemy import func, text
from sqlalchemy.orm import Mapped, mapped_column, declared_attr

from maxgpt.services import database
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.security import ShallowUser


class AuditedModel(database.Model):
    __abstract__ = True

    created_at: Mapped[database.DateTime] = mapped_column(database.DateTime, default=func.now(), nullable=False)
    creator_id: Mapped[database.String] = mapped_column(database.String(36), database.ForeignKey('users.id'), default=lambda: SessionContext.get_current_user().get_id(), nullable=False)

    @declared_attr
    def creator(cls):
        return database.relationship("UserModel", foreign_keys=[cls.creator_id], lazy="joined")

    modified_at: Mapped[database.DateTime] = mapped_column(database.DateTime, onupdate=func.now(), nullable=True)
    modifier_id: Mapped[database.String] = mapped_column(database.String(36), database.ForeignKey('users.id'), onupdate=lambda: SessionContext.get_current_user().get_id(), nullable=True)

    @declared_attr
    def modifier(cls):
        return database.relationship("UserModel", foreign_keys=[cls.modifier_id], lazy="joined")
    
    deleted_at: Mapped[database.DateTime] = mapped_column(database.DateTime, default=None, nullable=True)
    deleted_by: Mapped[database.String] = mapped_column(database.String(36), database.ForeignKey('users.id'), nullable=True, default=None)

    @declared_attr
    def deleter(cls):
        return database.relationship("UserModel", foreign_keys=[cls.deleted_by], lazy="joined")


    def to_dict(self) -> dict:
        result = {
            'createdAt': self.created_at,
            'creator': ShallowUser.to_dict(self.creator)
        }

        if self.modified_at:
            result['modifiedAt'] = self.modified_at
        if self.modifier:
            result['modifier'] = ShallowUser.to_dict(self.modifier)
        if self.deleted_at:
            result['deletedAt'] = self.deleted_at
        if self.deleter:
            result['deleter'] = ShallowUser.to_dict(self.deleter)
        return result