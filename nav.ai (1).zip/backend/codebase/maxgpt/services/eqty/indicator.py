import logging
from typing import Tuple, Optional

import requests
from  requests.exceptions import JSONDecodeError

from maxgpt.services.eqty.util import is_eqty_enabled, EQTY_GOV_URL

if is_eqty_enabled():

    GOV_API = f"governanceService/api/v1/configurations"

    def evaluate_indicator(uuid: str, name: str, observations: list[dict]) -> Tuple[list[bool], object]:
        try:
            logging.debug(f"Evaluating indicator {name} on {uuid} with observations {observations}")

            # TODO once GS provides a breakdown of the evaluation, we can use that. In the meantime, we'll hack it
            #      by first going through each item and checking its compliance individually.
            url = f"{EQTY_GOV_URL}/{GOV_API}/{uuid}/events"

            def evaluate_observation(observation: dict) -> Optional[bool]:
                response = requests.post(url, json={ "payload": {name: [observation]} })
                response.raise_for_status()
                return response.json().get("complianceStatus") == "compliant"

            compliant = list(map(evaluate_observation, observations))

            # Now in order to get GS to work correctly, we need to send the observations as a single payload.
            response = requests.post(url, json={ "payload": {name: observations} })
            response.raise_for_status()
            evaluation = response.json()
            logging.debug(f"Indicator {name} evaluation: {evaluation}")
            # TODO once GS provides a breakdown of the evaluation, we can extract compliant here
            return compliant, evaluation
        except JSONDecodeError:
            logging.error(f"Governance Studio returned invalid JSON for indicator {name} on {uuid}")
            raise