import json
import logging
from typing import List, Union, Tuple
from types import SimpleNamespace
from maxgpt.services.database_model import (
    DataObjectModel, AssistantModel, IngestProcessModel,
    ModuleModel, SystemInstructionModel, DataSourceModel, 
    AssistantSampleQuestionModel, AgentWorkflowModel, AgentModel,
    ConversationModel, MessageModel, MessageRole, MessagePartType,
    MessagePartModel, MessageEventModel,
    MessageEventType
)
from maxgpt.modules import ModuleRegistry, Module
from maxgpt.services.eqty.util import is_eqty_enabled, make_serializable

if is_eqty_enabled():
    
    import eqty
    

    def _wrap_data_source(data_source: DataSourceModel, violation: bool = False) -> eqty.Dataset:
        return eqty.Dataset.from_object(
            obj=make_serializable(data_source),
            name=data_source.name,
            description=data_source.description,
            # The following is an EQTY hack to show an EU Data and AI Act violation on one data source
            meta_order="1" if violation else "0",
        )


    def build_data_source_lineage(ds: DataSourceModel, violation: bool = False) -> eqty.Dataset:
        """
        Create the lineage for a data source.

        Args:
            ds: The data source model
            violation: Whether to mark this data source as a violation

        Returns:
            EQTY dataset representing the data source lineage
        """
        def _query_data_source_files() -> List[DataObjectModel]:
            """Query all files associated with this data source."""
            ingested_files: List[DataObjectModel] = []
            for process in IngestProcessModel.query.filter(IngestProcessModel.data_source_id == ds.id).all():
                ingested_files.extend(DataObjectModel.query.filter(DataObjectModel.ingest_process_id == process.id).all())
            return ingested_files

        @eqty.compute(
            metadata={
                "name": "Ingest documents",
                "description": "Ingest the source documents into the vector database",
            }
        )
        def ingest_documents(documents: Union[List[eqty.Document], eqty.Dataset]) -> eqty.Dataset:
            return _wrap_data_source(ds, violation)

        data_source_files = _query_data_source_files()
        if data_source_files:
            documents = [
                eqty.Document.from_object(
                    obj=file.url,
                    name=file.name,
                    description=f"{file.file_name} ({file.mime_type}) on {file.file_system}",
                    meta_order="1" if violation and not file_index else "0",
                )
                for file_index, file in enumerate(data_source_files)
            ]
        else:
            # We don't really know much about the data at this point
            documents = eqty.Dataset.from_object(
                obj=ds.id,
                name="Data",
                meta_order="1" if violation else "0",
            )
        return ingest_documents(documents)


    def _wrap_assistant(assistant: AssistantModel) -> eqty.Model:
        return eqty.Model.from_object(
            obj=make_serializable(assistant),
            name=assistant.name,
            description=assistant.description,
        )


    def build_assistant_lineage(_assistant: AssistantModel) -> eqty.Model:
        """
        Create the lineage for an assistant.

        Args:
            _assistant: The assistant model

        Returns:
            EQTY model representing the assistant
        """
        # TODO tags, tag_relations, *_attachment_storage,

        data_sources = DataSourceModel.query.filter(
                DataSourceModel.id.in_((relation.data_source_id for relation in _assistant.data_sources))
            ).all()
        llms = ModuleModel.query.filter(
                ModuleModel.id.in_((relation.module_id for relation in _assistant.llms))
            ).all()
        system_instructions = SystemInstructionModel.query.filter(
                SystemInstructionModel.id.in_((relation.system_instruction_id for relation in _assistant.system_instructions))
            ).all()
        sample_questions = [
                sample_question.content for sample_question in AssistantSampleQuestionModel.query.filter(
                    AssistantSampleQuestionModel.id.in_((relation.module_id for relation in _assistant.llms))
                ).all()
            ]

        # 1. Model the document ingestion process into data sources
        data_source_assets: List[eqty.Dataset] = [
            build_data_source_lineage(ds, ds_index == 0) for ds_index, ds in enumerate(data_sources)
        ]

        # 2. Model the agent registration process
        configuration_asset = eqty.Document.from_object(
                obj={
                    'name': _assistant.name,
                    'description': _assistant.description,
                    'greeting_message': _assistant.greeting_message,
                    'image': _assistant.image,
                    'icon': _assistant.icon,
                },
                name="Configuration",
                description="Configuration parameters such as name, description, greeting message and icon."
            )

        model_assets = [
                eqty.Model.from_object(
                    obj=make_serializable(llm),
                    name=llm.name,
                    description=llm.description,
                )
                for llm in llms
            ]

        system_instruction_assets = [
                eqty.Document.from_object(
                    obj=make_serializable(system_instruction),
                    name=system_instruction.name,
                    description=system_instruction.description,
                )
                for system_instruction in system_instructions
            ]
        if _assistant.custom_system_instruction:
            system_instruction_assets.append(
                eqty.Document.from_object(
                    obj=_assistant.custom_system_instruction,
                    name="Custom system instruction",
                    description=_assistant.custom_system_instruction,
                )
            )

        sample_question_assets = eqty.Dataset.from_object(
            obj=sample_questions,
            name="Sample questions",
            description="\n".join(sample_questions),
        )

        @eqty.compute(
            metadata={
                "name": "Assemble agent",
                "description": "Assemble the agent from configuration, LLM, prompts and data.",
            }
        )
        def agent_registration(configuration, models, data_sources, system_instructions, sample_questions):
            return _wrap_assistant(_assistant)

        return agent_registration(
            configuration_asset,
            model_assets,
            data_source_assets,
            system_instruction_assets,
            sample_question_assets,
        )


    def _wrap_agent(agent: AgentModel) -> eqty.Model:
        return eqty.Model.from_object(
            obj=make_serializable(agent),
            name=agent.name,
            description=agent.description,
        )


    def build_agent_lineage(_agent: AgentModel) -> eqty.Model:
        """
        Create the lineage for an agent.

        Args:
            _agent: The agent model

        Returns:
            EQTY model representing the agent lineage
        """
        # TODO tags, tag_relations

        llm = _agent.llm
        system_instructions = SystemInstructionModel.query.filter(
                SystemInstructionModel.id.in_((relation.system_instruction_id for relation in _agent.system_instructions))
            ).all()

        # 2. Model the agent registration process
        configuration_asset = eqty.Document.from_object(
                obj={
                    'name': _agent.name,
                    'description': _agent.description,
                    'image': _agent.image,
                    'icon': _agent.icon,
                },
                name="Configuration",
                description="Configuration parameters such as name, description, greeting message and icon."
            )

        model_asset = eqty.Model.from_object(
                obj=make_serializable(llm),
                name=llm.name,
                description=llm.description,
            )

        system_instruction_assets = [
                eqty.Document.from_object(
                    obj=make_serializable(system_instruction),
                    name=system_instruction.name,
                    description=system_instruction.description,
                )
                for system_instruction in system_instructions
            ]

        if _agent.custom_system_instruction:
            system_instruction_assets.append(
                eqty.Document.from_object(
                    obj=_agent.custom_system_instruction,
                    name="Custom system instruction",
                    description=_agent.custom_system_instruction,
                )
            )

        @eqty.compute(
            metadata={
                "name": "Assemble agent",
                "description": "Assemble the agent from configuration, LLM, prompts and data.",
            }
        )
        def agent_registration(configuration, model, system_instructions):
            return _wrap_agent(_agent)

        return agent_registration(
            configuration_asset,
            model_asset,
            system_instruction_assets,
        )


    def build_agent_workflow_lineage(_agent_workflow: AgentWorkflowModel) -> eqty.Model:
        """
        Create the lineage for an agent workflow.

        Args:
            _agent_workflow: The agent workflow model

        Returns:
            EQTY model representing the agent workflow lineage
        """
        # TODO tag_relations, tags, first_receiver_{type,id}

        assistants = [
            build_assistant_lineage(AssistantModel.query.get(rel.assistant_id))
            for rel in _agent_workflow.assistant_relations
        ]
        agents = [
            build_agent_lineage(AgentModel.query.get(rel.agent_id))
            for rel in _agent_workflow.agent_relations
        ]
        data_sources = [
            build_data_source_lineage(DataSourceModel.query.get(rel.data_source_id))
            for rel in _agent_workflow.data_source_relations
        ]
        handoffs = eqty.Dataset.from_object(
            obj=[
                make_serializable(rel)
                for rel in _agent_workflow.handoff_relations
                if rel.to_id is not None and rel.to_type is not None
            ],
            name="Handoffs",
            description="The handoff configuration for the agentic workflow",
        )

        @eqty.compute(
            metadata={
                "name": "Assemble workflow",
                "description": "Assemble the workflow from the agents, assistants, data sources and handoffs.",
            }
        )
        def workflow_registration(assistants, agents, data_sources, handoffs):
            return eqty.Model.from_object(
                obj=make_serializable(_agent_workflow),
                name=_agent_workflow.name,
                description=_agent_workflow.description,
            )

        return workflow_registration(assistants, agents, data_sources, handoffs)


    def _last_message_in_role(conversation: ConversationModel, role: MessageRole) -> MessageModel:
        """ Retrieve the last message in a conversation with a given role. """
        return next((m for m in reversed(conversation.messages) if m.role == role))


    def _last_message_part_of_type(message: MessageModel, part_type: MessagePartType, default_value: str) -> MessagePartModel:
        """ Retrieve the last part of a message with a given type. """
        return next((p for p in message.parts if p.type == part_type), default_value)


    def _fetch_last_user_message(conversation: ConversationModel) -> Tuple[str, List[eqty.Asset]]:
        message: MessageModel = _last_message_in_role(conversation, MessageRole.USER)
        return (
            _last_message_part_of_type(message, MessagePartType.TEXT, "User query").content,
            [
                eqty.Document.from_object(
                    obj=make_serializable(p),
                    name=p.content,
                    description=p.content)
                if p.type==MessagePartType.TEXT else
                eqty.Media.from_object(
                    obj=make_serializable(p),
                    name=p.type.name.replace('_', '').title())
                for p in message.parts
            ]
        )


    def _wrap_conversational_context(conversation: ConversationModel, last_user_query: str, user_query_assets: List[eqty.Asset]) -> eqty.Dataset:
        """
        Build the chat history for a conversation.
        """
        @eqty.compute(
            metadata={
                "name": "Conversational context",
                "description": "Retrieve the conversational context for the query.",
            }
        )
        def retrieve_context(query: List[Union[eqty.Document, eqty.Media]]) -> eqty.Dataset:
            return eqty.Dataset.from_object(
                        obj=make_serializable(conversation.messages),
                        name="Conversational context",
                        description=f"The conversational context for '{last_user_query}'.")
        return retrieve_context(user_query_assets)


    def _wrap_llm(module_id: str) -> eqty.Model:
        """
        Retrieve the principal LLM for a conversation.
        """
        llm_module: Module = ModuleRegistry.get_module(module_id)
        return eqty.Model.from_object(
            obj=f"{llm_module.get_name()}-{llm_module.get_description()}-{llm_module.get_modified_at()}",
            name=llm_module.get_name(),
            description=llm_module.get_description()
        )


    def _wrap_data_sources(
            data_source_ids: List[str],
            assistant: AssistantModel
    ) -> List[eqty.Dataset]:
        """
        Wrap data sources in EQTY datasets.
        """
        @eqty.compute(
            metadata={
                "name": "Orchestrate resources",
                "description": "Retrieve the data sources for the query.",
            }
        )
        def data_orchestrator(
            data_source_assets: List[eqty.Dataset],
            assistant_asset: eqty.Model,
        ) -> List[eqty.Dataset]:
            return data_source_assets + [
                eqty.Dataset.from_object(
                    obj=make_serializable(ds),
                    name=ds.name,
                    description=ds.description)
                for ds in DataSourceModel.query.filter(
                        DataSourceModel.id.in_((relation.data_source_id for relation in assistant.data_sources))
                    ).all()
            ]

        if data_source_ids:
            return data_orchestrator(
                [
                    eqty.Dataset.from_object(
                        obj=make_serializable(ds),
                        name=ds.name,
                        description=ds.description)
                    for ds in DataSourceModel.query.filter(DataSourceModel.id.in_(data_source_ids)).all()
                ],
                eqty.Model.from_object(
                    obj=make_serializable(assistant),
                    name=assistant.name,
                    description=assistant.description
                ),
            )
        else:
            return []


    def _perform_rag(
        data_source_assets: List[eqty.Dataset],
        user_query_assets: List[eqty.Asset],
        last_user_query: str
    ) -> eqty.Dataset:
        @eqty.compute(
            metadata={
                "name": "Retrieve relevant data",
                "description": "Retrieve relevant data from the data sets to augment response generation.",
            }
        )
        def rag(data_sources: List[eqty.Dataset], query: List[eqty.Asset]) -> eqty.Dataset:
            return eqty.Dataset.from_object(
                obj=make_serializable(query),
                name=f"Relevant data for {last_user_query}",
                description="Data pulled from " + ', '.join(map(lambda ds: ds.name, data_sources))
            )
        return rag(data_source_assets, user_query_assets) if data_source_assets or user_query_assets else []


    def _generate_prompt(
        llm_asset: eqty.Model,
        contextual_data_assets: List[eqty.Dataset],
        user_query_assets: List[Union[eqty.Document, eqty.Media]],
        last_user_query: str
    ) -> eqty.Document:
        prompt_gen_metadata = {
                "name": "Generate prompt",
                "description": "Generate the final prompt for the model.",
            }
        if contextual_data_assets:
            @eqty.compute(metadata=prompt_gen_metadata)
            def prompt_gen(llm: eqty.Model, contextual_data: eqty.Dataset, query: List[eqty.Asset]):
                return eqty.Document.from_object(
                    obj=f"{llm.cid}{contextual_data.cid}{list(map(lambda a: a.cid, query))}",
                    name=last_user_query,
                    description=f"LLM Prompt for {last_user_query}",
                )
            return prompt_gen(llm_asset, contextual_data_assets, user_query_assets)
        else:  # kludgy but EQTY doesn't handle None values very well
            @eqty.compute(metadata=prompt_gen_metadata)
            def prompt_gen(llm: eqty.Model, query: List[eqty.Asset]):
                return eqty.Document.from_object(
                    obj=f"{llm.cid}{list(map(lambda a: a.cid, query))}",
                    name=last_user_query,
                    description=f"LLM Prompt for {last_user_query}",
                )
            return prompt_gen(llm_asset, user_query_assets)


    def _generate_response(
        llm_asset: eqty.Model,
        prompt_asset: eqty.Document,
        conversational_context_asset: eqty.Dataset,
        last_message_text: str
    ) -> eqty.Token:
        @eqty.compute(
            metadata={
                "name": "Generate response",
                "description": "Generate the final response from the model.",
            }
        )
        def response_gen(llm: eqty.Model, prompt: eqty.Document, conversational_context):
            return eqty.Token.from_object(
                obj=f"{prompt.cid}{conversational_context.cid}{last_message_text}",
                name="LLM Response",
                description=last_message_text,
            )

        return response_gen(llm_asset, prompt_asset, conversational_context_asset)


    def build_chat_lineage(conversation: ConversationModel) -> eqty.Token:
        """
        Create the lineage for a conversation.

        Args:
            _conversation: The conversation model

        Returns:
            EQTY token representing the conversation
        """
        assert conversation.assistant_id, "Conversation must have an assistant"
        assert not conversation.agent_workflow_id, "Conversation must not be agentic"
        assert len(conversation.llms) == 1, "Conversation must have exactly one LLM"

        # Replicating the process implemented in ChatProcess
        # 0. Fetch and build chat history
        last_user_query, user_query_assets = _fetch_last_user_message(conversation)
        conversational_context_asset: eqty.Dataset = _wrap_conversational_context(conversation, last_user_query, user_query_assets)

        # 1. Fetch LLM
        llm_asset: eqty.Model = _wrap_llm(conversation.llms[0].module_id)

        # 2. Collect all relevant data sources
        data_source_assets: List[eqty.Dataset] = _wrap_data_sources(
            [relation.data_source_id for relation in conversation.data_sources],
            conversation.assistant
        )

        # 3. Retrieve data using RAG
        contextual_data_assets: List[eqty.Dataset] = _perform_rag(data_source_assets, user_query_assets, last_user_query)

        # 4. Generate prompt
        prompt_asset: eqty.Document = _generate_prompt(llm_asset, contextual_data_assets, user_query_assets, last_user_query)

        # 5. Stream tokens
        last_message_text: str = _last_message_part_of_type(_last_message_in_role(conversation, MessageRole.ASSISTANT), MessagePartType.TEXT, "Response").content
        return _generate_response(llm_asset, prompt_asset, conversational_context_asset, last_message_text)


    def build_agentic_chat_lineage(conversation: ConversationModel) -> eqty.Token:
        """
        Create the lineage for an agentic conversation.

        Args:
            conversation: The conversation model

        Returns:
            EQTY token representing the conversation
        """
        assert not conversation.assistant_id, "Agentic conversation cannot have an assistant"
        assert conversation.agent_workflow_id, "Agentic conversation must have a workflow"
        assert len(conversation.llms) > 0, "Agentic conversation must have at least one LLM"

        # Replicating the process implemented in AgenticChatProcess
        # 0. Fetch and build chat history
        last_user_query, user_query_assets = _fetch_last_user_message(conversation)
        conversational_context_asset: eqty.Dataset = _wrap_conversational_context(conversation, last_user_query, user_query_assets)

        assistant_message: MessageModel = _last_message_in_role(conversation, MessageRole.ASSISTANT)
        # assistant_message_text = _last_message_part_of_type(assistant_message, MessagePartType.TEXT, "Assistant response")

        workflow: AgentWorkflowModel = conversation.agent_workflow

        data_sources = {
            rel.data_source_id: _wrap_data_source(DataSourceModel.query.get(rel.data_source_id))
            for rel in workflow.data_source_relations
        }
        assistants = {rel.assistant_id: AssistantModel.query.get(rel.assistant_id) for rel in workflow.assistant_relations}
        assistant_assets = {id: _wrap_assistant(assistant) for id, assistant in assistants.items()}
        agents = {rel.agent_id: AgentModel.query.get(rel.agent_id) for rel in workflow.agent_relations}
        agent_assets = {id: _wrap_agent(agent) for id, agent in agents.items()}

        def get_agent(agent_info: dict) -> Tuple[Union[AgentModel, AssistantModel], eqty.Model, List[eqty.Dataset]]:
            if agent_info["type"] == "assistant":
                assistant: AssistantModel = assistants[agent_info["id"]]
                data_source_ids = [relation.data_source_id for relation in assistant.data_sources]
                return assistant_assets[agent_info["id"]], _wrap_llm(assistant.llms[0].module_id), _wrap_data_sources(data_source_ids, assistant)
            else:
                agent: AgentModel = agents[agent_info["id"]]
                return agent_assets[agent_info["id"]], _wrap_llm(agent.llm.module_id), []

        def build_agent_invocation(event: object, next_event: object, input: eqty.Token) -> eqty.Token:
            agent_asset, llm_asset, data_source_assets = get_agent(event.meta["agent"])
            all_query_assets = user_query_assets + ([input] if input else [])
            contextual_data_assets: List[eqty.Dataset] = _perform_rag(list(data_sources.values()) + data_source_assets, all_query_assets, last_user_query)
            prompt_asset: eqty.Document = _generate_prompt(agent_asset, contextual_data_assets, user_query_assets, last_user_query)
            last_message_text: str = next_event.content["output"] or f"handoff-{next_event.sequence}"
            return _generate_response(llm_asset, prompt_asset, conversational_context_asset, last_message_text)

        events = [
            SimpleNamespace(
                type=event.type.value,
                content=json.loads(event.content),
                meta=json.loads(event.meta) if event.meta else None,
                sequence=event.sequence
            )
            for event in MessageEventModel.query.filter_by(message_id=assistant_message.id)
                .order_by(MessageEventModel.sequence)
                .all()
            if event.type.value != MessageEventType.CHUNK.value
        ]

        result = None
        for event, next_event in zip(events, events[1:]):
            if event.type == MessageEventType.AGENT_INPUT.value and next_event.type == MessageEventType.AGENT_OUTPUT.value:
                logging.debug(f"Agent invocation {event.meta["agent"]} event in conversation {conversation.id}")
                result = build_agent_invocation(event, next_event, result)
            elif event.type == MessageEventType.AGENT_TOOL_CALL.value and next_event.type == MessageEventType.AGENT_TOOL_CALL_RESULT.value:
                logging.debug(f"Tool call {event.content["toolName"]} event in conversation {conversation.id}")
            elif event.type == MessageEventType.CONTEXT_NODE.value:
                logging.debug(f"Context node event {event.type} in conversation {conversation.id}")
            elif next_event.type == MessageEventType.ERROR.value:
                logging.warn(f"Error event {next_event.type} in conversation {conversation.id}")
            elif event.type not in [MessageEventType.AGENT_OUTPUT.value, MessageEventType.AGENT_TOOL_CALL_RESULT.value]:
                logging.warn(f"Unsupported event sequence when rendering lineage for conversation {conversation.id}: {event.type} -> {next_event.type}")

    
