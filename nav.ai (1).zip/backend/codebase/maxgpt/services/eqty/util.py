import atexit
import importlib.metadata as im
import json
import logging
import os
from datetime import datetime, timezone
from enum import Enum
import tempfile
from typing import Optional,Dict, Any
from maxgpt.services import database

EQTY_PROJECT = os.getenv('EQTY_PROJECT')
EQTY_GOV_URL = os.getenv('EQTY_GOV_URL')
try:
    EQTY_VERSION = im.version("eqty")
    if EQTY_PROJECT and EQTY_GOV_URL:
        logging.info(f"EQTY SDK v{EQTY_VERSION}, project {EQTY_PROJECT}")
    else:
        logging.warning(f"EQTY SDK v{EQTY_VERSION} detected but EQTY_PROJECT or EQTY_GOV_URL not set")
        EQTY_VERSION = None
except im.PackageNotFoundError:
    if EQTY_PROJECT:
        logging.warning(f"EQTY_PROJECT set to {EQTY_PROJECT} but can't find EQTY SDK")
    EQTY_VERSION = None
    

def get_eqty_version() -> Optional[str]:
    """Return the version of the EQTY SDK, or None if EQTY is not installed."""
    return EQTY_VERSION

def is_eqty_enabled() -> bool:
    """Return whether EQTY support is enabled."""
    return bool(EQTY_VERSION)


if is_eqty_enabled():
    
    import eqty
    
    EQTY_ORG_ID = os.getenv('EQTY_ORG_ID')      # accenture
    
    def init_eqty(custom_dir: Optional[str] = None) -> eqty.Config:
        """
        Initialise the EQTY framework at application start.
        
        Args:
            custom_dir: Optional custom directory for EQTY configuration
            
        Returns:
            EQTY configuration object
        """
        config = eqty.init(project=EQTY_PROJECT, custom_dir=custom_dir)
        if EQTY_GOV_URL and os.getenv('EQTY_API_KEY'):
            config.add_environment(
                EQTY_GOV_URL,
                name=EQTY_PROJECT,
                org_id=EQTY_ORG_ID)
            return eqty.login()
        else:
            return config.create_random_did()

    # Create temporary directory for EQTY and register cleanup
    temp = tempfile.TemporaryDirectory()
    atexit.register(temp.cleanup)
    init_eqty(temp.name)
    

    def generate_manifest_and_purge() -> Dict[str, Any]:
        """
        Generate the current lineage manifest and purge the EQTY state.
        
        Returns:
            Dictionary containing the manifest data
        """
        with tempfile.TemporaryDirectory() as temp_dir:
            manifest_path = os.path.join(temp_dir, "manifest.json")
            try:
                eqty.generate_manifest(manifest_path)
            finally: 
                # we want to clear the store even if manifest generation bugs out, else it will keep on bugging
                eqty.purge_integrity_store()
            
            with open(manifest_path, "r") as manifest_file:
                return json.loads(manifest_file.read())


def make_serializable(obj: Any) -> Any:
    """
    Recursively traverses an object graph and converts all datetime
    objects into ISO 8601 UTC strings so that JSON serialization works.

    Args:
        obj: The object to make serializable

    Returns:
        A serializable version of the object
    """
    if isinstance(obj, database.Model):
        # Get a dict representation
        return make_serializable(obj.to_dict())
    if isinstance(obj, eqty.Asset):
        # Get the encapsulated value
        return make_serializable(obj.value)
    elif isinstance(obj, datetime):
        # Convert datetime to UTC and serialize to ISO 8601 string
        return obj.astimezone(timezone.utc).isoformat()
    elif isinstance(obj, Enum):
        # Convert enumerated types into their string representation
        return obj.name
    elif isinstance(obj, dict):
        # Recursively process dictionaries
        return {key: make_serializable(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        # Recursively process lists
        return [make_serializable(item) for item in obj]
    elif isinstance(obj, tuple):
        # Recursively process tuples
        return tuple(make_serializable(item) for item in obj)
    elif isinstance(obj, set):
        # Recursively process sets (convert back to set after processing)
        return {make_serializable(item) for item in obj}
    else:
        # Return the object unchanged
        return obj
