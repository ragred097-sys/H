from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import List

from sqlalchemy import Enum, event, func, JSON, DateTime
from sqlalchemy.orm import Mapped, Session, declared_attr, mapped_column, Mapper

from maxgpt.api import EntityType
from maxgpt.core import DataType
from maxgpt.services import database, Tag
from maxgpt.services.internal import ShallowTag
from maxgpt.services.internal.audited_model import AuditedModel
from maxgpt.services.eqty.util import is_eqty_enabled
from maxgpt.services.data_model.authorization import ApplicationAccessRoleModel
from maxgpt.services.data_model.user import UserModel

class ModuleCapabilityType(enum.Enum):
    LLM = "LLM"
    EMBEDDING_MODEL = "EMBEDDING_MODEL"
    VECTOR_STORE = "VECTOR_STORE"
    FILE_STORAGE = "FILE_STORAGE"
    FUNCTION_TOOL = "FUNCTION_TOOL"


class MessageRole(enum.Enum):
    SYSTEM = "SYSTEM"
    USER = "USER"
    ASSISTANT = "ASSISTANT"


class FileStorageFileSystem(enum.Enum):
    OS = "OS"
    S3 = "S3"
    AZURE = "AZURE"
    NVIDIA_VSS = "NVIDIA_VSS"
    NONE = "NONE"


class MessagePartType(enum.Enum):
    TEXT = "TEXT"
    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    AUDIO = "AUDIO"
    DOCUMENT = "DOCUMENT"
    ATTACHMENT_REFERENCE = "ATTACHMENT_REFERENCE"


class MessageEventType(enum.Enum):
    CHUNK = "chunk"
    CONTEXT_NODE = "context_node"
    AGENT_INPUT = "agent_input"
    AGENT_OUTPUT = "agent_output"
    AGENT_TOOL_CALL = "agent_tool_call"
    AGENT_TOOL_CALL_RESULT = "agent_tool_call_result"
    ERROR = "error"


class AssistantModuleRelationModel(database.Model):
    __tablename__ = 'assistant_module_relations'

    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                        nullable=False)
    module_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True,
                                     nullable=False)


class AssistantTagRelationModel(database.Model):
    __tablename__ = 'assistant_tag_relations'

    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                        nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class AgentTagRelationModel(database.Model):
    __tablename__ = 'agent_tag_relations'

    agent_id: str = database.Column(database.String(36), database.ForeignKey('agents.id'), primary_key=True,
                                        nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)

class AgentWorkflowTagRelationModel(database.Model):
    __tablename__ = 'agent_workflow_tag_relations'

    agent_workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'), primary_key=True,
                                        nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class AgentWorkflowAgentRelationModel(database.Model):
    __tablename__ = 'agent_workflow_agent_relations'

    agent_workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'), primary_key=True,
                                        nullable=False)
    agent_id: str = database.Column(database.String(36), database.ForeignKey('agents.id'), primary_key=True,
                                  nullable=False)


class AgentWorkflowAssistantRelationModel(database.Model):
    __tablename__ = 'agent_workflow_assistant_relations'

    agent_workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'), primary_key=True,
                                        nullable=False)
    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                  nullable=False)


class ConversationTagRelationModel(database.Model):
    __tablename__ = 'conversation_tag_relations'

    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'),
                                           primary_key=True, nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class AssistantDataSourceRelationModel(database.Model):
    __tablename__ = 'assistant_data_source_relations'

    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                        nullable=False)
    data_source_id: str = database.Column(database.String(36), database.ForeignKey('data_sources.id'), primary_key=True,
                                          nullable=False)


class AssistantSystemInstructionRelationModel(database.Model):
    __tablename__ = 'assistant_system_instruction_relations'

    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                        nullable=False)
    system_instruction_id: str = database.Column(database.String(36), database.ForeignKey('system_instructions.id'), primary_key=True,
                                          nullable=False)


class AgentSystemInstructionRelationModel(database.Model):
    __tablename__ = 'agent_system_instruction_relations'

    agent_id: str = database.Column(database.String(36), database.ForeignKey('agents.id'), primary_key=True,
                                        nullable=False)
    system_instruction_id: str = database.Column(database.String(36), database.ForeignKey('system_instructions.id'), primary_key=True,
                                          nullable=False)

class AgentModuleRelation(database.Model):
    __tablename__ = 'agent_module_relations'

    agent_id: str = database.Column(database.String(36), database.ForeignKey('agents.id'), primary_key=True,
                                        nullable=False)
    module_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True,
                                          nullable=False)


class AgentWorkflowAgentType(enum.Enum):
    AGENT = EntityType.AGENT.value
    ASSISTANT = EntityType.ASSISTANT.value
    DATA_SOURCE = EntityType.DATA_SOURCE.value

    @staticmethod
    def from_value(value: str) -> 'AgentWorkflowAgentType':
        try:
            return AgentWorkflowAgentType(value)
        except KeyError:
            raise ValueError(f"No JsonType found for value '{value}'.")

    @staticmethod
    def by_subject_class(subject_class: type):
        if subject_class is AgentModel:
            return AgentWorkflowAgentType.AGENT
        elif subject_class is AssistantModel:
            return AgentWorkflowAgentType.ASSISTANT
        elif subject_class is DataSourceModel:
            return AgentWorkflowAgentType.DATA_SOURCE
        else:
            raise ValueError(f"Unknown agent workflow agent type for class '{subject_class.__name__}'")

    @staticmethod
    def by_subject_instance(subject: any):
        return AgentWorkflowAgentType.by_subject_class(subject.__class__)


class AgentWorkflowRootAgentType(enum.Enum):
    AGENT = EntityType.AGENT.value
    ASSISTANT = EntityType.ASSISTANT.value

    @staticmethod
    def from_value(value: str) -> 'AgentWorkflowRootAgentType':
        try:
            return AgentWorkflowRootAgentType(value)
        except KeyError:
            raise ValueError(f"No JsonType found for value '{value}'.")

    @staticmethod
    def by_subject_class(subject_class: type):
        if subject_class is AgentModel:
            return AgentWorkflowAgentType.AGENT
        elif subject_class is AssistantModel:
            return AgentWorkflowAgentType.ASSISTANT
        else:
            raise ValueError(f"Unknown agent workflow root type for class '{subject_class.__name__}'")

    @staticmethod
    def by_subject_instance(subject: any):
        return AgentWorkflowAgentType.by_subject_class(subject.__class__)


class AgentWorkflowHandoffRelationModel(database.Model):
    __tablename__ = 'agent_workflow_handoff_relations'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)

    agent_workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'),
                                        nullable=False)

    from_type: AgentWorkflowAgentType = database.Column(Enum(AgentWorkflowAgentType), nullable=False)
    from_id: str = database.Column(database.String(36), nullable=False)

    to_type: AgentWorkflowAgentType = database.Column(Enum(AgentWorkflowAgentType), nullable=True)
    to_id: str = database.Column(database.String(36), nullable=True)

    def to_dict(self):
        return {
            'from': {
                'type': self.from_type.value,
                'id': self.from_id
             },
            'to': {
                'type': self.to_type.value,
                'id': self.to_id
             }
        }


class WidgetTagRelationModel(database.Model):
    __tablename__ = 'widget_tag_relations'

    widget_id: str = database.Column(database.String(36), database.ForeignKey('widgets.id'), primary_key=True,
                                     nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class ConversationModuleRelationModel(database.Model):
    __tablename__ = 'conversation_module_relations'

    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'),
                                           primary_key=True, nullable=False)
    module_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True,
                                     nullable=False)


class ConversationDataSourceRelationModel(database.Model):
    __tablename__ = 'conversation_data_source_relations'

    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'),
                                           primary_key=True, nullable=False)
    data_source_id: str = database.Column(database.String(36), database.ForeignKey('data_sources.id'), primary_key=True,
                                          nullable=False)

class ConversationAttachmentRelationModel(database.Model):
    __tablename__ = 'conversation_attachment_relations'

    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'),
                                           primary_key=True, nullable=False)
    attachment_id: str = database.Column(database.String(36), database.ForeignKey('attachments.id'),
                                          primary_key=True,
                                          nullable=False)

class SystemInstructionAttachmentRelationModel(database.Model):
    __tablename__ = 'system_instruction_attachment_relations'

    system_instruction_id: str = database.Column(database.String(36), database.ForeignKey('system_instructions.id'),
                                           primary_key=True, nullable=False)
    attachment_id: str = database.Column(database.String(36), database.ForeignKey('attachments.id'),
                                          primary_key=True,
                                          nullable=False)


class AgentWorkflowDataSourceRelationModel(database.Model):
    __tablename__ = 'agent_workflow_data_source_relations'

    agent_workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'),
                                           primary_key=True, nullable=False)
    data_source_id: str = database.Column(database.String(36), database.ForeignKey('data_sources.id'), primary_key=True,
                                          nullable=False)


class DataSourceTagRelationModel(database.Model):
    __tablename__ = 'data_source_tag_relations'

    data_source_id: str = database.Column(database.String(36), database.ForeignKey('data_sources.id'), primary_key=True,
                                          nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class SystemInstructionTagRelationModel(database.Model):
    __tablename__ = 'system_instruction_tag_relations'

    system_instruction_id: str = database.Column(database.String(36), database.ForeignKey('system_instructions.id'),
                                                 primary_key=True, nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class ModuleTagRelationModel(database.Model):
    __tablename__ = 'module_tag_relations'

    module_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True,
                                     nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)


class WorkspaceTagRelationModel(database.Model):
    __tablename__ = 'workspace_tag_relations'

    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)
    
class TagCategoryTagRelationModel(database.Model):
    __tablename__ = 'tag_category_tag_relations'

    tag_category_id: str = database.Column(database.String(36), database.ForeignKey('tag_categories.id'), primary_key=True,
                                        nullable=False)
    tag_id: str = database.Column(database.String(36), database.ForeignKey('tags.id'), primary_key=True,
                                  nullable=False)
    


class WorkspaceAssistantRelationModel(database.Model):
    __tablename__ = 'workspace_assistant_relations'

    workspace: Mapped[WorkspaceModel] = database.relationship("WorkspaceModel")
    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)

    assistant: Mapped[AssistantModel] = database.relationship("AssistantModel")
    assistant_id = database.Column(database.String(36), database.ForeignKey('assistants.id'), primary_key=True,
                                   nullable=False)
    def to_dict(self):
        return {
            "workspaceId": self.workspace_id,
            "assistantId": self.assistant_id,
        }


class WorkspaceAgentRelationModel(database.Model):
    __tablename__ = 'workspace_agent_relations'

    workspace: Mapped[WorkspaceModel] = database.relationship("WorkspaceModel")
    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)

    agent: Mapped[AgentModel] = database.relationship("AgentModel")
    agent_id = database.Column(database.String(36), database.ForeignKey('agents.id'), primary_key=True,
                                   nullable=False)

    def to_dict(self):
        return {
            "workspaceId": self.workspace_id,
            "agentId": self.agent_id,
        }


class WorkspaceAgentWorkflowRelationModel(database.Model):
    __tablename__ = 'workspace_agent_workflow_relations'

    workspace: Mapped[WorkspaceModel] = database.relationship("WorkspaceModel")
    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)

    agent_workflow: Mapped[AgentWorkflowModel] = database.relationship("AgentWorkflowModel")
    agent_workflow_id = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'), primary_key=True,
                                   nullable=False)

    def to_dict(self):
        return {
            "workspace_id": self.workspace_id,
            "agentWorkflowId": self.agent_workflow_id,
        }


class UserApplicationAccessRoleRelationModel(AuditedModel):
    __tablename__ = 'user_application_access_role_relations'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)

    @declared_attr
    def user(cls):
        return database.relationship("UserModel", foreign_keys=[cls.user_id], lazy="joined")

    user_id = database.Column(database.String(36), database.ForeignKey('users.id'),
                              nullable=False)

    application_access_role = database.relationship("ApplicationAccessRoleModel")
    application_access_role_id: str = database.Column(database.String(36),
                                                      database.ForeignKey('application_access_roles.id'),
                                                      nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            'id': self.id,
            'user': self.user.to_dict(),
            'applicationAccessRole': self.application_access_role.to_dict()
        })
        return result


class ExternalRoleApplicationAccessRoleMappingModel(AuditedModel):
    __tablename__ = 'external_role_application_access_role_mapping'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)

    external_role_name = database.Column(database.String(100), nullable=False)

    application_access_role = database.relationship("ApplicationAccessRoleModel")
    application_access_role_id: str = database.Column(database.String(36),
                                                      database.ForeignKey('application_access_roles.id'),
                                                      nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            'id': self.id,
            'externalRoleName': self.external_role_name,
            'applicationAccessRole': self.application_access_role.to_dict()
        })
        return result


class WorkspaceWidgetRelationModel(database.Model):
    __tablename__ = 'workspace_widget_relations'

    workspace: Mapped[WorkspaceModel] = database.relationship("WorkspaceModel")
    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)

    widget: Mapped[WidgetModel] = database.relationship("WidgetModel")
    widget_id = database.Column(database.String(36), database.ForeignKey('widgets.id'), primary_key=True,
                                nullable=False)


class WorkspaceSystemInstructionRelationModel(database.Model):
    __tablename__ = 'workspace_system_instruction_relations'

    workspace: Mapped[WorkspaceModel] = database.relationship("WorkspaceModel")
    workspace_id: str = database.Column(database.String(36), database.ForeignKey('workspaces.id'), primary_key=True,
                                        nullable=False)

    system_instruction: Mapped[SystemInstructionModel] = database.relationship("SystemInstructionModel")
    system_instruction_id = database.Column(database.String(36), database.ForeignKey('system_instructions.id'),
                                            primary_key=True,
                                            nullable=False)

    def to_dict(self):
        return {
            "workspaceId": self.workspace_id,
            "systemInstructionId": self.system_instruction_id,
        }


class TagModel(AuditedModel, Tag):
    __tablename__ = 'tags'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    name = database.Column(database.String(100), nullable=False)
    description = database.Column(database.String(500), nullable=True)

    def get_id(self):
        return self.id

    def get_name(self):
        return self.name

    def get_description(self):
        return self.description

    def to_dict(self):
        tag_dict = Tag.to_dict(self)
        audited_dict = AuditedModel.to_dict(self)

        return {**tag_dict, **audited_dict}


class PreferenceScope(enum.Enum):
    USER = "user"
    APPLICATION = "application"
    GENERAL = "general"

    @staticmethod
    def from_value(value: str) -> 'PreferenceScope':
        try:
            return PreferenceScope(value)
        except KeyError:
            raise ValueError(f"No PreferenceScope found for value '{value}'.")


class PreferenceModel(database.Model):
    __tablename__ = 'preferences'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False, unique=True)
    label: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(500), nullable=False)

    scope: PreferenceScope = database.Column(Enum(PreferenceScope), nullable=False)
    type: DataType = database.Column(Enum(DataType), nullable=False)

    def to_dict(self):
        return {
            '__type_name': EntityType.PREFERENCE,
            'id': self.id,
            'name': self.name,
            'label': self.label,
            'description': self.description,
            'scope': self.scope,
            'type': self.type,
        }


class UserSettingModel(database.Model):
    __tablename__ = 'user_settings'

    user = database.relationship("UserModel")
    user_id: str = database.Column(database.String(36), database.ForeignKey('users.id'), primary_key=True,
                                   nullable=False)

    preference = database.relationship("PreferenceModel")
    preference_id: str = database.Column(database.String(36), database.ForeignKey('preferences.id'), primary_key=True,
                                         nullable=False)

    value = database.Column(database.String(500), nullable=False)

    def to_dict(self):
        return {
            'userId': self.user_id,
            'preferenceId': self.preference_id,
            'value': self.value,
        }


class ApplicationSettingModel(AuditedModel):
    __tablename__ = 'application_settings'
    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    preference = database.relationship("PreferenceModel")
    preference_id: str = database.Column(database.String(36), database.ForeignKey('preferences.id'), primary_key=True, nullable=False)

    value = database.Column(database.String(), nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            'id': self.id,
            'preferenceId': self.preference_id,
            'value': self.value,
        })
        return result


class AssistantSampleQuestionModel(database.Model):
    __tablename__ = 'assistant_sample_questions'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    content = database.Column(database.String(350), nullable=False)

    assistant = database.relationship("AssistantModel")
    assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), nullable=False)

    def to_dict(self):
        return {
            'content': self.content,

        }


class AssistantModel(AuditedModel):
    __tablename__ = 'assistants'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(500), nullable=False)

    tag_relations: Mapped[List[AssistantTagRelationModel]] = database.relationship(AssistantTagRelationModel,
                                                                                   cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=AssistantTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    custom_system_instruction = database.Column(database.String())
    greeting_message: str = database.Column(database.String(500), nullable=True)

    llms: Mapped[List[AssistantModuleRelationModel]] = database.relationship(AssistantModuleRelationModel,
                                                                             cascade='all')
    data_sources: Mapped[List[AssistantDataSourceRelationModel]] = database.relationship(
        AssistantDataSourceRelationModel, cascade='all')

    system_instructions: Mapped[List[AssistantSystemInstructionRelationModel]] = database.relationship(
        AssistantSystemInstructionRelationModel, cascade='all')

    @declared_attr
    def image_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.image_attachment_storage_id])

    image_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def audio_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.audio_attachment_storage_id])

    audio_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def video_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.video_attachment_storage_id])

    video_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def text_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.text_attachment_storage_id])

    text_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                      nullable=True)

    sample_questions: Mapped[List[AssistantSampleQuestionModel]] = database.relationship(AssistantSampleQuestionModel,
                                                                                         cascade='all')

    image: str = database.Column(database.String(), nullable=True)
    icon: str = database.Column(database.String(), nullable=True)

    def set_attachment_storage(self, media_type: DocumentType, file_storage_module_id: str):
        storage_map = {
            DocumentType.AUDIO: "audio_attachment_storage_id",
            DocumentType.IMAGE: "image_attachment_storage_id",
            DocumentType.VIDEO: "video_attachment_storage_id",
            DocumentType.TEXT: "text_attachment_storage_id",
        }
        setattr(self, storage_map[media_type], file_storage_module_id or None)

    def to_dict(self):
        attachmentStorages = []
        if self.video_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.VIDEO,
                'fileStorageId': self.video_attachment_storage_id,
            })
        if self.audio_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.AUDIO,
                'fileStorageId': self.audio_attachment_storage_id,
            })
        if self.image_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.IMAGE,
                'fileStorageId': self.image_attachment_storage_id,
            })
        if self.text_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.TEXT,
                'fileStorageId': self.text_attachment_storage_id,
            })

        result = super().to_dict()
        result.update({
            '__type_name': EntityType.ASSISTANT,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'customSystemInstruction': self.custom_system_instruction,
            'systemInstructionIds': [relation.system_instruction_id for relation in                    #Added join condition to filter out soft deleted system_instructions from response 
                                   database.session.query(AssistantSystemInstructionRelationModel).join(
                                        SystemInstructionModel,
                                        AssistantSystemInstructionRelationModel.system_instruction_id == SystemInstructionModel.id
                                    ).filter(
                                        AssistantSystemInstructionRelationModel.assistant_id == self.id,
                                        SystemInstructionModel.deleted_at.is_(None)
                                    ).all()] if self.system_instructions else [],
            'greetingMessage': self.greeting_message,
            'llmIds': [relation.module_id for relation in self.llms],
            'dataSourceIds': [relation.data_source_id for relation in                                   #Added join condition to filter out soft deleted data_sources from response
                            database.session.query(AssistantDataSourceRelationModel).join(
                                DataSourceModel,
                                AssistantDataSourceRelationModel.data_source_id == DataSourceModel.id
                            ).filter(
                                AssistantDataSourceRelationModel.assistant_id == self.id,
                                DataSourceModel.deleted_at.is_(None)
                            ).all()] if self.data_sources else [],
            'sampleQuestions': [question.content for question in self.sample_questions],
            'attachmentStorages': attachmentStorages,
            'icon': self.icon,
            'image': self.image
        })
        return result
    

class AgentModel(AuditedModel):
    __tablename__ = 'agents'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(500), nullable=False)

    tag_relations: Mapped[List[AgentTagRelationModel]] = database.relationship(AgentTagRelationModel,
                                                                                   cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=AgentTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    system_instructions: Mapped[List[AgentSystemInstructionRelationModel]] = database.relationship(
        AgentSystemInstructionRelationModel, cascade='all')
    custom_system_instruction = database.Column(database.String())

    function_tools: Mapped[List[AgentModuleRelation]] = database.relationship(AgentModuleRelation, cascade='all')

    image: str = database.Column(database.String(), nullable=True)
    icon: str = database.Column(database.String(), nullable=True)

    @declared_attr
    def llm(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.llm_id])

    llm_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.AGENT,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'systemInstructionIds': [relation.system_instruction_id for relation in
                              self.system_instructions] if self.system_instructions else [],
            'customSystemInstruction': self.custom_system_instruction,
            'llmId': self.llm_id,
            'functionToolIds': [relation.module_id for relation in self.function_tools] if self.function_tools else [],
            'image': self.image,
            'icon': self.icon
        })
        return result


class AgentWorkflowModel(AuditedModel):
    __tablename__ = 'agent_workflows'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(500), nullable=True)

    tag_relations: Mapped[List[AgentWorkflowTagRelationModel]] = database.relationship(
        AgentWorkflowTagRelationModel,
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=AgentWorkflowTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    first_receiver_type: AgentWorkflowRootAgentType = database.Column(Enum(AgentWorkflowRootAgentType), nullable=False)
    first_receiver_id = database.Column(database.String(36), nullable=False)

    agent_relations: Mapped[List[AgentWorkflowAgentRelationModel]] = database.relationship(
        AgentWorkflowAgentRelationModel,
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    assistant_relations: Mapped[List[AgentWorkflowAssistantRelationModel]] = database.relationship(
        AgentWorkflowAssistantRelationModel,
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    data_source_relations: Mapped[List[AgentWorkflowDataSourceRelationModel]] = database.relationship(
        AgentWorkflowDataSourceRelationModel,
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    handoff_relations: Mapped[List[AgentWorkflowHandoffRelationModel]] = database.relationship(
        AgentWorkflowHandoffRelationModel,
        cascade="all, delete-orphan",
        passive_deletes=True
    )

    image: str = database.Column(database.String(), nullable=True)
    icon: str = database.Column(database.String(), nullable=True)

    @declared_attr
    def image_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.image_attachment_storage_id])

    image_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def audio_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.audio_attachment_storage_id])

    audio_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def video_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.video_attachment_storage_id])

    video_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                       nullable=True)

    @declared_attr
    def text_attachment_storage(cls):
        return database.relationship("ModuleModel", foreign_keys=[cls.text_attachment_storage_id])

    text_attachment_storage_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'),
                                                      nullable=True)

    def set_attachment_storage(self, media_type: DocumentType, file_storage_module_id: str):
        storage_map = {
            DocumentType.AUDIO: "audio_attachment_storage_id",
            DocumentType.IMAGE: "image_attachment_storage_id",
            DocumentType.VIDEO: "video_attachment_storage_id",
            DocumentType.TEXT: "text_attachment_storage_id",
        }
        setattr(self, storage_map[media_type], file_storage_module_id or None)

    def to_dict(self):
        attachmentStorages = []
        if self.video_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.VIDEO,
                'fileStorageId': self.video_attachment_storage_id,
            })
        if self.audio_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.AUDIO,
                'fileStorageId': self.audio_attachment_storage_id,
            })
        if self.image_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.IMAGE,
                'fileStorageId': self.image_attachment_storage_id,
            })
        if self.text_attachment_storage_id:
            attachmentStorages.append({
                'type': DocumentType.TEXT,
                'fileStorageId': self.text_attachment_storage_id,
            })

        result = super().to_dict()

        _agents = []
        for rel in self.data_source_relations:
            # Check if data source present in agent-workflow is not soft deleted
            data_source = database.session.query(DataSourceModel).filter(
                DataSourceModel.id == rel.data_source_id,
                DataSourceModel.deleted_at.is_(None)
            ).first()
            
            if data_source:
                if not self.handoff_relations:
                    can_hand_off_to = None
                else:
                    can_hand_off_to = None
                    for h_rel in self.handoff_relations:
                        if h_rel.from_id == rel.data_source_id and h_rel.from_type == AgentWorkflowAgentType.DATA_SOURCE:
                            if h_rel.to_id is None or h_rel.to_type is None:
                                can_hand_off_to = []
                                break
                            else:
                                # Check if the handoff target agent/assistant is not soft-deleted
                                target_exists = False
                                if h_rel.to_type == AgentWorkflowAgentType.AGENT:
                                    target_exists = database.session.query(AgentModel).filter(
                                        AgentModel.id == h_rel.to_id,
                                        AgentModel.deleted_at.is_(None)
                                    ).first() is not None
                                elif h_rel.to_type == AgentWorkflowAgentType.ASSISTANT:
                                    target_exists = database.session.query(AssistantModel).filter(
                                        AssistantModel.id == h_rel.to_id,
                                        AssistantModel.deleted_at.is_(None)
                                    ).first() is not None
                                
                                if target_exists:
                                    if not can_hand_off_to:
                                        can_hand_off_to = []
                                    can_hand_off_to.append({'id': h_rel.to_id, 'type': h_rel.to_type.value})
                _agents.append({'id': rel.data_source_id, 'type': AgentWorkflowAgentType.DATA_SOURCE.value, 'canHandOffTo': can_hand_off_to})
        for rel in self.assistant_relations:
            #Check if assistant present in agent-workflow is not soft deleted
            assistant = database.session.query(AssistantModel).filter(
                AssistantModel.id == rel.assistant_id,
                AssistantModel.deleted_at.is_(None)
            ).first()
            
            if assistant:
                if not self.handoff_relations:
                    can_hand_off_to = None
                else:
                    can_hand_off_to = None
                    for h_rel in self.handoff_relations:
                        if h_rel.from_id == rel.assistant_id and h_rel.from_type == AgentWorkflowAgentType.ASSISTANT:
                            if h_rel.to_id is None or h_rel.to_type is None:
                                can_hand_off_to = []
                                break
                            else:
                                #Check if the handoff_target agent/assistant is not soft-deleted
                                target_exists = False
                                if h_rel.to_type == AgentWorkflowAgentType.AGENT:
                                    target_exists = database.session.query(AgentModel).filter(
                                        AgentModel.id == h_rel.to_id,
                                        AgentModel.deleted_at.is_(None)
                                    ).first() is not None
                                elif h_rel.to_type == AgentWorkflowAgentType.ASSISTANT:
                                    target_exists = database.session.query(AssistantModel).filter(
                                        AssistantModel.id == h_rel.to_id,
                                        AssistantModel.deleted_at.is_(None)
                                    ).first() is not None
                                
                                if target_exists:
                                    if not can_hand_off_to:
                                        can_hand_off_to = []
                                    can_hand_off_to.append({'id': h_rel.to_id, 'type': h_rel.to_type.value})
                _agents.append({'id': rel.assistant_id, 'type': AgentWorkflowAgentType.ASSISTANT.value, 'canHandOffTo': can_hand_off_to})

        for rel in self.agent_relations:
            # Check if agent present in agent-workflow is not soft deleted
            agent = database.session.query(AgentModel).filter(
                AgentModel.id == rel.agent_id,
                AgentModel.deleted_at.is_(None)
            ).first()
            
            if agent:
                if not self.handoff_relations:
                    can_hand_off_to = None
                else:
                    can_hand_off_to = None
                    for h_rel in self.handoff_relations:
                        if h_rel.from_id == rel.agent_id and h_rel.from_type == AgentWorkflowAgentType.AGENT:
                            if h_rel.to_id is None or h_rel.to_type is None:
                                can_hand_off_to = []
                                break
                            else:
                                # Check if the handoff agent/assistant is not soft-deleted
                                target_exists = False
                                if h_rel.to_type == AgentWorkflowAgentType.AGENT:
                                    target_exists = database.session.query(AgentModel).filter(
                                        AgentModel.id == h_rel.to_id,
                                        AgentModel.deleted_at.is_(None)
                                    ).first() is not None
                                elif h_rel.to_type == AgentWorkflowAgentType.ASSISTANT:
                                    target_exists = database.session.query(AssistantModel).filter(
                                        AssistantModel.id == h_rel.to_id,
                                        AssistantModel.deleted_at.is_(None)
                                    ).first() is not None
                                
                                if target_exists:
                                    if not can_hand_off_to:
                                        can_hand_off_to = []
                                    can_hand_off_to.append({'id': h_rel.to_id, 'type': h_rel.to_type.value})
                _agents.append({'id': rel.agent_id, 'type': AgentWorkflowAgentType.AGENT.value, 'canHandOffTo': can_hand_off_to})

        result.update({ 
            '__type_name': EntityType.AGENT_WORKFLOW,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'agents': _agents,
            'rootAgent': {'id': self.first_receiver_id, 'type': self.first_receiver_type.value} if self.first_receiver_id and self.first_receiver_type else None,
            'image': self.image,
            'icon': self.icon,
            'attachmentStorages': attachmentStorages
        })
        return result


class WidgetModel(AuditedModel):
    __tablename__ = 'widgets'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(500), nullable=False)

    tag_relations: Mapped[List[WidgetTagRelationModel]] = database.relationship(WidgetTagRelationModel,
                                                                                cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=WidgetTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    image: str = database.Column(database.String(), nullable=True)
    icon: str = database.Column(database.String(), nullable=True)

    url: str = database.Column(database.String(2048), nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.WIDGET,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'url': self.url,
            'image': self.image,
            'icon': self.icon
        })
        return result


class DataSourceModel(AuditedModel):
    __tablename__ = 'data_sources'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    name = database.Column(database.String(100), nullable=False)
    description = database.Column(database.String(500), nullable=True)
    filter_tag = database.Column(database.String(100), nullable=True)

    embedding_model_id = database.Column(database.String(36), database.ForeignKey('modules.id'), nullable=False)
    vector_store_id = database.Column(database.String(36), database.ForeignKey('modules.id'), nullable=False)
    file_storage_id = database.Column(database.String(36), database.ForeignKey('modules.id'), nullable=True)

    tag_relations: Mapped[List[DataSourceTagRelationModel]] = database.relationship(DataSourceTagRelationModel,
                                                                                    cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=DataSourceTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    def to_dict(self) -> dict:
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.DATA_SOURCE,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'filterTag': self.filter_tag,
            'embeddingModelId': self.embedding_model_id,
            'vectorStoreId': self.vector_store_id,
            'fileStorageId': self.file_storage_id,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
        })
        return result


class SystemInstructionModel(AuditedModel):
    __tablename__ = 'system_instructions'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    name = database.Column(database.String(100), nullable=False)
    description = database.Column(database.String(500), nullable=True)
    message = database.Column(database.String(), nullable=False)

    tag_relations: Mapped[List[SystemInstructionTagRelationModel]] = database.relationship(
        SystemInstructionTagRelationModel,
        cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=SystemInstructionTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    attachments: Mapped[List[SystemInstructionAttachmentRelationModel]] = database.relationship(
        SystemInstructionAttachmentRelationModel, cascade='all')

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.SYSTEM_INSTRUCTION,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'message': self.message,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
        })
        return result


class ModuleParameterModel(AuditedModel):
    __tablename__ = 'module_parameters'

    name = database.Column(database.String(100), nullable=False, primary_key=True)
    value = database.Column(database.String(4000), nullable=True)
    module = database.relationship("ModuleModel")
    module_id: str = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True,
                                     nullable=False)
    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.MODULE_PARAMETER,
            'name': self.name,
            'value': self.value,
            'module_id': self.module_id
        })
        return result



class ModuleModel(AuditedModel):
    __tablename__ = 'modules'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                         nullable=False)
    name = database.Column(database.String(100), nullable=False)
    description = database.Column(database.String(500), nullable=True)
    spec_id = database.Column(database.String(36), nullable=False)
    parameters: Mapped[List[ModuleParameterModel]] = database.relationship("ModuleParameterModel", back_populates="module", cascade="all, delete-orphan")
    capabilities: Mapped[List[ModuleCapabilityModel]] = database.relationship(
        "ModuleCapabilityModel",
        secondary="module_capabilities_relations",
        backref="modules"
    )

    tag_relations: Mapped[List[ModuleTagRelationModel]] = database.relationship(ModuleTagRelationModel,
                                                                                cascade='all', lazy='select')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=ModuleTagRelationModel.__tablename__,
                                                         viewonly=True, lazy='joined'
                                                         )
    supported_inputs = database.Column(JSON, nullable=True)

    def set_supported_inputs(self, types: List[DocumentType]):
        self.supported_inputs = [type_.value for type_ in types]

    def get_supported_inputs(self) -> List[DocumentType]:
        if self.supported_inputs:
            return [DocumentType(type_) for type_ in self.supported_inputs]
        return []

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.MODULE,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'specId': self.spec_id,
            'parameters': [_mp.to_dict() for _mp in self.parameters],
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'supportedInputs': self.get_supported_inputs()
        })
        return result

    @classmethod
    def from_dict(cls, module_dict: dict) -> ModuleModel:
        persistent_module = ModuleModel(id=module_dict["id"], name=module_dict["name"],
                                        description=module_dict["description"],
                                        spec_id=module_dict["specId"])


        for _parameter in module_dict["parameters"]:
            persisted_parameter = ModuleParameterModel(name=_parameter["name"],
                                             value=_parameter["value"])
            persistent_module.parameters.append(persisted_parameter)

        for _tag in module_dict["tags"]:
            persistent_module.tag_relations.append(ModuleTagRelationModel(module_id=module_dict["id"], tag_id=_tag["id"]))

        if "supportedInputs" in module_dict:
            persistent_module.set_supported_inputs([DocumentType(v) for v in module_dict["supportedInputs"]])

        return persistent_module


class ConversationModel(AuditedModel):
    __tablename__ = 'conversations'

    id: Mapped[str] = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()),
                                      unique=True,
                                      nullable=False)
    name: Mapped[str] = database.Column(database.String(80), nullable=True)
    messages: Mapped[List[MessageModel]] = database.relationship("MessageModel", back_populates="conversation",
                                                                 order_by="MessageModel.timestamp",
                                                                 cascade="all, delete-orphan")

    system_instruction_id: Mapped[str] = database.Column(database.String(36),
                                                         database.ForeignKey('system_instructions.id'), nullable=True)
    llms: Mapped[List[ConversationModuleRelationModel]] = database.relationship(ConversationModuleRelationModel,
                                                                                cascade='all')
    data_sources: Mapped[List[ConversationDataSourceRelationModel]] = database.relationship(
        ConversationDataSourceRelationModel, cascade='all')

    tag_relations: Mapped[List[ConversationTagRelationModel]] = database.relationship(ConversationTagRelationModel,
                                                                                      cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=ConversationTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    attachments: Mapped[List[ConversationAttachmentRelationModel]] = database.relationship(
        ConversationAttachmentRelationModel, cascade='all')

    assistant_id: Mapped[str] = database.Column(database.String(36), database.ForeignKey('assistants.id'),
                                                nullable=True)
    assistant: Mapped[AssistantModel] = database.relationship("AssistantModel", foreign_keys=[assistant_id])

    agent_workflow_id: Mapped[str] = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'),
                                                nullable=True)
    agent_workflow: Mapped[AgentWorkflowModel] = database.relationship("AgentWorkflowModel", foreign_keys=[agent_workflow_id])

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.CONVERSATION,
            'id': self.id,
            'name': self.name,
            'llmIds': [relation.module_id for relation in self.llms],
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'dataSourceIds': [relation.data_source_id for relation in
                            database.session.query(ConversationDataSourceRelationModel).join(
                                DataSourceModel,
                                ConversationDataSourceRelationModel.data_source_id == DataSourceModel.id
                            ).filter(
                                ConversationDataSourceRelationModel.conversation_id == self.id,
                                DataSourceModel.deleted_at.is_(None)
                            ).all()] if self.data_sources else [],  
            'assistantId': self.assistant_id,
            'agentWorkflowId': self.agent_workflow_id
        })
        return result


class MessageModel(database.Model):
    __tablename__ = 'messages'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    role = database.Column(Enum(MessageRole), nullable=False)
    conversation = database.relationship("ConversationModel", back_populates="messages")
    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'))
    parts: Mapped[List[MessagePartModel]] = database.relationship("MessagePartModel", back_populates="message",
                                                                  order_by="MessagePartModel.sequence",
                                                                  cascade="all, delete-orphan")

    timestamp: Mapped[datetime] = database.Column(database.DateTime, nullable=False, default=func.now())

    def to_dict(self):
        return {
            '__type_name': EntityType.MESSAGE,
            'id': self.id,
            'role': self.role,
            'conversationId': self.conversation_id,
            'timestamp': self.timestamp,
            'parts': [part.to_dict() for part in self.parts]
        }


class MessagePartModel(database.Model):
    __tablename__ = 'message_parts'

    sequence: int = database.Column(database.Integer, primary_key=True, default=0)
    message = database.relationship("MessageModel", back_populates="parts")
    message_id: str = database.Column(database.String(36), database.ForeignKey('messages.id'), primary_key=True)

    type = database.Column(Enum(MessagePartType), nullable=False)
    content: str = database.Column(database.String(), nullable=False)

    def to_dict(self):
        return {
            '__type_name': EntityType.MESSAGE_PART,
            'type': self.type,
            'content': self.content,
            'sequence': self.sequence,
        }


class MessageEventModel(database.Model):
    __tablename__ = 'message_events'

    sequence: int = database.Column(database.Integer, primary_key=True, default=0)
    message_id: str = database.Column(database.String(36), database.ForeignKey('messages.id'), primary_key=True)

    type = database.Column(Enum(MessageEventType), nullable=False)
    content: str = database.Column(database.String(), nullable=False)
    meta: str = database.Column(database.String(), nullable=True)

    def to_dict(self):
        return {
            '__type_name': EntityType.MESSAGE_EVENT,
            'type': self.type,
            'content': self.content,
            'meta': self.meta,
            'sequence': self.sequence,
        }


class MessageProcessModel(database.Model):
    __tablename__ = 'message_processes'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    message = database.relationship("MessageModel")
    message_id: str = database.Column(database.String(36), database.ForeignKey('messages.id'))

    timestamp: datetime = database.Column(database.DateTime, nullable=False, default=func.now())


class MessageProcessEventModel(database.Model):
    __tablename__ = 'message_process_events'

    sequence: int = database.Column(database.Integer, primary_key=True)
    timestamp: datetime = database.Column(database.DateTime, nullable=False)
    span_id: str = database.Column(database.String(200), nullable=False)
    type: str = database.Column(database.String(30), nullable=False)
    event_id: str = database.Column(database.String(36), nullable=False)
    message_process = database.relationship("MessageProcessModel")
    message_process_id: str = database.Column(database.String(36), database.ForeignKey('message_processes.id'))
    content: str = database.Column(database.Text(), nullable=True)


class IngestProcessModel(database.Model):
    __tablename__ = 'ingest_processes'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)

    data_source = database.relationship("DataSourceModel")
    data_source_id: str = database.Column(database.String(36),
                                          database.ForeignKey('data_sources.id', ondelete="SET NULL"), nullable=True)

    timestamp: datetime = database.Column(database.DateTime, nullable=False, default=func.now())

    def to_dict(self):
        return {
            'id': self.id,
            'dataSourceId': self.data_source_id,
            'timestamp': self.timestamp
        }


class DataObjectModel(AuditedModel):
    __tablename__ = 'data_objects'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(200), nullable=False)
    file_name: str = database.Column(database.String(200), nullable=False)
    file_system = database.Column(Enum(FileStorageFileSystem), nullable=False)
    url: str = database.Column(database.String(), nullable=True)
    mime_type: str = database.Column(database.String(80), nullable=True)
    ingest_process = database.relationship("IngestProcessModel")
    ingest_process_id: str = database.Column(database.String(36), database.ForeignKey('ingest_processes.id'))

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.DATA_OBJECT,
            'id': self.id,
            'name': self.name,
            'fileName': self.file_name,
            'fileSystem': self.file_system,
            'url': self.url,
            'ingestProcessId': self.ingest_process_id,
            'mimeType': self.mime_type
        })
        return result


class DocumentType(enum.Enum):
    IMAGE = "IMAGE"
    VIDEO = "VIDEO"
    AUDIO = "AUDIO"
    TEXT = "TEXT"


class AttachmentModel(AuditedModel):
    __tablename__ = 'attachments'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)

    name: str = database.Column(database.String(200), nullable=False)
    description: str = database.Column(database.String(), nullable=True)
    type: Mapped[DocumentType] = database.Column(Enum(DocumentType), nullable=False)
    mime_type: str = database.Column(database.String(80), nullable=True)
    size: int = database.Column(database.Integer, nullable=False)
    length: int = database.Column(database.Integer, nullable=True)

    thumbnail: str = database.Column(database.String(), nullable=True)

    file_storage_id = database.Column(database.String(36), database.ForeignKey('modules.id'), nullable=False)
    object_reference: str = database.Column(database.String(255), nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.ATTACHMENT,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'type': self.type,
            'mimeType': self.mime_type,
            'size': self.size,
            'length': self.length,
            'thumbnail': self.thumbnail,
            'fileStorageId': self.file_storage_id,
            'objectReference': self.object_reference,
        })
        return result


class IdentifiableModel(database.Model):
    __abstract__ = True
    id: Mapped[str] = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()),
                                      unique=True,
                                      nullable=False)


class WorkspaceModel(AuditedModel, IdentifiableModel):
    __tablename__ = 'workspaces'

    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(), nullable=False)

    tag_relations: Mapped[List[WorkspaceTagRelationModel]] = database.relationship(WorkspaceTagRelationModel,
                                                                                   cascade='all')
    tags: Mapped[List[TagModel]] = database.relationship(TagModel,
                                                         secondary=WorkspaceTagRelationModel.__tablename__,
                                                         viewonly=True
                                                         )

    image: str = database.Column(database.String(), nullable=True)
    icon: str = database.Column(database.String(), nullable=True)

    filtered_on_tags: bool = database.Column(database.Boolean, nullable=False, default=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.WORKSPACE,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': [ShallowTag.to_dict(tag) for tag in self.tags],
            'icon': self.icon,
            'image': self.image,
            'filteredOnTags': self.filtered_on_tags,
        })
        return result
    
class TagCategoryModel(AuditedModel, IdentifiableModel):
    __tablename__ = 'tag_categories'

    name: str = database.Column(database.String(100), nullable=False)
    description: str = database.Column(database.String(), nullable=False)
    icon: str = database.Column(database.String(), nullable=True)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.TAG_CATEGORY,
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'icon': self.icon,
            
        })
        return result
    
    


class FavoriteSubject(enum.Enum):
    MODULE = EntityType.MODULE.value
    DATA_SOURCE = EntityType.DATA_SOURCE.value
    ASSISTANT = EntityType.ASSISTANT.value
    WIDGET = EntityType.WIDGET.value
    WORKSPACE = EntityType.WORKSPACE.value
    SYSTEM_INSTRUCTION = EntityType.SYSTEM_INSTRUCTION.value
    AGENT = EntityType.AGENT.value
    AGENT_WORKFLOW = EntityType.AGENT_WORKFLOW.value

    @staticmethod
    def from_value(value: str) -> 'FavoriteSubject':
        try:
            return FavoriteSubject(value)
        except KeyError:
            raise ValueError(f"No JsonType found for value '{value}'.")


class AccessPermissionSubject(enum.Enum):
    MODULE = EntityType.MODULE.value
    DATA_SOURCE = EntityType.DATA_SOURCE.value
    ASSISTANT = EntityType.ASSISTANT.value
    WIDGET = EntityType.WIDGET.value
    WORKSPACE = EntityType.WORKSPACE.value
    SYSTEM_INSTRUCTION = EntityType.SYSTEM_INSTRUCTION.value
    AGENT = EntityType.AGENT.value
    AGENT_WORKFLOW = EntityType.AGENT_WORKFLOW.value

    @staticmethod
    def by_subject_class(subject_class: type):
        if subject_class is ModuleModel:
            return AccessPermissionSubject.MODULE
        elif subject_class is DataSourceModel:
            return AccessPermissionSubject.DATA_SOURCE
        elif subject_class is AssistantModel:
            return AccessPermissionSubject.ASSISTANT
        elif subject_class is WidgetModel:
            return AccessPermissionSubject.WIDGET
        elif subject_class is WorkspaceModel:
            return AccessPermissionSubject.WORKSPACE
        elif subject_class is SystemInstructionModel:
            return AccessPermissionSubject.SYSTEM_INSTRUCTION
        elif subject_class is AgentModel:
            return AccessPermissionSubject.AGENT
        elif subject_class is AgentWorkflowModel:
            return AccessPermissionSubject.AGENT_WORKFLOW
        else:
            raise ValueError(f"Unknown access permission subject type for class '{subject_class.__name__}'")

    @staticmethod
    def by_subject_instance(subject: any):
        return AccessPermissionSubject.by_subject_class(subject.__class__)


class PermissionType(enum.Enum):
    READ = 'READ'
    WRITE = 'WRITE'
    FORBIDDEN = 'FORBIDDEN'

    @staticmethod
    def from_value(value: str) -> 'PermissionType':
        try:
            return PermissionType(value)
        except KeyError:
            raise ValueError(f"No PermissionType found for value '{value}'.")

    @staticmethod
    def rank(access_level: PermissionType):
        if access_level == PermissionType.FORBIDDEN:
            return 0
        elif access_level == PermissionType.READ:
            return 1
        elif access_level == PermissionType.WRITE:
            return 2


class AccessPermissionAssigneeType(enum.Enum):
    USER = EntityType.USER.value
    ACCESS_ROLE = EntityType.ACCESS_ROLE.value

    @staticmethod
    def from_value(value: str) -> 'AccessPermissionAssigneeType':
        try:
            return AccessPermissionAssigneeType(value)
        except KeyError:
            raise ValueError(f"No JsonType found for value '{value}'.")


class UserFavoriteModel(database.Model):
    __tablename__ = 'user_favorites'
    user_id: str = database.Column(database.String(36), database.ForeignKey('users.id'), primary_key=True,
                                   nullable=False)
    subject_type = database.Column(Enum(FavoriteSubject), primary_key=True, nullable=False)
    subject_id: str = database.Column(database.String(36), primary_key=True, nullable=False)

    created_at: Mapped[database.DateTime] = mapped_column(database.DateTime, default=func.now(), nullable=False)

    def to_dict(self):
        return {
            'userId': self.user_id,
            'subjectType': self.subject_type,
            'subjectId': self.subject_id,
            'createdAt': self.created_at,
        }


class AccessPermissionModel(AuditedModel):
    __tablename__ = 'access_permissions'

    subject_type: AccessPermissionSubject = database.Column(Enum(AccessPermissionSubject), nullable=False)
    subject_id: str = database.Column(database.String(36), primary_key=True, nullable=False)
    assignee_type: AccessPermissionAssigneeType = database.Column(Enum(AccessPermissionAssigneeType), nullable=False,
                                                                  primary_key=True)
    assignee_id: Mapped[str] = database.Column(database.String(36), primary_key=True, nullable=False)

    access_level = database.Column(Enum(PermissionType), nullable=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            'subjectId': self.subject_id,
            'subjectType': self.subject_type,
            'accessLevel': self.access_level,
            'assigneeId': self.assignee_id,
            'assigneeType': self.assignee_type,
        })
        # result.update({
        #     'subject': {
        #         '__type_name': self.subject_type,
        #         'id': self.subject_id,
        #     },
        #     'assignee': {
        #         '__type_name': self.assignee_type,
        #         'id': self.assignee_id,
        #     },
        #     'accessLevel': self.access_level,
        # })
        return result

class SharedConversationModel(AuditedModel):
    __tablename__ = 'shared_conversations'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id', ondelete='CASCADE'),
                                          nullable=False)
    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.SHARED_CONVERSATION,
            'id': self.id,
            'conversationId': self.conversation_id
        })
        return result
    

class RatingSubject(enum.Enum):
    MODULE = EntityType.MODULE.value
    DATA_SOURCE = EntityType.DATA_SOURCE.value
    ASSISTANT = EntityType.ASSISTANT.value
    WIDGET = EntityType.WIDGET.value
    WORKSPACE = EntityType.WORKSPACE.value


class UserRatingModel(database.Model):
    __tablename__ = 'user_ratings'
    __table_args__ = (
        database.CheckConstraint('value BETWEEN 1 AND 5', name='check_value_range'),
    )

    user_id: str = database.Column(database.String(36), database.ForeignKey('users.id'), primary_key=True,
                                   nullable=False)

    subject_type = database.Column(Enum(FavoriteSubject), primary_key=True, nullable=False)
    subject_id: str = database.Column(database.String(36), primary_key=True, nullable=False)

    # value from 1 to 5
    value: int = database.Column(database.SmallInteger, nullable=False)

    created_at: Mapped[database.DateTime] = mapped_column(database.DateTime, default=func.now(), nullable=False)

    def to_dict(self):
        return {
            'userId': self.user_id,
            'subjectType': self.subject_type,
            'subjectId': self.subject_id,
            'value': self.value,
            'createdAt': self.created_at,
        }


# Ensuring that we do not insert names longer than 80 characters when generating a name for a conversation
@event.listens_for(ConversationModel, 'before_insert')
def before_insert_conversation(mapper: Mapper, connection, target):
    for column in mapper.columns:
        if column.name == 'name':
            value = getattr(target, column.name)
            if value and isinstance(value, str) and len(value) > 80:
                setattr(target, column.name, value[:80])


@event.listens_for(ConversationModel, 'before_delete')
def before_delete_conversation(mapper, connection, instance: ConversationModel):
    # Delete links from assistant to conversation first
    # Delete links from conversion to module first
    # Delete links from conversion to data sources first
    session = Session.object_session(instance)

    session.query(MessageModel).filter_by(conversation_id=instance.id).delete(synchronize_session=False)

    to_be_deleted_attachments = session.query(ConversationAttachmentRelationModel.attachment_id).filter_by(conversation_id=instance.id).all()
    session.query(ConversationAttachmentRelationModel).filter_by(conversation_id=instance.id).delete(synchronize_session=False)
    session.query(AttachmentModel).filter(AttachmentModel.id.in_(to_be_deleted_attachments)).delete(synchronize_session=False)

    # Step 3: Delete conversation-related records
    session.query(ConversationModuleRelationModel).filter_by(conversation_id=instance.id).delete(
        synchronize_session=False)
    session.query(ConversationTagRelationModel).filter_by(conversation_id=instance.id).delete(synchronize_session=False)
    session.query(ConversationDataSourceRelationModel).filter_by(conversation_id=instance.id).delete(
        synchronize_session=False)
    session.query(SharedConversationModel).filter_by(conversation_id=instance.id).delete(synchronize_session=False)

@event.listens_for(MessageModel, 'before_delete')
def before_delete_message(mapper, connection, instance: MessageModel):
    session = Session.object_session(instance)

    session.query(MessageProcessModel).filter_by(message_id=instance.id).delete(synchronize_session=False)
    session.query(MessagePartModel).filter_by(message_id=instance.id).delete(synchronize_session=False)
    session.query(MessageEventModel).filter_by(message_id=instance.id).delete(synchronize_session=False)


@event.listens_for(AssistantModel, 'before_delete')
def before_delete_assistant(mapper, connection, instance: AssistantModel):
    session = Session.object_session(instance)
    # TODO: Should we delete conversations or leave them orphaned? They could still work.
    session.query(AssistantModuleRelationModel).filter_by(assistant_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceAssistantRelationModel).filter_by(assistant_id=instance.id).delete(synchronize_session=False)
    session.query(AssistantDataSourceRelationModel).filter_by(assistant_id=instance.id).delete(
        synchronize_session=False)
    session.query(AssistantTagRelationModel).filter_by(assistant_id=instance.id).delete(synchronize_session=False)
    session.query(AssistantSystemInstructionRelationModel).filter_by(assistant_id=instance.id).delete(
        synchronize_session=False)


@event.listens_for(AgentModel, 'before_delete')
def before_delete_agent(mapper, connection, instance: AgentModel):
    session = Session.object_session(instance)
    session.query(AgentModuleRelation).filter_by(agent_id=instance.id).delete(synchronize_session=False)
    session.query(AgentTagRelationModel).filter_by(agent_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceAgentRelationModel).filter_by(agent_id=instance.id).delete(synchronize_session=False)
    session.query(AgentWorkflowAgentRelationModel).filter_by(agent_id=instance.id).delete(synchronize_session=False)


@event.listens_for(WidgetModel, 'before_delete')
def before_delete_widget(mapper, connection, instance: WidgetModel):
    session = Session.object_session(instance)
    session.query(WorkspaceWidgetRelationModel).filter_by(widget_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceSystemInstructionRelationModel).filter_by(widget_id=instance.id).delete(
        synchronize_session=False)
    session.query(WidgetTagRelationModel).filter_by(widget_id=instance.id).delete(synchronize_session=False)


@event.listens_for(DataSourceModel, 'before_delete')
def before_delete_data_source(mapper, connection, instance: DataSourceModel):
    session = Session.object_session(instance)
    session.query(AssistantDataSourceRelationModel).filter_by(data_source_id=instance.id).delete(
        synchronize_session=False)
    session.query(DataSourceTagRelationModel).filter_by(data_source_id=instance.id).delete(synchronize_session=False)


@event.listens_for(ModuleModel, 'before_delete')
def before_delete_data_source(mapper, connection, instance: ModuleModel):
    session = Session.object_session(instance)
    session.query(ModuleParameterModel).filter_by(module_id=instance.id).delete(
        synchronize_session=False)
    session.query(ModuleTagRelationModel).filter_by(module_id=instance.id).delete(
        synchronize_session=False)


@event.listens_for(WorkspaceModel, 'before_delete')
def before_delete_workspace(mapper, connection, instance: WorkspaceModel):
    # Delete links from assistant to workspaces first
    session = Session.object_session(instance)
    session.query(WorkspaceAssistantRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceTagRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceWidgetRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceSystemInstructionRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceAgentRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceAgentWorkflowRelationModel).filter_by(workspace_id=instance.id).delete(synchronize_session=False)


@event.listens_for(AgentWorkflowModel, 'before_delete')
def before_delete_agent_workflow(mapper, connection, instance: AgentWorkflowModel):
    session = Session.object_session(instance)
    session.query(AgentWorkflowHandoffRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)
    session.query(AgentWorkflowAssistantRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)
    session.query(AgentWorkflowDataSourceRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)
    session.query(AgentWorkflowAgentRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)
    session.query(AgentWorkflowTagRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)
    session.query(WorkspaceAgentWorkflowRelationModel).filter_by(agent_workflow_id=instance.id).delete(synchronize_session=False)


@event.listens_for(SystemInstructionModel, 'before_delete')
def before_delete_system_instruction(mapper, connection, instance: SystemInstructionModel):
    session = Session.object_session(instance)
    session.query(SystemInstructionTagRelationModel).filter_by(system_instruction_id=instance.id).delete(
        synchronize_session=False)
    session.query(AssistantSystemInstructionRelationModel).filter_by(system_instruction_id=instance.id).delete(
        synchronize_session=False)


@event.listens_for(AttachmentModel, 'before_delete')
def before_delete_attachment(mapper, connection, instance: AttachmentModel): 
    session = Session.object_session(instance) 
    session.query(ConversationAttachmentRelationModel).filter_by(attachment_id=instance.id).delete(synchronize_session=False)
    session.query(SystemInstructionAttachmentRelationModel).filter_by(attachment_id=instance.id).delete(synchronize_session=False)
    
@event.listens_for(TagCategoryModel, 'before_delete')
def before_delete_tag_category_model(instance: TagCategoryModel):
    session = Session.object_session(instance)
    session.query(TagCategoryTagRelationModel).filter_by(tag_category_id=instance.id).delete(synchronize_session=False)
    

class HiddenEntitySubject(enum.Enum):
    DATA_SOURCE = EntityType.DATA_SOURCE.value
    ASSISTANT = EntityType.ASSISTANT.value
    WIDGET = EntityType.WIDGET.value
    WORKSPACE = EntityType.WORKSPACE.value
    SYSTEM_INSTRUCTION = EntityType.SYSTEM_INSTRUCTION.value
    AGENT = EntityType.AGENT.value
    AGENT_WORKFLOW = EntityType.AGENT_WORKFLOW.value
    

    @staticmethod
    def from_value(value: str) -> 'HiddenEntitySubject':
        try:
            return HiddenEntitySubject(value)
        except KeyError:
            raise ValueError(f"No HiddenEntitySubject found for value '{value}'.")


class UserHiddenEntityModel(database.Model):
    __tablename__ = 'user_hidden_entities'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    user_id: str = database.Column(database.String(36), database.ForeignKey('users.id'), nullable=False)
    subject_type = database.Column(Enum(HiddenEntitySubject), nullable=False)
    subject_id: str = database.Column(database.String(36), nullable=False)
    created_at: datetime = database.Column(database.DateTime, default=func.now(), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'userId': self.user_id,
            'subjectType': self.subject_type.value,
            'subjectId': self.subject_id,
            'createdAt': self.created_at
        }
    
    
if is_eqty_enabled():

    @event.listens_for(AssistantModel, 'before_delete')
    def before_delete_agent(mapper, connection, instance: AssistantModel):
        session = Session.object_session(instance)
        session.query(AssistantGovernanceModel).filter_by(assistant_id=instance.id).delete(synchronize_session=False)

    @event.listens_for(AgentModel, 'before_delete')
    def before_delete_agent(mapper, connection, instance: AssistantModel):
        session = Session.object_session(instance)
        session.query(AssistantGovernanceModel).filter_by(agent_id=instance.id).delete(synchronize_session=False)

    @event.listens_for(AgentWorkflowModel, 'before_delete')
    def before_delete_agent_workflow(mapper, connection, instance: AgentWorkflowModel):
        session = Session.object_session(instance)
        session.query(AssistantGovernanceModel).filter_by(workflow_id=instance.id).delete(synchronize_session=False)

    class AssistantGovernanceModel(AuditedModel):
        __tablename__ = 'eqty_assistant_governance'
        
        id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                                  nullable=False)
        assistant_id: str = database.Column(database.String(36), database.ForeignKey('assistants.id'), unique=True, nullable=True)
        agent_id: str = database.Column(database.String(36), database.ForeignKey('agents.id'), unique=True, nullable=True)
        workflow_id: str = database.Column(database.String(36), database.ForeignKey('agent_workflows.id'), unique=True, nullable=True)

        configuration: str = database.Column(database.String(), nullable=True)
        status: str = database.Column(database.String(), nullable=True)

        def to_dict(self):
            result = super().to_dict()
            result.update({
                '__type_name': EntityType.ASSISTANT_GOVERNANCE,
                'id': self.id,
                'assistant_id': self.assistant_id,
                'workflow_id': self.workflow_id,
                'configuration': self.configuration,
                'status': self.status
            })
            return result


    @event.listens_for(ConversationModel, 'before_delete')
    def before_delete_conversation(mapper, connection, instance: ConversationModel):
        session = Session.object_session(instance)
        session.query(ConversationGovernanceModel).filter_by(conversation_id=instance.id).delete(synchronize_session=False)

    @event.listens_for(AssistantModel, 'after_update')
    def after_update_assistant(mapper, connection, instance: AssistantModel):
        # When an assistant is updated, its conversation governance data is no longer valid.
        session = Session.object_session(instance)
        conversations = session.query(ConversationModel.id) \
            .filter(ConversationModel.assistant_id == instance.id) \
            .subquery()
        session.query(ConversationGovernanceModel) \
            .filter(ConversationGovernanceModel.conversation_id.in_(conversations)) \
            .delete(synchronize_session=False)
    
    @event.listens_for(AgentWorkflowModel, 'after_update')
    def after_update_agent_workflow(mapper, connection, instance: AgentWorkflowModel):
        # When an agent workflow is updated, its conversation governance data is no longer valid.
        session = Session.object_session(instance)
        conversations = session.query(ConversationModel.id) \
            .filter(ConversationModel.agent_workflow_id == instance.id) \
            .subquery()
        session.query(ConversationGovernanceModel) \
            .filter(ConversationGovernanceModel.conversation_id.in_(conversations)) \
            .delete(synchronize_session=False)
        

    class ConversationGovernanceModel(AuditedModel):
        __tablename__ = 'eqty_conversation_governance'

        conversation_id: str = database.Column(database.String(36), database.ForeignKey('conversations.id'), 
                                               primary_key=True, unique=True, nullable=False)
        statistics: str = database.Column(database.String(), nullable=True)

        def to_dict(self):
            result = super().to_dict()
            result.update({
                '__type_name': EntityType.CONVERSATION_GOVERNANCE,
                'id': self.conversation_id,
                'statistics': self.statistics
            })
            return result


class ModuleCapabilityModel(AuditedModel):
    __tablename__ = 'module_capabilities'

    id = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True, nullable=False)
    name = database.Column(database.String(100), nullable=False)
    label = database.Column(database.String(100), nullable=False)
    description = database.Column(database.String(500), nullable=True)
    module_type = database.Column(Enum(ModuleCapabilityType), nullable=False)
    default = database.Column(database.Boolean, nullable=False, default=False)

    def to_dict(self):
        result = super().to_dict()
        result.update({
            '__type_name': EntityType.MODULE_CAPABILITY,
            'id': self.id,
            'name': self.name,
            'label': self.label,
            'description': self.description,
            'module_type': self.module_type,
            'default': self.default
        })
        return result
    
class ModuleCapabilityRelationModel(database.Model):
    __tablename__ = 'module_capabilities_relations'

    module_id = database.Column(database.String(36), database.ForeignKey('modules.id'), primary_key=True, nullable=False)
    module_capability_id = database.Column(database.String(36), database.ForeignKey('module_capabilities.id'), primary_key=True, nullable=False)
    value = database.Column(database.String(4000), nullable=True)

    def to_dict(self):
        return {
            'moduleId': self.module_id,
            'moduleCapabilityId': self.module_capability_id,
            'value': self.value
        }
