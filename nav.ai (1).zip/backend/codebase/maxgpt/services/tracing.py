import logging
from typing import Dict, List

from llama_index.core.instrumentation.event_handlers import BaseEventHandler
from llama_index.core.instrumentation.events import BaseEvent
from llama_index.core.instrumentation.events.agent import (
    AgentChatWithStepStartEvent,
    AgentChatWithStepEndEvent,
    AgentRunStepStartEvent,
    AgentRunStepEndEvent,
    AgentToolCallEvent,
)
from llama_index.core.instrumentation.events.chat_engine import (
    StreamChatErrorEvent,
    StreamChatDeltaReceivedEvent, StreamChatEndEvent, )
from llama_index.core.instrumentation.events.embedding import (
    EmbeddingStartEvent,
    EmbeddingEndEvent,
)
from llama_index.core.instrumentation.events.llm import (
    LLMPredictEndEvent,
    LLMPredictStartEvent,
    LLMStructuredPredictEndEvent,
    LLMStructuredPredictStartEvent,
    LLMCompletionEndEvent,
    LLMCompletionStartEvent,
    LLMChatEndEvent,
    LLMChatStartEvent,
    LLMChatInProgressEvent,
)
from llama_index.core.instrumentation.events.query import (
    QueryStartEvent,
    QueryEndEvent,
)
from llama_index.core.instrumentation.events.rerank import (
    ReRankStartEvent,
    ReRankEndEvent,
)
from llama_index.core.instrumentation.events.retrieval import (
    RetrievalStartEvent,
    RetrievalEndEvent,
)
from llama_index.core.instrumentation.events.span import (
    SpanDropEvent,
)
from llama_index.core.instrumentation.events.synthesis import (
    SynthesizeStartEvent,
    SynthesizeEndEvent,
    GetResponseStartEvent,
)
from treelib import Tree

class ChatEventHandler(BaseEventHandler):
    events: List[BaseEvent] = []

    types_to_persist: List[str] = ['StreamChatErrorEvent', 'EmbeddingStartEvent', 'EmbeddingEndEvent',
                                   'LLMPredictStartEvent', 'LLMPredictEndEvent', 'LLMCompletionStartEvent',
                                   'LLMCompletionEndEvent', 'LLMChatStartEvent', 'LLMChatEndEvent',
                                   'RetrievalStartEvent', 'RetrievalEndEvent', 'ReRankStartEvent', 'ReRankEndEvent',
                                   'QueryStartEvent', 'QueryEndEvent', 'SynthesizeStartEvent', 'SynthesizeEndEvent',
                                   'GetResponseStartEvent', 'StreamChatStartEvent', 'StreamChatEndEvent']

    @classmethod
    def class_name(cls) -> str:
        """Class name."""
        return "ChatEventHandler"

    def handle(self, event: BaseEvent, **kwargs) -> None:

        try:
            """Logic for handling event."""
            logging.log(logging.DEBUG, "-----------------------")
            # all events have these attributes
            logging.log(logging.DEBUG, event.id_)
            logging.log(logging.DEBUG, event.timestamp)
            logging.log(logging.DEBUG, event.span_id)

            # event specific attributes
            logging.log(logging.DEBUG, f"Event type: {event.class_name()}")

            try:
                if isinstance(event, AgentRunStepStartEvent):
                    logging.log(logging.DEBUG, event.task_id)
                    logging.log(logging.DEBUG, event.step)
                    logging.log(logging.DEBUG, event.input)
                elif isinstance(event, AgentRunStepEndEvent):
                    logging.log(logging.DEBUG, event.step_output)
                elif isinstance(event, AgentChatWithStepStartEvent):
                    logging.log(logging.DEBUG, event.user_msg)
                elif isinstance(event, AgentChatWithStepEndEvent):
                    logging.log(logging.DEBUG, event.response)
                elif isinstance(event, AgentToolCallEvent):
                    logging.log(logging.DEBUG, event.arguments)
                    logging.log(logging.DEBUG, event.tool.name)
                    logging.log(logging.DEBUG, event.tool.description)
                    logging.log(logging.DEBUG, event.tool.to_openai_tool())
                elif isinstance(event, StreamChatDeltaReceivedEvent):
                    logging.log(logging.DEBUG, event.delta)
                elif isinstance(event, StreamChatErrorEvent):
                    logging.log(logging.ERROR, event.exception)
                elif isinstance(event, EmbeddingStartEvent):
                    logging.log(logging.DEBUG, event.model_dict)
                elif isinstance(event, EmbeddingEndEvent):
                    logging.log(logging.DEBUG, event.chunks)
                    logging.log(logging.DEBUG, event.embeddings[0][:5])  # avoid printing all embeddings
                elif isinstance(event, LLMPredictStartEvent):
                    logging.log(logging.DEBUG, event.template)
                    logging.log(logging.DEBUG, event.template_args)
                elif isinstance(event, LLMPredictEndEvent):
                    logging.log(logging.DEBUG, event.output)
                elif isinstance(event, LLMStructuredPredictStartEvent):
                    logging.log(logging.DEBUG, event.template)
                    logging.log(logging.DEBUG, event.template_args)
                    logging.log(logging.DEBUG, event.output_cls)
                elif isinstance(event, LLMStructuredPredictEndEvent):
                    logging.log(logging.DEBUG, event.output)
                elif isinstance(event, LLMCompletionStartEvent):
                    logging.log(logging.DEBUG, event.model_dict)
                    logging.log(logging.DEBUG, event.prompt)
                    logging.log(logging.DEBUG, event.additional_kwargs)
                elif isinstance(event, LLMCompletionEndEvent):
                    logging.log(logging.DEBUG, event.response)
                    logging.log(logging.DEBUG, event.prompt)
                elif isinstance(event, LLMChatInProgressEvent):
                    logging.log(logging.DEBUG, event.messages)
                    logging.log(logging.DEBUG, event.response)
                elif isinstance(event, LLMChatStartEvent):
                    logging.log(logging.DEBUG, event.messages)
                    logging.log(logging.DEBUG, event.additional_kwargs)
                    logging.log(logging.DEBUG, event.model_dict)
                elif isinstance(event, LLMChatEndEvent):
                    logging.log(logging.DEBUG, event.messages)
                    logging.log(logging.DEBUG, event.response)
                elif isinstance(event, RetrievalStartEvent):
                    logging.log(logging.DEBUG, event.str_or_query_bundle)
                elif isinstance(event, RetrievalEndEvent):
                    logging.log(logging.DEBUG, event.str_or_query_bundle)
                    logging.log(logging.DEBUG, event.nodes)
                elif isinstance(event, ReRankStartEvent):
                    logging.log(logging.DEBUG, event.query)
                    logging.log(logging.DEBUG, event.nodes)
                    logging.log(logging.DEBUG, event.top_n)
                    logging.log(logging.DEBUG, event.model_name)
                elif isinstance(event, ReRankEndEvent):
                    logging.log(logging.DEBUG, event.nodes)
                elif isinstance(event, QueryStartEvent):
                    logging.log(logging.DEBUG, event.query)
                elif isinstance(event, QueryEndEvent):
                    logging.log(logging.DEBUG, event.response)
                    logging.log(logging.DEBUG, event.query)
                elif isinstance(event, SpanDropEvent):
                    logging.log(logging.DEBUG, event.err_str)
                elif isinstance(event, SynthesizeStartEvent):
                    logging.log(logging.DEBUG, event.query)
                elif isinstance(event, SynthesizeEndEvent):
                    logging.log(logging.DEBUG, event.response)
                    logging.log(logging.DEBUG, event.query)
                elif isinstance(event, GetResponseStartEvent):
                    logging.log(logging.DEBUG, event.query_str)
            except Exception as e:
                # message_process_event.content = None
                logging.log(logging.WARN, "Unable to add content to process event: " + str(e))

            logging.log(logging.DEBUG, "-----------------------")

            self.events.append(event)

            if isinstance(event, StreamChatEndEvent) or isinstance(event, StreamChatErrorEvent):
                self.print_event_span_trees()

        except Exception as e:
            print(e)
            database.session.rollback()
            raise e

    def _get_events_by_span(self) -> Dict[str, List[BaseEvent]]:
        events_by_span: Dict[str, List[BaseEvent]] = {}
        for event in self.events:
            if event.span_id in events_by_span:
                events_by_span[event.span_id].append(event)
            else:
                events_by_span[event.span_id] = [event]
        return events_by_span

    def _get_event_span_trees(self) -> List[Tree]:
        events_by_span = self._get_events_by_span()

        trees = []

        tree = Tree()
        tree.create_node(
            tag=f"Event execution tree for process '{self.message_process.id}'",
            identifier=self.message_process.id,
            parent=None,
            data=self.events[0].timestamp,
        )

        for span, sorted_events in events_by_span.items():

            # create root node i.e. span node
            tree.create_node(
                tag=f"{span} (SPAN)",
                identifier=span,
                parent=self.message_process.id,
                data=sorted_events[0].timestamp,
            )

            for event in sorted_events:
                tree.create_node(
                    tag=f"{event.class_name()}: {event.id_}",
                    identifier=event.id_,
                    parent=event.span_id,
                    data=event.timestamp,
                )

        trees.append(tree)
        return trees

    def print_event_span_trees(self) -> None:
        if logging.getLogger().getEffectiveLevel() == logging.DEBUG:
            """Method for viewing trace trees."""
            trees = self._get_event_span_trees()
            for tree in trees:
                print(
                    tree.show(
                        stdout=False, sorting=True, key=lambda node: node.data
                    )
                )
                print("")