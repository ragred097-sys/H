import logging
import os
from enum import Enum

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Engine
from sqlalchemy import event

from maxgpt.core import DataType


class _DatabaseVendor(Enum):
    SQL_LITE = 1
    POSTGRES = 2

database: SQLAlchemy  = SQLAlchemy()

def initialize_database(app: Flask):
    db_url = None
    try:
        db_provider = _DatabaseVendor[os.getenv("DB_PROVIDER", _DatabaseVendor.SQL_LITE.name)]

        if db_provider == _DatabaseVendor.POSTGRES:
            db_url = f"postgresql://{os.getenv('DB_POSTGRES_USERNAME')}:{os.getenv('DB_POSTGRES_PASSWORD')}@{os.getenv('DB_POSTGRES_HOST')}:{os.getenv('DB_POSTGRES_PORT')}/{os.getenv('DB_POSTGRES_DBNAME')}"
            logging.info(f"Database URL: {db_url.replace(os.getenv('DB_POSTGRES_PASSWORD'), '*****')}")

        elif db_provider == _DatabaseVendor.SQL_LITE:
            db_url = f"sqlite:///{os.getenv('DB_SQL_LITE_PATH', os.getcwd() + '/Persistence.db')}"
            logging.info(f"Database URL: {db_url}")

            # Enable SQLite foreign key constraints
            @event.listens_for(Engine, "connect")
            def set_sqlite_pragma(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON;")
                cursor.close()


    except KeyError:
        raise Exception(f"Unsupported database provider: '{os.getenv('DB_PROVIDER')}'. "
                        f"Possible values values are: {[vendor.name for vendor in _DatabaseVendor]}")

    logging.log(logging.DEBUG,
                f"Using {db_provider.name} Database implementation as application persistence")
    app.config["SQLALCHEMY_DATABASE_URI"] = db_url
    if os.getenv("APP_ENABLE_SQL_TRACE", 'False').lower() in ('true', '1', 't'):
        app.config["SQLALCHEMY_ECHO"] = True
        logging.log(logging.DEBUG,
                    f"Enabling SQLALCHEMY_ECHO")
    database.init_app(app)

    with app.app_context():
        database.create_all()
        from maxgpt.services.data_model.user import UserModel
        from maxgpt.services.data_model.user import SystemUser

        # Bootstrapping some defaults
        if UserModel.query.get(SystemUser.ID) is None:
            print("Creating SystemUser")
            database.session.add(SystemUser())
            database.session.commit()

        from maxgpt.services.database_model import ExternalRoleApplicationAccessRoleMappingModel
        from maxgpt.services import DefaultApplicationAccessRole
        from maxgpt.services.data_model.authorization import ApplicationAccessRoleModel
        from maxgpt.services.database_model import PreferenceModel, PreferenceScope

        if ApplicationAccessRoleModel.query.get(DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value) is None:
            print("Creating Administration application access role")
            database.session.add(ApplicationAccessRoleModel(
                description="A system-defined application access role for application administrators.",
                system=True,
                creator_id=SystemUser.ID,
                name = DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value,
                id = DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value
            ))
            # Add default external role mapping
            default_role_mapping = ExternalRoleApplicationAccessRoleMappingModel(
                external_role_name="maxgpt_"+DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value,
                application_access_role_id=DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value,
                creator_id=SystemUser.ID)
            database.session.add(default_role_mapping)
            database.session.commit()

        if ApplicationAccessRoleModel.query.get(DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value) is None:
            print("Creating Data Engineer application access role")
            database.session.add(ApplicationAccessRoleModel(
                description="A system-defined application access role for application data engineers.",
                system=True,
                creator_id=SystemUser.ID,
                name = DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value,
                id = DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value
            ))
            # Add default external role mapping
            default_role_mapping = ExternalRoleApplicationAccessRoleMappingModel(
                external_role_name="maxgpt_"+DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value,
                application_access_role_id=DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value,
                creator_id=SystemUser.ID)
            database.session.add(default_role_mapping)
            database.session.commit()

        if ApplicationAccessRoleModel.query.get(DefaultApplicationAccessRole.MAXGPT_USER.value) is None:
            print("Creating User application access role")
            database.session.add(ApplicationAccessRoleModel(
                description="A system-defined application access role for application users.",
                system=True,
                creator_id=SystemUser.ID,
                name = DefaultApplicationAccessRole.MAXGPT_USER.value,
                id = DefaultApplicationAccessRole.MAXGPT_USER.value
            ))
            # Add default external role mapping
            default_role_mapping = ExternalRoleApplicationAccessRoleMappingModel(
                external_role_name="maxgpt_"+DefaultApplicationAccessRole.MAXGPT_USER.value,
                application_access_role_id=DefaultApplicationAccessRole.MAXGPT_USER.value,
                creator_id=SystemUser.ID)
            database.session.add(default_role_mapping)
            database.session.commit()

        # Add default application-scope preferences if not present
        default_app_preferences = [
                    {
                        "name": "app-title",
                        "label": "Application Title",
                        "description": "The title displayed in the application header.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "ai-model",
                        "label": "Default AI Model",
                        "description": "The default AI model used across the application.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "embedding-model",
                        "label": "Default Embedding Model",
                        "description": "The default embedding model for text processing.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "vector-store",
                        "label": "Default Vector Store",
                        "description": "The default vector store for data storage.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "file-store",
                        "label": "Default File Store",
                        "description": "The default file store for document storage.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "image-file-store",
                        "label": "Image File Store",
                        "description": "File store configuration for image files.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "video-file-store",
                        "label": "Video File Store",
                        "description": "File store configuration for video files.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "audio-file-store",
                        "label": "Audio File Store",
                        "description": "File store configuration for audio files.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "text-file-store",
                        "label": "Text File Store",
                        "description": "File store configuration for text files.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.TEXT
                    },
                    {
                        "name": "footer-banner",
                        "label": "Footer Banner",
                        "description": "Application footer banner image.",
                        "scope": PreferenceScope.GENERAL,
                        "type": DataType.URL
                    }, 
            ]

        for pref in default_app_preferences:
            if PreferenceModel.query.filter_by(name=pref["name"]).first() is None:
                database.session.add(PreferenceModel(
                    name=pref["name"],
                    label=pref["label"],
                    description=pref["description"],
                    scope=pref["scope"],
                    type=pref["type"]
                )) 
        database.session.commit()

      

        # Add default LLM capabilities if not present
        from maxgpt.services.database_model import ModuleCapabilityModel, ModuleCapabilityType
        from maxgpt.services.data_model.user import SystemUser
        default_llm_capabilities = [
            {
                "name": "TEXT_SUMMARIZATION_TRANSLATION",
                "label": "Text generation, Summarization & Translation",
                "description": "Generate, summarize, and translate text",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "CONVERSATIONAL_AI",
                "label": "Conversational AI",
                "description": "Engage in natural conversations",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "CODE_GENERATION",
                "label": "Code Generation",
                "description": "Create and debug code",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "ADVANCED_REASONING",
                "label": "Advanced Reasoning",
                "description": "Handle complex reasoning tasks",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "ENTERPRISE_APPLICATIONS",
                "label": "Enterprise Applications",
                "description": "Support enterprise use cases",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "RESEARCH_DEVELOPMENT",
                "label": "Research & Development",
                "description": "Assist in research tasks",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "VIDEO_IMAGE_ANALYSIS",
                "label": "Video/Image Analysis",
                "description": "Analyze visual content",
                "module_type": "LLM",
                "default": False
            },
            {
                "name": "MULTIMODAL_CAPABILITIES",
                "label": "Multimodal Capabilities",
                "description": "Work with text and images",
                "module_type": "LLM",
                "default": False
            }
        ]


        default_embedding_capabilities = [
            {
                "name": "HIGH_SEMANTIC_SEARCH_QUALITY",
                "label": "High Semantic Search Quality",
                "description": "Accurate and context-aware search",
                "module_type": "EMBEDDING_MODEL",
                "default": False
            },
            {
                "name": "LOW_LATENCY",
                "label": "Low Latency",
                "description": "Fast embedding response time",
                "module_type": "EMBEDDING_MODEL",
                "default": False
            },
            {
                "name": "MULTILINGUAL_SUPPORT",
                "label": "Multilingual Support",
                "description": "Supports multiple languages",
                "module_type": "EMBEDDING_MODEL",
                "default": False
            },
            {
                "name": "OPENAI_COMPATIBLE_API",
                "label": "OpenAI-Compatible API",
                "description": "Works with OpenAI interfaces",
                "module_type": "EMBEDDING_MODEL",
                "default": False
            }
        ]
 
        default_vectorstore_capabilities = [
            {
                "name": "SCALABILITY_AND_PERFORMANCE",
                "label": "Scalability & Performance",
                "description": "Efficient and scalable storage",
                "module_type": "VECTOR_STORE",
                "default": False
            },
            {
                "name": "SIMILARITY_SEARCH",
                "label": "Similarity Search",
                "description": "Finds similar vector data",
                "module_type": "VECTOR_STORE",
                "default": False
            },
            {
                "name": "METADATA_FILTERING",
                "label": "Metadata Filtering",
                "description": "Filter results using metadata",
                "module_type": "VECTOR_STORE",
                "default": False
            },
            {
                "name": "CONSISTENCY_AND_FAULT_TOLERANCE",
                "label": "Consistency & Fault Tolerance",
                "description": "Reliable and fault-resilient design",
                "module_type": "VECTOR_STORE",
                "default": False
            },
            {
                "name": "API_SDK_INTEGRATION",
                "label": "API/SDK Integration",
                "description": "Easy API and SDK support",
                "module_type": "VECTOR_STORE",
                "default": False
            },
            {
                "name": "MULTIMODAL_SUPPORT",
                "label": "Multimodal Support",
                "description": "Handles vectors from multiple modalities",
                "module_type": "VECTOR_STORE",
                "default": False
            }
        ]
 
        default_filestore_capabilities = [
            {
                "name": "EASY_INTEGRATION",
                "label": "Easy Integration",
                "description": "Seamless integration with systems",
                "module_type": "FILE_STORAGE",
                "default": False
            },
            {
                "name": "SCALABILITY",
                "label": "Scalability",
                "description": "Grows with data demand",
                "module_type": "FILE_STORAGE",
                "default": False
            },
            {
                "name": "RELIABILITY_AND_FAULT_TOLERANCE",
                "label": "Reliability & Fault Tolerance",
                "description": "Resilient and consistent storage",
                "module_type": "FILE_STORAGE",
                "default": False
            },
            {
                "name": "LOW_LATENCY_ACCESS",
                "label": "Low Latency Access",
                "description": "Fast file retrieval times",
                "module_type": "FILE_STORAGE",
                "default": False
            },
            {
                "name": "AI_ML_PIPELINE_COMPATIBILITY",
                "label": "AI/ML Pipeline Compatibility",
                "description": "Compatibility with AL/ML pipeline",
                "module_type": "FILE_STORAGE",
                "default": False
            }
        ]



        moduleType=[default_llm_capabilities, default_embedding_capabilities, default_vectorstore_capabilities, default_filestore_capabilities]
        for mod in moduleType:
            for cap in mod:
                existing = ModuleCapabilityModel.query.filter_by(
                    name=cap["name"],
                    module_type=ModuleCapabilityType[cap["module_type"]]
                ).first()
                if existing is None:
                    database.session.add(ModuleCapabilityModel(
                        name=cap["name"],
                        label=cap["label"],
                        description=cap["description"],
                        module_type=ModuleCapabilityType[cap["module_type"]],
                        default=cap["default"],
                        creator_id=SystemUser.ID,
                        modifier_id=SystemUser.ID
                    ))
        database.session.commit()





