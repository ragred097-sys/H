import abc
import logging
import os
from copy import copy
from importlib.util import module_from_spec, spec_from_file_location
from inspect import isabstract, isclass, getmembers
from types import ModuleType
from typing import List, Type, Set, Optional, cast, TypeVar, get_origin

T = TypeVar('T')

def find_class_annotations(clazz: Type, annotation_class: T) -> List[Type[T]]:
    _result = []
    for annotation in clazz.__annotations__.keys():
        annotation_value = getattr(clazz, annotation)
        annotation_origin = get_origin(annotation_value)
        search_origin = get_origin(annotation_class)
        if annotation_origin is not None:
            annotation_type = annotation_origin
        else:
            annotation_type = annotation_value
        if search_origin is not None:
            annotation_class = search_origin
        if isinstance(annotation_type, annotation_class):
            _result.append(copy(cast(annotation_class, annotation_value)))
    return _result

def find_subclasses(base_class: Type[T], module: Optional[ModuleType] = None) -> Set[Type[T]]:
    """
    Finds all non-abstract subclasses of a given abstract class.

    Args:
        base_class (Type[abc.ABC]): The base class to find subclasses of.
        module: If given the search is limited to that module

    Returns:
        Set[Type]: A set of all classes that correctly implement the given base class.
    """
    subclasses: Set[Type] = set()

    def find_them(cls: Type, depth: int = 0):
        for subclass in cls.__subclasses__():
            logging.log(logging.DEBUG, "  " * depth + "Class to check " + subclass.__name__)
            if not isabstract(subclass):
                logging.log(logging.DEBUG, "  " * depth + "# Adding " + subclass.__name__)
                subclasses.add(subclass)
            find_them(subclass, depth + 1)

    if module:
        for name, obj in getmembers(module):
            if isclass(obj) and issubclass(obj, base_class):
                if not isabstract(obj):
                    subclasses.add(obj)
    else:
        logging.log(logging.DEBUG, "Finding subclasses for: " + base_class.__name__)
        find_them(base_class)

    return subclasses


def __import_module(module_name: str, module_path: str) -> ModuleType:
    """
    Dynamically imports a module given its name and path.

    Args:
        module_name (str): The name of the module.
        module_path (str): The file path to the module.

    Returns:
        module: The imported module.
    """
    logging.log(logging.INFO, f"Loading module {module_name} from {module_path}.")
    spec = spec_from_file_location(module_name, module_path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def import_modules(directory: str) -> List[ModuleType]:
    """
    Dynamically loads all modules in the specified directory,
    including subdirectories.

    Args:
        directory (str): The directory to search for Python files.

    Returns:
        object: 
    """
    modules: List[ModuleType] = []
    
    def recursive_search_directory(dir_path: str):
        for root, _, files in os.walk(dir_path):
            for filename in files:
                if filename.endswith('.py') and filename != '__init__.py':
                    module_name = os.path.splitext(filename)[0]  # remove '.py'
                    module_path = os.path.join(root, filename)
                    module = __import_module(module_name, module_path)
                    modules.append(module)

    # Start recursive search from the given directory
    recursive_search_directory(directory)

    return modules