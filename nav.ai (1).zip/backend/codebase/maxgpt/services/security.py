import abc
import json
import os
from enum import Enum
from typing import Optional

import jwt
import requests
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from jwt.utils import base64url_decode

from maxgpt.api import EntityType


class User:
    @abc.abstractmethod
    def get_id(self):
        pass

    @abc.abstractmethod
    def get_account_id(self):
        pass

    @abc.abstractmethod
    def get_display_name(self):
        pass

    @abc.abstractmethod
    def get_email(self):
        pass

    def to_dict(self):
        return {
            '__type_name': EntityType.USER,
            'id': self.get_id(),
            'name': self.get_display_name(),
            'accountId': self.get_account_id(),
            'email': self.get_email(),
        }


class ShallowUser(User):
    def __init__(self, user_id: str, user_display_name: str):
        self._id = user_id
        self._display_name = user_display_name

    def get_id(self):
        return self._id

    def get_display_name(self):
        return self._display_name

    def get_account_id(self):
        return None

    def get_email(self):
        return None

    def to_dict(self):
        return {
            '__type_name': EntityType.USER,
            'id': self.get_id(),
            'name': self.get_display_name(),
        }


class AuthenticatedUser(User):
    __id: str
    __account_id: str
    __display_name: str
    __email: str

    def __init__(self, user: User):
        self.__id = user.id
        self.__account_id = user.account_id
        self.__display_name = user.display_name
        self.__email = user.email

    def get_id(self):
        return self.__id

    def get_account_id(self):
        return self.__account_id

    def get_display_name(self):
        return self.__display_name

    def get_email(self):
        return self.__email


class AuthenticationException(Exception):
    __description: Optional[str] = None

    def __init__(self, description: Optional[str] = None) -> None:
        super().__init__()
        if description is not None:
            self.__description = description

    def get_description(self) -> str:
        return "" if self.__description is None else self.__description


class AuthenticationProviderType(Enum):
    _LOCAL_DEV = '_LOCAL_DEV'
    NONE = 'NONE'
    MSAL = 'MSAL'
    OPENID = 'OPENID'


# 4. Convert JWKS public key to PEM format
def jwk_to_pem(jwk_key):
    # This will extract the components of the key
    modulus = int.from_bytes(base64url_decode(jwk_key['n']), byteorder='big')
    exponent = int.from_bytes(base64url_decode(jwk_key['e']), byteorder='big')

    # Reconstruct the public RSA key using cryptography
    public_key = rsa.RSAPublicNumbers(exponent, modulus).public_key(default_backend())

    # Convert the RSA public key to PEM format
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem


class AuthenticatorConfiguration:
    @abc.abstractmethod
    def to_dict(self) -> dict:
        pass


class AbstractAuthenticator(abc.ABC):
    def __init__(self, provider: AuthenticationProviderType):
        self.provider: AuthenticationProviderType = provider

    def get_provider(self):
        return self.provider

    @abc.abstractmethod
    def authenticate_user(self, request, *args, **kwargs) -> Optional[dict]:
        """
        :param request: Flask request object
        :param args:
        :param kwargs:
        :return: The User ID of a given AccessToken if it can be verified (sub by default by oid for MSAL)

        This function need to check the provided access token against the configured authentication provider
        to secure endpoints. OPENID and MSAL are expecting a bearer token with RSA256 signature encryption.
        Good practice is to load public key should be loaded during initialization of the Authenticator implementation.
        """
        pass

    @abc.abstractmethod
    def get_configuration(self) -> AuthenticatorConfiguration | None:
        """
        :return: All authentication provider configurations that the client needs to initialize user

        authentication in the UI. Every future request to the backend if done using a token that gets verified for
        each and every request (see function authenticate_user).
        """
        pass

    @abc.abstractmethod
    def get_display_name(self, token: dict):
        pass

    @abc.abstractmethod
    def get_account_id(self, token: dict):
        pass

    @abc.abstractmethod
    def get_email(self, token: dict):
        pass

    @abc.abstractmethod
    def get_roles(self, token: dict) -> [str]:
        pass


class NoneAuthenticator(AbstractAuthenticator):
    def __init__(self):
        super().__init__(AuthenticationProviderType.NONE)

    def get_configuration(self) -> None:
        return None

    def get_display_name(self, token: dict):
        return token.get('display_name')

    def get_account_id(self, token: dict):
        return token.get('account_id')

    def get_email(self, token: dict):
        return token.get('email')

    def get_roles(self, token: dict) -> [str]:
        from maxgpt.services import DefaultApplicationAccessRole
        return [DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value,
                DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value,
                DefaultApplicationAccessRole.MAXGPT_USER.value]

    def authenticate_user(self, request, *args, **kwargs) -> Optional[dict]:
        return {
            'account_id': "MAX",
            'email': 'MAX@GPT.AI',
            'display_name': "MAX",
            'roles': self.get_roles({})
        }


class LocalDevAuthenticator(AbstractAuthenticator):
    def __init__(self):
        super().__init__(AuthenticationProviderType._LOCAL_DEV)

    def get_display_name(self, token: dict):
        return token.get('display_name')

    def get_account_id(self, token: dict):
        return token.get('account_id')

    def get_email(self, token: dict):
        return token.get('email')

    def get_roles(self, token: dict) -> [str]:
        from maxgpt.services import DefaultApplicationAccessRole
        return [DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value,
                DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value,
                DefaultApplicationAccessRole.MAXGPT_USER.value]

    def authenticate_user(self, request, *args, **kwargs) -> Optional[dict]:
        try:
            return {
                'account_id': os.getlogin(),
                'email': 'MAX@GPT.AI',
                'display_name': os.getlogin(),
                'roles': self.get_roles({})
            }
        except Exception:
            return {
                'account_id': request.remote_addr,
                'email': 'MAX@GPT.AI',
                'display_name': request.remote_addr,
                'roles': self.get_roles({})
            }
            x


class OpenIDAuthenticatorConfiguration(AuthenticatorConfiguration):
    def __init__(self, authority_url, client_id, client_secret, redirect_uri, response_type, response_scope):
        self.authority_url = authority_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.response_type = response_type
        self.response_scope = response_scope

    def to_dict(self) -> dict:
        return {
            'authority': self.authority_url,
            'clientId': self.client_id,
            'clientSecret': self.client_secret,
            'redirectUri': self.redirect_uri,
            'responseType': self.response_type,
            'scope': self.response_scope
        }


class OpenIDAuthenticator(AbstractAuthenticator):
    public_keys: list

    def __init__(self):
        super().__init__(AuthenticationProviderType.OPENID)
        self.configuration = OpenIDAuthenticatorConfiguration(
            authority_url=os.getenv('AUTH_OPENID_AUTHORITY_URL'),
            client_id=os.getenv('AUTH_OPENID_CLIENT_ID'),
            client_secret=os.getenv('AUTH_OPENID_CLIENT_SECRET'),
            redirect_uri=os.getenv('AUTH_OPENID_REDIRECT_URI'),
            response_type=os.getenv('AUTH_OPENID_RESPONSE_TYPE', 'code'),
            response_scope=os.getenv('AUTH_OPENID_RESPONSE_SCOPE', 'openid profile email'),
        )
        self.verify_expiration = os.getenv('AUTH_OPENID_VERIFY_EXPIRATION', False)

        discovery_response = requests.get(
            self.configuration.authority_url + '/.well-known/openid-configuration')
        jwks_uri = discovery_response.json()['jwks_uri']
        jwks_data = requests.get(jwks_uri).json()
        self.public_keys = jwks_data['keys']

    def get_display_name(self, token: dict):
        if not token:
            return None
        return token.get('name')

    def get_account_id(self, token: dict):
        if not token:
            return None
        return token.get('sub')

    def get_email(self, token: dict):
        if not token:
            return None
        return token.get('email')

    def authenticate_user(self, request, *args, **kwargs) -> Optional[dict]:
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            raise AuthenticationException("Missing Authorization header")

        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != 'bearer':
            raise AuthenticationException("Authorization header malformed")

        jwt_token = parts[1]

        # decode token payload
        jwt_header = jwt.get_unverified_header(jwt_token)
        kid = jwt_header['kid']

        # extract matching public key and convert to PEM format
        public_key_jwk = None
        for key in self.public_keys:
            if key['kid'] == kid:
                public_key_jwk = key
                break

        if public_key_jwk is None:
            raise Exception(f"No public key found for kid: {kid}")

        public_key = jwk_to_pem(public_key_jwk)

        if public_key:
            decoded_token = jwt.decode(jwt_token, public_key,
                                       algorithms=['RS256'],
                                       audience='account',
                                       options={
                                           'verify_signature': True,
                                           'verify_aud': True,
                                           'verify_iat': False,
                                           'verify_exp': self.verify_expiration,
                                           'verify_nbf': False,
                                           'verify_iss': True,
                                           'verify_sub': True,
                                           'verify_jti': True,
                                           'verify_at_hash': True,
                                           'leeway': 0
                                       })
            return decoded_token
        else:
            raise AuthenticationException("Unauthorized user")

    def get_roles(self, token: dict) -> [str]:
        result: [str] = []
        if token.get('realm_access'):
            if token.get('realm_access').get('roles'):
                for role_name in list(token.get('realm_access').get('roles')):
                    result.append(role_name)
        return result

    def get_configuration(self) -> OpenIDAuthenticatorConfiguration:
        return self.configuration


class MSALAuthenticatorConfiguration(AuthenticatorConfiguration):
    def __init__(self, tenant_id, app_client_id, api_client_id, api_scope, redirect_uri, authority):
        self.tenant_id = tenant_id
        self.app_client_id = app_client_id
        self.api_client_id = api_client_id
        self.api_scope = api_scope
        self.redirect_uri = redirect_uri
        self.authority = authority

    def to_dict(self) -> dict:
        return {
            "tenantId": self.tenant_id,
            "appClientId": self.app_client_id,
            "apiClientId": self.api_client_id,
            "apiScope": self.api_scope,
            "redirectUri": self.redirect_uri,
            "authority": self.authority
        }


class MsalAuthenticator(AbstractAuthenticator):
    AUTH_MSAL_TENANT_ID: str
    AUTH_MSAL_APP_CLIENT_ID: str
    AUTH_MSAL_API_CLIENT_ID: str
    AUTH_MSAL_API_SCOPE: str
    AUTH_MSAL_REDIRECT_URI: str
    AUTH_MSAL_AUTHORITY: str
    public_keys: list

    def __init__(self):
        super().__init__(AuthenticationProviderType.MSAL)
        __tenant_id = os.getenv("AUTH_MSAL_TENANT_ID")
        self.configuration = MSALAuthenticatorConfiguration(
            tenant_id=__tenant_id,
            app_client_id=os.getenv("AUTH_MSAL_APP_CLIENT_ID"),
            api_client_id=os.getenv("AUTH_MSAL_API_CLIENT_ID"),
            api_scope=os.getenv("AUTH_MSAL_API_SCOPE", "user_impersonation"),
            redirect_uri=os.getenv("AUTH_MSAL_REDIRECT_URI"),
            authority=os.getenv("AUTH_MSAL_AUTHORITY", f"https://login.microsoftonline.com/{__tenant_id}")
        )

        # get public key from azure (to be able to decode bearer token)
        # discovery_response = requests.get(self.AUTH_MSAL_AUTHORITY + '/.well-known/openid-configuration')
        discovery_response = requests.get(
            self.configuration.authority + '/v2.0/.well-known/openid-configuration?appid=' + self.configuration.api_client_id)
        jwks_uri = discovery_response.json()['jwks_uri']
        jwks_data = requests.get(jwks_uri).json()
        self.public_keys = jwks_data['keys']

    def get_display_name(self, token: dict):
        if not token:
            return None
        return token.get('oid')

    def get_account_id(self, token: dict):
        if not token:
            return None
        return token.get('oid')

    def get_email(self, token: dict):
        if not token:
            return None
        return token.get('oid')

    def authenticate_user(self, request, *args, **kwargs) -> Optional[dict]:
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            raise AuthenticationException("Missing Authorization header")

        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != 'bearer':
            raise AuthenticationException("Authorization header malformed")

        jwt_token = parts[1]

        # decode token payload
        header = jwt.get_unverified_header(jwt_token)

        # extract matching public key and convert to PEM format
        public_key = None
        for key in self.public_keys:
            if key['kid'] == header['kid']:
                public_key = jwt.PyJWK.from_json(json.dumps(key))
                break

        if public_key:
            decoded_token = jwt.decode(jwt_token, public_key,
                                       algorithms=['RS256'],
                                       audience='api://' + self.configuration.api_client_id,
                                       options={
                                           'verify_signature': True,
                                           'verify_aud': True,
                                           'verify_iat': True,
                                           'verify_exp': True,
                                           'verify_nbf': False,
                                           'verify_iss': True,
                                           'verify_sub': True,
                                           'verify_jti': True,
                                           'verify_at_hash': True,
                                           'leeway': 0
                                       })
            return decoded_token
        else:
            raise AuthenticationException("Unauthorized user")

    def get_roles(self, token: dict) -> [str]:
        raise NotImplementedError()

    def get_configuration(self) -> MSALAuthenticatorConfiguration:
        return self.configuration


# instance
class AuthenticationProviderRegistry(abc.ABC):
    __auth_provider_instance: Optional[AbstractAuthenticator] = None

    @classmethod
    def initialize(cls):
        auth_provider = os.getenv('AUTH_PROVIDER')
        if auth_provider is not None and auth_provider != AuthenticationProviderType.NONE.name:
            try:
                provider_type = AuthenticationProviderType[auth_provider]
                # noinspection PyProtectedMember
                if provider_type == AuthenticationProviderType.MSAL:
                    cls.__auth_provider_instance = MsalAuthenticator()
                elif provider_type == AuthenticationProviderType.OPENID:
                    cls.__auth_provider_instance = OpenIDAuthenticator()
                elif provider_type == AuthenticationProviderType._LOCAL_DEV:
                    cls.__auth_provider_instance = LocalDevAuthenticator()
            except KeyError:
                raise Exception(f"Invalid authentication provider: '{auth_provider}'")
        else:
            cls.__auth_provider_instance = NoneAuthenticator()

    @classmethod
    def get_authenticator(cls) -> AbstractAuthenticator:
        if not cls.__auth_provider_instance:
            cls.initialize()
        return cls.__auth_provider_instance
