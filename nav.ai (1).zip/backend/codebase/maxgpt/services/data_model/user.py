import uuid
from datetime import datetime

from maxgpt.services import database
from maxgpt.services.security import User


class UserModel(database.Model, User):
    """
        UserModel defines the persistence entity of a user. It is used by SQLAlchemy
        to manage the central table 'users'.
    """

    __tablename__ = 'users'

    def __init__(self, account_id, display_name, email):
        self.account_id = account_id
        self.display_name = display_name
        self.email = email

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    account_id: str = database.Column(database.String(80), nullable=False)
    display_name: str = database.Column(database.String(200), nullable=False)
    email: str = database.Column(database.String(200), nullable=True)

    created_at: datetime = database.Column(database.DateTime, default=datetime.now())

    settings = database.relationship("UserSettingModel", back_populates="user", cascade="all, delete-orphan")

    def get_id(self):
        return self.id

    def get_account_id(self):
        return self.account_id

    def get_display_name(self):
        return self.display_name

    def get_email(self):
        return self.email


class SystemUser(UserModel):
    """
        The system user is used to manage audited entities in the db or in memory that requires
        audit information but is not created from an application user.

        For example: Loading modules from ENV variables is done during bootstrapping and requires
        a creator reference that is not available at this point.

        The system user is generated during the db bootstrapping right after the db model creation.
    """

    ID: str = "0"

    def __init__(self):
        super().__init__(SystemUser.ID, SystemUser.ID, None)
        self.id = SystemUser.ID
        self.display_name = "SYSTEM"