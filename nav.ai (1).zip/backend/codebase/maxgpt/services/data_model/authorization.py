import uuid

from maxgpt.services import database, ApplicationAccessRole
from maxgpt.services.internal.audited_model import AuditedModel


class ApplicationAccessRoleModel(AuditedModel, ApplicationAccessRole):
    __tablename__ = 'application_access_roles'

    id: str = database.Column(database.String(36), primary_key=True, default=lambda: str(uuid.uuid4()), unique=True,
                              nullable=False)
    name: str = database.Column(database.String(100), nullable=False, unique=True)
    description: str = database.Column(database.String(), nullable=True)
    system: bool = database.Column(database.Boolean(), default=False, nullable=False)

    def get_id(self):
        return self.id

    def get_name(self):
        return self.name

    def get_system(self):
        return self.system

    def get_description(self):
        return self.description

    def to_dict(self):
        result = ApplicationAccessRole.to_dict(self)
        result.update(AuditedModel.to_dict(self))
        return result