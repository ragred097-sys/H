from typing import Protocol

class Identifiable(Protocol):
    id: int

class Audited(Protocol):
    creator_id: int

# combine Protocols as "&"  ist not working as expected
class IdentifiableAudited(Identifiable, Audited, Protocol):
    pass

