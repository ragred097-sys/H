import datetime
import io
import json
from typing import Optional

from flask import request, jsonify, send_file
from flask_restx import Namespace, Resource, reqparse
from werkzeug.datastructures import FileStorage
from sqlalchemy import select

from maxgpt.modules import ModuleType, ModuleRegistry
from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.api.impl.assistant import get_assistant_by_id

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services.database_model import ModuleModel, SystemInstructionModel, DataSourceModel, AssistantModel, \
    AssistantTagRelationModel, UserFavoriteModel, DocumentType, AssistantModuleRelationModel, \
    AssistantSystemInstructionRelationModel, AssistantSampleQuestionModel, FavoriteSubject
from maxgpt.navai.api.impl.utils import encrypt_json, decrypt_json
from maxgpt.services import database
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.api import EntityType

#### Variables ####
__Secret_Key__ = "maxgpt" # encryption key

__Supported_Entities__ = {
    EntityType.ASSISTANT: [
        "accessPermission",
        "createdAt",
        "creator",
        "id",
        "llmIds",
        "dataSourceIds",
        "systemInstructionIds",
        "tags"
        ]
    }

entity_handlers = {
    "Assistant_Export": None,
    "Assistant_Import": None
}

ns = Namespace('NavAIDataMigration',
               description='Endpoints require to execute importing and exporting of Agents.',
               path='/navai/system')

upload_parser = ns.parser()
upload_parser.add_argument(
    'file',
    location='files',
    type=FileStorage,
    required=False,
    help='Encrypted export file to import'
)
upload_parser.add_argument(
    'preview',
    location='args',
    choices=('true', 'false'),
    default='false',
    help='If true, returns decrypted file'
)

dmt_import_model_example = ns.schema_model('DMT Import Example', {
   "example": {
       "__type_name": "Assistant",
       "accessPermission": "WRITE",
       "attachmentStorages": [
           {
               "fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f",
               "type": "VIDEO"
           },
           {
               "fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f",
               "type": "AUDIO"
           },
           {
               "fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f",
               "type": "IMAGE"
           },
           {
               "fileStorageId": "d4728df5-c1ee-45be-bb25-eb4446d4b42f",
               "type": "TEXT"
           }
       ],
       "customSystemInstruction": None,
       "dataSourceIds": [],
       "description": "Jack in the Box",
       "favorite": False,
       "greetingMessage": "Greetings fellow humans",
       "hidden": False,
       "icon": None,
       "image": None,
       "llmIds": "01ab5eec-c6bc-4e13-abc0-5e4924f5d43b",
       "name": "Jack",
       "sampleQuestions": [
           "Would you like to know about quantum teleportation via void space and particle connection via quantum entanglement? Well, I sure can answer.",
           "Tell me, what evidence do you have regarding my blanket being the best blanket??!!!"
       ],
       "system_instructions": [
           {
               "description": "Informing the agent of its name",
               "name": "Naming",
               "message": "You are my helpful agent and your name is Jack"
           },
           {
               "description": "Experience information",
               "name": "Specialized in Law",
               "message": "You have a master degree in Law and have worked for the general attorney of your district for the past 4 years"
           }
       ],
       "systemInstructionIds": [
           "d0024d30-24a7-4b25-9277-a6b56c31ae3b"
       ],
       "tags": []
   }
})

# Required because RESTX-Swagger does not support null as example value for strings.
dmt_export_model_example = ns.schema_model('DMT - Export Request Configuration Example', {
   "example": {
       "entityId": "9dcc489b-e45d-4757-a214-7c2274b3c6e8",
       "entityType": "Assistant"
   }
})

#### Methods ####
def export_entity(name: str, entity_id: str):
    is_supported_entity(name)
    return entity_handlers[name+"_Export"](entity_id, __Supported_Entities__[EntityType(name)])

def import_entity(name: str, data: json):
    is_supported_entity(name)
    return entity_handlers[name+"_Import"](data)

def is_supported_entity(name: str):
    try:
        if not EntityType(name) in __Supported_Entities__:
            raise Exception("Unsupported entityType") 
    except:
        raise Exception("Unsupported entityType")

def create_encrypted_file(file_data):    
    # Encrypt content to avoid plain text exposure of secrets
    encrypted_content = encrypt_json(json_data=file_data, password=__Secret_Key__)

    # Create file in memory
    file_buffer = io.BytesIO()
    file_buffer.write(encrypted_content.encode())
    file_buffer.seek(0)

    return file_buffer

def get_decripted_file(uploaded_file):
    if not uploaded_file:
            return {"message": "No file uploaded"}, 400
    try:
        encrypted_content = uploaded_file.read().decode('utf-8')
        decrypted_json = decrypt_json(encrypted_content, __Secret_Key__)
        entity_data = json.loads(decrypted_json)
        return jsonify(entity_data)
    except Exception as e:
        return {"message": f"Failed to decript: {str(e)}"}, 400       

def export_assistant(assistant_id, remove_fields):
    
    data = get_assistant_by_id(assistant_id)

    attached_storages = data["attachmentStorages"]
    if attached_storages is not None:
        for storage in attached_storages:
            storage.pop("fileStorageId", None)

    data_source_ids = data.get("dataSourceIds")
    if data_source_ids is not None:
        data["data_sources"] = []
        for id in data_source_ids:
            data_source = DataSourceModel.query.filter(DataSourceModel.id == id).first()
            data["data_sources"].append({
                "name": data_source.name,
                "description": data_source.description
            })
    
    system_instructions_ids = data.get("systemInstructionIds")
    if system_instructions_ids is not None:
        data["system_instructions"] = []
        for id in system_instructions_ids:
            system_instruction = SystemInstructionModel.query.filter(SystemInstructionModel.id == id).first()
            data["system_instructions"].append({
                "name": system_instruction.name,
                "description": system_instruction.description,
                "message": system_instruction.message
            })

    # Remove top-level fields
    for field in remove_fields:
        data.pop(field, None)
    data["dataSourceIds"] = data.pop("data_sources", None)
    data["tags"] = []
    data["llmIds"] = []

    return jsonify(data)

entity_handlers["Assistant_Export"] = export_assistant

def import_assistant(data: dict):
    #current_user = SessionContext.get_current_user()
    created_instructions = create_system_instructions(data.get("system_instructions"))
    custom_system_instruction = data.get('customSystemInstruction', None)
    greeting_message = data.get('greetingMessage', None)
    sample_questions = data.get('sampleQuestions', []) 
    attachment_storages = data.get('attachmentStorages', [])


    assistant = AssistantModel(name=data.get('name'),
                                description=data.get('description'))

    if custom_system_instruction:
        assistant.custom_system_instruction = custom_system_instruction

    if greeting_message:
        assistant.greeting_message = greeting_message

    if attachment_storages:
        assistant.audio_attachment_storage_id = None
        assistant.image_attachment_storage_id = None
        assistant.video_attachment_storage_id = None
        assistant.text_attachment_storage_id = None
        for attachment_storage in attachment_storages:
            storage_type = DocumentType(attachment_storage.get('type'))
            file_storage_id = attachment_storage.get('fileStorageId')
            assistant.set_attachment_storage(storage_type, file_storage_id)

    if data.get('tags', None) is not None:
        for shallow_tag in data['tags']:
            assistant.tag_relations.append(
                AssistantTagRelationModel(assistant_id=assistant.id, tag_id=shallow_tag['id']))

    if data.get('llmIds', None) is not None:
        if isinstance(data['llmIds'], list):
            for llm_id in data['llmIds']:
                llm = get_llm_by_id(data['llmIds'])
                assistant.llms.append(AssistantModuleRelationModel(assistant_id=assistant.id, module_id=llm.get_id()))
        else:
            llm = get_llm_by_id(data['llmIds'])
            assistant.llms.append(AssistantModuleRelationModel(assistant_id=assistant.id, module_id=llm.get_id()))

    if len(assistant.llms) == 0:
        ns.abort(404, f"You need to assign at least one LLM to assistant '{assistant.name}'")

    if data.get('systemInstructionIds', None) is not None:
        for system_instruction_id in data['systemInstructionIds']:
            system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(system_instruction_id)
            # check if relation already exists
            exists = any(rel.system_instruction_id == system_instruction.id for rel in assistant.system_instructions)
            if exists:
                continue
            assistant.system_instructions.append(
                AssistantSystemInstructionRelationModel(assistant_id=assistant.id, system_instruction_id=system_instruction.id))

    for instruction in created_instructions:
        exists = any(rel.system_instruction_id == instruction.id for rel in assistant.system_instructions)
        if exists:
            continue
        assistant.system_instructions.append(
            AssistantSystemInstructionRelationModel(assistant_id=assistant.id, system_instruction_id=instruction.id))

    database.session.add(assistant)

    for sample_question in sample_questions:
        q = AssistantSampleQuestionModel(assistant=assistant, content=sample_question)
        database.session.add(q)

    # attach favorite information
    current_user = SessionContext.get_current_user()
    stmt = select(UserFavoriteModel.subject_id).where(
        (UserFavoriteModel.user_id == current_user.get_id()) &
        (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
    )

    set(database.session.scalars(stmt))

    # commit to get autogen fields filled before returning
    database.session.commit()

    return "success", 200
    #return jsonify([instr.to_dict() for instr in created_instructions])"

def get_llm_by_id(id):
    llm = ModuleRegistry.get_module(id)
    if llm is None:
        ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{id}'")
    elif llm.get_spec().get_module_type() != ModuleType.LLM:
        ns.abort(404,
                    f"No module of type {ModuleType.LLM} found for identifier '{id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
    return llm  

def get_system_instruction(name, description, message):
    return  SystemInstructionModel.query.filter(
            SystemInstructionModel.name == name,
            SystemInstructionModel.description == description,
            SystemInstructionModel.message == message            
        ).first()

def create_system_instructions(instructions):
    created = []
    for item in instructions:
        if item['name'] is None or item['message'] is None:
            continue
        existing_instruction = get_system_instruction(item['name'], item['description'], item['message'])
        if existing_instruction is None:
            system_instruction = SystemInstructionModel(
                name=item['name'],
                description=item['description'],
                message=item['message']
            )
            database.session.add(system_instruction)
            created.append(system_instruction)
        else:
            created.append(existing_instruction)       

    database.session.commit()
    return created


entity_handlers["Assistant_Import"] = import_assistant

#### Endpoints ####

# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('/export', strict_slashes=False, methods=['POST'])
class DMTExportEndpoint(Resource):
    @ns.expect(dmt_export_model_example)
    @ns.doc("DmtExport", description="Creates an encrypted file of the exported entity")
    @ns.response(200, 'Success')
    @ns.response(400, 'Referenced entity not found')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new preference"""

        body = request.get_json()
        entity_data = 1
        try:
            entity_data = export_entity(body['entityType'], body['entityId'])
        except Exception as e:
            return {"message": str(e)}, 422       
        
        file_data = json.dumps(json.loads(entity_data.get_data(as_text=True)))

        # Prepare and send encrypted text as file
        date_str = datetime.datetime.now().strftime("%YYYY_%mm_%dd")
        filename = f"export_{date_str}.txt"

        file_buffer = create_encrypted_file(file_data)

        # Return as a file response
        return send_file(
            file_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype="application/octet-stream"
        )

@ns.route('/import', strict_slashes=False, methods=['POST'])
class DMTImportEndpoint(Resource):
    @ns.expect(upload_parser)
    @ns.doc("DmtImport")
    @ns.response(200, 'Success')
    @ns.response(400, 'Invalid file or decryption error')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Import an Assistant from an encrypted file"""

        args = upload_parser.parse_args()        
        preview = str(args.get('preview', 'false')).lower() == 'true'

        if preview:
            uploaded_file = args['file']
            return get_decripted_file(uploaded_file)
        else:
            data = request.get_json()
            if not data:
                return {"message": "Missing JSON body"}, 400
            return import_entity(data["__type_name"], data)