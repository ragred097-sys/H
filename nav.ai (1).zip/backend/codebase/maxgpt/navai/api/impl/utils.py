from maxgpt.services.database_model import (
    WorkspaceModel, AssistantModel, AgentModel, AgentWorkflowModel,
    DataSourceModel, SystemInstructionModel,
    WorkspaceAssistantRelationModel, WorkspaceAgentRelationModel,
    WorkspaceAgentWorkflowRelationModel, AssistantDataSourceRelationModel, 
    AssistantSystemInstructionRelationModel, AgentSystemInstructionRelationModel
)
import json
import hashlib
import base64
from cryptography.fernet import Fernet
from maxgpt.api.internal.utils import NonFlaskCustomJsonEncoder

def encrypt_json(json_data: dict, password: str) -> str:
    key = generate_32b_key(password)
    fernet = Fernet(key)
    encrypted_data = fernet.encrypt(json.dumps(json_data, cls=NonFlaskCustomJsonEncoder).encode())
    return encrypted_data.decode()

def decrypt_json(encrypted_data: str, password: str) -> dict:
    key = generate_32b_key(password)
    fernet = Fernet(key)
    decrypted_data = fernet.decrypt(encrypted_data.encode()).decode()
    return json.loads(decrypted_data)

def generate_32b_key(password: str) -> bytes:
    key = hashlib.sha256(password.encode()).digest()
    return base64.urlsafe_b64encode(key[:32])

def get_workspace_assistants(workspace_id,deleted = False): 
    if deleted:
        deletion_filter = AssistantModel.deleted_at.isnot(None)
    else:
        deletion_filter = AssistantModel.deleted_at.is_(None) 

    workspace_assistants = AssistantModel.query.join(
        WorkspaceAssistantRelationModel,
        AssistantModel.id == WorkspaceAssistantRelationModel.assistant_id
    ).filter(
        WorkspaceAssistantRelationModel.workspace_id == workspace_id,
        deletion_filter
    ).all()

    return workspace_assistants 

def get_workspace_agents(workspace_id,deleted = False): 
    if deleted:
        deletion_filter = AgentModel.deleted_at.isnot(None)
    else:
        deletion_filter = AgentModel.deleted_at.is_(None)
    workspace_agents =  AgentModel.query.join(
                            WorkspaceAgentRelationModel,
                            AgentModel.id == WorkspaceAgentRelationModel.agent_id
                        ).filter(
                            WorkspaceAgentRelationModel.workspace_id == workspace_id,
                            deletion_filter
                        ).all()
    return workspace_agents

def get_workspace_agent_workflows(workspace_id,deleted = False): 
    if deleted:
        deletion_filter = AgentWorkflowModel.deleted_at.isnot(None)
    else:
        deletion_filter = AgentWorkflowModel.deleted_at.is_(None)
    workspace_agent_workflows = AgentWorkflowModel.query.join(
                                    WorkspaceAgentWorkflowRelationModel,
                                    AgentWorkflowModel.id == WorkspaceAgentWorkflowRelationModel.agent_workflow_id
                                ).filter(
                                    WorkspaceAgentWorkflowRelationModel.workspace_id == workspace_id,
                                deletion_filter
                                ).all()
    return workspace_agent_workflows

def get_assistant_data_sources(assistant_id,deleted = False): 
    if deleted:
        deletion_filter = DataSourceModel.deleted_at.isnot(None)
    else:
        deletion_filter = DataSourceModel.deleted_at.is_(None)
    assistant_data_sources = DataSourceModel.query.join(
                                AssistantDataSourceRelationModel,
                                DataSourceModel.id == AssistantDataSourceRelationModel.data_source_id
                            ).filter(
                                AssistantDataSourceRelationModel.assistant_id == assistant_id,
                                deletion_filter
                            ).all()
    return assistant_data_sources

def get_assistant_system_instructions(assistant_id,deleted = False): 
    if deleted:
        deletion_filter = SystemInstructionModel.deleted_at.isnot(None)
    else:
        deletion_filter = SystemInstructionModel.deleted_at.is_(None)
    assistant_system_instructions = SystemInstructionModel.query.join(
                                        AssistantSystemInstructionRelationModel,
                                        SystemInstructionModel.id == AssistantSystemInstructionRelationModel.system_instruction_id
                                    ).filter(
                                        AssistantSystemInstructionRelationModel.assistant_id == assistant_id,
                                        deletion_filter
                                    ).all()
    return assistant_system_instructions

def get_agent_system_instructions(agent_id,deleted = False): 
    if deleted:
        deletion_filter = SystemInstructionModel.deleted_at.isnot(None)
    else:
        deletion_filter = SystemInstructionModel.deleted_at.is_(None)
    agent_system_instructions = SystemInstructionModel.query.join(
                                    AgentSystemInstructionRelationModel,
                                    SystemInstructionModel.id == AgentSystemInstructionRelationModel.system_instruction_id
                                ).filter(
                                    AgentSystemInstructionRelationModel.agent_id == agent_id,
                                    deletion_filter
                                ).all()
    return agent_system_instructions

def is_data_source_used_by_other_assistants(data_source_id, exclude_assistant_ids=None, current_user_id=None):
    """Check if data source is used by any other assistants except excluding ones"""
    data_source = DataSourceModel.query.get(data_source_id)
    if data_source and data_source.creator_id != current_user_id:
        # If current user is not the creator, don't perform soft delete
        return True

    assistant_query = AssistantDataSourceRelationModel.query.join(
        AssistantModel,
        AssistantDataSourceRelationModel.assistant_id == AssistantModel.id
    ).filter(
        AssistantDataSourceRelationModel.data_source_id == data_source_id,
        AssistantModel.deleted_at.is_(None)
    )
    
    if exclude_assistant_ids:
        assistant_query = assistant_query.filter(~AssistantModel.id.in_(exclude_assistant_ids))
    
    return assistant_query.count() > 0

def is_system_instruction_used_by_other_assistants(system_instruction_id, exclude_assistant_ids=None, current_user_id=None):
    """Check if system instruction is used by any other assistants or agents except the excluded ones."""
    system_instruction = SystemInstructionModel.query.get(system_instruction_id)
    if system_instruction and system_instruction.creator_id != current_user_id:
        #If current user is not the creator, don't perform soft delete
        return True

    #Check if used by any other assistants
    assistant_query = AssistantSystemInstructionRelationModel.query.join(
        AssistantModel,
        AssistantSystemInstructionRelationModel.assistant_id == AssistantModel.id
    ).filter(
        AssistantSystemInstructionRelationModel.system_instruction_id == system_instruction_id,
        AssistantModel.deleted_at.is_(None)
    )
    
    if exclude_assistant_ids:
        assistant_query = assistant_query.filter(~AssistantModel.id.in_(exclude_assistant_ids))
    
    if assistant_query.count() > 0:
        return True

    #Check if used by any agents
    agent_query = AgentSystemInstructionRelationModel.query.join(
        AgentModel,
        AgentSystemInstructionRelationModel.agent_id == AgentModel.id
    ).filter(
        AgentSystemInstructionRelationModel.system_instruction_id == system_instruction_id,
        AgentModel.deleted_at.is_(None)
    )
    
    return agent_query.count() > 0

def is_system_instruction_used_by_other_agents(system_instruction_id, exclude_agent_ids=None, current_user_id=None):
    """Check if system instruction is used by any other agents or assistants except the excluded ones."""
    system_instruction = SystemInstructionModel.query.get(system_instruction_id)
    if system_instruction and system_instruction.creator_id != current_user_id:
        #If current user is not the creator, don't perform soft delete
        return True

    #Check if used by any other agents
    agent_query = AgentSystemInstructionRelationModel.query.join(
        AgentModel,
        AgentSystemInstructionRelationModel.agent_id == AgentModel.id
    ).filter(
        AgentSystemInstructionRelationModel.system_instruction_id == system_instruction_id,
        AgentModel.deleted_at.is_(None)
    )
    
    if exclude_agent_ids:
        agent_query = agent_query.filter(~AgentModel.id.in_(exclude_agent_ids))
    
    if agent_query.count() > 0:
        return True

    #Check if used by any assistants
    assistant_query = AssistantSystemInstructionRelationModel.query.join(
        AssistantModel,
        AssistantSystemInstructionRelationModel.assistant_id == AssistantModel.id
    ).filter(
        AssistantSystemInstructionRelationModel.system_instruction_id == system_instruction_id,
        AssistantModel.deleted_at.is_(None)
    )
    
    return assistant_query.count() > 0

 