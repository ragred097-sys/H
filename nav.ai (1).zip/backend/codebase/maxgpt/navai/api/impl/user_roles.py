from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import select

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import database
from maxgpt.services.database_model import UserApplicationAccessRoleRelationModel
from maxgpt.services.data_model.authorization import ApplicationAccessRoleModel
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('NavAIAccessRoles', 
               description='Returns access roles for all users.',
               path='/navai/access-roles')

# Response models
role_model = ns.model('Role', {
    'id': fields.String(description="ID of the role"),
    'name': fields.String(description="Name of the role"),
    'description': fields.String(description="Description of the role")
})

# Request model
batch_user_roles_request_model = ns.model('BatchUserRolesRequest', {
    'userIds': fields.List(fields.String(description="List of user IDs", required=True))
})

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class NavAIBatchUserRolesEndpoint(Resource):
    @ns.doc(description="Get role information for multiple users")
    @ns.expect(batch_user_roles_request_model)
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @ns.response(401, 'Unauthorized')
    @ns.response(403, 'Forbidden')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Get role information for multiple users."""
        
        current_user = SessionContext.get_current_user()
        if not current_user:
            ns.abort(401, "Authentication required")

        data = request.get_json()
        requested_user_ids = data.get('userIds', [])
        if not requested_user_ids:
            ns.abort(400, "No user IDs provided")
        
        user_roles = {}
        for user_id in requested_user_ids:
            roles = self._get_user_roles(user_id)
            user_roles[user_id] = roles

        return jsonify(user_roles)

    def _is_user_admin(self, user_id: str) -> bool:
        """Check if user has admin role"""
        try:
            admin_role = ApplicationAccessRoleModel.query.filter_by(
                name='ADMIN',
                deleted_at=None  # Only consider non-deleted roles
            ).first()
            if not admin_role:
                return False
                
            return UserApplicationAccessRoleRelationModel.query.filter_by(
                user_id=user_id,
                application_access_role_id=admin_role.id,
                deleted_at=None  # Only consider non-deleted relations
            ).first() is not None
        except Exception as e:
            print(f"Error checking admin status: {e}")
            return False

    def _get_user_roles(self, user_id: str) -> list:
        """Get roles for a specific user"""
        try:
            roles = UserApplicationAccessRoleRelationModel.query.filter_by(
                user_id=user_id,
                deleted_at=None  # Only consider non-deleted relations
            ).all()
            
            return [{
                'id': role.application_access_role.id,
                'name': role.application_access_role.name,
                'description': role.application_access_role.description
            } for role in roles if role.application_access_role.deleted_at is None]  # Only include non-deleted roles
        except Exception as e:
            print(f"Error getting user roles: {e}")
            return []

    @ns.doc(False)
    def options(self):
        return '', 200 