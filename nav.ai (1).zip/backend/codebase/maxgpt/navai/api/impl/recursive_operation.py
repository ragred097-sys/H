from flask import jsonify
from flask_restx import Namespace, Resource, fields
from datetime import datetime

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import database
from maxgpt.services.database_model import WorkspaceModel, AssistantModel, AgentModel, AgentWorkflowModel
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.navai.api.impl.utils import (
    get_workspace_assistants, get_workspace_agents, get_assistant_data_sources,
    get_workspace_agent_workflows, get_assistant_system_instructions,
    get_agent_system_instructions, is_data_source_used_by_other_assistants, 
    is_system_instruction_used_by_other_assistants, is_system_instruction_used_by_other_agents
)

ns = Namespace('NavAIRecursiveOperations',
               description="Recursive operations (delete/restore) for entities",
               path='/navai/recursive')

entities_affected_model = ns.model('AffectedEntities', {
    'workspaces': fields.Integer(description="Number of affected workspaces.", required=False),
    'assistants': fields.Integer(description="Number of affected assistants.", required=False),
    'data_sources': fields.Integer(description="Number of affected data sources.", required=False),
    'system_instructions': fields.Integer(description="Number of affected system instructions.", required=False),
    'agent_workflows': fields.Integer(description="Number of affected agent workflows.", required=False),
    'agents': fields.Integer(description="Number of affected agents.", required=False),
})

entity_model = ns.model('Entity', {
    'type': fields.String(description="Type of the entity.", required=False),
    'id': fields.String(description="Identifier of the entity.", required=False),
})

details_model = ns.model('Details', {
    'entity': fields.Nested(entity_model, description="Details of the entity.", required=False),
    'entities_affected': fields.Nested(entities_affected_model, description="Details of affected entities.", required=False),
})

operation_response_model = ns.model('OperationResponse', {
    'message': fields.String(description="Response message returned by API", required=False),
    'details': fields.Nested(details_model, description="Response message details.", required=False),
})

def process_entity_and_associated_entities(entity, current_user_id, affected_entities, operation='delete'):
    """Recursively process (delete/restore) an entity and its related entities based on entity_type"""
    if isinstance(entity, WorkspaceModel):
        affected_entities['workspaces'] += 1

        # Process workspace assistants
        assistants = get_workspace_assistants(entity.id, deleted=(operation == 'restore')) 
        for assistant in assistants:
            process_entity_and_associated_entities(assistant, current_user_id, affected_entities, operation)

        # Process workspace agents
        agents = get_workspace_agents(entity.id, deleted=(operation == 'restore'))
        for agent in agents:
            process_entity_and_associated_entities(agent, current_user_id, affected_entities, operation)

        # Process workspace agent workflows
        agent_workflows = get_workspace_agent_workflows(entity.id, deleted=(operation == 'restore'))
        for agent_workflow in agent_workflows:
            process_entity_and_associated_entities(agent_workflow, current_user_id, affected_entities, operation)

        # Process the workspace
        if operation == 'delete':
            entity.deleted_at = datetime.now()
            entity.deleted_by = current_user_id
        else:  # restore
            entity.deleted_at = None
            entity.deleted_by = None

    elif isinstance(entity, AssistantModel):
        affected_entities['assistants'] += 1

        # Check if assistant is used as root agent in any agent workflow
        if operation == 'delete':
            root_agent_workflows = AgentWorkflowModel.query.filter(
                AgentWorkflowModel.first_receiver_id == entity.id,
                AgentWorkflowModel.deleted_at.is_(None)
            ).first()
            if root_agent_workflows:
                ns.abort(400, f"Cannot delete assistant {entity.id} as it is used as root agent in one or more agent workflows")

        # Process assistant data sources
        data_sources = get_assistant_data_sources(entity.id, deleted=(operation == 'restore'))
        for data_source in data_sources:
            if operation == 'delete':
                if not is_data_source_used_by_other_assistants(data_source.id, [entity.id], current_user_id):
                    affected_entities['data_sources'] += 1
                    data_source.deleted_at = datetime.now()
                    data_source.deleted_by = current_user_id
            else:  # restore
                affected_entities['data_sources'] += 1
                data_source.deleted_at = None
                data_source.deleted_by = None

        # Process assistant system instructions
        system_instructions = get_assistant_system_instructions(entity.id, deleted=(operation == 'restore'))
        for system_instruction in system_instructions:
            if operation == 'delete':
                if not is_system_instruction_used_by_other_assistants(system_instruction.id, [entity.id], current_user_id):
                    affected_entities['system_instructions'] += 1
                    system_instruction.deleted_at = datetime.now()
                    system_instruction.deleted_by = current_user_id
            else:  # restore
                affected_entities['system_instructions'] += 1
                system_instruction.deleted_at = None
                system_instruction.deleted_by = None

        # Process the assistant
        if operation == 'delete':
            entity.deleted_at = datetime.now()
            entity.deleted_by = current_user_id
        else:  # restore
            entity.deleted_at = None
            entity.deleted_by = None

    elif isinstance(entity, AgentModel):
        affected_entities['agents'] += 1

        # Check if agent is used as root agent in any agent workflow
        if operation == 'delete':
            root_agent_workflows = AgentWorkflowModel.query.filter(
                AgentWorkflowModel.first_receiver_id == entity.id,
                AgentWorkflowModel.deleted_at.is_(None)
            ).first()
            if root_agent_workflows:
                ns.abort(400, f"Cannot delete agent {entity.id} as it is used as root agent in one or more agent workflows")

        # Process agent system instructions
        system_instructions = get_agent_system_instructions(entity.id, deleted=(operation == 'restore'))
        for system_instruction in system_instructions:
            if operation == 'delete':
                if not is_system_instruction_used_by_other_agents(system_instruction.id, [entity.id], current_user_id):
                    affected_entities['system_instructions'] += 1
                    system_instruction.deleted_at = datetime.now()
                    system_instruction.deleted_by = current_user_id
            else:  # restore
                affected_entities['system_instructions'] += 1
                system_instruction.deleted_at = None
                system_instruction.deleted_by = None

        # Process the agent
        if operation == 'delete':
            entity.deleted_at = datetime.now()
            entity.deleted_by = current_user_id
        else:  # restore
            entity.deleted_at = None
            entity.deleted_by = None

    elif isinstance(entity, AgentWorkflowModel):
        affected_entities['agent_workflows'] += 1

        # Process the agent workflow
        if operation == 'delete':
            entity.deleted_at = datetime.now()
            entity.deleted_by = current_user_id
        else:  # restore
            entity.deleted_at = None
            entity.deleted_by = None

@ns.route('/<entity_type>/<entity_id>', methods=['DELETE', 'PATCH','OPTIONS'])
class RecursiveOperationEndpoint(Resource):  
    @ns.doc("recursive_delete_entity")
    @ns.response(200, 'Success', operation_response_model)
    @ns.response(404, 'Entity not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, entity_type, entity_id):
        """Recursively delete an entity and its associated entities.""" 
        return self._process_entity(entity_type, entity_id, 'delete')

    @ns.doc("recursive_restore_entity")
    @ns.response(200, 'Success', operation_response_model)
    @ns.response(404, 'Entity not found')
    @requires_database_session
    @propagate_principal()
    def patch(self, entity_type, entity_id):
        """Recursively restore an entity and its associated entities."""
        return self._process_entity(entity_type, entity_id, 'restore')

    def _process_entity(self, entity_type, entity_id, operation):
        """Common processing logic for both delete and restore operations"""
        current_user = SessionContext.get_current_user()
        if not current_user:
            ns.abort(401, "Authentication required")

        # Initialize counters for affected entities
        affected_entities = {
            'workspaces': 0,
            'assistants': 0,
            'data_sources': 0,
            'system_instructions': 0,
            'agent_workflows': 0,
            'agents': 0
        }

        # Get the entity based on type
        entity = None 
        if entity_type.lower() == 'workspace':
            entity = WorkspaceModel.query.get(entity_id)
        elif entity_type.lower() == 'assistant':
            entity = AssistantModel.query.get(entity_id)
        elif entity_type.lower() == 'agent':
            entity = AgentModel.query.get(entity_id)
        elif entity_type.lower() == 'agentworkflow':
            entity = AgentWorkflowModel.query.get(entity_id)
        else:
            ns.abort(400, f"Invalid entity type: {entity_type}")

        if not entity:
            ns.abort(404, f"Entity not found: {entity_id}")

        # Check if user has permission
        if entity.creator_id != current_user.get_id():
            ns.abort(403, f"Not authorized to {operation} entity: {entity_id}")

        # Process entity and its associated entities
        process_entity_and_associated_entities(entity, current_user.get_id(), affected_entities, operation)  
        database.session.commit()

        operation_message = "deleted" if operation == 'delete' else "restored"
        return jsonify({
            'message': f"Successfully {operation_message} {entity_type} and its associated entities",
            'details': {
                'entity': {
                    'type': entity_type,
                    'id': entity_id
                },
                'entities_affected': affected_entities
            }
        })
    
    @ns.doc(False)
    def options(self, entity_type: str, entity_id: str):
        # Handle preflight OPTIONS request
        return '', 200