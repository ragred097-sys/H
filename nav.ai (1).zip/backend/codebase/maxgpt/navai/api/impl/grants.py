from flask import request, jsonify, Response
from flask_restx import Namespace, Resource, fields
from sqlalchemy import select

from maxgpt.api.internal.utils import requires_database_session, propagate_principal, get_user_access_for
from maxgpt.services import database
from maxgpt.services.database_model import (
    AccessPermissionModel, AccessPermissionSubject, AccessPermissionAssigneeType,
    PermissionType, AssistantModel, DataSourceModel, SystemInstructionModel,
    WorkspaceAssistantRelationModel, AssistantDataSourceRelationModel,
    AssistantSystemInstructionRelationModel, WorkspaceModel, AgentWorkflowModel,
    WorkspaceAgentWorkflowRelationModel, AgentWorkflowAssistantRelationModel,
    AgentModel, WorkspaceAgentRelationModel, AgentSystemInstructionRelationModel
)
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('NavAIPermissions', 
               description='Entity-specific share operations with users and roles',
               path='/navai/grants')

# Response models
access_permission_model = ns.model('AccessPermission', {
    'subject_type': fields.String(description="Type of the subject (WORKSPACE, ASSISTANT, etc.)"),
    'subject_id': fields.String(description="ID of the subject"),
    'assignee_type': fields.String(description="Type of the assignee (USER, ROLE)"),
    'assignee_id': fields.String(description="ID of the assignee"),
    'access_level': fields.String(description="Access level (READ, WRITE, ADMIN)")
})

success_response_model = ns.model('SuccessResponse', {
    'message': fields.String(description="Success message"),
    'details': fields.Raw(description="Detailed information about the operation")
})

# Request models
permission_model = ns.model('Permission', {
    'userId': fields.String(description="ID of the user", required=True),
    'permissionType': fields.String(description="Type of permission (READ, WRITE, ADMIN)", required=True)
})

role_permission_model = ns.model('RolePermission', {
    'roleId': fields.String(description="ID of the role", required=True),
    'permissionType': fields.String(description="Type of permission (READ, WRITE, ADMIN)", required=True)
})

batch_grant_request_model = ns.model('BatchGrantRequest', {
    'userPermissions': fields.List(fields.Nested(permission_model)),
    'rolePermissions': fields.List(fields.Nested(role_permission_model))
})

# Request models for DELETE
delete_permissions_request_model = ns.model('DeletePermissionsRequest', {
    'userIds': fields.List(fields.String(description="ID of the user", required=True)),
    'roleIds': fields.List(fields.String(description="ID of the role", required=True))
})

def _get_subject(subject_type, subject_id):
    """Get the subject entity based on type and ID."""
    if subject_type == AccessPermissionSubject.WORKSPACE:
        return WorkspaceModel.query.get(subject_id)
    elif subject_type == AccessPermissionSubject.ASSISTANT:
        return AssistantModel.query.get(subject_id)
    elif subject_type == AccessPermissionSubject.DATA_SOURCE:
        return DataSourceModel.query.get(subject_id)
    elif subject_type == AccessPermissionSubject.SYSTEM_INSTRUCTION:
        return SystemInstructionModel.query.get(subject_id)
    elif subject_type == AccessPermissionSubject.AGENT_WORKFLOW:
        return AgentWorkflowModel.query.get(subject_id)
    elif subject_type == AccessPermissionSubject.AGENT:
        return AgentModel.query.get(subject_id)
    return None

def _get_workspace_assistants(workspace_id):
    """Get all assistants in a workspace."""
    return AssistantModel.query.join(
        WorkspaceAssistantRelationModel,
        AssistantModel.id == WorkspaceAssistantRelationModel.assistant_id
    ).filter(
        WorkspaceAssistantRelationModel.workspace_id == workspace_id
    ).all()

def _get_workspace_agent_workflows(workspace_id):
    """Get all agent workflows in a workspace."""
    return AgentWorkflowModel.query.join(
        WorkspaceAgentWorkflowRelationModel,
        AgentWorkflowModel.id == WorkspaceAgentWorkflowRelationModel.agent_workflow_id
    ).filter(
        WorkspaceAgentWorkflowRelationModel.workspace_id == workspace_id
    ).all()

def _get_workspace_agents(workspace_id):
    """Get all agents in a workspace."""
    return AgentModel.query.join(
        WorkspaceAgentRelationModel,
        AgentModel.id == WorkspaceAgentRelationModel.agent_id
    ).filter(
        WorkspaceAgentRelationModel.workspace_id == workspace_id
    ).all()

def _get_agent_workflow_assistants(agent_workflow_id):
    """Get all assistants in an agent workflow."""
    return AssistantModel.query.join(
        AgentWorkflowAssistantRelationModel,
        AssistantModel.id == AgentWorkflowAssistantRelationModel.assistant_id
    ).filter(
        AgentWorkflowAssistantRelationModel.agent_workflow_id == agent_workflow_id
    ).all()

def _get_assistant_data_sources(assistant_id):
    """Get all data sources for an assistant."""
    return DataSourceModel.query.join(
        AssistantDataSourceRelationModel,
        DataSourceModel.id == AssistantDataSourceRelationModel.data_source_id
    ).filter(
        AssistantDataSourceRelationModel.assistant_id == assistant_id
    ).all()

def _get_assistant_system_instructions(assistant_id):
    """Get all system instructions for an assistant."""
    return SystemInstructionModel.query.join(
        AssistantSystemInstructionRelationModel,
        SystemInstructionModel.id == AssistantSystemInstructionRelationModel.system_instruction_id
    ).filter(
        AssistantSystemInstructionRelationModel.assistant_id == assistant_id
    ).all()

def _get_assistant_agent_workflows(assistant_id):
    """Get all agent workflows that contain this assistant."""
    return AgentWorkflowModel.query.join(
        AgentWorkflowAssistantRelationModel,
        AgentWorkflowModel.id == AgentWorkflowAssistantRelationModel.agent_workflow_id
    ).filter(
        AgentWorkflowAssistantRelationModel.assistant_id == assistant_id
    ).all()

def _get_agent_system_instructions(agent_id):
    """Get all system instructions for an agent."""
    return SystemInstructionModel.query.join(
        AgentSystemInstructionRelationModel,
        SystemInstructionModel.id == AgentSystemInstructionRelationModel.system_instruction_id
    ).filter(
        AgentSystemInstructionRelationModel.agent_id == agent_id
    ).all()

def _process_permissions(subject_type, subject_id, user_permissions, role_permissions, is_update=False):
    """Process user and role permissions for a subject."""
    created_grants = []
    
    # Process user permissions
    for perm in user_permissions:
        if not perm.get('userId') or not perm.get('permissionType'):
            ns.abort(400, "User ID and permission type are required for each user permission")
            
        try:
            access_level = PermissionType[perm['permissionType']]
        except KeyError:
            ns.abort(400, f"Invalid permission type: {perm['permissionType']}")

        # Check if permission already exists
        existing_permission = AccessPermissionModel.query.filter_by(
            subject_type=subject_type,
            subject_id=subject_id,
            assignee_type=AccessPermissionAssigneeType.USER,
            assignee_id=perm['userId']
        ).first()

        if existing_permission:
            if is_update:
                # Update existing permission
                existing_permission.access_level = access_level
                created_grants.append(existing_permission)
        else:
            # Create new permission
            new_permission = AccessPermissionModel(
                subject_type=subject_type,
                subject_id=subject_id,
                assignee_type=AccessPermissionAssigneeType.USER,
                assignee_id=perm['userId'],
                access_level=access_level
            )
            database.session.add(new_permission)
            created_grants.append(new_permission)

    # Process role permissions
    for perm in role_permissions:
        if not perm.get('roleId') or not perm.get('permissionType'):
            ns.abort(400, "Role ID and permission type are required for each role permission")
            
        try:
            access_level = PermissionType[perm['permissionType']]
        except KeyError:
            ns.abort(400, f"Invalid permission type: {perm['permissionType']}")

        # Check if permission already exists
        existing_permission = AccessPermissionModel.query.filter_by(
            subject_type=subject_type,
            subject_id=subject_id,
            assignee_type=AccessPermissionAssigneeType.ACCESS_ROLE,
            assignee_id=perm['roleId']
        ).first()

        if existing_permission:
            if is_update:
                # Update existing permission
                existing_permission.access_level = access_level
                created_grants.append(existing_permission)
        else:
            # Create new permission
            new_permission = AccessPermissionModel(
                subject_type=subject_type,
                subject_id=subject_id,
                assignee_type=AccessPermissionAssigneeType.ACCESS_ROLE,
                assignee_id=perm['roleId'],
                access_level=access_level
            )
            database.session.add(new_permission)
            created_grants.append(new_permission)
    
    return created_grants

def _share_entity(entity, user_permissions, role_permissions, created_grants, is_update=False):
    """Share an entity with the given permissions."""
    subject_type = AccessPermissionSubject.by_subject_instance(entity)
    
    #Process permissions based on add or update
    new_grants = _process_permissions(subject_type, entity.id, user_permissions, role_permissions, is_update)
    created_grants.extend(new_grants)

def _convert_entity_type(entity_type: str) -> str:
    """Convert frontend entity type to match AccessPermissionSubject enum values."""
    type_mapping = {
        'Workspace': WorkspaceModel,
        'Assistant': AssistantModel,
        'DataSource': DataSourceModel,
        'SystemInstruction': SystemInstructionModel,
        'AgentWorkflow': AgentWorkflowModel,
        'Agent': AgentModel
    }
    model_class = type_mapping.get(entity_type)
    if model_class:
        return AccessPermissionSubject.by_subject_class(model_class).name
    return entity_type.upper()

def _handle_permissions_request(entity_type, entity_id, user_permissions, role_permissions, is_update=False):
    """Handle permissions request for an entity and its related entities."""
    current_user = SessionContext.get_current_user()
    if not current_user:
        ns.abort(401, "Authentication required")

    try:
        subject_type = AccessPermissionSubject[_convert_entity_type(entity_type)]
    except KeyError:
        ns.abort(400, f"Invalid entity type: {entity_type}")

    entity = _get_subject(subject_type, entity_id)
    if not entity:
        ns.abort(404, f"Entity not found: {entity_id}")

    if entity.creator_id != current_user.get_id():
        ns.abort(403, f"Not authorized to update entity: {entity_id}")

    created_grants = []
    affected_entities = {
        'workspaces': set(),
        'assistants': set(),
        'data_sources': set(),
        'system_instructions': set(),
        'agent_workflows': set(),
        'agents': set()
    }

    def process_entity_and_related(entity, user_perms, role_perms):
        """Process permissions for an entity and its related entities recursively."""
        if isinstance(entity, WorkspaceModel):
            affected_entities['workspaces'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)

            # Get all assistants in the workspace
            workspace_assistants = (
                AssistantModel.query
                .join(WorkspaceAssistantRelationModel)
                .filter(WorkspaceAssistantRelationModel.workspace_id == entity.id)
                .all()
            )
            
            for assistant in workspace_assistants:
                process_entity_and_related(assistant, user_perms, role_perms)

            # Get all agents in the workspace
            workspace_agents = (
                AgentModel.query
                .join(WorkspaceAgentRelationModel)
                .filter(WorkspaceAgentRelationModel.workspace_id == entity.id)
                .all()
            )
            
            for agent in workspace_agents:
                process_entity_and_related(agent, user_perms, role_perms)

            # Get all agent workflows in the workspace
            workspace_workflows = (
                AgentWorkflowModel.query
                .join(WorkspaceAgentWorkflowRelationModel)
                .filter(WorkspaceAgentWorkflowRelationModel.workspace_id == entity.id)
                .all()
            )
            
            for workflow in workspace_workflows:
                affected_entities['agent_workflows'].add(workflow.id)
                _share_entity(workflow, user_perms, role_perms, created_grants, is_update)

        elif isinstance(entity, AssistantModel):
            affected_entities['assistants'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)

            # Get data sources
            data_sources = (
                DataSourceModel.query
                .join(AssistantDataSourceRelationModel)
                .filter(AssistantDataSourceRelationModel.assistant_id == entity.id)
                .all()
            )
            
            for data_source in data_sources:
                affected_entities['data_sources'].add(data_source.id)
                _share_entity(data_source, user_perms, role_perms, created_grants, is_update)

            # Get system instructions
            system_instructions = (
                SystemInstructionModel.query
                .join(AssistantSystemInstructionRelationModel)
                .filter(AssistantSystemInstructionRelationModel.assistant_id == entity.id)
                .all()
            )
            
            for instruction in system_instructions:
                affected_entities['system_instructions'].add(instruction.id)
                _share_entity(instruction, user_perms, role_perms, created_grants, is_update)

        elif isinstance(entity, AgentModel):
            affected_entities['agents'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)

            # Get system instructions associated with the agent
            system_instructions = _get_agent_system_instructions(entity.id)
            for instruction in system_instructions:
                affected_entities['system_instructions'].add(instruction.id)
                _share_entity(instruction, user_perms, role_perms, created_grants, is_update)

        elif isinstance(entity, AgentWorkflowModel):
            affected_entities['agent_workflows'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)

            # Get all assistants associated with the agent-workflow
            agent_workflow__assistants = (
                AssistantModel.query
                .join(AgentWorkflowAssistantRelationModel)
                .filter(AgentWorkflowAssistantRelationModel.agent_workflow_id == entity.id)
                .all()
            )

            for agent_workflow__assistant in agent_workflow__assistants:
                process_entity_and_related(agent_workflow__assistant, user_perms, role_perms)

        elif isinstance(entity, DataSourceModel):
            affected_entities['data_sources'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)

        elif isinstance(entity, SystemInstructionModel):
            affected_entities['system_instructions'].add(entity.id)
            _share_entity(entity, user_perms, role_perms, created_grants, is_update)
        
            assistants = (
                AssistantModel.query
                .join(AssistantSystemInstructionRelationModel)
                .filter(AssistantSystemInstructionRelationModel.system_instruction_id == entity.id)
                .all()
            )

            agents = (
                AgentModel.query
                .join(AgentSystemInstructionRelationModel)
                .filter(AgentSystemInstructionRelationModel.system_instruction_id == entity.id)
                .all()
            )

            
    # Start recursive processing
    process_entity_and_related(entity, user_permissions, role_permissions)
 
    try:
        database.session.commit()
        return {
            "message": "Permissions updated successfully",
            "details": {
                "entity": {
                    "type": entity_type,
                    "id": entity_id
                },
                "users_updated": [p['userId'] for p in user_permissions],
                "roles_updated": [p['roleId'] for p in role_permissions],
                "affected_entities": {
                    "workspaces": len(affected_entities['workspaces']),
                    "assistants": len(affected_entities['assistants']),
                    "data_sources": len(affected_entities['data_sources']),
                    "system_instructions": len(affected_entities['system_instructions']),
                    "agent_workflows": len(affected_entities['agent_workflows']),
                    "agents": len(affected_entities['agents'])
                }
            }
        }
    except Exception as e:
        database.session.rollback()
        ns.abort(500, f"Failed to update entity permissions: {str(e)}")

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class EntityShareEndpoint(Resource):
    @ns.doc(description="Share entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) with users and roles",
            params={
                'entityType': {
                    'description': 'Type of entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT)',
                    'in': 'query',
                    'type': 'string',
                    'required': True
                },
                'entityId': {
                    'description': 'ID of the entity to share',
                    'in': 'query',
                    'type': 'string',
                    'required': True
                }
            })
    @ns.expect(batch_grant_request_model)
    @ns.response(200, 'Success', success_response_model)
    @ns.response(400, 'Bad request')
    @ns.response(401, 'Unauthorized')
    @ns.response(403, 'Forbidden')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Share entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) with users and roles."""
        data = request.get_json()
        entity_type = request.args.get('entityType')
        entity_id = request.args.get('entityId')
        user_permissions = data.get('userPermissions', [])
        role_permissions = data.get('rolePermissions', [])
        
        if not entity_type or not entity_id:
            ns.abort(400, "Entity type and ID are required")
            
        return jsonify(_handle_permissions_request(entity_type, entity_id, user_permissions, role_permissions))

    @ns.doc(False)
    def options(self):
        response = Response()
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response

@ns.route('/<string:entity_type>/<string:entity_id>', strict_slashes=False, methods=['PUT', 'DELETE', 'OPTIONS'])
class EntityPermissionsEndpoint(Resource):
    @ns.doc(description="Update share permissions for an entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) and its related entities")
    @ns.expect(batch_grant_request_model)
    @ns.response(200, 'Success', success_response_model)
    @ns.response(400, 'Bad request')
    @ns.response(401, 'Unauthorized')
    @ns.response(403, 'Forbidden')
    @ns.response(404, 'Not found')
    @requires_database_session
    @propagate_principal()
    def put(self, entity_type, entity_id):
        """Update share permissions for an entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) and its related entities."""
        data = request.get_json()
        user_permissions = data.get('userPermissions', [])
        role_permissions = data.get('rolePermissions', [])
        
        return jsonify(_handle_permissions_request(entity_type, entity_id, user_permissions, role_permissions, is_update=True))

    @ns.doc(description="Delete specific permissions for an entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) and its related entities")
    @ns.expect(delete_permissions_request_model)
    @ns.response(200, 'Success', success_response_model)
    @ns.response(400, 'Bad request')
    @ns.response(401, 'Unauthorized')
    @ns.response(403, 'Forbidden')
    @ns.response(404, 'Not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, entity_type, entity_id):
        """Delete specific permissions for an entity (WORKSPACE, ASSISTANT, DATA_SOURCE, SYSTEM_INSTRUCTION, AGENT) and its related entities."""
        current_user = SessionContext.get_current_user()
        if not current_user:
            ns.abort(401, "Authentication required")

        # Validate entity type
        try:
            subject_type = AccessPermissionSubject[_convert_entity_type(entity_type)]
        except KeyError:
            ns.abort(400, f"Invalid entity type: {entity_type}")

        # Get the entity
        entity = _get_subject(subject_type, entity_id)
        if not entity:
            ns.abort(404, f"Entity not found: {entity_id}")

        # Check if user is the creator of the entity
        if entity.creator_id != current_user.get_id():
            ns.abort(403, f"Not authorized to delete permissions for entity: {entity_id}. Only the creator can delete permissions.")

        # Get request data
        data = request.get_json()
        user_ids = data.get('userIds', [])
        role_ids = data.get('roleIds', [])

        if not user_ids and not role_ids:
            ns.abort(400, "No user or role IDs provided in request")

        affected_entities = {
            'workspaces': [],
            'assistants': [],
            'data_sources': [],
            'system_instructions': [],
            'agent_workflows': [],
            'agents': []
        }

        try:
            # Helper function to delete permissions for a specific entity
            def _delete_permissions(subject_type, subject_id, user_ids, role_ids):
                if user_ids:
                    AccessPermissionModel.query.filter(
                        AccessPermissionModel.subject_type == subject_type,
                        AccessPermissionModel.subject_id == subject_id,
                        AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.USER,
                        AccessPermissionModel.assignee_id.in_(user_ids)
                    ).delete(synchronize_session=False)

                if role_ids:
                    AccessPermissionModel.query.filter(
                        AccessPermissionModel.subject_type == subject_type,
                        AccessPermissionModel.subject_id == subject_id,
                        AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.ACCESS_ROLE,
                        AccessPermissionModel.assignee_id.in_(role_ids)
                    ).delete(synchronize_session=False)

            # Delete permissions for the main entity
            _delete_permissions(subject_type, entity_id, user_ids, role_ids)

            # Track affected entities
            if subject_type == AccessPermissionSubject.WORKSPACE:
                affected_entities['workspaces'].append(entity_id)

                # Delete permissions for workspace assistants
                workspace_assistants = _get_workspace_assistants(entity_id)
                for assistant in workspace_assistants:
                    _delete_permissions(AccessPermissionSubject.ASSISTANT, assistant.id, user_ids, role_ids)
                    affected_entities['assistants'].append(assistant.id)

                    # Delete permissions for assistant's data sources
                    data_sources = _get_assistant_data_sources(assistant.id)
                    for data_source in data_sources:
                        _delete_permissions(AccessPermissionSubject.DATA_SOURCE, data_source.id, user_ids, role_ids)
                        affected_entities['data_sources'].append(data_source.id)

                    # Delete permissions for assistant's system instructions
                    system_instructions = _get_assistant_system_instructions(assistant.id)
                    for system_instruction in system_instructions:
                        _delete_permissions(AccessPermissionSubject.SYSTEM_INSTRUCTION, system_instruction.id, user_ids, role_ids)
                        affected_entities['system_instructions'].append(system_instruction.id)

                # Delete permissions for workspace agents
                workspace_agents = _get_workspace_agents(entity_id)
                for agent in workspace_agents:
                    _delete_permissions(AccessPermissionSubject.AGENT, agent.id, user_ids, role_ids)
                    affected_entities['agents'].append(agent.id)

                # Delete permissions for workspace agent workflows
                workspace_agent_workflows = _get_workspace_agent_workflows(entity_id)
                for agent_workflow in workspace_agent_workflows:
                    _delete_permissions(AccessPermissionSubject.AGENT_WORKFLOW, agent_workflow.id, user_ids, role_ids)
                    affected_entities['agent_workflows'].append(agent_workflow.id)

            elif subject_type == AccessPermissionSubject.ASSISTANT:
                affected_entities['assistants'].append(entity_id)

                # Delete permissions for assistant's data sources
                data_sources = _get_assistant_data_sources(entity_id)
                for data_source in data_sources:
                    _delete_permissions(AccessPermissionSubject.DATA_SOURCE, data_source.id, user_ids, role_ids)
                    affected_entities['data_sources'].append(data_source.id)

                # Delete permissions for assistant's system instructions
                system_instructions = _get_assistant_system_instructions(entity_id)
                for system_instruction in system_instructions:
                    _delete_permissions(AccessPermissionSubject.SYSTEM_INSTRUCTION, system_instruction.id, user_ids, role_ids)
                    affected_entities['system_instructions'].append(system_instruction.id)

            elif subject_type == AccessPermissionSubject.AGENT:
                affected_entities['agents'].append(entity_id)

                # Delete permissions for agent's system instructions
                system_instructions = _get_agent_system_instructions(entity_id)
                for system_instruction in system_instructions:
                    _delete_permissions(AccessPermissionSubject.SYSTEM_INSTRUCTION, system_instruction.id, user_ids, role_ids)
                    affected_entities['system_instructions'].append(system_instruction.id)

            elif subject_type == AccessPermissionSubject.AGENT_WORKFLOW:
                affected_entities['agent_workflows'].append(entity_id)

                # Delete permission for assistants associated with agent_workflow
                agent_workflow_assistants = _get_agent_workflow_assistants(entity_id)
                for assistant in agent_workflow_assistants:
                    _delete_permissions(AccessPermissionSubject.ASSISTANT, assistant.id, user_ids, role_ids)
                    affected_entities['assistants'].append(assistant.id)

                    # Delete permissions for data-sources associated with assistant
                    data_sources = _get_assistant_data_sources(assistant.id)
                    for data_source in data_sources:
                        _delete_permissions(AccessPermissionSubject.DATA_SOURCE, data_source.id, user_ids, role_ids)
                        affected_entities['data_sources'].append(data_source.id)

                    # Delete permissions for system instructions associated with assistant
                    system_instructions = _get_assistant_system_instructions(assistant.id)
                    for system_instruction in system_instructions:
                        _delete_permissions(AccessPermissionSubject.SYSTEM_INSTRUCTION, system_instruction.id, user_ids, role_ids)
                        affected_entities['system_instructions'].append(system_instruction.id)

            elif subject_type in [AccessPermissionSubject.DATA_SOURCE, AccessPermissionSubject.SYSTEM_INSTRUCTION]:
                if subject_type == AccessPermissionSubject.DATA_SOURCE:
                    affected_entities['data_sources'].append(entity_id)
                else:
                    affected_entities['system_instructions'].append(entity_id)

            database.session.commit()
            return jsonify({
                "message": "Permissions deleted successfully",
                "details": {
                    "entity": {
                        "type": entity_type,
                        "id": entity_id
                    },
                    "users_updated": user_ids,
                    "roles_updated": role_ids,
                    "affected_entities": {
                        "workspaces": len(affected_entities['workspaces']),
                        "assistants": len(affected_entities['assistants']),
                        "data_sources": len(affected_entities['data_sources']),
                        "system_instructions": len(affected_entities['system_instructions']),
                        "agent_workflows": len(affected_entities['agent_workflows']),
                        "agents": len(affected_entities['agents'])
                    }
                }
            })
        except Exception as e:
            database.session.rollback()
            ns.abort(500, f"Failed to delete entity permissions: {str(e)}")


    @ns.doc(False)
    def options(self, entity_type, entity_id):
        response = Response()
        response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
        response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
        return response