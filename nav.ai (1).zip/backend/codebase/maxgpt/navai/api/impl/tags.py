import json

from flask import Response,request, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import _get_tag_agent_workflows, _get_tag_agents, _get_tag_assistants, _get_tag_conversations, _get_tag_data_sources, _get_tag_modules, _get_tag_system_instructions, _get_tag_widgets, _get_tag_workspaces, get_entity_count_for_tag, requires_database_session, propagate_principal, audited_model, shallow_tag_model
from maxgpt.services import database
from maxgpt.services.database_model import TagModel


ns = Namespace('NavAITags', 
               description='tags associated with NavAI entities',
               path='/navai/tag')



@ns.route('/<tag_id>/')
class NavAITagsEndpoint(Resource):
    @ns.doc("list_tags")
    @requires_database_session
    @propagate_principal()
    def get(self, tag_id):
        """Get all entity types associated with a specific tag ID."""
        #  Validate the tag exists (you must have a TagModel defined)
        tag = TagModel.query.filter(
            TagModel.id == tag_id,
            TagModel.deleted_at.is_(None)
        ).first()
        if not tag:
            ns.abort(404, f"Tag with ID '{tag_id}' not found.")
        
        # Collect all related entities
        entity_response = {
            "assistant": [e.to_dict() for e in _get_tag_assistants(tag_id) or []],
            "agent": [e.to_dict() for e in _get_tag_agents(tag_id) or []],
            "workflow": [e.to_dict() for e in _get_tag_agent_workflows(tag_id) or []],
            "conversation": [e.to_dict() for e in _get_tag_conversations(tag_id) or []],
            "data_source": [e.to_dict() for e in _get_tag_data_sources(tag_id) or []],
            "system_instruction": [e.to_dict() for e in _get_tag_system_instructions(tag_id) or []],
            "module": [e.to_dict() for e in _get_tag_modules(tag_id) or []],
            "workspace": [e.to_dict() for e in _get_tag_workspaces(tag_id) or []],
            "widget": [e.to_dict() for e in _get_tag_widgets(tag_id) or []],
        }

        return jsonify(entity_response)

    

@ns.route('s/')
class TagsNavAIEndpoint(Resource):
    @ns.doc("list_tags")
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all stored tags with the count of associated entities."""

        tags = TagModel.query.filter(TagModel.deleted_at.is_(None)).all()
        tag_list = []

        for tag in tags:
            tag_data = tag.to_dict() 
            tag_data["entity_count"] = get_entity_count_for_tag(tag.id)
            tag_list.append(tag_data)

        return jsonify(tag_list)
    
