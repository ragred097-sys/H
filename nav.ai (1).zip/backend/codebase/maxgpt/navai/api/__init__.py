from maxgpt.navai.api.main import blueprint

__all__ = ['blueprint'] 