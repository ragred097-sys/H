from flask import Blueprint
from flask_restx import Api

from maxgpt.navai.api.impl.grants import ns as permissions_ns
from maxgpt.navai.api.impl.user_roles import ns as access_roles_ns
from maxgpt.navai.api.impl.tags import ns as tags_ns
from maxgpt.navai.api.impl.recursive_operation import ns as recursive_operation_ns
from maxgpt.navai.api.impl.data_migration_tool import ns as dmt_namespace

# Create a Blueprint for NavAI API
blueprint = Blueprint('navai', __name__, url_prefix='/navai')

# Create the API instance
api = Api(blueprint,
          title='NavAI API',
          description='UI-specific operations for permissions and access roles',
          version='1.0')

# Register namespaces
api.add_namespace(permissions_ns)
api.add_namespace(access_roles_ns) 
api.add_namespace(tags_ns)
api.add_namespace(recursive_operation_ns)
api.add_namespace(dmt_namespace)