import enum

class EntityType(enum.Enum):
    ACCESS_ROLE = 'AccessRole'
    ASSISTANT = 'Assistant'
    CONVERSATION = 'Conversation'
    DATA_OBJECT = 'DataObject'
    ATTACHMENT = 'Attachment'
    DATA_SOURCE = 'DataSource'
    MESSAGE = 'Message'
    MESSAGE_PART = 'MessagePart'
    MESSAGE_EVENT = 'MessageEvent'
    MODULE = 'Module'
    MODULE_PARAMETER = 'ModuleParameter'
    PREFERENCE = 'Preference'
    SYSTEM_INSTRUCTION = 'SystemInstruction'
    TAG = 'Tag'
    USER = 'User'
    WIDGET = 'Widget'
    WORKSPACE = 'Workspace'
    AGENT_FUNCTION = 'AgentFunction'
    AGENT_WORKFLOW = 'AgentWorkflow'
    AGENT = 'Agent'
    TAG_CATEGORY = 'TagCategory'
    SHARED_CONVERSATION = 'SharedConversation'
    ASSISTANT_GOVERNANCE = 'AssistantGovernance'
    CONVERSATION_GOVERNANCE = 'ConversationGovernance'
    MODULE_CAPABILITY = 'ModuleCapability'


    @staticmethod
    def from_value(value: str) -> 'EntityType':
        try:
            return EntityType(value)
        except KeyError:
            raise ValueError(f"No JsonType found for value '{value}'.")