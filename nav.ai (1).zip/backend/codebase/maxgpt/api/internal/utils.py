import enum
import inspect
import io
import json
import logging
import os
import re
import tempfile
import threading
from datetime import datetime
from functools import wraps
from http.client import HTTPConnection
from json import JSONEncoder
from typing import Iterable, Generator, Set, Type, List, TypeVar, Dict, Optional

import cv2
import debugpy
from PIL import Image
from flask import current_app, Response, stream_with_context, abort
from flask.json.provider import DefaultJSONProvider
from flask_restx import Namespace, fields
from llama_index.core.base.llms.types import CompletionResponse, ChatResponse
from llama_index.core.schema import NodeWithScore
from pandas import DataFrame
from sqlalchemy import and_, or_, select, literal
from werkzeug.datastructures.file_storage import FileStorage
from werkzeug.exceptions import HTTPException


from maxgpt.services import database, DefaultApplicationAccessRole
from maxgpt.services.data_model.authorization import ApplicationAccessRoleModel
from maxgpt.services.data_model.user import UserModel, SystemUser
from maxgpt.services.database_model import AgentModel, ApplicationSettingModel, MessageModel, MessagePartType, AgentWorkflowModel, AgentWorkflowTagRelationModel, AssistantModel,\
    AssistantTagRelationModel, ConversationModel, ConversationTagRelationModel, DataSourceModel, DataSourceTagRelationModel, ModuleModel, ModuleTagRelationModel, PreferenceModel,\
    SystemInstructionModel, SystemInstructionTagRelationModel, \
    WidgetModel, WidgetTagRelationModel, WorkspaceModel, WorkspaceTagRelationModel,AgentTagRelationModel, \
    MessagePartModel, ExternalRoleApplicationAccessRoleMappingModel, UserApplicationAccessRoleRelationModel, \
    WorkspaceModel, SystemInstructionModel, WidgetModel, AssistantModel, PermissionType, \
    AccessPermissionModel, AccessPermissionAssigneeType, AccessPermissionSubject, IdentifiableModel, DocumentType, \
    DataSourceModel, MessageEventModel, MessageEventType, DataObjectModel, IngestProcessModel
from maxgpt.services.internal.audited_model import AuditedModel
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.security import AuthenticationException, AuthenticationProviderRegistry, AuthenticatedUser
from flask import request

import pandas as pd
import base64
from io import BytesIO
from typing import Union, BinaryIO
import mimetypes


class CustomJSONProvider(DefaultJSONProvider):
    def default(self, obj):
        if isinstance(obj, enum.Enum):
            return obj.value
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

class NonFlaskCustomJsonEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, enum.Enum):
            return obj.value
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

def format_as_ndjson(chunk: dict) -> str:
    try:
        return json.dumps(chunk, ensure_ascii=False, cls=NonFlaskCustomJsonEncoder) + "\n"
    except Exception as error:
        logging.exception("Exception while generating response stream: %s", error)
        raise error


def get_string_token(message_text: str) -> Iterable:
    return format_as_ndjson({
        "type": "string",
        "content": message_text,
        "meta": None
    })


def context_node_to_content_dict(source_node: NodeWithScore) -> dict:
    return {
        'id': source_node.node_id,
        'nodeScore': source_node.get_score(),
        'nodeText': source_node.get_text(),
        'nodeMetadataPageLabel': source_node.metadata.get('page_label', None),
        'nodeMetadataFileName': source_node.metadata.get('file_name', '<not available>'),
        'maxgptDataObjectId': source_node.metadata.get('maxgpt-data_object-id', '<not available>'),
        'maxgptDataObjectFileSystem': source_node.metadata.get('maxgpt-data_object-file_system',
                                                                   '<not available>'),
        'maxgptDataObjectMimeType': source_node.metadata.get('maxgpt-data_object-mime_type', '<not available>'),
        'maxgptFilterTag': source_node.metadata.get('maxgpt-filter-tag', None),
        'maxgptSectionSummary': source_node.metadata.get('section_summary', None)
    }

attachment_api_structure = {
    'id': fields.String(description="The id of the attachment.", required=True, readonly=True),
    'name': fields.String(description="The name of the attachment.", max_length=255, required=False),
    'mimeType': fields.String(description="The mime type of the attachment", max_length=80, required=False),
    'size': fields.Integer(description="The size of the attachment in bytes", required=False),
    'objectReference': fields.String(
        description="The object id of the attachment in the file storage (e.g. externalId, absolute filepath, ...)",
        required=True, readonly=True)
}


# Global lock dictionary
locks = {}

# Function to acquire a user-specific lock
def get_user_lock(user_id) -> threading.Lock:
    if user_id not in locks:
        locks[user_id] = threading.Lock()
    return locks[user_id]

# Function to acquire a named lock
def get_named_lock(name: str) -> threading.Lock:
    if name not in locks:
        locks[name] = threading.Lock()
    return locks[name]

@stream_with_context
def yield_token_chunks(generator: Generator[str, None, None], on_finish) -> Iterable:
    aggregated: str = ""

    try:
        for token in generator:
            if isinstance(token, CompletionResponse):
                delta = token.delta
                aggregated += delta
                yield format_as_ndjson({
                    "type": MessageEventType.CHUNK.value,
                    "content": delta,
                    "meta": None
                })
            elif isinstance(token, ChatResponse):
                delta = token.delta
                aggregated += delta
                yield format_as_ndjson({
                    "type": MessageEventType.CHUNK.value,
                    "content": delta,
                    "meta": None
                })
            else:
                aggregated += token
                yield format_as_ndjson({
                    "type": MessageEventType.CHUNK.value,
                    "content": token,
                    "meta": None
                })
    except GeneratorExit:
        logging.log(logging.INFO, "Client disconnected during response stream")
        raise
    except Exception as error:
        logging.log(logging.ERROR, "Exception while generating response stream: %s", error)
        error_details = f"Exception while generating response stream: {error}"
        aggregated = error_details
        yield json.dumps({
            "type": MessageEventType.ERROR.value,
            "content": error_details,
            "meta": None
        }) + "\n"
    finally:
        if on_finish:
            if aggregated is None or aggregated.strip() == "":
                aggregated = "Oh no! Your LLM ran into an issue. Try catching one of the admins of this application to check the server logs for details."
            yield from on_finish(aggregated)


import asyncio

def convert_async_generator(async_gen):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    return loop.run_until_complete(collect_async_results(async_gen))

async def collect_async_results(async_gen):
    results = []

    # ChatGPT comment: Check if async_gen is a coroutine (not an async generator)
    if inspect.iscoroutine(async_gen):
        async_gen = await async_gen  # ChatGPT comment: Await it properly before iteration

    async for item in async_gen:  # ChatGPT comment: Now it's safe to iterate
        results.append(item)

    return results

# TODO: make this configurable
def is_source_node_relevant (source_node: NodeWithScore) -> bool:
    return source_node.metadata and source_node.score > 0.5

def generate_citation_from(source_node: NodeWithScore):
    #return  {"source": source_node["source"], "url": source_node["url"]}
    metadata = source_node.metadata
    return  {"source": source_node.metadata}

def generate_citations_from(source_nodes: List[NodeWithScore]) -> list:
    return [
        generate_citation_from(source_node)
        for source_node in source_nodes
        if is_source_node_relevant(source_node)
    ]

@stream_with_context
def yield_string_chunk(content: str) -> Iterable:
    yield format_as_ndjson({
        "type": MessageEventType.CHUNK.value,
        "content": content,
        "meta": None
    })

def with_message_events(message_dict: dict) -> dict:
    _events: List[MessageEventModel] = MessageEventModel.query.filter_by(message_id=message_dict['id']).order_by(MessageEventModel.sequence).all()
    message_dict['events'] = []
    for _event in _events:
        event_dict = {
            "type": _event.type.value,
            "content": json.loads(_event.content),
            "meta": json.loads(_event.meta) if _event.meta else None,
            "sequence": _event.sequence
        }
        message_dict['events'].append(event_dict)
    return message_dict

def with_conversation_details(shared_conversation: dict) -> dict:
    _conversation: ConversationModel = ConversationModel.query.filter_by(id=shared_conversation['conversationId']).first()
    if _conversation:
        shared_conversation['conversationCreatedOn'] = _conversation.created_at
        shared_conversation['conversationName'] = _conversation.name
    return shared_conversation

@stream_with_context
def yield_message_object(object: MessageModel) -> Iterable:
    try:
        yield format_as_ndjson({
            "type": "message",
            "content": with_message_events(object.to_dict()),
            "meta": None
        })
    except Exception as error:
        logging.log(logging.ERROR, "Exception while generating response stream: %s", error)
        error_details = f"Exception while generating response stream: {error}"
        yield json.dumps({
            "type": MessageEventType.ERROR.value,
            "content": error_details,
            "meta": None
        }) + "\n"

@stream_with_context
def yield_context_nodes(source_nodes: List[NodeWithScore]) -> Iterable:
    try:
        for source_node in source_nodes:
            yield format_as_ndjson({
                "type": MessageEventType.CONTEXT_NODE.value,
                "content": context_node_to_content_dict(source_node),
                "meta": None
            })
    except Exception as error:
        logging.log(logging.ERROR, "Exception while generating response stream: %s", error)
        error_details = f"Exception while generating response stream: {error}"
        yield json.dumps({
            "type": MessageEventType.ERROR.value,
            "content": error_details,
            "meta": None
        }) + "\n"


def handle_exception(err):
    """ Catching all exceptions and serialize them properly for the clients. """

    # We search for a human-readable message in different places. In case of http errors, we can make use of the error
    # inside the response attribute of the exception. Otherwise, we to get the most verbose messages from the args.
    # The last check and fallback is a description of the error if existing. This might not be verbose, but it still
    # provides more information than just 500: Internal Error
    # In case the error comes with a code directly, we use that one as default (that is in case of HttpErrors)
    if isinstance(err, AuthenticationException):
        # something went wrong with the token (timeout etc.) so we inform the client
        # about authenticating properly
        message = err.get_description()
        code = 401
    elif isinstance(err, HTTPException):
        message = err.description
        code = err.code
    elif hasattr(err, "response") and err.response is not None:
        message = json.loads(err.response.text)["error"]["message"]
        code = err.response.status_code
    else:
        message = str(err)
        code = 500
    return {"message": message, "code": code}, code

def add_cors_headers(response, trusted_origins=None):
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS,PATCH')   
    request_origin = request.headers.get('Origin')  
    if trusted_origins and request_origin:
        if request_origin in trusted_origins:
            response.headers.add('Access-Control-Allow-Origin', request_origin)
    response.headers.add('Access-Control-Allow-Credentials', 'true')
       
    return response


def set_mimetype(mimetype):
    """
    :param mimetype: mime type as string
    :return: A Response with the annotated mimetype
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            result = f(*args, **kwargs)
            return Response(result, mimetype=mimetype)

        return decorated_function

    return decorator

def data_source_to_dict(data_source: DataSourceModel) -> dict:
    result = data_source.to_dict()

    ingested_files: List[DataObjectModel] = []
    for process in IngestProcessModel.query.filter(IngestProcessModel.data_source_id == data_source.id).all():
        ingested_files = ingested_files + DataObjectModel.query.filter(DataObjectModel.ingest_process_id == process.id).all()

    result.update({
        'ingestedFiles': [do.to_dict() for do in ingested_files]
    })
    return result

def propagate_principal(allowed_app_role_names: [str] = None):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            from flask import request   # local import to avoid shadowing
            access_token = AuthenticationProviderRegistry.get_authenticator().authenticate_user(request)

            if access_token:
                # check if user exists on our side and - if not - create it
                token_account_id = AuthenticationProviderRegistry.get_authenticator().get_account_id(access_token)
                with (get_user_lock(token_account_id)):
                    if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                        logging.debug("MUTEX ACQUIRED: Get or create application user")
                    user = UserModel.query.filter(UserModel.account_id == token_account_id).first()
                    if not user:
                        token_display_name = AuthenticationProviderRegistry.get_authenticator().get_display_name(access_token)
                        token_email = AuthenticationProviderRegistry.get_authenticator().get_email(access_token)
                        user = UserModel(account_id=token_account_id, display_name=token_display_name, email=token_email)
                        database.session.add(user)
                        database.session.commit()

                        # By default, every new user is granted application access as USER
                        default_role_mapping = UserApplicationAccessRoleRelationModel(user_id=user.id,
                                                                                      application_access_role_id=DefaultApplicationAccessRole.MAXGPT_USER.value,
                                                                                      creator_id=SystemUser.ID)
                        database.session.add(default_role_mapping)
                        database.session.commit()
                    else:
                        # We check for updates provided by the IDP and keep our records in sync
                        token_display_name = AuthenticationProviderRegistry.get_authenticator().get_display_name(access_token)
                        token_email = AuthenticationProviderRegistry.get_authenticator().get_email(access_token)
                        if (user.display_name != token_display_name) or (user.email != token_email):
                            logging.debug("User record out of sync - updating user record")
                            user.display_name = token_display_name
                            user.email = token_email
                            database.session.commit()

                    """
                    If the annotated web service is restricted to certain application roles, we have to verify access 
                    for the current user in the following way:
                        1. Get AD roles of user from bearer token
                        2. Translate AD roles to Application Access Roles by querying the db relations
                        2b. Add directly assigned Application Roles of the user to the list of 2.
                        3. Check if the application access roles of a user is inside the allowed roles of the annotation 
                    """
                    effective_app_roles = {}

                    realm_roles: [str] = AuthenticationProviderRegistry.get_authenticator().get_roles(access_token)
                    external_app_role_mapping: [ApplicationAccessRoleModel] = (ExternalRoleApplicationAccessRoleMappingModel
                                                                          .query
                                                                          .join(ApplicationAccessRoleModel,
                                                                                ExternalRoleApplicationAccessRoleMappingModel.application_access_role_id == ApplicationAccessRoleModel.id)  # Explicit join with the related table
                                                                          .filter(
                                    ExternalRoleApplicationAccessRoleMappingModel.external_role_name.in_(realm_roles)
                                 ).all())
                    user_app_role_mapping: [ApplicationAccessRoleModel] = (UserApplicationAccessRoleRelationModel
                                 .query
                                 .join(ApplicationAccessRoleModel,
                                      UserApplicationAccessRoleRelationModel.application_access_role_id == ApplicationAccessRoleModel.id)  # Explicit join with the related table
                                 .filter(
                                     UserApplicationAccessRoleRelationModel.user_id == user.id
                                 ).all())

                    mapped_external_app_roles = [mapping.application_access_role for mapping in external_app_role_mapping]
                    mapped_user_app_roles = [mapping.application_access_role for mapping in user_app_role_mapping]

                    effective_app_roles = set(mapped_external_app_roles + mapped_user_app_roles)

                    if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
                        logging.log(logging.DEBUG, f"[Authorization check] realm roles = {realm_roles}")
                        logging.log(logging.DEBUG, f"[Authorization check] mapped app roles = {[role.name for role in mapped_external_app_roles]}")
                        logging.log(logging.DEBUG, f"[Authorization check] direct user app roles = {[role.name for role in mapped_user_app_roles]}")
                        logging.log(logging.DEBUG, f"[Authorization check] effective app roles = {[role.name for role in effective_app_roles]}")
                        logging.log(logging.DEBUG, f"[Authorization check] allowed roles = {allowed_app_role_names}")

                    if allowed_app_role_names is not None:
                        if isinstance(allowed_app_role_names, list):
                            if not set([role.name for role in effective_app_roles]) & set(allowed_app_role_names):
                                if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
                                    logging.log(logging.WARNING, f"[Authorization check] Access BLOCKED! (user: {user.id})")
                                abort(401, "Not authorized")
                            else:
                                if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
                                    logging.log(logging.DEBUG, f"[Authorization check] Access GRANTED! (user: {user.id})")
                        else:
                            logging.log(logging.WARNING, f"Annotation propagate_principal wrongly used in XXX. "
                                                         f"Argument allowed_roles must be a list of strings (role names).")

                    # detach from session to be able to access it later
                    database.session.expunge(user)
                    for effective_app_role in effective_app_roles:
                        database.session.expunge(effective_app_role)

                    SessionContext.set_current_user(AuthenticatedUser(user))
                    SessionContext.set_effective_app_roles(effective_app_roles)
                    if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                        logging.log(logging.DEBUG, "MUTEX RELEASED: Get or create application user")
            # call wrapped function
            return func(*args, **kwargs)
        return wrapper
    return decorator

def extract_video_length (file_bytes: bytes) -> float:
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tmp") as temp_video_file:
        temp_video_file.write(file_bytes)
        temp_video_path = temp_video_file.name

    cap: Optional[cv2.VideoCapture] = None
    try:
        # Open the video file with OpenCV
        cap = cv2.VideoCapture(temp_video_path)

        if not cap.isOpened():
            raise ValueError("Could not open video file.")

        # Get the total number of frames and fsp
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        # Calculate the duration in seconds
        return total_frames / fps if fps > 0 else 0
    finally:
        # Clean up the temporary video file and release the capture object
        os.remove(temp_video_path)
        if cap is not None:
            cap.release()



def convert_to_base64(data: Union[bytes, BytesIO, BinaryIO]) -> str:
    if isinstance(data, BytesIO):
        data = data.getvalue()
    elif hasattr(data, "read"):
        data = data.read()
    elif not isinstance(data, bytes):
        raise TypeError("Unsupported data type")
    return base64.b64encode(data).decode("utf-8")

def create_thumbnail_for_media_file (document_type: DocumentType, file_bytes, size=(300, 300)):
    if document_type == DocumentType.AUDIO:
        return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAAXNSR0IArs4c6QAAAHRJREFUGFcBaQCW/wGSKrj/VqB3AGzRXgBA7s4ADJbDAAElUdX/zNC0AApWSgBZI1gAXPwPAAHtgRz/MRvzAOoAegD14AYARp6tAAGQdpb/g81ZAC1c1wCZh7EATI6MAAHMayH/FM0+AAC6UwAHbNYAlnvdAMXDKY4c8ZXiAAAAAElFTkSuQmCC"
    elif document_type == DocumentType.VIDEO:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".tmp") as temp_video_file:
            temp_video_file.write(file_bytes)
            temp_video_path = temp_video_file.name

        try:
            # Open the video file with OpenCV
            cap = cv2.VideoCapture(temp_video_path)

            if not cap.isOpened():
                raise ValueError("Could not open video file.")

            # Get the total number of frames
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

            # Seek to the middle frame
            middle_frame = total_frames // 2
            cap.set(cv2.CAP_PROP_POS_FRAMES, middle_frame)

            # Read the frame
            ret, frame = cap.read()

            if not ret:
                raise ValueError("Could not read frame from video.")

            # Convert the frame to RGB (OpenCV uses BGR by default)
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            # Convert the frame to a PIL Image
            image = Image.fromarray(frame_rgb)
            image.thumbnail(size, Image.Resampling.LANCZOS)

            # Save the image to a BytesIO object
            thumbnail_bytes = io.BytesIO()
            image.save(thumbnail_bytes, format="JPEG")  # Save in JPEG format
            thumbnail_bytes.seek(0)  # Rewind to the start
            return "data:image/jpeg;base64," + convert_to_base64(thumbnail_bytes)

        finally:
            # Clean up the temporary video file and release the capture object
            os.remove(temp_video_path)
            cap.release()
    elif document_type == DocumentType.IMAGE:
        with Image.open(io.BytesIO(file_bytes)) as img:
            # Ensure the image is in RGB mode (useful for thumbnails)
            img = img.convert("RGB")

            # Create the thumbnail
            img.thumbnail(size, Image.Resampling.LANCZOS)

            # Save the thumbnail to a BytesIO object
            thumbnail_bytes = io.BytesIO()
            img.save(thumbnail_bytes, format="JPEG")  # Save in JPEG format
            thumbnail_bytes.seek(0)  # Rewind to the start

            return "data:image/jpeg;base64," + convert_to_base64(thumbnail_bytes)
    elif document_type == DocumentType.TEXT:
        return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAAXNSR0IArs4c6QAAAHRJREFUGFcBaQCW/wGSKrj/VqB3AGzRXgBA7s4ADJbDAAElUdX/zNC0AApWSgBZI1gAXPwPAAHtgRz/MRvzAOoAegD14AYARp6tAAGQdpb/g81ZAC1c1wCZh7EATI6MAAHMayH/FM0+AAC6UwAHbNYAlnvdAMXDKY4c8ZXiAAAAAElFTkSuQmCC"
    else:
        return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAAXNSR0IArs4c6QAAAHRJREFUGFcBaQCW/wGSKrj/VqB3AGzRXgBA7s4ADJbDAAElUdX/zNC0AApWSgBZI1gAXPwPAAHtgRz/MRvzAOoAegD14AYARp6tAAGQdpb/g81ZAC1c1wCZh7EATI6MAAHMayH/FM0+AAC6UwAHbNYAlnvdAMXDKY4c8ZXiAAAAAElFTkSuQmCC"


def requires_database_session(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        with current_app.app_context():
            try:
                response = f(*args, **kwargs)
                database.session.commit()
            except Exception as e:
                database.session.rollback()
                raise e
            finally:
                database.session.remove()
            return response
    return decorated_function


def setup_logger():
    log_level = os.environ.get("APP_LOG_LEVEL", "INFO")
    numeric_level = getattr(logging, log_level.upper(), None)

    if not isinstance(numeric_level, int):
        raise ValueError(f"Invalid log level '{log_level}' specified!")

    logging.basicConfig(level=numeric_level)
    logging.log(logging.INFO, "Loglevel set to " + log_level)

    '''Switches on logging of the requests module.'''
    if os.getenv("APP_ENABLE_HTTP_TRACE", 'False').lower() in ('true', '1', 't'):
        # Enable verbose http logging to trace all http requests with all details
        HTTPConnection.debuglevel = 1
        requests_log = logging.getLogger("requests.packages.urllib3")
        requests_log.setLevel(logging.DEBUG)
        requests_log.propagate = True
        logging.getLogger("httpcore.http11").setLevel(logging.DEBUG)
        logging.getLogger("httpcore.connection").setLevel(logging.DEBUG)
    else:
        logging.getLogger("httpcore.connection").setLevel(logging.INFO)
        logging.getLogger("httpcore.http11").setLevel(logging.INFO)

    # Remote Debugging?
    if os.getenv("DEBUGPY_ENABLED", 'False').lower() in ('true', '1', 't'):
        logging.log(logging.DEBUG, f"Start remote debugger on port {os.environ.get('DEBUGPY_PORT', 5678)}.")
        debugpy.listen((str(os.environ.get('DEBUGPY_HOST', "0.0.0.0")), int(os.environ.get('DEBUGPY_PORT', 5678))))
        if os.getenv("DEBUGPY_SUSPEND", 'False').lower() in ('true', '1', 't'):
            logging.log(logging.DEBUG, "Waiting for remote debugging client to connect.")
            debugpy.wait_for_client()


def add_simple_text_message(conversation, message_role, message_content):
    message = MessageModel(role=message_role, conversation=conversation)
    # message_content = message_content.encode('utf-8', errors='replace')
    message.parts.append(MessagePartModel(type=MessagePartType.TEXT, content=message_content))
    database.session.add(message)
    database.session.commit()
    return message

def add_message_event(message_id: str, sequence: int, type: MessageEventType, content: str, meta: Optional[str]):
    message_event = MessageEventModel(message_id=message_id, sequence=sequence, type=type, content=content, meta=meta)
    database.session.add(message_event)
    database.session.commit()
    return message_event


def shallow_user_model(ns: Namespace):
    return ns.model('User', {
        'id': fields.String(description="The UUID of the user.", required=True, readonly=True),
        'name': fields.String(description="The name of the user to be shown in the UI", required=False),
    })

def shallow_tag_model(ns: Namespace):
    return ns.model('Tag', {
        'id': fields.String(description="The UUID of the tag.", required=True, readonly=True),
        'name': fields.String(description="The name of the tag to be shown in the UI", required=False),
    })

def audited_model(ns: Namespace):
    return ns.model('Audited', {
        'createdAt': fields.DateTime(description="The timestamp when the conversation was created", required=True, readonly=True),
        'creator': fields.Nested(shallow_user_model(ns), description="The identifier of the user that initially created the conversation", required=True, readonly=True),
        'modifiedAt': fields.DateTime(description="The timestamp when the conversation was lastly updated", required=False, readonly=True),
        'modifier': fields.Nested(shallow_user_model(ns), description="The identifier of the user that lastly updated the conversation", required=False, readonly=True),
    })

def tagged_model(ns: Namespace):
    return ns.model('Tagged', {
        'tags': fields.List(fields.Nested(shallow_tag_model(ns)), description="The list of tags (shallow) with which this entity if tagged", required=True, readonly=True),
    })

def favorible_model(ns: Namespace):
    return ns.model('UserFavorite', {
        'favorite': fields.Boolean(description="Indicates if this object is marked as a favorite by the current user", readonly=True),
    })

def with_favorite(subject: dict, subject_ids: Set[str]):
    subject['favorite'] = subject['id'] in subject_ids
    return subject

def with_hidden(subject: dict, subject_ids: Set[str]):
    subject['hidden'] = subject['id'] in subject_ids
    return subject

def determine_document_type(file: FileStorage) -> DocumentType | None:
    mime_type = file.content_type

    if mime_type.startswith("image/") or mime_type.startswith("data:image/"):
        return DocumentType.IMAGE
    elif mime_type.startswith("video/"):
        return DocumentType.VIDEO
    elif mime_type.startswith("audio/"):
        return DocumentType.AUDIO
    elif (mime_type == "application/pdf" or mime_type == "application/msword"
        or mime_type == "application/json" or mime_type == "application/xml"
        or mime_type.startswith("text/")
        or mime_type.startswith("data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        or mime_type.startswith("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        or mime_type.startswith("data:application/json") or mime_type.startswith("data:text/")):
        return DocumentType.TEXT
    else:
        return DocumentType.TEXT

def get_user_access_for(subject: Union[WorkspaceModel, SystemInstructionModel, AssistantModel, WidgetModel, DataSourceModel]) -> PermissionType:
    result = PermissionType.FORBIDDEN # Default
    current_user = SessionContext.get_current_user()

    # 1 #
    #
    # Check if the user is either application admin or owner of the subject.
    # Both situations lead to automatic and implicit WRITE access
    if subject.creator_id == current_user.get_id():
        if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
            logging.log(logging.DEBUG, "[PERMISSION CHECK] WRITE (owner)")
        return PermissionType.WRITE

    admin_query_check = UserApplicationAccessRoleRelationModel.query.filter(
        and_(UserApplicationAccessRoleRelationModel.id == DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.name,
             UserApplicationAccessRoleRelationModel.user_id == current_user.get_id())).first()
    if admin_query_check:
        if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
            logging.log(logging.DEBUG, "[PERMISSION CHECK] WRITE (administrator role)")
        return PermissionType.WRITE

    # 2 #
    #
    # Check for direct user grants on the given subject
    direct_user_grant = AccessPermissionModel.query.filter(
        and_(AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.USER,
             AccessPermissionModel.assignee_id == current_user.get_id(),
             AccessPermissionModel.subject_id == subject.id,
             AccessPermissionModel.subject_type == AccessPermissionSubject.by_subject_instance(subject)
     )).first()

    if direct_user_grant:
        if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
            logging.log(logging.DEBUG, f"[PERMISSION CHECK] {direct_user_grant.access_level.name} (direct grant)")
        if PermissionType.rank(direct_user_grant.access_level) > PermissionType.rank(result):
            result = direct_user_grant.access_level

    # 3 #
    #
    # Check for implicit user grants on the given subject
    role_grants = AccessPermissionModel.query.filter(
        and_(AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.ACCESS_ROLE,
             AccessPermissionModel.subject_id == subject.id,
             AccessPermissionModel.subject_type == AccessPermissionSubject.by_subject_instance(subject),
             AccessPermissionModel.assignee_id.in_([role.get_id() for role in SessionContext.get_effective_app_roles()])
             )).all()
    if role_grants:
        highest_rank = PermissionType.rank(result)
        for role_grant in role_grants:
            rank = PermissionType.rank(role_grant.access_level)
            if rank > highest_rank:
                highest_rank = rank
                result = role_grant.access_level
        if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
            logging.log(logging.DEBUG, f"[PERMISSION CHECK] {result.name} (implicit grant)")

    # 4 #
    #
    # Default = FORBIDDEN
    if os.getenv("APP_ENABLE_AUTHORIZATION_TRACE", 'False').lower() in ('true', '1', 't'):
        logging.log(logging.DEBUG, f"[PERMISSION CHECK] {result.name} (default)")
    return result

def with_access_permission(subject: dict, access_level: PermissionType):
    subject['accessPermission'] = access_level.name
    return subject

T = TypeVar("T", bound=Union[IdentifiableModel, AuditedModel])

def fetch_with_permissions(
    model: Type[T],
    ids: Optional[Iterable[str]] = None,
    exclude: Optional[bool] = False
) -> List[T]:
    """
    Fetch objects of a model with permissions.

    Args:
        model: The SQLAlchemy model class (must be `Identifiable` and `Audited`)
        ids: Optional list of IDs to restrict the query.
        exclude: If True, exclude the provided IDs from the query. If False, include only the provided IDs.

    Returns:
        A list of model instances with permissions attached.
    """
    current_user = SessionContext.get_current_user()

    # query_1 = all granted access permissions for the model type and the current user that comes from
    #         - Direct user grants
    #         - Implicit grants via access groups
    query_1 = (
        select(model, AccessPermissionModel.access_level)
        .join(
            AccessPermissionModel,
            and_(
                model.id == AccessPermissionModel.subject_id,
                AccessPermissionModel.subject_type == AccessPermissionSubject.by_subject_class(model),
                or_(
                    and_(
                        AccessPermissionModel.assignee_id == current_user.get_id(),
                        AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.USER,
                    ),
                    and_(
                        AccessPermissionModel.assignee_id.in_(
                            [role.get_id() for role in SessionContext.get_effective_app_roles()]),
                        AccessPermissionModel.assignee_type == AccessPermissionAssigneeType.ACCESS_ROLE,
                    ),
                ),
                AccessPermissionModel.access_level.in_([PermissionType.READ, PermissionType.WRITE]),
            ),
            isouter=True,
        )
        .where(
            AccessPermissionModel.assignee_id.isnot(None),
            model.deleted_at.is_(None)
        )
    )

    # query_2 = query all model records of which the user is owner of and grant statically with WRITE permission!
    query_2 = (
            select (
                model,
                literal(PermissionType.WRITE.value).label("access_level"))
            .where(model.creator_id == current_user.get_id(),
                   model.deleted_at.is_(None)
                   )
        )
    # if an empty list is given we expect an empty result!
    if ids is not None:
        if not exclude:
            query_1 = query_1.where(model.id.in_(ids))
            query_2 = query_2.where(model.id.in_(ids))
        else:
             query_1 = query_1.where(model.id.not_in(ids))
             query_2 = query_2.where(model.id.not_in(ids))
    
    # !!! IMPORTANT TO KNOW !!!
    #
    # Why are we not using union_all here and merge both queries to single one?
    #   The answer is: we are going to lose automatic type extraction when doing this leading to the
    #   complex situation of mapping all but the last column of a result set to an instance of of the type 'model'
    #   manually. Not only is this a risky task but it also doesn't work with our inheritance model using Audit
    #   and Identifiable interfaces.
    #
    # So what is the solution then?
    #   2 queries is still better than potentially hundreds for each fetch request of entities, so we do 2 queries
    #   and merge manually afterwards by building up the final result map.
    query_1_results = database.session.execute(query_1).all()
    query_2_results = database.session.execute(query_2).all()

    enhanced_models: Dict[str, T] = {}
    for obj, access_permission in query_1_results:
        permission = access_permission if access_permission else PermissionType.FORBIDDEN
        if obj.id in enhanced_models:
            if PermissionType.rank(permission) > PermissionType.rank(enhanced_models[obj.id].permission):
                enhanced_models[obj.id].permission = permission
        else:
            obj.permission = permission
            enhanced_models[obj.id] = obj

    for obj, access_permission in query_2_results:
        # At this point, we know that access_permission is always set to 'WRITE' so we can directly map it to the enum
        permission = PermissionType.from_value(access_permission)
        if obj.id in enhanced_models:
            if PermissionType.rank(permission) > PermissionType.rank(enhanced_models[obj.id].permission):
                enhanced_models[obj.id].permission = permission
        else:
            obj.permission = permission
            enhanced_models[obj.id] = obj

    return list(enhanced_models.values())

def with_entities(subject: dict, **entity_ids):
    subject.update(entity_ids)
    return subject
def _get_tag_assistants(tag_id):
    """Get all assistants associated with a specific tag."""
    return AssistantModel.query.join(
        AssistantTagRelationModel,
        AssistantModel.id == AssistantTagRelationModel.assistant_id
    ).filter(
        AssistantTagRelationModel.tag_id == tag_id,
        AssistantModel.deleted_at.is_(None)
    ).all()

def _get_tag_agent_workflows(tag_id):
    """Get all agent workflows associated with a specific tag."""
    return AgentWorkflowModel.query.join(
        AgentWorkflowTagRelationModel,
        AgentWorkflowModel.id == AgentWorkflowTagRelationModel.agent_workflow_id
    ).filter(
        AgentWorkflowTagRelationModel.tag_id == tag_id,
        AgentWorkflowModel.deleted_at.is_(None)
        
    ).all()

def _get_tag_conversations(tag_id):
    """Get all conversations associated with a specific tag."""
    return ConversationModel.query.join(
        ConversationTagRelationModel,
        ConversationModel.id == ConversationTagRelationModel.conversation_id
    ).filter(
        ConversationTagRelationModel.tag_id == tag_id
    ).all()

def _get_tag_data_sources(tag_id):
    """Get all data sources associated with a specific tag."""
    return DataSourceModel.query.join(
        DataSourceTagRelationModel,
        DataSourceModel.id == DataSourceTagRelationModel.data_source_id
    ).filter(
        DataSourceTagRelationModel.tag_id == tag_id
    ).all()

def _get_tag_system_instructions(tag_id):
    """Get all system instructions associated with a specific tag."""
    return SystemInstructionModel.query.join(
        SystemInstructionTagRelationModel,
        SystemInstructionModel.id == SystemInstructionTagRelationModel.system_instruction_id
    ).filter(
        SystemInstructionTagRelationModel.tag_id == tag_id
    ).all()

def _get_tag_modules(tag_id):
    """Get all modules associated with a specific tag."""
    return ModuleModel.query.join(
        ModuleTagRelationModel,
        ModuleModel.id == ModuleTagRelationModel.module_id
    ).filter(
        ModuleTagRelationModel.tag_id == tag_id
    ).all()

def _get_tag_workspaces(tag_id):
    """Get all workspaces associated with a specific tag."""
    return WorkspaceModel.query.join(
        WorkspaceTagRelationModel,
        WorkspaceModel.id == WorkspaceTagRelationModel.workspace_id
    ).filter(
        WorkspaceTagRelationModel.tag_id == tag_id,
        WorkspaceModel.deleted_at.is_(None)
    ).all()

def _get_tag_widgets(tag_id):
    """Get all widgets associated with a specific tag."""
    return WidgetModel.query.join(
        WidgetTagRelationModel,
        WidgetModel.id == WidgetTagRelationModel.widget_id
    ).filter(
        WidgetTagRelationModel.tag_id == tag_id
    ).all()
def _get_tag_agents(tag_id):
    """Get all agents associated with a specific tag."""
    return AgentModel.query.join(
        AgentTagRelationModel,
        AgentModel.id == AgentTagRelationModel.agent_id
    ).filter(
        AgentTagRelationModel.tag_id == tag_id
    ).all()
def get_entity_count_for_tag(tag_id):
    """Return the total count of all entities associated with a given tag ID."""
    return sum([
        len(_get_tag_assistants(tag_id)),
        len(_get_tag_agents(tag_id)),
        len(_get_tag_agent_workflows(tag_id)),
        len(_get_tag_conversations(tag_id)),
        len(_get_tag_data_sources(tag_id)),
        len(_get_tag_system_instructions(tag_id)),
        len(_get_tag_modules(tag_id)),
        len(_get_tag_workspaces(tag_id)),
        len(_get_tag_widgets(tag_id))
    ])


class DefaultPreferenceKey(enum.Enum):
    DEFAULT_LLM = "ai-model"
    DEFAULT_EMBEDDING = "embedding-model"
    DEFAULT_VECTOR_STORE =  "vector-store"
    DEFAULT_FILE_STORAGE = "file-store" 

def get_default_module_ids_for_type(module_type=None):
    from maxgpt.modules.modules import ModuleType
    """
    Returns a set of default module IDs for the given module_type.
    If module_type is None, returns all default module IDs for all types.
    """ 
    module_type_to_pref_key = {
            ModuleType.LLM: DefaultPreferenceKey.DEFAULT_LLM,
            ModuleType.EMBEDDING_MODEL: DefaultPreferenceKey.DEFAULT_EMBEDDING,
            ModuleType.VECTOR_STORE: DefaultPreferenceKey.DEFAULT_VECTOR_STORE,
            ModuleType.FILE_STORAGE: DefaultPreferenceKey.DEFAULT_FILE_STORAGE,
        } 
    all_pref_keys = []
    if module_type is not None and module_type in module_type_to_pref_key:
            pref_key = module_type_to_pref_key[module_type] 
            all_pref_keys.append(pref_key) 
    else: 
        all_pref_keys.extend(list(module_type_to_pref_key.values())) 
    default_ids = set()
    for pref_key in all_pref_keys:  
        setting = ApplicationSettingModel.query \
            .join(PreferenceModel, ApplicationSettingModel.preference_id == PreferenceModel.id) \
            .filter(PreferenceModel.name == pref_key.value) \
            .first() 
        
        if setting:
            default_ids.add(setting.value) 
    return default_ids 

def with_default(module: dict, default_module_id: str | None) -> dict:
    module['default'] = (module.get('id') == default_module_id)
    return module


class SupportedPandasAIDataContentTypes:
    XLSX = "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" # "application/xsl+xml"
    CSV = "data:text/csv"

def base64_content_to_file(content) -> BytesIO:
    if not content.startswith("data:"):
        # Push through because content is already the content (for example in case of attachments
        data = content
    else:
        # Use regEx here to extend the value of this helper method for all cases beyond the
        # pandasai supported mimetypes
        pattern = r'^data:([^;,]+)(?:;base64)?,(.+)$'
        match = re.match(pattern, content)
        if not match:
            raise ValueError("Invalid data URI format")
        data = match.group(2)
    try:
        binary_content = base64.b64decode(data)
    except Exception as e:
        raise ValueError(f"Failed to decode base64 data: {e}")
    return BytesIO(binary_content)


def append_dataframe_from_part(data_str: str, pai_dfs: List[DataFrame], mime_type: str = None) -> None:
    """
    Given a message part and a list, decode and append DataFrames for XLSX, CSV.
    """
    # identity if we have an Excel file attached
    if data_str.startswith(SupportedPandasAIDataContentTypes.XLSX) or mime_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        file_like_object = base64_content_to_file(data_str)
        try:
            # read all the pages from Excel file
            dfs = pd.read_excel(file_like_object, sheet_name=None)
            # add sheet dataframes to the context dataframe list
            for df in dfs.values():
                pai_dfs.append(df)
        except Exception as e:
            logging.error(f"*** ChatProcess: Failed reading XLSX file: {e}")
        finally:
            file_like_object.close()
    elif data_str.startswith(SupportedPandasAIDataContentTypes.CSV) or mime_type == "text/csv":
        file_like_object = base64_content_to_file(data_str)
        try:
            df = pd.read_csv(file_like_object)
            # add dataframe to the context dataframe list
            pai_dfs.append(df)
        except Exception as e:
            logging.error(f"*** ChatProcess: Failed reading CSV file: {e}")
        finally:
            file_like_object.close()

    return pai_dfs

