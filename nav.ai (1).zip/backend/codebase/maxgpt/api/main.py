import logging
import os
import uuid
import sys

from flask import Blueprint, Flask, render_template, redirect, url_for, send_from_directory
from flask_cors import CORS
from flask import request 
from flask_restx import Api
from flask_session import Session
from werkzeug.middleware.proxy_fix import ProxyFix

from maxgpt.api.internal import utils as api_utils
from maxgpt.modules import ModuleSpecRegistry, ModuleRegistry
from maxgpt.services import database, initialize_database, AuthenticationProviderRegistry
from maxgpt.services.eqty.util import is_eqty_enabled

# Add navai to Python path
navai_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'navai')
if navai_path not in sys.path:
    sys.path.append(navai_path)

# Import NavAI API
from navai.api.main import blueprint as navai_blueprint
from navai.api.impl.grants import ns as navai_grants_namespace
from navai.api.impl.user_roles import ns as navai_user_roles_namespace
from navai.api.impl.tags import ns as navai_tags_namespace
from navai.api.impl.recursive_operation import ns as navai_recursive_operation_namespace

####### Init Logger
api_utils.setup_logger()

####### Init API
context_path = os.environ.get('APP_APPLICATION_ROOT', '')

authorityUrl = os.getenv('AUTH_OPENID_AUTHORITY_URL')

blueprint = Blueprint('api', __name__, url_prefix=context_path + '/api/v1')
default_label = 'MaximumGPT',


authorizations = None
security = None
if "OPENID" == os.getenv('AUTH_PROVIDER'):
    authorizations = {
        'MaximumGPT': {
            'type': 'oauth2',
            'authorizationUrl': authorityUrl + '/protocol/openid-connect/auth',
            'tokenUrl': authorityUrl + '/protocol/openid-connect/token',
            # 'flow': 'implicit',
            'flow': 'accessCode',
            'scopes': {
                'openid': 'Access your identity',
                'profile': 'Access your profile',
                'email': 'Access your email'
            }
        }
    }
    security = 'MaximumGPT'

api = Api(blueprint, doc=context_path + '/api/v1' + '/swagger/',
          title='MaximumGPT Web Service API',
          default_label='MaximumGPT',
          description='The one and only MaximumGPT backend to serve a comprehensive and valuable llm framework for your needs.',
          authorizations=authorizations,
          security=security)
# add generic error handler to the complete API
api.errorhandler(Exception)(api_utils.handle_exception)

# add all sub apis
from maxgpt.api.impl.system import ns as system_namespace

# Authentication
from maxgpt.api.impl.authentication import ns as authentication_namespace
from maxgpt.api.impl.authorization import ns as authorization_namespace
from maxgpt.api.impl.preferences import ns as preference_namespace
from maxgpt.api.impl.user import ns as user_namespace

# Process Execution (Ingest & Chat)
from maxgpt.api.impl.query import ns as query_namespace
from maxgpt.api.impl.conversation import ns as conversation_namespace
from maxgpt.api.impl.ingest import ns as ingest_namespace
from maxgpt.api.impl.module_spec import ns as module_spec_namespace
from maxgpt.api.impl.module import ns as module_namespace

# Modules
from maxgpt.api.impl.tag import ns as tag_namespace
from maxgpt.api.impl.system_instruction import ns as system_instruction_namespace
from maxgpt.api.impl.data_source import ns as data_source_namespace

from maxgpt.api.impl.workspace import ns as workspace_namespace
from maxgpt.api.impl.assistant import ns as assistant_namespace
from maxgpt.api.impl.agent import ns as agent_namespace
from maxgpt.api.impl.agent_workflows import ns as agent_workflow_namespace
from maxgpt.api.impl.widget import ns as widget_namespace
from maxgpt.api.impl.tag_category import ns as tag_category_namespace

from maxgpt.api.impl.data_object import ns as data_object_namespace
from maxgpt.api.impl.shared_conversation import ns as shared_conversation_namespace
from maxgpt.api.impl.application_settings import ns as application_settings_namespace
from navai.api.impl.data_migration_tool import ns as dmt_namespace

if is_eqty_enabled():
    from maxgpt.api.impl.governance import ns as governance_namespace

api.add_namespace(system_namespace)

api.add_namespace(authentication_namespace)
api.add_namespace(authorization_namespace)
api.add_namespace(user_namespace)
api.add_namespace(preference_namespace)

api.add_namespace(module_spec_namespace)
api.add_namespace(module_namespace)

api.add_namespace(system_instruction_namespace)

api.add_namespace(data_source_namespace)
api.add_namespace(ingest_namespace)
api.add_namespace(data_object_namespace)

api.add_namespace(assistant_namespace)
api.add_namespace(agent_namespace)
api.add_namespace(agent_workflow_namespace)
api.add_namespace(widget_namespace)

api.add_namespace(workspace_namespace)

api.add_namespace(conversation_namespace)
api.add_namespace(query_namespace)

api.add_namespace(tag_namespace)
api.add_namespace(navai_grants_namespace)
api.add_namespace(navai_user_roles_namespace)
api.add_namespace(navai_tags_namespace)
api.add_namespace(navai_recursive_operation_namespace)
api.add_namespace(dmt_namespace)
api.add_namespace(tag_category_namespace)

api.add_namespace(shared_conversation_namespace)
api.add_namespace(application_settings_namespace)

if is_eqty_enabled():
    api.add_namespace(governance_namespace)


app = Flask(__name__, static_folder='static')
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1)

# register endpoints via blueprint
app.register_blueprint(blueprint)
app.register_blueprint(navai_blueprint)  # Register NavAI blueprint

# set specific json encoder to handle marshalling of enums properly
app.json = api_utils.CustomJSONProvider(app)

# # uncomment for debugging reasons to see all configured routes
# for rule in app.url_map.iter_rules():
#     print(f"Route: {rule} -> {rule.endpoint} [{', '.join(rule.methods)}]")

# TODO: Check leading / in case context path is set
app.config['SECRET_KEY'] = uuid.uuid4().hex
app.config['SERVER_NAME'] = os.environ.get('APP_SERVER_NAME')


if os.getenv("APP_ENABLE_CORS", 'False').lower() in ('true', '1', 't'):
    # Get trusted origins from environment variable  and Format should be comma-separated list
    trusted_origins_str = os.getenv("APP_CORS_TRUSTED_ORIGINS","")

    trusted_origins = [
        origin.strip() 
        for origin in trusted_origins_str.split(',') 
        if origin.strip()
        
    ]  
    if len(trusted_origins)>0: 
        logging.log(logging.WARN, f"CORS is enabled for trusted origins: {trusted_origins}")
        CORS(app, supports_credentials=True, origins=trusted_origins)
        def cors_headers_with_origins(response):
            return api_utils.add_cors_headers(response, trusted_origins)  
        app.after_request(cors_headers_with_origins)
    else:
        logging.log(logging.WARN, "CORS is enabled origins *")
        CORS(app, supports_credentials=True)
        app.after_request(api_utils.add_cors_headers)
else:
    logging.log(logging.WARN, f"'APP_ENABLE_CORS' is set to {os.getenv('APP_ENABLE_CORS')}")


# Session configuration
session = Session()
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = False  # set signing key when used
session.init_app(app)

# attach max-gpt to persistence
initialize_database(app)

# initialize registries
ModuleSpecRegistry.initialize()
with app.app_context():
    ModuleRegistry.initialize()

# Bootstrap auth provider configuration to cache it
AuthenticationProviderRegistry.initialize()

# ensure session is closed when app is tearing down
# noinspection PyUnusedLocal
@app.teardown_appcontext
def shutdown_session(exception=None):
    database.session.remove()

if context_path is not None and context_path != '':
    @app.route('/')
    def home_ui():
        return redirect(url_for('context_home_ui'))

@app.route(context_path + '/')
def context_home_ui():
   return render_template('index.html')

@app.route(context_path + '/swagger-ui/')
def swagger_ui():
   return render_template('swagger-ui/index.html', spec='api/v1/swagger.json', contextPath=context_path)

@app.route(context_path + '/static/<path:path>')
def get_static_resource(path):
    return send_from_directory('static', path)

if logging.getLogger().isEnabledFor(logging.DEBUG):
    print("## Available endpoints:")
    print(app.url_map)
