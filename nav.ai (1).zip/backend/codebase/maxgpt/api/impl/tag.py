from datetime import datetime
import logging
from operator import and_
from sqlalchemy import delete, select

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, shallow_tag_model
from maxgpt.services import DefaultApplicationAccessRole, database
from maxgpt.services.database_model import TagCategoryModel, TagCategoryTagRelationModel, TagModel
from maxgpt.services.internal.session_context import SessionContext


ns = Namespace('Tags',
               description='Configure tags to be used to tag modules, assistants, widgets and workspaces.',
               path='/tag')

tag_model = ns.inherit('Tag', audited_model(ns), shallow_tag_model(ns), {
    'name':fields.String(description="Name of the tag",max_lenght=36,required=True),
    'description': fields.String(description="A short summary of the tag.", max_length=500, required=False),
    'tagCategoryId': fields.String(description="ID of the tag category associated with this tag", required=False),
})


# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class TagsEndpoint(Resource):
    @ns.doc("list_tags")
    @ns.param('isDeleted', 'Set to true to get soft-deleted tags', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(tag_model)))
    @ns.param('categoryId', 'Tag Category Identifier (use "null" or empty for uncategorized)', type=str, required=False, _in="query")
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all stored tags that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == 'true':
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_tags = TagModel.query.filter(
                TagModel.deleted_at.isnot(None),
                TagModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([tag.to_dict() for tag in soft_deleted_tags])
        tag_category_id = request.args.get('tagCategoryId')
        
        # Default: all tags not deleted
        tags_query = TagModel.query.filter(TagModel.deleted_at.is_(None))

        if 'tagCategoryId' in request.args:
            if tag_category_id in [None, '', 'null', 'None']:
                # Get uncategorized tags
                related_tag_ids = TagCategoryTagRelationModel.query.with_entities(
                    TagCategoryTagRelationModel.tag_id
                )
                tag_ids = list(set(database.session.scalars(related_tag_ids)))
                tags_query = tags_query.filter(TagModel.id.notin_(tag_ids))
            else:
                # Validate and filter by category
                tag_category = TagCategoryModel.query.get(tag_category_id)
                if tag_category is None:
                    ns.abort(404, f"Tag category with ID '{tag_category_id}' does not exist.")
                tags_query = tags_query.join(
                    TagCategoryTagRelationModel,
                    TagModel.id == TagCategoryTagRelationModel.tag_id
                ).filter(TagCategoryTagRelationModel.tag_category_id == tag_category_id)

        tags = tags_query.all()
        return jsonify([tag.to_dict() for tag in tags])
   
    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class TagFactoryEndpoint(Resource):
    @ns.expect(tag_model)
    @ns.doc("create_tag")
    @ns.response(200, 'Success', tag_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new tag. If 'tagCategoryId' is provided, the tag will be linked to that category."""
        _data = request.get_json()

        # Validate input
        if 'name' not in _data:
            ns.abort(400, "Field 'name' is required to create a tag")
        _tag = TagModel.query.filter(
            TagModel.name == _data['name'],
            TagModel.deleted_at.is_(None)
        ).first()
        if _tag:
            ns.abort(400, f"Tag with name {_data['name']} already exists.")

        tag_name = _data['name']
        tag_description = _data.get('description')
        tag_category_id = _data.get('tagCategoryId')  # Optional

        # Create the tag
        _tag = TagModel(name=tag_name, description=tag_description)
        database.session.add(_tag)

        # If tagCategoryId is provided, create the relation
        if tag_category_id:
            _tag_category = TagCategoryModel.query.get(tag_category_id)
            if _tag_category is None:
                ns.abort(404, f"Tag category with ID '{tag_category_id}' does not exist.")


            # Create the association
            relation = TagCategoryTagRelationModel(
                tag_category_id=tag_category_id,
                tag_id=_tag.id
            )
            database.session.add(relation)

        # Final commit to persist tag and relation
        database.session.commit()

        return jsonify(_tag.to_dict())

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<tag_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class tagEndpoint(Resource):
    @ns.doc(description="read_tag")
    @ns.response(200, 'Success', tag_model)
    @ns.response(404, 'Tag not found')
    @requires_database_session
    @propagate_principal()
    def get(self, tag_id: str):
        """Returns the tag for the given id if existing and accessible for the current user."""
        _tag = TagModel.query.filter(
            TagModel.id == tag_id,
            TagModel.deleted_at.is_(None)
        ).first()

        if _tag is None:
            ns.abort(404, 'A tag with identifier "{}" does not exist'.format(tag_id))

        return jsonify(_tag.to_dict())
    
    @ns.doc("update_tag")
    @ns.expect(tag_model)
    @ns.response(200, 'Success', tag_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The tag does not exist.')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def put(self, tag_id: str):
        """Updates an existing tag. If 'tagCtaegoryId' is provided, it links the tag to that category."""
        _data = request.get_json()

        _tag = TagModel.query.filter(
            TagModel.id == tag_id,
            TagModel.deleted_at.is_(None)
        ).first()

        if _tag is None:
            ns.abort(404, f'A tag with identifier "{tag_id}" does not exist.')

        if _tag.deleted_at is not None:
            ns.abort(404, f'The tag with identifier "{tag_id}" has already been deleted and cannot be modified.')

        # Update fields
        if 'name' in _data:
            _tag_exists = TagModel.query.filter(
                TagModel.name == _data['name'],
                TagModel.id != tag_id,
                TagModel.deleted_at.is_(None)
            ).first()
            if _tag_exists:
                ns.abort(400, f"Tag with name {_data['name']} already exists.")
            _tag.name = _data['name']
        
        if 'description' in _data:
            _tag.description = _data['description']

        # Handle optional tagCategoryId association
        tag_category_id = _data.get('tagCategoryId')
        if tag_category_id:
            _tag_category = TagCategoryModel.query.get(tag_category_id)
            if _tag_category is None:
                ns.abort(404, f"Tag category with ID '{tag_category_id}' does not exist.")


            # Check if relation already exists
            exists_stmt = select(TagCategoryTagRelationModel).where(
                TagCategoryTagRelationModel.tag_id == tag_id
            )
            if database.session.execute(exists_stmt).first():
                ns.abort(400, f"Tag is already associated with another Tag Category")
            else:
                relation = TagCategoryTagRelationModel(
                    tag_category_id=tag_category_id,
                    tag_id=tag_id
                )
                database.session.add(relation)

        # Save changes
        database.session.commit()

        return jsonify(_tag.to_dict())


    @ns.doc("delete_tag")
    @ns.param('hardDelete', 'Set to true to hard delete the tag', type=bool, required=False, _in="query")
    @ns.param('tagCategoryId', 'ID of the tag category to remove association from', type=str, required=False, _in="query")
    @ns.response(200, 'Success', tag_model)
    @ns.response(404, 'The tag does not exist')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def delete(self, tag_id: str):
        """Delete the tag or remove its association with a tag category."""
        tag_category_id = request.args.get('tagCategoryId')
        hard_delete = request.args.get('hardDelete', 'false').lower() == 'true'

        _tag: TagModel = TagModel.query.filter(
            TagModel.id == tag_id,
            TagModel.deleted_at.is_(None)
        ).first()

        if _tag is None:
            ns.abort(404, f'A tag with identifier "{tag_id}" does not exist')

        # CASE 1: Just remove the relation to a tag category
        if tag_category_id:
            _tag_category = TagCategoryModel.query.get(tag_category_id)
            if _tag_category is None:
                ns.abort(404, f"A tag_category with identifier '{tag_category_id}' does not exist")

            
            stmt = delete(TagCategoryTagRelationModel).where(
                and_(
                    TagCategoryTagRelationModel.tag_category_id == tag_category_id,
                    TagCategoryTagRelationModel.tag_id == tag_id
                )
            )
            database.session.execute(stmt)
            database.session.commit()

            return jsonify({"message": f"Tag '{tag_id}' was unlinked from tag_category '{tag_category_id}'"})

        # CASE 2: Proceed to delete the tag
        tag_dict = _tag.to_dict()

        if hard_delete:
            logging.log(logging.INFO, f"Hard delete the tag:{tag_id}")
            database.session.delete(_tag)
        else:
            logging.log(logging.INFO, f"Soft delete the tag:{tag_id}")
            _tag.deleted_at = datetime.now()
            _tag.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()

        return jsonify(tag_dict)
    @ns.doc(False)
    def options(self, tag_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<tag_id>/restore/', strict_slashes=False, methods=['PATCH', 'OPTIONS'])
class TagRestoreEndpoint(Resource):
    @ns.doc("restore_tag")
    @ns.response(200, 'Success', tag_model)
    @ns.response(404, 'The tag does not exist.')
    @requires_database_session
    @propagate_principal()
    def patch(self, tag_id: str):
        """Restore a soft-deleted tag."""
        current_user = SessionContext.get_current_user()
        _tag = TagModel.query.get(tag_id)
        if not _tag:
            ns.abort(404, f"Tag with id {tag_id} does not exist.")
        
        if not _tag.deleted_at:
            ns.abort(400, f"Tag with id {tag_id} is not deleted.")

         # Check if the current user is the creator of the tag
        if _tag.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this Tag")

        _tag.deleted_at = None
        _tag.deleted_by = None
        database.session.commit()

        
        return jsonify(_tag.to_dict())

    @ns.doc(False)
    def options(self, tag_id: str):
        # Handle preflight OPTIONS request
        return '', 200
