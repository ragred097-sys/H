import json

from flask import Response, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import AuthenticationProviderRegistry
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.security import MSALAuthenticatorConfiguration, OpenIDAuthenticatorConfiguration, \
    AuthenticatorConfiguration

ns = Namespace('Authentication', description='Operations related to authentication of a user. In general authentication takes place on client and server side. So to keep configuration on a single place you will find methods here to retrieve all required configurations.'
                                             'Supported authentication providers are as of now OpenID and MSAL, but other - proprietary - implementations could be provided bespoke.',
               path='/authentication')

user_profile_model = ns.model("User Profile", {
    'id': fields.String(description="The UUID of the current user", required=True, readonly=True, max_length=30),
    'account_id': fields.String(description="The account name of the current user", required=True, readonly=True)
})


def auth_config_model(ns: Namespace):
    return ns.model('AuthConfig', {})


openid_config_model = ns.inherit('OpenIDConfig', auth_config_model(ns), {
    'authority': fields.String(
        description="The URL of the OpenID provider's authorization server.",
        example="https://openid.example.com"
    ),
    'clientId': fields.String(
        description="The client ID issued to the application by the OpenID provider.",
        example="abc123"
    ),
    'clientSecret': fields.String(
        description="The client secret for secure authentication with the OpenID provider.",
        example="supersecret"
    ),
    'redirectUri': fields.String(
        description="The URI where the OpenID provider redirects after authentication.",
        example="https://app.example.com/callback"
    ),
    'responseType': fields.String(
        description="The response type for authentication (e.g., 'code' for authorization code flow).",
        example="code"
    ),
    'scope': fields.String(
        description="The requested permissions and scopes (e.g., 'openid profile email').",
        example="openid profile email"
    ),
})

msal_config_model = ns.inherit('MSALConfig', auth_config_model(ns), {
    'tenantId': fields.String(
        description="The unique identifier of the Azure AD tenant.",
        example="my-tenant-id"
    ),
    'appClientId': fields.String(
        description="The client ID of the registered application in Azure AD.",
        example="app-client-xyz"
    ),
    'authority': fields.String(
        description="The URL of the Azure AD authorization server.",
        example="https://login.microsoftonline.com/my-tenant-id"
    ),
    'redirectUri': fields.String(
        description="The URI where the Azure AD provider redirects after authentication.",
        example="https://app.example.com/callback"
    ),
    'apiClientId': fields.String(
        description="The client ID of the API that the application will access.",
        example="api-client-xyz"
    ),
    'apiScope': fields.String(
        description="The scope of access permissions required for the API.",
        example="https://graph.microsoft.com/.default"
    ),
})
#
# # Authentication Configuration Model (Root Response) with `oneOf`
# auth_config_response_model = ns.model('AuthConfigResponse', {
#     "provider": fields.String(
#         description="The authentication provider type. This determines the structure of 'config'.",
#         enum=["OPENID", "MSAL"],
#         example="OPENID"
#     ),
#     "config": fields.Polymorph({
#         MSALAuthenticatorConfiguration: msal_config_model,
#         OpenIDAuthenticatorConfiguration: openid_config_model
#     }, description="The authentication configuration response.")
# })

@ns.route('/', strict_slashes=False)
class AuthConfigEndpoint(Resource):
    @ns.doc(description="""
        Retrieves the authentication configuration based on the selected authentication provider. 
        The response structure varies depending on the configured provider.

        - If the provider is **OPENID**, the `config` field will follow the OpenIDConfig schema.
        - If the provider is **MSAL**, the `config` field will follow the MSALConfig schema.

        Clients should use the `provider` field to determine which structure to expect.
    """, security=None)
    #@ns.response(200, 'Success', auth_config_response_model)
    def get(self):
        """Returns the authentication configuration."""
        authenticator = AuthenticationProviderRegistry.get_authenticator()
        return jsonify({
            'provider': authenticator.get_provider(),
            'config': authenticator.get_configuration().to_dict()
        })

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/me/', strict_slashes=False)
class AuthAboutMeEndpoint(Resource):
    @ns.doc("get_userprofile")
    @ns.response(200, 'Success', user_profile_model)
    @requires_database_session
    # @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_USER.value])
    @propagate_principal()
    def get(self):
        current_user = SessionContext.get_current_user().to_dict()
        effective_user_roles = [role.to_dict() for role in SessionContext.get_effective_app_roles()]
        current_user['applicationAccessRoles'] = effective_user_roles

        return jsonify(current_user)

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
