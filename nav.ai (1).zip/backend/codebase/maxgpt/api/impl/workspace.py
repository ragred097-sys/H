import logging
from typing import List

from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from flask_sqlalchemy.session import Session
from sqlalchemy import and_, select, delete
from werkzeug.exceptions import SecurityError
from datetime import datetime
from maxgpt.api import EntityType
from maxgpt.api.impl.agent import agent_model
from maxgpt.api.impl.agent_workflows import agent_workflow_model
from maxgpt.api.impl.assistant import assistant_model
from maxgpt.api.impl.system_instruction import system_instruction_model
from maxgpt.api.impl.widget import widget_model
from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.internal.utils import audited_model, tagged_model, with_favorite, get_user_access_for, \
    with_access_permission, fetch_with_permissions, favorible_model, with_hidden
from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import database
from maxgpt.services.database_model import WorkspaceModel, WorkspaceAssistantRelationModel, AssistantModel, \
    WorkspaceWidgetRelationModel, WidgetModel, WorkspaceTagRelationModel, UserFavoriteModel, FavoriteSubject, \
    AccessPermissionSubject, AccessPermissionModel, AccessPermissionAssigneeType, PermissionType, \
    WorkspaceSystemInstructionRelationModel, SystemInstructionModel, WorkspaceAgentRelationModel, AgentModel, \
    WorkspaceAgentWorkflowRelationModel, AgentWorkflowModel, AgentModel, UserHiddenEntityModel, HiddenEntitySubject
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('Workspaces',
               description='Configure workspaces of a user.',
               path='/workspace')

workspace_model = ns.inherit('Workspace', audited_model(ns), tagged_model(ns), favorible_model(ns), {
    'id': fields.String(description="The identifier of the workspace.", required=True, readonly=True),
    'name': fields.String(description="The name of the workspace.", max_length=100, required=True),
    'description': fields.String(description="A detailed description of the workspace.", required=False),
    'icon': fields.String(description="A base64 encoded image to show as icon for this workspace.", required=False),
    'image': fields.String(description="A base64 encoded image to show in the workspace tile.", required=False),
    'filteredOnTags': fields.Boolean(description="A flag to indicate of entities inside the workspace should be filtered on the workspace tags.", required=False),
})

workspace_linked_assistant_ids = ns.model('List of assistant IDs', {
    'assistantIds': fields.List(fields.String,
                                description="A list of identifiers of assistants bound to the workspace.",
                                required=True),
})

workspace_linked_agent_workflow_ids = ns.model('List of Agent Workflow IDs', {
    'agentWorkflowIds': fields.List(fields.String,
                                description="A list of identifiers of agent workflows bound to the workspace.",
                                required=True),
})

workspace_linked_agent_ids = ns.model('List of agent IDs', {
    'agentIds': fields.List(fields.String,
                                description="A list of identifiers of agents bound to the workspace.",
                                required=True),
})

workspace_linked_widget_ids = ns.model('List of widget IDs', {
    'widgetIds': fields.List(fields.String, description="A list of identifiers of widgets bound to the workspace.",
                             required=True),
})

workspace_linked_system_instruction_ids = ns.model('List of system instructions IDs', {
    'systemInstructionIds': fields.List(fields.String, description="A list of identifiers of system instructions bound to the workspace.",
                             required=True),
})


@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class WorkspacesEndpoint(Resource):
    @ns.doc("list_workspaces")
    @ns.param('isDeleted', 'Set to true to get soft-deleted workspaces', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden workspaces, false for only unhidden', type=bool, required=False, _in="query")
    @ns.param('search', 'A search pattern as regular expression to look for. Start and end marks are added automatically', required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(workspace_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available workspaces that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == "true":
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_workspaces = WorkspaceModel.query.filter(
                WorkspaceModel.deleted_at.isnot(None),
                WorkspaceModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([workspace.to_dict() for workspace in soft_deleted_workspaces])

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            _enhanced_workspaces: list[WorkspaceModel] = fetch_with_permissions(WorkspaceModel, hidden_ids)
        elif hidden_param == 'false':
            _enhanced_workspaces: list[WorkspaceModel] = fetch_with_permissions(
                WorkspaceModel,
                ids=hidden_ids,
                exclude=True
            )
        else:
            _enhanced_workspaces: list[WorkspaceModel] = fetch_with_permissions(WorkspaceModel)

        _search_pattern = request.args.get('search')
        if _search_pattern:
            import re
            try:
                search_regex = re.compile(f".*{re.escape(_search_pattern)}.*", re.IGNORECASE)
                _enhanced_workspaces = [
                    workspace for workspace in _enhanced_workspaces
                    if search_regex.search(workspace.name) or search_regex.search(workspace.description)
                ]
            except re.error:
                _enhanced_workspaces = []

        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WORKSPACE)
        )
        subject_ids = set(database.session.scalars(stmt))
        
        return jsonify([with_hidden(with_favorite(with_access_permission(_workspace.to_dict(), _workspace.permission), subject_ids), hidden_ids)
                        for _workspace in _enhanced_workspaces])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class WorkspaceFactoryEndpoint(Resource):
    @ns.expect(workspace_model)
    @ns.doc("create_workspace")
    @ns.response(200, 'Success', workspace_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new Workspace."""
        _data = request.get_json()
        _image = _data.get('image')
        _icon = _data.get('icon')
        _filteredOnTags = _data.get('filteredOnTags')

        _workspace = WorkspaceModel(name=_data.get('name'),
                                    description=_data.get('description'))

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _workspace.tag_relations.append(
                    WorkspaceTagRelationModel(workspace_id=_workspace.id, tag_id=_shallow_tag['id']))
        if _image:
            _workspace.image = _image
        if _icon:
            _workspace.icon = _icon
        if _filteredOnTags:
            _workspace.filteredOnTags = bool(_filteredOnTags)

        database.session.add(_workspace)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WORKSPACE)
        )

        subject_ids = set(database.session.scalars(stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_workspace.to_dict(), subject_ids), set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class WorkspaceEndpoint(Resource):
    @ns.doc("read_workspace")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted workspaces', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', workspace_model)
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        """Returns a Workspace for the given id."""
        # Apply deleted filter if includeDeleted is not true
        if 'includeDeleted' in request.args and request.args.get('includeDeleted').lower() == 'true':
            delete_filter = WorkspaceModel.deleted_at.isnot(None)
        else:
            delete_filter = WorkspaceModel.deleted_at.is_(None)

        _workspace = WorkspaceModel.query.filter(WorkspaceModel.id == workspace_id,
                        delete_filter).first()

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                    f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WORKSPACE)
        )

        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        
        return jsonify(with_access_permission(with_hidden(with_favorite(_workspace.to_dict(), subject_ids), hidden_ids), grant))

    @ns.doc("update_workspace")
    @ns.expect(workspace_model)
    @ns.response(200, 'Success', workspace_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, workspace_id: str):
        """Updates an existing Workspace."""
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f'A workspace with identifier "{workspace_id}" does not exist')

        #Check if workspace is already deleted
        if _workspace.deleted_at is not None:
            ns.abort(404, f'The workspace with identifier "{workspace_id}" has already been deleted and cannot be modified')

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        # Mandatory attributes
        _workspace.name = _data['name'] if 'name' in _data else _workspace.name
        _workspace.description = _data['description'] if 'description' in _data else _workspace.description

        session = Session.object_session(_workspace)

        # Optional update fields
        if _data.get('tags') is not None:
            for _tag_relation in _workspace.tag_relations:
                session.delete(_tag_relation)
            _workspace.tag_relations = []
            for _shallow_tag in _data['tags']:
                _workspace.tag_relations.append(
                    WorkspaceTagRelationModel(workspace_id=_workspace.id, tag_id=_shallow_tag['id']))

        _workspace.image = _data['image'] if 'image' in _data else _workspace.image
        _workspace.icon = _data['icon'] if 'icon' in _data else _workspace.icon
        _workspace.filtered_on_tags = bool(_data['filteredOnTags']) if 'filteredOnTags' in _data else _workspace.filtered_on_tags

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WORKSPACE)
        )

        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(with_access_permission(with_hidden(with_favorite(_workspace.to_dict(), subject_ids), hidden_ids), grant))

    @ns.doc("delete_workspace")
    @ns.param('hardDelete', 'Set to true to hard delete the workspace', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', workspace_model)
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        """Deletes an existing Workspace."""
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f'A workspace with identifier "{workspace_id}" does not exist')

        #Check if workspace is already deleted
        if _workspace.deleted_at is not None:
            ns.abort(404, f'The workspace with identifier "{workspace_id}" has already been deleted')

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to delete workspace with identifier '{workspace_id}'")

        workspace_dict = _workspace.to_dict()
        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.WORKSPACE,
                UserFavoriteModel.subject_id == workspace_id
            )
        ).delete()

        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE,
                UserHiddenEntityModel.subject_id == workspace_id
            )
        ).delete()

        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == "true":
            logging.log(logging.INFO, f"Hard delete the workspace:{workspace_id}")
            database.session.delete(_workspace)
        else:
            logging.log(logging.INFO, f"Soft delete the workspace:{workspace_id}")
            _workspace.deleted_at = datetime.now()
            _workspace.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()

        # attach favorite information
        subject_ids = set([])
        return jsonify(with_access_permission(with_hidden(with_favorite(workspace_dict, subject_ids), subject_ids), grant))

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/assistants/', strict_slashes=False, methods=['GET', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceAssistantsEndpoint(Resource):
    @ns.doc("read_workspace_assistant_relations")
    @ns.response(200, 'Success', fields.List(fields.Nested(assistant_model)))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        #Added filter to honor soft delete
        _workspace = WorkspaceModel.query.filter(
            WorkspaceModel.id == workspace_id,
            WorkspaceModel.deleted_at.is_(None)
        ).first()
        
        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        stmt = select(WorkspaceAssistantRelationModel.assistant_id).where(
            WorkspaceAssistantRelationModel.workspace_id == _workspace.id
        )

        assistant_ids = database.session.scalars(stmt).all()

        enhanced_assistants: List[AssistantModel] = fetch_with_permissions(AssistantModel, assistant_ids)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_assistant.to_dict(), _assistant.permission), subject_ids), hidden_ids)
                        for _assistant in enhanced_assistants])

    @ns.doc(description="create_workspace_assistant_link")
    @ns.expect(workspace_linked_assistant_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(assistant_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @propagate_principal()
    @requires_database_session
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'assistantIds' not in _data:
            ns.abort(400, 'You must provide a list of assistant ids to add them to your workspace.')

        _assistant_ids = set(_data['assistantIds'])

        # Reduce to set of ids that are not linked yet and required creation of new relations
        stmt = select(WorkspaceAssistantRelationModel.assistant_id).where(
            (WorkspaceAssistantRelationModel.workspace_id == workspace_id) &
            (WorkspaceAssistantRelationModel.assistant_id.in_(_assistant_ids))
        )
        _assistant_ids = _assistant_ids - set(database.session.scalars(stmt))

        enhanced_assistants: List[AssistantModel] = fetch_with_permissions(AssistantModel, _assistant_ids)

        for _assistant in enhanced_assistants:
            _workspace_assistant_relation = WorkspaceAssistantRelationModel(workspace_id=workspace_id,
                                                                            assistant_id=_assistant.id)
            database.session.add(_workspace_assistant_relation)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_assistant.to_dict(), _assistant.permission), subject_ids), hidden_ids)
                        for _assistant in enhanced_assistants])

    @ns.doc(description="delete_workspace_assistant_link")
    @ns.expect(workspace_linked_assistant_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(assistant_model)))
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'assistantIds' not in _data:
            ns.abort(400, 'You must provide a list of assistant ids to add them to your workspace.')

        _assistant_ids = set(_data['assistantIds'])

        # filter out relations that are no longer existing
        stmt = select(WorkspaceAssistantRelationModel.assistant_id).where(
            (WorkspaceAssistantRelationModel.workspace_id == workspace_id) &
            (WorkspaceAssistantRelationModel.assistant_id.in_(_assistant_ids))
        )
        _assistant_ids = _assistant_ids - set(database.session.scalars(stmt))

        # now load complete assistants including their permissions - this will filter out the ones
        # the current user has no permission for (those links will not be deleted)
        enhanced_assistants: List[AssistantModel] = fetch_with_permissions(AssistantModel, _assistant_ids)

        # delete existing relations
        stmt = delete(WorkspaceAssistantRelationModel).where(
            and_(
                WorkspaceAssistantRelationModel.workspace_id == workspace_id,
                WorkspaceAssistantRelationModel.assistant_id.in_([assistant.id for assistant in enhanced_assistants]),
            )
        )
        database.session.execute(stmt)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_assistant.to_dict(), _assistant.permission), subject_ids), hidden_ids)
                        for _assistant in enhanced_assistants])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/agents/', strict_slashes=False, methods=['GET', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceAgentEndpoint(Resource):
    @ns.doc("read_workspace_agent_relations")
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_model)))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        stmt = select(WorkspaceAgentRelationModel.agent_id).where(
            WorkspaceAgentRelationModel.workspace_id == _workspace.id
        )

        agent_ids = database.session.scalars(stmt).all()

        enhanced_agents: List[AgentModel] = fetch_with_permissions(AgentModel, agent_ids)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent.to_dict(), _agent.permission), subject_ids), hidden_ids)
                        for _agent in enhanced_agents])

    @ns.doc(description="create_workspace_agent_link")
    @ns.expect(workspace_linked_agent_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @propagate_principal()
    @requires_database_session
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'agentIds' not in _data:
            ns.abort(400, 'You must provide a list of agents ids to add them to your workspace.')

        _agent_ids = set(_data['agentIds'])

        # Reduce to set of ids that are not linked yet and required creation of new relations
        stmt = select(WorkspaceAgentRelationModel.agent_id).where(
            (WorkspaceAgentRelationModel.workspace_id == workspace_id) &
            (WorkspaceAgentRelationModel.agent_id.in_(_agent_ids))
        )
        _agent_ids = _agent_ids - set(database.session.scalars(stmt))

        enhanced_agents: List[AgentModel] = fetch_with_permissions(AgentModel, _agent_ids)

        for _agent in enhanced_agents:
            _workspace_agent_relation = WorkspaceAgentRelationModel(workspace_id=workspace_id,
                                                                            agent_id=_agent.id)
            database.session.add(_workspace_agent_relation)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent.to_dict(), _agent.permission), subject_ids), hidden_ids)
                        for _agent in enhanced_agents])

    @ns.doc(description="delete_workspace_agent_link")
    @ns.expect(workspace_linked_agent_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_model)))
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'agentIds' not in _data:
            ns.abort(400, 'You must provide a list of agent ids to add them to your workspace.')

        _agent_ids = set(_data['agentIds'])

        # filter out relations that are no longer existing
        stmt = select(WorkspaceAgentRelationModel.agent_id).where(
            (WorkspaceAgentRelationModel.workspace_id == workspace_id) &
            (WorkspaceAgentRelationModel.agent_id.in_(_agent_ids))
        )
        _agent_ids = _agent_ids - set(database.session.scalars(stmt))

        # now load complete agents including their permissions - this will filter out the ones
        # the current user has no permission for (those links will not be deleted)
        enhanced_agents: List[AgentModel] = fetch_with_permissions(AgentModel, _agent_ids)

        # delete existing relations
        stmt = delete(WorkspaceAgentRelationModel).where(
            and_(
                WorkspaceAgentRelationModel.workspace_id == workspace_id,
                WorkspaceAgentRelationModel.agent_id.in_([agent.id for agent in enhanced_agents]),
            )
        )
        database.session.execute(stmt)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent.to_dict(), _agent.permission), subject_ids), hidden_ids)
                        for _agent in enhanced_agents])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<workspace_id>/agent-workflows/', strict_slashes=False, methods=['GET', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceAgentWorkflowEndpoint(Resource):
    @ns.doc("read_workspace_agent_workflow_relations")
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_workflow_model)))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        stmt = select(WorkspaceAgentWorkflowRelationModel.agent_workflow_id).where(
            WorkspaceAgentWorkflowRelationModel.workspace_id == _workspace.id
        )

        agent_workflow_ids = database.session.scalars(stmt).all()

        enhanced_agent_workflows: List[AgentWorkflowModel] = fetch_with_permissions(AgentWorkflowModel, agent_workflow_ids)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent_workflow.to_dict(), _agent_workflow.permission), subject_ids), hidden_ids)
                        for _agent_workflow in enhanced_agent_workflows])

    @ns.doc(description="create_workspace_agent_workflow_link")
    @ns.expect(workspace_linked_agent_workflow_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_workflow_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @propagate_principal()
    @requires_database_session
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'agentWorkflowIds' not in _data:
            ns.abort(400, 'You must provide a list of agent workflow ids to add them to your workspace.')

        _agent_workflow_ids = set(_data['agentWorkflowIds'])

        # Reduce to set of ids that are not linked yet and required creation of new relations
        stmt = select(WorkspaceAgentWorkflowRelationModel.agent_workflow_id).where(
            (WorkspaceAgentWorkflowRelationModel.workspace_id == workspace_id) &
            (WorkspaceAgentWorkflowRelationModel.agent_workflow_id.in_(_agent_workflow_ids))
        )
        _agent_workflow_ids = _agent_workflow_ids - set(database.session.scalars(stmt))

        enhanced_agent_workflows: List[AgentWorkflowModel] = fetch_with_permissions(AgentWorkflowModel, _agent_workflow_ids)

        for _agent_workflow in enhanced_agent_workflows:
            _workspace_agent_workflow_relation = WorkspaceAgentWorkflowRelationModel(workspace_id=workspace_id,
                                                                            agent_workflow_id=_agent_workflow.id)
            database.session.add(_workspace_agent_workflow_relation)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT_WORKFLOW)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent_workflow.to_dict(), _agent_workflow.permission), subject_ids), hidden_ids)
                        for _agent_workflow in enhanced_agent_workflows])

    @ns.doc(description="delete_workspace_agent_workflow_link")
    @ns.expect(workspace_linked_agent_workflow_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_workflow_model)))
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'agentWorkflowIds' not in _data:
            ns.abort(400, 'You must provide a list of agent workflow ids to add them to your workspace.')

        _agent_workflow_ids = set(_data['agentWorkflowIds'])

        # filter out relations that are no longer existing
        stmt = select(WorkspaceAgentWorkflowRelationModel.agent_workflow_id).where(
            (WorkspaceAgentWorkflowRelationModel.workspace_id == workspace_id) &
            (WorkspaceAgentWorkflowRelationModel.agent_workflow_id.in_(_agent_workflow_ids))
        )
        _agent_workflow_ids = _agent_workflow_ids - set(database.session.scalars(stmt))

        # now load complete agents including their permissions - this will filter out the ones
        # the current user has no permission for (those links will not be deleted)
        enhanced_agent_workflows: List[AgentWorkflowModel] = fetch_with_permissions(AgentWorkflowModel, _agent_workflow_ids)

        # delete existing relations
        stmt = delete(WorkspaceAgentWorkflowRelationModel).where(
            and_(
                WorkspaceAgentWorkflowRelationModel.workspace_id == workspace_id,
                WorkspaceAgentWorkflowRelationModel.agent_workflow_id.in_([agent_workflow.id for agent_workflow in enhanced_agent_workflows]),
            )
        )
        database.session.execute(stmt)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT_WORKFLOW)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent_workflow.to_dict(), _agent_workflow.permission), subject_ids), hidden_ids)
                        for _agent_workflow in enhanced_agent_workflows])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/widgets/', strict_slashes=False, methods=['GET', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceWidgetsEndpoint(Resource):
    @ns.doc("read_workspace_widgets_links")
    @ns.response(200, 'Success', fields.List(fields.Nested(widget_model)))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        stmt = select(WorkspaceWidgetRelationModel.widget_id).where(
            WorkspaceWidgetRelationModel.workspace_id == _workspace.id
        )

        widget_ids = database.session.scalars(stmt).all()

        enhanced_widgets: List[WidgetModel] = fetch_with_permissions(WidgetModel, widget_ids)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_widget.to_dict(), _widget.permission), subject_ids), hidden_ids)
                        for _widget in enhanced_widgets])

    @ns.doc(description="create_workspace_widget_link")
    @ns.expect(workspace_linked_widget_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(widget_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @propagate_principal()
    @requires_database_session
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'widgetIds' not in _data:
            ns.abort(400, 'You must provide a list of widget ids to add them to your workspace.')

        _widget_ids = set(_data['widgetIds'])

        # Reduce to set of ids that are not linked yet and required creation of new relations
        stmt = select(WorkspaceWidgetRelationModel.widget_id).where(
            (WorkspaceWidgetRelationModel.workspace_id == workspace_id) &
            (WorkspaceWidgetRelationModel.widget_id.in_(_widget_ids))
        )
        _widget_ids = _widget_ids - set(database.session.scalars(stmt))

        enhanced_widgets: List[WidgetModel] = fetch_with_permissions(WidgetModel, _widget_ids)

        for _widget in enhanced_widgets:
            _workspace_widget_relation = WorkspaceWidgetRelationModel(workspace_id=workspace_id,
                                                                      widget_id=_widget.id)
            database.session.add(_workspace_widget_relation)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_widget.to_dict(), _widget.permission), subject_ids), hidden_ids)
                        for _widget in enhanced_widgets])

    @ns.doc(description="delete_workspace_widget_link")
    @ns.expect(workspace_linked_widget_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(widget_model)))
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'widgetIds' not in _data:
            ns.abort(400, 'You must provide a list of widget ids to add them to your workspace.')

        _widget_ids = set(_data['widgetIds'])

        # filter out relations that are no longer existing
        stmt = select(WorkspaceWidgetRelationModel.widget_id).where(
            (WorkspaceWidgetRelationModel.workspace_id == workspace_id) &
            (WorkspaceWidgetRelationModel.widget_id.in_(_widget_ids))
        )
        _widget_ids = _widget_ids - set(database.session.scalars(stmt))

        # now load complete widgets including their permissions - this will filter out the ones
        # the current user has no permission for (those links will not be deleted)
        enhanced_widgets: List[WidgetModel] = fetch_with_permissions(WidgetModel, _widget_ids)

        # delete existing relations
        stmt = delete(WorkspaceWidgetRelationModel).where(
            and_(
                WorkspaceWidgetRelationModel.workspace_id == workspace_id,
                WorkspaceWidgetRelationModel.widget_id.in_([widget.id for widget in enhanced_widgets]),
            )
        )
        database.session.execute(stmt)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_widget.to_dict(), _widget.permission), subject_ids), hidden_ids)
                        for _widget in enhanced_widgets])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class WorkspaceGrantsEndpoint(Resource):
    @ns.doc(description="read_workspace_grants")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _workspace.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WORKSPACE)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class WorkspaceGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_workspace_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.WORKSPACE, subject_id=workspace_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceGrantEndpoint(Resource):
    @ns.doc(description="read_workspace_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str, assignee_type: str, assignee_id: str):
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _workspace.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WORKSPACE) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for workspace '{_workspace.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for workspace {workspace_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]

        return jsonify(permission.to_dict())

    @ns.doc(description="update_workspace_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def put(self, workspace_id: str, assignee_type: str, assignee_id: str):
        _data = request.get_json()
        _workspace = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _workspace.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WORKSPACE) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for workspace '{_workspace.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for workspace {workspace_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_workspace_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Workspace not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str, assignee_type: str, assignee_id: str):
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _workspace.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WORKSPACE) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for workspace '{_workspace.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for workspace {workspace_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, workspace_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<workspace_id>/system-instructions/', strict_slashes=False, methods=['GET', 'POST', 'DELETE', 'OPTIONS'])
class WorkspaceSystemInstructionsEndpoint(Resource):
    @ns.doc("read_workspace_system_instructions_links")
    @ns.response(200, 'Success', fields.List(fields.Nested(system_instruction_model)))
    @ns.response(404, 'System Instruction not found')
    @requires_database_session
    @propagate_principal()
    def get(self, workspace_id: str):
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read workspace with identifier '{workspace_id}'")

        stmt = select(WorkspaceSystemInstructionRelationModel.system_instruction_id).where(
            WorkspaceSystemInstructionRelationModel.workspace_id == _workspace.id
        )

        system_instruction_ids = database.session.scalars(stmt).all()

        enhanced_system_instructions: List[SystemInstructionModel] = fetch_with_permissions(SystemInstructionModel, system_instruction_ids)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WORKSPACE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_system_instruction.to_dict(), _system_instruction.permission), subject_ids), hidden_ids)
                        for _system_instruction in enhanced_system_instructions])

    @ns.doc(description="create_workspace_system_instruction_link")
    @ns.expect(workspace_linked_system_instruction_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(system_instruction_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workspace does not exist.')
    @propagate_principal()
    @requires_database_session
    def post(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'systemInstructionIds' not in _data:
            ns.abort(400, 'You must provide a list of system instruction ids to add them to your workspace.')

        _system_instruction_ids = set(_data['systemInstructionIds'])

        # Reduce to set of ids that are not linked yet and required creation of new relations
        stmt = select(WorkspaceSystemInstructionRelationModel.system_instruction_id).where(
            (WorkspaceSystemInstructionRelationModel.workspace_id == workspace_id) &
            (WorkspaceSystemInstructionRelationModel.system_instruction_id.in_(_system_instruction_ids))
        )
        _system_instruction_ids = _system_instruction_ids - set(database.session.scalars(stmt))

        enhanced_system_instructions: List[SystemInstructionModel] = fetch_with_permissions(SystemInstructionModel, _system_instruction_ids)

        for _system_instruction in enhanced_system_instructions:
            _workspace_system_instruction_relation = WorkspaceSystemInstructionRelationModel(workspace_id=workspace_id,
                                                                      system_instruction_id=_system_instruction.id)
            database.session.add(_workspace_system_instruction_relation)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_system_instruction.to_dict(), _system_instruction.permission), subject_ids), hidden_ids)
                        for _system_instruction in enhanced_system_instructions])

    @ns.doc(description="delete_workspace_system_instruction_link")
    @ns.expect(workspace_linked_system_instruction_ids)
    @ns.response(200, 'Success', fields.List(fields.Nested(system_instruction_model)))
    @ns.response(404, 'The workspace does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, workspace_id: str):
        _data = request.get_json()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)

        if _workspace is None:
            ns.abort(404, f"A workspace with identifier '{workspace_id}' does not exist")

        grant = get_user_access_for(_workspace)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update workspace with identifier '{workspace_id}'")

        if 'systemInstructionIds' not in _data:
            ns.abort(400, 'You must provide a list of system instruction ids to add them to your workspace.')

        _system_instruction_ids = set(_data['systemInstructionIds'])

        # filter out relations that are no longer existing
        stmt = select(WorkspaceSystemInstructionRelationModel.system_instruction_id).where(
            (WorkspaceSystemInstructionRelationModel.workspace_id == workspace_id) &
            (WorkspaceSystemInstructionRelationModel.system_instruction_id.in_(_system_instruction_ids))
        )
        _system_instruction_ids = _system_instruction_ids - set(database.session.scalars(stmt))

        # now load complete system_instructions including their permissions - this will filter out the ones
        # the current user has no permission for (those links will not be deleted)
        enhanced_system_instructions: List[SystemInstructionModel] = fetch_with_permissions(SystemInstructionModel, _system_instruction_ids)

        # delete existing relations
        stmt = delete(WorkspaceSystemInstructionRelationModel).where(
            and_(
                WorkspaceSystemInstructionRelationModel.workspace_id == workspace_id,
                WorkspaceSystemInstructionRelationModel.system_instruction_id.in_([system_instruction.id for system_instruction in enhanced_system_instructions]),
            )
        )
        database.session.execute(stmt)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify([with_hidden(with_favorite(with_access_permission(_system_instruction.to_dict(), _system_instruction.permission), subject_ids), hidden_ids)
                        for _system_instruction in enhanced_system_instructions])

    @ns.doc(False)
    def options(self, workspace_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    
 
@ns.route('/<workspace_id>/restore')
class RestoreWorkspaceEndpoint(Resource):
    @ns.doc(description="restore_deleted_workspace")
    @ns.response(200, 'Workspace restored successfully', model=workspace_model)
    @ns.response(404, 'The workspace does not exist or is not deleted')
    @requires_database_session
    @propagate_principal()
    def patch(self, workspace_id: str):
        """Restores a soft-deleted workspace."""
        current_user = SessionContext.get_current_user()
        _workspace: WorkspaceModel = WorkspaceModel.query.get(workspace_id)
        if _workspace is None or _workspace.deleted_at is None:
            ns.abort(404, f"Workspace with identifier '{workspace_id}' is not deleted or does not exist")

        # Check if the current user is the creator of the workspace
        if _workspace.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this workspace")

       
        _workspace.deleted_at = None
        _workspace.deleted_by = None  
        database.session.commit()
        return jsonify(_workspace.to_dict())
    @ns.doc(False)
    def options(self, workspace_id: str):
        return '', 200
        
