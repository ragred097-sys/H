import json
import os
from typing import cast

from flask import request, Response
from flask_restx import Namespace, Resource, fields, reqparse
from werkzeug.datastructures import FileStorage

from maxgpt.api.internal.utils import propagate_principal, requires_database_session
from maxgpt.core.ingest_process import FileIngestProcess, TextIngestProcess, WebCrawlIngestProcess,ImageIngestProcess
from maxgpt.modules import ModuleRegistry, ModuleType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.services.database_model import DataSourceModel, DocumentType

ns = Namespace('Data Ingestion',
               description='Operations for ingesting files into the application vector index stores.', path="/ingest")


ingest_override_parameter_model = ns.model("Ingest Override Parameter", {
    'name': fields.String(description="The name of the parameter.", required=True),
    'value': fields.String(description="The value of the parameter", required=True),
})

parser = reqparse.RequestParser()
parser.add_argument('file', type=FileStorage, location='files', required=True)
parser.add_argument('llmId', type=str, location='form', required=True)
parser.add_argument('dataSourceId', type=str, location='form', required=True)
parser.add_argument('overrides', type=str, location='form', default="[]")

ingestion_text_data_object_model = ns.model('Ingestion Text-Data Object', {
    'llmId': fields.String(description="The identifier of an existing llm module.", required=True),
    'dataSourceId': fields.String(description="The UUID of n existing data source.", required=True),
    'overrides': fields.List(fields.Nested(ingest_override_parameter_model),
                             description="Expert configurations to configure the ingestion process in a particular way. Do not use if you are not sure what to do.",
                             default=[], required=False),
    'content': fields.String(description="The textual content that should be ingested.", required=True)
})

ingestion_website_model = ns.model('Ingestion Website-Data Object', {
    'llmId': fields.String(description="The identifier of an existing llm module.", required=True),
    'dataSourceId': fields.String(description="The UUID of n existing data source.", required=True),
    'overrides': fields.List(fields.Nested(ingest_override_parameter_model),
                             description="Expert configurations to configure the ingestion process in a particular way. Do not use if you are not sure what to do.",
                             default=[], required=False),
    'url': fields.String(description="The url of the website you want to crawl for ingestion.", required=True)
})


ALLOWED_IMAGE_TYPES = ('.png', '.jpg', '.jpeg', '.webp', '.svg', '.xml', '.gif', '.bmp')

@ns.route('/file/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class IngestFileEndpoint(Resource):
    @ns.doc(description="Ingest data from a file to the application vector store index and data storage.")
    @ns.expect(parser)
    @requires_database_session
    @propagate_principal()
    def post(self):
        _args = parser.parse_args() # to get the file

        _file = _args['file']
        _file_length = _file.seek(0, os.SEEK_END)
        _file.seek(0, os.SEEK_SET)

        _llm_id = _args['llmId']
        _data_source_id_ = _args['dataSourceId']

        _llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_llm_id))
        _data_source = DataSourceModel.query.get(_data_source_id_)

        if _llm is None:
            ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
        elif _llm.get_spec().get_module_type() != ModuleType.LLM:
            ns.abort(404,
                     f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{_llm.get_spec().get_module_type()}'")

        if _data_source is None:
            ns.abort(404, f"No data source found for identifier '{_data_source_id_}'")

        _overrides = json.loads(_args['overrides']) if 'overrides' in _args and _args['overrides'] != "[]" else []

        process = FileIngestProcess(file=_file, data_source=_data_source, llm=_llm, overrides=_overrides, file_length=_file_length)
        return Response(process.execute(), mimetype='text/event-stream')

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/text/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class IngestTextEndpoint(Resource):
    @ns.expect(ingestion_text_data_object_model)
    @ns.doc("Ingest raw text to the application vector store index and data storage.")
    @requires_database_session
    @propagate_principal()
    def post(self):
        _data = request.get_json()
        if 'content' not in _data:
            raise ValueError(
                'To ingest a text, you need to provide text of course.')
        if 'dataSourceId' not in _data:
            raise ValueError(
                'To ingest a text, you need to provide a valid identifier that refers to an existing data source module.')
        if 'llmId' not in _data:
            raise ValueError(
                'To ingest a text, you need to provide a valid identifier that refers to an existing llm module.')

        _data_source = DataSourceModel.query.get(_data['dataSourceId'])
        _llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_data['llmId']))
        _overrides = _data['overrides'] if 'overrides' in _data else []

        process = TextIngestProcess(content=request.json['content'], data_source=_data_source, llm=_llm, overrides=_overrides)
        return Response(process.execute(), mimetype='text/event-stream')

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/website/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class IngestWebsiteEndpoint(Resource):
    @ns.expect(ingestion_website_model)
    @ns.doc("Ingest the textual content of a website to the application vector store index. The content is not persisted additionally into the blob or file storage.")
    @requires_database_session
    @propagate_principal()
    def post(self):
        _data = request.get_json()
        if 'url' not in _data:
            raise ValueError(
                'To ingest website content, you need to provide the url of the website of course.')
        if 'dataSourceId' not in _data:
            raise ValueError(
                'To ingest a text, you need to provide a valid identifier that refers to an existing data source module.')
        if 'llmId' not in _data:
            raise ValueError(
                'To ingest a text, you need to provide a valid identifier that refers to an existing llm module.')

        _data_source = DataSourceModel.query.get(_data['dataSourceId'])
        _llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_data['llmId']))
        _overrides = _data['overrides'] if 'overrides' in _data else []

        process = WebCrawlIngestProcess(website_url=request.json['url'], data_source=_data_source, llm=_llm, overrides=_overrides)
        return Response(process.execute(), mimetype='text/event-stream')


    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
    

@ns.route('/image/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class IngestImageEndpoint(Resource):
    @ns.doc(description="Ingest image data to the application vector store index and data storage.")
    @ns.expect(parser)
    @requires_database_session
    @propagate_principal()
    def post(self):
        _args = parser.parse_args()  # to get the file

        _file = _args['file']
        _file_length = _file.seek(0, os.SEEK_END) 
        _file.seek(0, os.SEEK_SET) 

        MAX_IMAGE_UPLOAD_SIZE_IN_MB = int(os.getenv('MAX_IMAGE_UPLOAD_SIZE_IN_MB',5))
           
        max_file_size_bytes = MAX_IMAGE_UPLOAD_SIZE_IN_MB * 1024 * 1024  # Convert MB to bytes 

        # Check if the file size exceeds the allowed limit
        if _file_length > max_file_size_bytes:
            ns.abort(400, f"File size exceeds the {MAX_IMAGE_UPLOAD_SIZE_IN_MB} MB limit.") 

        _llm_id = _args['llmId']
        _data_source_id_ = _args['dataSourceId']

        _llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_llm_id))
        _data_source = DataSourceModel.query.get(_data_source_id_)

        if _llm is None:
            ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
        elif _llm.get_spec().get_module_type() != ModuleType.LLM:
            ns.abort(404,
                     f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{_llm.get_spec().get_module_type()}'")

        if _data_source is None:
            ns.abort(404, f"No data source found for identifier '{_data_source_id_}'") 

        if not _file.filename.lower().endswith(ALLOWED_IMAGE_TYPES): 
            ns.abort(400, f"Invalid file type. Supported formats: {', '.join(ext.upper().lstrip('.') for ext in ALLOWED_IMAGE_TYPES)}.")

        # Validate LLM supported inputs 
        if DocumentType.IMAGE not in _llm.get_supported_inputs():
            ns.abort(400, f"The LLM module '{_llm_id}' does not support image inputs.")

        _overrides = json.loads(_args['overrides']) if 'overrides' in _args and _args['overrides'] != "[]" else []

        # Instantiate ImageIngestProcess with correct argument name
        process = ImageIngestProcess(image_file=_file, data_source=_data_source,llm_id=_llm_id, llm=_llm, overrides=_overrides)
        return Response(process.execute(), mimetype='image/event-stream')

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
