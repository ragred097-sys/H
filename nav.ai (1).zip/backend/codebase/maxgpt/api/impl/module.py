import re
from typing import List

from flask import request, abort, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import select, and_
from sqlalchemy.sql.operators import or_

from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, tagged_model, \
    with_favorite, DefaultPreferenceKey, get_default_module_ids_for_type, with_default
from maxgpt.modules import ModuleType, ModuleRegistry, ModuleSpecRegistry
from maxgpt.services import database, DefaultApplicationAccessRole
from maxgpt.services.database_model import ModuleModel, DataSourceModel, \
    AssistantModuleRelationModel, ConversationModuleRelationModel, UserFavoriteModel, FavoriteSubject, DocumentType, \
    ModuleCapabilityModel, ModuleCapabilityRelationModel
from maxgpt.services.internal import ShallowTag
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('Modules',
               description='System modules that are registered and available in the currently running application.',
               path='/module')

module_parameter_model = ns.model("ModuleParameter", {
    'name': fields.String(description="The name of the module parameter.", required=True),
    'value': fields.String(description="The value of the module parameter", required=True)
})

capability_model = ns.model('Capability', {
    'name': fields.String(required=True),
    'label': fields.String(required=True),
    'value': fields.String(required=True)
})

module_model = ns.inherit('Module', audited_model(ns), tagged_model(ns), {
    'id': fields.String(description="The identifier of the module.", max_length=36, required=True, readonly=True),
    'name': fields.String(description="The unique name of the typed module.", max_length=100, required=True),
    'description': fields.String(description="A short summary of the module.", max_length=500, required=False),
    'specId': fields.String(description="The identifier of the module spec on which this module has been defined", max_length=36, required=True),
    'supportedInputs': fields.List(fields.String(description="Document type", enum=[t.name for t in DocumentType])),
    'parameters': fields.List(fields.Nested(module_parameter_model), required=False),
    'default': fields.Boolean(description="Indicates if this module is the default for the current context", required=False, default=False, example=False),
    'capabilities': fields.List(fields.Nested(capability_model), required=True)
})

capability_full_model = ns.model('CapabilityFull', {
    'id': fields.String(required=True),
    'name': fields.String(required=True),
    'label': fields.String(required=True),
    'description': fields.String(required=False),
    'module_type': fields.String(required=True),
    'default': fields.Boolean(required=True)
})

# To avoid confusion: The 's' is attached to the configured path value of this namespace. Meaning this endpoint is
@ns.route('s/', strict_slashes=False)
class ModulesEndpoint(Resource):
    @ns.doc(description="list_modules")
    @ns.param("type", description="The type of the module", _in="query")
    @ns.param("name", description="A name pattern as regular expression to look for. Start and end marks are added automatically", _in="query")
    @ns.param("module_spec_id", description="The id of a module spec to retrieve only module for the given module specification", _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(module_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available modules that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        _type_filter = request.args.get('type') 
        _name_pattern = request.args.get('name')
        _module_specification_id = request.args.get('module_spec_id')
        module_type = None

        try:
            module_type = ModuleType(_type_filter) if _type_filter else None
        except ValueError:
            ns.abort(400, f"Module type '{_type_filter}' is invalid.") 

        modules = ModuleRegistry.get_modules(module_type) 
        if _name_pattern is not None:
            modules = list(filter(lambda m: bool(re.match("^" + _name_pattern + "$", m.get_name())), modules))

        if _module_specification_id is not None:
            modules = list(filter(lambda m: m.get_spec().get_id() == _module_specification_id, modules))
 
        default_ids = get_default_module_ids_for_type(module_type) 
        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.MODULE)
        )

        subject_ids = set(database.session.scalars(stmt)) 
        result = [
            with_default(
                with_favorite(module.to_dict(show_secrets=SessionContext.is_administrator() or SessionContext.is_data_engineer()), subject_ids),
                module.get_id() if module.get_id() in default_ids else None
            )
            for module in modules
        ]
        
        return jsonify(result)

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False)
class ModuleFactoryEndpoint(Resource):
    @ns.expect(module_model)
    @ns.doc("create_module")
    @ns.response(200, 'Success', module_model)
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value, DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value])
    def post(self):
        """Creates a new module"""
        _data = request.get_json()

        module_spec = ModuleSpecRegistry.get_module_spec(_data['specId'])
        if not module_spec:
            ns.abort(400, f"Module spec '{_data['specId']}' does not exist.")

        _shallow_tags = []
        if _data.get('tags') is not None:
            for tag in _data['tags']:
                _shallow_tags.append(ShallowTag(tag['id'], tag['name']))

        _supported_inputs: List[DocumentType] = []
        if _data.get('supportedInputs') is not None:
            for document_type_name in _data['supportedInputs']:
                _supported_inputs.append(DocumentType(document_type_name))

        # NEW: Extract capabilities from payload and convert to dict
        _capabilities = {cap['name']: cap['value'] for cap in _data.get('capabilities', [])}

        module = ModuleRegistry.create_module(_data['name'], _data.get('description'), module_spec,
                                              {parameter['name']: parameter['value'] for parameter in _data['parameters']},
                                              _shallow_tags, _supported_inputs, capabilities=_capabilities)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.MODULE)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Use with_default with None (always False for POST)
        module_dict = with_favorite(module.to_dict(show_secrets=True), subject_ids)
        module_dict = with_default(module_dict, None)
        return jsonify(module_dict)

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<module_id>/', strict_slashes=False)
class ModuleEndpoint(Resource):
    @ns.doc("update_module")
    @ns.expect(module_model)
    @ns.response(200, 'Success', module_model)
    @ns.response(404, 'Module not found')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value, DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value])
    def put(self, module_id: str):
        """Updates an existing module"""
        _data = request.get_json()

        _shallow_tags = []
        if _data.get('tags') is not None:
            for tag in _data['tags']:
                _shallow_tags.append(ShallowTag(tag['id'], tag['name']))

        _supported_inputs: List[DocumentType] = []
        if _data.get('supportedInputs') is not None:
            for document_type_name in _data['supportedInputs']:
                _supported_inputs.append(DocumentType(document_type_name))

        # Extract capabilities from payload and convert to dict (NEW)
        _capabilities = {cap['name']: cap['value'] for cap in _data.get('capabilities', [])}

        module =  ModuleRegistry.update_module(module_id, _data['name'], _data.get ('description'),
                                               {parameter['name']: parameter['value'] for parameter in _data['parameters']},
                                               _shallow_tags,
                                               _supported_inputs,
                                               capabilities=_capabilities)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.MODULE)
        )
        subject_ids = set(database.session.scalars(stmt))
 
        module_type = module.get_spec().get_module_type() 
        default_ids = get_default_module_ids_for_type(module_type)
        module_dict = with_favorite(module.to_dict(show_secrets=True), subject_ids)
        module_dict = with_default(module_dict, module.get_id() if module.get_id() in default_ids else None)
        return jsonify(module_dict)

    @ns.doc("get_module")
    @ns.param("module_id", description="The identifier of the module.", _in="path")
    @ns.response(200, 'Success', fields.Nested(module_model))
    @ns.response(404, 'Module not found')
    @requires_database_session
    @propagate_principal()
    def get(self, module_id: str):
        """Returns a module for the given identifier"""
        current_user = SessionContext.get_current_user()

        module = ModuleRegistry.get_module(module_id)

        if module is None:
            ns.abort(404, f"No module found for identifier '{module_id}'")

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.MODULE)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Use new utility for default logic
        module_type = module.get_spec().get_module_type() 
        default_ids = get_default_module_ids_for_type(module_type)
        module_dict = with_favorite(module.to_dict(show_secrets=SessionContext.is_administrator() or SessionContext.is_data_engineer()), subject_ids)
        module_dict = with_default(module_dict, module.get_id() if module.get_id() in default_ids else None)
        return jsonify(module_dict)

    @ns.doc("delete_module")
    @ns.response(200, 'Success', module_model)
    @ns.response(404, 'The module does not exist.')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value, DefaultApplicationAccessRole.MAXGPT_DATA_ENGINEER.value])
    def delete(self, module_id: str):
        """Deletes an existing Module if possible"""

        # We must ensure that we can only delete if the module is not used anywhere.
        # TODO (next step): logical delete by setting deleted_at    , deleted_by audit fields

        _module = ModuleModel.query.get(module_id)

        if _module is None:
            ns.abort(404, f"No module found for identifier '{module_id}'")

        # Check 3 places:
        #   DataSourceModel.embedding_model_id /.vectore_store_id / file_storage_id
        #   AssistantModuleRelationModel.module_id
        #   ConversationModuleRelationModel.module_id
        if len(AssistantModuleRelationModel.query.filter_by(module_id=_module.id).all()) > 0:
            abort(409, f"Conflict - Module already in use by assistants.")
        if len(ConversationModuleRelationModel.query.filter_by(module_id=_module.id).all()) > 0:
            abort(409, f"Conflict - Module already in use by conversations.")
        if len(DataSourceModel.query.filter(or_(DataSourceModel.embedding_model_id == _module.id,
                                                   or_(
                                                        DataSourceModel.vector_store_id == _module.id,
                                                        DataSourceModel.file_storage_id == _module.id)
                                                   )
                                               ).all()) > 0:
            abort(409, f"Conflict - Module already in use by data sources.")

        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.MODULE,
                UserFavoriteModel.subject_id == module_id
            )
        ).delete()

        _module = ModuleRegistry.delete_module(module_id)

        # attach favorite information
        subject_ids = set([])
        # Use new utility for default logic
        module_type = _module.get_spec().get_module_type()
        default_ids = get_default_module_ids_for_type(module_type)
        module_dict = with_favorite(_module.to_dict(show_secrets=True), subject_ids)
        module_dict = with_default(module_dict, _module.get_id() if _module.get_id() in default_ids else None)
        return jsonify(module_dict)

    @ns.doc(False)
    def options(self, module_id: str):
        # Handle preflight OPTIONS request
        return '', 200