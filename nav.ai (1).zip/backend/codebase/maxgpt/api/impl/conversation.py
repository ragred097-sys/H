import json
import logging
import os
from io import BytesIO
from itertools import chain
from typing import Iterable, List, Optional, cast, Union

from flask import Response, request, jsonify, send_file, stream_with_context
from flask_restx import Namespace, Resource, fields, reqparse
from llama_index.core.agent.workflow import AgentInput, AgentStream, AgentOutput, ToolCall, ToolCallResult
from sqlalchemy import asc
from sqlalchemy.orm import joinedload, Session
from werkzeug.datastructures.file_storage import FileStorage
from werkzeug.utils import secure_filename

from maxgpt.api.impl.data_source import data_source_model, data_source_to_dict
from maxgpt.api.internal.utils import add_simple_text_message, yield_token_chunks, get_string_token, \
    yield_message_object, tagged_model, create_thumbnail_for_media_file, extract_video_length, determine_document_type, \
    format_as_ndjson, convert_async_generator, get_named_lock, yield_context_nodes, add_message_event, \
    with_message_events, context_node_to_content_dict, attachment_api_structure
from maxgpt.api.internal.utils import propagate_principal, requires_database_session, audited_model
from maxgpt.core.agentic_chat_process import AgenticChatProcess, AgenticWorkflowSourceNodeEvent
from maxgpt.core.chat_process import ChatProcess, ChatResponse
from maxgpt.modules import ModuleRegistry, ModuleType
from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.services.database_model import ConversationModel, database, MessageRole, SystemInstructionModel, \
    ConversationModuleRelationModel, DataSourceModel, ConversationDataSourceRelationModel, DataSourceTagRelationModel, \
    ConversationTagRelationModel, AttachmentModel, AssistantModel, DocumentType, MessageEventType, \
    ConversationAttachmentRelationModel, AgentWorkflowModel, SharedConversationModel
from maxgpt.services.database_model import MessageModel, MessagePartModel, MessagePartType
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.eqty.util import is_eqty_enabled

ns = Namespace('Conversation', description='Operations related to a Conversation.', path="/conversation")

message_override_parameter_model = ns.model("Message Override Parameter", {
    'name': fields.String(description="The name of the parameter.", required=True),
    'value': fields.String(description="The value of the parameter", required=True),
})

message_part_model = ns.model('MessagePart', {
    'type': fields.String(description="The type of the message part (TEXT | BASE64_IMAGE)", enum=[t.name for t in MessagePartType],
                          required=True, default=MessagePartType.TEXT.name, example=MessagePartType.TEXT.name),
    'content': fields.String(description="The content of the part encoded as string", required=False),
    'sequence': fields.Integer(description="The sequence of the part", required=True, readonly=True),
})

message_model = ns.model('Message', {
    'id': fields.String(description="The UUID of the message.", required=True, readonly=True),
    'role': fields.String(description="The role of the message.", enum=[r.name for r in MessageRole],
                          default=MessageRole.USER.name, required=False, example=MessageRole.USER.name),
    'conversationId': fields.String(description="The UUID of the conversation to which the message belongs.",
                                     required=True, readonly=True),
    'parts': fields.List(fields.Nested(message_part_model), description='The list of message parts'),

    'overrides': fields.List(fields.Nested(message_override_parameter_model), description="Expert configurations to configure message processing in a particular way. Do not use if you are not sure what to do.",
                             default=[], required=False),

    'timestamp': fields.DateTime(description="The creation time of this resource", required=True, readonly=True),
})

conversation_model = ns.inherit('Conversation', audited_model(ns), tagged_model(ns), {
    'id': fields.String(description="The UUID of the model.", required=True, readonly=True),
    'name': fields.String(description="The name of the model.", max_length=80, required=False),
    'llmIds': fields.List(fields.String, description="The UUIDs of the user's language models.", required=True),
    'dataSourceIds': fields.List(fields.String, description="The UUIDs of the user's data sources.", required=False),
    'assistantId': fields.List(fields.String, description="The UUIDs of the assistant this conversation belongs to.",
                               required=False),
    'agentWorkflowId': fields.List(fields.String, description="The UUIDs of the agent_workflow if provided.",
                               required=False)
})

attachment_model = ns.inherit('Attachment', audited_model(ns), attachment_api_structure)

attachment_parser = reqparse.RequestParser()
attachment_parser.add_argument('file', type=FileStorage, location='files', required=True, help='A set of multi media files.')
attachment_parser.add_argument('fileStorageID', type=str, location='form', required=False, help='Override for file storage.')


def process_assistant_response(conversation: ConversationModel, m_role: MessageRole, assistant_response: str, event_by_type: list[(MessageEventType, dict, dict)] = []):
    # Add message to the database
    message = add_simple_text_message(conversation, m_role, assistant_response)
    for i, event_with_type in enumerate(event_by_type):
        add_message_event(message_id=message.id, sequence=i, type=event_with_type[0], content=json.dumps(event_with_type[1], indent=2), meta=(json.dumps(event_with_type[2], indent=2)))
    yield from yield_message_object(message)


def get_conversation(conversation_id: str):
    """
    Retrieves a conversation by its ID and checks if the current user has access to it.

    Args:
        conversation_id (str): The ID of the assistant to retrieve.
    """
    _conversation = ConversationModel.query.get(conversation_id)
    if _conversation is None:
        ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
    elif not is_access_granted(_conversation):
        ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")
    
    return _conversation


# To avoid confusion: The 's' is attached to the configured path value of this namespace. Meaning this endpoint is
# attached to /conversations/
@ns.route('s/', strict_slashes=False)
class ConversationsEndpoint(Resource):
    @ns.doc("list_conversations")
    @ns.response(200, 'Success', fields.List(fields.Nested(conversation_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all stored conversations for the current user."""
        conversations = ConversationModel.query.filter(ConversationModel.creator_id == SessionContext.get_current_user().get_id()).all()
        return jsonify([conversation.to_dict() for conversation in conversations])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False)
class ConversationFactoryEndpoint(Resource):
    @ns.expect(conversation_model)
    @ns.doc("create_conversation")
    @ns.response(200, 'Success', conversation_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new conversation"""
        _data = request.get_json()
        _name = _data.get('name')
        _llms = _data.get('llmIds')
        _data_sources = _data.get('dataSourceIds')

        _conversation = ConversationModel(name=_name)

        if _llms:
            for _llm_id in _llms:
                llm = ModuleRegistry.get_module(_llm_id)
                if llm is None:
                    ns.abort(422, f"Referenced entity not found: No module of type {ModuleType.LLM} with identifier '{_llm_id}'")
                elif llm.get_spec().get_module_type() != ModuleType.LLM:
                    ns.abort(422, f"Referenced entity not found: No module of type {ModuleType.LLM} with identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
                else:
                    _conversation.llms.append(ConversationModuleRelationModel(conversation_id=_conversation.id,
                                                                              module_id=llm.get_id()))
        if len(_llms) == 0:
            ns.abort(400, f"You need to assign at least one LLM to conversation '{_conversation.name}'")

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _conversation.tag_relations.append(
                    ConversationTagRelationModel(conversation_id=_conversation.id, tag_id=_shallow_tag['id']))

        if _data.get('systemInstructionIds'):
            for _system_instruction_id in _data['systemInstructionIds']:
                _system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(_system_instruction_id)
                add_simple_text_message(_conversation, MessageRole.SYSTEM, _system_instruction.message)

        if _data_sources:
            for _data_source_id in _data_sources:
                _data_source: Optional[DataSourceModel] = DataSourceModel.query.get_or_404(_data_source_id, f"No data source found for identifier '{_data_source_id}'.")
                _conversation.data_sources.append(ConversationDataSourceRelationModel(conversation_id=_conversation.id,
                                                                                      data_source_id=_data_source.id))

        database.session.add(_conversation)
        database.session.commit()

        return jsonify(_conversation.to_dict())

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/', strict_slashes=False)
@ns.param('conversation_id', 'A valid ID of an existing conversation.')
class ConversationEndpoint(Resource):
    @ns.doc("update_conversation")
    @ns.expect(conversation_model)
    @ns.response(200, 'Success', conversation_model)
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'Conversation not found.')
    @requires_database_session
    @propagate_principal()
    def put(self, conversation_id):
        """Updates the conversation matching the given conversation_id with the fields of the provided data inside the http request body"""
        _data = request.get_json()

        _conversation = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        # Mandatory fields
        _conversation.name = _data['name'][:79] if 'name' in _data else _conversation.name

        session = Session.object_session(_conversation)
        if _data.get('llmIds'):
            for existing_relation in _conversation.llms:
                session.delete(existing_relation)
            _conversation.llms = []
            for _llm_id in _data['llmIds']:
                llm = ModuleRegistry.get_module(_llm_id)
                if llm is None:
                    ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
                elif llm.get_spec().get_module_type() != ModuleType.LLM:
                    ns.abort(404,
                             f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
                else:
                    _conversation.llms.append(
                        ConversationModuleRelationModel(conversation_id=_conversation.id, module_id=llm.get_id()))

        if len(_conversation.llms) == 0:
            ns.abort(404, f"You need to assign at least one LLM to conversation '{_conversation.name}'")

        if _data.get('tags') is not None:
            for _tag_relation in _conversation.tag_relations:
                session.delete(_tag_relation)
            _conversation.tag_relations = []
            for _shallow_tag in _data['tags']:
                _conversation.tag_relations.append(
                    ConversationTagRelationModel(conversation_id=_conversation.id, tag_id=_shallow_tag['id']))

        if _data.get('dataSourceIds'):
            for existing_relation in _conversation.data_sources:
                session.delete(existing_relation)
            _conversation.data_sources = []
            for _data_source_id in _data['dataSourceIds']:
                _data_source: Optional[DataSourceModel] = DataSourceModel.query.get(_data_source_id)
                if _data_source is None:
                    ns.abort(404, f"No data source found for identifier '{_data_source_id}'.")
                else:
                    _conversation.data_sources.append(
                        ConversationDataSourceRelationModel(conversation_id=_conversation.id, data_source_id=_data_source.id))

        database.session.commit()

        return jsonify(_conversation.to_dict())


    @ns.doc("get_conversation")
    @ns.response(200, 'Success', conversation_model)
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id):
        """Returns the conversation matching the given identifier"""
        conversation = ConversationModel.query.get(conversation_id)

        if conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(conversation):
            ns.abort(403, f"The conversation with identifier '{conversation_id}' is not accessible for the current user.")

        return jsonify(conversation.to_dict())

    @ns.doc("delete_conversation")
    @ns.response(200, 'Success')
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @requires_database_session
    @propagate_principal()
    def delete(self, conversation_id):
        """Removes the conversation matching the given identifier from the current users history"""
        conversation = ConversationModel.query.get(conversation_id)

        if conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(conversation):
            ns.abort(403, f"The conversation with identifier '{conversation_id}' is not accessible for the current user.")

        database.session.delete(conversation)
        return jsonify(conversation.to_dict())

    @ns.doc(False)
    def options(self, conversation_id):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/messages/', strict_slashes=False)
class MessagesEndpoint(Resource):
    @ns.doc(description="list_messages")
    @ns.response(200, 'Success', fields.List(fields.Nested(message_model)))
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id):
        """Returns a list of all messages of the given conversations in chronological order."""
        conversation = ConversationModel.query.get(conversation_id)

        if conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(conversation):
            ns.abort(403, f"The conversation with identifier '{conversation_id}' is not accessible for the current user.")

        messages = (database.session.query(MessageModel)
                    .filter_by(conversation_id=conversation_id)
                    .order_by(asc(MessageModel.timestamp))
                    .options(joinedload(MessageModel.parts)))

        # todo: ensure that messages are sorted by timestamp!
        return jsonify([with_message_events(message.to_dict()) for message in messages])

    @ns.doc(False)
    def options(self, conversation_id):
        # Handle preflight OPTIONS request
        return '', 200


def is_access_granted(conversation: ConversationModel):
    return conversation.creator_id == SessionContext.get_current_user().get_id()


@ns.route('/<conversation_id>/message/', strict_slashes=False)
@ns.param('conversation_id', 'A valid UUID of an existing conversation.')
class MessageEndpoint(Resource):
    @ns.doc(description="post_message")
    @ns.expect(message_model)
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @propagate_principal()
    def post(self, conversation_id):
        """Send a new message in the given conversation to the AI framework and returns the final response."""
        try:
            conversation = ConversationModel.query.get(conversation_id)
            if conversation is None:
                ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
            elif not is_access_granted(conversation):
                ns.abort(403,
                         f"The conversation with identifier '{conversation_id}' is not accessible for the current user.")

            data = request.get_json()

            # We allow adding system messages (aka system instructions) to an existing conversation to change the response behavior.
            if data.get('role') == MessageRole.SYSTEM.name:
                system_message = MessageModel(role=MessageRole.SYSTEM, conversation=conversation)
                database.session.add(system_message)
                for i, part in enumerate(data['parts']):
                    message_part_type = MessagePartType[part['type']]
                    message_part_content = part['content']
                    if message_part_type == MessagePartType.TEXT:
                        database.session.add(
                            MessagePartModel(type=message_part_type, sequence=i,
                                             content=message_part_content, message=system_message))
                    else:
                        raise AssertionError(f'unsupported type of message part "{part["type"]}" for system messages.')
                return Response(get_string_token(message_text="Instruction received."), mimetype='application/json')

            # We also support impersonating as assistant, so you can add assistant messages to the conversation history
            # without agent or llm interaction.
            if data.get('role') == MessageRole.ASSISTANT.name:
                assistant_message = MessageModel(role=MessageRole.ASSISTANT, conversation=conversation)
                database.session.add(assistant_message)
                assistant_response = ""
                for i, part in enumerate(data['parts']):
                    message_part_type = MessagePartType[part['type']]
                    message_part_content = part['content']
                    if message_part_type == MessagePartType.TEXT:
                        database.session.add(
                            MessagePartModel(type=message_part_type, sequence=i,
                                             content=message_part_content, message=assistant_message))
                        assistant_response += message_part_content + "\n"
                    else:
                        raise AssertionError(f'unsupported type of message part "{part["type"]}" for assistant messages.')
                return Response(get_string_token(message_text=assistant_response.strip()), mimetype='application/json')

            if conversation.agent_workflow_id:
                process = AgenticChatProcess(conversation=conversation, user_message_parts=data['parts'],
                                      overrides=data.get('overrides', []))
                database.session.commit()

                @stream_with_context
                def event_stream(_process):
                    chat_response = _process.async_execute()
                    yield from yield_message_object(process.get_user_message())

                    aggregated: str = ""
                    message_events_with_type: List[(MessageEventType, dict)]= []
                    try:
                        for event in convert_async_generator(chat_response):
                            if isinstance(event, AgenticWorkflowSourceNodeEvent):
                                _event = {
                                    "type": event.type,
                                    "content": event.content_dict,
                                    "meta": event.meta
                                }
                                message_events_with_type.append(
                                    (MessageEventType.CONTEXT_NODE, _event["content"], _event["meta"]))
                                yield format_as_ndjson(_event)
                            if isinstance(event, AgentInput):
                                _event = {
                                    "type": MessageEventType.AGENT_INPUT.value,
                                    "content": {
                                        "input" : [message.content for message in event.input]
                                    },
                                    "meta": {
                                        "nodeId": event.current_agent_name,
                                        "agent": {
                                            "id": event.current_agent_name.split("#")[2],
                                            "name": event.current_agent_name.split("#")[1],
                                            "type": event.current_agent_name.split("#")[0],
                                        }
                                    }
                                }
                                message_events_with_type.append((MessageEventType.AGENT_INPUT, _event["content"], _event["meta"]))
                                yield format_as_ndjson(_event)
                            elif isinstance(event, AgentStream):
                                if event.delta and event.delta != "":
                                    aggregated += event.delta
                                    yield format_as_ndjson({
                                        "type": MessageEventType.CHUNK.value,
                                        "content": event.delta,
                                        "meta": {
                                            "nodeId": event.current_agent_name,
                                            "agent": {
                                                "id": event.current_agent_name.split("#")[2],
                                                "name": event.current_agent_name.split("#")[1],
                                                "type": event.current_agent_name.split("#")[0],
                                            },
                                        }
                                    })
                            elif isinstance(event, AgentOutput):
                                _event = {
                                    "type": MessageEventType.AGENT_OUTPUT.value,
                                    "content": {
                                        "toolCalls": [call.tool_name for call in event.tool_calls],
                                        "output": event.response.content
                                    },
                                    "meta": {
                                        "nodeId": event.current_agent_name,
                                        "agent": {
                                            "id": event.current_agent_name.split("#")[2],
                                            "name": event.current_agent_name.split("#")[1],
                                            "type": event.current_agent_name.split("#")[0],
                                        }
                                    }
                                }
                                message_events_with_type.append((MessageEventType.AGENT_OUTPUT, _event["content"], _event["meta"]))
                                yield format_as_ndjson(_event)
                            elif isinstance(event, ToolCall) and not isinstance(event, ToolCallResult):
                                _modified_tool_agrs = event.tool_kwargs
                                if "to_agent" in _modified_tool_agrs:
                                    print(json.dumps(event.tool_kwargs))
                                    agent_parts = event.tool_kwargs["to_agent"].split("#")
                                    if len(agent_parts) == 3:
                                        _modified_tool_agrs["to_agent"] = {
                                            "nodeId": event.tool_kwargs["to_agent"],
                                            "agent": {
                                                "type": agent_parts[0],
                                                "name": agent_parts[1],
                                                "id": agent_parts[2]
                                            }
                                        }
                                    elif len(agent_parts) == 2:
                                        _modified_tool_agrs["to_agent"] = {
                                            "nodeId": event.tool_kwargs["to_agent"],
                                            "agent": {
                                                "type": None,
                                                "name": agent_parts[0],
                                                "id": agent_parts[1]
                                            }
                                        }
                                    else:
                                        _modified_tool_agrs["to_agent"] = {
                                            "nodeId": event.tool_kwargs["to_agent"],
                                            "agent": {
                                                "type": None,
                                                "name": event.tool_kwargs["to_agent"],
                                                "id": event.tool_kwargs["to_agent"]
                                            }
                                        }

                                _event = {
                                    "type": MessageEventType.AGENT_TOOL_CALL.value,
                                    "content": {
                                        "toolName": event.tool_name,
                                        "toolArgs": _modified_tool_agrs
                                    },
                                    "meta": {
                                        "toolCallId": event.tool_id,
                                    }
                                }
                                message_events_with_type.append((MessageEventType.AGENT_TOOL_CALL, _event["content"], _event["meta"]))
                                yield format_as_ndjson(_event)
                            elif isinstance(event, ToolCallResult):
                                _event = {
                                    "type": MessageEventType.AGENT_TOOL_CALL_RESULT.value,
                                    "content": {
                                        "toolName": event.tool_output.tool_name,
                                        "output": event.tool_output.content
                                    },
                                    "meta": {
                                        "toolCallId": event.tool_id,
                                    }
                                }
                                message_events_with_type.append((MessageEventType.AGENT_TOOL_CALL_RESULT, _event["content"], _event["meta"]))
                                yield format_as_ndjson(_event)
                    except GeneratorExit:
                        logging.log(logging.INFO, "Client disconnected while generating response stream.") 
                        return
                    except Exception as error:
                        logging.log(logging.ERROR, "Exception while generating response stream: %s", error)
                        error_details = f"Exception while generating response stream: {error}"
                        aggregated = error_details

                        _event = {
                            "type": MessageEventType.ERROR.value,
                            "content": error_details,
                            "meta": None
                        }
                        message_events_with_type.append((MessageEventType.ERROR, _event["content"], _event["meta"]))
                        yield json.dumps(_event) + "\n"
                        raise error
                    finally:
                        if aggregated is None or aggregated.strip() == "":
                            aggregated = "Oh no! Your LLM ran into an issue. Try catching one of the admins of this application to check the server logs for details."
                        yield from process_assistant_response(
                            conversation,
                            MessageRole.ASSISTANT,
                            aggregated, message_events_with_type)

                # noinspection PyCallingNonCallable
                return Response(response=event_stream(process), mimetype='text/event-stream', status=200)
            else:
                process = ChatProcess(conversation=conversation, user_message_parts=data['parts'], overrides=data.get('overrides', []))
                database.session.commit()

                chat_response: ChatResponse = process.execute()

                # noinspection PyCallingNonCallable
                return Response(
                    chain(
                        # 1. send back user message object
                        yield_message_object(process.get_user_message()),

                        # 2. yield context nodes used to answer the questions
                        yield_context_nodes(chat_response.get_source_nodes()),

                        # 3. stream assistant response including citations if any
                        yield_token_chunks(
                            chat_response.get_token_generator(),
                            lambda assistant_response: process_assistant_response(
                                conversation,
                                MessageRole.ASSISTANT,
                                assistant_response,
                                [(MessageEventType.CONTEXT_NODE, context_node_to_content_dict(source_node), None) for source_node in chat_response.get_source_nodes()]),
                            )),
                    mimetype='text/event-stream')
        except Exception as e:
            logging.log(logging.ERROR, e)
            database.session.rollback()
            ns.abort(500, e)
        finally:
            if database.session.is_active:
                try:
                    database.session.commit()
                except Exception as e2:
                    # Should not happen again but just in case, we are at least logging the error
                    # TODO FIXME: Check when re-implementing message events again.
                    logging.log(logging.ERROR, e2)

    @ns.doc(False)
    def options(self, conversation_id):
        # Handle preflight OPTIONS request
        return '', 200

    @staticmethod
    def __assistant_response_to_message_callback(conversation: ConversationModel, message_content):
        message = MessageModel(role=MessageRole.ASSISTANT, conversation=conversation)
        message.parts.append(MessagePartModel(type=MessagePartType.TEXT, content=message_content))
        database.session.add(message)
        database.session.commit()


@ns.route('/<conversation_id>/data-sources/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class DatasourceFetchEndpoint(Resource):
    @ns.doc("list_conversation_data_sources")
    @ns.response(200, 'Success', fields.Nested(data_source_model))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The conversation does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id: str):
        """Creates a new data source"""
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)

        if _conversation is None:
            ns.abort(404, f'An conversation with identifier "{conversation_id}" does not exist')

        conv_to_ds_relations = ConversationDataSourceRelationModel.query.filter(
            ConversationDataSourceRelationModel.conversation_id == conversation_id).all()
        ds_ids = [relation.data_source_id for relation in conv_to_ds_relations]
        data_sources = DataSourceModel.query.filter(DataSourceModel.id.in_(ds_ids)).all()

        return jsonify([data_source_to_dict(data_source) for data_source in data_sources])

    @ns.doc(False)
    def options(self, conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/data-source/', strict_slashes=False)
@ns.param('conversation_id', 'A valid UUID of an existing conversation.')
class DatasourceCreateEndpoint(Resource):
  
    @ns.doc(description="Create a new data source for this conversation with isolated knowledge.")
    @ns.expect(data_source_model)
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @propagate_principal()
    def post(self, conversation_id: str):
     
        """Creates a new data source"""
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)

        if _conversation is None:
            ns.abort(404, f'A conversation with identifier "{conversation_id}" does not exist')

        _data = request.get_json()

        _vector_store_id = _data.get('vectorStoreId')
        _embedding_model_id = _data.get('embeddingModelId')
        _file_storage_id = _data.get('fileStorageId')

        _name = _data['name'] if 'name' in _data else ((_conversation.name if _conversation.name else _conversation.id))
        _description = _data['description'] if 'description' in _data else (f"An automaticly generated data source (knowledge) for the context of the conversation named '{_conversation.name}'. It contains documents that have been ingested by the user to provide further context information to the ongoing conversation.")

        _data_source = DataSourceModel(name=_name, description=_description)

        if _embedding_model_id:
            _embedding_model = ModuleRegistry.get_module(_embedding_model_id)
            if _embedding_model is None or _embedding_model.get_spec().get_module_type() != ModuleType.EMBEDDING_MODEL:
                ns.abort(400, f"Embedding model with id {_embedding_model_id} does not exists or is of wrong type")
            else:
                _data_source.embedding_model_id = _embedding_model.get_id()
        if _vector_store_id:
            _vector_store = ModuleRegistry.get_module(_vector_store_id)
            if _vector_store is None or _vector_store.get_spec().get_module_type() != ModuleType.VECTOR_STORE:
                ns.abort(400, f"Embedding model with id {_vector_store_id} does not exists or is of wrong type")
            else:
                _data_source.vector_store_id = _vector_store.get_id()

        if _file_storage_id:
            _file_storage = ModuleRegistry.get_module(_file_storage_id)
            if _file_storage is None or _file_storage.get_spec().get_module_type() != ModuleType.FILE_STORAGE:
                ns.abort(400, f"File Storage with id {_file_storage} does not exists or is of wrong type")
            else:
                _data_source.file_storage_id = _file_storage.get_id()

        # check if given tags exists
        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _data_source.tag_relations.append(
                    DataSourceTagRelationModel(data_source_id=_data_source.id, tag_id=_shallow_tag['id']))

        # Add _conversation id as filter tag by default
        _data_source.filter_tag = _conversation.id
        database.session.add(_data_source)
        database.session.commit()

        # Create link between data source and assistant
        link = ConversationDataSourceRelationModel(conversation_id=_conversation.id, data_source_id=_data_source.id)
        database.session.add(link)
        database.session.commit()
      
        return jsonify(data_source_to_dict(_data_source))

    @ns.doc(False)
    def options(self, conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/attachments/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AttachmentsFetchEndpoint(Resource):
    @ns.doc("list_conversation_attachments")
    @ns.response(200, 'Success', fields.List(fields.Nested(attachment_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The conversation does not exist.')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id: str):

        _conversation = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        all_attachments = (database.session.query(AttachmentModel)
                           .join(ConversationAttachmentRelationModel, AttachmentModel.id == ConversationAttachmentRelationModel.attachment_id)
                           .filter(ConversationAttachmentRelationModel.conversation_id == _conversation.id)
                           .all())
        return jsonify([attachment.to_dict() for attachment in all_attachments])

    @ns.doc(False)
    def options(self, conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<conversation_id>/attachment', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AttachmentFactoryEndpoint(Resource):
    @ns.doc("create_conversation_attachment")
    @ns.expect(attachment_parser)
    @ns.response(200, 'Success', fields.List(fields.Nested(attachment_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The conversation does not exist.')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def post(self, conversation_id: str):
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        # Stream files
        _args = attachment_parser.parse_args()  # to get the file
        _file: FileStorage = _args['file']
        _file_storage_id = _args['fileStorageID'] if 'fileStorageID' in _args else None

        if _file is None:
            ns.abort(404, f"No file attached to request")
            return
        else:
            _file_length = _file.seek(0, os.SEEK_END)
            _file.seek(0, os.SEEK_SET) # reset stream

            _file_name = secure_filename(_file.filename)

            _file_content = b''
            while True:
                chunk = _file.stream.read(4096)
                if not chunk:
                    break
                _file_content += chunk

            _file_mime_type = _file.content_type

            _document_type: DocumentType = determine_document_type(_file)

            _file_storage = None
            _thumbnail = None
            _media_length = None
            if _file_storage_id:
                _file_storage = ModuleRegistry.get_module(_file_storage_id)
            else:
                # An assistant or agent_workflow is required to upload multimedia data!
                if not _conversation.assistant_id and not _conversation.agent_workflow_id:
                    ns.abort(404, f"The conversation is not bound to an assistant or agent workflow. Attachments can only be uploaded to attachment-aware conversations.'")
                _attachment_context_entity: Union[AssistantModel, AgentWorkflowModel] = _conversation.assistant if _conversation.assistant else _conversation.agent_workflow
                
                if _document_type == DocumentType.AUDIO:
                    _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment_context_entity.audio_attachment_storage_id))
                elif _document_type == DocumentType.VIDEO:
                    _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment_context_entity.video_attachment_storage_id))
                    _media_length = extract_video_length(file_bytes=_file_content)
                elif _document_type == DocumentType.IMAGE:
                    _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment_context_entity.image_attachment_storage_id))
                elif _document_type == DocumentType.TEXT:
                    _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment_context_entity.text_attachment_storage_id))
                else:
                    ns.abort(400, f"Unknown or unsupported mime type '{_file_mime_type}'")

            if _file_storage is None:
                ns.abort(400, f"Missing storage configuration for document type '{_document_type}' in '{_attachment_context_entity.name}'.")

            # TODO: Check for existing file already and append _<counter> to the filename
            file_storage_object: FileStorageObject = _file_storage.write("attachments" + os.path.sep + conversation_id + os.path.sep + _file_name, _file_content, media_length=_media_length)

            _thumbnail = create_thumbnail_for_media_file(document_type=_document_type, file_bytes=_file_content)

            attachment = AttachmentModel(object_reference=file_storage_object.reference_id, name=_file_name, type=_document_type, mime_type=_file_mime_type,
                                         size=_file_length, file_storage_id=_file_storage.get_id(),
                                         thumbnail=_thumbnail, length=_media_length, description=file_storage_object.details)

            database.session.add(attachment)
            database.session.commit() # Get the id

            conversation_attachment_relation = ConversationAttachmentRelationModel(
                attachment_id=attachment.id,
                conversation_id=_conversation.id,  # Assuming _conversation is your ConversationModel instance
            )
            _conversation.attachments.append(conversation_attachment_relation)

            database.session.commit()

            return jsonify(attachment.to_dict())

    @ns.doc(False)
    def options(self, conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/attachment/<attachment_id>', strict_slashes=False)
@ns.param('conversation_id', 'A valid UUID of an existing conversation.')
@ns.param('attachment_id', 'A valid UUID of an existing attachment.')
class AttachmentEndpoint(Resource):

    @ns.doc("get_conversation_attachment")
    @ns.response(200, 'Success', attachment_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The conversation does not exist.')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id: str, attachment_id: str):
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        _attachment = AttachmentModel.query.get(attachment_id)

        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")

        return jsonify(_attachment.to_dict())


    @ns.doc("delete_conversation_attachment")
    @ns.response(200, 'Success')
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist.')
    @requires_database_session
    @propagate_principal()
    def delete(self, conversation_id: str, attachment_id: str):
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        _attachment = AttachmentModel.query.get(attachment_id)

        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")
        _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment.file_storage_id))

        database.session.delete(_attachment)

        if _file_storage is None:
            ns.abort(400,
                     f"Corrupted data. File storage with identifier '{_attachment.file_storage_id}' not found.")
        try:
            # _file_storage.delete(_attachment.object_reference)
            logging.log(logging.WARNING, "# TODO # Deletion of original file in assigned blob storage for attachments.")
        except Exception as e:
            logging.log(logging.WARNING, f"Error occurred while deleting the attachment in the assigned file storage: {str(e)}")

        return jsonify(_attachment.to_dict())

    @ns.doc(False)
    def options(self, conversation_id: str, attachment_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<conversation_id>/attachment/<attachment_id>/content', strict_slashes=False)
@ns.param('conversation_id', 'A valid UUID of an existing conversation.')
@ns.param('attachment_id', 'A valid UUID of an existing attachment.')
class AttachmentContentEndpoint(Resource):
    @ns.doc("get_conversation_attachment_content")
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The conversation does not exist.')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id: str, attachment_id: str):
        _conversation: ConversationModel = ConversationModel.query.get(conversation_id)
        if _conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(_conversation):
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        _attachment: AttachmentModel = AttachmentModel.query.get(attachment_id)
        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")
        elif _attachment.id not in [ca.attachment_id for ca in _conversation.attachments]:
            ns.abort(403, f"Attachment with identifier '{attachment_id}' belongs to another conversation")

        _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment.file_storage_id))

        if _file_storage is None:
            ns.abort(400,
                     f"Corrupted data. File storage with identifier '{_attachment.file_storage_id}' not found.")

        try:
            _content = _file_storage.read(_attachment.object_reference)
            return send_file(
                BytesIO(_content) if isinstance(_content, bytes) else _content,
                as_attachment=True,
                download_name=_attachment.name,
                mimetype=_attachment.mime_type
            )
        except Exception as e:
            return f"Error occurred: {str(e)}", 500

    @ns.doc(False)
    def options(self, conversation_id: str, attachment_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<conversation_id>/shared-conversation/', strict_slashes=False, methods=['GET', 'OPTIONS'])
@ns.param('conversation_id', 'A valid UUID of an existing conversation.')
class SharedConversationInfoEndpoint(Resource):
    @ns.doc("get_shared_conversation_info")
    @ns.response(200, 'Success')
    @ns.response(403, 'The conversation belongs to another user')
    @ns.response(404, 'The conversation does not exist')
    @requires_database_session
    @propagate_principal()
    def get(self, conversation_id: str):
        """Returns the shared conversation ID if the conversation was shared previously"""
        conversation: ConversationModel = ConversationModel.query.get(conversation_id)

        if conversation is None:
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
        elif not is_access_granted(conversation):
            ns.abort(403, f"The conversation with identifier '{conversation_id}' is not accessible for the current user.")

        #Fetch the shared conversation for the conversation_id
        shared_conversation = (SharedConversationModel.query
                             .filter_by(conversation_id=conversation_id)
                             .first())

        return jsonify(shared_conversation.to_dict() if shared_conversation else None)

    @ns.doc(False)
    def options(self, conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200


if is_eqty_enabled():
    
    from maxgpt.services.database_model import ConversationGovernanceModel
    from maxgpt.services.eqty.util import generate_manifest_and_purge
    from maxgpt.services.eqty.lineage import build_chat_lineage, build_agentic_chat_lineage

    @ns.route('/<conversation_id>/lineage/exists', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AssistantLineageExistsEndpoint(Resource):
        @ns.doc(description="Retrieve whether lineage information exists for a conversation.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The conversation does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, conversation_id: str):
            
            def _is_valid_conversation() -> bool:
                _conversation: Optional[ConversationModel] = ConversationModel.query.get(conversation_id)

                if _conversation is None:
                    ns.abort(404, f"No conversation found for identifier '{conversation_id}'")
                elif not is_access_granted(_conversation):
                    ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")
                else:
                    return True
            
            return jsonify(_is_valid_conversation())
            
        @ns.doc(False)
        def options(self, conversation_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    @ns.route('/<conversation_id>/lineage/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class ConversationLineageEndpoint(Resource):
        @ns.doc(description="Retrieve lineage information for a conversation.")
        @ns.response(200, 'Success')
        @ns.response(400, 'Bad request')
        @ns.response(404, 'The conversation does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, conversation_id: str):
            _conversation: Optional[ConversationModel] = get_conversation(conversation_id)

            # single-threaded because the EQTY SDK isn't threadsafe
            with (get_named_lock("EQTY")):
                if _conversation.assistant_id:
                    _ = build_chat_lineage(_conversation)
                else:
                    _ = build_agentic_chat_lineage(_conversation)

                manifest = generate_manifest_and_purge()
                
            return jsonify(manifest)
        
        @ns.doc(False)
        def options(self, conversation_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    DEFAULT_GOVERNANCE_STATISTICS = {
        "thumb": None,
        "messages": {},
    }   
    
    @ns.route('/<conversation_id>/governance/stats', strict_slashes=False, methods=['GET', 'PUT', 'OPTIONS'])
    class ConversationGovernanceEndpoint(Resource):
        @ns.doc(description="Retrieve the governance stats for a conversation.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The conversation does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, conversation_id: str):
            _ = get_conversation(conversation_id)

            _governance = ConversationGovernanceModel.query.get(conversation_id)
            if _governance is None:
                _governance = ConversationGovernanceModel(
                        conversation_id = conversation_id,
                        statistics = json.dumps(DEFAULT_GOVERNANCE_STATISTICS),
                    )
                database.session.add(_governance)
                database.session.commit()

            return Response(_governance.statistics, mimetype='application/json')
            
            
        @ns.doc(description="Update the governance stats for a conversation.")    
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The conversation does not exist')
        @requires_database_session
        @propagate_principal()
        def put(self, conversation_id: str):
            _ = get_conversation(conversation_id)
            _data = request.get_json()
            _governance = ConversationGovernanceModel.query.get(conversation_id)
            if _governance is None:
                _governance = ConversationGovernanceModel(
                        conversation_id = conversation_id,
                        statistics = "{}",
                    )
                database.session.add(_governance)

            _governance.statistics = json.dumps({
                    **DEFAULT_GOVERNANCE_STATISTICS,
                    **json.loads(_governance.statistics),
                    **_data,
                })
            database.session.commit()
            return Response(_governance.statistics, mimetype='application/json')

        @ns.doc(False)
        def options(self, conversation_id: str):
            # Handle preflight OPTIONS request
            return '', 200
