import logging
from typing import List
from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import and_, delete, select
from datetime import datetime
from maxgpt.api.internal.utils import audited_model, tagged_model, with_favorite, get_user_access_for, \
    with_access_permission, fetch_with_permissions, favorible_model, with_entities
from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import DefaultApplicationAccessRole, database
from maxgpt.services.database_model import TagCategoryTagRelationModel, TagCategoryModel, TagModel, UserFavoriteModel, FavoriteSubject, PermissionType
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('Tag Category',
               description='Configure Tag Categories of a user.',
               path='/tag-category')

tag_category_model = ns.inherit('Tag_category', audited_model(ns), favorible_model(ns), {
    'id': fields.String(description="The identifier of the tag_category.", required=True, readonly=True),
    'name': fields.String(description="The name of the tag_category.", max_length=100, required=True),
    'description': fields.String(description="A detailed description of the tag_category.", required=False),
    'icon': fields.String(description="A base64 encoded image to show as icon for this tag_category.", required=False),
   
})
tag_category_linked_tag_ids = ns.model('List of tag IDs', {
    'tagIds': fields.List(fields.String,
                                description="A list of identifiers of tag bound to the tag_category.",
                                required=True),
})                               

@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class TagCategoryEndpoint(Resource):
    @ns.doc("list_tag_category")
    @ns.response(200, 'Success', fields.List(fields.Nested(tag_category_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available tag_category that are accessible for the current user."""
        tag_categories = TagCategoryModel.query.filter(TagCategoryModel.deleted_at.is_(None)).all()
        return jsonify([_tag_category.to_dict() for _tag_category in tag_categories])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
    
@ns.route('/<tag_category_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class TagCategoryFactoryEndpoint(Resource):
    @ns.doc(description="read_tag_category")
    @ns.response(200, 'Success', tag_category_model)
    @ns.response(404, 'tag_category not found')
    @requires_database_session
    @propagate_principal()
    def get(self, tag_category_id: str):
        """Returns the tag_category for the given id if existing and accessible for the current user."""
        _tag_category: TagCategoryModel = TagCategoryModel.query.filter(
            TagCategoryModel.id == tag_category_id,
            TagCategoryModel.deleted_at.is_(None)
        ).first()

        if _tag_category is None:
            ns.abort(404, f"A tag_category with identifier '{tag_category_id}' does not exist")
        return jsonify(_tag_category.to_dict())


    @ns.doc("update_tag_category")
    @ns.expect(tag_category_model)
    @ns.response(200, 'Success', tag_category_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The tag_category does not exist.')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def put(self, tag_category_id: str):
        """Updates an existing tag_category."""
        _data = request.get_json()
        _tag_category = TagCategoryModel.query.get(tag_category_id)

        if _tag_category is None:
            ns.abort(404, f'A tag_category with identifier "{tag_category_id}" does not exist')

        #Check if tag_category is already deleted
        if _tag_category.deleted_at is not None:
            ns.abort(404, f'The tag_category with identifier "{tag_category_id}" has already been deleted and cannot be modified')

        # Mandatory attributes
        _tag_category.name = _data['name'] if 'name' in _data else _tag_category.name
        _tag_category.description = _data['description'] if 'description' in _data else _tag_category.description

        _tag_category.icon = _data['icon'] if 'icon' in _data else _tag_category.icon
        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(_tag_category.to_dict())



    @ns.doc("delete_tag_category")
    @ns.param('hardDelete', 'Set to true to hard delete the tag_category', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', tag_category_model)
    @ns.response(404, 'The tag_category does not exist')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def delete(self, tag_category_id: str):
        """Delete the tag_category for the given identifier if existing and accessible for the current user."""
        _tag_category : TagCategoryModel = TagCategoryModel.query.get(tag_category_id)

        if _tag_category is None:
            ns.abort(404, f'A tag_category with identifier "{tag_category_id}" does not exist')

        #Check if tag_category is already deleted
        if _tag_category.deleted_at is not None:
            ns.abort(404, f'The tag_category with identifier "{tag_category_id}" has already been deleted')
        tag_category_dict = _tag_category.to_dict()

        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == "true":
            logging.log(logging.INFO, f"Hard delete the tag_category:{tag_category_id}")
            database.session.delete(_tag_category)
        else:
            stmt = delete(TagCategoryTagRelationModel).where(
                TagCategoryTagRelationModel.tag_category_id == tag_category_id
            )
            database.session.execute(stmt)

            logging.log(logging.INFO, f"Soft delete the tag_category:{tag_category_id}")
            _tag_category.deleted_at = datetime.now()
            _tag_category.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()
        return jsonify(tag_category_dict)
    @ns.doc(False)
    def options(self, tag_category_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class TagCategoriesFactoryEndpoint(Resource):
    @ns.expect(tag_category_model)
    @ns.doc("create_tag_category")
    @ns.response(200, 'Success', tag_category_model)
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def post(self):
        """Creates a new tag_category."""
        _data = request.get_json()

        _tag_category = TagCategoryModel(name=_data['name'], description=_data.get('description'))
        database.session.add(_tag_category)

        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(_tag_category.to_dict())

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
    