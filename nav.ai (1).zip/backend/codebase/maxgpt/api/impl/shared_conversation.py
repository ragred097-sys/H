import logging
from datetime import datetime 

from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import desc

from maxgpt.api.internal.utils import propagate_principal, requires_database_session, audited_model, with_conversation_details
from maxgpt.services.database_model import SharedConversationModel, ConversationModel, database, MessageModel
from maxgpt.services.internal.session_context import SessionContext

logger = logging.getLogger(__name__)

ns = Namespace('SharedConversation', description='Operations related to shared conversations.', path="/shared-conversation")

shared_conversation_model = ns.inherit('SharedConversation', audited_model(ns), {
    'id': fields.String(description="The UUID of the shared conversation.", required=True, readonly=True),
    'conversationId': fields.String(description="The UUID of the original conversation.", required=True),
})

message_part_model = ns.model('MessagePart', {
    'type': fields.String(description="The type of the message part", required=True),
    'content': fields.String(description="The content of the message part", required=True),
    'sequence': fields.Integer(description="The sequence number of the message part", required=True),
})

message_model = ns.model('Message', {
    'id': fields.String(description="The UUID of the message", required=True),
    'role': fields.String(description="The role of the message sender", required=True),
    'conversationId': fields.String(description="The UUID of the conversation", required=True),
    'timestamp': fields.DateTime(description="The timestamp when the message was created", required=True),
    'parts': fields.List(fields.Nested(message_part_model), description="The parts of the message", required=True),
})

@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class SharedConversationsEndpoint(Resource):
    @ns.doc("list_shared_conversations")
    @ns.response(200, 'Success', fields.List(fields.Nested(shared_conversation_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all shared conversations created by the current user."""
        current_user_id = SessionContext.get_current_user().get_id() 
        
        shared_conversations = SharedConversationModel.query.filter(SharedConversationModel.creator_id == SessionContext.get_current_user().get_id()).order_by(desc(SharedConversationModel.created_at)).all()
        return jsonify([with_conversation_details(shared_conversation.to_dict()) for shared_conversation in shared_conversations])

    @ns.doc(False)
    def options(self):
        return '', 200

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class SharedConversationFactoryEndpoint(Resource):
    @ns.expect(shared_conversation_model)
    @ns.doc("create_shared_conversation")
    @ns.response(200, 'Success', shared_conversation_model)
    @ns.response(404, 'Conversation not found')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new shared conversation entry"""
        data = request.get_json()
        conversation_id = data.get('conversationId')
        current_user_id = SessionContext.get_current_user().get_id()
           
        # Check if conversation exists
        conversation = ConversationModel.query.get(conversation_id)
        if not conversation: 
            ns.abort(404, f"No conversation found for identifier '{conversation_id}'")

        # Check if user has access to the conversation
        if conversation.creator_id != current_user_id: 
            ns.abort(403, f"Conversation with identifier '{conversation_id}' belongs to another user")

        # Create new shared conversation
        shared_conversation = SharedConversationModel(
            conversation_id=conversation_id
        )
        
        try:
            # Add to database session and commit
            database.session.add(shared_conversation)
            database.session.commit() 
        except Exception as e:
            logger.error(f"Error creating shared conversation: {str(e)}")
            database.session.rollback()
            raise

        return jsonify(shared_conversation.to_dict())

    @ns.doc(False)
    def options(self):
        return '', 200

@ns.route('/<shared_conversation_id>/', strict_slashes=False,methods=['GET','PUT','DELETE','OPTIONS'])
@ns.param('shared_conversation_id', 'A valid UUID of an existing shared conversation.')
class SharedConversationEndpoint(Resource):
    @ns.doc("get_shared_conversation")
    @ns.response(200, 'Success', shared_conversation_model)
    @ns.response(404, 'Shared conversation not found')
    @requires_database_session
    @propagate_principal()
    def get(self, shared_conversation_id: str):
        """Returns the shared conversation matching the given identifier""" 
        
        shared_conversation = SharedConversationModel.query.get(shared_conversation_id)
        
        if not shared_conversation: 
            ns.abort(404, f"The referenced conversation does not exist or has been deleted '{shared_conversation_id}'")
         
        return jsonify(shared_conversation.to_dict())

    @ns.doc("update_shared_conversation")
    @ns.response(200, 'Success', shared_conversation_model)
    @ns.response(403, 'The shared conversation belongs to another user')
    @ns.response(404, 'Shared conversation not found')
    @requires_database_session
    @propagate_principal()
    def put(self, shared_conversation_id: str):
        """Updates the shared conversation timestamp when resharing"""
        current_user_id = SessionContext.get_current_user().get_id() 
        
        shared_conversation = SharedConversationModel.query.get(shared_conversation_id)
        
        if not shared_conversation: 
            ns.abort(404, f"No shared conversation found for identifier '{shared_conversation_id}'")
        
        # Check ownership
        if shared_conversation.creator_id != current_user_id: 
            ns.abort(403, f"Shared conversation with identifier '{shared_conversation_id}' belongs to another user")
        
        try:
            # Update timestamp
            shared_conversation.created_at = datetime.now()
            database.session.commit() 
        except Exception as e: 
            database.session.rollback()
            raise
        
        return jsonify(shared_conversation.to_dict())

    @ns.doc("delete_shared_conversation")
    @ns.response(200, 'Success')
    @ns.response(403, 'The shared conversation belongs to another user')
    @ns.response(404, 'Shared conversation not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, shared_conversation_id: str):
        """Deletes the shared conversation"""
        current_user_id = SessionContext.get_current_user().get_id() 
        shared_conversation = SharedConversationModel.query.get(shared_conversation_id)
        
        if not shared_conversation: 
            ns.abort(404, f"No shared conversation found for identifier '{shared_conversation_id}'")
        
        # Check ownership
        if shared_conversation.creator_id != current_user_id: 
            ns.abort(403, f"Shared conversation with identifier '{shared_conversation_id}' belongs to another user")
        
        try:
            # Store the data before deletion
            deleted_data = shared_conversation.to_dict()
            
            # Delete the shared conversation
            SharedConversationModel.query.filter_by(id=shared_conversation_id).delete()
            database.session.commit() 
            
            return jsonify(deleted_data)
        except Exception as e: 
            database.session.rollback()
            raise
        
        return '', 200

    @ns.doc(False)
    def options(self, shared_conversation_id: str):
        return '', 200

@ns.route('/<shared_conversation_id>/messages/', strict_slashes=False, methods=['GET', 'OPTIONS'])
@ns.param('shared_conversation_id', 'A valid UUID of an existing shared conversation')
class SharedConversationMessagesEndpoint(Resource):
    @ns.doc("get_shared_conversation_messages")
    @ns.response(200, 'Success', fields.List(fields.Nested(message_model)))
    @ns.response(404, 'Shared conversation not found')
    @requires_database_session
    def get(self, shared_conversation_id: str):
        """Returns all messages belonging to the conversation until the shared conversation's creation time"""
        shared_conversation = SharedConversationModel.query.get(shared_conversation_id)
        if not shared_conversation:
            ns.abort(404, f"The referenced conversation '{shared_conversation_id}' does not exist or has been deleted")
        
        #Fetch the conversation
        conversation = ConversationModel.query.get(shared_conversation.conversation_id)
        if not conversation:
            ns.abort(404, f"No conversation found for identifier '{shared_conversation.conversation_id}'")
        
        #Fetch messages up to the shared conversation's created_at timestamp
        messages = (MessageModel.query
                   .filter(MessageModel.conversation_id == conversation.id)
                   .filter(MessageModel.timestamp <= shared_conversation.created_at)
                   .order_by(MessageModel.timestamp)
                   .all())
        
        return jsonify([message.to_dict() for message in messages])

    @ns.doc(False)
    def options(self, shared_conversation_id: str):
        # Handle preflight OPTIONS request
        return '', 200

 