import os
from io import BytesIO
from typing import cast
import logging

from flask import request, jsonify, send_file
from flask_restx import Namespace, Resource, fields, reqparse
from flask_sqlalchemy.session import Session
from sqlalchemy import select, and_
# from sqlalchemy.testing.plugin.plugin_base import logging
from werkzeug.datastructures import FileStorage
from werkzeug.exceptions import SecurityError
from werkzeug.utils import secure_filename
from datetime import datetime

from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, tagged_model, \
    with_favorite, with_access_permission, fetch_with_permissions, get_user_access_for, attachment_api_structure, \
    determine_document_type, create_thumbnail_for_media_file, extract_video_length, with_hidden
from maxgpt.modules import ModuleRegistry
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.services import database
from maxgpt.services.database_model import HiddenEntitySubject, SystemInstructionModel, SystemInstructionTagRelationModel, \
    UserFavoriteModel, FavoriteSubject, PermissionType, AccessPermissionModel, AccessPermissionSubject, \
    AccessPermissionAssigneeType, AttachmentModel, SystemInstructionAttachmentRelationModel, DocumentType, UserHiddenEntityModel
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('System Instructions',
               description='Configure system instructions used by assistants or default conversations as leading system message to the llm.',
               path='/system-instruction')

system_instruction_model = ns.inherit('System Instruction', audited_model(ns), tagged_model(ns), {
    'id': fields.String(description="The UUID of the system prompt.", required=True, readonly=True),
    'name': fields.String(description="The name of the system prompt.", max_length=100, required=False),
    'description': fields.String(description="A short summary of the data source.", max_length=500, required=False),
    'message': fields.String(description="The actual prompt text.", required=True),
    'hidden': fields.Boolean(description="Whether the system instruction is hidden.", required=False, default=False),
})

attachment_model = ns.inherit('Attachment', audited_model(ns), attachment_api_structure)

attachment_parser = reqparse.RequestParser()
attachment_parser.add_argument('file', type=FileStorage, location='files', required=True, help='A set of multi media files.')
attachment_parser.add_argument('fileStorageId', type=str, location='form', required=True, help='The ID of an existing file storage module.')


@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class SystemInstructionsEndpoint(Resource):
    @ns.doc(description="list_system_instructions")
    @ns.param('isDeleted', 'Set to true to get soft-deleted system-instructions', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden system-instructions, false for only unhidden', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(system_instruction_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == 'true':
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_system_instructions = SystemInstructionModel.query.filter(
                SystemInstructionModel.deleted_at.isnot(None),
                SystemInstructionModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([system_instruction.to_dict() for system_instruction in soft_deleted_system_instructions])
        
        
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
         # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            _enhanced_system_instructions: list[SystemInstructionModel] = fetch_with_permissions(SystemInstructionModel,hidden_ids)
        elif hidden_param == 'false':
            _enhanced_system_instructions: list[SystemInstructionModel] = fetch_with_permissions(
                SystemInstructionModel,
                ids=hidden_ids,
                exclude=True 
            )
        else:
            _enhanced_system_instructions: list[SystemInstructionModel] = fetch_with_permissions(SystemInstructionModel)
        
        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )

        subject_ids = set(database.session.scalars(stmt))
       
        return jsonify([with_hidden(with_favorite(with_access_permission(_system_instruction.to_dict(), _system_instruction.permission), subject_ids),hidden_ids)
                        for _system_instruction  in  _enhanced_system_instructions])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class SystemInstructionFactoryEndpoint(Resource):
    @ns.expect(system_instruction_model)
    @ns.doc("create_system_instruction")
    @ns.response(200, 'Success', system_instruction_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        _data = request.get_json()

        _system_instruction = SystemInstructionModel(name=_data['name'],
                                                     description=_data['description'],
                                                     message=_data['message'])
        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _system_instruction.tag_relations.append(
                    SystemInstructionTagRelationModel(system_instruction_id=_system_instruction.id, tag_id=_shallow_tag['id']))

        database.session.add(_system_instruction)
        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_system_instruction.to_dict(), set([])),set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<system_instruction_id>/', strict_slashes=False,  methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class SystemInstructionEndpoint(Resource):
    @ns.doc(description="read_system_instruction")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted system instructions', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', system_instruction_model)
    @ns.response(404, 'System Instruction not found')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str):
        # Base query without deleted filter
        query = SystemInstructionModel.query.filter(SystemInstructionModel.id == system_instruction_id)
        
        # Only apply deleted filter if includeDeleted is not true
        if 'includeDeleted' not in request.args or request.args.get('includeDeleted').lower() != 'true':
            query = query.filter(SystemInstructionModel.deleted_at.is_(None))
            
        _system_instruction = query.first()

        if _system_instruction is None:
            ns.abort(404, 'A system instruction with identifier "{}" does not exist'.format(system_instruction_id))

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read the system instruction with identifier '{system_instruction_id}'")

        current_user = SessionContext.get_current_user()
        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )

        subject_ids = set(database.session.scalars(stmt))

        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify(with_access_permission(with_hidden(with_favorite(_system_instruction.to_dict(), subject_ids),hidden_ids), grant))


    @ns.doc(description="update_system_instruction")
    @ns.expect(system_instruction_model)
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The system instruction does not exist.')
    @propagate_principal()
    @requires_database_session
    def put(self, system_instruction_id: str):
        _data = request.get_json()
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.get(system_instruction_id)

        if _system_instruction is None:
            ns.abort(404, 'A system instruction with identifier "{}" does not exist'.format(system_instruction_id))

        #Check if system_instruction is already deleted
        if _system_instruction.deleted_at is not None:
            ns.abort(404, f"The system_instruction with identifier {system_instruction_id} has already been deleted and cannot be modified")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read the system instruction with identifier '{system_instruction_id}'")

        # Mandatory attributes
        if 'message' not in _data:
            ns.abort(400, 'You must provide the message of the system instruction when updating a record.')
        _system_instruction.message = _data['message']

        # Optional update attributes
        _system_instruction.name = _data['name'] if 'name' in _data else _system_instruction.name
        _system_instruction.description = _data['description'] if 'description' in _data else _system_instruction.description

        session = Session.object_session(_system_instruction)

        if _data.get('tags') is not None:
            for _tag_relation in _system_instruction.tag_relations:
                session.delete(_tag_relation)
            _system_instruction.tag_relations = []
            for _shallow_tag in _data['tags']:
                _system_instruction.tag_relations.append(
                    SystemInstructionTagRelationModel(system_instruction_id=_system_instruction.id, tag_id=_shallow_tag['id']))

        database.session.commit()

        current_user = SessionContext.get_current_user()

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION)
        )

        subject_ids = set(database.session.scalars(stmt))

        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify(with_access_permission(with_hidden(with_favorite(_system_instruction.to_dict(), subject_ids),hidden_ids), grant))


    @ns.doc(description="delete_system_instruction")
    @ns.param('hardDelete', 'Set to true to hard delete the system-instruction', type=bool, required=False, _in="query")
    @ns.response(404, 'The system instruction does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, system_instruction_id: str):
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.get(system_instruction_id)
        current_user = SessionContext.get_current_user()
        if _system_instruction is None:
            ns.abort(404, 'A system instruction with identifier "{}" does not exist'.format(system_instruction_id))

        #Check if system_instruction is already soft deleted
        if _system_instruction.deleted_at is not None:
            ns.abort(404, f"The system_instruction with identifier {system_instruction_id} has already been deleted")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to delete the system instruction with identifier '{system_instruction_id}'")

        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.SYSTEM_INSTRUCTION,
                UserFavoriteModel.subject_id == _system_instruction.id
            )
        ).delete()
         # delete hidden information
        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION,
                UserHiddenEntityModel.subject_id == _system_instruction.id
            )
        ).delete()

        #This check will preserve the original functionality of DELETE API and can be used from swagger using query parameter
        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == 'true':
            logging.log(logging.INFO, f"Hard delete the system-instruction:{system_instruction_id}")
            database.session.delete(_system_instruction)    
        else:
            logging.log(logging.INFO, f"Soft delete the system-instruction:{system_instruction_id}")
            _system_instruction.deleted_at = datetime.now()
            _system_instruction.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_system_instruction.to_dict(), set([])),set([])), grant))


    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<system_instruction_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class SystemInstructionGrantsEndpoint(Resource):
    @ns.doc(description="read_system_instruction_grants")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'SystemInstruction not found')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str):
        #Added filter to honor SOFT delete
        _system_instruction = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()

        if _system_instruction is None:
            ns.abort(404, f"A system_instruction with identifier '{system_instruction_id}' does not exist")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update system instruction with identifier '{system_instruction_id}'")

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _system_instruction.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.SYSTEM_INSTRUCTION)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<system_instruction_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class SystemInstructionGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_system_instruction_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'SystemInstruction not found')
    @requires_database_session
    @propagate_principal()
    def post(self, system_instruction_id: str):
        _data = request.get_json()
        #Added filter to honor SOFT delete
        _system_instruction = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()

        if _system_instruction is None:
            ns.abort(404, f"A system instruction with identifier '{system_instruction_id}' does not exist")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update system_instruction with identifier '{system_instruction_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.SYSTEM_INSTRUCTION, subject_id=system_instruction_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<system_instruction_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'])
class SystemInstructionGrantEndpoint(Resource):
    @ns.doc(description="read_system_instruction_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'SystemInstruction_id not found')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str, assignee_type: str, assignee_id: str):
        #Added filter to honor SOFT delete
        _system_instruction = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        

        if _system_instruction is None:
            ns.abort(404, f"A system instruction_id with identifier '{system_instruction_id}' does not exist")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update system instruction with identifier '{system_instruction_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _system_instruction.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.SYSTEM_INSTRUCTION) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for system instruction '{_system_instruction.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for system instruction {system_instruction_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]

        return jsonify(permission.to_dict())

    @ns.doc(description="update_system_instruction_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'SystemInstruction not found')
    @requires_database_session
    @propagate_principal()
    def put(self, system_instruction_id: str, assignee_type: str, assignee_id: str):
        _data = request.get_json()
        #Added filter to honor SOFT delete
        _system_instruction = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()

        if _system_instruction is None:
            ns.abort(404, f"A system instruction with identifier '{system_instruction_id}' does not exist")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update system instruction with identifier '{system_instruction_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _system_instruction.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.SYSTEM_INSTRUCTION) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for system instruction '{_system_instruction.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for system instruction {system_instruction_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_system_instruction_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'SystemInstruction not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, system_instruction_id: str, assignee_type: str, assignee_id: str):
        #Added filter to honor SOFT delete
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()

        if _system_instruction is None:
            ns.abort(404, f"A system instruction with identifier '{system_instruction_id}' does not exist")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update system instruction with identifier '{system_instruction_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _system_instruction.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.SYSTEM_INSTRUCTION) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for system instruction '{_system_instruction.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for system instruction {system_instruction_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, system_instruction_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200




@ns.route('/<system_instruction_id>/attachments/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class SystemInstructionAttachmentsFetchEndpoint(Resource):
    @ns.doc("list_system_instruction_attachments")
    @ns.response(200, 'Success', fields.List(fields.Nested(attachment_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The system instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str):

        #Added filter to honor SOFT delete
        _system_instruction = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        if _system_instruction is None:
            ns.abort(404, f"No system_instruction found for identifier '{system_instruction_id}'")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read the system instruction with identifier '{system_instruction_id}'")

        all_attachments = (database.session.query(AttachmentModel)
                           .join(SystemInstructionAttachmentRelationModel, AttachmentModel.id == SystemInstructionAttachmentRelationModel.attachment_id)
                           .filter(SystemInstructionAttachmentRelationModel.system_instruction_id == system_instruction_id)
                           .all())
        return jsonify([attachment.to_dict() for attachment in all_attachments])

    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<system_instruction_id>/attachment', strict_slashes=False, methods=['POST', 'OPTIONS'])
class SystemInstructionAttachmentFactoryEndpoint(Resource):
    @ns.doc("create_system_instruction_attachment")
    @ns.expect(attachment_parser)
    @ns.response(200, 'Success', fields.List(fields.Nested(attachment_model)))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The system_instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def post(self, system_instruction_id: str):
        #Added filter to honor SOFT delete
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        if _system_instruction is None:
            ns.abort(404, f"No system_instruction found for identifier '{system_instruction_id}'")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to write the system instruction with identifier '{system_instruction_id}'")

        # Stream files
        _args = attachment_parser.parse_args()
        _file: FileStorage = _args['file']

        if _file is None:
            ns.abort(404, f"No file attached to request")
            return
        else:
            _file_length = _file.seek(0, os.SEEK_END)
            _file.seek(0, os.SEEK_SET) # reset stream

            _file_name = secure_filename(_file.filename)

            _file_content = b''
            while True:
                chunk = _file.stream.read(4096)
                if not chunk:
                    break
                _file_content += chunk

            _file_mime_type = _file.content_type
            _document_type: DocumentType = determine_document_type(_file)

            _media_length = None
            if _document_type == DocumentType.VIDEO:
                _media_length = extract_video_length(file_bytes=_file_content)

            _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_args['fileStorageId']))
            file_storage_object: FileStorageObject = _file_storage.write("attachments" + os.path.sep + "system_instruction" + os.path.sep + system_instruction_id + os.path.sep + _file_name, _file_content, media_length=_media_length)

            _thumbnail = create_thumbnail_for_media_file(document_type=_document_type, file_bytes=_file_content)

            attachment = AttachmentModel(object_reference=file_storage_object.reference_id, name=_file_name, type=_document_type, mime_type=_file_mime_type,
                                         size=_file_length, file_storage_id=_file_storage.get_id(),
                                         thumbnail=_thumbnail, length=_media_length, description=file_storage_object.details)
            database.session.add(attachment)
            database.session.commit() # Get the id

            system_instruction_attachment_relation = SystemInstructionAttachmentRelationModel(
                attachment_id=attachment.id,
                system_instruction_id=_system_instruction.id,
            )
            _system_instruction.attachments.append(system_instruction_attachment_relation)

            database.session.commit()

            return jsonify(attachment.to_dict())

    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<system_instruction_id>/attachment/<attachment_id>', strict_slashes=False)
@ns.param('system_instruction_id', 'A valid UUID of an existing system instruction.')
@ns.param('attachment_id', 'A valid UUID of an existing attachment.')
class SystemInstructionAttachmentEndpoint(Resource):

    @ns.doc("get_system_instruction_attachment")
    @ns.response(200, 'Success', attachment_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The system_instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str, attachment_id: str):
        #Added filter to honor SOFT delete
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        if _system_instruction is None:
            ns.abort(404, f"No system_instruction found for identifier '{system_instruction_id}'")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to write the system instruction with identifier '{system_instruction_id}'")

        _attachment = AttachmentModel.query.get(attachment_id)

        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")

        return jsonify(_attachment.to_dict())


    @ns.doc("delete_system_instruction_attachment")
    @ns.response(200, 'Success')
    @ns.response(404, 'The system_instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def delete(self, system_instruction_id: str, attachment_id: str):
        #Added filter to honor SOFT delete
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        if _system_instruction is None:
            ns.abort(404, f"No system_instruction found for identifier '{system_instruction_id}'")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to write the system instruction with identifier '{system_instruction_id}'")

        _attachment = AttachmentModel.query.get(attachment_id)

        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")
        _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment.file_storage_id))

        database.session.delete(_attachment)

        if _file_storage is None:
            ns.abort(400,
                     f"Corrupted data. File storage with identifier '{_attachment.file_storage_id}' not found.")
        try:
            # _file_storage.delete(_attachment.object_reference)
            logging.log(logging.WARNING, "# TODO # Deletion of original file in assigned blob storage for attachments.")
        except Exception as e:
            logging.log(logging.WARNING, f"Error occurred while deleting the attachment in the assigned file storage: {str(e)}")

        return jsonify(_attachment.to_dict())

    @ns.doc(False)
    def options(self, system_instruction_id: str, attachment_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<system_instruction_id>/attachment/<attachment_id>/content', strict_slashes=False)
@ns.param('system_instruction_id', 'A valid UUID of an existing system_instruction.')
@ns.param('attachment_id', 'A valid UUID of an existing attachment.')
class SystemInstructionAttachmentContentEndpoint(Resource):
    @ns.doc("get_system_instruction_attachment_content")
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The system_instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, system_instruction_id: str, attachment_id: str):
        #Added filter to honor SOFT delete
        _system_instruction: SystemInstructionModel = SystemInstructionModel.query.filter(
            SystemInstructionModel.id == system_instruction_id,
            SystemInstructionModel.deleted_at.is_(None)
        ).first()
        if _system_instruction is None:
            ns.abort(404, f"No system_instruction found for identifier '{system_instruction_id}'")

        grant = get_user_access_for(_system_instruction)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read the system instruction with identifier '{system_instruction_id}'")

        _attachment: AttachmentModel = AttachmentModel.query.get(attachment_id)
        if _attachment is None:
            ns.abort(404, f"No attachment found for identifier '{attachment_id}'")
        elif _attachment.id not in [ca.attachment_id for ca in _system_instruction.attachments]:
            ns.abort(403, f"Attachment with identifier '{attachment_id}' belongs to another system_instruction")

        _file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_attachment.file_storage_id))

        if _file_storage is None:
            ns.abort(400,
                     f"Corrupted data. File storage with identifier '{_attachment.file_storage_id}' not found.")

        try:
            _content = _file_storage.read(_attachment.object_reference)
            return send_file(
                BytesIO(_content) if isinstance(_content, bytes) else _content,
                as_attachment=True,
                download_name=_attachment.name,
                mimetype=_attachment.mime_type
            )
        except Exception as e:
            return f"Error occurred: {str(e)}", 500

    @ns.doc(False)
    def options(self, system_instruction_id: str, attachment_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<system_instruction_id>/restore/', strict_slashes=False, methods=['PATCH', 'OPTIONS'])
class SystemInstructionRestoreEndpoint(Resource):
    @ns.doc("restore_system_instruction")
    @ns.response(200, 'Success', system_instruction_model)
    @ns.response(404, 'The system instruction does not exist.')
    @requires_database_session
    @propagate_principal()
    def patch(self, system_instruction_id: str):
        """Restore a soft-deleted system instruction."""
        current_user = SessionContext.get_current_user()
        _system_instruction = SystemInstructionModel.query.get(system_instruction_id)
        if not _system_instruction:
            ns.abort(404, f"System instruction with id {system_instruction_id} does not exist.")

        if not _system_instruction.deleted_at:
            ns.abort(400, f"System instruction with id {system_instruction_id} is not deleted.")
        
        # Check if the current user is the creator of the System instrcution
        if _system_instruction.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this System instrcution")

        _system_instruction.deleted_at = None
        _system_instruction.deleted_by = None
        database.session.commit()

       
        return jsonify(_system_instruction.to_dict())

    @ns.doc(False)
    def options(self, system_instruction_id: str):
        # Handle preflight OPTIONS request
        return '', 200