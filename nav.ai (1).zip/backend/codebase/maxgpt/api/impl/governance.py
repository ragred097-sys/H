from flask import jsonify
from flask_restx import Namespace, Resource, reqparse
import datetime
import json
import logging
from dataclasses import dataclass
from typing import Iterable, Optional, Tuple
from functools import reduce
from sqlalchemy import and_
from maxgpt.services.database_model import ConversationModel, ConversationGovernanceModel, AssistantGovernanceModel, \
    MessageModel, MessageEventType, MessageEventModel
from maxgpt.services import database
from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services.eqty.indicator import evaluate_indicator

DEFAULT_GOVERNANCE_CONFIGURATION = {
    'thumbs_indicator_uuid': None
}
DEFAULT_GOVERNANCE_STATUS = {
    'thumbs_indicator': { 'pass': None }
}

DEFAULT_THUMBS_WINDOW = 30
DEFAULT_MINIMUM_THUMBS = 10
CONVERSATION_THUMB_WEIGHT = 3

class ConversationStats:
    def __init__(self, score=0, thumbs=0):
        self.score = score
        self.thumbs = thumbs
    
    def update(self, thumb, weight=1):
        if thumb is not None:
            self.thumbs += weight
            self.score += thumb * weight
    
    def evaluate(self, minimum_thumbs) -> Optional[int]:
        if self.thumbs < minimum_thumbs:
            return None
        return int(100 * self.score / self.thumbs)
    
    def __str__(self):
        return f"ConversationStats(score={self.score}, thumbs={self.thumbs})"
    
    def __repr__(self):
        return self.__str__()


ns = Namespace('Governance',
               description='Governance information and batch operations.',
               path='/governance')

conversation_governance_arguments = reqparse.RequestParser()
conversation_governance_arguments.add_argument(
    'thumbsWindow', type=int, required=False, default=DEFAULT_THUMBS_WINDOW, 
    help='The number of days to consider for thumbs.')
conversation_governance_arguments.add_argument(
    'minimumThumbs', type=int, required=False, default=DEFAULT_MINIMUM_THUMBS, 
    help='Minimum number of thumbs needed to calculate the governance status.')

def _aggregate_conversation_stats(
        governance_conversation_iterator: Iterable[tuple[ConversationGovernanceModel, ConversationModel]]
    ) -> dict[tuple[str, str], ConversationStats]:
    """
    Aggregate conversation statistics.

    When the user is interacting directly with an assistant, all stats is aggregated to the assistant.
    The conversation-level thumb is weighted more heavily by `CONVERSATION_THUMB_WEIGHT`.
    
    A workflow is more complex. As the quality overall conversation in a workflow is a combination of the
    performance of the individual agents, the orchestrator and the workflow connections made between them,
    the conversation stats are assigned to the top level workflow without attempting to attribute the
    thumb evaluation to any specific agent.

    The message level thumbs in a workflow are more useful for evaluating the performance of the individual
    agents. The stats are aggregated to both the workflow, the orchestrator and to each agent involved in
    the specific interaction.
    
    Args:
        governance_conversation_iterator: iterates through (governance, conversation) tuples to process
    """
    def build_agent_set(agent_ids: set[str], event: MessageEventModel) -> set[str]:
        id: str = json.loads(event.meta).get("agent", {}).get("id")
        if id:
            return agent_ids | {id}
        else:
            logging.error(f"Message event {event.id} has no agent id")
            return agent_ids

    def aggregate_stats(
            aggregated_stats: dict[tuple[str, str], ConversationStats],
            governance_conversation: tuple[ConversationGovernanceModel, ConversationModel]
        ) -> dict[tuple[str, str], ConversationStats]:
        governance, conversation = governance_conversation
        
        def aggregate_stat(id: str, thumb: Optional[int]) -> None:
            if thumb is not None:
                if id not in aggregated_stats:
                    aggregated_stats[id] = ConversationStats()
                aggregated_stats[id].update(thumb)

        def get_message_thumb(message_id_stat: tuple[str, dict]) -> Tuple[MessageModel, int]:
            message_id, stats = message_id_stat
            message = next(filter(lambda m: m.id == message_id, conversation.messages), None)
            thumb = 0 if stats.get('thumb') is None else 1 if stats['thumb'] else -1
            return message, thumb
        
        # Conversation level thumbs up/down processing
        stats = json.loads(governance.statistics)
        top_id = (conversation.assistant_id, conversation.agent_workflow_id)
        logging.debug(f"Aggregating stats for {top_id} ({len(conversation.messages)} messages) with {stats}")
        aggregate_stat(top_id, stats.get('thumb'))

        # Message level thumbs up/down processing
        for message, thumb in map(get_message_thumb, stats.get('messages', {}).items()):
            aggregate_stat(top_id, thumb)
            if conversation.agent_workflow_id is None:
                continue

            agents_involved = reduce(
                build_agent_set, 
                MessageEventModel.query.filter(
                    and_(
                        MessageEventModel.message_id == message.id,
                        MessageEventModel.type == MessageEventType.AGENT_OUTPUT,
                        MessageEventModel.meta.isnot(None)
                    )
                ).all(),
                set())
            
            logging.debug(f"Workflow agents involved: {agents_involved}")
            for agent_id in agents_involved:
                aggregate_stat((agent_id, None), thumb)

        return aggregated_stats

    return reduce(aggregate_stats, governance_conversation_iterator, {})
    

@dataclass
class ThumbsObservation:
    governance: AssistantGovernanceModel
    percent: int

    @property
    def is_sufficient(self) -> bool:
        return self.percent is not None

    def export(self) -> dict:
        return {
            "assistant_id": self.governance.assistant_id,
            "workflow_id": self.governance.workflow_id,
            "percent": self.percent if self.is_sufficient else 100 # an insufficient observation should be a GC pass
        }


def _gather_governance_indicators(aggregated_stats: dict[tuple[str, str], ConversationStats], minimum_thumbs: int) -> dict[str, list[ThumbsObservation]]:
    """
    Gather the governance controls for all assistants and workflows.

    Args:
        aggregated_stats: A dictionary of aggregated stats for all assistants and workflows.
        minimum_thumbs: The minimum number of thumbs needed to calculate the governance status.

    Returns:
        A dictionary of governance indicator observations.
    """
    indicator_observations = {}
    for (assistant_id, agent_workflow_id), stats in aggregated_stats.items():
        _governance = AssistantGovernanceModel.query.filter(
                AssistantGovernanceModel.assistant_id == assistant_id,
                AssistantGovernanceModel.workflow_id == agent_workflow_id
            ).first()
        if _governance is None:
            continue

        configuration = json.loads(_governance.configuration)

        thumbs_indicator_uuid = configuration["thumbs_indicator_uuid"]
        if thumbs_indicator_uuid:
            thumbs_percent = stats.evaluate(minimum_thumbs)
            logging.info(f"thumbs indicator for {assistant_id} {agent_workflow_id} has value {thumbs_percent} on {thumbs_indicator_uuid}")
            indicator_observations.setdefault(thumbs_indicator_uuid.strip(), []).append(
                ThumbsObservation(percent=thumbs_percent, governance=_governance)
            )
    return indicator_observations


def _update_governance(indicator_observations: dict[str, list[ThumbsObservation]]) -> list[dict]:
    """
    Execute all indicators and update their governance status.

    Args:
        indicators: A dictionary of governance observations.

    Returns:
        A list of dictionaries containing the governance status for all assistants and workflows.
    """
    logging.info(f"Updating governance for {indicator_observations}")
    governance_statuses = []
    for indicator, observations in indicator_observations.items():
        if observations:
            logging.debug(f"Evaluating governance in {indicator} for {observations}")
            compliance, evaluation = evaluate_indicator(indicator, "thumbs", [o.export() for o in observations])
            logging.debug(f"Compliance: {compliance}\nEvaluation: {evaluation}")

            def _process_valid(observation: ThumbsObservation, compliant: bool):
                _governance = observation.governance
                status = {
                    **json.loads(_governance.status),
                    'thumbs_indicator': {
                        'percent': observation.percent,
                        'pass': compliant if observation.is_sufficient else None,
                        'evaluation': evaluation if observation.is_sufficient else None
                    }
                }
                _governance.status = json.dumps(status)
                return (_governance, status)

            governance_statuses.extend(map(_process_valid, observations, compliance))

    return governance_statuses


ns = Namespace('Governance',
               description='Governance information and batch operations.',
               path='/governance')

conversation_governance_arguments = reqparse.RequestParser()
conversation_governance_arguments.add_argument(
    'thumbsWindow', type=int, required=False, default=DEFAULT_THUMBS_WINDOW, 
    help='The number of days to consider for thumbs.')
conversation_governance_arguments.add_argument(
    'minimumThumbs', type=int, required=False, default=DEFAULT_MINIMUM_THUMBS, 
    help='Minimum number of thumbs needed to calculate the governance status.')

@ns.route('/conversations/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class ConversationsGovernanceEndpoint(Resource):
    @ns.doc(description="Update the governance status of all assistants and workflows.")
    @ns.expect(conversation_governance_arguments)
    @ns.response(200, 'Success')
    @requires_database_session
    @propagate_principal()
    def get(self):
        args = conversation_governance_arguments.parse_args()
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=args.thumbsWindow)
        logging.info(f"Updating agent governance for conversations after cutoff date: {cutoff_date}"
                     f", minimum thumbs: {args.minimumThumbs}")

        governance_statuses = _update_governance(
            _gather_governance_indicators(
                _aggregate_conversation_stats(
                    database.session.query(ConversationGovernanceModel, ConversationModel)
                        .join(ConversationModel, ConversationGovernanceModel.conversation_id == ConversationModel.id)
                        .filter(ConversationGovernanceModel.created_at >= cutoff_date)
                        .all()
                ), 
                args.minimumThumbs
            )
        )
        database.session.commit()

        return jsonify({
            "cutoff_date": cutoff_date,
            "statuses": [
                {
                    'id': _governance.id,
                    'assistant_id': _governance.assistant_id,
                    'workflow_id': _governance.workflow_id,
                    'status': status
                }
                for _governance, status in governance_statuses
            ]
        })
    
    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
