import json
import logging

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import or_, and_, select
from sqlalchemy.orm import Session
from werkzeug.exceptions import SecurityError

from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, tagged_model, \
    favorible_model, with_favorite, fetch_with_permissions, with_access_permission, get_user_access_for, with_hidden
from maxgpt.services import database
from maxgpt.services.database_model import TagModel, WidgetModel, WidgetTagRelationModel, FavoriteSubject, \
    UserFavoriteModel, PermissionType, AccessPermissionModel, AccessPermissionSubject, AccessPermissionAssigneeType, \
    UserHiddenEntityModel, HiddenEntitySubject
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('Widget',
               description='Widgets representing a container for internal or external tools.',
               path='/widget')

widget_model = ns.inherit('Widget', audited_model(ns), tagged_model(ns), favorible_model(ns), {
    'id': fields.String(description="The UUID of the widget.", required=True, readonly=True),
    'name': fields.String(description="The name of the widget.", max_length=100, required=True),
    'description': fields.String(description="A verbose description of the widget.", max_length=2000, required=True),
    'url': fields.String(description="A URL that refers to the widget's application.", required=True),
    'icon': fields.String(description="A base64 encoded image to show as icon for this widget.", required=False),
    'image': fields.String(description="A base64 encoded image to show in the widget tile.", required=False)
})

# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class WidgetsEndpoint(Resource):
    @ns.doc("list_widgets")
    @ns.param('hidden', 'Set to true to get only hidden widgets, false for only unhidden', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(widget_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available widgets that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        
        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        
        # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            enhanced_widgets = fetch_with_permissions(WidgetModel, hidden_ids)
        elif hidden_param == 'false':
            enhanced_widgets = fetch_with_permissions(
                WidgetModel,
                ids=hidden_ids,
                exclude=True   
            )
        else:
            enhanced_widgets = fetch_with_permissions(WidgetModel)

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))
        
        return jsonify([with_hidden(with_favorite(with_access_permission(_widget.to_dict(), _widget.permission), subject_ids), hidden_ids) 
                        for _widget in enhanced_widgets])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class WidgetFactoryEndpoint(Resource):
    @ns.expect(widget_model)
    @ns.doc("create_widget")
    @ns.response(200, 'Success', widget_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new Widget."""
        _data = request.get_json()
        _image = _data.get('image')
        _icon = _data.get('icon')
        
        _widget = WidgetModel(name=_data.get('name'),
                                    description=_data.get('description'),
                                    url=_data.get('url'))

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _widget.tag_relations.append(
                    WidgetTagRelationModel(widget_id=_widget.id, tag_id=_shallow_tag['id']))
        if _image:
            _widget.image = _image
        if _icon:
            _widget.icon = _icon

        database.session.add(_widget)
        # commit to get autogen fields filled before returning
        database.session.commit()

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        
        return jsonify(with_access_permission(with_hidden(with_favorite(_widget.to_dict(), subject_ids), set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<widget_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class WidgetEndpoint(Resource):
    @ns.doc("read_widget")
    @ns.response(200, 'Success', fields.Nested(widget_model))
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def get(self, widget_id: str):
        """Returns a Widget for the given id."""
        _widget: WidgetModel = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f'A widget with identifier "{widget_id}" does not exist')

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read widget with identifier '{widget_id}'")

        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        
        return jsonify(with_access_permission(with_hidden(with_favorite(_widget.to_dict(), subject_ids), hidden_ids), grant))


    @ns.doc("update_widget")
    @ns.expect(widget_model)
    @ns.response(200, 'Success', widget_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The widget does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, widget_id: str):
        """Updates an existing Widget."""
        _data = request.get_json()
        _widget: WidgetModel = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f'A widget with identifier "{widget_id}" does not exist')

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        # Mandatory fields
        _widget.name = _data['name'] if 'name' in _data else _widget.name
        _widget.description = _data['description'] if 'description' in _data else _widget.description
        _widget.url = _data['url'] if 'url' in _data else _widget.url

        session = Session.object_session(_widget)

        # Optional update fields
        if _data.get('tags') is not None:
            for _tag_relation in _widget.tag_relations:
                session.delete(_tag_relation)
            _widget.tag_relations = []
            for _shallow_tag in _data['tags']:
                _widget.tag_relations.append(
                    WidgetTagRelationModel(widget_id=_widget.id, tag_id=_shallow_tag['id']))

        _widget.image = _data['image'] if 'image' in _data else _widget.image
        _widget.icon = _data['icon'] if 'icon' in _data else _widget.icon

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.WIDGET)
        )
        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        
        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(with_access_permission(with_hidden(with_favorite(_widget.to_dict(), subject_ids), hidden_ids), grant))


    @ns.doc("delete_widget")
    @ns.response(200, 'Success', widget_model)
    @ns.response(404, 'The widget does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, widget_id: str):
        """Deletes an existing Widget."""
        _widget: WidgetModel = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f'A widget with identifier "{widget_id}" does not exist')

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to delete widget with identifier '{widget_id}'")

        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.WIDGET,
                UserFavoriteModel.subject_id == _widget.id
            )
        ).delete()

        subject_ids = set([])
         # delete hidden information
        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.WIDGET,
                UserHiddenEntityModel.subject_id == _widget.id
            )
        ).delete()
        database.session.delete(_widget)
        database.session.commit()
        return jsonify(with_access_permission(with_hidden(with_favorite(_widget.to_dict(), subject_ids), subject_ids), grant))

    @ns.doc(False)
    def options(self, widget_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<widget_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class WidgetGrantsEndpoint(Resource):
    @ns.doc(description="read_widget_grants")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def get(self, widget_id: str):
        _widget = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f"A widget with identifier '{widget_id}' does not exist")

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _widget.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WIDGET)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, widget_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<widget_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class WidgetGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_widget_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def post(self, widget_id: str):
        _data = request.get_json()
        _widget = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f"A widget with identifier '{widget_id}' does not exist")

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.WIDGET, subject_id=widget_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, widget_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<widget_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'])
class WidgetGrantEndpoint(Resource):
    @ns.doc(description="read_widget_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def get(self, widget_id: str, assignee_type: str, assignee_id: str):
        _widget = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f"A widget with identifier '{widget_id}' does not exist")

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _widget.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WIDGET) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for widget '{_widget.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for widget {widget_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]

        return jsonify(permission.to_dict())

    @ns.doc(description="update_widget_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def put(self, widget_id: str, assignee_type: str, assignee_id: str):
        _data = request.get_json()
        _widget = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f"A widget with identifier '{widget_id}' does not exist")

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _widget.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WIDGET) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for widget '{_widget.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for widget {widget_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_widget_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Widget not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, widget_id: str, assignee_type: str, assignee_id: str):
        _widget: WidgetModel = WidgetModel.query.get(widget_id)

        if _widget is None:
            ns.abort(404, f"A widget with identifier '{widget_id}' does not exist")

        grant = get_user_access_for(_widget)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update widget with identifier '{widget_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _widget.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.WIDGET) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for widget '{_widget.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for widget {widget_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, widget_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200
