from flask import Response, request
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import propagate_principal, yield_token_chunks
from maxgpt.core.query_process import QueryProcess
from maxgpt.services.database_model import MessagePartType, DataSourceModel

ns = Namespace('Query', description='Operations allowing querying a LLM.', path="/query")

message_override_parameter_model = ns.model("Message Override Parameter", {
    'name': fields.String(description="The name of the parameter.", required=True),
    'value': fields.String(description="The value of the parameter", required=True),
})

message_part_model = ns.model('MessagePart', {
    'type': fields.String(description="The type of the message part (TEXT | BASE64_IMAGE)", enum=[t.name for t in MessagePartType],
                          required=True, default=MessagePartType.TEXT.name, example=MessagePartType.TEXT.name),
    'content': fields.String(description="The content of the part encoded as string", required=False),
})

message_model = ns.model('Query Message', {
    'parts': fields.List(fields.Nested(message_part_model), description='The list of message parts'),
    'llmId': fields.String(description="The ID of a LLM module to be used for the query engine.", required=True),
    'dataSourceId': fields.String(description="The ID of a data source module if the query should consider custom data knowledge", required=False),
    'overrides': fields.List(fields.Nested(message_override_parameter_model), description="Expert configurations to configure message processing in a particular way. Do not use if you are not sure what to do.",
                             default=[], required=False),
})

@ns.route('/message/', strict_slashes=False)
class MessageEndpoint(Resource):
    @ns.doc(description="Send a new message to the AI framework and streams its final response.")
    @ns.expect(message_model)
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @propagate_principal()
    def post(self):
        data = request.get_json()

        if 'dataSourceId' in data:
            __data_source = DataSourceModel.query.get(data['dataSourceId'])
            if __data_source is None:
                ns.abort(404, 'A data source with identifier "{}" does not exist'.format(data['dataSourceId']))
        else:
            __data_source = None

        process = QueryProcess(user_message_parts=data['parts'], llm_id=data['llmId'], data_source=__data_source, overrides=data.get('overrides', []))
        # noinspection PyCallingNonCallable
        return Response(yield_token_chunks(process.execute(), None),
                        mimetype='text/event-stream')

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
