import logging

from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from flask_sqlalchemy.session import Session
from sqlalchemy import and_, select
from werkzeug.exceptions import SecurityError
from datetime import datetime

from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, tagged_model, \
    with_favorite, get_user_access_for, fetch_with_permissions, with_access_permission, data_source_to_dict, with_hidden
from maxgpt.modules import ModuleRegistry, ModuleType
from maxgpt.services import database
from maxgpt.services.database_model import DataSourceModel, DataSourceTagRelationModel, \
    FavoriteSubject, HiddenEntitySubject, UserFavoriteModel, PermissionType, AccessPermissionModel, AccessPermissionSubject, \
    AccessPermissionAssigneeType, UserHiddenEntityModel
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('DataSources',
               description='Configure data sources',
               path='/data-source')

data_source_model = ns.inherit('DataSource', audited_model(ns), tagged_model(ns), {
    'id': fields.String(description="The id of the data source.", required=True, readonly=True),
    'name': fields.String(description="The name of the data source.", max_length=100, required=False),
    'description': fields.String(description="A short summary of the data source.", max_length=500, required=False),
    'filterTag': fields.String(description="A tag to isolate data within the same vector store index", max_length=100, required=False),
    'embeddingModelId': fields.String(description="The ID of an existing embedding model module.", max_length=36, required=True),
    'vectorStoreId': fields.String(description="The ID of an existing vector store index module.", max_length=36, required=True),
    'fileStorageId': fields.String(description="The ID of an existing file storage module.", max_length=36, required=False),
})


# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class DataSourcesEndpoint(Resource):
    @ns.doc("list_data_sources")
    @ns.param('isDeleted', 'Set to true to get soft-deleted data-sources', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden system-instructions, false for only unhidden', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(data_source_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all stored data sources that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == 'true':
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_data_sources = DataSourceModel.query.filter(
                DataSourceModel.deleted_at.isnot(None),
                DataSourceModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([data_source.to_dict() for data_source in soft_deleted_data_sources])
        
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
         # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            enhanced_datasources: list[DataSourceModel] = fetch_with_permissions(DataSourceModel,hidden_ids)
        elif hidden_param == 'false':
            enhanced_datasources: list[DataSourceModel] = fetch_with_permissions(
                DataSourceModel,
                ids=hidden_ids,
                exclude=True   
            )
        else:
            enhanced_datasources = fetch_with_permissions(DataSourceModel)

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))
       

        return jsonify([with_favorite(with_hidden(with_access_permission(data_source_to_dict(_datasource), _datasource.permission),hidden_ids), subject_ids)
                        for _datasource in enhanced_datasources])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class DatasourceFactoryEndpoint(Resource):
    @ns.expect(data_source_model)
    @ns.doc("create_data-source")
    @ns.response(200, 'Success', data_source_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new data source."""
        _data = request.get_json()
        _vector_store_id = _data.get('vectorStoreId')
        _embedding_model_id = _data.get('embeddingModelId')
        _file_storage_id = _data.get('fileStorageId')
        _description = _data.get('description')

        _data_source = DataSourceModel(name=_data['name'])

        if _description:
            _data_source.description = _description

        if _embedding_model_id:
            _embedding_model = ModuleRegistry.get_module(_embedding_model_id)
            if _embedding_model is None or _embedding_model.get_spec().get_module_type() != ModuleType.EMBEDDING_MODEL:
                ns.abort(400, f"Embedding model with id {_embedding_model_id} does not exists or is of wrong type")
            else:
                _data_source.embedding_model_id = _embedding_model.get_id()

        if _vector_store_id:
            _vector_store = ModuleRegistry.get_module(_vector_store_id)
            if _vector_store is None or _vector_store.get_spec().get_module_type() != ModuleType.VECTOR_STORE:
                ns.abort(400, f"Vector store with id {_vector_store_id} does not exists or is of wrong type")
            else:
                _data_source.vector_store_id = _vector_store.get_id()

        if _file_storage_id:
            _file_storage = ModuleRegistry.get_module(_file_storage_id)
            if _file_storage is None or _file_storage.get_spec().get_module_type() != ModuleType.FILE_STORAGE:
                ns.abort(400, f"File Storage with id {_file_storage_id} does not exists or is of wrong type")
            else:
                _data_source.file_storage_id = _file_storage.get_id()

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _data_source.tag_relations.append(
                    DataSourceTagRelationModel(data_source_id=_data_source.id, tag_id=_shallow_tag['id']))

        _data_source.filter_tag = _data.get('filterTag') if 'filterTag' in _data else None

        database.session.add(_data_source)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))


        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(data_source_to_dict(_data_source), subject_ids),set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<data_source_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class DatasourceEndpoint(Resource):
    @ns.doc(description="read_data_source")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted data sources', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', data_source_model)
    @ns.response(404, 'Data-source not found')
    @requires_database_session
    @propagate_principal()
    def get(self, data_source_id: str):
        """Returns the data source for the given id if existing and accessible for the current user."""
        # Base query without deleted filter
        query = DataSourceModel.query.filter(DataSourceModel.id == data_source_id)
        
        # Only apply deleted filter if includeDeleted is not true
        if 'includeDeleted' not in request.args or request.args.get('includeDeleted').lower() != 'true':
            query = query.filter(DataSourceModel.deleted_at.is_(None))
            
        _data_source = query.first()

        if _data_source is None:
            ns.abort(404, 'A data source with identifier "{}" does not exist'.format(data_source_id))
  
        grant = get_user_access_for(_data_source)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401,
                     f"Not authorized. You do not have permission to read datasource with identifier '{data_source_id}'")

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))

        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify(with_hidden(with_favorite(data_source_to_dict(_data_source), subject_ids),hidden_ids))


    @ns.doc("update_data_source")
    @ns.expect(data_source_model)
    @ns.response(200, 'Success', data_source_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The data source does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, data_source_id: str):
        """Updates an existing data source."""
        _data = request.get_json()
        _data_source: DataSourceModel = DataSourceModel.query.get(data_source_id)

        if _data_source is None:
            ns.abort(404, 'A data source with identifier "{}" does not exist'.format(data_source_id))

        #Check if data_source is already deleted
        if _data_source.deleted_at is not None:
            ns.abort(404, f"The data_source with identifier {data_source_id} has already been deleted and cannot be modified")

        grant = get_user_access_for(_data_source)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to update datasource with identifier '{data_source_id}'")

        # TODO: Validate consistency with existing referrers
        _data_source.name = _data.get('name') if 'name' in _data else _data_source.name
        _data_source.description = _data.get('description') if 'description' in _data else _data_source.description
        _data_source.filter_tag = _data.get('filterTag') if 'filterTag' in _data else _data_source.filter_tag

        session = Session.object_session(_data_source)

        if 'embeddingModelId' in _data:
            _embedding_model_id = _data.get('embeddingModelId')
            if _embedding_model_id:
                if _data_source.embedding_model_id and _embedding_model_id != _data_source.embedding_model_id:
                    ns.abort(400, f"Your are no allowed to change the embedding model")
                else:
                    _embedding_model = ModuleRegistry.get_module(_embedding_model_id)
                    if _embedding_model is None or _embedding_model.get_spec().get_module_type() != ModuleType.EMBEDDING_MODEL:
                        ns.abort(400, f"Embedding model with id {_embedding_model_id} does not exists or is of wrong type")
                    else:
                        _data_source.embedding_model_id = _embedding_model.get_id()
            else:
                if _data_source.embedding_model_id:
                    ns.abort(400, f"Your are no allowed to change the embedding model")

        if 'vectorStoreId' in _data:
            _vector_store_id = _data.get('vectorStoreId')
            if _vector_store_id:
                if _data_source.vector_store_id and _vector_store_id != _data_source.vector_store_id:
                    ns.abort(400, f"Your are no allowed to change the vector store")
                else:
                    _vector_store = ModuleRegistry.get_module(_vector_store_id)
                    if _vector_store is None or _vector_store.get_spec().get_module_type() != ModuleType.VECTOR_STORE:
                        ns.abort(400, f"Vector store with id {_vector_store_id} does not exists or is of wrong type")
                    else:
                        _data_source.vector_store_id = _vector_store.get_id()
            else:
                if _data_source.vector_store_id:
                    ns.abort(400, f"Your are no allowed to change the vector store")

        if 'fileStorageId' in _data:
            _file_storage_id = _data.get('fileStorageId')
            if _file_storage_id:
                if _data_source.file_storage_id and _file_storage_id != _data_source.file_storage_id:
                    ns.abort(400, f"Your are no allowed to change the file storage")
                else:
                    _file_storage = ModuleRegistry.get_module(_file_storage_id)
                    if _file_storage is None or _file_storage.get_spec().get_module_type() != ModuleType.FILE_STORAGE:
                        ns.abort(400, f"File Storage with id {_file_storage_id} does not exists or is of wrong type")
                    else:
                        _data_source.file_storage_id = _file_storage.get_id()
            else:
                if _data_source.file_storage_id:
                    ns.abort(400, f"Your are no allowed to change the file storage")

        # Optional update fields
        if _data.get('tags') is not None:
            for _relation in _data_source.tag_relations:
                session.delete(_relation)
            _data_source.tag_relations = []
            for _shallow_tag in _data['tags']:
                _data_source.tag_relations.append(
                    DataSourceTagRelationModel(data_source_id=_data_source.id, tag_id=_shallow_tag['id']))

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        database.session.commit()

        return jsonify(with_hidden(with_favorite(data_source_to_dict(_data_source), subject_ids),hidden_ids))

    @ns.doc("delete_data_source")
    @ns.param('hardDelete', 'Set to true to hard delete the data-source', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', data_source_model)
    @ns.response(404, 'The data_source does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, data_source_id: str):
        """Delete the data source for the given identifier if existing and accessible for the current user."""
        _data_source = DataSourceModel.query.get(data_source_id)
        current_user = SessionContext.get_current_user()

        if _data_source is None:
            ns.abort(404, 'A data source with identifier "{}" does not exist'.format(data_source_id))
        
        #Check if data_source is already soft deleted
        if _data_source.deleted_at is not None:
            ns.abort(404, f"The data_source with identifier {data_source_id} has already been deleted")

        grant = get_user_access_for(_data_source)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,
                     f"Not authorized. You do not have permission to delete datasource with identifier '{data_source_id}'")
        
        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE,
                UserFavoriteModel.subject_id == data_source_id
            )
        ).delete()
         # delete hidden information
        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE,
                UserHiddenEntityModel.subject_id == data_source_id
            )
        ).delete()

        #This check will preserve the original functionality of DELETE API and can be used from swagger using query parameter
        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == 'true':
            logging.log(logging.INFO, f"Hard delete the data-source:{data_source_id}")
            database.session.delete(_data_source)
        else:
            logging.log(logging.INFO, f"Soft delete the data-source:{data_source_id}")
            _data_source.deleted_at = datetime.now()
            _data_source.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()
        # attach favorite information
        subject_ids = set([])
        return jsonify(with_hidden(with_favorite(data_source_to_dict(_data_source), subject_ids),subject_ids))

    @ns.doc(False)
    def options(self, data_source_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<data_source_id>/grants/', strict_slashes=False, methods=['GET','OPTIONS'])
class DatasourceGrantsEndpoint(Resource):
    @ns.doc(description="Get data-source grant")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'Data source not found')
    @requires_database_session
    @propagate_principal()
    def get(self, data_source_id: str):
        """Returns data-source grants"""
        _datasource = DataSourceModel.query.filter(
            DataSourceModel.id == data_source_id,
            DataSourceModel.deleted_at.is_(None)
        ).first()
        #_datasource = database.session.get(DataSourceModel, data_source_id)  #Change as per unit test

        if _datasource is None:
            ns.abort(404, f"A data source with identifier '{data_source_id}' does not exist.")

        grant = get_user_access_for(_datasource)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
            ns.abort(401, f"Not authorized. You are not authorized to update datasource with identifier '{data_source_id}'")

        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _datasource.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.DATA_SOURCE)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])
    
    @ns.doc(False)
    def options(self, data_source_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    
@ns.route('/<data_source_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class DatasourceGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_datasource_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Datasource not found')
    @requires_database_session
    @propagate_principal()
    def post(self, data_source_id: str):
        """Create data-source grants"""
        _data = request.get_json()
        _datasource = DataSourceModel.query.filter(
            DataSourceModel.id == data_source_id,
            DataSourceModel.deleted_at.is_(None)
        ).first()
        #_datasource = database.session.get(DataSourceModel, data_source_id)  #Changes as per unit test

        if _datasource is None:
            ns.abort(404, f"A datasource with identifier '{data_source_id}' does not exists")

        grant = get_user_access_for(_datasource)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401, f"Not authorized. You do not have permission to update datasource with identifier '{data_source_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.DATA_SOURCE, subject_id=data_source_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))
        
        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())
    
    @ns.doc(False)
    def options(self, data_source_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    
@ns.route('/<data_source_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False, methods=['PUT', 'DELETE', 'OPTIONS'])
class DatasourceGrantEndpoint(Resource):
    @ns.doc(description="update_datasource_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Datasource not found')
    @requires_database_session
    @propagate_principal()
    def put(self, data_source_id: str, assignee_type: str, assignee_id:str):
        """Update data-source grants"""
        _data = request.get_json()
        _datasource = DataSourceModel.query.filter(
            DataSourceModel.id == data_source_id,
            DataSourceModel.deleted_at.is_(None)
        ).first()

        if _datasource is  None:
            ns.abort(404, f"A datasource with identifier '{data_source_id}' does not exist")

        grant = get_user_access_for(_datasource)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,f"Not authorized. You do not have permission to update datasource with identifier '{data_source_id}'")

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid access level')
        
        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _datasource.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.DATA_SOURCE) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )

        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404, f"A permission for datasource '{_datasource.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for datasource {data_source_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")
        
        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())
    
    @ns.doc(description="delete_datasource_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Datasource not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, data_source_id: str, assignee_type: str, assignee_id: str):
        """Delete a datasource grant"""
        _datasource = DataSourceModel.query.filter(
            DataSourceModel.id == data_source_id,
            DataSourceModel.deleted_at.is_(None)
        ).first()

        if _datasource is None:
            ns.abort(404, f"A datasource with identifier '{data_source_id}' does not exist")

        grant = get_user_access_for(_datasource)
        if PermissionType.rank(grant) < PermissionType.rank(PermissionType.WRITE):
            ns.abort(401,f"Not authorized. You do not have permission to update datasource with identifier '{data_source_id}'")

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _datasource.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.DATA_SOURCE) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for datasource '{_datasource.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant delete request for datasource {data_source_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)
        database.session.commit()

        return jsonify(permission.to_dict())
    
    @ns.doc(False)
    def options(self, data_source_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<data_source_id>/restore/', strict_slashes=False, methods=['PATCH', 'OPTIONS'])
class DataSourceRestoreEndpoint(Resource):
    @ns.doc("restore_data_source")
    @ns.response(200, 'Success', data_source_model)
    @ns.response(404, 'The data source does not exist.')
    @requires_database_session
    @propagate_principal()
    def patch(self, data_source_id: str):
        """Restore a soft-deleted data source."""
        current_user = SessionContext.get_current_user()
        _data_source = DataSourceModel.query.get(data_source_id)
        if not _data_source:
            ns.abort(404, f"Data source with id {data_source_id} does not exist.")

        if not _data_source.deleted_at:
            ns.abort(400, f"Data source with id {data_source_id} is not deleted.")

        # Check if the current user is the creator of the datasource
        if _data_source.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this Data source")

        _data_source.deleted_at = None
        _data_source.deleted_by = None
        database.session.commit()

        
        return jsonify(data_source_to_dict(_data_source))

    @ns.doc(False)
    def options(self, data_source_id: str):
        # Handle preflight OPTIONS request
        return '', 200