import base64
import datetime
import hashlib
import io
import json
import logging
import os
import time
from types import SimpleNamespace
from typing import List

from cryptography.fernet import Fernet
from flask import request, jsonify, send_file
from flask_restx import Namespace, Resource, fields, reqparse
from werkzeug.datastructures import FileStorage

from maxgpt.api.internal.utils import requires_database_session, propagate_principal, NonFlaskCustomJsonEncoder, \
    data_source_to_dict
from maxgpt.modules import ModuleRegistry, ModuleType, ModuleSpecRegistry, Module
from maxgpt.services import database
from maxgpt.services.eqty.util import get_eqty_version
from maxgpt.services.database_model import ModuleModel, SystemInstructionModel, DataSourceModel, AssistantModel, \
    AgentModel, AgentWorkflowModel, WorkspaceModel, TagModel, DocumentType, SystemInstructionTagRelationModel, \
    DataSourceTagRelationModel, AgentSystemInstructionRelationModel, AgentModuleRelation, AgentTagRelationModel, \
    AssistantSystemInstructionRelationModel, AssistantTagRelationModel, AssistantModuleRelationModel, \
    AssistantDataSourceRelationModel, AssistantSampleQuestionModel, AgentWorkflowTagRelationModel, \
    AgentWorkflowDataSourceRelationModel, AgentWorkflowAgentType, AgentWorkflowAssistantRelationModel, \
    AgentWorkflowAgentRelationModel, AgentWorkflowHandoffRelationModel, AgentWorkflowRootAgentType, ConversationModel, \
    DataObjectModel, IngestProcessModel, WorkspaceAgentWorkflowRelationModel, WorkspaceAgentRelationModel, \
    WorkspaceAssistantRelationModel, WorkspaceSystemInstructionRelationModel, WorkspaceTagRelationModel
from maxgpt.services.internal import ShallowTag
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.navai.api.impl.utils import decrypt_json, encrypt_json

ns = Namespace('System',
               description='Endpoints providing details about the system and executing system operations like importing and exporting of entities.',
               path='/system')

export_configuration = ns.model('Export Request Configuration', {
        'llmModules': fields.Boolean(description="Export should include llm modules", required=True, default=True),
        'embeddingModelModules': fields.Boolean(description="Export should include embedding model modules", required=True, default=True),
        'vectorStoreModules': fields.Boolean(description="Export should include vector store modules", required=True, default=True),
        'fileStorageModules': fields.Boolean(description="Export should include file storage modules", required=True, default=True),
        'functionToolModules': fields.Boolean(description="Export should include function tool modules", required=True, default=True),
        'systemInstructions': fields.Boolean(description="Export should include system instructions", required=True, default=True),
        'dataSources': fields.Boolean(description="Export should include data sources with data object details", required=True, default=True),
        'assistants': fields.Boolean(description="Export should include assistants", required=True, default=True),
        'agents': fields.Boolean(description="Export should include agents", required=True, default=True),
        'agentWorkflows': fields.Boolean(description="Export should include agent workflows", required=True, default=True),
        'workspaces': fields.Boolean(description="Export should include workspaces", required=True, default=True),
        'force': fields.Boolean(description="Ignore validation and warnings.", required=True, default=False),
        'password': fields.String(default=None, description="A password to secure the returned file content. You need this password to upload the file content on a different system. Optional.", required=False)
})

# Required because RESTX-Swagger does not support null as example value for strings.
export_configuration_example = ns.schema_model('Export Request Configuration Example', {
    "example": {
        "llmModules": True,
        "embeddingModelModules": True,
        "vectorStoreModules": True,
        "fileStorageModules": True,
        "functionToolModules": True,
        "systemInstructions": True,
        "dataSources": True,
        "assistants": True,
        "agents": True,
        "agentWorkflows": True,
        "workspaces": True,
        "force": False,
        "password": None
    }
})

def str_to_bool(value):
    return str(value).lower() in ["true", "1"]

import_configuration_parser = reqparse.RequestParser()
import_configuration_parser.add_argument('file', type=FileStorage, location='files', required=True)
import_configuration_parser.add_argument('llmModules', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('embeddingModelModules', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('vectorStoreModules', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('fileStorageModules', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('functionToolModules', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('systemInstructions', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('dataSources', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('assistants', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('agents', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('agentWorkflows', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('workspaces', default=True, type=str_to_bool, location='form', required=True)
import_configuration_parser.add_argument('password', type=str, location='form', required=False)


def create_module_for_module_dict(_module_dict: dict) -> Module:
    module_spec = ModuleSpecRegistry.get_module_spec(_module_dict['specId'])
    if not module_spec:
        raise RuntimeError(f"Module spec '{_module_dict['specId']}' does not exist.")

    _shallow_tags = []
    if _module_dict.get('tags') is not None:
        for tag in _module_dict['tags']:
            _shallow_tags.append(ShallowTag(tag['id'], tag['name']))

    _supported_inputs: List[DocumentType] = []
    if _module_dict.get('supportedInputs') is not None:
        for document_type_name in _module_dict['supportedInputs']:
            _supported_inputs.append(DocumentType(document_type_name))

    return ModuleRegistry.create_module(_module_dict['name'], _module_dict.get('description'), module_spec,
                                 {parameter['name']: parameter['value'] for parameter in
                                  _module_dict['parameters']},
                                 _shallow_tags, _supported_inputs, _module_dict["id"])

def assert_tag_existence(_tags: List[dict] = []) -> List[ShallowTag]:
    _shallow_tags = []
    for tag in _tags:
        _shallow_tags.append(ShallowTag(tag['id'], tag['name']))
        if not TagModel.query.filter_by(id=tag['id']).first():
            logging.info(f"*** IMPORT *** \tCreating missing Tag '{tag['name']}'.")
            database.session.add(
                TagModel(id=tag['id'], name=tag['name'], description=None))
    database.session.commit()
    return _shallow_tags


@ns.route('/export/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class ExportEndpoint(Resource):
    @ns.doc("export")
    @ns.expect(export_configuration_example)
    @requires_database_session
    @propagate_principal(allowed_app_role_names=['administrator'])
    def post(self):
        configuration_dict = request.json  # Get dictionary

        if configuration_dict is None:
            ns.abort(400, "Invalid request")

        configuration = SimpleNamespace(**configuration_dict)

        # Validate if not enforced:
        if not configuration.force:
            if configuration.dataSources:
                if not configuration.embeddingModelModules or not configuration.vectorStoreModules or not configuration.fileStorageModules:
                    ns.abort(400, "When exporting DataSources, you need to export embedding model modules, vector store modules and file storage modules too. Use force=True to ignore this warning.")

            if configuration.assistants:
                if not configuration.llmModules or not configuration.systemInstructions or not configuration.dataSources:
                    ns.abort(400, "When exporting Assistants, you need to export llm modules, system instructions and data sources too. Use force=True to ignore this warning.")

            if configuration.agents:
                if not configuration.functionToolModules or not configuration.systemInstructions:
                    ns.abort(400, "When exporting Agents, you need to export Function Tools System Instructions too. Use force=True to ignore this warning.")

            if configuration.agentWorkflows:
                if not configuration.agents or not configuration.assistants or not configuration.dataSources:
                    ns.abort(400, "When exporting Agent Workflows, you need to export agents, assistants and data sources too. Use force=True to ignore this warning.")

            if configuration.workspaces:
                if not configuration.agents or not configuration.assistants or not configuration.dataSources or not configuration.systemInstructions or not configuration.agentWorkflows:
                    ns.abort(400, "When exporting a workspace, you need to export agents, assistants, system instructions, agent workflows and data sources too. Use force=True to ignore this warning.")

        # Now collecting the data
        file_content = {}

        if configuration.llmModules:
            _in_memory_modules = ModuleRegistry.get_modules(ModuleType.LLM)
            _modules = ModuleModel.query.filter(ModuleModel.id.in_([_m.get_id() for _m in _in_memory_modules])).all()
            file_content['llmModules'] = [_llmModule.to_dict() for _llmModule in _modules]

        if configuration.embeddingModelModules:
            _in_memory_modules = ModuleRegistry.get_modules(ModuleType.EMBEDDING_MODEL)
            _modules = ModuleModel.query.filter(ModuleModel.id.in_([_m.get_id() for _m in _in_memory_modules])).all()
            file_content['embeddingModelModules'] = [_llmModule.to_dict() for _llmModule in _modules]

        if configuration.vectorStoreModules:
            _in_memory_modules = ModuleRegistry.get_modules(ModuleType.VECTOR_STORE)
            _modules = ModuleModel.query.filter(ModuleModel.id.in_([_m.get_id() for _m in _in_memory_modules])).all()
            file_content['vectorStoreModules'] = [_llmModule.to_dict() for _llmModule in _modules]

        if configuration.fileStorageModules:
            _in_memory_modules = ModuleRegistry.get_modules(ModuleType.FILE_STORAGE)
            _modules = ModuleModel.query.filter(ModuleModel.id.in_([_m.get_id() for _m in _in_memory_modules])).all()
            file_content['fileStorageModules'] = [_llmModule.to_dict() for _llmModule in _modules]

        if configuration.functionToolModules:
            _in_memory_modules = ModuleRegistry.get_modules(ModuleType.FUNCTION_TOOL)
            _modules = ModuleModel.query.filter(ModuleModel.id.in_([_m.get_id() for _m in _in_memory_modules])).all()
            file_content['functionToolModules'] = [_llmModule.to_dict() for _llmModule in _modules]

        if configuration.systemInstructions:
            file_content['systemInstructions'] = [_entity.to_dict() for _entity in SystemInstructionModel.query.all()]

        if configuration.dataSources:
            # fetch all conversation ids
            conversation_ids = {conv.id for conv in database.session.query(ConversationModel.id).all()}
            # following the auto-generation of data_sources, we exclude everything where filter_tag not equals to any conversation id
            valid_data_source_ids = {
                ds.id for ds in database.session.query(DataSourceModel.id)
                .filter(DataSourceModel.filter_tag.notin_(conversation_ids))
                .all()
            }
            file_content['dataSources'] = [
                data_source_to_dict(ds) for ds in DataSourceModel.query.filter(
                    DataSourceModel.id.in_(valid_data_source_ids)
                ).all()
            ]

            file_content['dataSourcesIngestProcesses'] = [
                ingest.to_dict() for ingest in IngestProcessModel.query.filter(
                    IngestProcessModel.data_source_id.in_(valid_data_source_ids)
                ).all()
            ]

        if configuration.assistants:
            file_content['assistants'] = [_entity.to_dict() for _entity in AssistantModel.query.all()]

        if configuration.agents:
            file_content['agents'] = [_entity.to_dict() for _entity in AgentModel.query.all()]

        if configuration.agentWorkflows:
            file_content['agentWorkflows'] = [_entity.to_dict() for _entity in AgentWorkflowModel.query.all()]

        if configuration.workspaces:
            file_content['workspaces'] = [_entity.to_dict() for _entity in WorkspaceModel.query.all()]
            if configuration.agentWorkflows:
                file_content['workspaceAgentWorkflowRelations'] = [_entity.to_dict() for _entity in WorkspaceAgentWorkflowRelationModel.query.all()]
            if configuration.agents:
                file_content['workspaceAgentRelations'] = [_entity.to_dict() for _entity in WorkspaceAgentRelationModel.query.all()]
            if configuration.assistants:
                file_content['workspaceAssistantRelations'] = [_entity.to_dict() for _entity in WorkspaceAssistantRelationModel.query.all()]
            if configuration.systemInstructions:
                file_content['workspaceSystemInstructionRelations'] = [_entity.to_dict() for _entity in WorkspaceSystemInstructionRelationModel.query.all()]
            # if configuration.widgtes: #TODO

        # Add some meta information about the export
        file_content['meta'] = {
            'exportUser': SessionContext.get_current_user().get_display_name(),
            'timestamp': str(time.time()),
        }

        # Encrypt content to avoid plain text exposure of secrets
        _encrypted_content = encrypt_json(file_content, configuration.password if configuration.password else "maxgpt")

        # Prepare and send encrypted text as file
        date_str = datetime.datetime.now().strftime("%YYYY_%mm_%dd")
        filename = f"export_{date_str}.maxgpt"

        # Create an in-memory file
        file_buffer = io.BytesIO()
        file_buffer.write(_encrypted_content.encode())
        file_buffer.seek(0)

        # Return as a file response
        return send_file(
            file_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype="application/octet-stream"
        )

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/import/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class ImportEndpoint(Resource):
    @ns.doc(description="Gets an export of the application with password to import consisting entities.")
    @ns.expect(import_configuration_parser)
    @requires_database_session
    @propagate_principal(allowed_app_role_names=['administrator'])
    def post(self):
        _args = import_configuration_parser.parse_args()

        _file = _args.pop('file')
        _file_length = _file.seek(0, os.SEEK_END)
        _file.seek(0, os.SEEK_SET)

        configuration = SimpleNamespace(**_args)
        result = {
            "configuration": _args,
        }

        logging.info(f"*** IMPORT *** Importing a system backup using this configuration: {configuration}")

        # Read file
        encrypted_content = _file.read().decode()

        # Decrypt content using password from _args
        password = configuration.password if configuration.password else "maxgpt"
        try:
            decrypted_data = decrypt_json(encrypted_content, password)

            # import following dependency order
            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** LLM Modules")
            logging.info(f"*** IMPORT ***")
            result["llmModules"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.llmModules and "llmModules" in decrypted_data:
                _entity_array = decrypted_data["llmModules"]
                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if ModuleModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** Module '{_entity_dict['name']}' already exists. SKIPPED")
                        result["llmModules"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(f"*** IMPORT *** Importing module '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        assert_tag_existence(_entity_dict["tags"])
                        create_module_for_module_dict(_entity_dict)
                        logging.info(f"*** IMPORT *** \tModule '{_entity_dict['name']}' successfully imported.")
                        result["llmModules"]["imported"] += 1

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Embedding Model Modules")
            logging.info(f"*** IMPORT ***")
            result["embeddingModelModules"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.embeddingModelModules and "embeddingModelModules" in decrypted_data:
                _entity_array = decrypted_data["embeddingModelModules"]
                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if ModuleModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** Module '{_entity_dict['name']}' already exists. SKIPPED")
                        result["embeddingModelModules"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(f"*** IMPORT *** Importing module '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        assert_tag_existence(_entity_dict["tags"])
                        create_module_for_module_dict(_entity_dict)
                        logging.info(f"*** IMPORT *** \tModule '{_entity_dict['name']}' successfully imported.")
                        result["embeddingModelModules"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.embeddingModelModules = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Vector Store Modules")
            logging.info(f"*** IMPORT ***")
            result["vectorStoreModules"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.vectorStoreModules and "vectorStoreModules" in decrypted_data:
                _entity_array = decrypted_data["vectorStoreModules"]
                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if ModuleModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** Module '{_entity_dict['name']}' already exists. SKIPPED")
                        result["vectorStoreModules"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing module '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        assert_tag_existence(_entity_dict["tags"])
                        create_module_for_module_dict(_entity_dict)
                        logging.info(f"*** IMPORT *** \tModule '{_entity_dict['name']}' successfully imported.")
                        result["vectorStoreModules"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.vectorStoreModules = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** File Storage Modules")
            logging.info(f"*** IMPORT ***")
            result["fileStorageModules"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.fileStorageModules and "fileStorageModules" in decrypted_data:
                _entity_array = decrypted_data["fileStorageModules"]
                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if ModuleModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** Module '{_entity_dict['name']}' already exists. SKIPPED")
                        result["fileStorageModules"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing module '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        assert_tag_existence(_entity_dict["tags"])
                        create_module_for_module_dict(_entity_dict)
                        logging.info(f"*** IMPORT *** \tModule '{_entity_dict['name']}' successfully imported.")
                        result["fileStorageModules"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.fileStorageModules = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Function Tool Modules")
            logging.info(f"*** IMPORT ***")
            result["functionToolModules"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.functionToolModules and "functionToolModules" in decrypted_data:
                _entity_array = decrypted_data["functionToolModules"]
                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if ModuleModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** Module '{_entity_dict['name']}' already exists. SKIPPED")
                        result["functionToolModules"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing module '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        assert_tag_existence(_entity_dict["tags"])
                        create_module_for_module_dict(_entity_dict)
                        logging.info(f"*** IMPORT *** \tModule '{_entity_dict['name']}' successfully imported.")
                        result["functionToolModules"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.functionToolModules = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** System Instructions")
            logging.info(f"*** IMPORT ***")
            result["systemInstructions"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.systemInstructions and "systemInstructions" in decrypted_data:
                _entity_array = decrypted_data["systemInstructions"]

                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if SystemInstructionModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(f"*** IMPORT *** System instruction '{_entity_dict['name']}' already exists. SKIPPED")
                        result["systemInstructions"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing system instruction '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_entity_dict["tags"])
                        _persisted_entity = SystemInstructionModel(id=_entity_dict["id"], name=_entity_dict["name"],
                                               description=_entity_dict["description"], message=_entity_dict["message"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(SystemInstructionTagRelationModel(tag_id=_tag.get_id(),
                                                                                       system_instruction_id=_entity_dict['id']))
                        database.session.add(_persisted_entity)
                        database.session.commit()
                        logging.info(f"*** IMPORT *** \tSystem instruction '{_entity_dict['name']}' successfully imported.")
                        result["systemInstructions"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.systemInstructions = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Data Sources")
            logging.info(f"*** IMPORT ***")
            result["dataSources"] = {
                "skipped": 0,
                "imported": 0,
            }

            if configuration.dataSources and "dataSources" in decrypted_data:
                _entity_array = decrypted_data["dataSources"]

                for _ds_entity_dict in _entity_array:
                    # Check if module id already exists
                    if DataSourceModel.query.filter_by(id=_ds_entity_dict["id"]).first():
                        logging.info(
                            f"*** IMPORT *** Data Source '{_ds_entity_dict['name']}' already exists. SKIPPED")
                        result["dataSources"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing data source '{_ds_entity_dict['name']}' with old id {_ds_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_ds_entity_dict["tags"])
                        _persisted_entity = DataSourceModel(id=_ds_entity_dict["id"], name=_ds_entity_dict["name"], description=_ds_entity_dict["description"],
                                                            filter_tag=_ds_entity_dict["filterTag"],
                                                            embedding_model_id=_ds_entity_dict["embeddingModelId"],
                                                            vector_store_id=_ds_entity_dict["vectorStoreId"],
                                                            file_storage_id=_ds_entity_dict["fileStorageId"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(
                                DataSourceTagRelationModel(tag_id=_tag.get_id(),
                                                                  data_source_id=_ds_entity_dict['id']))
                        database.session.add(_persisted_entity)
                        database.session.commit()
                        logging.info(
                            f"*** IMPORT *** \tData source '{_ds_entity_dict['name']}' successfully imported.")
                        result["dataSources"]["imported"] += 1

                        #TODO: What about the ingested files? Should we crate a fake ingest process and add the data objects
                        # so that we still have at least the list of files? Will be critical for local storages, because they
                        # cannot be just copied. So maybe only do so if FileStorage Type is not LOCAL?

                    if "dataSourcesIngestProcesses" in decrypted_data:
                        _entity_array = decrypted_data["dataSourcesIngestProcesses"]

                        for _entity_dict in _entity_array:
                            # Check if process id already exists
                            if IngestProcessModel.query.filter_by(id=_entity_dict["id"]).first():
                                logging.info(
                                    f"*** IMPORT *** Data Source (Ingest Process) '{_entity_dict['id']}' already exists. SKIPPED")
                            else:
                                # Create or Update (update not yet supported)
                                logging.info(
                                    f"*** IMPORT *** Data Source (Ingest Process) '{_entity_dict['id']}' with old id.")
                                _persisted_entity = IngestProcessModel(id=_entity_dict["id"],
                                                                       data_source_id=_entity_dict["dataSourceId"],
                                                                       timestamp=datetime.datetime.now())
                                database.session.add(_persisted_entity)
                                database.session.commit()
                                logging.info(
                                    f"*** IMPORT *** \tData Source (Ingest Process) '{_entity_dict['id']}' successfully imported.")
                    else:
                        logging.info(
                            f"*** IMPORT *** Skipping Data Source (Ingest Process) because configuration.dataSources = false or no data to import.")

                    if "dataSourcesIngestProcesses" in decrypted_data:
                        for _entity_dict in _ds_entity_dict['ingestedFiles']:
                            # Check if process id already exists
                            if DataObjectModel.query.filter_by(id=_entity_dict["id"]).first():
                                logging.info(
                                    f"*** IMPORT *** Data Source (Data Object) '{_entity_dict['name']}' already exists. SKIPPED")
                            else:
                                # Create or Update (update not yet supported)
                                logging.info(
                                    f"*** IMPORT *** Data Source (Data Object) '{_entity_dict['name']}' with old id '{_entity_dict['id']}'.")
                                _persisted_entity = DataObjectModel(id=_entity_dict["id"],
                                                                       name=_entity_dict["name"],
                                                                       file_name=_entity_dict["fileName"],
                                                                       file_system=_entity_dict["fileSystem"],
                                                                       url=_entity_dict["url"],
                                                                       mime_type=_entity_dict["mimeType"],
                                                                       ingest_process_id=_entity_dict["ingestProcessId"],
                                                                    )
                                database.session.add(_persisted_entity)
                                database.session.commit()
                                logging.info(
                                    f"*** IMPORT *** \tData Source (Data Object) '{_entity_dict['name']}' successfully imported.")


            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.dataSources = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Agents")
            logging.info(f"*** IMPORT ***")
            result["agents"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.agents and "agents" in decrypted_data:
                _entity_array = decrypted_data["agents"]

                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if AgentModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(
                            f"*** IMPORT *** Agent '{_entity_dict['name']}' already exists. SKIPPED")
                        result["agents"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Importing agent '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_entity_dict["tags"])

                        _persisted_entity = AgentModel(id=_entity_dict["id"], name=_entity_dict["name"],
                                                            description=_entity_dict["description"],
                                                            llm_id=_entity_dict["llmId"],
                                                            image=_entity_dict["image"],
                                                            icon=_entity_dict["icon"],
                                                            custom_system_instruction=_entity_dict["customSystemInstruction"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(
                                AgentTagRelationModel(tag_id=_tag.get_id(),
                                                           agent_id=_entity_dict['id']))

                        for _system_instruction_id in _entity_dict["systemInstructionIds"]:
                            _persisted_entity.system_instructions.append(
                                AgentSystemInstructionRelationModel(system_instruction_id=_system_instruction_id,
                                                                    agent_id=_entity_dict["id"]))

                        for _function_tool_id in _entity_dict["functionToolIds"]:
                            _persisted_entity.function_tools.append(
                                AgentModuleRelation(module_id=_function_tool_id,
                                                        agent_id=_entity_dict["id"]))

                        database.session.add(_persisted_entity)
                        database.session.commit()
                        logging.info(
                            f"*** IMPORT *** \tAgent '{_entity_dict['name']}' successfully imported.")
                        result["agents"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.agents = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Assistants")
            logging.info(f"*** IMPORT ***")
            result["assistants"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.assistants and "assistants" in decrypted_data:
                _entity_array = decrypted_data["assistants"]

                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if AssistantModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(
                            f"*** IMPORT *** Assistant '{_entity_dict['name']}' already exists. SKIPPED")
                        result["assistants"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Assistant '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_entity_dict["tags"])

                        _persisted_entity = AssistantModel(id=_entity_dict["id"], name=_entity_dict["name"],
                                                       description=_entity_dict["description"],
                                                       custom_system_instruction=_entity_dict["customSystemInstruction"],
                                                       greeting_message=_entity_dict["greetingMessage"],
                                                       image=_entity_dict["image"],
                                                       icon=_entity_dict["icon"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(
                                AssistantTagRelationModel(tag_id=_tag.get_id(),
                                                      assistant_id=_entity_dict['id']))

                        for _system_instruction_id in _entity_dict["systemInstructionIds"]:
                            _persisted_entity.system_instructions.append(
                                AssistantSystemInstructionRelationModel(system_instruction_id=_system_instruction_id,
                                                                    assistant_id=_entity_dict["id"]))

                        for _llm_id in _entity_dict["llmIds"]:
                            _persisted_entity.llms.append(
                                AssistantModuleRelationModel(module_id=_llm_id,
                                                                assistant_id=_entity_dict["id"]))

                        for _ds_id in _entity_dict["dataSourceIds"]:
                            _persisted_entity.data_sources.append(
                                AssistantDataSourceRelationModel(data_source_id=_ds_id,
                                                             assistant_id=_entity_dict["id"]))

                        for _attachment_storage in _entity_dict["attachmentStorages"]:
                            if _attachment_storage["type"] == DocumentType.VIDEO.value:
                                _persisted_entity.video_attachment_storage_id = _attachment_storage["fileStorageId"]
                            elif _attachment_storage["type"] == DocumentType.IMAGE.value:
                                _persisted_entity.image_attachment_storage_id = _attachment_storage["fileStorageId"]
                            elif _attachment_storage["type"] == DocumentType.TEXT.value:
                                _persisted_entity.text_attachment_storage_id = _attachment_storage["fileStorageId"]
                            elif _attachment_storage["type"] == DocumentType.AUDIO.value:
                                _persisted_entity.audio_attachment_storage_id = _attachment_storage["fileStorageId"]

                        database.session.add(_persisted_entity)
                        database.session.commit()

                        for _sample_question_content in _entity_dict["sampleQuestions"]:
                            database.session.add(AssistantSampleQuestionModel(content=_sample_question_content, assistant_id=_entity_dict["id"]))
                        database.session.commit()

                        logging.info(
                            f"*** IMPORT *** \tAssistant '{_entity_dict['name']}' successfully imported.")
                        result["assistants"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.assistants = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Agent Workflows")
            logging.info(f"*** IMPORT ***")
            result["agentWorkflows"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.agentWorkflows and "agentWorkflows" in decrypted_data:
                _entity_array = decrypted_data["agentWorkflows"]

                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if AgentWorkflowModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(
                            f"*** IMPORT *** Agent Workflow '{_entity_dict['name']}' already exists. SKIPPED")
                        result["agentWorkflows"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Agent Workflow '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_entity_dict["tags"])

                        _persisted_entity = AgentWorkflowModel(id=_entity_dict["id"], name=_entity_dict["name"],
                                                           description=_entity_dict["description"],
                                                           first_receiver_type=AgentWorkflowRootAgentType.from_value(_entity_dict["rootAgent"]["type"]) if _entity_dict["rootAgent"] else None,
                                                           first_receiver_id=_entity_dict[
                                                               "rootAgent"]["id"] if _entity_dict["rootAgent"] else None,
                                                           image=_entity_dict["image"],
                                                           icon=_entity_dict["icon"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(
                                AgentWorkflowTagRelationModel(tag_id=_tag.get_id(),
                                                          agent_workflow_id=_entity_dict['id']))

                        for _agent in _entity_dict["agents"]:
                            if _agent["type"] == AgentWorkflowAgentType.DATA_SOURCE.value:
                                _persisted_entity.data_source_relations.append(
                                    AgentWorkflowDataSourceRelationModel(data_source_id=_agent["id"],
                                                                         agent_workflow_id=_entity_dict["id"]))
                            elif _agent["type"] == AgentWorkflowAgentType.ASSISTANT.value:
                                _persisted_entity.assistant_relations.append(
                                    AgentWorkflowAssistantRelationModel(assistant_id=_agent["id"],
                                                                         agent_workflow_id=_entity_dict["id"]))
                            elif _agent["type"] == AgentWorkflowAgentType.AGENT.value:
                                _persisted_entity.agent_relations.append(
                                    AgentWorkflowAgentRelationModel(agent_id=_agent["id"],
                                                                         agent_workflow_id=_entity_dict["id"]))

                            if not _agent["canHandOffTo"]:
                                # Empty set? Then we add a relation without to entity
                                _persisted_entity.handoff_relations.append(
                                    AgentWorkflowHandoffRelationModel(agent_workflow_id=_entity_dict["id"],
                                                                      from_type=AgentWorkflowAgentType.from_value(_agent["type"]),
                                                                      from_id=_agent["id"],
                                                                      to_type=None,
                                                                      to_id=None
                                                                      ))
                            else:
                                for _handoff in _agent["canHandOffTo"]:
                                    _handoff_to_agent_id = _handoff['id']
                                    _handoff_to_agent_type = AgentWorkflowAgentType.from_value(_handoff['type'])
                                    _persisted_entity.handoff_relations.append(
                                        AgentWorkflowHandoffRelationModel(agent_workflow_id=_entity_dict["id"],
                                                                          from_type=AgentWorkflowAgentType.from_value(_agent["type"]),
                                                                          from_id=_agent["id"],
                                                                          to_type=_handoff_to_agent_type,
                                                                          to_id=_handoff_to_agent_id
                                                                          ))

                            for _attachment_storage in _entity_dict["attachmentStorages"]:
                                if _attachment_storage["type"] == DocumentType.VIDEO.value:
                                    _persisted_entity.video_attachment_storage_id = _attachment_storage["fileStorageId"]
                                elif _attachment_storage["type"] == DocumentType.IMAGE.value:
                                    _persisted_entity.image_attachment_storage_id = _attachment_storage["fileStorageId"]
                                elif _attachment_storage["type"] == DocumentType.TEXT.value:
                                    _persisted_entity.text_attachment_storage_id = _attachment_storage["fileStorageId"]
                                elif _attachment_storage["type"] == DocumentType.AUDIO.value:
                                    _persisted_entity.audio_attachment_storage_id = _attachment_storage["fileStorageId"]

                        database.session.add(_persisted_entity)
                        database.session.commit()

                        logging.info(
                            f"*** IMPORT *** \tAgent workflow '{_entity_dict['name']}' successfully imported.")
                        result["agentWorkflows"]["imported"] += 1
            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.agentWorkflows = false or no data to import.")

            logging.info(f"*** IMPORT ***")
            logging.info(f"*** IMPORT *** Workspaces")
            logging.info(f"*** IMPORT ***")
            result["workspaces"] = {
                "skipped": 0,
                "imported": 0,
            }
            if configuration.workspaces and "workspaces" in decrypted_data:
                _entity_array = decrypted_data["workspaces"]

                for _entity_dict in _entity_array:
                    # Check if module id already exists
                    if WorkspaceModel.query.filter_by(id=_entity_dict["id"]).first():
                        logging.info(
                            f"*** IMPORT *** Workspace '{_entity_dict['name']}' already exists. SKIPPED")
                        result["workspaces"]["skipped"] += 1
                    else:
                        # Create or Update (update not yet supported)
                        logging.info(
                            f"*** IMPORT *** Workspace '{_entity_dict['name']}' with old id {_entity_dict['id']}.")
                        _shallow_tags = assert_tag_existence(_entity_dict["tags"])

                        _persisted_entity = WorkspaceModel(id=_entity_dict["id"], name=_entity_dict["name"],
                                                               description=_entity_dict["description"],
                                                               image=_entity_dict["image"],
                                                               icon=_entity_dict["icon"],
                                                               filtered_on_tags=_entity_dict["filteredOnTags"])
                        for _tag in _shallow_tags:
                            _persisted_entity.tag_relations.append(
                                WorkspaceTagRelationModel(tag_id=_tag.get_id(),
                                                              workspace_id=_entity_dict['id']))

                        database.session.add(_persisted_entity)
                        database.session.commit()

                        logging.info(
                            f"*** IMPORT *** \tWorkspace '{_entity_dict['name']}' successfully imported.")
                        result["workspaces"]["imported"] += 1

                    if "workspaceAgentWorkflowRelations" in decrypted_data:
                        for _relation_dict in decrypted_data["workspaceAgentWorkflowRelations"]:
                            if (WorkspaceAgentWorkflowRelationModel.query
                                    .filter(
                                        WorkspaceAgentWorkflowRelationModel.workspace_id == _relation_dict["workspaceId"],
                                        WorkspaceAgentWorkflowRelationModel.agent_workflow_id == _relation_dict["agentWorkflowId"]
                                    ).first()):
                                logging.info(
                                    f"*** IMPORT *** Workspace (AgentWorkflow Relation) to '{_relation_dict['agentWorkflowId']}' already exists. SKIPPED")
                            else:
                                # Create or Update (update not yet supported)
                                logging.info(
                                    f"*** IMPORT *** Workspace (AgentWorkflow Relation) to '{_relation_dict['agentWorkflowId']}' with old ids.")
                                _persisted_entity = WorkspaceAgentWorkflowRelationModel(workspace_id =_relation_dict["workspaceId"],
                                                                                        agent_workflow_id=_relation_dict["agentWorkflowId"])
                                database.session.add(_persisted_entity)
                                database.session.commit()

                                logging.info(
                                    f"*** IMPORT *** \tWorkspace (AgentWorkflow Relation) to '{_relation_dict['agentWorkflowId']}' successfully imported.")

                        if "workspaceAgentRelations" in decrypted_data:
                            for _relation_dict in decrypted_data["workspaceAgentRelations"]:
                                if (WorkspaceAgentRelationModel.query
                                        .filter(
                                    WorkspaceAgentRelationModel.workspace_id == _relation_dict["workspaceId"],
                                    WorkspaceAgentRelationModel.agent_id == _relation_dict["agentId"]
                                ).first()):
                                    logging.info(
                                        f"*** IMPORT *** Workspace (Agent Relation) to '{_relation_dict['agentId']}' already exists. SKIPPED")
                                else:
                                    # Create or Update (update not yet supported)
                                    logging.info(
                                        f"*** IMPORT *** Workspace (Agent Relation) to '{_relation_dict['agentId']}' with old ids.")
                                    _persisted_entity = WorkspaceAgentRelationModel(
                                        workspace_id=_relation_dict["workspaceId"],
                                        agent_id=_relation_dict["agentId"])
                                    database.session.add(_persisted_entity)
                                    database.session.commit()

                                    logging.info(
                                        f"*** IMPORT *** \tWorkspace (Agent Relation) to '{_relation_dict['agentId']}' successfully imported.")

                        if "workspaceSystemInstructionRelations" in decrypted_data:
                            for _relation_dict in decrypted_data["workspaceSystemInstructionRelations"]:
                                if (WorkspaceSystemInstructionRelationModel.query
                                        .filter(
                                    WorkspaceSystemInstructionRelationModel.workspace_id == _relation_dict["workspaceId"],
                                    WorkspaceSystemInstructionRelationModel.system_instruction_id == _relation_dict["systemInstructionId"]
                                ).first()):
                                    logging.info(
                                        f"*** IMPORT *** Workspace (SystemInstruction Relation) to '{_relation_dict['systemInstructionId']}' already exists. SKIPPED")
                                else:
                                    # Create or Update (update not yet supported)
                                    logging.info(
                                        f"*** IMPORT *** Workspace (SystemInstruction Relation) to '{_relation_dict['systemInstructionId']}' with old ids.")
                                    _persisted_entity = WorkspaceSystemInstructionRelationModel(
                                        workspace_id=_relation_dict["workspaceId"],
                                        system_instruction_id=_relation_dict["systemInstructionId"])
                                    database.session.add(_persisted_entity)
                                    database.session.commit()

                                    logging.info(
                                        f"*** IMPORT *** \tWorkspace (SystemInstruction Relation) to '{_relation_dict['systemInstructionId']}' successfully imported.")

                        if "workspaceAssistantRelations" in decrypted_data:
                            for _relation_dict in decrypted_data["workspaceAssistantRelations"]:
                                if (WorkspaceAssistantRelationModel.query
                                        .filter(
                                    WorkspaceAssistantRelationModel.workspace_id == _relation_dict["workspaceId"],
                                    WorkspaceAssistantRelationModel.assistant_id == _relation_dict["assistantId"]
                                ).first()):
                                    logging.info(
                                        f"*** IMPORT *** Workspace (Assistant Relation) to '{_relation_dict['assistantId']}' already exists. SKIPPED")
                                else:
                                    # Create or Update (update not yet supported)
                                    logging.info(
                                        f"*** IMPORT *** Workspace (Assistant Relation) to '{_relation_dict['assistantId']}' with old ids.")
                                    _persisted_entity = WorkspaceAssistantRelationModel(
                                        workspace_id=_relation_dict["workspaceId"],
                                        assistant_id=_relation_dict["assistantId"])
                                    database.session.add(_persisted_entity)
                                    database.session.commit()

                                    logging.info(
                                        f"*** IMPORT *** \tWorkspace (Assistant Relation) to '{_relation_dict['assistantId']}' successfully imported.")

            else:
                logging.info(f"*** IMPORT *** Skipping because configuration.workspaces = false or no data to import.")

            return jsonify(result)
        except Exception as e:
            return ns.abort(500, str(e))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/info/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class SystemInfoEndpoint(Resource):
    @ns.doc(description="Retrieve system info.")
    @ns.response(200, 'Success')
    @ns.response(400, 'Bad request')
    @propagate_principal()
    def get(self):
        eqty_version = get_eqty_version()
        return jsonify({
            "eqty": { "version": eqty_version } if eqty_version else "Not Installed.",
            "user_version": os.getenv("USER_VERSION") if os.getenv("USER_VERSION") else "Not available.",
            "backend_commit": os.getenv("BACKEND_COMMIT") if os.getenv("BACKEND_COMMIT") else "Not available.",
            "backend_deployment_datetime": os.getenv("BACKEND_DEPLOYMENT_DATETIME") if os.getenv("BACKEND_DEPLOYMENT_DATETIME") else "Not available.",
            "backend_build_number": os.getenv("BACKEND_BUILD_NUMBER") if os.getenv("BACKEND_BUILD_NUMBER") else "Not available.",
            "backend_build_datetime": os.getenv("BACKEND_BUILD_DATETIME") if os.getenv("BACKEND_BUILD_DATETIME") else "Not available.",
        })

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200
