import json
import logging
from typing import Optional

from flask import request, jsonify, Response
from flask_restx import Namespace, Resource, fields
from sqlalchemy import and_, select
from sqlalchemy.orm import Session
from werkzeug.exceptions import SecurityError
from datetime import datetime

from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model, tagged_model, \
    with_favorite, favorible_model, fetch_with_permissions, with_access_permission, \
    get_user_access_for, with_hidden, get_named_lock
from maxgpt.services import database
from maxgpt.services.database_model import SystemInstructionModel, UserFavoriteModel, FavoriteSubject, PermissionType, \
    AgentModel, AgentWorkflowModel, \
    AgentTagRelationModel, AgentSystemInstructionRelationModel, ModuleModel, AgentModuleRelation, AccessPermissionModel, \
    AccessPermissionSubject, AccessPermissionAssigneeType, UserHiddenEntityModel, HiddenEntitySubject
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.eqty.util import is_eqty_enabled

ns = Namespace('Agent',
               description='Agents used in agentic workflows.',
               path='/agent')


agent_model = ns.inherit('Agent', audited_model(ns), tagged_model(ns), favorible_model(ns), {
    'id': fields.String(description="The UUID of the agent.", required=True, readonly=True),
    'name': fields.String(description="The name of the agent.", max_length=100, required=True),
    'description': fields.String(description="A verbose description of the agent and it's capabilities. This is crucial meta information for orchestrators to decide which agent to use for a certain task.", max_length=2000, required=True),

    'systemInstructionIds': fields.List(fields.String(description="The UUIDs of system instructions linked to this agent."), required=False, example=["<system_instruction_id>"]),
    'customSystemInstruction': fields.String(
        description="A user-specific extension to the pre-defined and selected system prompt.", max_length=2000,
        required=False),

    'llmId': fields.String(description="The UUIDs of the language model used by the agent.", required=True),
    'functionToolIds': fields.List(fields.String(description="The UUIDs modules of type FUNCTION_TOOL that enrich the agent capabilities with predefined tool functions."), required=False, example=["<module_id>"]),

    'icon': fields.String(description="A base64 encoded image to show as icon for this assistant.", required=False),
    'image': fields.String(description="A base64 encoded image to show in the assistant tile.", required=False)
})

def get_agent(agent_id: str, permission: PermissionType, include_deleted: bool = False):
    """
    Retrieves an agent by its ID and checks if the current user has access to it.

    Args:
        agent_id (str): The ID of the agent to retrieve.
        permission (PermissionType): The permission type to check.
        include_deleted (str): Whether to include deleted agents.
    """
    query = AgentModel.query.filter(AgentModel.id == agent_id)
    
    # Only apply deleted filter if includeDeleted is not true
    if not include_deleted:
        query = query.filter(AgentModel.deleted_at.is_(None))

    _agent: Optional[AgentModel] = query.first()

    if _agent is None:
        ns.abort(404, f'An agent with identifier "{agent_id}" does not exist')

    grant = get_user_access_for(_agent)
    if PermissionType.rank(grant) < PermissionType.rank(permission):
        operation = 'read' if permission == PermissionType.READ else 'write'
        ns.abort(401,
                f"Not authorized. You do not have permission to {operation} agent with identifier '{agent_id}'")
                    
    return _agent, grant


# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AgentsEndpoint(Resource):
    @ns.doc("list_agents")
    @ns.param('isDeleted', 'Set to true to get soft-deleted agents', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden agents, false for only unhidden', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available agents that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == 'true':
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_agents = AgentModel.query.filter(
                AgentModel.deleted_at.isnot(None),
                AgentModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([agent.to_dict() for agent in soft_deleted_agents])
            
        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        
        # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            enhanced_agents = fetch_with_permissions(AgentModel, hidden_ids)
        elif hidden_param == 'false':
            enhanced_agents = fetch_with_permissions(
                AgentModel,
                ids=hidden_ids,
                exclude=True   
            )
        else:
            enhanced_agents = fetch_with_permissions(AgentModel)

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )
        subject_ids = set(database.session.scalars(stmt))
        
        return jsonify([with_hidden(with_favorite(with_access_permission(_agent.to_dict(), _agent.permission), subject_ids), hidden_ids)
                        for _agent in enhanced_agents])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AgentFactoryEndpoint(Resource):
    @ns.expect(agent_model)
    @ns.doc("create_agent")
    @ns.response(200, 'Success', agent_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new agent."""
        _data = request.get_json()
        _custom_system_instruction = _data.get('customSystemInstruction')
        _llm_id = _data.get('llmId')

        _agent = AgentModel(name=_data.get('name'),
                                    description=_data.get('description'), llm_id=_llm_id)

        if _custom_system_instruction:
            _agent.custom_system_instruction = _custom_system_instruction

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _agent.tag_relations.append(
                    AgentTagRelationModel(agent_id=_agent.id, tag_id=_shallow_tag['id']))

        if _data.get('systemInstructionIds') is not None:
            for _system_instruction_id in _data['systemInstructionIds']:
                _system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(_system_instruction_id)
                _agent.system_instructions.append(
                    AgentSystemInstructionRelationModel(agent_id=_agent.id, system_instruction_id=_system_instruction.id))

        if _data.get('functionToolIds') is not None:
            for _function_tool_id in _data['functionToolIds']:
                _function_tool: Optional[ModuleModel] = ModuleModel.query.get_or_404(_function_tool_id)
                _agent.function_tools.append(
                    AgentModuleRelation(agent_id=_agent.id, module_id=_function_tool.id))

        _image = _data.get('image')
        if _image:
            _agent.image = _image

        _icon = _data.get('icon')
        if _icon:
            _agent.icon = _icon

        database.session.add(_agent)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )

        subject_ids = set(database.session.scalars(stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_agent.to_dict(), subject_ids), set([])), PermissionType.WRITE))


    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class AgentEndpoint(Resource):
    @ns.doc("read_agent ")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted agents', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.Nested(agent_model))
    @ns.response(404, 'Agent not found')
    @requires_database_session
    @propagate_principal()
    def get(self, agent_id: str):
        """Returns an agent for the given id."""
        _agent, grant = get_agent(agent_id, PermissionType.READ, request.args.get('includeDeleted', 'false').lower() == 'true')
        current_user = SessionContext.get_current_user()
        
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )

        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify(with_hidden(with_access_permission(with_favorite(_agent.to_dict(), subject_ids), grant), hidden_ids))

    @ns.doc("update_agent")
    @ns.expect(agent_model)
    @ns.response(200, 'Success', agent_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The agent does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, agent_id: str):
        """Updates an existing agent."""
        _data = request.get_json()
        _agent, grant = get_agent(agent_id, PermissionType.WRITE)

        # Mandatory fields
        _agent.name = _data['name'] if 'name' in _data else _agent.name
        _agent.description = _data['description'] if 'description' in _data else _agent.description
        _agent.llm_id = _data['llmId'] if 'llmId' in _data else _agent.llm_id

        session = Session.object_session(_agent)

        # Optional update fields
        _agent.image = _data['image'] if 'image' in _data else _agent.image
        _agent.icon = _data['icon'] if 'icon' in _data else _agent.icon
        if _data.get('tags') is not None:
            for tag_relation in _agent.tag_relations:
                session.delete(tag_relation)
            _agent.tag_relations = []
            for _shallow_tag in _data['tags']:
                _agent.tag_relations.append(
                    AgentTagRelationModel(agent_id=_agent.id, tag_id=_shallow_tag['id']))

        if _data.get('systemInstructionIds') is not None:
            for system_instruction_relation in _agent.system_instructions:
                session.delete(system_instruction_relation)
            _agent.system_instructions = []
            for _system_instruction_id in _data['systemInstructionIds']:
                _system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(_system_instruction_id)
                _agent.system_instructions.append(
                    AgentSystemInstructionRelationModel(agent_id=_agent.id, system_instruction_id=_system_instruction.id))

        if _data.get('functionToolIds') is not None:
            for _function_tool_relation in _agent.function_tools:
                session.delete(_function_tool_relation)
            _agent.function_tools = []
            for _function_tool_id in _data['functionToolIds']:
                _function_tool: Optional[ModuleModel] = ModuleModel.query.get_or_404(_function_tool_id)
                _agent.function_tools.append(
                    AgentModuleRelation(agent_id=_agent.id, module_id=_function_tool.id))


        _agent.custom_system_instruction = _data[
            'customSystemInstruction'] if 'customSystemInstruction' in _data else _agent.custom_system_instructio

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT)
        )

        subject_ids = set(database.session.scalars(stmt))

        # Get hidden entities for current user
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(with_hidden(with_access_permission(with_favorite(_agent.to_dict(), subject_ids), grant), hidden_ids))

    @ns.doc("delete_agent")
    @ns.param('hardDelete', 'Set to true to hard delete the utility agent', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', agent_model)
    @ns.response(404, 'The agent does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, agent_id: str):
        """Deletes an existing agent."""
        _agent, grant = get_agent(agent_id, PermissionType.WRITE)

        """Check if the agent is a root in AgentWorkflow"""
        _agent_workflow: AgentWorkflowModel = AgentWorkflowModel.query.filter(
            AgentWorkflowModel.first_receiver_id == agent_id,
            AgentWorkflowModel.deleted_at.is_(None)
        ).first()

        if _agent_workflow is not None:
            ns.abort(400,
                     f"Cannot delete an agent with identifier '{agent_id}' because it is used as root agent inside one or more agent workflows.")

        agent_dict = _agent.to_dict()
        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.AGENT,
                UserFavoriteModel.subject_id == _agent.id
            )
        ).delete()

        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT,
                UserHiddenEntityModel.subject_id == _agent.id
            )
        ).delete()

        #This check will preserve the original functionality of DELETE API and can be used from swagger using query parameter
        #The UI will always call this API without query parameter,so default functionality will be soft delete 
        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == 'true':
            logging.log(logging.INFO, f"Hard delete the utility agent:{agent_id}")
            database.session.delete(_agent)
        else:
            logging.log(logging.INFO, f"Soft delete the utility agent:{agent_id}")
            _agent.deleted_at = datetime.now()
            _agent.deleted_by = SessionContext().get_current_user().get_id()
            
        database.session.commit()


        # attach favorite information
        subject_ids = set([])   
        return jsonify(with_hidden(with_access_permission(with_favorite(agent_dict, subject_ids), grant), subject_ids))

    @ns.doc(False)
    def options(self, agent_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AgentGrantsEndpoint(Resource):
    @ns.doc(description="Get agent grant")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'Agent not found')
    @requires_database_session
    @propagate_principal()
    def get(self, agent_id: str):
        _agent, grant = get_agent(agent_id, PermissionType.READ)

        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, agent_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AgentGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_agent_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Agent not found')
    @requires_database_session
    @propagate_principal()
    def post(self, agent_id: str):
        _ = get_agent(agent_id, PermissionType.WRITE)

        _data = request.get_json()
        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.AGENT,
                                               subject_id=agent_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, agent_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['PUT', 'DELETE', 'OPTIONS'])
class AgentGrantEndpoint(Resource):
    @ns.doc(description="update_agent_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Agent not found')
    @requires_database_session
    @propagate_principal()
    def put(self, agent_id: str, assignee_type: str, assignee_id: str):
        _agent, _ = get_agent(agent_id, PermissionType.WRITE)

        _data = request.get_json()
        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid access level')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )

        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for agent '{_agent.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for agent {agent_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_agent_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Agent not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, agent_id: str, assignee_type: str, assignee_id: str):
        _agent, _ = get_agent(agent_id, PermissionType.WRITE)

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for agent '{_agent.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant delete request for agent {agent_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, agent_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    

@ns.route('/<agent_id>/restore')
class RestoreAgentEndpoint(Resource):
    @ns.doc(description="restore_deleted_agent")
    @ns.response(200, 'Agent restored successfully', model=agent_model)
    @ns.response(404, 'The agent does not exist or is not deleted')
    @requires_database_session
    @propagate_principal()
    def patch(self, agent_id: str):
        """Restores a soft-deleted agent."""
        current_user = SessionContext.get_current_user()
        _agent: AgentModel = AgentModel.query.get(agent_id)
       
        if _agent is None or _agent.deleted_at is None:
            ns.abort(404, f"Agent with identifier '{agent_id}' is not deleted or does not exist")
        # Check if the current user is the creator of the agent   
        if _agent.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this agent")

        _agent.deleted_at = None
        _agent.deleted_by = None  

        database.session.commit()
        return jsonify(_agent.to_dict())

    @ns.doc(False)
    def options(self, agent_id: str):
        """Handle preflight OPTIONS request."""
        return '', 200


if is_eqty_enabled():
    
    from maxgpt.services.eqty.util import generate_manifest_and_purge
    from maxgpt.services.eqty.lineage import build_agent_lineage
    from maxgpt.services.database_model import AssistantGovernanceModel
    from maxgpt.api.impl.governance import DEFAULT_GOVERNANCE_CONFIGURATION, DEFAULT_GOVERNANCE_STATUS

    OVERRIDE_GOVERNANCE_CONFIGURATION = {
        'type': 'agent',
    }


    @ns.route('/<agent_id>/lineage/exists', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentLineageExistsEndpoint(Resource):
        @ns.doc(description="Retrieve whether lineage information exists for an agent.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_id: str):
            _ = get_agent(agent_id, PermissionType.READ)
            return jsonify(True)
            
        @ns.doc(False)
        def options(self, agent_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    @ns.route('/<agent_id>/lineage/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentLineageEndpoint(Resource):
        @ns.doc(description="Retrieve lineage information for an agent.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_id: str):
            _agent, _ = get_agent(agent_id, PermissionType.READ)

            # Replicating the process to construct an agent
            # single-threaded because the EQTY SDK isn't threadsafe
            with (get_named_lock("EQTY")):
                _ = build_agent_lineage(_agent)
                manifest = generate_manifest_and_purge()
                
            return jsonify(manifest)

        @ns.doc(False)
        def options(self, agent_id: str):
            # Handle preflight OPTIONS request
            return '', 200
        

    @ns.route('/<agent_id>/governance/configuration', strict_slashes=False, methods=['GET', 'PUT', 'OPTIONS'])
    class AgentGovernanceConfigurationEndpoint(Resource):
        @ns.doc(description="Retrieve the configuration for an agent.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_id: str):
            _ = get_agent(agent_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.agent_id == agent_id).first()
            configuration = _governance.configuration if _governance else json.dumps(DEFAULT_GOVERNANCE_CONFIGURATION | OVERRIDE_GOVERNANCE_CONFIGURATION)
            return Response(configuration, mimetype='application/json')
            
            
        @ns.doc(description="Update the configuration for an agent.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent does not exist')
        @requires_database_session
        @propagate_principal()
        def put(self, agent_id: str):
            _ = get_agent(agent_id, PermissionType.WRITE)
            _data = request.get_json()
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.agent_id == agent_id).first()
            if _governance is None:
                _governance = AssistantGovernanceModel(
                    agent_id = agent_id,
                    configuration = "{}",
                    status = json.dumps(DEFAULT_GOVERNANCE_STATUS),
                )
                database.session.add(_governance)

            _governance.configuration = json.dumps({
                    **DEFAULT_GOVERNANCE_CONFIGURATION, 
                    **json.loads(_governance.configuration),
                    **_data, 
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                })
            # Reset the governance status to default when the configuration is updated.
            _governance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)
            
            database.session.commit()
            return Response(_governance.configuration, mimetype='application/json')


        @ns.doc(False)
        def options(self, agent_id: str):
            # Handle preflight OPTIONS request
            return '', 200
        

    @ns.route('/<agent_id>/governance/status', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentGovernanceStatusEndpoint(Resource):
        @ns.doc(description="Retrieve the governance status for an agent.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_id: str):
            _ = get_agent(agent_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.agent_id == agent_id).first()
            return Response(
                _governance.status if _governance else json.dumps(DEFAULT_GOVERNANCE_STATUS), 
                mimetype='application/json'
            )

        @ns.doc(False)
        def options(self, agent_id: str):
            # Handle preflight OPTIONS request
            return '', 200
