import logging
import os
from typing import Union, cast

import requests
from flask import send_file, Response, jsonify
from flask_restx import Namespace, Resource

from maxgpt.api.internal.utils import propagate_principal, requires_database_session, get_user_access_for
from maxgpt.modules import ModuleRegistry
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
from maxgpt.services.database_model import DataObjectModel, IngestProcessModel, DataSourceModel, PermissionType

ns = Namespace('Data Object',
               description='Operations to read Data Objects if you are allowed to', path="/data-object")


@ns.route('/<data_object_id>/', strict_slashes=False, methods=['GET'])
class DataObjectEndpoint(Resource):
    @ns.doc(description="Read Data Objects if you are allowed to.")
    @requires_database_session
    @propagate_principal()
    def get(self, data_object_id):
        _data_object: DataObjectModel = DataObjectModel.query.get(data_object_id)

        if not _data_object:
            ns.abort(404, 'A data object with the provided id does not exist')

        # We use try to use the original file storage to which the data object has been loaded
        # initially. We fetch this information via the data source relations
        _process = IngestProcessModel.query.get(_data_object.ingest_process_id)
        if _process is not None:
            _original_data_source = DataSourceModel.query.get(_process.data_source_id)
            grant = get_user_access_for(_original_data_source)
            if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
                ns.abort(401,
                         f"Not authorized. You do not have permission to read this file")

        return  jsonify(_data_object.to_dict())



@ns.route('/<data_object_id>/content/', strict_slashes=False, methods=['GET'])
class DataObjectContentEndpoint(Resource):
    @ns.doc(description="Read Data Objects if you are allowed to.")
    @requires_database_session
    @propagate_principal()
    def get(self, data_object_id):

        _data_object = DataObjectModel.query.get(data_object_id)

        if not _data_object:
            ns.abort(404, 'A data object with the provided id does not exist')

        try:
            # We use try to use the original file storage to which the data object has been loaded
            # initially. We fetch this information via the data source relations
            _process = IngestProcessModel.query.get(_data_object.ingest_process_id)
            _data_bytes: Union[bytes, None] = None
            _original_file_storage: Union[AbstractFileStorage, None] = None
            if _process is not None:
                _original_data_source = DataSourceModel.query.get(_process.data_source_id)

                grant = get_user_access_for(_original_data_source)
                if PermissionType.rank(grant) < PermissionType.rank(PermissionType.READ):
                    ns.abort(401,
                             f"Not authorized. You do not have permission to read this file")

                _original_file_storage = cast(AbstractFileStorage, ModuleRegistry.get_module(_original_data_source.file_storage_id))
                logging.log(logging.DEBUG,
                            f"Trying to read {_original_data_source.id + os.path.sep + _data_object.file_name} from data source {_original_file_storage.get_name()}")
                _data_bytes = _original_file_storage.read(_original_data_source.id + os.path.sep + _data_object.file_name)

            if _data_bytes and _original_file_storage:
                try:
                    return Response(
                        _data_bytes,
                        content_type=_data_object.mime_type if _data_object.mime_type else 'application/octet-stream',
                        headers={
                            "Content-Disposition": f"attachment; filename={_data_object.file_name}"
                        }
                    )
                except Exception as e:
                    logging.log(logging.ERROR, e)
                    # Continue with next approach

            # Now we check if we can use the stored URL to directly access the data_object either remotely or locally
            if _data_object.url.startswith('http'):
                logging.log(logging.DEBUG,
                            f"Trying to read {_data_object.file_name} from URL {_data_object.url}")
                # We have to fetch the remote content first and forward it to the caller
                response = requests.get(_data_object.url, stream=True)
                if response.status_code == 200:
                    return Response (
                        response.iter_content(chunk_size=8192),
                        content_type=_data_object.mime_type if _data_object.mime_type else 'application/octet-stream',
                        headers={
                            "Content-Disposition": f"attachment; filename={_data_object.file_name}"
                        }
                    )
            else:
                logging.log(logging.DEBUG,
                            f"Trying to read {_data_object.file_name} from local FS at ./{_data_object.url}")
                # Open the file in binary mode and return it as a response
                # We expect the file to be present on the local file system in this case
                return send_file(
                    _data_object.url,
                    as_attachment=True,
                    download_name=_data_object.file_name,  # Set the download filename
                    mimetype=_data_object.mime_type if _data_object.mime_type else 'application/octet-stream' # Second layer of defaulting
                )
        except Exception as e:
            logging.log(logging.ERROR, e)
            ns.abort(500, e)

    @ns.doc(False)
    def options(self, data_object_id):
        # Handle preflight OPTIONS request
        return '', 200
