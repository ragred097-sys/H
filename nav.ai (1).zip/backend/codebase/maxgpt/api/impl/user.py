import json

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.services import database
from maxgpt.services.data_model.user import UserModel
from maxgpt.services.database_model import UserSettingModel, PreferenceModel, PreferenceScope, UserRatingModel, \
    UserFavoriteModel, FavoriteSubject, UserApplicationAccessRoleRelationModel, UserHiddenEntityModel, HiddenEntitySubject
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('Users',
               description='Read user meta data',
               path='/user')

user_model = ns.model('User', {
    'id': fields.String(description="The UUID of the user.", required=True, readonly=True),
    'accountId': fields.String(description="The external id of a user.", required=False, readonly=True),
    'name': fields.String(description="The name of a user to show in the UYI", required=False),
    'email': fields.String(description="The email of a user if existing", required=False, readonly=True),
    'createdAt': fields.DateTime(description="The timestamp when the conversation was created", required=True,
                                 readonly=True),
})

user_setting_model = ns.model('UserSetting', {
    'userId': fields.String(description="The UUID of the user.", required=True, readonly=True),
    'preferenceId': fields.String(description="The UUID of the user preference.", required=True, readonly=True),
    'value': fields.String(description="The value as string (!) of the preference for that user. "
                                       "Type conversion must be done on client side", required=True),
})

user_favorite_model = ns.model('UserFavorite', {
    'userId': fields.String(description="The UUID of the user.", required=True, readonly=True),
    'subjectType': fields.String(description="The subject type.", required=True),
    'subjectId': fields.String(description="The subject identifier. ", required=True),
    'createdAt': fields.DateTime(description="The timestamp when the conversation was created", required=True,
                                 readonly=True),
})

access_role_model = ns.model('AccessRole', {
    'id': fields.String(description="The UUID of the access role.", required=True, readonly=True),
    'name': fields.String(description="The name of the access role.", required=True),
    'description': fields.String(description="The description of the access role.", required=False),
})

user_hidden_entity_model = ns.model('UserHiddenEntity', {
    'id': fields.String(description="The UUID of the hidden entity record.", required=True, readonly=True),
    'userId': fields.String(description="The UUID of the user.", required=True, readonly=True),
    'subjectType': fields.String(description="The type of the hidden entity.", required=True, enum=[t.value for t in HiddenEntitySubject]),
    'subjectId': fields.String(description="The ID of the hidden entity.", required=True),
    'createdAt': fields.DateTime(description="The timestamp when the entity was hidden", required=True, readonly=True),
})

# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UsersEndpoint(Resource):
    @ns.doc("list_users")
    @ns.response(200, 'Success', fields.List(fields.Nested(user_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all stored data sources that are accessible for the current user."""
        users = UserModel.query.all()
        return jsonify([user.to_dict() for user in users])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<user_id>/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UserEndpoint(Resource):
    @ns.doc(description="read_user")
    @ns.response(200, 'Success', user_model)
    @ns.response(404, 'User not found')
    @requires_database_session
    @propagate_principal()
    def get(self, user_id: str):
        """Returns the user for the given id if existing and accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()

        _user: UserModel = UserModel.query.get(user_id)

        if _user is None:
            ns.abort(404, f"No user found for identifier '{user_id}'")

        return jsonify(_user.to_dict())

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<user_id>/settings/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UserSettingsEndpoint(Resource):
    @ns.doc(description="list_user_settings")
    @ns.response(200, 'Success', fields.List(fields.Nested(user_setting_model)))
    @ns.response(403, 'Access denied')
    @requires_database_session
    @propagate_principal()
    def get(self, user_id: str):
        """Returns the settings for the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read settings of another user")

        _settings: list[UserSettingModel] = (UserSettingModel.query
                            .filter_by(user_id=user_id).all())

        return jsonify([_setting.to_dict() for _setting in _settings])

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<user_id>/setting/', strict_slashes=False)
class UserSettingFactoryEndpoint(Resource):
    @ns.expect(user_setting_model)
    @ns.doc("create_user_preference")
    @ns.response(200, 'Success', user_setting_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(403, 'Access denied')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self, user_id: str):
        """Creates a new preference the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read settings of another user")
        _data = request.get_json()

        preference: PreferenceModel = PreferenceModel.query.get(_data.get('preferenceId'))
        if preference is None:
            ns.abort(422, f"Preference with identifier '{_data.get('preferenceId')}' does not exist") 
        if preference.scope not in [PreferenceScope.USER, PreferenceScope.GENERAL]:
            ns.abort(422, f"Preference with identifier '{_data.get('preferenceId')}' must have scope '{PreferenceScope.USER.name}', '{PreferenceScope.GENERAL.name}'")


        # TODO: mandatory and type checking
        _user_setting = UserSettingModel(user_id=user_id, preference_id=preference.id,
                                                 value=_data.get('value'), )

        database.session.add(_user_setting)
        database.session.commit()

        return jsonify(_user_setting.to_dict())

    @ns.doc(False)
    def options(self, user_id):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<user_id>/setting/<preference_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
@ns.param('user_id', 'A valid UUID of a user.')
@ns.param('preference_id', 'A valid UUID of a (user) preference.')
class UserSettingEndpoint(Resource):
    @ns.doc(description="read_user_setting")
    @ns.response(200, 'Success', user_setting_model)
    @ns.response(403, 'Access denied')
    @ns.response(404, 'Setting not found')
    @requires_database_session
    @propagate_principal()
    def get(self, user_id: str, preference_id: str):
        """Returns the user setting for the given id."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read settings of another user")

        _user_preference = UserSettingModel.query.get((user_id, preference_id))

        if _user_preference is None:
            ns.abort(404, f"No user setting found for preference with identifier '{preference_id}'")

        return jsonify(_user_preference.to_dict())

    @ns.doc("update_user_setting")
    @ns.expect(user_setting_model)
    @ns.response(200, 'Success', user_setting_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The preference does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, user_id: str, preference_id: str):
        """Updates an existing preference."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read settings of another user")
        _data = request.get_json()

        _user_setting = UserSettingModel.query.get((user_id, preference_id))
        if _user_setting is None:
            ns.abort(404, f"No user setting found for preference with identifier '{preference_id}'")

        # TODO: mandatory and type checking
        _user_setting.value = _data.get('value')

        database.session.commit()

        return jsonify(_user_setting.to_dict())

    @ns.doc("delete_user_setting")
    @ns.response(200, 'Success', user_setting_model)
    @ns.response(404, 'The preference does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, user_id: str, preference_id: str):
        """Delete the user setting for the given preference identifier."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read settings of another user")
        _data = request.get_json()

        _user_setting = UserSettingModel.query.get((user_id, preference_id))
        if _user_setting is None:
            ns.abort(404, f"No user setting found for preference with identifier '{preference_id}'")

        database.session.delete(_user_setting)

        return jsonify(_user_setting.to_dict())

    @ns.doc(False)
    def options(self, user_id: str, preference_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    
    
#########################


@ns.route('/<user_id>/favorites/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UserFavoritesEndpoint(Resource):
    @ns.doc(description="list_user_favorites")
    @ns.response(200, 'Success', fields.List(fields.Nested(user_favorite_model)))
    @ns.response(403, 'Access denied')
    @requires_database_session
    @propagate_principal()
    def get(self, user_id: str):
        """Returns the favorites for the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read favorites of another user")

        _favorites: list[UserFavoriteModel] = (UserFavoriteModel.query
                            .filter_by(user_id=user_id).all())

        return jsonify([_favorite.to_dict() for _favorite in _favorites])

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<user_id>/favorite/', strict_slashes=False, methods=['DELETE', 'POST', 'OPTIONS'])
@ns.param('user_id', 'A valid UUID of a user.', _in="path")
class UserFavoriteEndpoint(Resource):
    @ns.expect(user_favorite_model)
    @ns.doc("create_user_favorite")
    @ns.response(200, 'Success', user_favorite_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(403, 'Access denied')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self, user_id: str):
        """Creates a new preference the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot create favorites of another user")
        _data = request.get_json()

        # TODO: mandatory and type checking
        _user_favorite = UserFavoriteModel(user_id=user_id, subject_type=FavoriteSubject.from_value(_data["subjectType"]), subject_id=_data["subjectId"])

        database.session.add(_user_favorite)
        database.session.commit()

        return jsonify(_user_favorite.to_dict())

    @ns.doc("delete_user_favorite")
    @ns.response(200, 'Success', user_favorite_model)
    @ns.response(404, 'The favorite does not exist')
    @ns.param('subjectType', 'A valid subject_type', _in="query")
    @ns.param('subjectId', 'A valid subject_id', _in="query")
    @requires_database_session
    @propagate_principal()
    def delete(self, user_id: str):
        """Delete the user favorite for the given preference identifier."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot delete favorites of another user")

        _subject_type = request.args.get('subjectType')
        _subject_id = request.args.get('subjectId')

        _user_favorite = UserFavoriteModel.query.get((user_id, FavoriteSubject.from_value(_subject_type), _subject_id))
        if _user_favorite is None:
            ns.abort(404, f"No user favorite found for subject {_subject_type} with identifier '{_subject_id}'")

        database.session.delete(_user_favorite)

        return jsonify(_user_favorite.to_dict())

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<user_id>/hidden-entities/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UserHiddenEntitiesEndpoint(Resource):
    @ns.doc(description="list_user_hidden_entities")
    @ns.response(200, 'Success', fields.List(fields.Nested(user_hidden_entity_model)))
    @ns.response(403, 'Access denied')
    @requires_database_session
    @propagate_principal()
    def get(self, user_id: str):
        """Returns the hidden entities for the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot read hidden entities of another user")

        _hidden_entities: list[UserHiddenEntityModel] = (UserHiddenEntityModel.query
                            .filter_by(user_id=user_id).all())

        return jsonify([_entity.to_dict() for _entity in _hidden_entities])

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200

@ns.route('/<user_id>/hidden-entity/', strict_slashes=False, methods=['POST', 'DELETE', 'OPTIONS'])
@ns.param('user_id', 'A valid UUID of a user.', _in="path")
class UserHiddenEntityEndpoint(Resource):
    @ns.expect(user_hidden_entity_model)
    @ns.doc("create_user_hidden_entity")
    @ns.response(200, 'Success', user_hidden_entity_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(403, 'Access denied')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self, user_id: str):
        """Creates a new hidden entity record for the given user-id if accessible."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot create hidden entities for another user")
        _data = request.get_json()

        # Check if entity is already hidden
        existing = UserHiddenEntityModel.query.filter_by(
            user_id=user_id,
            subject_type=HiddenEntitySubject.from_value(_data["subjectType"]),
            subject_id=_data["subjectId"]
        ).first()
        
        if existing:
            ns.abort(409, f"Entity is already hidden")

        _user_hidden_entity = UserHiddenEntityModel(
            user_id=user_id,
            subject_type=HiddenEntitySubject.from_value(_data["subjectType"]),
            subject_id=_data["subjectId"]
        )

        database.session.add(_user_hidden_entity)
        database.session.commit()

        return jsonify(_user_hidden_entity.to_dict())

    @ns.doc("delete_user_hidden_entity")
    @ns.response(200, 'Success', user_hidden_entity_model)
    @ns.response(404, 'The hidden entity does not exist')
    @ns.param('subjectType', 'A valid subject_type', _in="query")
    @ns.param('subjectId', 'A valid subject_id', _in="query")
    @requires_database_session
    @propagate_principal()
    def delete(self, user_id: str):
        """Delete the hidden entity record for the given subject."""
        current_user = SessionContext.get_current_user()
        if current_user and user_id == "me":
            user_id = current_user.get_id()
        elif current_user is None or current_user.get_id() != user_id:
            ns.abort(403, f"You cannot delete hidden entities of another user")

        _subject_type = request.args.get('subjectType')
        _subject_id = request.args.get('subjectId')

        _user_hidden_entity = UserHiddenEntityModel.query.filter_by(
            user_id=user_id,
            subject_type=HiddenEntitySubject.from_value(_subject_type),
            subject_id=_subject_id
        ).first()

        if _user_hidden_entity is None:
            ns.abort(404, f"No hidden entity found for subject {_subject_type} with identifier '{_subject_id}'")

        database.session.delete(_user_hidden_entity)
        database.session.commit()

        return jsonify(_user_hidden_entity.to_dict())

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200