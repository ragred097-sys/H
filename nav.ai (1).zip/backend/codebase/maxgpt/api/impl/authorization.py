import json

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields

from sqlalchemy.orm import joinedload
from maxgpt.api import EntityType
from maxgpt.api.impl.user import user_model
from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model
from maxgpt.services import database
from maxgpt.services.data_model.authorization import ApplicationAccessRoleModel
from maxgpt.services.database_model import ExternalRoleApplicationAccessRoleMappingModel, \
    UserApplicationAccessRoleRelationModel, PermissionType, AccessPermissionSubject, \
    AccessPermissionAssigneeType

ns = Namespace('Authorization', description='Operations to manage authorization.',
               path='/authorization')

access_role_model = ns.inherit('Access Role', audited_model(ns), {
    'id': fields.String(description="The id of the access role.", required=True, readonly=True),
    'name': fields.String(description="The name of the access role.", max_length=100, required=True),
    'description': fields.String(description="A short summary of the access role.", max_length=500, required=False),
    'system': fields.Boolean(description="A flag indicating the role as system role.", readonly=True, required=False,
                             default=False),
})

external_role_access_role_mapping_model = ns.inherit('External role to Access Role Mapping', audited_model(ns), {
    'id': fields.String(description="The id of the external role to access role mapping.", required=True,
                        readonly=True),
    'externalRoleName': fields.String(description="The name of the external role.", max_length=100, required=True),
    'applicationAccessRole': fields.Nested(access_role_model, description="An access role.", max_length=500,
                                           required=False),
})

user_access_role_mapping_model = ns.inherit('User to Access Role Mapping', audited_model(ns), {
    'id': fields.String(description="The id of the external role to access role mapping.", required=True,
                        readonly=True),
    'user': fields.Nested(user_model, description="An user.", max_length=500, required=False),
    'applicationAccessRole': fields.Nested(access_role_model, description="A short summary of the access role.",
                                           max_length=500, required=False),
})

create_user_access_role_mapping_model = ns.model('Create User to Access Role Mapping', {
    'user': fields.Nested(
        ns.model('User Reference', {
            'id': fields.String(description="The UUID of the user.", required=True)
        }), description="The user to map.", required=True),
    'applicationAccessRole': fields.Nested(
        ns.model('Access Role Reference', {
            'id': fields.String(description="The id of the access role.", required=True)
    }), description="The access role to map.", required=True),
})

access_permission_model = ns.inherit('Access Permission', audited_model(ns), {
    'subjectType': fields.String(description="The type of the subject that has a permission assigned.", max_length=50,
                                 required=True,
                                 enum=[t.name for t in AccessPermissionSubject]),
    'subjectId': fields.String(description="The id of the subject that has a permission assigned.", required=True),
    'assigneeId': fields.String(
        description="The id of the assignee that got a permission assigned to a referenced subject.", required=True),
    'assigneeType': fields.String(
        description="The type of the assignee that got a permission assigned to a referenced subject [USER, ROLE].",
        required=True,
        enum=[EntityType.USER.value, EntityType.ACCESS_ROLE.value]),
    'accessLevel': fields.String(
        description="The access level for the assignee that for his permission on the subject [READ, WRITE, FORBIDDEN].",
        required=True, enum=[t.name for t in PermissionType], default=PermissionType.READ.name),
})

access_permission_for_known_subject_model = ns.inherit(
    'Reduced Access Permission for adding permissions to known subject', audited_model(ns), {
        'assigneeId': fields.String(
            description="The id of the assignee that got a permission assigned to a referenced subject.",
            required=True),
        'assigneeType': fields.String(
            description="The type of the assignee that got a permission assigned to a referenced subject [USER, ROLE].",
            required=True,
            enum=[EntityType.USER.value, EntityType.ACCESS_ROLE.value]),
        'accessLevel': fields.String(
            description="The access level for the assignee that for his permission on the subject [READ, WRITE, FORBIDDEN].",
            required=True,
            enum=[t.name for t in PermissionType], default=PermissionType.READ.name),
    })

access_permission_for_known_subject_and_assignee_model = ns.inherit(
    'Reduced Access Permission for updating access level', audited_model(ns), {
        'accessLevel': fields.String(
            description="The access level for the assignee that for his permission on the subject [READ, WRITE, FORBIDDEN].",
            required=True, enum=[t.name for t in PermissionType], default=PermissionType.READ.name),
    })


@ns.route('/access-roles/', strict_slashes=False)
class AccessRolesEndpoint(Resource):
    @ns.doc(description='Returns all application access roles.')
    @ns.response(200, 'Success', fields.List(fields.Nested(access_role_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns all access roles."""
        _result = ApplicationAccessRoleModel.query.all()
        return jsonify([role.to_dict() for role in _result])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AccessRoleFactoryEndpoint(Resource):
    @ns.expect(access_role_model)
    @ns.doc("create_access_role")
    @ns.response(200, 'Success', access_role_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new data source."""
        _data = request.get_json()

        _name = _data.get('name')
        _description = _data.get('description')
        _system = False  # We do not allow the creation of system roles

        _access_role = ApplicationAccessRoleModel(name=_name, description=_description)
        database.session.add(_access_role)
        database.session.commit()

        return jsonify(_access_role.to_dict())

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class AccessRoleEndpoint(Resource):
    @ns.doc("read_access_role")
    @ns.response(200, 'Success', access_role_model)
    @ns.response(404, 'Access Role not found')
    @requires_database_session
    @propagate_principal()
    def get(self, access_role_id: str):
        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        return jsonify(_access_role.to_dict())

    @ns.doc("update_access_role")
    @ns.expect(access_role_model)
    @ns.response(200, 'Success', access_role_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The access role does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, access_role_id: str):
        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        _data = request.get_json()

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        # Mandatory fields
        _access_role.name = _data['name'] if 'name' in _data else _access_role.name
        _access_role.description = _data['description'] if 'description' in _data else _access_role.description

        database.session.commit()

        return jsonify(_access_role.to_dict())

    @ns.doc("delete_access_role")
    @ns.response(200, 'Success', access_role_model)
    @ns.response(404, 'The access_role does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, access_role_id: str):
        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        if _access_role.system is True:
            ns.abort(401, f"System roles cannot be deleted.")

        database.session.delete(_access_role)
        database.session.commit()

        return jsonify(_access_role.to_dict())

    @ns.doc(False)
    def options(self, access_role_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/user-mappings/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class UserToAccessRoleMappingsEndpoint(Resource):
    @ns.doc("read_user_to_access_role_mappings")
    @ns.response(200, 'Success', user_access_role_mapping_model)
    @ns.response(404, 'Access Role not found')
    @requires_database_session
    @propagate_principal()
    def get(self, access_role_id: str):
        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        result = UserApplicationAccessRoleRelationModel.query.filter_by(
            application_access_role_id=access_role_id).all()

        return jsonify([mapping.to_dict() for mapping in result])

    @ns.doc(False)
    def options(self, access_role_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/user-mapping/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class UserToAccessRoleMappingFactoryEndpoint(Resource):
    @ns.doc("read_user_to_access_role_mappings")
    @ns.expect(create_user_access_role_mapping_model)
    @ns.response(200, 'Success', user_access_role_mapping_model)
    @ns.response(404, 'Access Role not found')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self, access_role_id: str):
        _data = request.get_json()

        if 'user' not in _data or 'id' not in _data['user']:
            ns.abort(422, f"Mandatory attribute 'user.id' is missing in body.")

        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)
        
        user_check = UserApplicationAccessRoleRelationModel.query.filter_by(user_id = _data.get('user').get('id'), application_access_role_id=access_role_id).first()
        

        if user_check:
            ns.abort(409, f"The user is already mapped to the role '{access_role_id}'.")
            
        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        _mapping = UserApplicationAccessRoleRelationModel(user_id=_data.get('user').get('id'),
                                                          application_access_role_id=access_role_id)

        database.session.add(_mapping)
        database.session.commit()

        return jsonify(_mapping.to_dict())

    @ns.doc(False)
    def options(self, access_role_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/user-mapping/<mapping_id>/', strict_slashes=False,
          methods=['GET', 'DELETE', 'OPTIONS'])
class UserToAccessRoleMappingEndpoint(Resource):
    @ns.doc("read_user_to_access_role_mapping")
    @ns.response(200, 'Success', user_access_role_mapping_model)
    @ns.response(404, 'User to access role mapping not found')
    @requires_database_session
    @propagate_principal()
    def get(self, access_role_id: str, mapping_id: str):
        _mapping = UserApplicationAccessRoleRelationModel.query.get(mapping_id)

        if _mapping is None:
            ns.abort(404, f'An user to access role mapping with identifier "{mapping_id}" does not exist')

        return jsonify(_mapping.to_dict())

    @ns.doc("delete_user_to_access_role_mapping")
    @ns.response(200, 'Success', user_access_role_mapping_model)
    @ns.response(404, 'The access_role does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, access_role_id: str, mapping_id: str):
        #application_access_role are being used in to_dict(), which requires them to be loaded to avoid Lazy loading issue
        _mapping = UserApplicationAccessRoleRelationModel.query.options(joinedload(UserApplicationAccessRoleRelationModel.application_access_role)).get(mapping_id)
        
        mapping_data = _mapping.to_dict()

        if _mapping is None:
            ns.abort(404, f'An user to access role mapping with identifier "{mapping_id}" does not exist')

        database.session.delete(_mapping)
        database.session.commit()

        return jsonify(mapping_data)

    @ns.doc(False)
    def options(self, access_role_id: str, mapping_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/external-role-mappings/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class ExternalRoleToAccessRoleMappingsEndpoint(Resource):
    @ns.doc("read_external_role_to_access_role_mappings")
    @ns.response(200, 'Success', external_role_access_role_mapping_model)
    @ns.response(404, 'Access Role not found')
    @requires_database_session
    @propagate_principal()
    def get(self, access_role_id: str):
        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        result = ExternalRoleApplicationAccessRoleMappingModel.query.filter_by(
            application_access_role_id=access_role_id).all()

        return jsonify([mapping.to_dict() for mapping in result])

    @ns.doc(False)
    def options(self, access_role_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/external-role-mapping/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class ExternalRoleToAccessRoleMappingFactoryEndpoint(Resource):
    @ns.doc("read_external_role_to_access_role_mappings")
    @ns.response(200, 'Success', external_role_access_role_mapping_model)
    @ns.response(404, 'Access Role not found')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self, access_role_id: str):
        _data = request.get_json()

        if 'externalRoleName' not in _data:
            ns.abort(422, f"Mandatory attribute 'externalRoleName' is missing in body.")

        _access_role = ApplicationAccessRoleModel.query.get(access_role_id)

        if _access_role is None:
            ns.abort(404, f'An access role with identifier "{access_role_id}" does not exist')

        _mapping = ExternalRoleApplicationAccessRoleMappingModel(external_role_name=_data.get('externalRoleName'),
                                                                 application_access_role_id=access_role_id)

        database.session.add(_mapping)
        database.session.commit()

        return jsonify(_mapping.to_dict())

    @ns.doc(False)
    def options(self, access_role_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/access-role/<access_role_id>/external-role-mapping/<mapping_id>/', strict_slashes=False,
          methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class ExternalRoleToAccessRoleMappingEndpoint(Resource):
    @ns.doc("read_external_role_to_access_role_mapping")
    @ns.response(200, 'Success', external_role_access_role_mapping_model)
    @ns.response(404, 'External role to access role mapping not found')
    @requires_database_session
    @propagate_principal()
    def get(self, access_role_id: str, mapping_id: str):
        _mapping = ExternalRoleApplicationAccessRoleMappingModel.query.get(mapping_id)

        if _mapping is None:
            ns.abort(404, f'An external to access role mapping with identifier "{mapping_id}" does not exist')

        return jsonify(_mapping.to_dict())

    @ns.doc("update_external_role_to_access_role_mapping")
    @ns.expect(external_role_access_role_mapping_model)
    @ns.response(200, 'Success', external_role_access_role_mapping_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The external role to access role mapping does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, access_role_id: str, mapping_id: str):
        _mapping = ExternalRoleApplicationAccessRoleMappingModel.query.get(mapping_id)

        if _mapping is None:
            ns.abort(404, f'An external to access role mapping with identifier "{mapping_id}" does not exist')

        _data = request.get_json()

        _external_role_name = _data['externalRoleName'] if 'externalRoleName' in _data else _mapping.external_role_name

        _mapping.external_role_name = _external_role_name

        database.session.commit()

        return jsonify(_mapping.to_dict())

    @ns.doc("delete_external_role_to_access_role_mapping")
    @ns.response(200, 'Success', external_role_access_role_mapping_model)
    @ns.response(404, 'The access_role does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, access_role_id: str, mapping_id: str):
        _mapping = ExternalRoleApplicationAccessRoleMappingModel.query.get(mapping_id)
        
        if _mapping is None:
            ns.abort(404, f'An external role to access role mapping with identifier "{mapping_id}" does not exist')
        
        # Calling _mapping.to_dict() before deleting to avoid lazy loading issues
        mapping_data = _mapping.to_dict()

        database.session.delete(_mapping)
        database.session.commit()  
        
        return jsonify(mapping_data) 
    
    @ns.doc(False)
    def options(self, access_role_id: str, mapping_id: str):
        # Handle preflight OPTIONS request
        return '', 200
