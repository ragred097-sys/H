import logging
import json
from typing import Optional, List, Tuple

from flask import request, jsonify, Response
from flask_restx import Namespace, Resource, fields
from flask_restx._http import HTTPStatus
from sqlalchemy import and_, select
from sqlalchemy.orm import Session
from werkzeug.exceptions import SecurityError
from datetime import datetime

from maxgpt.api.impl.authorization import access_permission_model, access_permission_for_known_subject_model, \
    access_permission_for_known_subject_and_assignee_model
from maxgpt.api.impl.conversation import conversation_model
from maxgpt.api.internal.utils import get_named_lock, requires_database_session, propagate_principal, audited_model, tagged_model, \
    with_favorite, favorible_model, fetch_with_permissions, with_access_permission, \
    get_user_access_for, with_hidden
from maxgpt.modules import ModuleRegistry, ModuleType
from maxgpt.services import database
from maxgpt.services.database_model import UserFavoriteModel, FavoriteSubject, PermissionType, AgentWorkflowModel, \
    AgentWorkflowAgentRelationModel, AgentWorkflowTagRelationModel, AgentWorkflowDataSourceRelationModel, \
    AgentWorkflowAssistantRelationModel, AgentWorkflowHandoffRelationModel, AgentWorkflowAgentType, \
    ConversationModel, ConversationModuleRelationModel, AgentModel, AssistantModel, AgentWorkflowRootAgentType, \
    AccessPermissionModel, AccessPermissionSubject, AccessPermissionAssigneeType, DocumentType, \
    UserHiddenEntityModel, HiddenEntitySubject
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.eqty.util import is_eqty_enabled

ns = Namespace('Agent Workflows',
               description='Agentic workflows definitions.',
               path='/agent-workflow')

agent_workflow_agent_reference_model = ns.inherit('Agent-Workflow Agent Reference', {
    'type': fields.String(description="The type of the node in this a workflow handoff relation", enum=[t.value for t in AgentWorkflowAgentType], required=True),
    'id': fields.String(description="The id of the node in this a workflow handoff relation", required=True)
})

agent_workflow_root_agent_reference_model = ns.inherit('Agent-Workflow Root Agent Reference', {
    'type': fields.String(description="The type of the node in this a workflow handoff relation", enum=[t.value for t in AgentWorkflowRootAgentType], required=True),
    'id': fields.String(description="The id of the node in this a workflow handoff relation", required=True)
})

agent_workflow_agent_model = ns.inherit('Agent-Workflow Agent', {
    'type': fields.String(description="The type of the node in this a workflow handoff relation", enum=[t.value for t in AgentWorkflowAgentType], required=True),
    'id': fields.String(description="The id of the node in this a workflow handoff relation", required=True),
    'canHandOffTo': fields.List(fields.Nested(agent_workflow_agent_reference_model), description="A list of other agents to which this agent can handoff tasks. None = All, [] = No handoff possible, [agent references] = restricted hand off possibilities.", required=False)
})

agent_workflow_model = ns.inherit('Agent Workflow', audited_model(ns), tagged_model(ns), favorible_model(ns), {
    'id': fields.String(description="The UUID of the agent workflow.", required=True, readonly=True),
    'name': fields.String(description="The name of the agent workflow.", max_length=100, required=True),
    'description': fields.String(description="A verbose description of the agent workflow.", max_length=2000, required=True),
    'agents': fields.List(fields.Nested(agent_workflow_agent_model), description="The list of agents this agent workflow has.", required=True),
    'rootAgent': fields.Nested(agent_workflow_root_agent_reference_model, description="The root agent of this workflows (aka the first receiving agent in this workflow).", required=True),
    'icon': fields.String(description="A base64 encoded image to show as icon for this assistant.", required=False),
    'image': fields.String(description="A base64 encoded image to show in the assistant tile.", required=False)
})

def get_agent_workflow(agent_workflow_id: str, permission: PermissionType, include_deleted: bool = False) -> Tuple[AgentWorkflowModel, PermissionType]:
    """Retrieves an agent workflow and checks the user's permission for it."""
    workflow: Optional[AgentWorkflowModel] = AgentWorkflowModel.query.get(agent_workflow_id)

    if workflow is None:
        ns.abort(404, f'An agent workflow with identifier "{agent_workflow_id}" does not exist')

    # Check if agent workflow is already deleted
    if workflow.deleted_at is not None and not include_deleted:
        msg = f"The agent workflow with identifier {agent_workflow_id} has been deleted"
        if permission == PermissionType.WRITE:
            msg += " and cannot be modified"
        ns.abort(404, msg)

    grant = get_user_access_for(workflow)
    if PermissionType.rank(grant) < PermissionType.rank(permission):
        operation = 'read' if permission == PermissionType.READ else 'write'
        ns.abort(401,
                f"Not authorized. You do not have permission to {operation} agent workflow with identifier '{agent_workflow_id}'")
    else:
        return workflow, grant


# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AgentWorkflowsEndpoint(Resource):
    @ns.doc("list_agent_workflows")
    @ns.param('isDeleted', 'Set to true to get soft-deleted agent workflows', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden system-instructions, false for only unhidden', type=bool, required=False, _in="query")
    @ns.param('search', 'A search pattern as regular expression to look for. Start and end marks are added automatically', required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(agent_workflow_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available agent workflows that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if 'isDeleted' in request.args and request.args.get('isDeleted').lower() == 'true':
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_agent_workflows = AgentWorkflowModel.query.filter(
                AgentWorkflowModel.deleted_at.isnot(None),
                AgentWorkflowModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([agent_workflow.to_dict() for agent_workflow in soft_deleted_agent_workflows])

         # attach hidden information
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT_WORKFLOW)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
         # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            enhanced_agents: list[AgentWorkflowModel] = fetch_with_permissions(AgentWorkflowModel,hidden_ids)
        elif hidden_param == 'false':
            enhanced_agents: list[AgentWorkflowModel] = fetch_with_permissions(
                AgentWorkflowModel,
                ids=hidden_ids,
                exclude=True   
            )
        else:
            enhanced_agents = fetch_with_permissions(AgentWorkflowModel)

        _search_pattern = request.args.get('search')
        if _search_pattern:
            import re
            try:
                search_regex = re.compile(f".*{re.escape(_search_pattern)}.*", re.IGNORECASE)
                enhanced_agents = [
                    agent_workflow for agent_workflow in enhanced_agents
                    if search_regex.search(agent_workflow.name) or search_regex.search(agent_workflow.description)
                ]
            except re.error:
                enhanced_agents = []

        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )
        subject_ids = set(database.session.scalars(stmt))

        return jsonify([with_hidden(with_favorite(with_access_permission(_agent.to_dict(), _agent.permission), subject_ids), hidden_ids)
                        for _agent in enhanced_agents])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AgentWorkflowFactoryEndpoint(Resource):
    @ns.expect(agent_workflow_model)
    @ns.doc("create_agent_workflow")
    @ns.response(200, 'Success', agent_workflow_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new agent workflow."""
        _data = request.get_json()

        _agent_workflow = AgentWorkflowModel(name=_data.get('name'),
                                    description=_data.get('description'))

        __agent_lookup = set()  # to validate handoff relations later
        for _agent in _data.get('agents', []):
            _agent_id = _agent.get('id')
            _agent_type = AgentWorkflowAgentType.from_value(_agent.get('type'))
            __agent_lookup.add((_agent_type, _agent_id))

            if _agent_type == AgentWorkflowAgentType.AGENT:
                _agent_workflow.agent_relations.append(
                    AgentWorkflowAgentRelationModel(agent_workflow_id=_agent_workflow.id, agent_id=_agent_id))
            elif _agent_type == AgentWorkflowAgentType.ASSISTANT:
                _agent_workflow.assistant_relations.append(
                    AgentWorkflowAssistantRelationModel(agent_workflow_id=_agent_workflow.id,
                                                        assistant_id=_agent_id))
            elif _agent_type == AgentWorkflowAgentType.DATA_SOURCE:
                _agent_workflow.data_source_relations.append(
                    AgentWorkflowDataSourceRelationModel(agent_workflow_id=_agent_workflow.id,
                                                         data_source_id=_agent_id))
            else:
                ns.abort(code=HTTPStatus.BAD_REQUEST, message="Unknown agent type.")


        for _agent in _data.get('agents', []):
            _agent_id = _agent.get('id')
            _agent_type = AgentWorkflowAgentType.from_value(_agent.get('type'))
            _agent_handoffs = _agent.get('canHandOffTo') if 'canHandOffTo' in _agent else None

            # process handoffs for each agent
            if _agent_handoffs is not None:
                # Empty set? Then we add a relation without to entity
                if not _agent_handoffs:
                    _agent_workflow.handoff_relations.append(
                        AgentWorkflowHandoffRelationModel(agent_workflow_id=_agent_workflow.id,
                                                          from_type=_agent_type,
                                                          from_id=_agent_id,
                                                          to_type=None,
                                                          to_id=None
                                                          ))
                else:
                    for _handoff in _agent_handoffs:
                        _handoff_to_agent_id = _handoff['id']
                        _handoff_to_agent_type = AgentWorkflowAgentType.from_value(_handoff['type'])

                        # check if target is part of this workflow
                        if (_handoff_to_agent_type, _handoff_to_agent_id) in __agent_lookup:
                            _agent_workflow.handoff_relations.append(
                                AgentWorkflowHandoffRelationModel(agent_workflow_id=_agent_workflow.id,
                                                                  from_type=_agent_type,
                                                                  from_id=_agent_id,
                                                                  to_type=_handoff_to_agent_type,
                                                                  to_id=_handoff_to_agent_id
                                                                  ))
                        else:
                            ns.abort(code=HTTPStatus.BAD_REQUEST, message=f"Relation points to {_handoff_to_agent_type.name} with if '{_handoff_to_agent_id}' which is not part of this workflow")

        _root_agent_reference = _data.get('rootAgent')
        if _root_agent_reference is None or _root_agent_reference["id"] not in [_a["id"] for _a in _data.get('agents', [])]:
            ns.abort(code=HTTPStatus.BAD_REQUEST, message="You must specify a rootAgent that is part of your workflow.")

        _root_agent_reference_type = AgentWorkflowRootAgentType.from_value(_root_agent_reference['type'])
        if _root_agent_reference_type == AgentWorkflowRootAgentType.AGENT:
            AgentModel.query.get_or_404(_root_agent_reference['id'], f'No agent found with id "{_agent_workflow.first_receiver_id}"')
        elif _root_agent_reference_type == AgentWorkflowRootAgentType.ASSISTANT:
            AssistantModel.query.get_or_404(_root_agent_reference['id'], f'No assistant found with id "{_agent_workflow.first_receiver_id}"')

        _agent_workflow.first_receiver_type = _root_agent_reference_type
        _agent_workflow.first_receiver_id = _root_agent_reference['id']

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _agent_workflow.tag_relations.append(
                    AgentWorkflowTagRelationModel(agent_workflow_id=_agent_workflow.id, tag_id=_shallow_tag['id']))

        _image = _data.get('image')
        if _image:
            _agent_workflow.image = _image

        _icon = _data.get('icon')
        if _icon:
            _agent_workflow.icon = _icon

        _attachment_storages = _data.get('attachmentStorages') if _data.get('attachmentStorages') else {}
        if _attachment_storages:
            _agent_workflow.audio_attachment_storage_id = None
            _agent_workflow.image_attachment_storage_id = None
            _agent_workflow.video_attachment_storage_id = None
            _agent_workflow.text_attachment_storage_id = None
            for _attachment_storage in _attachment_storages:
                storage_type = DocumentType(_attachment_storage.get('type'))
                file_storage_id = _attachment_storage.get('fileStorageId')
                _agent_workflow.set_attachment_storage(storage_type, file_storage_id)

        database.session.add(_agent_workflow)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )

        subject_ids = set(database.session.scalars(stmt))
        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_agent_workflow.to_dict(), subject_ids), set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_workflow_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class AgentWorkflowEndpoint(Resource):
    @ns.doc("read_agent_workflow")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted agent workflows', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.Nested(agent_workflow_model))
    @ns.response(404, 'Agent Workflow not found')
    @requires_database_session
    @propagate_principal()
    def get(self, agent_workflow_id: str):
        current_user = SessionContext.get_current_user()
        include_deleted = 'includeDeleted' in request.args and request.args.get('includeDeleted').lower() == 'true'
        _agent_workflow, grant = get_agent_workflow(agent_workflow_id, PermissionType.READ, include_deleted)

        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )

        subject_ids = set(database.session.scalars(stmt))
         # attach hidden information
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT_WORKFLOW)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        return jsonify(with_access_permission(with_hidden(with_favorite(_agent_workflow.to_dict(), subject_ids),hidden_ids), grant))

    @ns.doc("update_agent_workflow")
    @ns.expect(agent_workflow_model)
    @ns.response(200, 'Success', agent_workflow_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The agent does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, agent_workflow_id: str):
        """Updates an existing agent."""
        _data = request.get_json()
        _agent_workflow, grant = get_agent_workflow(agent_workflow_id, PermissionType.WRITE)

        # Mandatory fields
        session = Session.object_session(_agent_workflow)

        _agent_workflow.name = _data['name'] if 'name' in _data else _agent_workflow.name
        _agent_workflow.description = _data['description'] if 'description' in _data else _agent_workflow.description

        if 'agents' in _data:
            # A new structure was provided so we wipe and re-create
            _agent_workflow.agent_relations.clear()
            _agent_workflow.assistant_relations.clear()
            _agent_workflow.data_source_relations.clear()

            __agent_lookup = set()  # to validate handoff relations later
            for _agent in _data.get('agents', []):
                _agent_id = _agent.get('id')
                _agent_type = AgentWorkflowAgentType.from_value(_agent.get('type'))
                __agent_lookup.add((_agent_type, _agent_id))

                if _agent_type == AgentWorkflowAgentType.AGENT:
                    _agent_workflow.agent_relations.append(
                        AgentWorkflowAgentRelationModel(agent_workflow_id=_agent_workflow.id, agent_id=_agent_id))
                elif _agent_type == AgentWorkflowAgentType.ASSISTANT:
                    _agent_workflow.assistant_relations.append(
                        AgentWorkflowAssistantRelationModel(agent_workflow_id=_agent_workflow.id,
                                                            assistant_id=_agent_id))
                elif _agent_type == AgentWorkflowAgentType.DATA_SOURCE:
                    _agent_workflow.data_source_relations.append(
                        AgentWorkflowDataSourceRelationModel(agent_workflow_id=_agent_workflow.id,
                                                             data_source_id=_agent_id))
                else:
                    ns.abort(code=HTTPStatus.BAD_REQUEST, message="Unknown agent type.")

            # now check all handoff relation
            _agent_workflow.handoff_relations.clear()

            for _agent in _data.get('agents', []):
                _agent_id = _agent.get('id')
                _agent_type = AgentWorkflowAgentType.from_value(_agent.get('type'))
                _agent_handoffs = _agent.get('canHandOffTo') if 'canHandOffTo' in _agent else None

                # process handoffs for each agent
                if _agent_handoffs is not None:
                    # Empty set? Then we add a relation without to entity
                    if not _agent_handoffs:
                        _agent_workflow.handoff_relations.append(
                            AgentWorkflowHandoffRelationModel(agent_workflow_id=_agent_workflow.id,
                                                              from_type=_agent_type,
                                                              from_id=_agent_id,
                                                              to_type=None,
                                                              to_id=None
                                                              ))
                    else:
                        for _handoff in _agent_handoffs:
                            _handoff_to_agent_id = _handoff['id']
                            _handoff_to_agent_type = AgentWorkflowAgentType.from_value(_handoff['type'])

                            # check if target is part of this workflow
                            if (_handoff_to_agent_type, _handoff_to_agent_id) in __agent_lookup:
                                _agent_workflow.handoff_relations.append(
                                    AgentWorkflowHandoffRelationModel(agent_workflow_id=_agent_workflow.id,
                                                                      from_type=_agent_type,
                                                                      from_id=_agent_id,
                                                                      to_type=_handoff_to_agent_type,
                                                                      to_id=_handoff_to_agent_id
                                                                      ))
                            else:
                                # ignore for now to get invalid workflow healed silently
                                # ns.abort(code=HTTPStatus.BAD_REQUEST, message=f"Relation points to {_handoff_to_agent_type.name} with if '{_handoff_to_agent_id}' which is not part of this workflow")
                                print(f"Relation points to {_handoff_to_agent_type.name} with if '{_handoff_to_agent_id}' which is not part of this workflow")

        # updating the root agent
        _root_agent_reference = _data.get('rootAgent')
        if _root_agent_reference is None or _root_agent_reference["id"] not in [_a["id"] for _a in _data.get('agents', [])]:
            ns.abort(code=HTTPStatus.BAD_REQUEST, message="You must specify a rootAgent that is part of your workflow.")

        _root_agent_reference_type = AgentWorkflowRootAgentType.from_value(_root_agent_reference['type'])
        # if _root_agent_reference_type == AgentWorkflowRootAgentType.AGENT:
        #     AgentModel.query.get_or_404(_root_agent_reference['id'],
        #                                 f'No agent found with id "{_agent_workflow.first_receiver_id}"')
        # elif _root_agent_reference_type == AgentWorkflowRootAgentType.ASSISTANT:
        #     AssistantModel.query.get_or_404(_root_agent_reference['id'],
        #                                     f'No assistant found with id "{_agent_workflow.first_receiver_id}"')

        _agent_workflow.first_receiver_type = _root_agent_reference_type
        _agent_workflow.first_receiver_id = _root_agent_reference['id']

        # Optional update fields
        _agent_workflow.image = _data['image'] if 'image' in _data else _agent_workflow.image
        _agent_workflow.icon = _data['icon'] if 'icon' in _data else _agent_workflow.icon

        _attachment_storages = _data.get('attachmentStorages') if _data.get('attachmentStorages') else []
        if _attachment_storages:
            _agent_workflow.audio_attachment_storage_id = None
            _agent_workflow.image_attachment_storage_id = None
            _agent_workflow.video_attachment_storage_id = None
            _agent_workflow.text_attachment_storage_id = None
            for _attachment_storage in _attachment_storages:
                storage_type = DocumentType(_attachment_storage.get('type'))
                file_storage_id = _attachment_storage.get('fileStorageId')
                _agent_workflow.set_attachment_storage(storage_type, file_storage_id)

        if _data.get('tags') is not None:
            _agent_workflow.tag_relations.clear()
            for _shallow_tag in _data['tags']:
                _agent_workflow.tag_relations.append(
                    AgentWorkflowTagRelationModel(agent_workflow_id=_agent_workflow.id, tag_id=_shallow_tag['id']))

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW)
        )

        subject_ids = set(database.session.scalars(stmt))

        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.SYSTEM_INSTRUCTION)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(with_access_permission(with_hidden(with_favorite(_agent_workflow.to_dict(), subject_ids), hidden_ids),grant))

    @ns.doc("delete_agent_workflow")
    @ns.param('hardDelete', 'Set to true to hard delete the agent_workflow', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', agent_workflow_model)
    @ns.response(404, 'The agent workflow does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, agent_workflow_id: str):
        _agent_workflow, grant = get_agent_workflow(agent_workflow_id, PermissionType.WRITE)
        
        agent_workflow_dict = _agent_workflow.to_dict()

        current_user = SessionContext.get_current_user()
        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.AGENT_WORKFLOW,
                UserFavoriteModel.subject_id == _agent_workflow.id
            )
        ).delete()
         # delete hidden information
        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.AGENT_WORKFLOW,
                UserHiddenEntityModel.subject_id == _agent_workflow.id
            )
        ).delete()

        #This check will preserve the original functionality of DELETE API and can be used from swagger using query parameter
        #The UI will always call this API without query parameter,so default functionality will be soft delete 
        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == 'true':
            logging.log(logging.INFO, f"Hard delete the agent-workflow:{agent_workflow_id}")
            database.session.delete(_agent_workflow)
        else:
            logging.log(logging.INFO, f"Soft delete the agent-workflow:{agent_workflow_id}")
            _agent_workflow.deleted_at = datetime.now()
            _agent_workflow.deleted_by = SessionContext().get_current_user().get_id()     
        database.session.commit()
        # attach favorite information
        subject_ids = set([])
         
        return jsonify(with_access_permission(with_hidden(with_favorite(agent_workflow_dict, subject_ids), subject_ids), grant))

    @ns.doc(False)
    def options(self, agent_workflow_id: str):
        # Handle preflight OPTIONS request
        return '', 200
    
    
@ns.route('/<agent_workflow_id>/conversations/', strict_slashes=False, methods=['GET', 'POST', 'OPTIONS'])
class AgentWorkflowConversationsFetchEndpoint(Resource):
    @ns.doc("read_agent_workflow_conversation_relations")
    @ns.response(200, 'Success', fields.List(fields.Nested(conversation_model)))
    @ns.response(404, 'AgentWorkflow not found')
    @requires_database_session
    @propagate_principal()
    def get(self, agent_workflow_id: str):
        _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)

        _conversations: List[ConversationModel] = ConversationModel.query.filter(
            ConversationModel.agent_workflow_id == _agent_workflow.id).all()

        return jsonify([conversation.to_dict() for conversation in _conversations]),

    @ns.doc(False)
    def options(self, agent_workflow_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_workflow_id>/conversation/', strict_slashes=False, methods=['GET', 'POST', 'OPTIONS'])
class AgentWorkflowConversationsCreateEndpoint(Resource):
    @ns.doc("create_agent_workflow_conversation_relation")
    @ns.expect(conversation_model)
    @ns.response(200, 'Success', conversation_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The workflow does not exist.')
    @requires_database_session
    @propagate_principal()
    def post(self, agent_workflow_id: str):
        """Creates a new conversation"""
        _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)

        _data = request.get_json()

        _name = _data.get('name') if _data is not None else None
        _conversation = ConversationModel(name=_name, agent_workflow_id=_agent_workflow.id)

        # Collecting llms from the list of agents and assistants
        llms_by_agent_or_assistant_id = {}
        for relation in _agent_workflow.agent_relations:
            agent: AgentModel = AgentModel.query.get(relation.agent_id)
            llms_by_agent_or_assistant_id[relation.agent_id] = [agent.llm_id]
        for relation in _agent_workflow.assistant_relations:
            assistant: AssistantModel = AssistantModel.query.get(relation.assistant_id)
            llms_by_agent_or_assistant_id[relation.assistant_id] = [llm.module_id for llm in assistant.llms]

        if not llms_by_agent_or_assistant_id:
            ns.abort(404, f"You cannot create a conversation for a workflow that does not contain at least one agent with a valid llm.")

        # Add llms from root agent first
        for _llm_id in llms_by_agent_or_assistant_id[_agent_workflow.first_receiver_id]:
            llm = ModuleRegistry.get_module(_llm_id)
            if llm is None:
                ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
            elif llm.get_spec().get_module_type() != ModuleType.LLM:
                ns.abort(404,
                         f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
            else:
                _conversation.llms.append(ConversationModuleRelationModel(conversation_id=_conversation.id,
                                                                          module_id=llm.get_id()))
        # Now all the rest excluding the ones of the root agent
        merged_llm_ids = set().union(*[v for k, v in llms_by_agent_or_assistant_id.items() if k != _agent_workflow.first_receiver_id])
        for _llm_id in merged_llm_ids:
            llm = ModuleRegistry.get_module(_llm_id)
            if llm is None:
                ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
            elif llm.get_spec().get_module_type() != ModuleType.LLM:
                ns.abort(404,
                         f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
            else:
                if llm.get_id() not in llms_by_agent_or_assistant_id[_agent_workflow.first_receiver_id]: # Avoid PK violations because the same llms are used as by the root agent
                    _conversation.llms.append(ConversationModuleRelationModel(conversation_id=_conversation.id,
                                                                          module_id=llm.get_id()))

        if len(_conversation.llms) == 0:
            ns.abort(404, f"You need to assign at least one LLM to conversation '{_conversation.name}'")

        # Automatically add an assistant message if the assistant has a greeting message
        # if _agent_workflow.greeting_message:
        #     add_simple_text_message(_conversation, MessageRole.ASSISTANT, _agent_workflow.greeting_message)
        # TODO: Put back the code to not forget about it. Greeting messages should be characterized specifically and not just as ASSISTANT
        #  message to decide whether or not to display it inside the chat of the UI

        database.session.add(_conversation)

        database.session.commit()

        return jsonify(_conversation.to_dict())

    @ns.doc(False)
    def options(self, agent_workflow_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_workflow_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AgentWorkflowGrantsEndpoint(Resource):
    @ns.doc(description="Get agent workflow_grant")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'AgentWorkflow not found')
    @requires_database_session
    @propagate_principal()
    def get(self, agent_workflow_id: str):
        _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)

        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent_workflow.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT_WORKFLOW)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, agent_workflow_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_workflow_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AgentWorkflowGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_agent_workflow_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Agent Workflow not found')
    @requires_database_session
    @propagate_principal()
    def post(self, agent_workflow_id: str):
        _data = request.get_json()
        get_agent_workflow(agent_workflow_id, PermissionType.WRITE)

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.AGENT_WORKFLOW,
                                               subject_id=agent_workflow_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, agent_workflow_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<agent_workflow_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['PUT', 'DELETE', 'OPTIONS'])
class AgentWorkflowGrantEndpoint(Resource):
    @ns.doc(description="update_agent_workflow_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Agent Workflow not found')
    @requires_database_session
    @propagate_principal()
    def put(self, agent_workflow_id: str, assignee_type: str, assignee_id: str):
        _data = request.get_json()
        _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.WRITE)

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid access level')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent_workflow.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT_WORKFLOW) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )

        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for agent workflow '{_agent_workflow.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for agent workflow {agent_workflow_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_agent_workflow_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Agent Workflow not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, agent_workflow_id: str, assignee_type: str, assignee_id: str):
        _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.WRITE)
        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _agent_workflow.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.AGENT_WORKFLOW) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for agent workflow '{_agent_workflow.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant delete request for agent workflow {agent_workflow_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, agent_workflow_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200


if is_eqty_enabled():
    
    from maxgpt.services.eqty.util import generate_manifest_and_purge
    from maxgpt.services.eqty.lineage import build_agent_workflow_lineage
    from maxgpt.services.database_model import AssistantGovernanceModel
    from maxgpt.api.impl.governance import DEFAULT_GOVERNANCE_CONFIGURATION, DEFAULT_GOVERNANCE_STATUS

    OVERRIDE_GOVERNANCE_CONFIGURATION = {
        'type': 'agent-workflow',
    }


    @ns.route('/<agent_workflow_id>/lineage/exists/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentWorkflowLineageExistsEndpoint(Resource):
        @ns.doc(description="Retrieve whether lineage information exists for an agent workflow.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'Agent Workflow not found')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_workflow_id: str):
            _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)
            return jsonify(True)
            
        @ns.doc(False)
        def options(self, agent_workflow_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    @ns.route('/<agent_workflow_id>/lineage/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentWorkflowLineageEndpoint(Resource):
        @ns.doc(description="Retrieve lineage information for an agent workflow.")
        @ns.response(200, 'Success')
        @ns.response(400, 'Bad request')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'TAgent Workflow not found')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_workflow_id: str):
            _agent_workflow, _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)
            
            # Replicating the process to construct a workflow
            # single-threaded because the EQTY SDK isn't threadsafe
            with (get_named_lock("EQTY")):
                _ = build_agent_workflow_lineage(_agent_workflow)
                manifest = generate_manifest_and_purge()
            
            return jsonify(manifest)

        @ns.doc(False)
        def options(self, agent_workflow_id: str):
            # Handle preflight OPTIONS request
            return '', 200
    

    @ns.route('/<agent_workflow_id>/governance/configuration', strict_slashes=False, methods=['GET', 'PUT', 'OPTIONS'])
    class AgentWorkflowGovernanceConfigurationEndpoint(Resource):
        @ns.doc(description="Retrieve the configuration for an agent workflow.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent workflow does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_workflow_id: str):
            _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.workflow_id == agent_workflow_id).first()
            configuration = _governance.configuration if _governance else json.dumps(DEFAULT_GOVERNANCE_CONFIGURATION | OVERRIDE_GOVERNANCE_CONFIGURATION)
            return Response(configuration, mimetype='application/json')
            
        @ns.doc(description="Update the configuration for an agent workflow.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent workflow does not exist')
        @requires_database_session
        @propagate_principal()
        def put(self, agent_workflow_id: str):
            _ = get_agent_workflow(agent_workflow_id, PermissionType.WRITE)
            _data = request.get_json()
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.workflow_id == agent_workflow_id).first()
            if _governance is None:
                _governance = AssistantGovernanceModel(
                    workflow_id = agent_workflow_id,
                    configuration = "{}",
                    status = json.dumps(DEFAULT_GOVERNANCE_STATUS),
                )
                database.session.add(_governance)

            _governance.configuration = json.dumps({
                    **DEFAULT_GOVERNANCE_CONFIGURATION, 
                    **json.loads(_governance.configuration),
                    **_data, 
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                })
            # Reset the governance status to default when the configuration is updated.
            _governance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)

            database.session.commit()
            return Response(_governance.configuration, mimetype='application/json')

        @ns.doc(False)
        def options(self, agent_workflow_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    @ns.route('/<agent_workflow_id>/governance/status/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AgentWorkflowGovernanceStatusEndpoint(Resource):
        @ns.doc(description="Retrieve the governance status for an agent workflow.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The agent workflow does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, agent_workflow_id: str):
            _ = get_agent_workflow(agent_workflow_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.workflow_id == agent_workflow_id).first()
            return Response(
                _governance.status if _governance else json.dumps(DEFAULT_GOVERNANCE_STATUS), 
                mimetype='application/json'
            )

        @ns.doc(False)
        def options(self, agent_workflow_id: str):
            # Handle preflight OPTIONS request
            return '', 200
