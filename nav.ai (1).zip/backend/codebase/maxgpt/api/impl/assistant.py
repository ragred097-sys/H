import logging
import json
from typing import Optional, List

from flask import request, jsonify, Response
from flask_restx import Namespace, Resource, fields
from sqlalchemy import and_, select
from sqlalchemy.orm import Session
from werkzeug.exceptions import SecurityError
from datetime import datetime

from maxgpt.api.impl.authorization import access_permission_model, \
    access_permission_for_known_subject_and_assignee_model, access_permission_for_known_subject_model
from maxgpt.api.impl.conversation import conversation_model
from maxgpt.api.impl.data_source import data_source_model, data_source_to_dict
from maxgpt.api.internal.utils import get_named_lock, requires_database_session, propagate_principal, add_simple_text_message, \
    audited_model, tagged_model, with_favorite, favorible_model, fetch_with_permissions, with_access_permission, \
    get_user_access_for, with_hidden
from maxgpt.modules import ModuleRegistry, ModuleType
from maxgpt.services import database
from maxgpt.services.database_model import DocumentType, AssistantModel, HiddenEntitySubject, \
    SystemInstructionModel, DataSourceModel, \
    AssistantModuleRelationModel, AssistantDataSourceRelationModel, ConversationModel, \
    ConversationModuleRelationModel, MessageRole, DataSourceTagRelationModel, AssistantTagRelationModel, \
    UserFavoriteModel, FavoriteSubject, PermissionType, AccessPermissionModel, AccessPermissionSubject, \
    AccessPermissionAssigneeType, AssistantSampleQuestionModel, AssistantSystemInstructionRelationModel, \
    UserHiddenEntityModel, AgentWorkflowModel
from maxgpt.services.internal.session_context import SessionContext
from maxgpt.services.eqty.util import is_eqty_enabled

ns = Namespace('Assistant',
               description='Assistants that are registered and available in the currently running application.',
               path='/assistant')


assistant_attachment_storages_model = ns.inherit('Assistant Attachment Storages', {
    'video': fields.String(description="The UUID of a valid file storage module.", max_length=36, required=False),
    'audio': fields.String(description="The UUID of a valid file storage module.", max_length=36, required=False),
    'image': fields.String(description="The UUID of a valid file storage module.", max_length=36, required=False),
    'text': fields.String(description="The UUID of a valid file storage module.", max_length=36, required=False)
})


assistant_model = ns.inherit('Assistant', audited_model(ns), tagged_model(ns), favorible_model(ns), {
    'id': fields.String(description="The UUID of the assistant.", required=True, readonly=True),
    'name': fields.String(description="The name of the assistant.", max_length=100, required=True),
    'description': fields.String(description="A verbose description of the assistant.", max_length=2000, required=True),

    'systemInstructionIds': fields.List(fields.String, description="The UUIDs of the assistant system instructions linked to this assistant.", required=False),
    'customSystemInstruction': fields.String(
        description="A user-specific extension to the pre-defined and selected system prompt.", max_length=2000,
        required=False),

    'greetingMessage': fields.String(
        description="An optional greeting message that will be added to each conversation in this assistant.",
        max_length=500, required=False),

    'llmIds': fields.List(fields.String, description="The UUIDs of the user's language models.", required=True),
    'dataSourceIds': fields.List(fields.String, description="The UUIDs of the user's data sources.", required=False),
    'sampleQuestions': fields.List(fields.String, description="A list of sample questions to quick start a meaningful conversation with this assistant.", required=False),

    'icon': fields.String(description="A base64 encoded image to show as icon for this assistant.", required=False),
    'image': fields.String(description="A base64 encoded image to show in the assistant tile.", required=False),

    'attachmentStorages': fields.Nested(assistant_attachment_storages_model)
})

assistant_conversation_model = ns.model('Conversation In Assistant', {
    'id': fields.String(description="The UUID of the model.", required=True, readonly=True),
    'name': fields.String(description="The name of the model.", max_length=100, required=False),
    'description': fields.String(description="A short summary of the data source.", max_length=500, required=False),
    'filterTag': fields.String(description="A tag to isolate data within the same vector store index", max_length=100,
                               required=False)
})

share_assistant_model = ns.model('ShareAssistant', {
    'userPermissions': fields.List(fields.Nested(ns.model('UserPermission', {
        'userId': fields.String(required=True, description='User ID'),
        'permissionType': fields.String(required=True, description='Permission type', enum=['READ', 'WRITE', 'ADMIN'])
    }))),
    'rolePermissions': fields.List(fields.Nested(ns.model('RolePermission', {
        'roleId': fields.String(required=True, description='Role ID'),
        'permissionType': fields.String(required=True, description='Permission type', enum=['READ', 'WRITE', 'ADMIN'])
    })))
})

remove_share_model = ns.model('RemoveShare', {
    'userIds': fields.List(fields.String(required=True, description='User IDs to remove')),
    'roleIds': fields.List(fields.String(required=True, description='Role IDs to remove'))
})

def get_assistant(assistant_id: str, permission: PermissionType, include_deleted: bool = False):
    """
    Retrieves an assistant by its ID and checks if the current user has access to it.

    Args:
        assistant_id (str): The ID of the assistant to retrieve.
        permission (PermissionType): The permission type to check.
        include_deleted (str): Whether to include deleted assistants.
    """
    query = AssistantModel.query.filter(AssistantModel.id == assistant_id)
    # Only apply deleted filter if includeDeleted is not true
    if not include_deleted:
        query = query.filter(AssistantModel.deleted_at.is_(None))
            
    _assistant: Optional[AssistantModel] = query.first()

    if _assistant is None:
        ns.abort(404, f'An assistant with identifier "{assistant_id}" does not exist')

    grant = get_user_access_for(_assistant)
    if PermissionType.rank(grant) < PermissionType.rank(permission):
        operation = 'read' if permission == PermissionType.READ else 'write'
        ns.abort(401,
                f"Not authorized. You do not have permission to {operation} assistant with identifier '{assistant_id}'")
                    
    return _assistant, grant


# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AssistantsEndpoint(Resource):
    @ns.doc("list_assistants")
    @ns.param('isDeleted', 'Set to true to get soft-deleted assistants', type=bool, required=False, _in="query")
    @ns.param('hidden', 'Set to true to get only hidden system-instructions, false for only unhidden', type=bool, required=False, _in="query")
    @ns.param('search', 'A search pattern as regular expression to look for. Start and end marks are added automatically', required=False, _in="query")
    @ns.response(200, 'Success', fields.List(fields.Nested(assistant_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available assistants that are accessible for the current user."""
        current_user = SessionContext.get_current_user()
        if "isDeleted" in request.args and request.args.get('isDeleted').lower() == "true":
            #Filter to fetch only soft-deleted entities and created/owned by current user
            soft_deleted_assistants = AssistantModel.query.filter(
                AssistantModel.deleted_at.isnot(None),
                AssistantModel.creator_id == current_user.get_id()
            ).all()
            return jsonify([assistant.to_dict() for assistant in soft_deleted_assistants])
            
       
          # attach hidden information
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
         # Check and filter hidden query param
        hidden_param = request.args.get('hidden', '').lower()
        if hidden_param == 'true':
            enhanced_assistants: list[AssistantModel] = fetch_with_permissions(AssistantModel,hidden_ids)
        elif hidden_param == 'false':
            enhanced_assistants: list[AssistantModel] = fetch_with_permissions(
                AssistantModel,
                ids=hidden_ids,
                exclude=True   
            )
        else:
            enhanced_assistants = fetch_with_permissions(AssistantModel)

        _search_pattern = request.args.get('search')
        if _search_pattern:
            import re
            try:
                search_regex = re.compile(f".*{re.escape(_search_pattern)}.*", re.IGNORECASE)
                enhanced_assistants = [
                    assistant for assistant in enhanced_assistants
                    if search_regex.search(assistant.name) or search_regex.search(assistant.description)
                ]
            except re.error:
                enhanced_assistants = []
        
        # attach favorite information
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )
        subject_ids = set(database.session.scalars(stmt))
        
        return jsonify([with_favorite(with_hidden(with_access_permission(_assistant.to_dict(), _assistant.permission),hidden_ids), subject_ids)
                        for _assistant in enhanced_assistants])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AssistantFactoryEndpoint(Resource):
    @ns.expect(assistant_model)
    @ns.doc("create_assistant")
    @ns.response(200, 'Success', assistant_model)
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new Assistant."""
        _data = request.get_json()
        _custom_system_instruction = _data.get('customSystemInstruction')
        _greeting_message = _data.get('greetingMessage')
        _sample_questions : list[str]= _data.get('sampleQuestions') if _data.get('sampleQuestions') else []
        _attachment_storages = _data.get('attachmentStorages') if _data.get('attachmentStorages') else {}

        _image = _data.get('image')
        _icon = _data.get('icon')

        _assistant = AssistantModel(name=_data.get('name'),
                                    description=_data.get('description'))

        if _custom_system_instruction:
            _assistant.custom_system_instruction = _custom_system_instruction

        if _image:
            _assistant.image = _image

        if _icon:
            _assistant.icon = _icon

        if _greeting_message:
            _assistant.greeting_message = _greeting_message

        if _attachment_storages:
            _assistant.audio_attachment_storage_id = None
            _assistant.image_attachment_storage_id = None
            _assistant.video_attachment_storage_id = None
            _assistant.text_attachment_storage_id = None
            for _attachment_storage in _attachment_storages:
                storage_type = DocumentType(_attachment_storage.get('type'))
                file_storage_id = _attachment_storage.get('fileStorageId')
                _assistant.set_attachment_storage(storage_type, file_storage_id)

        if _data.get('tags') is not None:
            for _shallow_tag in _data['tags']:
                _assistant.tag_relations.append(
                    AssistantTagRelationModel(assistant_id=_assistant.id, tag_id=_shallow_tag['id']))

        if _data.get('llmIds') is not None:
            for _llm_id in _data['llmIds']:
                llm = ModuleRegistry.get_module(_llm_id)
                if llm is None:
                    ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
                elif llm.get_spec().get_module_type() != ModuleType.LLM:
                    ns.abort(404,
                             f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
                else:
                    _assistant.llms.append(
                        AssistantModuleRelationModel(assistant_id=_assistant.id, module_id=llm.get_id()))
        if len(_assistant.llms) == 0:
            ns.abort(404, f"You need to assign at least one LLM to assistant '{_assistant.name}'")

        if _data.get('dataSourceIds') is not None:
            for _data_source_id in _data['dataSourceIds']:
                _data_source: Optional[DataSourceModel] = DataSourceModel.query.get(_data_source_id)
                if _data_source is None:
                    ns.abort(404, f"No data source found for identifier '{_data_source_id}'.")
                else:
                    _assistant.data_sources.append(
                        AssistantDataSourceRelationModel(assistant_id=_assistant.id, data_source_id=_data_source.id))

        if _data.get('systemInstructionIds') is not None:
            for _system_instruction_id in _data['systemInstructionIds']:
                _system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(_system_instruction_id)
                _assistant.system_instructions.append(
                    AssistantSystemInstructionRelationModel(assistant_id=_assistant.id, system_instruction_id=_system_instruction.id))

        database.session.add(_assistant)

        for _sample_question in _sample_questions:
            _q = AssistantSampleQuestionModel(assistant=_assistant, content=_sample_question)
            database.session.add(_q)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )

        subject_ids = set(database.session.scalars(stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()

        return jsonify(with_access_permission(with_hidden(with_favorite(_assistant.to_dict(), subject_ids),set([])), PermissionType.WRITE))

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200

def get_assistant_by_id(assistant_id: str):
    """Returns an Assistant for the given id."""
    current_user = SessionContext.get_current_user()
    _assistant, grant = get_assistant(assistant_id, PermissionType.READ, request.args.get('includeDeleted', 'false').lower() == 'true')

    stmt = select(UserFavoriteModel.subject_id).where(
        (UserFavoriteModel.user_id == current_user.get_id()) &
        (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
    )

    subject_ids = set(database.session.scalars(stmt))
        # attach hidden information
    hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
        (UserHiddenEntityModel.user_id == current_user.get_id()) &
        (UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT)
    )
    hidden_ids = set(database.session.scalars(hidden_stmt))
    return (with_access_permission(with_hidden(with_favorite(_assistant.to_dict(), subject_ids),hidden_ids), grant))

@ns.route('/<assistant_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
class AssistantEndpoint(Resource):
    @ns.doc("read_assistant")
    @ns.param('includeDeleted', 'Set to true to include soft-deleted assistants', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', fields.Nested(assistant_model))
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def get(self, assistant_id: str):
        """Returns an Assistant for the given id."""
        return jsonify(get_assistant_by_id(assistant_id))

    @ns.doc("update_assistant")
    @ns.expect(assistant_model)
    @ns.response(200, 'Success', assistant_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, assistant_id: str):
        """Updates an existing Assistant."""
        _data = request.get_json()
        _assistant, grant = get_assistant(assistant_id, PermissionType.WRITE)

        # Mandatory fields
        _assistant.name = _data.get('name', _assistant.name)
        _assistant.description = _data.get('description', _assistant.description)

        session = Session.object_session(_assistant)
        if _data.get('llmIds') is not None:
            for tag_relation in _assistant.llms:
                session.delete(tag_relation)
            _assistant.llms = []
            for _llm_id in _data['llmIds']:
                llm = ModuleRegistry.get_module(_llm_id)
                if llm is None:
                    ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'")
                elif llm.get_spec().get_module_type() != ModuleType.LLM:
                    ns.abort(404,
                             f"No module of type {ModuleType.LLM} found for identifier '{_llm_id}'. Given one is of type '{llm.get_spec().get_module_type()}'")
                else:
                    _assistant.llms.append(
                        AssistantModuleRelationModel(assistant_id=_assistant.id, module_id=llm.get_id()))
        if len(_assistant.llms) == 0:
            ns.abort(404, f"You need to assign at least one LLM to assistant '{_assistant.name}'")

        if _data.get('dataSourceIds') is not None:
            for ds_relation in _assistant.data_sources:
                session.delete(ds_relation)
            _assistant.data_sources = []
            for _data_source_id in _data['dataSourceIds']:
                _data_source: Optional[DataSourceModel] = DataSourceModel.query.get(_data_source_id)
                if _data_source is None:
                    ns.abort(404, f"No data source found for identifier '{_data_source_id}'.")
                else:
                    _assistant.data_sources.append(
                        AssistantDataSourceRelationModel(assistant_id=_assistant.id, data_source_id=_data_source.id))

        if _data.get('systemInstructionIds') is not None:
            for system_instruction_relation in _assistant.system_instructions:
                session.delete(system_instruction_relation)
            _assistant.system_instructions = []
            for _system_instruction_id in _data['systemInstructionIds']:
                _system_instruction: Optional[SystemInstructionModel] = SystemInstructionModel.query.get_or_404(_system_instruction_id)
                _assistant.system_instructions.append(
                    AssistantSystemInstructionRelationModel(assistant_id=_assistant.id, system_instruction_id=_system_instruction.id))

        # Optional update fields
        if _data.get('tags') is not None:
            for tag_relation in _assistant.tag_relations:
                session.delete(tag_relation)
            _assistant.tag_relations = []
            for _shallow_tag in _data['tags']:
                _assistant.tag_relations.append(
                    AssistantTagRelationModel(assistant_id=_assistant.id, tag_id=_shallow_tag['id']))

        _attachment_storages = _data.get('attachmentStorages') if _data.get('attachmentStorages') else []
        if _attachment_storages:
            _assistant.audio_attachment_storage_id = None
            _assistant.image_attachment_storage_id = None
            _assistant.video_attachment_storage_id = None
            _assistant.text_attachment_storage_id = None
            for _attachment_storage in _attachment_storages:
                storage_type = DocumentType(_attachment_storage.get('type'))
                file_storage_id = _attachment_storage.get('fileStorageId')
                _assistant.set_attachment_storage(storage_type, file_storage_id)

        _assistant.custom_system_instruction = _data[
            'customSystemInstruction'] if 'customSystemInstruction' in _data else _assistant.custom_system_instruction
        _assistant.greeting_message = _data[
            'greetingMessage'] if 'greetingMessage' in _data else _assistant.greeting_message
        _assistant.image = _data['image'] if 'image' in _data else _assistant.image
        _assistant.icon = _data['icon'] if 'icon' in _data else _assistant.icon

        if _data.get('sampleQuestions') is not None:
            AssistantSampleQuestionModel.query.filter_by(assistant_id=_assistant.id).delete()
            _sample_questions: list[str] = _data.get('sampleQuestions')
            for _sample_question in _sample_questions:
                _q = AssistantSampleQuestionModel(assistant=_assistant, content=_sample_question)
                database.session.add(_q)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT)
        )

        subject_ids = set(database.session.scalars(stmt))
          # attach hidden information
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        # commit to get autogen fields filled before returning
        database.session.commit()
        return jsonify(with_access_permission(with_hidden(with_favorite(_assistant.to_dict(), subject_ids),hidden_ids), grant))

    @ns.doc("delete_assistant")
    @ns.param('hardDelete', 'Set to true to hard delete the assistant', type=bool, required=False, _in="query")
    @ns.response(200, 'Success', assistant_model)
    @ns.response(404, 'The assistant does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, assistant_id: str):
        """Deletes an existing Assistant."""
        _assistant, grant = get_assistant(assistant_id, PermissionType.WRITE)

        # Check if assistant is used as root agent in any agent workflow
        root_agent_workflows = AgentWorkflowModel.query.filter(
            AgentWorkflowModel.first_receiver_id == _assistant.id,
            AgentWorkflowModel.deleted_at.is_(None)
        ).first()
        if root_agent_workflows:
            ns.abort(400, f"Cannot delete assistant {assistant_id} as it is used as root agent in one or more agent workflows")

        # TODO: Should we delete conversations or leave them orphaned? They could still work.

        assistant_dict = _assistant.to_dict()
        # delete favorites
        UserFavoriteModel.query.filter(
            and_(
                UserFavoriteModel.subject_type == FavoriteSubject.ASSISTANT,
                UserFavoriteModel.subject_id == _assistant.id
            )
        ).delete()
        # delete hidden information
        UserHiddenEntityModel.query.filter(
            and_(
                UserHiddenEntityModel.subject_type == HiddenEntitySubject.ASSISTANT,
                UserHiddenEntityModel.subject_id == _assistant.id
            )
        ).delete()
        
        #This check will preserve the original functionality of DELETE API and can be used from swagger using query parameter
        #The UI will always call this API without query parameter,so default functionality will be soft delete 
        if 'hardDelete' in request.args and request.args.get('hardDelete').lower() == 'true':
            logging.log(logging.INFO, f"Hard delete the assistant:{assistant_id}")
            database.session.delete(_assistant)
        else:
            logging.log(logging.INFO, f"Soft delete the assistant:{assistant_id}")
            _assistant.deleted_at = datetime.now()
            _assistant.deleted_by = SessionContext().get_current_user().get_id()

        database.session.commit()

        # attach favorite information
        subject_ids = set([])
        return jsonify(with_access_permission(with_hidden(with_favorite(assistant_dict, subject_ids),subject_ids), grant))

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200




@ns.route('/<assistant_id>/conversations/', strict_slashes=False, methods=['GET', 'POST', 'OPTIONS'])
class AssistantConversationsFetchEndpoint(Resource):
    @ns.doc("read_assistant_conversation_relations")
    @ns.response(200, 'Success', fields.List(fields.Nested(conversation_model)))
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def get(self, assistant_id: str):
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)
        _conversations: List[ConversationModel] = ConversationModel.query.filter(
            ConversationModel.assistant_id == _assistant.id).all()

        return jsonify([conversation.to_dict() for conversation in _conversations]),

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/conversation/', strict_slashes=False, methods=['GET', 'POST', 'OPTIONS'])
class AssistantConversationsCreateEndpoint(Resource):
    @ns.doc("create_assistant_conversation_relation")
    @ns.expect(conversation_model)
    @ns.response(200, 'Success', conversation_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def post(self, assistant_id: str):
        """Creates a new conversation"""
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

        # That's really bad copied code from the Conversation endpoint
        # TODO: Put into a server layer between endpoint and persistence
        _data = request.get_json()

        _name = _data.get('name') if _data is not None else None
        _conversation = ConversationModel(name=_name, assistant_id=_assistant.id)

        if _assistant.llms:
            for _llm_relation in _assistant.llms:
                llm = ModuleRegistry.get_module(_llm_relation.module_id)
                if llm is None:
                    ns.abort(404, f"No module of type {ModuleType.LLM} found for identifier '{_llm_relation}'")
                elif llm.get_spec().get_module_type() != ModuleType.LLM:
                    ns.abort(404,
                             f"No module of type {ModuleType.LLM} found for identifier '{_llm_relation}'. Given one is of type '{llm.get_spec().get_module_type()}'")
                else:
                    _conversation.llms.append(ConversationModuleRelationModel(conversation_id=_conversation.id,
                                                                              module_id=llm.get_id()))
        if len(_conversation.llms) == 0:
            ns.abort(404, f"You need to assign at least one LLM to conversation '{_conversation.name}'")

        for _system_instruction_relation in _assistant.system_instructions:
            _system_instruction = SystemInstructionModel.query.get_or_404(_system_instruction_relation.system_instruction_id)
            add_simple_text_message(_conversation, MessageRole.SYSTEM, _system_instruction.message)

        # Bootstrap chat history with system and assistant messages
        if _assistant.custom_system_instruction:
            add_simple_text_message(_conversation, MessageRole.SYSTEM, _assistant.custom_system_instruction)

        # Automatically add an assistant message if the assistant has a greeting message
        # if _assistant.greeting_message:
        #     add_simple_text_message(_conversation, MessageRole.ASSISTANT, _assistant.greeting_message)
        # TODO: Put back the code to not forget about it. Greeting messages should be characterized specifically and not just as ASSISTANT
        #  message to decide whether or not to display it inside the chat of the UI

        database.session.add(_conversation)

        database.session.commit()

        return jsonify(_conversation.to_dict())

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/data-sources/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AssistantDatasourceFetchEndpoint(Resource):
    @ns.doc("list_assistant_data_sources")
    @ns.expect(fields.Nested(data_source_model))
    @ns.response(200, 'Success', fields.Nested(data_source_model))
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def get(self, assistant_id: str):
        """Creates a new data source"""
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

        ass_to_ds_relations = AssistantDataSourceRelationModel.query.filter(
            AssistantDataSourceRelationModel.assistant_id == assistant_id).all()
        ds_ids = [relation.data_source_id for relation in ass_to_ds_relations]
        data_sources = DataSourceModel.query.filter(DataSourceModel.id.in_(ds_ids)).all()

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))
          # attach hidden information
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))

        return jsonify([with_hidden(with_favorite(data_source_to_dict(_ds), subject_ids), hidden_ids) for _ds in data_sources])

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/data-source/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AssistantDatasourceCreateEndpoint(Resource):
    @ns.doc("create_assistant_data_source_relation")
    @ns.expect(data_source_model)
    @ns.response(200, 'Success', data_source_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The assistant does not exist.')
    @requires_database_session
    @propagate_principal()
    def post(self, assistant_id: str):
        """Creates a new data source"""
        _data = request.get_json()
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

        _vector_store_id = _data.get('vectorStoreId')
        _embedding_model_id = _data.get('embeddingModelId')
        _file_storage_id = _data.get('fileStorageId')

        _name = _data['name'] if 'name' in _data else (_assistant.name + " - Datasource")
        _description = _data['description'] if 'description' in _data else (
            f"Linked data source for assistant '{_assistant.name}'.")

        new_data_source = DataSourceModel(name=_name, description=_description)

        if _embedding_model_id:
            _embedding_model = ModuleRegistry.get_module(_embedding_model_id)
            if _embedding_model is None or _embedding_model.get_spec().get_module_type() != ModuleType.EMBEDDING_MODEL:
                ns.abort(400, f"Embedding model with id {_embedding_model_id} does not exists or is of wrong type")
            else:
                new_data_source.embedding_model_id = _embedding_model.get_id()
        if _vector_store_id:
            _vector_store = ModuleRegistry.get_module(_vector_store_id)
            if _vector_store is None or _vector_store.get_spec().get_module_type() != ModuleType.VECTOR_STORE:
                ns.abort(400, f"Embedding model with id {_vector_store_id} does not exists or is of wrong type")
            else:
                new_data_source.vector_store_id = _vector_store.get_id()

        if _file_storage_id:
            _file_storage = ModuleRegistry.get_module(_file_storage_id)
            if _file_storage is None or _file_storage.get_spec().get_module_type() != ModuleType.FILE_STORAGE:
                ns.abort(400, f"File Storage with id {_file_storage} does not exists or is of wrong type")
            else:
                new_data_source.file_storage_id = _file_storage.get_id()

        # check if given tags exists
        _tag_ids = []
        if 'tags' in _data:
            for _shallow_tag in _data.get('tags'):
                _tag_ids.append(_shallow_tag.get('id'))

        # Add tags from assistant
        if _assistant.tag_relations:
            for _relation in _assistant.tag_relations:
                _tag_ids.append(_relation.tag_id)

        for _tag_id in _tag_ids:
            new_data_source.tag_relations.append(
                DataSourceTagRelationModel(data_source_id=new_data_source.id, tag_id=_tag_id))

        # Add assistant id as filter tag by default when a data source is created like this
        new_data_source.filter_tag = _data.get('filterTag') if 'filterTag' in _data else _assistant.id
        database.session.add(new_data_source)
        database.session.commit()

        # Create link between data source and assistant
        link = AssistantDataSourceRelationModel(assistant_id=_assistant.id, data_source_id=new_data_source.id)
        database.session.add(link)

        # attach favorite information
        current_user = SessionContext.get_current_user()
        stmt = select(UserFavoriteModel.subject_id).where(
            (UserFavoriteModel.user_id == current_user.get_id()) &
            (UserFavoriteModel.subject_type == FavoriteSubject.DATA_SOURCE)
        )

        subject_ids = set(database.session.scalars(stmt))
        hidden_stmt = select(UserHiddenEntityModel.subject_id).where(
            (UserHiddenEntityModel.user_id == current_user.get_id()) &
            (UserHiddenEntityModel.subject_type == HiddenEntitySubject.DATA_SOURCE)
        )
        hidden_ids = set(database.session.scalars(hidden_stmt))
        database.session.commit()

        return jsonify(with_hidden(with_favorite(data_source_to_dict(new_data_source), subject_ids)), hidden_ids)

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/grants/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class AssistantGrantsEndpoint(Resource):
    @ns.doc(description="read_assistant_grants")
    @ns.response(200, 'Success', fields.List(fields.Nested(access_permission_model)))
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def get(self, assistant_id: str):
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        all_permissions_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _assistant.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.ASSISTANT)
        )
        all_permissions = set(database.session.scalars(all_permissions_stmt))

        return jsonify([permission.to_dict() for permission in all_permissions])

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/grant/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class AssistantGrantFactoryEndpoint(Resource):
    @ns.doc(description="create_assistant_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_model)
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def post(self, assistant_id: str):
        _data = request.get_json()
        _assistant, _ = get_assistant(assistant_id, PermissionType.WRITE)

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        if 'assigneeId' not in _data:
            ns.abort(400, 'You must provide a valid assigneeId.')

        if 'assigneeType' not in _data:
            ns.abort(400, 'You must provide a valid assigneeType.')

        _assignee_type = AccessPermissionAssigneeType.from_value(_data['assigneeType'])

        new_permission = AccessPermissionModel(subject_type=AccessPermissionSubject.ASSISTANT, subject_id=assistant_id,
                                               assignee_id=_data['assigneeId'], assignee_type=_assignee_type,
                                               access_level=PermissionType.from_value(_data['accessLevel']))

        new_permission = database.session.merge(new_permission)
        database.session.commit()

        return jsonify(new_permission.to_dict())

    @ns.doc(False)
    def options(self, assistant_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/grant/<assignee_type>/<assignee_id>', strict_slashes=False,
          methods=['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'])
class AssistantGrantEndpoint(Resource):
    @ns.doc(description="read_assistant_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def get(self, assistant_id: str, assignee_type: str, assignee_id: str):
        _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _assistant.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.ASSISTANT) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for assistant '{_assistant.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for assistant {assistant_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]

        return jsonify(permission.to_dict())

    @ns.doc(description="update_assistant_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.expect(access_permission_for_known_subject_and_assignee_model)
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def put(self, assistant_id: str, assignee_type: str, assignee_id: str):
        _data = request.get_json()
        _assistant, _ = get_assistant(assistant_id, PermissionType.WRITE)

        if 'accessLevel' not in _data:
            ns.abort(400, 'You must provide a valid accessLevel.')

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _assistant.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.ASSISTANT) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for assistant '{_assistant.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for assistant {assistant_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        permission.access_level = PermissionType.from_value(_data['accessLevel'])

        database.session.commit()

        return jsonify(permission.to_dict())

    @ns.doc(description="delete_assistant_grant")
    @ns.response(200, 'Success', fields.Nested(access_permission_model))
    @ns.response(404, 'Assistant not found')
    @requires_database_session
    @propagate_principal()
    def delete(self, assistant_id: str, assignee_type: str, assignee_id: str):
        _assistant, _ = get_assistant(assistant_id, PermissionType.WRITE)

        _assignee_type = AccessPermissionAssigneeType.from_value(assignee_type)

        # TODO: Only continue when current user is owner or, in the next step, has access to read
        permission_stmt = select(AccessPermissionModel).where(
            (AccessPermissionModel.subject_id == _assistant.id) &
            (AccessPermissionModel.subject_type == AccessPermissionSubject.ASSISTANT) &
            (AccessPermissionModel.assignee_type == _assignee_type) &
            (AccessPermissionModel.assignee_id == assignee_id)
        )
        permission = list(database.session.scalars(permission_stmt))
        if len(permission) == 0:
            ns.abort(404,
                     f"A permission for assistant '{_assistant.name}' and {_assignee_type} with identifier '{assignee_id}' does not exist")

        if len(permission) > 1:
            logging.log(logging.WARN,
                        f"{_assignee_type} grant put request for assistant {assistant_id} and assignee {assignee_id} returned multiple records in the DB.")
            raise SecurityError("Not-allowed security configuration request identified. Your request has been logged.")

        permission = permission[0]
        database.session.delete(permission)

        return jsonify(permission.to_dict())

    @ns.doc(False)
    def options(self, assistant_id: str, assignee_type: str, assignee_id: str):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<assistant_id>/restore')
class RestoreAssistantEndpoint(Resource):
    @ns.doc(description="restore_deleted_assistant")
    @ns.response(200, 'Assistant restored successfully', model=assistant_model)
    @ns.response(404, 'The assistant does not exist or is not deleted')
    @requires_database_session
    @propagate_principal()
    def patch(self, assistant_id: str):
        """Restores a soft-deleted assistant."""
        
        current_user = SessionContext.get_current_user()

        _assistant: AssistantModel = AssistantModel.query.get(assistant_id)
        
        if _assistant is None or _assistant.deleted_at is None:
            ns.abort(404, f"Assistant with identifier '{assistant_id}' is not deleted or does not exist")
        # Check if the current user is the creator of the assistant
        if _assistant.creator_id != current_user.get_id():
            ns.abort(403, "You are not authorized to restore this assistant")

        _assistant.deleted_at = None
        _assistant.deleted_by = None  

        database.session.commit()
        return jsonify(_assistant.to_dict())

    @ns.doc(False)
    def options(self, assistant_id: str):
        """Handles preflight CORS request."""
        return '', 200


if is_eqty_enabled():
    
    from maxgpt.services.eqty.util import generate_manifest_and_purge
    from maxgpt.services.eqty.lineage import build_assistant_lineage
    from maxgpt.services.database_model import AssistantGovernanceModel
    from maxgpt.api.impl.governance import DEFAULT_GOVERNANCE_CONFIGURATION, DEFAULT_GOVERNANCE_STATUS

    OVERRIDE_GOVERNANCE_CONFIGURATION = {
        'type': 'assistant',
    }


    @ns.route('/<assistant_id>/lineage/exists', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AssistantLineageExistsEndpoint(Resource):
        @ns.doc(description="Retrieve whether lineage information exists for an assistant.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The assistant does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, assistant_id: str):
            _ = get_assistant(assistant_id, PermissionType.READ)
            return jsonify(True)
            
        @ns.doc(False)
        def options(self, assistant_id: str):
            # Handle preflight OPTIONS request
            return '', 200


    @ns.route('/<assistant_id>/lineage/', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AssistantLineageEndpoint(Resource):
        @ns.doc(description="Retrieve lineage information for an assistant.")
        @ns.response(200, 'Success')
        @ns.response(400, 'Bad request')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The assistant does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, assistant_id: str):
            _assistant, _ = get_assistant(assistant_id, PermissionType.READ)

            # Replicating the process to construct an assistant
            # single-threaded because the EQTY SDK isn't threadsafe
            with (get_named_lock("EQTY")):
                _ = build_assistant_lineage(_assistant)
                manifest = generate_manifest_and_purge()
                
            return jsonify(manifest)

        @ns.doc(False)
        def options(self, assistant_id: str):
            # Handle preflight OPTIONS request
            return '', 200
        
       
    @ns.route('/<assistant_id>/governance/configuration', strict_slashes=False, methods=['GET', 'PUT', 'OPTIONS'])
    class AssistantGovernanceConfigurationEndpoint(Resource):
        @ns.doc(description="Retrieve the configuration for an assistant.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The assistant does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, assistant_id: str):
            _ = get_assistant(assistant_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.assistant_id == assistant_id).first()
            configuration = _governance.configuration if _governance else json.dumps(DEFAULT_GOVERNANCE_CONFIGURATION | OVERRIDE_GOVERNANCE_CONFIGURATION)
            return Response(configuration, mimetype='application/json')
            
            
        @ns.doc(description="Update the configuration for an assistant.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The assistant does not exist')
        @requires_database_session
        @propagate_principal()
        def put(self, assistant_id: str):
            _ = get_assistant(assistant_id, PermissionType.WRITE)
            _data = request.get_json()
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.assistant_id == assistant_id).first()
            if _governance is None:
                _governance = AssistantGovernanceModel(
                    assistant_id = assistant_id,
                    configuration = "{}",
                    status = json.dumps(DEFAULT_GOVERNANCE_STATUS),
                )
                database.session.add(_governance)

            _governance.configuration = json.dumps({
                    **DEFAULT_GOVERNANCE_CONFIGURATION, 
                    **json.loads(_governance.configuration),
                    **_data, 
                    **OVERRIDE_GOVERNANCE_CONFIGURATION
                })
            # Reset the governance status to default when the configuration is updated.
            _governance.status = json.dumps(DEFAULT_GOVERNANCE_STATUS)
            
            database.session.commit()
            return Response(_governance.configuration, mimetype='application/json')


        @ns.doc(False)
        def options(self, assistant_id: str):
            # Handle preflight OPTIONS request
            return '', 200
        

    @ns.route('/<assistant_id>/governance/status', strict_slashes=False, methods=['GET', 'OPTIONS'])
    class AssistantGovernanceStatusEndpoint(Resource):
        @ns.doc(description="Retrieve the governance status for an assistant.")
        @ns.response(200, 'Success')
        @ns.response(401, 'Not authorized')
        @ns.response(404, 'The assistant does not exist')
        @requires_database_session
        @propagate_principal()
        def get(self, assistant_id: str):
            _ = get_assistant(assistant_id, PermissionType.READ)
            _governance = AssistantGovernanceModel.query.filter(AssistantGovernanceModel.assistant_id == assistant_id).first()
            return Response(
                _governance.status if _governance else json.dumps(DEFAULT_GOVERNANCE_STATUS), 
                mimetype='application/json'
            )

        @ns.doc(False)
        def options(self, assistant_id: str):
            # Handle preflight OPTIONS request
            return '', 200
