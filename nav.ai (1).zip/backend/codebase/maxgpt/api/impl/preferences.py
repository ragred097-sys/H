import json

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields
from sqlalchemy import or_

from maxgpt.api.internal.utils import requires_database_session, propagate_principal
from maxgpt.core import DataType
from maxgpt.services import database
from maxgpt.services.database_model import PreferenceModel, PreferenceScope
from maxgpt.services.internal.session_context import SessionContext  

ns = Namespace('Preferences',
               description='Maintain available preferences (e.g. scope "USER" that can be set individually for a user).',
               path='/user-preference')

preference_model = ns.model('Preference', {
    'id': fields.String(description="The UUID of the preference.", required=True, readonly=True),
    'name': fields.String(description="The name of the preference.", required=True),
    'label': fields.String(description="The label of the preference.", required=False),
    'description': fields.String(description="The description of the preference.", required=False),
    'type': fields.String(description="The data type of a preference.", enum=[t.name for t in DataType],
                          required=True),
    'scope': fields.String(description="The scope of a preference.", enum=[scope.name for scope in PreferenceScope],
                          required=True)
})

# To avoid confusion: The 's' is attached to the configured path value of this namespace.
@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class PreferencesEndpoint(Resource):
    @ns.doc("list_preferences")
    @ns.response(200, 'Success', fields.List(fields.Nested(preference_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns a list of all available user preferences."""
        if SessionContext.is_administrator():
            user_preferences = PreferenceModel.query.order_by(PreferenceModel.name).all()
        else:
            user_preferences = PreferenceModel.query.filter(
                or_(
                    PreferenceModel.scope == PreferenceScope.USER,
                    PreferenceModel.scope == PreferenceScope.GENERAL
                )
            ).order_by(PreferenceModel.name).all()
        return jsonify([preference.to_dict() for preference in user_preferences])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/', strict_slashes=False)
class PreferenceFactoryEndpoint(Resource):
    @ns.expect(preference_model)
    @ns.doc("create_user_preference")
    @ns.response(200, 'Success', preference_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal()
    def post(self):
        """Creates a new preference"""
        _data = request.get_json()

        _preference_model = PreferenceModel(name=_data.get('name'), label=_data.get('label'),
                                                 description=_data.get('description'), )

        try:
            _preference_model.type = DataType.from_value(_data.get('type'))
        except ValueError:
            ns.abort(f"Specified type '{_data.get('type')}' does not exist")

        try:
            _preference_model.scope = PreferenceScope.from_value(_data.get('scope'))
        except ValueError:
            ns.abort(f"Specified scope '{_data.get('scope')}' does not exist")

        database.session.add(_preference_model)
        database.session.commit()

        return jsonify(_preference_model.to_dict())

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<preference_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
@ns.param('preference_id', 'A valid UUID of an existing preference.')
class UserEndpoint(Resource):
    @ns.doc(description="read_preference")
    @ns.response(200, 'Success', preference_model)
    @ns.response(404, 'User not found')
    @requires_database_session
    @propagate_principal()
    def get(self, preference_id: str):
        """Returns the user preference for the given id if existing."""
        _user_preference = PreferenceModel.query.get(preference_id)

        if _user_preference is None:
            ns.abort(404, f"No preference found for identifier '{preference_id}'")

        return jsonify(_user_preference.to_dict())

    @ns.doc("update_preference")
    @ns.expect(preference_model)
    @ns.response(200, 'Success', preference_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'The preference does not exist.')
    @requires_database_session
    @propagate_principal()
    def put(self, preference_id: str):
        """Updates an existing preference."""
        _data = request.get_json()
        _preference: PreferenceModel = PreferenceModel.query.get(preference_id)

        if _preference is None:
            ns.abort(404, 'A preference with identifier "{}" does not exist'.format(preference_id))

        _preference.name = _data.get('name') if 'name' in _data else _preference.name
        _preference.label = _data.get('label') if 'label' in _data else _preference.label
        _preference.description = _data.get('description') if 'description' in _data else _preference.description

        if 'scope' in _data:
            scope = PreferenceScope.from_value(_data.get('scope'))
            if scope != _preference.scope:
                ns.abort(400, 'You cannot change the scope of a preference afterwards')

        # TODO if type change is possible (e.g. from number to text)
        #      or check if all settings referring to this preference are save to be updated
        if 'type' in _data:
            type = DataType.from_value(_data.get('type'))
            if type != _preference.type:
                ns.abort(400, 'You cannot change the type of a preference afterwards')

        database.session.commit()

        return jsonify(_preference.to_dict())

    @ns.doc("delete_preference")
    @ns.response(200, 'Success', preference_model)
    @ns.response(404, 'The preference does not exist')
    @requires_database_session
    @propagate_principal()
    def delete(self, preference_id: str):
        """Delete the preference for the given identifier if existing."""
        _preference: PreferenceModel = PreferenceModel.query.get(preference_id)

        if _preference is None:
            ns.abort(404, 'A preference with identifier "{}" does not exist'.format(preference_id))

        # TODO check if preference is still used?
        database.session.delete(_preference)

        return jsonify(_preference.to_dict())

    @ns.doc(False)
    def options(self, user_id: str):
        # Handle preflight OPTIONS request
        return '', 200

