import json
from typing import Optional

from flask import Response, request, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import propagate_principal
from maxgpt.modules.modules import ModuleType, ModuleSpec, ModuleSpecRegistry

ns = Namespace('Module Specifications',
               description='Collect information about the available modules that can be configured and registered in this application instance.',
               path='/module-spec')


module_configuration_model = ns.model('Module Specification Configuration', {
    'name': fields.String(description="The name of the configuration.", required=True),
    'type': fields.String(description="The value type of the configuration.", required=True),
    'default': fields.String(description="The default value of the configuration.", required=True),
    'description': fields.String(description="The description for the configuration.", required=True),
    'optional': fields.Boolean(description="Information if configuration is optional or not.", required=True),
})

capabilities_model = ns.model('Module Specification Capability', {
    'name': fields.String(description="The name of the capability.", required=True),
    'type': fields.String(description="The type of the capability.", required=True),
    'default': fields.Boolean(description="The default value of the capability.", required=True),
    'description': fields.String(description="The description of the capability.", required=False),
    'label': fields.String(description="The label of the capability.", required=False),
})
 

module_specification_model = ns.model('Module Specification', {
    'id': fields.String(description="The identifier of the module specification.", required=True, readonly=True),
    'name': fields.String(description="A descriptive name of the module specification.", max_length=100, required=True),
    'description': fields.String(description="The description of the module specification.", required=True),
    'moduleType': fields.String(description="The module type of the module specification.", required=True),
    'parameters': fields.List(fields.Nested(module_configuration_model), description="A list of all configurations for the module specification.", required=False),
    'capabilities': fields.List(fields.Nested(capabilities_model), description="A list of all capabilities for the module specification.", required=False)
})


@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class ModuleSpecificationsEndpoint(Resource):
    @ns.doc(description="list_module_specifications")
    @ns.param("moduleType", description="The module type of the module specification.", _in="query", required=False)
    @ns.response(200, 'Success', fields.List(fields.Nested(module_specification_model)))
    @propagate_principal()
    def get(self):
        module_type_name = request.args.get('moduleType')

        module_type: Optional[ModuleType] = None

        if module_type_name:
            module_type = ModuleType[module_type_name]
            if module_type is None:
                ns.abort(400, "Module type '{}' not found.".format(module_type_name))

        module_specs = ModuleSpecRegistry.get_module_specs(module_type)

        return jsonify([_module_spec.to_dict() for _module_spec in module_specs])

    @ns.doc(False)
    def options(self):
        # Handle preflight OPTIONS request
        return '', 200


@ns.route('/<module_spec_id>/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class ModuleSpecificationEndpoint(Resource):
    @ns.doc(description="read_module_specification")
    @ns.response(200, 'Success', module_specification_model)
    @ns.response(404, 'Module Specification not found')
    @propagate_principal()
    def get(self, module_spec_id: str):
        _module_spec = ModuleSpecRegistry.get_module_spec(module_spec_id)

        if _module_spec is None:
            ns.abort(404, 'A module specification with identifier "{}" does not exist'.format(module_spec_id))

        return jsonify(_module_spec.to_dict())

    @ns.doc(False)
    def options(self, module_spec_id: str):
        # Handle preflight OPTIONS request
        return '', 200
