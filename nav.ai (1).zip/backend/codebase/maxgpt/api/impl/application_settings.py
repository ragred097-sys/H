from flask import request, jsonify
from flask_restx import Namespace, Resource, fields

from maxgpt.api.internal.utils import requires_database_session, propagate_principal, audited_model
from maxgpt.services import database, DefaultApplicationAccessRole
from maxgpt.services.database_model import ApplicationSettingModel, PreferenceModel, PreferenceScope
from maxgpt.services.internal.session_context import SessionContext

ns = Namespace('ApplicationSettings',
               description='Manage application-level settings',
               path='/application/setting')

# Use audited_model for audit fields
application_setting_model = ns.inherit('ApplicationSetting',
    audited_model(ns),
    {
        'id': fields.String(description="The UUID of the application setting.", required=True, readonly=True),
        'preferenceId': fields.String(description="The UUID of the application preference.", required=True, readonly=True),
        'value': fields.String(description="The value as string (!) of the preference for the application.", required=True),
    }
)

application_setting_input_model = ns.model('ApplicationSettingInput', {
    'preferenceId': fields.String(description="The UUID of the application preference.", required=True),
    'value': fields.String(description="The value as string (!) of the preference for the application.", required=True),
})

application_setting_update_model = ns.model('ApplicationSettingUpdate', {
    'value': fields.String(description="The value as string (!) of the preference for the application.", required=True),
}) 

@ns.route('s/', strict_slashes=False, methods=['GET', 'OPTIONS'])
class ApplicationSettingsEndpoint(Resource):
    @ns.doc("list_application_settings")
    @ns.response(200, 'Success', fields.List(fields.Nested(application_setting_model)))
    @requires_database_session
    @propagate_principal()
    def get(self):
        """Returns all application-level settings (any authenticated user)."""
        settings = ApplicationSettingModel.query.all()
        return jsonify([setting.to_dict() for setting in settings])

    @ns.doc(False)
    def options(self):
        return '', 200

@ns.route('/', strict_slashes=False, methods=['POST', 'OPTIONS'])
class ApplicationSettingFactoryEndpoint(Resource):
    @ns.expect(application_setting_input_model)
    @ns.doc("create_application_setting")
    @ns.response(200, 'Success', application_setting_model)
    @ns.response(400, 'Referenced entity not found')
    @ns.response(403, 'Access denied')
    @ns.response(422, 'Bad request')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def post(self):
        """Create a new application-level setting (admin only)."""
        data = request.get_json()
        preference = PreferenceModel.query.get(data.get('preferenceId'))
        if preference is None:
            ns.abort(422, f"Preference with identifier '{data.get('preferenceId')}' does not exist")
        if preference.scope not in [PreferenceScope.APPLICATION, PreferenceScope.GENERAL]:
            ns.abort(422, f"Preference with identifier '{data.get('preferenceId')}' must have scope 'APPLICATION' or 'GENERAL'")

        setting = ApplicationSettingModel(preference_id=preference.id, value=data.get('value'))
        database.session.add(setting)
        database.session.commit()
        return jsonify(setting.to_dict())

    @ns.doc(False)
    def options(self):
        return '', 200

@ns.route('/<preference_id>/', strict_slashes=False, methods=['GET', 'PUT', 'DELETE', 'OPTIONS'])
@ns.param('preference_id', 'A valid UUID of an application preference.')
class ApplicationSettingEndpoint(Resource):
    @ns.doc("get_application_setting")
    @ns.response(200, 'Success', application_setting_model)
    @ns.response(403, 'Access denied')
    @ns.response(404, 'Setting not found')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def get(self, preference_id: str):
        """Get a specific application-level setting (admin only)."""
        setting = ApplicationSettingModel.query.filter_by(preference_id=preference_id).first()
        if setting is None:
            ns.abort(404, f"No application setting found for preference '{preference_id}'")
        return jsonify(setting.to_dict())

    @ns.doc("update_application_setting")
    @ns.expect(application_setting_update_model)
    @ns.response(200, 'Success', application_setting_model)
    @ns.response(400, 'Bad request')
    @ns.response(404, 'Setting not found')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def put(self, preference_id: str):
        """Update an application-level setting (admin only)."""
        data = request.get_json()
        setting = ApplicationSettingModel.query.filter_by(preference_id=preference_id).first()
        if setting is None:
            ns.abort(404, f"No application setting found for preference '{preference_id}'")
        setting.value = data.get('value')
        database.session.commit()
        return jsonify(setting.to_dict())

    @ns.doc("delete_application_setting")
    @ns.response(200, 'Success', application_setting_model)
    @ns.response(404, 'Setting not found')
    @requires_database_session
    @propagate_principal(allowed_app_role_names=[DefaultApplicationAccessRole.MAXGPT_ADMINISTRATOR.value])
    def delete(self, preference_id: str):
        """Delete an application-level setting (admin only)."""
        setting = ApplicationSettingModel.query.filter_by(preference_id=preference_id).first()
        if setting is None:
            ns.abort(404, f"No application setting found for preference '{preference_id}'")
        database.session.delete(setting)
        database.session.commit()
        return jsonify(setting.to_dict())

    @ns.doc(False)
    def options(self, preference_id: str):
        return '', 200 