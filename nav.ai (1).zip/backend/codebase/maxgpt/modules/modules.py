from __future__ import annotations

import abc
import datetime
import hashlib
import json
import logging
import os
from abc import abstractmethod
from datetime import datetime
from enum import Enum
from typing import Optional, List, Type, Dict, Any

import torch
from flask import current_app
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from maxgpt.api import EntityType
from maxgpt.api.internal.utils import get_named_lock
from maxgpt.services import database, Tag
from maxgpt.services.data_model.user import SystemUser
from maxgpt.services.database_model import ModuleModel, ModuleParameterModel, TagModel, \
    ModuleTagRelationModel, DataType, DocumentType, \
    ModuleCapabilityModel, ModuleCapabilityRelationModel, ModuleCapabilityType, database
from maxgpt.services.internal import ShallowTag
from maxgpt.services.reflections import import_modules, find_subclasses, find_class_annotations
from maxgpt.services.security import ShallowUser

print(f"#### Torch - CUDA details ####")
print(f"\tCUDA available = {torch.cuda.is_available()}")
print(f"\tCUDA version = {torch.version.cuda}")
print(f"\t{torch.cuda.device_count()} available instances")
if torch.cuda.device_count() > 0:
    print(f"\t{torch.cuda.current_device()} selected as current device")

print(f"#### Torch - MPS details ####")
print(f"\tMPS available = {torch.backends.mps.is_available()}")
print(f"\tMPS is built = {torch.backends.mps.is_built()}")

class ModuleType(Enum):
    LLM = "LLM"
    EMBEDDING_MODEL = "EMBEDDING_MODEL"
    VECTOR_STORE = "VECTOR_STORE"
    FILE_STORAGE = "FILE_STORAGE"
    FUNCTION_TOOL = "FUNCTION_TOOL"
    DOCUMENT_PARSER = "DOCUMENT_PARSER"

    def get_base_class(self) -> Type[ModuleSpecFactory]:
        from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
        from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
        from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
        from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
        from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
        from maxgpt.modules.impl.document_parser. abstract_document_parser import AbstractDocumentParser

        if self == self.LLM:
            return AbstractLLM
        elif self == self.EMBEDDING_MODEL:
            return AbstractEmbeddingModel
        elif self == self.VECTOR_STORE:
            return AbstractVectorStore
        elif self == self.FILE_STORAGE:
            return AbstractFileStorage
        elif self == self.FUNCTION_TOOL:
            return AbstractFunctionTool
        elif self == self.DOCUMENT_PARSER:
            return AbstractDocumentParser
        else:
            raise Exception(f"Not implemented for type {self.name}")


class ModuleSpecParameter(abc.ABC):
    def __init__(self, name: str, label: str, description: str, data_type: DataType,
                 default: str = None, optional: bool = False, secured: bool = False, enum_values=None):
        self._name = name
        self._label = label
        self._description = description
        self._default = default
        self._optional = optional
        self._type = data_type
        self._secured = secured
        self._enum_values = enum_values

    def get_name(self) -> str:
        return self._name

    def get_label(self) -> str:
        return self._label

    def get_description(self) -> str:
        return self._description

    def get_default(self) -> Optional[str]:
        return self._default

    def get_optional(self) -> bool:
        return self._optional

    def get_type(self) -> DataType:
        return self._type

    def is_secured(self) -> bool:
        return self._secured

    def to_dict(self) -> dict:
        d = {
            "name": self._name,
            "label": self._label,
            "description": self._description,
            "type": self._type,
            "default": self._default,
            "optional": self._optional,
            "secured": self._secured
        }
        if self._enum_values is not None:
            d["enum_values"] = self._enum_values
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    def __eq__(self, __value):
        if isinstance(__value, ModuleSpecParameter):
            return self.get_name() == __value.get_name()
        return False

    def __hash__(self):
        return self._name.__hash__()

    def __str__(self):
        return self.to_json()


class ModuleSpecFactory:
    @classmethod
    @abc.abstractmethod
    def get_spec_id(cls) -> str:
        pass

    @classmethod
    @abc.abstractmethod
    def get_spec_name(cls) -> str:
        pass

    @classmethod
    @abc.abstractmethod
    def get_spec_description(cls) -> str:
        pass

    @classmethod
    @abc.abstractmethod
    def get_spec_type(cls) -> ModuleType:
        pass

    @classmethod
    @abc.abstractmethod
    def get_spec_parameters(cls) -> List[ModuleSpecParameter]:
        pass


class ModuleSpec(abc.ABC):
    _id: str
    _name: str
    _module_type: ModuleType
    _parameters: List[ModuleSpecParameter] = []
    _parameters_by_name: Dict[str, ModuleSpecParameter] = {}
    _runtime: Type

    def __init__(self, module_spec_id: str, module_spec_name: str,  module_spec_description: str, module_spec_runtime: Type, module_type: ModuleType,
                 parameters: List[ModuleSpecParameter]):
        self._id = module_spec_id
        self._name = module_spec_name
        self._description = module_spec_description
        self._module_type = module_type
        self._parameters = parameters
        for parameter in parameters:
            self._parameters_by_name[parameter.get_name()] = parameter
        self._runtime = module_spec_runtime

    def get_id(self) -> str:
        return self._id

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self._description

    def get_module_type(self) -> ModuleType:
        return self._module_type

    def get_parameters(self) -> List[ModuleSpecParameter]:
        return self._parameters

    def get_parameter(self, name: str) -> Optional[ModuleSpecParameter]:
        return self._parameters_by_name.get(name)

    def get_runtime(self) -> Type:
        return self._runtime

    def to_dict(self) -> dict:
        result = {
            "id": self._id,
            "name": self._name,
            "description": self._description,
            "type": self._module_type,
            "parameters": [parameter.to_dict() for parameter in self._parameters]
        }
        # Fetch capabilities from the database for this module type
        capabilities = []
        try:
            db_caps = (
                database.session.query(ModuleCapabilityModel)
                .filter(ModuleCapabilityModel.module_type == ModuleCapabilityType[self._module_type.name])
                .all()
            )
            capabilities = [
                {
                    "name": cap.name,
                    "type": cap.module_type.value,
                    "default": cap.default,
                    "description": cap.description,
                    "label": cap.label,
                }
                for cap in db_caps
            ]
        except Exception as e:
            capabilities = []
        result["capabilities"] = capabilities
        return result

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    def __eq__(self, __value):
        if isinstance(__value, ModuleSpec):
            return self.get_id() == __value.get_id()
        return False

    def __hash__(self):
        return self._id.__hash__()

    def __repr__(self):
        return self.to_json()


class ModuleSpecRegistry(abc.ABC):
    __initialized: bool = False
    __specs_by_type_and_id: Dict[ModuleType, Dict[str, ModuleSpec]] = {}
    __specs_by_id: Dict[str, ModuleSpec] = {}

    @classmethod
    def initialize(cls):
        if cls.__initialized:
            raise RuntimeError("ModuleSpecRegistry already initialized")
        cls.__specs_by_type_and_id: Dict[ModuleType, Dict[str, ModuleSpec]] = {}
        cls.__specs_by_id: Dict[str, ModuleSpec] = {}

        for t in ModuleType:
            cls.__specs_by_type_and_id[t] = {}

        import_modules(os.path.dirname(os.path.abspath(__file__)) + "/impl")

        cls.__search_and_add_specs(ModuleType.LLM)
        cls.__search_and_add_specs(ModuleType.EMBEDDING_MODEL)
        cls.__search_and_add_specs(ModuleType.VECTOR_STORE)
        cls.__search_and_add_specs(ModuleType.FILE_STORAGE)
        cls.__search_and_add_specs(ModuleType.FUNCTION_TOOL)
        cls.__search_and_add_specs(ModuleType.DOCUMENT_PARSER)

        cls.__initialized = True

    @classmethod
    def __search_and_add_specs(cls, module_type: ModuleType):
        module_classes = find_subclasses(module_type.get_base_class())
        for module_class in module_classes:
            logging.log(logging.INFO,
                        f"Found module implementation of type {module_type}: {module_class.__name__}. Adding it to registry")
            try:
                module_spec = ModuleSpec(module_spec_id=module_class.get_spec_id(),
                                         module_spec_name=module_class.get_spec_name(),
                                         module_spec_description=module_class.get_spec_description(),
                                         module_spec_runtime=module_class,
                                         module_type=module_type,
                                         parameters=find_class_annotations(module_class, ModuleSpecParameter))
                cls.__add_module_spec(module_spec)
            except Exception as e:
                logging.warning("Unable to instantiated module spec '" + module_class.__name__ + "': " + str(e))

    @classmethod
    def __add_module_spec(cls, module_spec: ModuleSpec):
        # noinspection PyUnresolvedReferences
        type_name = module_spec.__class__.__name__
        if module_spec.get_id() in cls.__specs_by_id:
            raise ValueError(f"{type_name} with spec id '{module_spec.get_id()}' already registered.")

        cls.__specs_by_id[module_spec.get_id()] = module_spec
        cls.__specs_by_type_and_id[module_spec.get_module_type()][module_spec.get_id()] = module_spec
        logging.info(f"{type_name} with spec id '{module_spec.get_id()}' registered.")
        return cls

    @classmethod
    def get_module_specs(cls, module_type: Optional[ModuleType] = None) -> List[ModuleSpec]:
        cls.__assert_initialized()

        _result: List[ModuleSpec] = []
        for _module_spec in cls.__specs_by_id.values():
            if module_type is None or module_type == _module_spec.get_module_type():
                _result.append(_module_spec)

        return _result

    @classmethod
    def get_module_spec(cls, spec_id: str) -> Optional[ModuleSpec]:
        cls.__assert_initialized()

        if spec_id not in cls.__specs_by_id:
            return None
        else:
            return cls.__specs_by_id[spec_id]

    @classmethod
    def __assert_initialized(cls):
        if not cls.__initialized:
            raise Exception("Registry not yet initialized")


class Module:
    @abstractmethod
    def get_id(self) -> str:
        pass

    @abstractmethod
    def get_name(self) -> str:
        pass

    @abstractmethod
    def get_description(self) -> str:
        pass

    @abstractmethod
    def get_tags(self) -> List[Tag]:
        pass

    @abstractmethod
    def get_supported_inputs(self) -> List[DocumentType]:
        pass

    @abstractmethod
    def get_spec(self) -> ModuleSpec:
        pass

    @abstractmethod
    def get_created_at(self) -> datetime:
        pass

    @abstractmethod
    def get_creator(self) -> ShallowUser:
        pass

    @abstractmethod
    def get_modified_at(self) -> datetime:
        pass

    @abstractmethod
    def get_modifier(self) -> ShallowUser:
        pass

    @abstractmethod
    def get_parameter_value(self, spec_parameter: ModuleSpecParameter) -> Optional[str]:
        pass

    def to_dict(self, show_secrets: bool = False):
        result = {
            '__type_name': EntityType.MODULE,
            'id': self.get_id(),
            'name': self.get_name(),
            'description': self.get_description(),
            'specId': self.get_spec().get_id(),
            'tags': [ShallowTag.to_dict(tag) for tag in self.get_tags()],
            'supportedInputs': [document_type.value for document_type in self.get_supported_inputs()],
            'parameters': [
                {
                    'name': parameter_spec.get_name(),
                    'value': self.get_parameter_value(parameter_spec) if not parameter_spec.is_secured() or show_secrets else "************",
                }
                for parameter_spec in self.get_spec().get_parameters()],
            'createdAt': self.get_created_at(),
            'creator': ShallowUser.to_dict(self.get_creator()),
        }
        if self.get_modified_at():
            result['modifiedAt'] = self.get_modified_at()
        if self.get_modifier():
            result['modifier'] = ShallowUser.to_dict(self.get_modifier())

        # --- Add capabilities field ---
        try:
            from maxgpt.services.database_model import ModuleCapabilityRelationModel, ModuleCapabilityModel, database
            capability_relations = database.session.query(ModuleCapabilityRelationModel).filter_by(module_id=self.get_id()).all()
            capabilities = []
            for rel in capability_relations:
                cap_model = database.session.query(ModuleCapabilityModel).filter_by(id=rel.module_capability_id).first()
                if cap_model:
                    capabilities.append({
                        "name": cap_model.name,
                        "label": cap_model.label,
                        "value": rel.value
                    })
            result["capabilities"] = capabilities
        except Exception:
            result["capabilities"] = []
        # --- End capabilities field ---

        return result

    def __eq__(self, __value):
        if isinstance(__value, Module):
            return self.get_id() == __value.get_id()
        return False

    def __hash__(self):
        return self.get_id().__hash__()

    def __repr__(self):
        return f"Module(id={self.get_id()}, name={self.get_name()}, type={self.get_spec().get_module_type()})"
















class ModuleRegistry(abc.ABC):
    """
    This is a singleton acting as cache for modules.
    It works on a single process alone but uses basic cache mechanism to stay in sync with the underlying database.
    That means:
        Read:
            - check already cached instances against existing in the db (using modified_at timestamp)
            - if differs, load from db or remove if the module has been deleted by another process
            - if equal, just return the cached module
        Edit:
            - check already cached instances against existing in the db (using modified_at timestamp)
            - if differs, load from db or remove if the module has been deleted by another process
            - modify provided details on synchronized cached instance
            - Always set modified_at of module in DB, even when just parameters have been changed
        Delete:
            - check already cached instances against existing in the db (using modified_at timestamp)
            - if differs, load from db or remove if the module has been deleted by another process
            - delete if still not already deleted by someone else
    """
    __initialized: bool = False
    __instances_by_type_and_id: Dict[ModuleType, Dict[str, Module]] = {}
    __instances_by_id: Dict[str, Module] = {}

    @classmethod
    def initialize(cls):
        """
        Collects all information about persisted, env provided or kwargs provided modules to create a fresh
        module instance cache.
        """
        if cls.__initialized:
            raise RuntimeError("ModuleRegistry already initialized")
        with (get_named_lock("ModuleRegistry_Class_Lock")):
            if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                logging.debug("MUTEX ACQUIRED: Registry - initialize clean")
            for t in ModuleType:
                cls.__instances_by_type_and_id[t] = {}
            if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                logging.log(logging.DEBUG, "MUTEX RELEASED: Registry - initialize clean")

        # add modules from persistence (note that persistence must be setup before!
        persistent_modules: List[ModuleModel] = ModuleModel.query.all()
        for persistent_module in persistent_modules:
            module_spec = ModuleSpecRegistry.get_module_spec(persistent_module.spec_id)
            if module_spec is None:
                logging.warning(
                    f"Module spec with identifier '{persistent_module.spec_id}' not found in registry. Skipping it.")
            else:
                module_parameters: Dict[str, str] = {}
                for parameter in persistent_module.parameters:
                    module_parameters[parameter.name] = parameter.value

                # This is locking the access to the dicts internally!
                cls.__add_module_instance_for(persistent_module.id,
                                              persistent_module.name,
                                              persistent_module.description,
                                              module_spec,
                                              module_parameters,
                                              persistent_module.tags,
                                              persistent_module.get_supported_inputs(),
                                              persistent_module.created_at,
                                              persistent_module.creator,
                                              persistent_module.modified_at,
                                              persistent_module.modifier)
                logging.info(f"Module '{persistent_module.name}' with id '{persistent_module.id}' registered (init).")

        # add modules based on env properties
        # only one runtime module per spec can be instantiated in dev
        # TODO: disable for production use (but keep it alive for dev!)
        for module_spec in ModuleSpecRegistry.get_module_specs():
            parameters_from_env = cls.__get_parameters_from_env(module_spec)
            if parameters_from_env:
                # Create a hash based on the provided parameters so that the id is stable across environments as long as the configs are the same
                module_id = hashlib.sha3_256((''.join(
                    (param + parameters_from_env[param]) for param in parameters_from_env)).encode()).hexdigest()
                # ok, we found something in the ENV
                logging.info(
                    f"Found environment variables for module spec '{module_spec.get_name()}'. Adding it as in memory module.")

                # TODO: check if already existing and print porper error to remove env parameters for second model
                # This is locking the access to the dicts internally!
                cls.__add_module_instance_for(module_id,
                                              f"In memory (ENV) module for Spec '{module_spec.get_name()}'",
                                              None,
                                              module_spec,
                                              parameters_from_env,
                                              [],
                                              [],
                                              datetime.now(),
                                              SystemUser())
                module_name = f"In memory (ENV) module for Spec '{module_spec.get_name()}'"
                logging.info(f"Module '{module_name}' with id '{module_id}' registered (init with env).")

        with (get_named_lock("ModuleRegistry_Class_Lock")):
            if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                logging.debug("MUTEX ACQUIRED: Registry - initialize finish")
            cls.__initialized = True
            if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                logging.log(logging.DEBUG, "MUTEX RELEASED: Registry - initialize finish")

    @classmethod
    def __assert_initialized(cls):
        if not cls.__initialized:
            raise Exception("Registry not yet initialized")

    @classmethod
    def __assert_latest_instances(cls):
        module_stmt = select(ModuleModel.id)
        db_module_ids = list(database.session.scalars(module_stmt))
        all_module_ids = set(list(cls.__instances_by_id.keys()) + db_module_ids)
        for module_id in all_module_ids:
            cls.__assert_latest_instance(module_id)

    @classmethod
    def __assert_latest_instance(cls, module_id: str):
        """
        Ensure that the module for the given instance id is in sync with the latest changes on the DB and reload sync when it is not.
        """
        cached_module = cls.__instances_by_id.get(module_id, None)
        persistent_module = ModuleModel.query.filter_by(id=module_id).first()
        if ((cached_module is None and persistent_module is not None) or
                (cached_module is not None and persistent_module is None) or
                (cached_module is not None and persistent_module is not None and cached_module.get_modified_at() != persistent_module.modified_at)):
            """
            Remove the outdated instance from cache and add new from db
            """
            module_spec_id = None
            if persistent_module is not None:
                module_spec_id = persistent_module.spec_id
            elif persistent_module is None and cached_module is not None:
                module_spec_id = cached_module.get_spec_id()
            module_spec = ModuleSpecRegistry.get_module_spec(module_spec_id)
            if module_spec is None:
                logging.warning(
                    f"Module spec with identifier '{module_spec_id}' not found in registry. Skipping it.")
            else:
                if cached_module is not None:
                    with (get_named_lock("ModuleRegistry_Class_Lock")):
                        if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                            logging.debug("MUTEX ACQUIRED: Registry - Remove instance from cache")
                        cls.__instances_by_id.pop(module_id)
                        cls.__instances_by_type_and_id[module_spec.get_module_type()].pop(module_id)
                        if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                            logging.debug("MUTEX RELEASED: Registry - Remove instance from cache")

                # This is locking the access to the dicts internally!
                if persistent_module is not None:
                    module_parameters: Dict[str, str] = {}
                    for parameter in persistent_module.parameters:
                        module_parameters[parameter.name] = parameter.value

                    cls.__add_module_instance_for(persistent_module.id,
                                                  persistent_module.name,
                                                  persistent_module.description,
                                                  module_spec,
                                                  module_parameters,
                                                  persistent_module.tags,
                                                  persistent_module.get_supported_inputs(),
                                                  persistent_module.created_at,
                                                  persistent_module.creator,
                                                  persistent_module.modified_at,
                                                  persistent_module.modifier)
                    logging.debug(
                        f"Module '{persistent_module.name}' with id '{persistent_module.id}' synced with db.")

    @staticmethod
    def __get_parameters_from_env(module_spec: ModuleSpec) -> Optional[Dict[str, str]]:
        # we consider a module to be registered if we have at least one of its parameters in the ENV
        found: bool = False

        parameters: Dict[str, str] = {}

        for parameter in module_spec.get_parameters():
            if parameter.get_name() in os.environ:
                found = True
                parameters[parameter.get_name()] = os.environ[parameter.get_name()]
        if found:
            return parameters
        else:
            return None

    @classmethod
    def __add_module_instance_for(cls, module_id: str, module_name: str, module_description: str | None,
                                  module_spec: ModuleSpec,
                                  module_parameters: Dict[str, str],
                                  module_tags: List[Tag],
                                  module_supported_inputs: List[DocumentType],
                                  module_created_at: datetime, module_creator: ShallowUser,
                                  module_modified_at: datetime = None, module_modifier: ShallowUser = None) -> Module:
        """
        Adds a new module instance to the registry's in memory cache structures.

        Returns: the new module instance
        """
        module: Optional[Module] = None
        try:
            # Fetch capabilities for this module from the relation table
            from maxgpt.services.database_model import ModuleCapabilityRelationModel, ModuleCapabilityModel, database
            capability_relations = database.session.query(ModuleCapabilityRelationModel).filter_by(module_id=module_id).all()
            capabilities = {}
            for rel in capability_relations:
                cap_model = database.session.query(ModuleCapabilityModel).filter_by(id=rel.module_capability_id).first()
                if cap_model:
                    capabilities[cap_model.name] = rel.value
            # Try to pass capabilities to the module's constructor if supported
            try:
                module = module_spec.get_runtime()(module_id, module_name, module_description, module_parameters,
                                                   module_tags,
                                                   module_supported_inputs,
                                                   module_created_at, module_creator, module_modified_at,
                                                   module_modifier,
                                                   capabilities=capabilities)
            except TypeError:
                # fallback for modules that don't accept capabilities
                module = module_spec.get_runtime()(module_id, module_name, module_description, module_parameters,
                                                   module_tags, module_supported_inputs, module_created_at, module_creator,
                                                   module_modified_at, module_modifier)
        except Exception as e:
            logging.warning("Unable to instantiated module of type '" + module_spec.get_name() + "': " + str(e))

        if module:
            if module.get_id() in cls.__instances_by_id:
                raise ValueError(f"Module with id '{module.get_id()}' already registered.")

            with (get_named_lock("ModuleRegistry_Class_Lock")):
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX ACQUIRED: Registry - Add module instance for")
                cls.__instances_by_id[module.get_id()] = module
                cls.__instances_by_type_and_id[module_spec.get_module_type()][module.get_id()] = module
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX RELEASED: Registry - Add module instance for")

        return module


    @classmethod
    def create_module(
        cls,
        module_name: str,
        module_description: str,
        module_spec: ModuleSpec,
        module_parameters: Dict[str, str],
        module_tags: List[Tag],
        module_supported_inputs: List[DocumentType],
        capabilities: Dict[str, str],
        predefined_module_id: str = None
    ) -> Module:
        cls.__assert_initialized()
        # check that all mandatory parameters are given
        for module_spec_parameter in module_spec.get_parameters():
            if not module_spec_parameter.get_optional():
                if not module_parameters.get(module_spec_parameter.get_name()):
                    raise Exception(
                        f"Module spec '{module_spec.get_name()}' requires parameter with name '{module_spec_parameter.get_name()}' to be set")

        persistent_module = ModuleModel(id=(predefined_module_id if predefined_module_id else None), name=module_name, description=module_description, spec_id=module_spec.get_id())
        for parameter_name in module_parameters.keys():
            # fails if parameter is not supported
            if module_spec.get_parameter(parameter_name):
                # TODO: validate that value can be marshalled to expected type
                parameter = ModuleParameterModel(name=parameter_name,
                                                 value=module_parameters[parameter_name])
                persistent_module.parameters.append(parameter)
            else:
                raise Exception(
                    f"Module spec '{module_spec.get_name()}' supports no parameter with name '{parameter_name}'")

        if len(module_tags) > 0:
            persistent_module.tag_relations = []
            for tag in module_tags:
                persistent_module.tag_relations.append(
                    ModuleTagRelationModel(module_id=persistent_module.id, tag_id=tag.get_id()))

        persistent_module.set_supported_inputs(module_supported_inputs)

        with current_app.app_context():
            database.session.add(persistent_module)
            database.session.commit()

            # NEW: Handle capabilities AFTER module is committed and has an ID
            for cap_name, cap_value in capabilities.items():
                cap_model = database.session.query(ModuleCapabilityModel).filter_by(name=cap_name).first()
                if not cap_model:
                    raise Exception(f"Capability '{cap_name}' not found")
                relation = ModuleCapabilityRelationModel(
                    module_id=persistent_module.id,
                    module_capability_id=cap_model.id,
                    value=cap_value
                )
                database.session.add(relation)
            
            database.session.commit()

            # store went through, so add instance to registry
            # locking is done internally inside the function
            result = cls.__add_module_instance_for(persistent_module.id, persistent_module.name, persistent_module.description, module_spec,
                                                 module_parameters,
                                                 persistent_module.tags,
                                                 persistent_module.get_supported_inputs(),
                                                 persistent_module.created_at, persistent_module.creator)
            return result

    @classmethod
    def update_module(cls, module_id: str, module_name: str, module_description: str,
                      module_parameters: Dict[str, str], module_tags: List[Tag], module_supported_inputs: List[DocumentType], capabilities: Dict[str, str] = None) -> Module:
        cls.__assert_initialized()
        cls.__assert_latest_instance(module_id)

        # load existing from db
        with current_app.app_context():
            persistent_module: Optional[ModuleModel] = ModuleModel.query.get(module_id)
            if persistent_module is None:
                raise Exception(f"No module found for identifier '{module_id}'")

            module_spec = ModuleSpecRegistry.get_module_spec(persistent_module.spec_id)

            # check that all mandatory parameters are given
            for module_spec_parameter in module_spec.get_parameters():
                if not module_spec_parameter.get_optional():
                    if not module_parameters.get(module_spec_parameter.get_name()):
                        raise Exception(
                            f"Module spec '{module_spec.get_name()}' requires parameter with name '{module_spec_parameter.get_name()}' to be set")

            if persistent_module.name != module_name:
                persistent_module.name = module_name
            if persistent_module.description != module_description:
                persistent_module.description = module_description

            current_parameter_by_name: Dict[str, ModuleParameterModel] = {parameter.name: parameter for parameter in
                                                                          persistent_module.parameters}
            # add or update existing parameter
            for parameter_name in module_parameters.keys():
                # fails if parameter is not supported
                if module_spec.get_parameter(parameter_name):
                    # TODO: validate that value can be marshalled to expected type
                    current_parameter = current_parameter_by_name.get(parameter_name)
                    if current_parameter:
                        # update if it exists AND if it has changed
                        if current_parameter.value != module_parameters[parameter_name]:
                            current_parameter.value = module_parameters[parameter_name]
                    else:
                        # does not exist add new
                        persistent_module.parameters.append(
                            ModuleParameterModel(name=parameter_name,
                                                 value=module_parameters[parameter_name]))
                else:
                    raise Exception(
                        f"Module spec '{module_spec.get_name()}' supports no parameter with name '{parameter_name}'")
            # remove all parameters that are no longer set
            for parameter in current_parameter_by_name.values():
                if not module_parameters.get(parameter.name):
                    persistent_module.parameters.remove(parameter)

            tag_relations_by_id = {relation.tag_id: relation for relation in persistent_module.tag_relations}

            for tag in module_tags:
                tag_id = tag.get_id()
                if tag_id in tag_relations_by_id:
                    # still mapped, just remove it to find orphans
                    tag_relations_by_id.pop(tag_id)
                else:
                    persistent_module.tag_relations.append(
                        ModuleTagRelationModel(module_id=persistent_module.id, tag_id=tag_id))

            persistent_module.set_supported_inputs(module_supported_inputs)
            # WE MUST ENSURE THAT THE PARENT MODULE IS UPDATED, EVEN IF JUST THE PARAMETERS HAVEN BEEN UPDATED
            persistent_module.modified_at = func.now()

            # remove leftovers
            for relation in tag_relations_by_id.values():
                database.session.delete(relation)

            # --- Capabilities update logic (NEW) ---
            if capabilities is not None:
                from maxgpt.services.database_model import ModuleCapabilityRelationModel, ModuleCapabilityModel
                # Remove all existing capability relations for this module
                database.session.query(ModuleCapabilityRelationModel).filter_by(module_id=module_id).delete()
                # Add new capability relations
                for cap_name, cap_value in capabilities.items():
                    cap_model = database.session.query(ModuleCapabilityModel).filter_by(name=cap_name).first()
                    if not cap_model:
                        raise Exception(f"Capability '{cap_name}' not found")
                    relation = ModuleCapabilityRelationModel(
                        module_id=module_id,
                        module_capability_id=cap_model.id,
                        value=cap_value
                    )
                    database.session.add(relation)
            # --- End capabilities update logic ---

            database.session.commit()

            # update went through, so remove old and add new instance to registry
            with (get_named_lock("ModuleRegistry_Class_Lock")):
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX ACQUIRED: Registry - update module")
                cls.__instances_by_id.pop(persistent_module.id)
                cls.__instances_by_type_and_id[module_spec.get_module_type()].pop(persistent_module.id)
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX RELEASED: Registry - update module")

            result = cls.__add_module_instance_for(persistent_module.id, persistent_module.name, persistent_module.description,
                                                 module_spec, module_parameters,
                                                 persistent_module.tags,
                                                 persistent_module.get_supported_inputs(),
                                                 persistent_module.created_at, persistent_module.creator,
                                                 persistent_module.modified_at, persistent_module.modifier)

            return result

    @classmethod
    def delete_module(cls, module_id: str) -> Module:
        cls.__assert_initialized()
        cls.__assert_latest_instance(module_id)

        # load existing from db
        _module: Optional[ModuleModel] = ModuleModel.query.get(module_id)
        if _module is None:
            raise Exception(f"No module found for identifier '{module_id}'")

        module_spec = ModuleSpecRegistry.get_module_spec(_module.spec_id)
        with current_app.app_context():
            session = Session.object_session(_module)
            # Delete all capability relations for this module before deleting the module itself
            session.query(ModuleCapabilityRelationModel).filter_by(module_id=_module.id).delete()
            session.delete(_module)
            session.commit()

            with (get_named_lock("ModuleRegistry_Class_Lock")):
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX ACQUIRED: Registry - delete module")
                deleted_module = cls.__instances_by_id.pop(_module.id)
                cls.__instances_by_type_and_id[module_spec.get_module_type()].pop(_module.id)
                if os.getenv("APP_ENABLE_LOCK_TRACE", 'False').lower() in ('true', '1', 't'):
                    logging.debug("MUTEX RELEASED: Registry - delete module")

            return deleted_module

    @classmethod
    def get_modules(cls, module_type: Optional[ModuleType] = None) -> List[Module]:
        """
        Fetches all current module instances
        """
        cls.__assert_initialized()
        cls.__assert_latest_instances()

        # make copy
        if module_type:
            return list(cls.__instances_by_type_and_id[module_type].values())
        else:
            return list(cls.__instances_by_id.values())

    @classmethod
    def get_module(cls, module_id: str) -> Optional[Module]:
        """
        Fetches the current module instance for the given identifier
        """
        cls.__assert_initialized()
        cls.__assert_latest_instance(module_id)

        return cls.__instances_by_id.get(module_id)
