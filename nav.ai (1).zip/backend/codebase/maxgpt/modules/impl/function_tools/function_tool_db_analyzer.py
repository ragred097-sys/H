from llama_index.tools.database import DatabaseToolSpec
from sqlalchemy import create_engine

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class FunctionToolDbAnalyzer(AbstractFunctionTool):

    __uri_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_URI",
        label="A valid connection string URI",
        description="A complete connection string to your db. Replaces all other parameters.",
        optional=True,
        data_type=DataType.TEXT)

    __scheme_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_SCHEME",
        label="The db provider",
        description="The db provider (e.g. postgresql).",
        optional=True,
        default="postgresql",
        data_type=DataType.TEXT)

    __host_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_HOST",
        label="The host of your db",
        description="The host of your db",
        optional=True,
        data_type=DataType.TEXT)

    __porrt_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_PORT",
        label="The port of your db",
        description="The port of your db",
        optional=True,
        data_type=DataType.INTEGER)

    __db_user_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_USER",
        label="DB user",
        description="The username of your db",
        optional=True,
        data_type=DataType.TEXT)

    __db_password_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_PASSWORD",
        label="DB password",
        description="The password for the user of your db",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __db_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_DB_ANALYZER_DB_NAME",
        label="DB name",
        description="The name of your db",
        optional=True,
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__uri_conf, cls.__db_name_conf, cls.__db_user_conf, cls.__db_password_conf, cls.__host_conf, cls.__porrt_conf, cls.__scheme_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "ccbf7a99-02af-4ab2-9151-5ea5f077c897"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Database Analyzer"

    @classmethod
    def get_spec_description(cls) -> str:
        return "This tool enables you to get information about tables in your database, to fetch table structures and also to fetch data directly."


    def get_tools(self):
        if self.get_parameter_value(self.__uri_conf):
            db_spec = DatabaseToolSpec(
                uri=self.get_parameter_value(self.__uri_conf)
            )
        else:
            db_spec = DatabaseToolSpec(
                scheme=self.get_parameter_value(self.__scheme_conf),
                host=self.get_parameter_value(self.__host_conf),
                port=self.get_parameter_value(self.__porrt_conf),
                user=self.get_parameter_value(self.__db_user_conf),
                password=self.get_parameter_value(self.__db_password_conf),
                dbname=self.get_parameter_value(self.__db_name_conf),
            )
        return db_spec.to_tool_list()

