import logging

from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter 


class FunctionToolEmailSender(AbstractFunctionTool):
    __server_user_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_SERVER_USER",
        label="Username for authentication.",
        description="Username for authentication.",
        optional=False,
        data_type=DataType.TEXT)

    __server_host_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_SENDER_SERVER_HOST",
        label="SMTP Server of the sender provider",
        description="SMTP Server of the sender provider.",
        optional=False,
        data_type=DataType.TEXT)

    __server_port_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_SENDER_SERVER_PORT",
        label="SMTP Server port of the sender provider",
        description="SMTP Server port of the sender provider.",
        optional=False,
        data_type=DataType.INTEGER)

    __server_password_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_SENDER_PASSWORD",
        label="Password for server authentication.",
        description="Password for server authentication",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)

    __sender_email_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_SENDER_EMAIL",
        label="Email of the sender.",
        description="Email address of the sender.",
        optional=False,
        data_type=DataType.TEXT)

    __is_html_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_EMAIL_IS_HTML",
        label="Email Body is HTML?",
        description="Set to true to send the email as HTML, or false for plain text.",
        optional=True,
        data_type=DataType.BOOLEAN,
        default=True
    )

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__sender_email_conf, cls.__server_password_conf, cls.__server_host_conf, cls.__server_port_conf, cls.__server_user_conf, cls.__is_html_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "8e56e8b7-c012-4700-a520-16de8e51cda3"

    @classmethod
    def get_spec_name(cls) -> str:
        return "E-Mail sender"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A tool to send emails using the configured SMTP server."

    async def send_email(self, ctx: Context, receiver_email: str, subject: str, body: str, **kwargs):
        """
            Sends an email.

            Args:
                receiver_email (str): The recipient's email address.
                subject (str): The subject of the email.
                body (str): The body of the email. 

            Output:
                No output

            State Update:
                No state change
            """
        from smtplib import SMTPAuthenticationError
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        import smtplib


        try:
            message = MIMEMultipart("alternative")
            message["From"] = self.get_parameter_value(self.__sender_email_conf)
            message["To"] = receiver_email
            message["Subject"] = subject

            is_html = str(self.get_parameter_value(self.__is_html_conf)).lower() == "true"  
            if is_html: 
                html_body = f"<html><body>{body}</body></html>" if not body.startswith('<html>') else body
                part = MIMEText(html_body, "html")
            else:  
                part = MIMEText(body, "plain")
            message.attach(part)

            host = self.get_parameter_value(self.__server_host_conf)
            port = int(self.get_parameter_value(self.__server_port_conf))
            auth_user = self.get_parameter_value(self.__server_user_conf)
            auth_password = self.get_parameter_value(self.__server_password_conf)
            sender_email = self.get_parameter_value(self.__sender_email_conf)

            if port == 587:
                # STARTTLS
                logging.log(logging.INFO, f"{auth_user} {auth_password} {sender_email} {host} {port} {receiver_email}")
                with smtplib.SMTP(host, port) as server:
                    server.ehlo()
                    server.starttls()
                    server.ehlo()
                    server.login(auth_user, auth_password)
                    server.sendmail(sender_email, receiver_email, message.as_string())
            else:
                # SMTP_SSL
                with smtplib.SMTP_SSL(host, port) as server:
                    server.login(auth_user, auth_password)
                    server.sendmail(sender_email, receiver_email, message.as_string())
        except SMTPAuthenticationError as e:
            logging.log(logging.ERROR, "Error: SMTP authentication failed. Check your email and password.")
            logging.log(logging.ERROR, f"{e}")
            raise e
        except Exception as e:
            logging.log(logging.ERROR, f"An error occurred: {e}")
            raise e


    def get_tools(self):
        return [FunctionTool.from_defaults(fn=self.send_email)]

