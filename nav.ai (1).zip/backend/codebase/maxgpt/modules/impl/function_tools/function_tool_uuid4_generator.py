from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class FunctionToolUUID4Generator(AbstractFunctionTool):

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return []

    @classmethod
    def get_spec_id(cls) -> str:
        return "d955899d-101c-4e77-bb6b-d6238ac9bb6a"

    @classmethod
    def get_spec_name(cls) -> str:
        return "UUID4 Generator Tool"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A tool to generate new UUID4 values using remote API calls."

    async def get_uuids(self, ctx: Context, number_of_ids: int = 1, **kwargs):
        """
        Generate a set of UUIDs using the free api of https://www.uuidtools.com/.

        Args:
                number_of_ids (int): The number of UUIDs to generate

        Output:
                Returns the an json array of newly created uuids.

        State Update:
            No state change
        """
        import requests
        result = requests.get(f"https://www.uuidtools.com/api/generate/v4/count/{number_of_ids}").json()
        return result

    def get_tools(self):
        return [FunctionTool.from_defaults(fn=self.get_uuids)]

