from llama_index.tools.google import GoogleSearchToolSpec

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class FunctionToolGoogleWebSearch(AbstractFunctionTool):

    __api_key_url: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_GOOGLE_WEB_SEARCH_API_KEY",
        label="Your google API key",
        description="Google API key to access your Google search engines.",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __engine_id_url: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_GOOGLE_WEB_ENGINE_ID",
        label="Your google search engine ID",
        description="Your Google search engine ID.",
        optional=True,
        secured=False,
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_url, cls.__engine_id_url]

    @classmethod
    def get_spec_id(cls) -> str:
        return "f591d80c-9fa2-44f4-8ac1-add358022cf7"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Google Web Search"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A tool that leverages google search apis to load data from the web."

    def get_tools(self):
        api_key = self.get_parameter_value(self.__api_key_url)
        search_engine_id = self.get_parameter_value(self.__engine_id_url)
        tool_spec = GoogleSearchToolSpec(key=api_key, engine=search_engine_id)
        return tool_spec.to_tool_list()

