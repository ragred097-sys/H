from llama_index.tools.wolfram_alpha import WolframAlphaToolSpec

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class FunctionToolWolframAlpha(AbstractFunctionTool):

    __api_key: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_WOLFRAM_ALPHA_API_KEY",
        label="Api key of your wolfram alpha account",
        description="Api key of your wolfram alpha account",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key]

    @classmethod
    def get_spec_id(cls) -> str:
        return "b0331bc5-9115-4c4f-a1e5-2952e9f7ddf3"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Wolfram Alpha"

    @classmethod
    def get_spec_description(cls) -> str:
        return "This tool uses wolfram alpha to perform mathematical calculations."

    def get_tools(self):
        wolfram_spec = WolframAlphaToolSpec(app_id=self.get_parameter_value(self.__api_key))
        return wolfram_spec.to_tool_list()

