from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class AzureLocationToGeoCodeConverter(AbstractFunctionTool):

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_AZURE_LOC_GEOCODE_CONVERTER_API_KEY",
        label="Azure Maps API Key",
        description="The access token or api key to access your Azure Maps Account.",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)

    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_AZURE_LOC_GEOCODE_CONVERTER_BASE_URL",
        label="Azure Maps API Base URL",
        description="The base url for the Azure Maps API.",
        optional=True,
        default="https://atlas.microsoft.com/search/address/json",
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf, cls.__base_url_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "e7bd47b1-3be4-498a-ba12-ca1900241c45"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure Loc. to Geo Code"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A tool to convert a given textual location to Geocode using Azure Maps API."

    async def convert_location_to_geocode(self, ctx: Context, location_name: str, **kwargs):
        """
        This function tool translate location names to geocode information including latitude and longitude.

        Args:
            location_name (str): A string value defining a location in the world. E.g. Luxembourg City

        Output:
            Geocode information as json object (json)

        State Update:
            geoCodeExtracted set to True after completion
        """

        import requests
        current_state = await ctx.get("state")

        params = {
            "api-version": "1.0",
            "query": location_name,
            "subscription-key": self.get_parameter_value(self.__api_key_conf)
        }

        result = requests.get(self.get_parameter_value(self.__base_url_conf), params=params).json()

        current_state["geoCodeExtracted"] = True
        await ctx.set("state", current_state)

        return result


    def get_tools(self):
        return [FunctionTool.from_defaults(fn=self.convert_location_to_geocode)]

