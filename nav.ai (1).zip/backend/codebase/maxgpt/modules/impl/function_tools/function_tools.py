import abc
from typing import Callable, List

from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.modules import ModuleType


class AbstractFunctionTool(AbstractModule):

    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.FUNCTION_TOOL


    @abc.abstractmethod
    def get_spec_description(cls) -> str:
        pass


    @abc.abstractmethod
    def get_tools(self) -> List[FunctionTool]:
        pass


    def get_impl(self) -> List[FunctionTool]:
        return self.get_tools()
