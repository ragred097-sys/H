import json
from typing import Optional

from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter

async def set_state_value(ctx: Context, key: Optional[str], value: Optional[str], **kwargs):
    """
        Updates the state inside the content object shared by all agents.

        Args:
            key (str): The key inside the state json object
            value (str): The new value for the given key in inside the state json object.

        Output:
            Returns the current shared state as json string.

        State Update:
            Updated according to the given arguments if args are provided.
        """
    current_state = await ctx.get("state")
    if key and value:
        current_state[key] = value
        await ctx.set("state", current_state)
    return current_state

async def get_state_value(ctx: Context, key: Optional[str], **kwargs):
    """
        Reads a value from the state inside the content object shared by all agents

        Args:
            key (str): The key inside the state json object

        Output:
            Returns the value of the provided key from inside the shared state if the key exists, else None.

        State Update:
            No update is performed.
        """
    current_state = await ctx.get("state")
    if key in current_state:
        return current_state[key]
    else:
        return None

async def get_state(ctx: Context, **kwargs):
    """
        Reads the full state inside the content object shared by all agents

        Args:

        Output:
            Returns the full state object as json string

        State Update:
            No update is performed.
        """
    current_state = await ctx.get("state")
    return json.dumps(current_state)

def get_tools():
    return [FunctionTool.from_defaults(fn=set_state_value),
            FunctionTool.from_defaults(fn=get_state_value),
            FunctionTool.from_defaults(fn=get_state)]


class FunctionToolStateUpdater(AbstractFunctionTool):

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return []

    @classmethod
    def get_spec_id(cls) -> str:
        return "0f1b51aa-b13a-4be9-96c2-cf9322fc5b80"

    @classmethod
    def get_spec_name(cls) -> str:
        return "State Updater"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A set of basic tools to modify the shared state between agents."

    def get_tools(self):
        return get_tools()

