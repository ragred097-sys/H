import asyncio
from typing import Callable, Any

from llama_index.core.tools import FunctionTool
from llama_index.tools.mcp import BasicMCPClient, McpToolSpec

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class FunctionToolMcp(AbstractFunctionTool):

    __mcp_server_url: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_MCP_SERVER_URL",
        label="MCP Server URL",
        description="The url of the MCP server you want to integrate.",
        optional=False,
        data_type=DataType.URL)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__mcp_server_url]

    @classmethod
    def get_spec_id(cls) -> str:
        return "14849239-92eb-4962-ad69-6d0cf0698aec"

    @classmethod
    def get_spec_name(cls) -> str:
        return "MCP Tools"

    @classmethod
    def get_spec_description(cls) -> str:
        return "This tool fetches function from a MCP server and creates a list of FunctionTool instances to extend agent capabilities with the remote MCP functions."


    async def get_tools(self):
        mcp_client = BasicMCPClient(self.get_parameter_value(self.__mcp_server_url))
        mcp_tool = McpToolSpec(client=mcp_client)
        return await mcp_tool.to_tool_list_async()

