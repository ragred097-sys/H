from typing import Callable

from llama_index.core.tools import FunctionTool
from llama_index.core.workflow import Context

from maxgpt.core import DataType
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.modules import ModuleSpecParameter


class AzureWeatherConditionProvider(AbstractFunctionTool):

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_AZURE_WEATHER_CONDITION_API_KEY",
        label="Azure Maps API Key",
        description="The access token or api key to access your Azure Maps Account.",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)

    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FT_AZURE_WEATHER_CONDITION_BASE_URL",
        label="Azure Maps API Base URL",
        description="The base url for the Azure Maps API.",
        optional=True,
        default="https://atlas.microsoft.com/weather/currentConditions/json",
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf, cls.__base_url_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "27150404-d388-480d-9a99-5cddac27375e"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure Weather Condition API"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A tool to call Azure Weather API for fetching current weather conditions."

    async def fetch_current_weather_condition(self, ctx: Context, latitude: float, longitude: float, unit: str = "metric", **kwargs) -> Callable:
        """
        This function tool uses 3 parameters, 'latitude', 'longitude' and 'unit' to fetch current weather condition from the Azure Maps API.
        The result is a json object following the structure of the Azure Maps API Versio 1.0.

        Args:
            latitude (float): A latitude value in decimal degrees.
            longitude (float): A longitude value in decimal degrees.
            unit (str [metric|imperial): metric or imperial as string. The default is 'metric'

        Output:
            Current weather condition information as json object (json)

        State Update:
            weatherReceived set to True after completion
        """

        import requests
        current_state = await ctx.get("state")

        params = {
            "api-version": "1.0",
            "query": f"{latitude},{longitude}",
            "subscription-key": self.get_parameter_value(self.__api_key_conf),
            "unit": unit
        }

        result = requests.get(self.get_parameter_value(self.__base_url_conf), params=params).json()

        # This is more a test to provide a template for you
        current_state["weatherReceived"] = True
        await ctx.set("state", current_state)

        return result


    def get_tools(self):
        return [FunctionTool.from_defaults(fn=self.fetch_current_weather_condition)]

