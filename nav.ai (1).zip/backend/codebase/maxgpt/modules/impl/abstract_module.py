from __future__ import annotations

import abc
import datetime
import logging
from typing import Dict, Optional, List

from maxgpt.modules.modules import ModuleSpecParameter, Module, ModuleSpecFactory, ModuleSpec, \
    ModuleSpecRegistry
from maxgpt.services import Tag
from maxgpt.services.database_model import DocumentType
from maxgpt.services.internal import ShallowTag
from maxgpt.services.security import ShallowUser, User


class AbstractModule(abc.ABC, ModuleSpecFactory, Module):
    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag],
                 module_supported_inputs: List[DocumentType],
                 module_created_at: datetime, module_creator: User,
                 module_modified_at: datetime, module_modifier: User):
        self.__id = module_id
        self.__name = module_name
        self.__description = module_description if module_name is not None else self.get_spec().get_description()
        self.__parameters_by_spec: Dict[ModuleSpecParameter, str] = {}
        # create copy to avoid having database model instance
        self.__tags = [ShallowTag(tag.get_id(), tag.get_name()) for tag in module_tags]
        self.__supported_inputs = module_supported_inputs
        self.__created_at = module_created_at
        self.__creator = ShallowUser(module_creator.get_id(), module_creator.get_display_name())
        self.__modified_at = module_modified_at
        self.__modifier = ShallowUser(module_modifier.get_id(), module_modifier.get_display_name()) if module_modifier else None

        unused_module_parameters = list(module_parameters.keys())
        for spec_parameter in self.get_spec_parameters():
            # Check if a parameter value for the spec parameter is provided
            if spec_parameter.get_name() in module_parameters:
                self.__parameters_by_spec[spec_parameter] = module_parameters[spec_parameter.get_name()]
                unused_module_parameters.remove(spec_parameter.get_name())
            # If not provide, check if the spec parameter is either optional or has a default set. Both cases are valid
            elif not spec_parameter.get_optional() and spec_parameter.get_default() is None:
                # check for missing mandatory parameters
                raise Exception(f"Mandatory parameter '{spec_parameter.get_name()}' is missing")

        # write warning for given parameters that do not exist
        for unused_module_parameter in unused_module_parameters:
            logging.info(f"Value for not existing parameter '{unused_module_parameter}' specified.")

    def get_parameter_value(self, spec_parameter: ModuleSpecParameter) -> Optional[str]:
        if self.__parameters_by_spec.get(spec_parameter):
            return self.__parameters_by_spec[spec_parameter]
        else:
            return spec_parameter.get_default()

    def get_id(self) -> str:
        return self.__id

    def get_name(self) -> str:
        return self.__name

    def get_description(self) -> str:
        return self.__description

    def get_spec(self) -> ModuleSpec:
        return ModuleSpecRegistry.get_module_spec(self.get_spec_id())

    def get_tags(self) -> List[Tag]:
        return self.__tags

    def get_supported_inputs(self) -> List[DocumentType]:
        return self.__supported_inputs

    def get_created_at(self) -> datetime:
        return self.__created_at

    def get_creator(self) -> ShallowUser:
        return self.__creator

    def get_modified_at(self) -> datetime:
        return self.__modified_at

    def get_modifier(self) -> ShallowUser:
        return self.__modifier

    @abc.abstractmethod
    def get_impl(self) -> any:
        pass
