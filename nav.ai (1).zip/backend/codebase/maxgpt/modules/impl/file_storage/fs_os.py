import os
from typing import BinaryIO

from flask import current_app
from maxgpt.core import DataType
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services.database_model import FileStorageFileSystem
from werkzeug.utils import secure_filename



class FSOperatingSystem(AbstractFileStorage):

    __base_path_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_OS_BASE_PATH",
        label="Base Path",
        description="Path to the root folder to store ingested files.",
        default="./ingested_files",
        optional=True,
        data_type=DataType.TEXT)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_path_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "b3a6b442-8123-49ee-b379-9ee1ff9099ae"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Local File System"

    @classmethod
    def get_spec_description(cls) -> str:
        return "File storage that stores files on a local disc or a mount point."

    def read(self, filename: str) -> BinaryIO:
        os.makedirs(os.path.dirname(self.get_url_for_filename(filename)), exist_ok=True)
        return open(self.get_url_for_filename(filename), 'rb')

    def write(self, filename: str, binary_data: bytes, **kwargs):
        os.makedirs(os.path.dirname(self.get_url_for_filename(filename)), exist_ok=True)
        with open(self.get_url_for_filename(filename), "wb") as binary_file:
            binary_file.write(binary_data)
        return FileStorageObject(reference_id=filename, url=self.get_url_for_filename(filename))

    def get_file_system(self) -> FileStorageFileSystem:
        return FileStorageFileSystem.OS

    def get_impl(self):
        return self

   
    @staticmethod
    def is_path_forbidden(path: str) -> bool:
        FORBIDDEN_PATHS = [
        "/bin", "/sbin", "/etc", "/lib", "/lib64",
        "/boot", "/dev", "/proc", "/sys",
        ".",".."
        ]
        abs_path = os.path.abspath(path).lower()

    # Check against forbidden system paths
        for forbidden in FORBIDDEN_PATHS:
            forbidden_abs = os.path.abspath(forbidden).lower()
            if abs_path == forbidden_abs or abs_path.startswith(forbidden_abs + os.sep):
                return True

        # Explicitly reject raw "." and ".." (not their resolved form)
        raw = path.strip().replace("\\", "/")
        if raw in [".", ".."]:
            return True
        

        return False
    
    def get_url_for_filename(self, filename: str) -> str:
        base_path = os.path.abspath(self.get_parameter_value(self.__base_path_conf))
    
        # Validate the base path
        if self.is_path_forbidden(base_path):
            raise ValueError(f"Base path '{base_path}' is forbidden.")
    
        # Resolve the full path using the given filename (not secured)
        full_path = os.path.abspath(os.path.join(base_path, filename))
    
        # Prevent access outside the base path
        if not full_path.startswith(base_path + os.sep):
            raise ValueError("Path traversal attempt detected.")
    
        # Final forbidden path check
        if self.is_path_forbidden(full_path):
            raise ValueError(f"Access to path '{full_path}' is not allowed.")
    
        return full_path


    
    
    
