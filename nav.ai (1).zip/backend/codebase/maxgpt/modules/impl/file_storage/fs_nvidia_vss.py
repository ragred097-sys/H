import io
import logging
import math
import os.path

import requests

from maxgpt.core import DataType
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services.database_model import FileStorageFileSystem


class FSNvidiaVss(AbstractFileStorage):
    __vss_uri: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_URI",
        label="NVIDIA VSS API base URI",
        description="The API endpoint for Nvidia VSS.",
        optional=False,
        data_type=DataType.TEXT)

    __vss_model: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_MODEL",
        label="NVIDIA VSS model",
        description="The model to be used for VSS operations",
        optional=True,
        default="nvila",
        data_type=DataType.TEXT)

    __vss_model_temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_MODEL_TEMPERATURE",
        label="Model Temperature",
        description="The model temperature to use for query and summarize.",
        optional=True,
        default="0.2",
        data_type=DataType.FLOAT)

    __vss_sum_prompt: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_SUM_PROMPT",
        label="Summary Prompt",
        description="The summary prompt for summarizing video content.",
        optional=True,
        default="Write a verbose caption for the provided video.",
        data_type=DataType.TEXT)

    __vss_caption_prompt: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_CAPTION_PROMPT",
        label="Caption Prompt",
        description="The caption prompt for summarizing video content.",
        optional=True,
        default="Write a verbose caption for the provided video.",
        data_type=DataType.TEXT)

    __vss_sum_aggregation_prompt: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_SUM_AGGREGATION_PROMPT",
        label="Summary Aggregation Prompt",
        description="The summary aggregation prompt for summarizing video content.",
        optional=True,
        default="Write a verbose summary for the provided content.",
        data_type=DataType.TEXT)

    __vss_num_chunks: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_NVIDIA_VSS_num_chunks",
        label="Number of chunks",
        description="The expected number of chunks for summarizing video content. Defaults to 5.",
        optional=True,
        default="5",
        data_type=DataType.INTEGER)

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__vss_uri, cls.__vss_model]

    @classmethod
    def get_spec_id(cls) -> str:
        return "df96ca9b-45ad-478d-8acd-91d2ae38c9b6"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Nvidia VSS Video Storage"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Filestorage based on Nvidia VSS Video Storage"

    def summarize_video(self, video_id: str, chunk_duration: int=10):
        chunk_overlap_duration = math.ceil(1.0 / 15.0 * chunk_duration) if math.ceil(
            1.0 / 15.0 * chunk_duration) < chunk_duration else chunk_duration - 1

        payload = {
            "id": video_id,
            "prompt": self.get_parameter_value(self.__vss_sum_prompt),
            "model": self.get_parameter_value(self.__vss_model),
            "api_type": "internal",
            "response_format": {
                "type": "text"
            },
            "stream": False,
            "stream_options": {
                "include_usage": False
            },
            "max_tokens": 512,
            "temperature": float(self.get_parameter_value(self.__vss_model_temperature)),
            "top_p": 1,
            "top_k": 100,
            "seed": 10,
            "chunk_duration": chunk_duration,
            "chunk_overlap_duration": chunk_overlap_duration,
            "summary_duration": 60,
            "media_info": {
                "type": "offset",
                "start_offset": 0,
                "end_offset": 4000000000
            },
            "user": "user-123",
            "caption_summarization_prompt": self.get_parameter_value(self.__vss_caption_prompt),
            "summary_aggregation_prompt": self.get_parameter_value(self.__vss_sum_aggregation_prompt),
            "graph_rag_prompt_yaml": "",
            "tools": [],
            "summarize": True,
            "enable_chat": True,
            "enable_chat_history": True,
            "enable_cv_metadata": False,
            "cv_pipeline_prompt": "person . car . bicycle;0.5",
            "num_frames_per_chunk": 10,
            "vlm_input_width": 256,
            "vlm_input_height": 256,
            "enable_audio": False,
            "summarize_batch_size": 5,
            "rag_type": "graph-rag",
            "rag_top_k": 5,
            "rag_batch_size": 5,
            "summarize_max_tokens": 512,
            "summarize_temperature": 0.2,
            "summarize_top_p": 1,
            "chat_max_tokens": 512,
            "chat_temperature": 0.2,
            "chat_top_p": 1,
            "notification_max_tokens": 512,
            "notification_temperature": 0.2,
            "notification_top_p": 1
        }

        logging.log(logging.WARNING, "Automatic summary generation will be executed with the following payload.")
        logging.log(logging.DEBUG, payload)

        api_response = requests.post(
            self.get_parameter_value(self.__vss_uri) + "/summarize",
            json=payload)

        if api_response.status_code != 200: # Check if the response is valid
            logging.log(logging.ERROR, f"Error response from summarize endpoint: {api_response.text}")
            raise ValueError(f"There was an error from VSS summarize endpoint. Please contact the administrator. {api_response.text}")
        summary_response = api_response.json()["choices"][0]['message']['content']
        logging.log(logging.DEBUG, summary_response)
        return summary_response

    def get_all_files(self, purpose: str = "vision"):
        list_of_files = requests.get(
            f"{self.get_parameter_value(self.__vss_uri)}/files?purpose={purpose}"
        )
        return list_of_files.json()

    def delete(self, vss_file_id: str):
        response = requests.delete(
            self.get_url_for_filename(vss_file_id)
        )
        return response

    def read_metadata(self, vss_file_id: str):
        response = requests.get(
            self.get_url_for_filename(vss_file_id)
        )
        return response

    def read(self, vss_file_id: str) -> io.BytesIO:
        response = requests.get(
            f"{self.get_url_for_filename(vss_file_id)}/content"
        )
        return io.BytesIO(response.content) # returning a file-like object

    def write(self, filename: str, binary_data: bytes, **kwargs) -> FileStorageObject:

        if "purpose" in kwargs:
            purpose = kwargs["purpose"]
        else:
            purpose = "vision"

        if "media_type" in kwargs:
            media_type = kwargs["media_type"]
        else:
            media_type = "video"

        if "media_length" in kwargs:
            media_length = kwargs["media_length"]
            chunk_duration = math.ceil(media_length / int(self.get_parameter_value(self.__vss_num_chunks)))
        else:
            chunk_duration = 10

        filename_split = filename.split(os.path.sep)
        multipart_form_data = {
            'purpose': (None, purpose),
            'media_type': (None, media_type),
            'file': (filename_split[len(filename_split)-1], binary_data)
        }
        response = requests.post(
            f"{self.get_parameter_value(self.__vss_uri)}/files",
            files=multipart_form_data
        )
        if response.ok:
            video_id = response.json()['id']
            summary_value = self.summarize_video(video_id=video_id, chunk_duration=chunk_duration)
            return FileStorageObject(reference_id=video_id, url=self.get_url_for_filename(video_id), details=summary_value)
        else:
            raise ValueError(response.json().get('message'))

    def get_file_system(self) -> FileStorageFileSystem:
        return FileStorageFileSystem.NVIDIA_VSS

    def get_url_for_filename(self, vss_file_id: str) -> str:
        return f"{self.get_parameter_value(self.__vss_uri)}/files/{vss_file_id}"

    def get_impl(self):
        return self