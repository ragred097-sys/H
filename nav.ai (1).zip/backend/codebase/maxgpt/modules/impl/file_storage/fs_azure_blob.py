from azure.storage.blob import BlobServiceClient

from maxgpt.core import DataType
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services.database_model import FileStorageFileSystem


class FSAzureBlobStorage(AbstractFileStorage):

    __blob_storage_account_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_AZURE_BLOB_STORAGE_ACCOUNT",
        label="Account Name",
        description="The storage account name that contains your blob container.",
        optional=False,
        data_type=DataType.TEXT)

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_AZURE_BLOB_API_KEY",
        label="API Key",
        description="An API key to access the container and operate on it.",
        optional=False,
        data_type=DataType.TEXT,
        secured=True)

    __container_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_AZURE_BLOB_CONTAINER_NAME",
        label="Container Name",
        description="An name of the container that contains your blob objects.",
        optional=False,
        data_type=DataType.TEXT)

    __client: BlobServiceClient = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__blob_storage_account_conf, cls.__api_key_conf, cls.__container_name_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "57fb9cb8-e7e0-4f0d-82fe-540e8cb535b8"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure Blob Storage"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Files storage that stores files in a Azure Blob Storage container."

    def read(self, filename: str) -> bytes:
        blob = self.get_impl().get_blob_client(container=self.get_parameter_value(self.__container_name_conf), blob=filename)
        stream = blob.download_blob()
        return stream.readall()


    def write(self, filename: str, binary_data: bytes, **kwargs):
        new_blob = self.get_impl().get_blob_client(container=self.get_parameter_value(self.__container_name_conf), blob=filename)
        new_blob.upload_blob(binary_data, overwrite=True)
        return FileStorageObject(reference_id=filename, url=self.get_url_for_filename(filename))


    def get_file_system(self) -> FileStorageFileSystem:
        return FileStorageFileSystem.AZURE

    def get_impl(self):
        if self.__client is None:
            self.__client = BlobServiceClient(account_url=f"https://{self.get_parameter_value(self.__blob_storage_account_conf)}.blob.core.windows.net/",
                                        credential=self.get_parameter_value(self.__api_key_conf))
        return self.__client

    def get_url_for_filename(self, filename: str) -> str:
        blob = self.get_impl().get_blob_client(container=self.get_parameter_value(self.__container_name_conf), blob=filename)
        return blob.url
