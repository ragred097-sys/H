import abc
import io
from typing import Union, BinaryIO

from pydantic import BaseModel

from maxgpt.modules.modules import ModuleType
from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.services.database_model import FileStorageFileSystem

class FileStorageObject(BaseModel):
    reference_id: str
    details: str = None
    url: str

class AbstractFileStorage(AbstractModule):
    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.FILE_STORAGE

    @abc.abstractmethod
    def read(self, url: str) -> Union[bytes, io.BytesIO, BinaryIO]:
        pass

    @abc.abstractmethod
    def write(self, filename: str, binary_data: bytes, **kwargs) -> FileStorageObject:
        """
        Returns a FileStoragerObject, which contains information about the remotely stored file.
        """
        pass

    @abc.abstractmethod
    def get_file_system(self) -> FileStorageFileSystem:
        pass

    @abc.abstractmethod
    def get_url_for_filename(self, filename: str) -> str:
        pass