import io
import logging

from minio import Minio

from maxgpt.core import DataType
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage, FileStorageObject
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services.database_model import FileStorageFileSystem


class FSMinIOStorage(AbstractFileStorage):

    __server_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_SERVER_URL",
        label="Server URL",
        description="The address of the minio/s3 service host",
        optional=False,
        data_type=DataType.TEXT)

    __access_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_ACCESS_KEY",
        label="Access Key",
        description="The access or api key.",
        optional=False,
        data_type=DataType.TEXT)

    __secret_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_SECRET_KEY",
        label="Secret Key",
        description="The secret key required to access the endpoint.",
        optional=False,
        data_type=DataType.TEXT)

    __bucket_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_BUCKET_NAME",
        label="Bucket Name",
        description="The S3 bucket name for this instance.",
        optional=False,
        data_type=DataType.TEXT)

    __ssl_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_SSL",
        label="SSL Enabled",
        description="Flag to indicate if the endpoint is accessible via https or http.",
        optional=False,
        default="False",
        data_type=DataType.BOOLEAN)

    __verify_ssl_cert_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_FS_MINIO_VERIFY_SSL_CERT",
        label="Verify SSL Certificate",
        description="Weather or not to verify SSL certificate.",
        optional=False,
        default="False",
        data_type=DataType.BOOLEAN)

    __client: Minio = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__server_url_conf,
                cls.__access_key_conf,
                cls.__secret_key_conf,
                cls.__bucket_name_conf,
                cls.__verify_ssl_cert_conf,
                cls.__ssl_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "1e77cd2f-39d4-457a-84bd-950ea488cac3"

    @classmethod
    def get_spec_name(cls) -> str:
        return "MinIO S3"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Files storage that stores files in a MinIO S3 container."

    def read(self, filename: str) -> bytes:
        bucket_name = self.get_parameter_value(self.__bucket_name_conf)
        response = None
        try:
            response = self.get_impl().get_object(bucket_name, filename)
            return response.read()
        finally:
            if response:
                response.close()
                response.release_conn()


    def write(self, filename: str, binary_data: bytes, **kwargs):
        bucket_name = self.get_parameter_value(self.__bucket_name_conf)
        self.get_impl().put_object(bucket_name=bucket_name, object_name=filename, data=io.BytesIO(binary_data), length=len(binary_data))
        return FileStorageObject(reference_id=filename, url=self.get_url_for_filename(filename))


    def get_file_system(self) -> FileStorageFileSystem:
        return FileStorageFileSystem.S3


    def get_impl(self):
        if self.__client is None:
            self.__client = Minio(self.get_parameter_value(self.__server_url_conf),
                        access_key=self.get_parameter_value(self.__access_key_conf),
                        secret_key=self.get_parameter_value(self.__secret_key_conf),
                        cert_check=self.get_parameter_value(self.__verify_ssl_cert_conf).lower() in ('true', '1', 't'),
                        secure=self.get_parameter_value(self.__ssl_conf).lower() in ('true', '1', 't'),
                  )
            bucket_name = self.get_parameter_value(self.__bucket_name_conf)
            # Make the bucket if it doesn't exist.
            found = self.__client.bucket_exists(bucket_name)
            if not found:
                self.__client.make_bucket(bucket_name)
                logging.log(logging.DEBUG, "Created bucket", bucket_name)
            else:
                logging.log(logging.DEBUG, "Bucket", bucket_name, "already exists")
        return self.__client

    def get_url_for_filename(self, filename: str) -> str:
        prefix = "https://" if self.get_parameter_value(self.__verify_ssl_cert_conf).lower() in ('true', '1', 't') else "http://"
        _url = prefix + self.get_parameter_value(self.__server_url_conf) + "/" + self.get_parameter_value(self.__bucket_name_conf) + "/" + filename
        print(_url)
        return _url
