import datetime
from typing import Dict, List, Optional

from llama_index.core import VectorStoreIndex
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.vector_stores.qdrant import QdrantVectorStore
from qdrant_client import qdrant_client

from maxgpt.core import DataType
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services import Tag
from maxgpt.services.database_model import DocumentType
from maxgpt.services.security import User


class MaxQdrantVectorStore(AbstractVectorStore):

    __url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_URL",
        label="Host Name / IP Address",
        description="The URL at which Qdrant is hosted.",
        data_type=DataType.TEXT,
        default="127.0.0.1")

    __port_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_PORT",
        label="Port",
        description="The PORT at which Qdrant is hosted.",
        data_type=DataType.INTEGER,
        default="6333")

    __index_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_INDEX_NAME",
        label="Index name",
        description="A unique name for the index bound to this instance of a vector index store. Default to 'default'.",
        data_type=DataType.TEXT,
        default="default")

    __https_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_HTTPS",
        label="Use HTTPS",
        description="Is this connection using https? It goes hand in hand with M_VECTOR_STORE_QDRANT_HTTPS_VERIFY. [True or False] Default: False",
        data_type=DataType.BOOLEAN,
        optional=True,
        default="False")

    __https_verify_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_HTTPS_VERIFY",
        label="Verify HTTPS",
        description="Should ssl connections be verified? Only relevant when M_VECTOR_STORE_QDRANT_HTTPS=True. [True or False] Default: False",
        data_type=DataType.BOOLEAN,
        optional=True,
        default="False")

    __proxy_prefix_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_PROXY_PREFIX",
        label="Proxy prefix",
        description="A prefix used to target qdrant instances behind a proxy server. For example: 'qdrant' when hosted at <url>:<port>/qdrant",
        data_type=DataType.TEXT,
        optional=True)

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_QDRANT_API_KEY",
        label="API Key",
        description="An optional API key that you might need to connect to your qdrant instance.",
        data_type=DataType.TEXT,
        optional=True)

    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag], module_supported_inputs: List[DocumentType], module_created_at: datetime,
                 module_creator: User, module_modified_at: datetime, module_modifier: User):
        super().__init__(module_id, module_name, module_description, module_parameters, module_tags,
                         module_supported_inputs, module_created_at, module_creator, module_modified_at,
                         module_modifier)
        self.__index: Optional[BaseIndex[IndexDict]] = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__url_conf, cls.__port_conf, cls.__index_name_conf, cls.__https_conf, cls.__https_verify_conf, cls.__proxy_prefix_conf, cls.__api_key_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "6be9447d-b45e-4563-af34-22d44fbde905"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Qdrant"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Vector store implementation that uses Qdrant."

    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        if self.__index is None:
            _url = self.get_parameter_value(self.__url_conf)
            _port = int(self.get_parameter_value(self.__port_conf))
            _https_enabled = self.get_parameter_value(self.__https_conf).lower() in ["true", "1"]
            _https_verify = self.get_parameter_value(self.__https_verify_conf).lower() in ["true", "1"]
            _proxy_prefix = self.get_parameter_value(self.__proxy_prefix_conf)
            client = qdrant_client.QdrantClient(url=_url, port=_port,
                                                https=_https_enabled, verify=_https_verify,
                                                prefix=_proxy_prefix,
                                                api_key=self.get_parameter_value(self.__api_key_conf))

            vector_store = QdrantVectorStore(client=client, collection_name=self.get_parameter_value(self.__index_name_conf))
            self.__index = VectorStoreIndex.from_vector_store(vector_store, embed_model=embed_model, show_progress=True)
        return self.__index


    def is_available(self) -> bool:
        # TODO: Availability Check
        return True

    def persist(self):
        pass