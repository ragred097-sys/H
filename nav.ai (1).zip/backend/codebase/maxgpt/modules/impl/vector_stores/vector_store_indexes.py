import abc

from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex

from maxgpt.modules.modules import ModuleType
from maxgpt.modules.impl.abstract_module import AbstractModule


class AbstractVectorStore(AbstractModule):
    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.VECTOR_STORE

    @abc.abstractmethod
    def is_available(self) -> bool:
        # TODO: Availability Check
        return True

    @abc.abstractmethod
    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        pass

    @abc.abstractmethod
    def persist(self):
        pass
