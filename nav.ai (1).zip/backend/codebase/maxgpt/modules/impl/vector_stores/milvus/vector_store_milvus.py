import asyncio
import datetime
from typing import Dict, List, Optional

from llama_index.core import VectorStoreIndex
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.vector_stores.milvus import MilvusVectorStore

from maxgpt.core import DataType
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services import Tag, ensure_event_loop
from maxgpt.services.database_model import DocumentType
from maxgpt.services.security import User


class MaxMilvusVectorStore(AbstractVectorStore):

    __uri_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_MILVUS_URI",
        label="Hosted instance or local file",
        description="URI that points to a Milvus instance. Can be a server like https://0.0.0.0:19530 or a file like ./milvus.db",
        data_type=DataType.TEXT,
        optional=False,
        default="./milvus.db")

    __index_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_MILVUS_INDEX_NAME",
        label="Index name",
        description="A unique name for the index bound to this instance of a vector index store. Default to 'default'.",
        data_type=DataType.TEXT,
        optional=False,
        default="default")

    __dimension_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_MILVUS_DIMENSION",
        label="Dimension of vectors",
        description="The dimension of the vectors. Optional. Defaults to 3072",
        data_type=DataType.INTEGER,
        optional=True,
        default="3072"
    )

    __token_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_MILVUS_TOKEN",
        label="API Key Token",
        description="An optional token that you might need to connect to your milvus instance.",
        data_type=DataType.TEXT,
        optional=True)

    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag], module_supported_inputs: List[DocumentType], module_created_at: datetime,
                 module_creator: User, module_modified_at: datetime, module_modifier: User):
        super().__init__(module_id, module_name, module_description, module_parameters, module_tags,
                         module_supported_inputs, module_created_at, module_creator, module_modified_at,
                         module_modifier)
        self.__index: Optional[BaseIndex[IndexDict]] = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__uri_conf, cls.__index_name_conf, cls.__dimension_conf, cls.__token_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "fe4e32ce-0a90-4d4e-9152-553acf7f16b4"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Milvus"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Vector store implementation that uses Milvus."

    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        if self.__index is None:
            ensure_event_loop()

            _uri = self.get_parameter_value(self.__uri_conf) # default "./milvus_demo.db"
            _collection_name = self.get_parameter_value(self.__index_name_conf)
            _dim = int(self.get_parameter_value(self.__dimension_conf)) if self.get_parameter_value(self.__dimension_conf) is not None else None
            _token = self.get_parameter_value(self.__token_conf)

            # possible extensions:

            # embedding_field: str = DEFAULT_EMBEDDING_KEY,
            # doc_id_field: str = DEFAULT_DOC_ID_KEY,
            # similarity_metric: str = "IP",
            # consistency_level: str = "Session",
            # overwrite: bool = False,
            # text_key: Optional[str] = None,
            # output_fields: Optional[List[str]] = None,
            # index_config: Optional[dict] = None,
            # search_config: Optional[dict] = None,
            # collection_properties: Optional[dict] = None,
            # batch_size: int = DEFAULT_BATCH_SIZE,
            # enable_sparse: bool = False,
            # sparse_embedding_function: Optional[BaseSparseEmbeddingFunction] = None,
            # hybrid_ranker: str = "RRFRanker",
            # hybrid_ranker_params: dict = {},
            # index_management: IndexManagement = IndexManagement.CREATE_IF_NOT_EXISTS,
            # scalar_field_names: Optional[List[str]] = None,
            # scalar_field_types: Optional[List[DataType]] = None,
            # ** kwargs: Any,

            vector_store = MilvusVectorStore(
                uri=_uri,
                dim=_dim,
                collection_name=_collection_name,
                overwrite=True
            )
            self.__index = VectorStoreIndex.from_vector_store(vector_store, embed_model=embed_model)
        return self.__index


    def is_available(self) -> bool:
        # TODO: Availability Check
        return True

    def persist(self):
        pass