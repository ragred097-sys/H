import datetime
import logging
import os
from typing import Dict, List, Optional

from llama_index.core import VectorStoreIndex, StorageContext, load_index_from_storage, Document
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.core.vector_stores import SimpleVectorStore

from maxgpt.core import DataType
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services import Tag
from maxgpt.services.database_model import DocumentType
from maxgpt.services.security import User


class LocalVectorStore(AbstractVectorStore):

    __persist_dir_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_LOCAL_PERSIST_DIR",
        label="Folder",
        description="A path for storing a vector index locally on your disk (can be relative or absolute). "
                    "Default to './vector_store/index'.",
        data_type=DataType.TEXT,
        optional=True,
        default="./vector_store/index")

    __index_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_LOCAL_INDEX_NAME",
        label="Index Name",
        description="A unique name for the index bound to this instance of a vector index store. Default to 'default'.",
        data_type=DataType.TEXT,
        optional=True,
        default="default")


    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag], module_supported_inputs: List[DocumentType], module_created_at: datetime,
                 module_creator: User, module_modified_at: datetime, module_modifier: User):
        super().__init__(module_id, module_name, module_description, module_parameters, module_tags,
                         module_supported_inputs, module_created_at, module_creator, module_modified_at,
                         module_modifier)
        self.__index: Optional[BaseIndex[IndexDict]] = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__persist_dir_conf, cls.__index_name_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "2b929513-16fa-47a4-94b5-7036e16fa8dc"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Local File System"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A simple vector store that stores files on a local disc or a mount point."

    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        if self.__index is None:
            _lookup_index_id = self.get_parameter_value(self.__index_name_conf)
            if not os.path.exists(self.get_parameter_value(self.__persist_dir_conf)) or len(os.listdir(self.get_parameter_value(self.__persist_dir_conf))) == 0:
                # Unfortunately, it is not possible to create an empty index with a reliable structure that can be re-used later.
                # So our idea to create a new index using a fake document to start with.
                vector_store = SimpleVectorStore()
                storage_context = StorageContext.from_defaults(vector_store=vector_store)
                # create a fresh index
                fake_documents = [Document(text="MaximumGPT is your solution to solve business problems leveraging modern AI capabilities.")]
                self.__index = VectorStoreIndex.from_documents(
                    fake_documents, storage_context=storage_context, embed_model=embed_model
                )
                self.__index.set_index_id(_lookup_index_id)
                self.persist()
                logging.log(logging.DEBUG,f"Created local file based vector index called '{_lookup_index_id}' in {self.get_parameter_value(self.__persist_dir_conf)}")
            else:
                vector_store = SimpleVectorStore.from_persist_dir(persist_dir=self.get_parameter_value(self.__persist_dir_conf), namespace="default")
                storage_context = StorageContext.from_defaults(
                    vector_store=vector_store, persist_dir=self.get_parameter_value(self.__persist_dir_conf)
                )
                existing_index_ids = [idx.index_id for idx in storage_context.index_store.index_structs()]
                if _lookup_index_id not in existing_index_ids:
                    logging.log(logging.DEBUG, f"Index with id {_lookup_index_id} not yet existing. Creating it!")
                    # create a fresh index
                    fake_documents = [Document(
                        text="MaximumGPT is your solution to solve business problems leveraging modern AI capabilities.")]
                    self.__index = VectorStoreIndex.from_documents(
                        fake_documents, storage_context=storage_context, embed_model=embed_model
                    )
                    self.__index.set_index_id(_lookup_index_id)
                    self.persist()
                else:
                    # Load existing index
                    self.__index = load_index_from_storage(storage_context=storage_context, embed_model=embed_model, index_id=_lookup_index_id)
                    logging.log(logging.DEBUG, f"Index with id {_lookup_index_id} exists and loaded")

                logging.log(logging.DEBUG, f"Loaded vector index called '{_lookup_index_id}' from local store in {self.get_parameter_value(self.__persist_dir_conf)}")
        return self.__index


    def is_available(self) -> bool:
        # TODO: Availability Check
        return True

    def persist(self):
        if self.__index is not None:
            self.__index.storage_context.persist(persist_dir=self.get_parameter_value(self.__persist_dir_conf))