import datetime
import hashlib
from typing import Dict, List, Optional

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from llama_index.core import VectorStoreIndex
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.vector_stores.azureaisearch import AzureAISearchVectorStore, IndexManagement

from maxgpt.core import DataType
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.services import Tag
from maxgpt.services.database_model import DocumentType
from maxgpt.services.security import User


class MaxAzureAISearchVectorStore(AbstractVectorStore):
    __endpoint_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_AZURE_AI_SEARCH_ENDPOINT",
        label="API Endpoint",
        description="The endpoint at which this vector store can be accessed in Azure AI Search.",
        data_type=DataType.URL,
        optional=False)

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_AZURE_AI_SEARCH_API_KEY",
        label="API Key",
        description="The Api key required to access this search index in Azure AI Search.",
        data_type=DataType.TEXT,
        optional=False,
        secured=True)

    __api_version_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_AZURE_AI_SEARCH_API_VERSION",
        label="API Version",
        description="The api version of this vector store in Azure AI Search. Default: 2024-07-01",
        data_type=DataType.TEXT,
        optional=True,
        default="2024-07-01")

    __index_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_AZURE_AI_SEARCH_INDEX_NAME",
        label="Index Name",
        description="A unique name for the index bound to this instance of a vector index store. Default to 'default'.",
        data_type=DataType.TEXT,
        default="default")

    __index_embedding_dim_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_AZURE_AI_SEARCH_INDEX_EMB_DIM",
        label="Embedding Dimension",
        description="Dimension of embeddings used by this instance of a vector index store. Default to '1536'.",
        data_type=DataType.INTEGER,
        optional=True,
        default="1536")

    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag], module_supported_inputs: List[DocumentType], module_created_at: datetime,
                 module_creator: User, module_modified_at: datetime, module_modifier: User):
        super().__init__(module_id, module_name, module_description, module_parameters, module_tags,
                         module_supported_inputs, module_created_at, module_creator, module_modified_at,
                         module_modifier)
        self.__index: Optional[BaseIndex[IndexDict]] = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf, cls.__endpoint_conf, cls.__api_version_conf, cls.__index_name_conf, cls.__index_embedding_dim_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "67bbfc9b-2084-4e24-824f-6be2065a6515"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure AI Search"

    @classmethod
    def get_spec_description(cls) -> str:
        return "A vector store based on Azure AI Search"

    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        if self.__index is None:
            credential = AzureKeyCredential(self.get_parameter_value(self.__api_key_conf))
            index_client = SearchIndexClient(
                endpoint=self.get_parameter_value(self.__endpoint_conf),
                credential=credential,
            )

            vector_store = AzureAISearchVectorStore(
                search_or_index_client=index_client,
                index_name=self.get_parameter_value(self.__index_name_conf),
                index_management=IndexManagement.CREATE_IF_NOT_EXISTS,
                id_field_key="id",
                chunk_field_key="chunk",
                embedding_field_key="embedding",
                embedding_dimensionality=int(self.get_parameter_value(self.__index_embedding_dim_conf)),
                metadata_string_field_key="metadata",
                doc_id_field_key="doc_id",
            )

            self.__index = VectorStoreIndex.from_vector_store(vector_store, embed_model=embed_model)
        return self.__index


    def is_available(self) -> bool:
        # TODO: Availability Check
        return True

    def persist(self):
        pass