import datetime
from typing import Dict, List, Optional

from llama_index.core import VectorStoreIndex
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.vector_stores.postgres import PGVectorStore

from maxgpt.core import DataType
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services import Tag
from maxgpt.services.database_model import DocumentType
from maxgpt.services.security import User


class MaxPostgresVectorStore(AbstractVectorStore):

    __db_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_DB_NAME",
        label="Name of the database",
        description="Name of the database in the postgres pgvector instance.",
        data_type=DataType.TEXT,
        optional=False)

    __host_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_HOST",
        label="The host of the pgvector instance",
        description="The host of the pgvector instance.",
        data_type=DataType.TEXT,
        optional=False,
        default="127.0.0.1")

    __username_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_USERNAME",
        label="The username for the given database",
        description="The password for the given database.",
        data_type=DataType.TEXT,
        optional=False)

    __password_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_PASSWORD",
        label="The password for the given user and database",
        description="The password for the given user and database.",
        data_type=DataType.TEXT,
        optional=False,
        secured=True)

    __port_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_PORT",
        label="The port number of the pgvector instance",
        description="The port number of the pgvector instance.",
        data_type=DataType.INTEGER,
        optional=False,
        default="5432")

    __index_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_INDEX_NAME",
        label="Index name (i.e. table name)",
        description="The index name of table name where embeddings will be stored to.",
        data_type=DataType.TEXT,
        optional=True,
        default="default_idx")

    __dimension_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_VECTOR_STORE_PGVECTOR_DIMENSION",
        label="Dimension of vectors",
        description="The dimension of the vectors. Optional. Defaults to 3072",
        data_type=DataType.INTEGER,
        optional=True,
        default="3072"
    )

    def __init__(self, module_id: str, module_name: str, module_description: str, module_parameters: Dict[str, str],
                 module_tags: List[Tag], module_supported_inputs: List[DocumentType], module_created_at: datetime,
                 module_creator: User, module_modified_at: datetime, module_modifier: User):
        super().__init__(module_id, module_name, module_description, module_parameters, module_tags,
                         module_supported_inputs, module_created_at, module_creator, module_modified_at,
                         module_modifier)
        self.__index: Optional[BaseIndex[IndexDict]] = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__db_name_conf,
                cls.__host_conf,
                cls.__password_conf,
                cls.__port_conf,
                cls.__username_conf,
                cls.__index_name_conf,
                cls.__dimension_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "b9ff0d41-793d-4933-b184-c85b4dbb6522"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Postgres PGVector"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Vector store implementation that uses Postgres PGVector."

    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        if self.__index is None:
            _db_name = self.get_parameter_value(self.__db_name_conf)
            _host = self.get_parameter_value(self.__host_conf)
            _password = self.get_parameter_value(self.__password_conf)
            _port = self.get_parameter_value(self.__port_conf)
            _username = self.get_parameter_value(self.__username_conf)
            _index_name = self.get_parameter_value(self.__index_name_conf)
            _dimension = int(self.get_parameter_value(self.__dimension_conf))

            vector_store = PGVectorStore.from_params(
                database=_db_name,
                host=_host,
                password=_password,
                port=_port,
                user=_username,
                table_name=_index_name,
                embed_dim=_dimension,  # openai embedding dimension
                hnsw_kwargs={
                    "hnsw_m": 16,
                    "hnsw_ef_construction": 64,
                    "hnsw_ef_search": 40,
                    "hnsw_dist_method": "vector_cosine_ops",
                },
            )
            self.__index = VectorStoreIndex.from_vector_store(vector_store, embed_model=embed_model, show_progress=True)
        return self.__index


    def is_available(self) -> bool:
        # TODO: Availability Check
        return True


    def persist(self):
        pass