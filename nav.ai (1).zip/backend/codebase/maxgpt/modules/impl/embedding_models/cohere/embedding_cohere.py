from llama_index.core.base.llms.base import BaseLLM
from llama_index.embeddings.cohere import CohereEmbedding

from maxgpt.core import DataType
from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
from maxgpt.modules.modules import ModuleSpecParameter


class EmbeddingCohere(AbstractEmbeddingModel):

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_COHERE_API_KEY",
        label="Api Key",
        description="Your api key to access the cohere service.",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_COHERE_MODEL_NAME",
        label="Model Name",
        optional=False,
        description="The cohere model to use.",
        data_type=DataType.TEXT)
    __input_type_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_COHERE_INPUT_TYPE",
        label="Input Type",
        description="The input type configuration of the cohere api.",
        default=None,
        optional=True,
        data_type=DataType.TEXT)
    __embedding_type_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_COHERE_EMBEDDING_TYPE",
        label="Embedding Type",
        description="The embedding type configuration of the cohere api.",
        default="float",
        optional=True,
        data_type=DataType.TEXT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__model_name_conf,
                cls.__embedding_type_conf,
                cls.__input_type_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "1d1f6862-ec4e-4920-938e-0db590d9525a"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Cohere Embedding"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Cohere Embedding to use embedding models deployed on it."

    def get_impl(self):
        if self.__client is None:
            self.__client = CohereEmbedding(api_key=self.get_parameter_value(self.__api_key_conf),
                                   model=self.get_parameter_value(self.__model_name_conf),
                                   input_type=self.get_parameter_value(self.__input_type_conf),
                                   embedding_type=self.get_parameter_value(self.__embedding_type_conf),
                                   timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
