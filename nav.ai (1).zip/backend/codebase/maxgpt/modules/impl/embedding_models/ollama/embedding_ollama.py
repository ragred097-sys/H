import json

from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.embeddings.ollama import OllamaEmbedding

from maxgpt.core import DataType
from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
from maxgpt.modules.modules import ModuleSpecParameter


class EmbeddingOllama(AbstractEmbeddingModel):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_OLLAMA_BASE_URL",
        label="Base URL",
        description="Base url the ollama model is hosted under.",
        default="http://0.0.0.0:11434",
        optional=False,
        data_type=DataType.URL)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_OLLAMA_MODEL_NAME",
        label="Model Name",
        optional=False,
        description="The Ollama model to use.",
        data_type=DataType.TEXT)
    __kwargs: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDING_OLLAMA_ADDITIONAL_KWARGS",
        label="Additional Keyword Arguments",
        optional=True,
        default="{}",
        description="Additional Keyword Arguments known to the selected model.",
        data_type=DataType.JSON)

    __client: BaseEmbedding = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__kwargs]

    @classmethod
    def get_spec_id(cls) -> str:
        return "6286c237-fad8-484a-ad87-9eaa9f21eabf"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Ollama"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Embedding model implementation that uses LLMs deployed on an Ollama instance."

    def get_impl(self):
        if self.__client is None:
            self.__client = OllamaEmbedding(base_url=self.get_parameter_value(self.__base_url_conf),
                                   model_name=self.get_parameter_value(self.__model_name_conf),
                                   ollama_additional_kwargs=json.loads(self.get_parameter_value(self.__kwargs)),
                                   request_timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
