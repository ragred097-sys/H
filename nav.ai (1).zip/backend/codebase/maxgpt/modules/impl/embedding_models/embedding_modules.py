import abc

from llama_index.core.base.embeddings.base import BaseEmbedding

from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.modules import ModuleType


class AbstractEmbeddingModel(AbstractModule):
    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.EMBEDDING_MODEL

    @abc.abstractmethod
    def is_available(self) -> bool:
        pass

    @abc.abstractmethod
    def get_impl(self) -> BaseEmbedding:
        pass
