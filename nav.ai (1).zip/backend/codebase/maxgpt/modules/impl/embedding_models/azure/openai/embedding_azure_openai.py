from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.embeddings.azure_openai import AzureOpenAIEmbedding

from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
from maxgpt.modules.modules import ModuleSpecParameter
from maxgpt.services.database_model import DataType


class EmbeddingModelAzureOpenAI(AbstractEmbeddingModel):
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMB_AZURE_OPENAI_API_KEY",
        label="API Key",
        description="The key to get access to the embedding model hosted at OpenAI services.",
        secured=True,
        data_type=DataType.TEXT)
    __endpoint_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMB_AZURE_OPENAI_ENDPOINT",
        label="API Endpoint",
        description="The endpoint that serves the API for the embedding model hosted at OpenAI services.",
        data_type=DataType.URL)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMB_AZURE_OPENAI_MODEL_NAME",
        label="Model Name",
        description="The name of the embedding model hosted at OpenAI services.",
        data_type=DataType.TEXT)
    __deployment_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMB_AZURE_OPENAI_DEPLOYMENT_NAME",
        label="Deployment Name",
        description="The name of the deployment inside OpenAI services.",
        data_type=DataType.TEXT)
    __api_version_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMB_AZURE_OPENAI_API_VERSION",
        label="API Version",
        description="The key to get access to the embedding model hosted at OpenAI services.",
        data_type=DataType.TEXT,
        default="2023-07-01-preview",
        optional=True)

    __client: BaseEmbedding = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__endpoint_conf,
                cls.__api_version_conf,
                cls.__deployment_name_conf,
                cls.__model_name_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "846232c8-b6e9-4ee2-87ab-3e173768f06c"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure OpenAI"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Embedding model implementation that uses Azure OpenAI."

    def get_impl(self):
        if self.__client is None:
            self.__client = AzureOpenAIEmbedding(
                model=self.get_parameter_value(self.__model_name_conf),
                deployment_name=self.get_parameter_value(self.__deployment_name_conf),
                api_key=self.get_parameter_value(self.__api_key_conf),
                azure_endpoint=self.get_parameter_value(self.__endpoint_conf),
                api_version=self.get_parameter_value(self.__api_version_conf),
            )
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
