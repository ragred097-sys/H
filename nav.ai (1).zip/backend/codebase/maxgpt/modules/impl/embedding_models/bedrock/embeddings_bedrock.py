from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.embeddings.bedrock import BedrockEmbedding

from maxgpt.core import DataType
from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
from maxgpt.modules.modules import ModuleType, ModuleSpecParameter


class EmbeddingsBedrock(AbstractEmbeddingModel):
    __region_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDINGS_BEDROCK_REGION",
        label="AWS Region",
        description="AWS Region where Bedrock is available (e.g., us-east-1)",
        data_type=DataType.TEXT)
    
    __model_id_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDINGS_BEDROCK_MODEL_ID",
        label="Model ID",
        description="The Bedrock embedding model to use (e.g., amazon.titan-embed-text-v1)",
        default="amazon.titan-embed-text-v1",
        optional=True,
        data_type=DataType.TEXT)
    
    __access_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDINGS_BEDROCK_ACCESS_KEY",
        label="AWS Access Key",
        description="AWS Access Key (optional if using instance profile)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)
    
    __secret_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDINGS_BEDROCK_SECRET_KEY",
        label="AWS Secret Key",
        description="AWS Secret Key (optional if using instance profile)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)
    
    __session_token_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_EMBEDDINGS_BEDROCK_AWS_SESSION_TOKEN",
        label="AWS Session token",
        description="AWS session token (optional, required only when using temporary credentials)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __client: BaseEmbedding = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [
            cls.__region_conf,
            cls.__model_id_conf,
            cls.__access_key_conf,
            cls.__secret_key_conf,
            cls.__session_token_conf
        ]

    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.EMBEDDING_MODEL

    @classmethod
    def get_spec_id(cls) -> str:
        return "7c37cddc-082d-4e38-a574-92278c8be98e"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Amazon Bedrock"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration with Amazon Bedrock to generate embeddings using models."

    def get_impl(self) -> BaseEmbedding:
        if self.__client is None:
            self.__client = BedrockEmbedding(
                model_name=self.get_parameter_value(self.__model_id_conf),
                aws_access_key_id=self.get_parameter_value(self.__access_key_conf),
                aws_secret_access_key=self.get_parameter_value(self.__secret_key_conf),
                aws_session_token=self.get_parameter_value(self.__session_token_conf),
                region_name=self.get_parameter_value(self.__region_conf),
            )
        return self.__client

    def is_available(self) -> bool:
        try:
            # Basic availability check
            self.get_impl()
            return True
        except Exception:
            return False 