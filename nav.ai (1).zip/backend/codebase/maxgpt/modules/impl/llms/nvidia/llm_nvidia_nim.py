from langchain_nvidia_ai_endpoints import ChatNVIDIA
from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.langchain import LangChainLLM
from llama_index.llms.nvidia import NVIDIA

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class NvidiaNim(AbstractLLM):
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_NVIDIA_NIM_MODEL_NAME",
        label="Model Name",
        description="Local hosting - The model hosted via the provided nvidia nim api url.",
        data_type=DataType.TEXT,
        optional=False)
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_NVIDIA_NIM_BASE_URL",
        label="Base URL",
        description="Local hosting - Base url for the nvidia nim api. Defaults to http://0.0.0.0:8080/v1",
        default="http://0.0.0.0:1234/v1",
        data_type=DataType.URL,
        optional=True)
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_NVIDIA_NIM_API_KEY",
        label="API Key",
        description="Remote hosting Nvidia NIMs - API Key to use remote inference model.",
        data_type=DataType.TEXT,
        optional=True,
        secured=True)
    __max_tokens_conf = ModuleSpecParameter(
        name="M_LLM_NVIDIA_NIM_MAX_TOKENS",
        label="Max Tokens",
        description="Maximum number of tokens",
        data_type=DataType.INTEGER,
        default="1024",
        optional=True)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__max_tokens_conf,
                cls.__api_key_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "c1befa38-b299-467f-9fb9-81ff6c583c91"

    @classmethod
    def get_spec_name(cls) -> str:
        return "NVIDIA NIMs"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of NVIDIA NIMs"

    def get_impl(self):
        if self.__client is None:
            #FIXME: The llamaindex NVIDIA client is not supporting function calling properly when streaming inside
            # an AgentWorkflow. Using the Langchain client for Nvidia and ReActAgents in the workflows works great.
            # Once they fixed that in the llamaindex integration, we can go back and remove the langchain wrapper again.
            langchain_model = ChatNVIDIA(base_url=self.get_parameter_value(self.__base_url_conf),
                                   model=self.get_parameter_value(self.__model_name_conf),
                                   max_tokens=int(self.get_parameter_value(self.__max_tokens_conf)),
                                   nvidia_api_key=self.get_parameter_value(self.__api_key_conf),
                                   request_timeout=360.0)
            self.__client = LangChainLLM(llm=langchain_model)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
