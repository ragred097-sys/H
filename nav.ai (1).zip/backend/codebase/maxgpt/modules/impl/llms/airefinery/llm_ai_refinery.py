import httpx
from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.openai_like import OpenAILike

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMOllama(AbstractLLM):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AIR_BASE_URL",
        label="Base URL",
        description="Base url for the AI refinery microservice API",
        optional=False,
        data_type=DataType.URL)

    __model_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AIR_MODEL",
        label="Model/Agent",
        description="The model or agent you want to use.",
        optional=True,
        default="auto",
        data_type=DataType.TEXT)

    __username_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AIR_USERNAME",
        label="Basic Auth Username",
        description="Basic auth username if api is secured with basic auth.",
        optional=True,
        data_type=DataType.TEXT)

    __password_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AIR_PASSWORD",
        label="Basic Auth Password",
        description="Basic auth password if api is secured with basic auth.",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf, cls.__model_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "8ea51fb8-551f-455d-af72-63e1d7f2d119"

    @classmethod
    def get_spec_name(cls) -> str:
        return "AI Refinery"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of microservice API for AI refinery."

    def get_impl(self):
        if self.__client is None:

            http_client = None
            if self.get_parameter_value(self.__username_conf):
                http_client = httpx.Client(auth=(self.get_parameter_value(self.__username_conf),
                                                 self.get_parameter_value(self.__password_conf)))

            self.__client = OpenAILike(model=self.get_parameter_value(self.__model_conf),
                                       api_base=self.get_parameter_value(self.__base_url_conf),
                                       api_key="fake", http_client=http_client)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
