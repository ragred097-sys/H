from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.cohere import Cohere

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMCohere(AbstractLLM):

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_COHERE_API_KEY",
        label="Api Key",
        description="Your api key to access the cohere service.",
        optional=False,
        secured=True,
        data_type=DataType.TEXT)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_COHERE_MODEL_NAME",
        label="Model Name",
        optional=False,
        description="The cohere model to use.",
        data_type=DataType.TEXT)
    __temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_COHERE_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        default="0.2",
        optional=True,
        data_type=DataType.FLOAT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__model_name_conf,
                cls.__temperature]

    @classmethod
    def get_spec_id(cls) -> str:
        return "f47ac10b-58cc-4372-a567-0e02b2c3d479"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Cohere"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Cohere to access LLMs deployed on it."

    def get_impl(self):
        if self.__client is None:
            self.__client = Cohere(api_key=self.get_parameter_value(self.__api_key_conf),
                                   model=self.get_parameter_value(self.__model_name_conf),
                                   temperature=float(self.get_parameter_value(self.__temperature)),
                                   timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
