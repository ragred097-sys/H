from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.bedrock import Bedrock

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMBedrock(AbstractLLM):
    __region_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_BEDROCK_REGION",
        label="AWS Region",
        description="AWS Region where Bedrock is available (e.g., us-east-1)",
        data_type=DataType.TEXT)
    
    __model_id_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_BEDROCK_MODEL_ID",
        label="Model ID",
        description="The Bedrock model to use (e.g., anthropic.claude-v2)",
        data_type=DataType.TEXT)
    
    __session_token_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_BEDROCK_AWS_SESSION_TOKEN",
        label="AWS Session token",
        description="AWS session token (optional, required only when using temporary credentials)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)
    
    __access_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_BEDROCK_ACCESS_KEY",
        label="AWS Access Key",
        description="AWS Access Key (optional if using instance profile)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)
    
    __secret_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_BEDROCK_SECRET_KEY",
        label="AWS Secret Key",
        description="AWS Secret Key (optional if using instance profile)",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [
            cls.__region_conf,
            cls.__model_id_conf,
            cls.__session_token_conf,
            cls.__access_key_conf,
            cls.__secret_key_conf
        ]

    @classmethod
    def get_spec_id(cls) -> str:
        return "9b1deb4d-3b7d-4fdb-9b4b-27b381db3c48"   

    @classmethod
    def get_spec_name(cls) -> str:
        return "Amazon Bedrock"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration with Amazon Bedrock to access various foundation models."

    def get_impl(self) -> BaseLLM:
        if self.__client is None:
            self.__client = Bedrock(
                model=self.get_parameter_value(self.__model_id_conf),
                aws_access_key_id=self.get_parameter_value(self.__access_key_conf),
                aws_secret_access_key=self.get_parameter_value(self.__secret_key_conf),
                aws_session_token=self.get_parameter_value(self.__session_token_conf),
                region_name=self.get_parameter_value(self.__region_conf),
            )
        return self.__client

    def is_available(self) -> bool:
        try: 
            self.get_impl()
            return True
        except Exception:
            return False 