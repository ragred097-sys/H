from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.gemini import Gemini
import google.generativeai as genai

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMGoogleGemini(AbstractLLM):
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_API_KEY",
        label="API Key",
        description="The key to get access to supported google llms.",
        secured=True,
        data_type=DataType.TEXT)
    __model_other_model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_OTHER_MODEL_NAME",
        label="Model Name",
        description="The name of the llm model hosted at Google where your api key has access to",
        optional=True,
        data_type=DataType.TEXT)
    __api_temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_TEMPERATURE",
        label="LLM Temperature",
        description="Value between 0 and 1. Lower means more predictable output, higher means more creativity.",
        optional=True,
        default="0.1",
        data_type=DataType.FLOAT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__model_other_model_name_conf,
                cls.__api_temperature]

    @classmethod
    def get_spec_id(cls) -> str:
        return "3b2fdec9-a25f-4b79-af0d-b8e9078ecd0c"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Google Gemini"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Google Gemini"

    def get_impl(self):
        if self.__client is None:
            if self.get_parameter_value(self.__model_other_model_name_conf):
                self.__client = Gemini(api_key=self.get_parameter_value(self.__api_key_conf),
                                       model_name=self.get_parameter_value(self.__model_other_model_name_conf),
                                       temperature=float(self.get_parameter_value(self.__api_temperature)))
            else:
                self.__client = Gemini(api_key=self.get_parameter_value(self.__api_key_conf),
                                       temperature=float(self.get_parameter_value(self.__api_temperature)))
            # print available models for the user
            print("Available models in your Gemini subscription:")
            for m in genai.list_models():
                if "generateContent" in m.supported_generation_methods:
                    print("\t" + m.name)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
