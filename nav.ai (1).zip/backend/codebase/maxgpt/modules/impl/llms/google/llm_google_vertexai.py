import asyncio
import json
from typing import Any, Sequence

import vertexai
from google.oauth2 import service_account
from llama_index.core.base.llms.generic_utils import completion_to_chat_decorator, acompletion_to_chat_decorator
from llama_index.core.base.llms.types import (
    ChatMessage,
    ChatResponse,
    ChatResponseGen,
    CompletionResponse,
    CompletionResponseGen,
    LLMMetadata, CompletionResponseAsyncGen, ChatResponseAsyncGen,
)
from llama_index.core.llms import LLM
from vertexai.generative_models import GenerativeModel, SafetySetting, HarmCategory, HarmBlockThreshold

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class CustomVertexAIWrapper(LLM):
    """
    Custom Vertex AI wrapper with safety settings being disabled to avoid very restrictive policies that
    kick in when simply greeting dear Google.
    """

    def __init__(
            self,
            model: str,
            project: str,
            credentials: service_account.Credentials,
            num_output: int,
            context_window: int,
            temperature: float = 0.1,
            **kwargs: Any,
    ):
        super().__init__(**kwargs)

        # Initialize Vertex AI
        vertexai.init(project=project, credentials=credentials)

        # That is what we need! Maybe we can make it configurable but I prefer to not restrict anything at this point
        # (we are lacking proper error handling for llm error messages)
        safety_settings = [
            SafetySetting(category=HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
            SafetySetting(category=HarmCategory.HARM_CATEGORY_UNSPECIFIED,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
            SafetySetting(category=HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
            SafetySetting(category=HarmCategory.HARM_CATEGORY_HARASSMENT,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
            SafetySetting(category=HarmCategory.HARM_CATEGORY_CIVIC_INTEGRITY,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
            SafetySetting(category=HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                          threshold=HarmBlockThreshold.BLOCK_NONE),
        ]

        self._model = GenerativeModel(
            model_name=model,
            safety_settings=safety_settings,
        )
        self._temperature = temperature
        self._model_name = model
        self._num_output = num_output
        self._context_window = context_window

    @property
    def metadata(self) -> LLMMetadata:
        return LLMMetadata(
            context_window=self._context_window,
            num_output=self._num_output,
            is_chat_model=True,
            model_name=self._model_name,
        )

    def _messages_to_content(self, messages: Sequence[ChatMessage]) -> str:
        """Convert ChatMessage sequence to a single content string. Taken the template from antropic sonnet 4 :D"""
        content_parts = []
        for message in messages:
            if message.role == "user":
                content_parts.append(f"User: {message.content}")
            elif message.role == "assistant":
                content_parts.append(f"Assistant: {message.content}")
            elif message.role == "system":
                content_parts.append(f"System: {message.content}")
        return "\n".join(content_parts)

    def chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        content = self._messages_to_content(messages)
        # This line is important for us as well and justifies the existence of this wrapper class
        chat_session = self._model.start_chat(response_validation=False)
        response = chat_session.send_message(
            content,
            generation_config={
                "temperature": self._temperature,
                **kwargs.get("generation_config", {})
            }
        )

        return ChatResponse(
            message=ChatMessage(
                role="assistant",
                content=response.text if response.text else "No response generated."
            )
        )

    def stream_chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponseGen:
        content = self._messages_to_content(messages)
        # This line is important for us as well and justifies the existence of this wrapper class
        chat_session = self._model.start_chat(response_validation=False)

        # Generate streaming response
        response_stream = chat_session.send_message(
            content,
            generation_config={
                "temperature": self._temperature,
                **kwargs.get("generation_config", {})
            },
            stream=True
        )

        def gen() -> ChatResponseGen:
            content_parts = []
            for chunk in response_stream:
                if chunk.text:
                    content_parts.append(chunk.text)
                    yield ChatResponse(
                        message=ChatMessage(
                            role="assistant",
                            content="".join(content_parts)
                        ),
                        delta=chunk.text
                    )

        return gen()

    @acompletion_to_chat_decorator
    async def acomplete(self, prompt: str, **kwargs: Any) -> CompletionResponse:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.complete, prompt, **kwargs)

    @acompletion_to_chat_decorator
    async def astream_complete(self, prompt: str, **kwargs: Any) -> CompletionResponseAsyncGen:
        async def agen() -> CompletionResponseAsyncGen:
            # Convert sync generator to async generator
            sync_gen = self.stream_complete(prompt, **kwargs)
            for response in sync_gen:
                yield response

        return agen()

    async def achat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        """Generate an async chat response."""
        # For simplicity, we'll use the sync method in a thread pool. Maybe not optimal but working for now.
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.chat, messages, **kwargs)

    async def astream_chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponseAsyncGen:
        async def agen() -> ChatResponseAsyncGen:
            sync_gen = self.stream_chat(messages, **kwargs)
            for response in sync_gen:
                yield response

        return agen()

    @completion_to_chat_decorator
    def complete(self, prompt: str, **kwargs: Any) -> CompletionResponse:
        """Generate a completion response."""
        chat_session = self._model.start_chat(response_validation=False)

        response = chat_session.send_message(
            prompt,
            generation_config={
                "temperature": self._temperature,
                **kwargs.get("generation_config", {})
            }
        )

        return CompletionResponse(
            text=response.text if response.text else "No response generated."
        )

    @completion_to_chat_decorator
    def stream_complete(self, prompt: str, **kwargs: Any) -> CompletionResponseGen:
        """Generate a streaming completion response."""
        chat_session = self._model.start_chat(response_validation=False)

        response_stream = chat_session.send_message(
            prompt,
            generation_config={
                "temperature": self._temperature,
                **kwargs.get("generation_config", {})
            },
            stream=True
        )

        def gen() -> CompletionResponseGen:
            content_parts = []
            for chunk in response_stream:
                if chunk.text:
                    content_parts.append(chunk.text)
                    yield CompletionResponse(
                        text="".join(content_parts),
                        delta=chunk.text
                    )

        return gen()

class LLMGoogleVertexAI(AbstractLLM):
    __spn_info_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_VERTEX_SPN_INFO",
        label="SPN Auth - Info mappings",
        description="SPN Auth - Info mappings",
        secured=True,
        optional=True,
        data_type=DataType.TEXT)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_VERTEX_MODEL_NAME",
        label="Model Name",
        description="The name of the llm model hosted at Google where your api key has access to",
        optional=True,
        data_type=DataType.TEXT)
    __model_num_output_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_VERTEX_MODEL_NUM_OUTPUT",
        label="Num Output of the selected model",
        description="Num Output of the selected model. Defaults to 8192.",
        optional=True,
        default="8192",
        data_type=DataType.INTEGER)
    __model_context_window_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_VERTEX_MODEL_CONTEXT_WINDOW",
        label="Size of the context window of the selected model",
        description="Size of the context window of the selected model. Defaults to 32768.",
        optional=True,
        default="32768",
        data_type=DataType.INTEGER)
    __api_temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_GOOGLE_VERTEX_TEMPERATURE",
        label="LLM Temperature",
        description="Value between 0 and 1. Lower means more predictable output, higher means more creativity.",
        optional=True,
        default="0.1",
        data_type=DataType.FLOAT)

    __client: CustomVertexAIWrapper = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return ([cls.__model_name_conf,
                cls.__api_temperature,
                cls.__spn_info_conf,
                cls.__model_num_output_conf,
                cls.__model_context_window_conf])

    @classmethod
    def get_spec_id(cls) -> str:
        return "6ee40e15-57dc-4fb7-9532-a98d5ccca8e7"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Google Vertex AI"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Google Vertex AI"

    def get_impl(self) -> CustomVertexAIWrapper:
        if self.__client is None:
            credentials: service_account.Credentials = (
                service_account.Credentials.from_service_account_info(info=json.loads(self.get_parameter_value(self.__spn_info_conf)))
            )

            self.__client = CustomVertexAIWrapper(
                model=self.get_parameter_value(self.__model_name_conf),
                project=credentials.project_id,
                credentials=credentials,
                temperature=float(self.get_parameter_value(self.__api_temperature)),
                num_output=int(self.get_parameter_value(self.__model_num_output_conf)),
                context_window=int(self.get_parameter_value(self.__model_context_window_conf)),
            )
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True