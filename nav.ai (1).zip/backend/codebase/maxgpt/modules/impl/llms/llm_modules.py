import abc
from typing import Union, Optional

from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import ChatMessage, MessageRole, TextBlock, ImageBlock
from llama_index.core.llms import LLM
from llama_index.core.multi_modal_llms import MultiModalLLM

from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.modules import ModuleType
from maxgpt.services.database_model import MessagePartModel, MessagePartType
from pandasai.llm.base import LLM as PandasLLM


class AbstractLLM(AbstractModule):
    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.LLM

    @abc.abstractmethod
    def is_available(self) -> bool:
        pass

    @abc.abstractmethod
    def get_impl(self) -> Union[BaseLLM, MultiModalLLM, LLM]:
        pass

    def get_pandasai_impl(self) -> Optional[PandasLLM]:
        return None

    def prompt_gen(self, message_parts: [MessagePartModel]) -> str:
        result = ""
        for message_part in message_parts:
            if message_part.type == MessagePartType.TEXT:
                result += (message_part.content + "\n")
        return result.strip()
