from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.azure_openai import AzureOpenAI

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter
from pandasai.llm.base import LLM as PandasLLM
from pandasai.llm.azure_openai import AzureOpenAI as PandasAzureOpenAI


class LLMAzureOpenAI(AbstractLLM):
    __endpoint_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_ENDPOINT",
        label="API Endpoint",
        description="The endpoint that serves the API for the llm hosted at OpenAI services.",
        data_type=DataType.URL)
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_API_KEY",
        label="API Key",
        description="The key to get access to the llm hosted at OpenAI services.",
        secured=True,
        data_type=DataType.TEXT)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_MODEL_NAME",
        label="Model Name",
        description="The name of the llm model hosted at OpenAI services.",
        data_type=DataType.TEXT)
    __deployment_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_DEPLOYMENT_NAME",
        label="Deployment Name",
        description="The name of the deployment inside OpenAI services.",
        data_type=DataType.TEXT)
    __api_version_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_API_VERSION",
        label="API Version",
        description="The key to get access to the llm hosted at OpenAI services.",
        data_type=DataType.TEXT,
        default="2023-07-01-preview",
        optional=True)
    __api_temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_OPENAI_TEMPERATURE",
        label="LLM Temperature",
        description="Value between 0 and 1. Lower means more predictable output, higher means more creativity.",
        optional=True,
        default="0.1",
        data_type=DataType.FLOAT)

    __client: BaseLLM = None
    __pai_client: PandasLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__endpoint_conf,
                cls.__api_temperature,
                cls.__api_version_conf,
                cls.__deployment_name_conf,
                cls.__model_name_conf]
        
    @classmethod
    def get_spec_id(cls) -> str:
        return "d7975f09-2b33-4ddf-bc29-cdc6c64a6781"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure OpenAI"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of OpenAI deployed on Azure"

    def get_impl(self) -> BaseLLM:
        if self.__client is None:
            self.__client = AzureOpenAI(
                model=self.get_parameter_value(self.__model_name_conf),
                deployment_name=self.get_parameter_value(self.__deployment_name_conf),
                api_key=self.get_parameter_value(self.__api_key_conf),
                azure_endpoint=self.get_parameter_value(self.__endpoint_conf),
                api_version=self.get_parameter_value(self.__api_version_conf),
                temperature=float(self.get_parameter_value(self.__api_temperature)),
                supports_content_blocks=True
           )
        return self.__client

    def get_pandasai_impl(self) -> PandasLLM:
        if self.__pai_client is None:
            self.__pai_client = PandasAzureOpenAI(
                model=self.get_parameter_value(self.__model_name_conf),
                deployment_name=self.get_parameter_value(self.__deployment_name_conf),
                api_token=self.get_parameter_value(self.__api_key_conf),
                azure_endpoint=self.get_parameter_value(self.__endpoint_conf),
                api_version=self.get_parameter_value(self.__api_version_conf),
                temperature=float(self.get_parameter_value(self.__api_temperature))
           )
        return self.__pai_client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
