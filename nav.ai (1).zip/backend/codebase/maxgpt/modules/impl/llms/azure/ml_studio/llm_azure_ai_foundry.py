import json
from typing import Any, Sequence

import requests
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import CompletionResponse, ChatMessage, CompletionResponseGen, \
    LLMMetadata, MessageRole
from llama_index.core.llms import CustomLLM
from llama_index.core.llms.callbacks import llm_completion_callback
from llama_index.llms.azure_inference import AzureAICompletionsModel

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class AzureHuggingFaceWrapper(CustomLLM):
    endpoint_url: str = ""
    api_key: str = ""
    model_input_field: str = "inputs"
    temperature: float = 0.7
    max_new_tokens: int = 390
    top_p: float = 0.95
    context_window: int = 32000
    num_output: int = 390
    model_name: str = "custom"

    def __init__(self, /, endpoint_url: str,
                api_key: str,
                model_input_field: str = "inputs",
                temperature: float = 0.7,
                max_new_tokens: int = 390,
                top_p: float = 0.95,
                context_window: int = 32000,
                num_output: int = 390,
                model_name: str = "custom",
                **data: Any):
        super().__init__()
        self.endpoint_url = endpoint_url
        self.api_key = api_key
        self.model_input_field = model_input_field
        self.temperature = temperature
        self.max_new_tokens = max_new_tokens
        self.top_p = top_p
        self.model_name = model_name
        self.num_output = num_output
        self.context_window = context_window

    def _build_headers(self):
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _build_payload(self, prompt: str):
        input_value = ""
        chat_history_value = ""
        for message in json.loads(prompt)["messages"]:
            if message["role"] == MessageRole.USER:
                input_value = message["content"] + "\n"
            chat_history_value += message["role"] + ": " + message["content"] + "\n"

        # Historical knowledge does not work ith ALIA-b40
        # if chat_history_value:
        #     input_value += "\nThe following context information has already been discussed and can be used as additional knowledge:\n" + chat_history_value

        return {
            self.model_input_field: input_value,
            "parameters": {
                "temperature": self.temperature,
                "top_p": self.top_p,
                "max_new_tokens": self.max_new_tokens,
                "return_full_text": False,
            }
        }

    def _parse_response(self, response) -> str:
        result = response.json()
        if isinstance(result, list) and "generated_text" in result[0]:
            response_str = result[0]["generated_text"]
        elif "generated_text" in result:
            response_str = result["generated_text"]
        else:
            response_str = str(result)
        if response_str.startswith("assistant:"):
            response_str = response_str.replace("assistant:", "", 1)
        return response_str.strip()

    @property
    def metadata(self) -> LLMMetadata:
        """Get LLM metadata."""
        return LLMMetadata(
            context_window=self.context_window,
            num_output=self.num_output,
            model_name=self.model_name,
        )

    @llm_completion_callback()
    def complete(self, prompt: str, **kwargs: Any) -> CompletionResponse:
        payload = self._build_payload(prompt)
        response = requests.post(self.endpoint_url, headers=self._build_headers(), json=payload)
        if response.status_code != 200:
            raise Exception(f"Request failed: {response.status_code} - {response.text}")
        text = self._parse_response(response)
        return CompletionResponse(text=text)

    @llm_completion_callback()
    def stream_complete(
            self, prompt: str, **kwargs: Any
    ) -> CompletionResponseGen:
        text = self.complete(prompt).text
        response = ""
        for word in text.split():
            token = word + " "
            response += token
            yield CompletionResponse(text=response, delta=token)

    def messages_to_prompt(messages: Sequence[ChatMessage]) -> str:
        payload = {}
        string_messages = []
        for message in messages:
            # each message is a simple json with role and content
            message_json = {"role": message.role, "content": message.content}
            string_messages.append(message_json)
        payload["messages"] = string_messages
        return json.dumps(payload)

class LLMAzureAIFoundry(AbstractLLM):
    __endpoint_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_ENDPOINT",
        label="API Endpoint",
        description="The endpoint that serves the API for the llm hosted at AI Foundry.",
        data_type=DataType.URL)
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_API_KEY",
        label="API Key",
        description="The key to get access to the llm hosted at AI Foundry.",
        secured=True,
        data_type=DataType.TEXT)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_MODEL_NAME",
        label="Model Name",
        optional=True,
        description="The name of the llm model hosted at AI Foundry.",
        data_type=DataType.TEXT)
    __api_temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_TEMPERATURE",
        label="LLM Temperature",
        description="Value between 0 and 1. Lower means more predictable output, higher means more creativity.",
        optional=True,
        default="0.1",
        data_type=DataType.FLOAT)
    __max_new_tokens: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_MAX_NEW_TOKENS",
        label="Number of new tokens in the response",
        description="Number of new tokens in the response.",
        optional=True,
        default="390",
        data_type=DataType.INTEGER)
    __is_huggingface_inference: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_AZURE_AI_FOUNDRY_IF_HF_INFERENCE",
        label="Is the model respecting hf inference? False (default) -> OpenAI-like",
        description="Is the model respecting hf inference? False (default) -> OpenAI-like",
        optional=True,
        default="False",
        data_type=DataType.BOOLEAN)


    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__api_key_conf,
                cls.__endpoint_conf,
                cls.__api_temperature,
                cls.__max_new_tokens,
                cls.__is_huggingface_inference,
                cls.__model_name_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "4eb1ba91-17fe-4129-a0c2-014b8385e763"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Azure AI Foundry"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Azure AI Foundry endpoints"

    def get_impl(self) -> BaseLLM:
        if self.__client is None:

            if str(self.get_parameter_value(self.__is_huggingface_inference)).lower() in ["true", "1"]:
                self.__client = AzureHuggingFaceWrapper(
                    endpoint_url=self.get_parameter_value(self.__endpoint_conf),
                    api_key=self.get_parameter_value(self.__api_key_conf),
                    model_name=self.get_parameter_value(self.__model_name_conf),
                    temperature=float(self.get_parameter_value(self.__api_temperature)),
                    max_new_tokens=int(self.get_parameter_value(self.__max_new_tokens)),
                )
            else:
                self.__client = AzureAICompletionsModel(
                    endpoint=self.get_parameter_value(self.__endpoint_conf),
                    credential=self.get_parameter_value(self.__api_key_conf),
                    model_name=self.get_parameter_value(self.__model_name_conf),
                    temperature=float(self.get_parameter_value(self.__api_temperature)),
                )
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
