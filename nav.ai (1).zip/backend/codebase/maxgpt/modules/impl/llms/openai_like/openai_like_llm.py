import json

import httpx
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.constants import DEFAULT_CONTEXT_WINDOW
from llama_index.llms.openai_like import OpenAILike
from llama_index.llms.vllm import Vllm, VllmServer

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMOpenAILike(AbstractLLM):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_BASE_URL",
        label="Base URL",
        description="Base url the vLLM model is hosted under.",
        default="https://hostname.com/v1",
        data_type=DataType.URL)

    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_MODEL_NAME",
        label="Model Name",
        description="The model to use.",
        data_type=DataType.TEXT)

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_API_KEY",
        label="API Key",
        description="The key to get access to the llm hosted at OpenAI services. Put a random string is not needed.",
        secured=True,
        default="Fake-Key",
        optional=True,
        data_type=DataType.TEXT)

    __temperature_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        optional=True,
        default="0.2",
        data_type=DataType.FLOAT)

    __additional_kwargs_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_ADDITIONAL_KWARGS",
        label="Additional Keyword Arguments",
        optional=True,
        default="{}",
        description="Additional Keyword Arguments known to the selected model.",
        data_type=DataType.JSON)

    __ctx_window_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_CTX_WINDOW",
        label="Context Window",
        optional=True,
        default=str(DEFAULT_CONTEXT_WINDOW),
        description=f"Context window size. Defaults to {DEFAULT_CONTEXT_WINDOW} tokens",
        data_type=DataType.INTEGER)

    __max_tokens_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_MAX_TOKENS",
        label="Max tokens to generate",
        optional=True,
        default=str(3000),
        description=f"Max tokens limit that the llm should generate. Defaults to 3000 tokens.",
        data_type=DataType.INTEGER)

    __is_chat_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_IS_CHAT",
        label="Is chat model",
        optional=True,
        default="False",
        description=f"Is this model a chat model? Defaults to False.",
        data_type=DataType.BOOLEAN)

    __is_tool_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_IS_TOOL",
        label="Is toll calling model",
        optional=True,
        default="False",
        description=f"Is this model a tool calling model? Defaults to False.",
        data_type=DataType.BOOLEAN)

    __username_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_USERNAME",
        label="Basic Auth Username",
        description="Basic auth username if api is secured with basic auth.",
        optional=True,
        data_type=DataType.TEXT)

    __password_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_LIKE_PASSWORD",
        label="Basic Auth Password",
        description="Basic auth password if api is secured with basic auth.",
        optional=True,
        secured=True,
        data_type=DataType.TEXT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__additional_kwargs_conf,
                cls.__ctx_window_conf,
                cls.__max_tokens_conf,
                cls.__is_chat_conf,
                cls.__is_tool_conf,
                cls.__username_conf,
                cls.__password_conf,
                cls.__api_key_conf,
                cls.__temperature_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "e5433914-a346-4bd7-8003-32e1c8c17c72"

    @classmethod
    def get_spec_name(cls) -> str:
        return "OpenAI-Like"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Generic module integration to access LLMs inferences that follow the OpenAI api specification."

    def get_impl(self):
        if self.__client is None:

            http_client = None
            if self.get_parameter_value(self.__username_conf):
                http_client = httpx.Client(auth=(self.get_parameter_value(self.__username_conf),
                                                 self.get_parameter_value(self.__password_conf)))

            self.__client = OpenAILike(api_base=self.get_parameter_value(self.__base_url_conf),
                                       model=self.get_parameter_value(self.__model_name_conf),
                                       api_key=self.get_parameter_value(self.__api_key_conf),
                                       temperature=float(self.get_parameter_value(self.__temperature_conf)),
                                       context_window=int(self.get_parameter_value(self.__ctx_window_conf)),
                                       max_tokens=int(self.get_parameter_value(self.__max_tokens_conf)),
                                       is_chat_model=str(self.get_parameter_value(self.__is_chat_conf)).lower() == "true",
                                       is_function_calling_model=str(self.get_parameter_value(self.__is_tool_conf)).lower() == "true",
                                       additional_kwargs=json.loads(self.get_parameter_value(self.__additional_kwargs_conf)),
                                       http_client=http_client)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
