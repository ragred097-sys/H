import json

from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.vllm import Vllm, VllmServer

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMvLLM(AbstractLLM):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_VLLM_BASE_URL",
        label="Base URL",
        description="Base url the vLLM model is hosted under.",
        default="http://0.0.0.0:11434",
        data_type=DataType.URL)

    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_VLLM_MODEL_NAME",
        label="Model Name",
        description="The vLLM model to use.",
        data_type=DataType.TEXT)

    __temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_VLLM_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        optional=True,
        default="0.2",
        data_type=DataType.FLOAT)

    __vllm_kwargs: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_VLLM_KWARGS",
        label="Additional VLLM Keyword Arguments",
        optional=True,
        default="{}",
        description="Additional Keyword Arguments known to the selected model.",
        data_type=DataType.JSON)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__vllm_kwargs,
                cls.__temperature]

    @classmethod
    def get_spec_id(cls) -> str:
        return "97080db1-32c3-423a-87eb-08a58060d300"

    @classmethod
    def get_spec_name(cls) -> str:
        return "vLLM"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of vLLM."

    def get_impl(self):
        if self.__client is None:
            self.__client = VllmServer(api_url=self.get_parameter_value(self.__base_url_conf),
                                 model=self.get_parameter_value(self.__model_name_conf),
                                 vllm_kwargs=json.loads(self.get_parameter_value(self.__vllm_kwargs)),
                                 temperature=float(self.get_parameter_value(self.__temperature)))
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
