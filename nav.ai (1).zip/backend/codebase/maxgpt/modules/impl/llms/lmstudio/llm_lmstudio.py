import hashlib

from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.lmstudio import LMStudio as LlamaIndexLMStudio

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter

class LMStudio(AbstractLLM):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_LM_STUDIO_BASE_URL",
        label="Base URL",
        description="Base url for the lm studio api. Defaults to http://0.0.0.0:1234/v1",
        default="http://0.0.0.0:1234/v1",
        data_type=DataType.URL)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_LM_STUDIO_MODEL_NAME",
        label="Model Name",
        description="The model hosted via the provided lm studio api url.",
        data_type=DataType.TEXT)
    __temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_LM_STUDIO_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        default="0.10",
        data_type=DataType.FLOAT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__temperature]

    @classmethod
    def get_spec_id(cls) -> str:
        return "6ecbe079-b1ff-46e8-96cc-72849a0d366b"

    @classmethod
    def get_spec_name(cls) -> str:
        return "LM-Studio"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of LM-Studio to access LLMs deployed on it."

    def get_impl(self):
        if self.__client is None:
            self.__client = LlamaIndexLMStudio(base_url=self.get_parameter_value(self.__base_url_conf),
                                   model_name=self.get_parameter_value(self.__model_name_conf),
                                   temperature=float(self.get_parameter_value(self.__temperature)),
                                   request_timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
