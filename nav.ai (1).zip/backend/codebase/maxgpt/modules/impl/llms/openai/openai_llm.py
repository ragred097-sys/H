import json

from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.constants import DEFAULT_CONTEXT_WINDOW
from llama_index.llms.openai import OpenAI

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter


class LLMOpenAI(AbstractLLM):
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_MODEL_NAME",
        label="Model Name",
        description="The model to use.",
        data_type=DataType.TEXT)

    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_API_KEY",
        label="API Key",
        description="The key to get access to the llm hosted at OpenAI services.",
        secured=True,
        data_type=DataType.TEXT)

    __temperature_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        optional=True,
        default="0.2",
        data_type=DataType.FLOAT)

    __additional_kwargs_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_ADDITIONAL_KWARGS",
        label="Additional Keyword Arguments",
        optional=True,
        default="{}",
        description="Additional Keyword Arguments known to the selected model.",
        data_type=DataType.JSON)

    __ctx_window_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_CTX_WINDOW",
        label="Context Window",
        optional=True,
        default=str(DEFAULT_CONTEXT_WINDOW),
        description=f"Context window size. Defaults to {DEFAULT_CONTEXT_WINDOW} tokens",
        data_type=DataType.INTEGER)

    __max_tokens_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_MAX_TOKENS",
        label="Max tokens to generate",
        optional=True,
        default=str(3000),
        description=f"Max tokens limit that the llm should generate. Defaults to 3000 tokens.",
        data_type=DataType.INTEGER)

    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OPENAI_BASE_URL",
        label="Base URL (Optional)",
        description="Base url to the OpenAI model if hosted on a private machine.",
        optional=True,
        data_type=DataType.URL)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__model_name_conf,
                cls.__api_key_conf,
                cls.__temperature_conf,
                cls.__max_tokens_conf,
                cls.__ctx_window_conf,
                cls.__additional_kwargs_conf,
                cls.__base_url_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "1058a7b7-30a8-4c04-85ee-3ab2effac6cc"

    @classmethod
    def get_spec_name(cls) -> str:
        return "OpenAI"

    @classmethod
    def get_spec_description(cls) -> str:
        return "The official OpenAI inference."

    def get_impl(self):
        if self.__client is None:
            self.__client = OpenAI(api_base=self.get_parameter_value(self.__base_url_conf),
                                   model=self.get_parameter_value(self.__model_name_conf),
                                   api_key=self.get_parameter_value(self.__api_key_conf),
                                   temperature=float(self.get_parameter_value(self.__temperature_conf)),
                                   context_window=int(self.get_parameter_value(self.__ctx_window_conf)),
                                   additional_kwargs=json.loads(self.get_parameter_value(self.__additional_kwargs_conf)),
                                   timeout=360.0)

        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
