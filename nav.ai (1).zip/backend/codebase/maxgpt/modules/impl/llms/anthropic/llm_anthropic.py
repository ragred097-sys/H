import hashlib
import json

from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.anthropic import Anthropic

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter

class LLMAnthropic(AbstractLLM):
# Mandatory

    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_ANTHROPIC_MODEL_NAME",
        label="Model Name",
        description="The Anthropic model to use.",
        data_type=DataType.TEXT)
    __temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_ANTHROPIC_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        default="0.2",
        data_type=DataType.FLOAT)
    __api_key_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_ANTHROPIC_API_KEY",
        label="API Key",
        description="Your api key to access the anthropic service.",
        data_type=DataType.TEXT)

# Optional

    __additional_kwargs_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_ANTHROPIC_ADDITIONAL_KWARGS",
        label="Additional Kwargs",
        description="Additional Kwargs for the anthropic client (expert).",
        optional=True,
        default="{}",
        data_type=DataType.JSON)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__model_name_conf,
                cls.__temperature,
                cls.__api_key_conf,
                cls.__additional_kwargs_conf]

    @classmethod
    def get_spec_id(cls) -> str:
        return "59e368dc-c817-4032-aecb-b2c7339de6f9"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Anthropic"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Anthropic to access LLMs deployed on it."

    def get_impl(self):
        if self.__client is None:
            self.__client = Anthropic(model=self.get_parameter_value(self.__model_name_conf),
                                temperature=float(self.get_parameter_value(self.__temperature)),
                                api_key=self.get_parameter_value(self.__api_key_conf),
                                additional_kwargs=json.loads(self.get_parameter_value(self.__additional_kwargs_conf)),
                                timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
