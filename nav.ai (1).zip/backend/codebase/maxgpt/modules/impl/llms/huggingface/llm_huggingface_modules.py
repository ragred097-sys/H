import json
import logging
import os

import torch
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.constants import DEFAULT_CONTEXT_WINDOW, DEFAULT_NUM_OUTPUTS
from llama_index.llms.huggingface import HuggingFaceInferenceAPI, HuggingFaceLLM
from llama_index.llms.huggingface.base import DEFAULT_HUGGINGFACE_MODEL
from pydash import to_lower
from transformers import BitsAndBytesConfig, AutoTokenizer, AutoModelForCausalLM, AutoConfig

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter

# Configure Huggingface Deployed Model
os.environ['HF_HUB_DISABLE_SYMLINKS_WARNING'] = 'True'


class LLMHuggingface(AbstractLLM):
    _api_token_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_API_TOKEN",
        label="API Token",
        description="If not used locally but using the Huggingface inference API, this api token must be provided.",
        data_type=DataType.TEXT,
        optional=True,
        secured=True)
    _context_window_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_CONTEXT_WINDOW",
        label="Context Window",
        description="Size of the HF context window.",
        optional=True,
        default=DEFAULT_CONTEXT_WINDOW,
        data_type=DataType.INTEGER)
    _max_new_tokens_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_MAX_NEW_TOKENS",
        label="Max New Tokens",
        description="Maximum new tokens.",
        optional=True,
        default=DEFAULT_NUM_OUTPUTS,
        data_type=DataType.INTEGER)
    _generate_kwargs_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_GENERATE_KWARGS",
        label="Generate Kwargs",
        optional=True,
        description="kwargs that can be understood by the used model.",
       data_type=DataType.JSON)
    _tokenizer_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_TOKENIZER_NAME",
        label="Tokenizer Name",
        optional=True,
        description="The name of the used tokenizer",
        data_type=DataType.TEXT)
    _stopping_ids_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_STOPPING_IDS",
        label="Stopping IDs",
        optional=True,
        description="See HF documentation for further details.",
        data_type=DataType.TEXT)
    _tokenizer_kwargs_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_TOKENIZER_KWARGS",
        label="Tokenizer Kwargs",
        optional=True,
        description="Json structured kwargs for the tokenizer.",
       data_type=DataType.JSON)
    _model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_MODEL_NAME",
        label="Model Name",
        description="The name of the HF model to use.",
        optional=False,
        data_type=DataType.TEXT)
    _model_message_syntax: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_MESSAGE_SYNTAX",
        label="Message syntax",
        description="A dictionary to convert message objects to valid model strings for messages of different roles (placeholder = message.content). E.g. { system: '<|system|>\\n{message.content}</s>\\n' }",
        optional=True,
       data_type=DataType.JSON)
    _chat_template: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_HF_CHAT_TEMPLATE",
        label="Chat Template",
        description="If the selected model does not provide a chat template from it's pretrained model instance, you need to specify the chat_template manually. E.g. {system_message}\n{user_message}\n{assistant_message}",
        optional=True,
        data_type=DataType.TEXT)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls._context_window_conf,
                cls._max_new_tokens_conf,
                cls._generate_kwargs_conf,
                cls._tokenizer_name_conf,
                cls._tokenizer_kwargs_conf,
                cls._stopping_ids_conf,
                cls._api_token_conf,
                cls._model_name_conf,
                cls._chat_template,
                cls._model_message_syntax]

    @classmethod
    def get_spec_id(cls) -> str:
        return "7f5db693-669c-4b73-a3b8-ff0a0a95726d"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Huggingface"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Huggingface to access LLM deployed on it."

    def _messages_to_prompt(self, messages):
        conversation_mapping = json.loads(self.get_parameter_value(self._model_message_syntax))

        if "system" not in conversation_mapping or "{message.content}" not in conversation_mapping['system']:
            raise ValueError("M_LLM_HF_MESSAGE_SYNTAX must have the attribute 'system' set to a valid syntax string.")
        if "user" not in conversation_mapping or "{message.content}" not in conversation_mapping['user']:
            raise ValueError("M_LLM_HF_MESSAGE_SYNTAX must have the attribute 'user' set to a valid syntax string.")
        if "assistant" not in conversation_mapping or "{message.content}" not in conversation_mapping['assistant']:
            raise ValueError(
                "M_LLM_HF_MESSAGE_SYNTAX must have the attribute 'assistant' set to a valid syntax string.")

        system_split = conversation_mapping['system'].split("{message.content}")
        user_split = conversation_mapping['user'].split("{message.content}")
        assistant_split = conversation_mapping['assistant'].split("{message.content}")

        prefixes: dict = {
            'system': system_split[0],
            'user': user_split[0],
            'assistant': assistant_split[0]}
        suffixes: dict = {
            'system': system_split[1] if len(system_split) > 1 else "",
            'user': user_split[1] if len(user_split) > 1 else "",
            'assistant': assistant_split[1] if len(assistant_split) > 1 else ""}

        prompt = ""
        for message in messages:
            if to_lower(message.role) == "system":
                prompt += f"{prefixes['system']}{message.content}{suffixes['system']}"
            elif to_lower(message.role) == "user":
                prompt += f"{prefixes['user']}{message.content}{suffixes['user']}"
            elif to_lower(message.role) == "assistant":
                prompt += f"{prefixes['assistant']}{message.content}{suffixes['assistant']}"

        # ensure we start with a system prompt, insert blank if needed
        if not prompt.startswith(prefixes['system']):
            prompt = prefixes['system'] + suffixes['system'] + prompt

        # add final assistant prompt
        prompt = prompt + prefixes['assistant']

        print(prompt)

        return prompt

    def _get_hf_inference_client(self):
        return HuggingFaceInferenceAPI(
            model_name=self.get_parameter_value(self._model_name_conf),
            token=self.get_parameter_value(self._api_token_conf)
        )

    def _get_hf_local_client(self):

        if torch.cuda.is_available():
            print("HF module is using CUDA")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True
            )
            model_kwargs = {"quantization_config": quantization_config}
            device = "cuda"
        elif torch.backends.mps.is_available():
            print("HF module is using MPS")
            model_kwargs = {}
            quantization_config = None
            device = "mps"
        else:
            device = "auto"
            model_kwargs = {}
            quantization_config = None

        ### We configure the tokenizer ourselves to get control other chat templates and other configurations.
        t_kwargs = json.loads(self.get_parameter_value(self._tokenizer_kwargs_conf)) if self.get_parameter_value(
            self._tokenizer_kwargs_conf) is not None else {}
        tokenizer_name = self.get_parameter_value(self._tokenizer_name_conf) if self.get_parameter_value(self._tokenizer_name_conf) is not None else self.get_parameter_value(self._model_name_conf)
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name, **t_kwargs)
        model = AutoModelForCausalLM.from_pretrained(self.get_parameter_value(self._model_name_conf),
                                                     device_map=device, **model_kwargs)
        config = AutoConfig.from_pretrained(self.get_parameter_value(self._model_name_conf))
        if hasattr(tokenizer, "chat_template") and tokenizer.chat_template:
            logging.log(logging.DEBUG, "Chat template for HF model already exists in pre-trained model:",
                        tokenizer.chat_template)
        elif hasattr(config, "chat_template"):
            logging.log(logging.DEBUG, "Chat template for HF model taken from auto config of model ",
                        tokenizer.chat_template)
            tokenizer.chat_template = config.chat_template
        else:
            chat_template = self.get_parameter_value(self._chat_template)
            tokenizer.chat_template = chat_template

        return HuggingFaceLLM(
            context_window=int(self.get_parameter_value(self._context_window_conf)),
            max_new_tokens=int(self.get_parameter_value(self._max_new_tokens_conf)),
            generate_kwargs=json.loads(self.get_parameter_value(self._generate_kwargs_conf)) if self.get_parameter_value(self._generate_kwargs_conf) is not None else None,
            tokenizer=tokenizer,
            device_map=device,
            stopping_ids=json.loads(self.get_parameter_value(self._stopping_ids_conf)) if self.get_parameter_value(self._stopping_ids_conf) is not None else None,
            model=model,
            messages_to_prompt=self._messages_to_prompt if self.get_parameter_value(
                self._model_message_syntax) is not None else None
        )

    def get_impl(self):
        if self.__client is None:
            if self.get_parameter_value(self._api_token_conf) is not None:
                self.__client = self._get_hf_inference_client()
            else:
                self.__client = self._get_hf_local_client()
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
