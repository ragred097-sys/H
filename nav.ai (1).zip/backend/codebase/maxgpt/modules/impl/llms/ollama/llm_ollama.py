import hashlib

from llama_index.core.base.llms.base import BaseLLM
from llama_index.llms.ollama import Ollama

from maxgpt.core import DataType
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.modules import ModuleSpecParameter

class LLMOllama(AbstractLLM):
    __base_url_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OLLAMA_BASE_URL",
        label="Base URL",
        description="Base url the ollama model is hosted under.",
        default="http://0.0.0.0:11434",
        data_type=DataType.URL)
    __model_name_conf: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OLLAMA_MODEL_NAME",
        label="Model Name",
        description="The Ollama model to use.",
        data_type=DataType.TEXT)
    __temperature: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OLLAMA_TEMPERATURE",
        label="Temperature",
        description="The temperature to use for sampling (0.0 <= x <= 1.0).",
        default="0.2",
        data_type=DataType.FLOAT)

    __json_mode: ModuleSpecParameter = ModuleSpecParameter(
        name="M_LLM_OLLAMA_JSON_MODE",
        label="Sets json mode of the model",
        description="Sets json mode of the model if the model supports it. Defaults to False.",
        default="False",
        data_type=DataType.BOOLEAN)

    __client: BaseLLM = None

    @classmethod
    def get_spec_parameters(cls) -> list[ModuleSpecParameter]:
        return [cls.__base_url_conf,
                cls.__model_name_conf,
                cls.__temperature,
                cls.__json_mode]

    @classmethod
    def get_spec_id(cls) -> str:
        return "b21dd0f5-e06a-41b9-bdb5-39ba3e0bbece"

    @classmethod
    def get_spec_name(cls) -> str:
        return "Ollama"

    @classmethod
    def get_spec_description(cls) -> str:
        return "Integration of Ollama to access LLMs deployed on it."

    def get_impl(self):
        if self.__client is None:
            self.__client = Ollama(base_url=self.get_parameter_value(self.__base_url_conf),
                                   model=self.get_parameter_value(self.__model_name_conf),
                                   temperature=float(self.get_parameter_value(self.__temperature)),
                                   json_mode=str(self.get_parameter_value(self.__json_mode)).lower() == "true",
                                   request_timeout=360.0)
        return self.__client

    def is_available(self) -> bool:
        # TODO: Availability Check
        return True
