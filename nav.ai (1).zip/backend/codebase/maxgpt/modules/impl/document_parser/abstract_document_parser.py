from abc import ABC, abstractmethod
from typing import Iterator

from maxgpt.modules.modules import ModuleType
from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.document_parser.doc_element import DocumentElement

from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex

class AbstractDocumentParser(AbstractModule):
    """
    Abstract base class for document parsers.
    """

    @abstractmethod
    def parse(self, filename: str) -> Iterator[DocumentElement]:
        pass

    @classmethod
    def get_spec_type(cls) -> ModuleType:
        return ModuleType.DOCUMENT_PARSER

    @abstractmethod
    def is_available(self) -> bool:
        return True

    @abstractmethod
    def get_impl(self, embed_model: BaseEmbedding) -> BaseIndex[IndexDict]:
        pass

    @abstractmethod
    def persist(self):
        pass
