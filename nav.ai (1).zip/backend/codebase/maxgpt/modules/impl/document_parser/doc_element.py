from typing import List, Optional, Tuple, Dict
from enum import Enum
from collections import namedtuple

Coordinate = namedtuple('Coordinate', ['x', 'y'])

class DocumentElementType(Enum):
    TITLE = "title"
    PARAGRAPH = "paragraph"
    IMAGE = "image"
    TABLE = "table"

class DocumentElement():
    """
    Represents an element extracted from a document, such as title, paragraph, image, etc.
    """
    type: DocumentElementType
    text: List[str]
    page: Optional[int] = 1  
    top_left: Optional[Coordinate] = None
    bottom_right: Optional[Coordinate] = None
    metadata: Optional[List[Dict[str, str]]] = None
