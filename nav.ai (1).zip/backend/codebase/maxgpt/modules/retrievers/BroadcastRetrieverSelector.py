from typing import Sequence

from llama_index.core import QueryBundle
from llama_index.core.base.base_selector import BaseSelector, SelectorResult, SingleSelection
from llama_index.core.prompts.mixin import PromptDictType
from llama_index.core.tools import ToolMetadata


class BroadcastRetrieverSelector(BaseSelector):
    """A selector that broadcasts queries to all retriever tools."""

    def __init__(self,  **kwargs):
        super().__init__(**kwargs)

    def _get_prompts(self) -> PromptDictType:
        # You can return an empty prompt dictionary or modify it based on your needs
        return {}

    def _update_prompts(self, prompts_dict: PromptDictType) -> None:
        # Optionally update the prompts if needed
        pass

    async def _aselect(self, choices: Sequence[ToolMetadata], query: QueryBundle):
        # Asynchronous method for selecting tools (we broadcast here)
        return [tool for tool in choices]

    def _select(self, choices: Sequence[ToolMetadata], query: QueryBundle):
        # Synchronous method for selecting tools (we broadcast here)
        selections = [
            SingleSelection(index=i, reason="Broadcasting")
            for i, index in enumerate(choices)
        ]
        return SelectorResult(selections=selections)