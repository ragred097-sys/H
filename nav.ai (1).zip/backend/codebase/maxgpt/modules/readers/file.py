import os
import tempfile
from pathlib import Path
from typing import Optional, Dict, List

from fsspec import AbstractFileSystem
from llama_index.core import Document
from llama_index.readers.file import PptxReader


class SingleSlidePptxReader(PptxReader):

    def __init__(self):
        self.__lazy_initialized = False

    def load_data(
        self,
        file: Path,
        extra_info: Optional[Dict] = None,
        fs: Optional[AbstractFileSystem] = None,
    ) -> List[Document]:
        if not self.__lazy_initialized:
            super().__init__()

        """
        We are enhancing the default behavior of the PPTX Reader of llamaindex
        to achieve a per slide split into documents.
        The idea is that slides in a presentation are a valid semantic closure around the content
        """
        from pptx import Presentation

        if fs:
            with fs.open(file) as f:
                presentation = Presentation(f)
        else:
            presentation = Presentation(file)

        documents: List[Document] = []

        for i, slide in enumerate(presentation.slides):
            slide_extra_info = extra_info or {}
            result = ""
            result += f"\n\nSlide #{i+1}: \n"
            slide_extra_info['maxgpt_slide_number'] = i+1
            slide_extra_info['maxgpt_doc_reference'] = str(file.absolute()) + "#" + str(i+1)
            for shape in slide.shapes:
                if hasattr(shape, "image"):
                    image = shape.image
                    # get image "file" contents
                    image_bytes = image.blob
                    # temporarily save the image to feed into model
                    f = tempfile.NamedTemporaryFile("wb", delete=False)
                    try:
                        f.write(image_bytes)
                        f.close()
                        result += f"\n Image: {self.caption_image(f.name)}\n\n"
                    finally:
                        os.unlink(f.name)

                try:
                    if hasattr(shape, 'table'):
                        table = [[cell.text for cell in row.cells] for row in shape.table.rows]
                        if len(table) > 0:
                            result += f"\n Table: {str(table)}\n"
                except Exception as e:
                    print(str(e))

                if hasattr(shape, "text"):
                    result += f"{shape.text}\n"

            documents.append(Document(text=result, metadata=slide_extra_info))
        return documents
