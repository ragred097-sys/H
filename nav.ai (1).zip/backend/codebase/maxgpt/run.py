import os

from waitress import serve
from argparse import ArgumentParser
from dotenv import load_dotenv

load_dotenv()

if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-m", "--mode", default="DEV", dest="mode",
                        help="Mode of the application [DEV, PRODUCTION]")
    args = parser.parse_args()

    from maxgpt.api.main import app
    if args.mode == 'PRODUCTION':
        no_of_threads = int(os.environ.get('API_THREADS', 1))
        print (f"MaximumGPT is running in {str(args.mode)} mode using waitress with {no_of_threads} threads.")
        serve(app, host=os.environ.get('APP_HOST', '0.0.0.0'), port=int(os.environ.get('APP_PORT', 5001)), threads=no_of_threads)
    else:
        print(f"MaximumGPT is running in {str(args.mode)}. No multi-threading and potentially unstable and insecure.")
        app.run(host=os.environ.get('APP_HOST', '0.0.0.0'), port=int(os.environ.get('APP_PORT', 5001)))