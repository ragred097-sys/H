import enum

class DataType(enum.Enum):
    TEXT = "text"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    DATETIME = "datetime"
    URL = "url"
    JSON = "json"
    ENUM = "enum"
    #EMAIL = "email"

    @staticmethod
    def from_value(value: str) -> 'DataType':
        try:
            return DataType(value)
        except KeyError:
            raise ValueError(f"No DataType found for value '{value}'.")
