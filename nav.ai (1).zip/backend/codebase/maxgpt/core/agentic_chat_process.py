import abc
import json
import logging
import re
from typing import cast, List, Optional, Union, Callable

from llama_index.core import PromptTemplate
from llama_index.core.agent.workflow import BaseWorkflowAgent
from llama_index.core.base.llms.types import ChatMessage, ImageBlock, ContentBlock, TextBlock
from llama_index.core.base.llms.types import MessageRole as LlamaIndexMessageRole
from llama_index.core.data_structs import IndexDict
from llama_index.core.indices.base import BaseIndex
from llama_index.core.indices.vector_store import VectorIndexRetriever

from llama_index.core.llms.function_calling import FunctionCallingLLM
from llama_index.core.tools import FunctionTool, BaseTool
from llama_index.core.vector_stores import MetadataFilters, MetadataFilter
from llama_index.core.workflow import Context, Event
from pydash import to_lower

from maxgpt.api.internal.utils import convert_to_base64, context_node_to_content_dict, append_dataframe_from_part
from maxgpt.core.internal.EnhancedAgentWorkflow import EnhancedAgentWorkflow, ReorderedFunctionAgent, ReorderedReActAgent
from maxgpt.core.internal.utils import get_file_from_file_storage
from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
from maxgpt.modules.impl.function_tools.function_tool_state_updater import get_tools as StateUpdaterTools
from maxgpt.modules.impl.function_tools.function_tools import AbstractFunctionTool
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleRegistry
from maxgpt.services import database
from maxgpt.services.database_model import ConversationModel, MessageModel, MessageProcessModel, MessagePartType, \
    MessagePartModel, \
    MessageRole, DataSourceModel, DataObjectModel, IngestProcessModel, AttachmentModel, DocumentType, \
    AgentWorkflowModel, AgentModel, SystemInstructionModel, AgentWorkflowAgentType, AssistantModel, \
    MessageEventType

import pandasai as pai
from pandasai.schemas.df_config import Config

base64_pattern = re.compile(r"^data:(image/[^;]+);base64,")

class AgenticWorkflowSourceNodeEvent(Event):
    type: str = MessageEventType.CONTEXT_NODE.value
    event_type: str = MessageEventType.CONTEXT_NODE.value
    content_dict: dict
    meta: str = None

def retrieve_context(ctx: Context, query: str, index: BaseIndex[IndexDict], filters: Optional[MetadataFilters] = None, similarity_top_k: int = 3):
    """Fetch relevant context from the given vector index."""
    retriever = VectorIndexRetriever(index=index, similarity_top_k=similarity_top_k, filters=filters, verbose=True)
    retrieved_nodes = retriever.retrieve(query)
    if ctx:
        for node in retrieved_nodes:
            ctx.write_event_to_stream(AgenticWorkflowSourceNodeEvent(content_dict=context_node_to_content_dict(node)))
    else:
        logging.log(logging.WARNING, f"No context found when retrieving context information during workflow execution.")

    if not retrieved_nodes:
        retrieved_nodes = []

    return json.dumps([context_node_to_content_dict(node) for node in retrieved_nodes])

def create_retriever_tool(index, filters: Optional[MetadataFilters] = None, similarity_top_k: int = 3, tool_name: str = "retrieve_context"):
    def retrieve_context_wrapped(ctx: Context, query: str, **kwargs):
        """
        This function loads additional context information from a remote vector store and returns it as valid json array.
        It supports to answer user prompts with potentially helpful context information.

        Args:
            ctx: The llamaindex workflow Context
            query: The user query that is used to load data from a vector store
            **kwargs: additional kwargs if provided
        Returns:
            Retrieved Context Information from a vector store (JSON).
        """
        try:
            print("Wrapped function called with query:", query)
            return retrieve_context(ctx, query, index, filters, similarity_top_k)
        except Exception as e:
            print("Exception in retrieve_context_wrapped:", e)
            raise e
    retrieve_context_wrapped.__name__ = tool_name
    return FunctionTool.from_defaults(fn=retrieve_context_wrapped, name=tool_name)

class AgenticChatProcess(abc.ABC):

    def __init__(self, conversation: ConversationModel, user_message_parts: dict, overrides: List[dict]):
        self.__conversation: ConversationModel = conversation
        self.__overrides: dict = {}
        for override in overrides:
            self.__overrides[override['name']] = override['value']

        # 1. Fetch and build chat history for additional context information (memory)
        # - SYSTEM prompts always remain inside the history
        # - the number of chat messages (ASSISTANT or USER) can be overwritten with override_chat_history_message_limit. The default is 10 messages
        # - SYSTEM prompts are not deducted from the limited history messages
        # For dev: we need to reverse the list of messages to fetch the LAST n messages of the conversation and then reverse again to hand it over to llama_index in the correct order!
        _chat_history_message_limit = self.__overrides[
            'override_chat_history_message_limit'] if 'override_chat_history_message_limit' in self.__overrides else 8
        self.__chat_history = []
        self.__pandas_dataframes = []
        for i, message in enumerate(list(reversed(self.__conversation.messages))):
            # TODO: DK: I think we need to skip system prompts from the chat history in case of workflows. Each agent should only use it's own sys prompts and nothing else.
            if message.role == MessageRole.SYSTEM or _chat_history_message_limit > 0:
                if message.role != MessageRole.SYSTEM:
                    _chat_history_message_limit -= 1

                content_blocks: List[ContentBlock] = []
                for part in message.parts:
                    if part.type == MessagePartType.IMAGE:
                        content_blocks.append(ImageBlock(url=part.content))
                    elif part.type == MessagePartType.TEXT:
                        content_blocks.append(TextBlock(text=part.content))
                    elif part.type == MessagePartType.DOCUMENT:
                        append_dataframe_from_part(part.content, self.__pandas_dataframes)
                    elif part.type == MessagePartType.ATTACHMENT_REFERENCE:
                        # fetch attachment meta from db
                        _attachment: Optional[AttachmentModel] = AttachmentModel.query.get(part.content)
                        if _attachment:
                            # get image from file storage
                            if _attachment.id not in [ca.attachment_id for ca in self.__conversation.attachments]:
                                raise Exception(
                                    f"Corrupted data. Attachment with identifier '{_attachment.id}' belongs to another conversation")
                            if _attachment.type == DocumentType.IMAGE:
                                file_object = get_file_from_file_storage(_attachment)
                                content_blocks.append(ImageBlock(url="data:image/jpeg;base64," + convert_to_base64(file_object)))
                            elif _attachment.type == DocumentType.TEXT:
                                file_object = get_file_from_file_storage(_attachment)
                                # Try processing supported structured data files
                                append_dataframe_from_part(convert_to_base64(file_object), self.__pandas_dataframes, _attachment.mime_type)
                            else:
                                _attachment_dict = _attachment.to_dict()
                                _attachment_dict.pop(
                                    "thumbnail")  # Avoid base64 encoded string of thumbnail in system prompt to save tokens :D
                                _attachment_ref_instruct = (
                                    f"The user might ask a question about a media file. If he does without further referencing which document, use the following attachment reference details: {_attachment_dict}.\n"
                                    f"In particular, make use the objectReference if you need to refer to the document with its original identifier.")
                                content_blocks.append(TextBlock(text=_attachment_ref_instruct))

                self.__chat_history.append(
                    ChatMessage(role=LlamaIndexMessageRole(to_lower(message.role.value)), blocks=content_blocks))

        self.__chat_history = list(reversed(self.__chat_history))

        # 2. Process and create persistence entities for the provided user message
        #    (This follows "what comes in, goes out" while the actual user prompt to the llm later is different)
        self.__user_message = MessageModel(role=MessageRole.USER, conversation=self.__conversation)
        database.session.add(self.__user_message)

        # Parse and process the message parts of the new user message
        for i, part in enumerate(user_message_parts):
            database.session.add(
                MessagePartModel(type=MessagePartType[part['type']], sequence=i, content=part['content'],
                                 message=self.__user_message))

    def get_user_message(self) -> MessageModel:
        return self.__user_message

    def __normalize_agent_name(self, raw_name: str):
        return raw_name.replace('"', '').replace(" ", "_")

    def __get_index_from_data_source(self, data_source: DataSourceModel):
        """
        Checks if the data source has ingested files and returns the underlying vector store client.
        """
        ingested_files: List[DataObjectModel] = []
        for process in IngestProcessModel.query.filter(
                IngestProcessModel.data_source_id == data_source.id).all():
            ingested_files = ingested_files + DataObjectModel.query.filter(
                DataObjectModel.ingest_process_id == process.id).all()
        if ingested_files:
            _embed_model = fetch_module(data_source.embedding_model_id).get_impl()
            return cast(AbstractVectorStore, fetch_module(data_source.vector_store_id)).get_impl(
                _embed_model)
        else:
            logging.log(logging.WARNING,
                        f"*** Skipping DataSource '{data_source.name}' because it has no ingested files ***")
            return None

    def create_workflow_agent(self, name: str, agent_description: str , system_prompt: str,
                              llm: AbstractLLM, can_handoff_to: Optional[List[str]],
                              tools: Optional[List[Union[BaseTool, Callable]]] = None) -> BaseWorkflowAgent:
        _llm = llm.get_impl().copy()
        if isinstance(_llm, FunctionCallingLLM) and _llm.metadata and _llm.metadata.is_function_calling_model:
            return ReorderedFunctionAgent(name=name,
                                           description=agent_description,
                                           system_prompt=system_prompt,
                                           llm=_llm,
                                           can_handoff_to=can_handoff_to,
                                           tools=tools)
        else:
            logging.log(logging.INFO, f"The llm '{llm.get_name()}' is not function calling (native). ReActAgent is used instead.")
            return ReorderedReActAgent(name=name,
                                          description=agent_description,
                                          system_prompt=system_prompt,
                                          llm=_llm,
                                          can_handoff_to=can_handoff_to,
                                          tools=tools)

    async def async_execute(self):
        """
        Generates a llama index based function agents workflow with agents for our entities [AgentModel / AssistantModel].
        One of the function agents will be root.
        Each agent can have restricted hand off relations to other agents.
        Assistants and Agents might bring multiple SystemPrompts, which will be concatenated all together into one for the function agent.
        If a data source is involved, the following behavior applies:
        - If the data source is coming with an agent, the agent gets a retriever tool attached in the function agent wrapper for each of the data sources.
        - If the data source comes from the conversation, the datasource is attached as a retriever tool to the root agent.
        - If a data source has been defined as part of the workflow, it will we wrapped in a generic function agent with a retriever tool for the data source.
        #TODO: If a DOCUMENT is sent as message part, we must create an in-memory index that we set into the context of the workflow to make it available for all agents and their tools.
        """
        if not self.__conversation.agent_workflow:
            raise Exception(f"Bad request. An agentic workflow requires the according link in the conversation. Your conversation has no agent workflow.")

        logging.log(logging.INFO, f"*** Preparing Agentic Workflow MessageProcess ***")

        chat_history = self.__chat_history
        __agent_workflow: AgentWorkflowModel = self.__conversation.agent_workflow
        _conversation_llm_module: AbstractLLM = fetch_module(self.__conversation.llms[0].module_id)
        _conversation_llm = _conversation_llm_module.get_impl()

        # Get Context Retrieval Configurations from overrides
        _token_limit = self.__overrides[
            'override_chat_memory_buffer_token_limit'] if 'override_chat_memory_buffer_token_limit' in self.__overrides else 100000
        _similarity_top_k = self.__overrides[
            'override_embedding_similarity_top_k'] if 'override_embedding_similarity_top_k' in self.__overrides else 3
        _similarity_top_p = self.__overrides[
            'override_embedding_similarity_top_p'] if 'override_embedding_similarity_top_p' in self.__overrides else 0.9

        logging.log(logging.INFO, f"*** Generating state updater function tool shared by all agents ***")
        default_tools = StateUpdaterTools()

        logging.log(logging.INFO, f"*** Generate prompt from message blocks ***")
        _user_message = ""
        for message_part in self.__user_message.parts:
            if message_part.type == MessagePartType.TEXT:
                _user_message += (message_part.content + "\n")
            if message_part.type == MessagePartType.ATTACHMENT_REFERENCE:
                _attachment = AttachmentModel.query.get(message_part.content)
                if _attachment:
                    _attachment_dict = _attachment.to_dict()
                    if _attachment.id not in [ca.attachment_id for ca in self.__conversation.attachments]:
                        raise Exception(
                            f"Corrupted data. Attachment with identifier '{_attachment.id}' belongs to another conversation")

                    _attachment_dict.pop(
                        "thumbnail")  # Avoid base64 encoded string of thumbnail in system prompt to save tokens :D
                    if _attachment.type == DocumentType.VIDEO:
                        _attachment_ref_instruct = (f"The user might ask a question about a video. If he does without further referencing it, use the following attachment to answer him:\n"
                                                    f"{_attachment_dict}.\n"
                                                    f"In particular, use the field objectReference as id referencing the video and use the description to answer questions about the content of the video when its available and not instructed otherwise in order to avoid additional tool invocations.")
                        _message_blocks: List[ContentBlock] = [TextBlock(text=_attachment_ref_instruct)]
                        chat_history.append(ChatMessage(role=LlamaIndexMessageRole('system'), blocks=_message_blocks))
                    else:
                        _attachment_ref_instruct = (
                            f"The user might ask a question about a media file. If he does without further referencing which document, use the following attachment reference details: {_attachment_dict}.\n"
                            f"In particular, make use the objectReference if you need to refer to the document with its original identifier.")
                        _message_blocks: List[ContentBlock] = [TextBlock(text=_attachment_ref_instruct)]
                        chat_history.append(ChatMessage(role=LlamaIndexMessageRole('system'), blocks=_message_blocks))

        # Creating the functional agents that are part of the workflow.
        # Collection all handoff relations defined in the workflow and build up a lookup map by type and from id to a list of to ids
        logging.log(logging.INFO,
                    f"*** Preparing lookup structures for hand off relations ***")
        _workflow_handoff_relation_lookup = {
            AgentWorkflowAgentType.AGENT.value: {},
            AgentWorkflowAgentType.ASSISTANT.value: {},
            AgentWorkflowAgentType.DATA_SOURCE.value: {}
        }
        for _workflow_handoff_relation in __agent_workflow.handoff_relations:
            _to_node_entity: Optional[AgentModel] = None
            if _workflow_handoff_relation.to_type == AgentWorkflowAgentType.AGENT:
                #Check if handoff agent is not soft-deleted
                _to_node_entity: AgentModel = AgentModel.query.filter(
                    AgentModel.id == _workflow_handoff_relation.to_id,
                    AgentModel.deleted_at.is_(None)
                ).first()
            if _workflow_handoff_relation.to_type == AgentWorkflowAgentType.ASSISTANT:
                #Check if handoff assistant is not soft-deleted
                _to_node_entity: AssistantModel = AssistantModel.query.filter(
                    AssistantModel.id == _workflow_handoff_relation.to_id,
                    AssistantModel.deleted_at.is_(None)
                ).first()
            if _workflow_handoff_relation.to_type == AgentWorkflowAgentType.DATA_SOURCE:
                #Check if handoff data source is not soft-deleted
                _to_node_entity: DataSourceModel = DataSourceModel.query.filter(
                    DataSourceModel.id == _workflow_handoff_relation.to_id,
                    DataSourceModel.deleted_at.is_(None)
                ).first()

            if _workflow_handoff_relation.from_id not in _workflow_handoff_relation_lookup[_workflow_handoff_relation.from_type.value]:
                _workflow_handoff_relation_lookup[_workflow_handoff_relation.from_type.value][
                    _workflow_handoff_relation.from_id] = []
            if _to_node_entity:
                _workflow_handoff_relation_lookup[_workflow_handoff_relation.from_type.value][
                    _workflow_handoff_relation.from_id].append((self.__normalize_agent_name(to_lower(_workflow_handoff_relation.to_type.value) + "#" + _to_node_entity.name + "#" + _to_node_entity.id), _to_node_entity))

        logging.log(logging.INFO,f"*** Creating FunctionAgents ***")
        functional_agents_by_id = {}

        # AGENTS
        logging.log(logging.INFO,f"*** \tAgents")
        if len(__agent_workflow.agent_relations) == 0:
            logging.log(logging.INFO, f"*** \tNo agents nodes found ")
        else:
            for _agent_relation in __agent_workflow.agent_relations:
                _agent: AgentModel = AgentModel.query.get(_agent_relation.agent_id)
                logging.log(logging.INFO,f"*** \t\t{_agent.name}")
                _agent_llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_agent.llm_id))

                logging.log(logging.INFO, f"*** \t\t\tMerging System Prompts...")
                _agent_system_prompt = ""
                for _sys_instruct_relation in _agent.system_instructions:
                    _sys_instruct = SystemInstructionModel.query.get(_sys_instruct_relation.system_instruction_id)
                    _agent_system_prompt += _sys_instruct.message + "\n"
                if _agent.custom_system_instruction:
                    _agent_system_prompt += _agent.custom_system_instruction + "\n"

                logging.log(logging.INFO, f"*** \t\t\tConfiguring Tools...")
                _tools = default_tools.copy()
                if _agent.function_tools:
                    for _function_tool_relation in _agent.function_tools:
                        _function_tool_module = cast(AbstractFunctionTool, ModuleRegistry.get_module(_function_tool_relation.module_id))
                        _function_tools: List[FunctionTool] = _function_tool_module.get_impl()

                        # TODO / FIXME: This is nasty to identify MCP, which requires to be called awaited to collect tools -> Again Asyncio issues with waitress
                        if _function_tool_module.get_spec().get_id() == "14849239-92eb-4962-ad69-6d0cf0698aec":
                            # THIS IS MCP
                            _function_tools: List[FunctionTool] = await _function_tool_module.get_impl()
                        else:
                            _function_tools: List[FunctionTool] = _function_tool_module.get_impl()

                        # FIXME: An inconsistency in llamaindex blocks us from linking the function tool to the function tool inside an agent.
                        #  The only option we have is to use the function tool id as tool name.
                        for i, _function_tool in enumerate(_function_tools):
                            # _function_tool.metadata.name = _function_tool_module.get_id() + f"---{i}"
                            _tools.append(_function_tool)

                logging.log(logging.INFO, f"*** \t\t\tFetch hand off relations...")
                # Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
                # TODO: Remove when openai supports longer tool descriptions
                _handoff_available_agents = """
# Handoff instructions
 
The following agents are available for handoff actions:
"""
                if _agent.id in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.AGENT.value]:
                    _handoff_entities = [item[0] for item in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.AGENT.value][
                        _agent.id]]
                    if not _handoff_entities:
                        _handoff_available_agents += "\n\t No agents available for handoff.\n"
                    else:
                        for item in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.AGENT.value][_agent.id]:
                            _handoff_available_agents += f"\n\t{item[0]} \n\tDescription: {item[1].description}\n"
                else:
                    _handoff_entities = None
                    _handoff_available_agents += ""

                logging.log(logging.INFO, f"*** \t\t\tCreating agent...")
                functional_agents_by_id[_agent.id] = self.create_workflow_agent(name=self.__normalize_agent_name(to_lower(AgentWorkflowAgentType.AGENT.value) + "#"
                                                                        + _agent.name + "#"
                                                                        + _agent.id),
                                                                   agent_description=_agent.description,
                                                                   system_prompt=_agent_system_prompt + _handoff_available_agents,
                                                                   llm=_agent_llm,
                                                                   can_handoff_to=_handoff_entities,
                                                                   tools=_tools)

        logging.log(logging.INFO, f"***")
       

        # ASSISTANTS
        logging.log(logging.INFO, f"*** \tAssistants")
        if len(__agent_workflow.assistant_relations) == 0:
            logging.log(logging.INFO, f"*** \tNo assistants found ")
        else:
            for _assistant_relation in __agent_workflow.assistant_relations:
                _assistant: AssistantModel = AssistantModel.query.get(_assistant_relation.assistant_id)
                logging.log(logging.INFO, f"*** \t\t{_assistant.name}")
                _assistant_llm: AbstractLLM = cast(AbstractLLM, ModuleRegistry.get_module(_assistant.llms[0].module_id))

                logging.log(logging.INFO, f"*** \t\t\tMerging System Prompts...")
                _assistant_system_prompt = ""
                for _sys_instruct_relation in _assistant.system_instructions:
                    _sys_instruct = SystemInstructionModel.query.get(_sys_instruct_relation.system_instruction_id)
                    _assistant_system_prompt += _sys_instruct.message + "\n"
                if _assistant.custom_system_instruction:
                    _assistant_system_prompt += _assistant.custom_system_instruction + "\n"

                logging.log(logging.INFO, f"*** \t\t\tConfiguring Tools...")
                _tools = default_tools.copy()
                if len(_assistant.data_sources) > 0:
                    for _data_source_rel in _assistant.data_sources:
                        # Check if data source is soft deleted using a single query
                        _data_source = DataSourceModel.query.filter(
                            DataSourceModel.id == _data_source_rel.data_source_id,
                            DataSourceModel.deleted_at.is_(None)
                        ).first()
                        if _data_source is None:
                            continue
                        _index = self.__get_index_from_data_source(_data_source)
                        if _index:
                            _tool = create_retriever_tool(_index, similarity_top_k=_similarity_top_k, filters=MetadataFilters(
                                filters=[MetadataFilter(
                                    key="maxgpt-filter-tag",
                                    value=_data_source.filter_tag
                                )]) if _data_source.filter_tag else None, tool_name="retrieve_context_"+_data_source.id)
                            _tools.append(_tool)

                logging.log(logging.INFO, f"*** \t\t\tFetch hand off relations...")
                # Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
                # TODO: Remove when openai supports longer tool descriptions
                _handoff_available_agents = """
# Handoff instructions

The following agents are available for handoff actions:
"""
                if _assistant.id in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.ASSISTANT.value]:
                    _handoff_entities = [item[0] for item in
                                         _workflow_handoff_relation_lookup[AgentWorkflowAgentType.ASSISTANT.value][
                                             _assistant.id]]
                    for item in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.ASSISTANT.value][_assistant.id]:
                        _handoff_available_agents += f"\n\t{item[0]} \n\tDescription: {item[1].description}\n"
                else:
                    _handoff_entities = None
                    _handoff_available_agents += ""


                logging.log(logging.INFO, f"*** \t\t\tCreating agent...")
                functional_agents_by_id[_assistant.id] = self.create_workflow_agent(name=self.__normalize_agent_name(to_lower(AgentWorkflowAgentType.ASSISTANT.value) + "#"
                                                                        + _assistant.name + "#"
                                                                        + _assistant.id),
                                                                       agent_description=_assistant.description,
                                                                       system_prompt=_assistant_system_prompt + _handoff_available_agents,
                                                                       llm=_assistant_llm,
                                                                       can_handoff_to=_handoff_entities,
                                                                       tools=_tools)

        logging.log(logging.INFO, f"***")

        # DATA SOURCES
        # Creating a retriever agent for each data_source in this network.
        logging.log(logging.INFO, f"*** \tData Sources")
        if len(self.__conversation.agent_workflow.data_source_relations) > 0:
            for _data_source_relation in self.__conversation.agent_workflow.data_source_relations:
                _agent_workflow_ds: DataSourceModel = DataSourceModel.query.get(_data_source_relation.data_source_id)
                _index = self.__get_index_from_data_source(_agent_workflow_ds)
                logging.log(logging.INFO, f"*** \t\t{_agent_workflow_ds.name}")

                logging.log(logging.INFO, f"*** \t\t\tConfiguring Tools...")
                _tool = create_retriever_tool(_index, similarity_top_k=_similarity_top_k,
                                              filters=MetadataFilters(
                                                  filters=[MetadataFilter(
                                                      key="maxgpt-filter-tag",
                                                      value=_agent_workflow_ds.filter_tag
                                                  )]) if _agent_workflow_ds.filter_tag else None,
                                              tool_name="retrieve_context_" + _agent_workflow_ds.id)

                logging.log(logging.INFO, f"*** \t\t\tFetch hand off relations...")
                # Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
                # TODO: Remove when openai supports longer tool descriptions
                _handoff_available_agents = """
# Handoff instructions

The following agents are available for handoff actions:
"""
                if _agent_workflow_ds.id in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.DATA_SOURCE.value]:
                    _handoff_entities = [item[0] for item in
                                         _workflow_handoff_relation_lookup[AgentWorkflowAgentType.DATA_SOURCE.value][
                                             _agent_workflow_ds.id]]
                    for item in _workflow_handoff_relation_lookup[AgentWorkflowAgentType.DATA_SOURCE.value][_agent_workflow_ds.id]:
                        _handoff_available_agents += f"\n\t{item[0]} \n\tDescription: {item[1].description}\n"
                else:
                    _handoff_entities = None
                    _handoff_available_agents += ""

                logging.log(logging.INFO, f"*** \t\t\tCreating agent with conversation llm '{_conversation_llm_module.get_name()}'...")
                _tools = default_tools.copy()
                _tools.append(_tool)
                functional_agents_by_id[_agent_workflow_ds.id] = self.create_workflow_agent(name=self.__normalize_agent_name(to_lower(AgentWorkflowAgentType.DATA_SOURCE.value) + "#"
                                                                        + _agent_workflow_ds.name + "#"
                                                                        + _agent_workflow_ds.id),
                                                                agent_description=(
                                                                            "Retriever agent to retrieve data from a vector store '" + _agent_workflow_ds.name) if not _agent_workflow_ds.description else (
                                                                                _agent_workflow_ds.description if len(_agent_workflow_ds.description) <= 1020 else (_agent_workflow_ds.description[:1020] + "...")),
                                                                llm=_conversation_llm_module,
                                                                system_prompt=f"""
You are a retriever agent. 
Your only task is to fetch relevant context using the tool {_tool.metadata.name}. 

Constraints: 
- ALWAYS use the tool you are equipped with before replying
- Do not respond to the user directly.
- NEVER stop or interrupt the workflow
- ALWAYS continue to the next agent using the following options.
                                                                    """ + _handoff_available_agents,
                                                                can_handoff_to=_handoff_entities,
                                                                tools=_tools)
        else:
            logging.log(logging.INFO, f"*** \tNo data source nodes found ")
        logging.log(logging.INFO, f"***")
       

        logging.log(logging.INFO, f"*** \tConversation Specific Data Source")
        if len(self.__conversation.data_sources) > 0:
            logging.log(logging.INFO, f"*** \t\tFound {len(self.__conversation.data_sources)} conversation data sources...")
            for _data_source_rel in self.__conversation.data_sources:
                # Check if data source is soft deleted using a single query
                _data_source = DataSourceModel.query.filter(
                    DataSourceModel.id == _data_source_rel.data_source_id,
                    DataSourceModel.deleted_at.is_(None)
                ).first()
                if _data_source is None:
                    continue
                _index = self.__get_index_from_data_source(_data_source)
                if _index:
                    logging.info(f"*** \t\tCreating retriever tool around conversation DS '{_data_source.name}'...")
                    _tool = create_retriever_tool(_index, similarity_top_k=_similarity_top_k, filters=MetadataFilters(
                        filters=[MetadataFilter(
                            key="maxgpt-filter-tag",
                            value=_data_source.filter_tag
                        )]) if _data_source.filter_tag else None, tool_name="retrieve_context_" + _data_source.id)

                    for _network_agent in functional_agents_by_id.values():
                        logging.info(
                            f"*** \t\tAdding conversation DS retriever tool to {_network_agent.name}")
                        _network_agent.tools.append(_tool)
        else:
            logging.log(logging.INFO,
                        f"*** \t\tNo conversation specific data source found ")

        logging.log(logging.INFO, f"***")
        logging.log(logging.INFO, f"*** Agent creation complete ***")

        # MULTI_MODAL: images needs to be appended to the chat history
        logging.log(logging.INFO, f"*** Add image blocks to the top of the chat history if provided. ***")

        image_blocks: List[ImageBlock] = []
        for part in self.__user_message.parts:
            if part.type == MessagePartType.IMAGE:
                image_blocks.append(
                    ImageBlock(
                        url=part.content
                    ))
            elif part.type == MessagePartType.ATTACHMENT_REFERENCE:
                # fetch attachment meta from db
                _attachment: AttachmentModel = AttachmentModel.query.get_or_404(part.content)
                if _attachment.id not in [ca.attachment_id for ca in self.__conversation.attachments]:
                    raise Exception(
                        f"Corrupted data. Attachment with identifier '{_attachment.id}' belongs to another conversation")
                if _attachment.type == DocumentType.IMAGE:
                    # get image from file storage
                    file_object = get_file_from_file_storage(_attachment)
                    image_blocks.append(
                        ImageBlock(
                            url="data:image/jpeg;base64," + convert_to_base64(file_object)
                        ))
                elif _attachment.type == DocumentType.TEXT:
                    file_object = get_file_from_file_storage(_attachment)
                    # Try processing supported structured data files
                    append_dataframe_from_part(convert_to_base64(file_object), self.__pandas_dataframes, _attachment.mime_type)
            elif part.type == MessagePartType.DOCUMENT:
                append_dataframe_from_part(part.content, self.__pandas_dataframes)

        if len(image_blocks) > 0:
            logging.log(logging.INFO, f"*** Added {len(image_blocks)} image blocks ***")
            chat_history = chat_history + [ChatMessage(
                role=LlamaIndexMessageRole.USER,
                blocks=image_blocks)]

        # go with pandasai processing if we have dataframes using the conversation llm
        if len(self.__pandas_dataframes) > 0:
            _pandasai_llm = _conversation_llm_module.get_pandasai_impl()
            if _pandasai_llm is None:
                raise Exception(
                    f"Structured data was attached but no pandasai implementation was found for the selected llm"
                )
            agent = pai.agent.Agent(self.__pandas_dataframes, config=Config(llm=_pandasai_llm))
            for msg in chat_history:
                agent.add_message(msg.content, msg.role == MessageRole.USER)
            agent.add_message("\n IMPORTANT INSTRUCTION: Column names and values can contain trailing spaces.",
                              is_user=False)
            pandas_response = agent.chat(_user_message, output_type="string")
            logging.log(logging.DEBUG, f"*** ChatProcess: Pandasai response: {pandas_response}:")

            if not isinstance(pandas_response, str):
                pandas_response = str(pandas_response)

            logging.log(logging.DEBUG, f"*** ChatProcess: Pandasai response: {pandas_response}:")

            # Create a generator that yields the pandas_response
            # def pandas_response_gen():
            #     yield pandas_response

            # We append the on-the-fly generated context information to the chat history and the let the workflow
            # process normally.
            chat_history = chat_history + [ChatMessage(
                content=pandas_response,
                role=LlamaIndexMessageRole.SYSTEM
            )]
            _user_message += (
                "\n CRITICAL INSTRUCTION: The answer for this prompt is already given by the assistant in the last message. "
                "Present the answer as if it was given by you and integrate it seamlessly into the conversation.")
            # return ChatResponse(pandas_response_gen(), []) #TODO: Use this if the append to the history does not work out

        # Put it all together and run the llama_index wrappers
        logging.log(logging.INFO, f"*** Identify root agent ***")
        _root_agent_name = functional_agents_by_id[__agent_workflow.first_receiver_id].name
        __process = MessageProcessModel(message=self.__user_message)
        database.session.add(__process)
        database.session.commit()

        # Fix a strange behavior in the llamaindex workflow that avoid taking the root_agent from the param in case of only 1 agent in the list.
        # It then takes agents[0] which does not work if we use dict_values as input
        _function_agents: List[BaseWorkflowAgent] = []
        for key in functional_agents_by_id:
            _function_agents.append(functional_agents_by_id[key])

        # This is the place where we know about all agents, so we can fix the handoff instructions for those agents that are able to handoff
        # to all other agents.
        # Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
        # TODO: Remove when openai supports longer tool descriptions
        for key in functional_agents_by_id:
            _agent : BaseWorkflowAgent = functional_agents_by_id[key]
            if _agent.can_handoff_to is None:
                for _target_agent_key in functional_agents_by_id:
                    _target_agent: BaseWorkflowAgent = functional_agents_by_id[_target_agent_key]
                    if _target_agent.name != _agent.name:
                        _agent.system_prompt += f"\n\t{_target_agent.name} \n\tDescription: {_target_agent.description}\n"

        logging.log(logging.INFO, f"*** Create the agent workflow ***")
        # Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
        # TODO: Remove when openai supports longer tool descriptions
        workflow = EnhancedAgentWorkflow(
            initial_state={},
            agents=_function_agents,
            root_agent=_root_agent_name,
            handoff_prompt=PromptTemplate("Useful for handing off to another agent."
                           "If you are currently not equipped to handle the user's request, or another agent is better suited to handle the request, please hand off to the appropriate agent."
                           "Available agents have been provided in detail in the system prompt."),
            handoff_output_prompt=(
                "handoff_result: Due to {reason}, the user's request has been passed to {to_agent}."
                "Please review the conversation history immediately and continue responding to the user's request."
            ),
            verbose=(True if logging.getLogger().isEnabledFor(logging.DEBUG) else False)
        )

        user_message_content_blocks: List[ContentBlock] = [TextBlock(text=_user_message)]
        chat_history.append(ChatMessage(role=LlamaIndexMessageRole('user'), blocks=user_message_content_blocks))

        #DEBUG LOGS
        logging.log(logging.INFO, f"*** ")
        logging.log(logging.INFO, f"*** ")

        logging.debug("Agent Workflow Summary:")
        logging.debug("-" * 40)  # Separator

        logging.debug("Workflow Overview:")
        logging.debug("  This is your workflow definition.")
        logging.debug("-" * 40)

        for agent in _function_agents:
            logging.debug(f"  Agent: {agent.name}")
            logging.debug(f"    Is Root Agent: {'Yes' if _root_agent_name == agent.name else 'No'}")
            logging.debug(f"    Description: {agent.description.strip()}")  # Strip leading/trailing whitespace
            # logging.debug(f"    SystemInstruction: {agent.system_prompt.strip()}") # DO NOT USE IT ON PRODUCTION AS IT MAKE YOUR LOG GO BOOM BOOM
            logging.debug("    Can handoff to:")

            if agent.can_handoff_to is None:
                logging.debug("      All agents")
            elif agent.can_handoff_to:
                for handoff_agent_name in agent.can_handoff_to:
                    logging.debug(f"      - {handoff_agent_name}")
            else:
                logging.debug("      No one")

            logging.debug("    Tools:")
            if agent.tools:
                for tool in agent.tools:
                    description_lines = [line.strip() for line in tool.metadata.description.strip().split("\n") if
                                         line.strip()]
                    description = ', '.join(description_lines)
                    logging.debug(f"      - {tool.metadata.name}, {description}")
            else:
                logging.debug("      None")
            logging.debug("-" * 20)  # Agent Separator
        logging.debug("-" * 40)  # workflow summary seperator

        # get list of events from stream
        # NOTE: this is ESSENTIAL otherwise it will fail as the async-generator is NOT iterable
        logging.log(logging.INFO, f"*** RUN the workflow ***")
        response = workflow.run(chat_history=chat_history)
        return response.stream_events()


def fetch_module(module_id):
    return cast(AbstractModule, ModuleRegistry.get_module(module_id))
