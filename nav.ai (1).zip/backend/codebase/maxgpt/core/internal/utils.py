from typing import cast

from maxgpt.modules import ModuleRegistry
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
from maxgpt.services.database_model import AttachmentModel


def get_file_from_file_storage(attachment: AttachmentModel):
    _file_storage = cast(AbstractFileStorage,
                         ModuleRegistry.get_module(attachment.file_storage_id))
    if _file_storage is None:
        raise Exception(
            f"Corrupted data. File storage with identifier '{attachment.file_storage_id}' not found.")
    file_object = _file_storage.read(attachment.object_reference)
    return file_object