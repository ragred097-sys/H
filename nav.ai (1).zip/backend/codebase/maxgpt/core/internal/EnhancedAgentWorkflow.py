from typing import Optional, override

from llama_index.core.agent.workflow import AgentWorkflow, BaseWorkflowAgent, ReActAgent
from llama_index.core.agent.workflow.multi_agent_workflow import handoff
from llama_index.core.tools import AsyncBaseTool, FunctionTool
from typing import override, Sequence, List

from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.core.workflow import Context
from llama_index.core.memory import BaseMemory
from llama_index.core.tools import AsyncBaseTool
from llama_index.core.agent.workflow.workflow_events import (
    AgentOutput,
)

class ReorderedReActAgent(ReActAgent):
    """
    Kudos to https://www.dataleadsfuture.com/fixing-the-agent-handoff-problem-in-llamaindexs-agentworkflow-system/

    An enhanced version of a FunctionAgent that optimizes handoff invocations
    """

    @override
    async def take_step(
            self,
            ctx: Context,
            llm_input: List[ChatMessage],
            tools: Sequence[AsyncBaseTool],
            memory: BaseMemory,
    ) -> AgentOutput:
        last_msg = llm_input[-1] and llm_input[-1].content
        await ctx.get("state", None)

        if "handoff_result" in last_msg:
            for message in llm_input[::-1]:
                if message.role == MessageRole.USER:
                    last_user_msg = message
                    llm_input.append(last_user_msg)
                    break

        return await super().take_step(ctx, llm_input, tools, memory)


class ReorderedFunctionAgent(FunctionAgent):
    """
    Kudos to https://www.dataleadsfuture.com/fixing-the-agent-handoff-problem-in-llamaindexs-agentworkflow-system/

    An enhanced version of a FunctionAgent that optimizes handoff invocations
    """

    @override
    async def take_step(
            self,
            ctx: Context,
            llm_input: List[ChatMessage],
            tools: Sequence[AsyncBaseTool],
            memory: BaseMemory,
    ) -> AgentOutput:
        last_msg = llm_input[-1] and llm_input[-1].content
        await ctx.get("state", None)

        if "handoff_result" in last_msg:
            for message in llm_input[::-1]:
                if message.role == MessageRole.USER:
                    last_user_msg = message
                    llm_input.append(last_user_msg)
                    break

        return await super().take_step(ctx, llm_input, tools, memory)


class EnhancedAgentWorkflow(AgentWorkflow):
    """
    Kudos to https://www.dataleadsfuture.com/fixing-the-agent-handoff-problem-in-llamaindexs-agentworkflow-system/
    Workaround following this thread: https://github.com/run-llama/llama_index/issues/18530#issuecomment-2831452401
    TODO: Rework when openai supports longer tool descriptions

    An enhanced version of the agent workflow that optimizes handoff invocations that is using a fix length handoff prompt to avoid
    getting too long tool description ValueErrors.

    Requires you to set a proper handoff prompt with reference to the system instruction where the actual agent descriptions are located.
    """

    def _get_handoff_tool(
        self, current_agent: BaseWorkflowAgent
    ) -> Optional[AsyncBaseTool]:
        """Creates a handoff tool for the given agent."""
        agent_info = {cfg.name: cfg.description for cfg in self.agents.values()}
        configs_to_remove = []
        for name in agent_info:
            if name == current_agent.name:
                configs_to_remove.append(name)
            elif (
                current_agent.can_handoff_to is not None
                and name not in current_agent.can_handoff_to
            ):
                configs_to_remove.append(name)

        for name in configs_to_remove:
            agent_info.pop(name)

        if not agent_info:
            return None

        handoff_prompt = self.handoff_prompt
        fn_tool_prompt = handoff_prompt.format()
        return FunctionTool.from_defaults(
            async_fn=handoff, description=fn_tool_prompt, return_direct=True
        )