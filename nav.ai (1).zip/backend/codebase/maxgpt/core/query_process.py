import abc
import logging
from typing import Optional, cast, List, Generator

from llama_index.core.base.base_query_engine import BaseQueryEngine
from llama_index.core.indices import EmptyIndex
from llama_index.core.indices.base import BaseIndex
from llama_index.core.vector_stores import MetadataFilters, MetadataFilter, FilterOperator

from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleRegistry
from maxgpt.services.database_model import MessagePartType, \
    DataSourceModel, MessagePartModel


class QueryProcess(abc.ABC):
    """
        This process can be used to query raw text directly to the provided llm.
        Optionally, you can provide a data source that should be considered to answer your query.
        The response is streamed in the same way as for ChatProcess but no data will be persisted in the
        application persistence.

        Use-cases are:

            - Admin tasks like summarizing things to get a condensed summary
            - ...

        Possible overrides:

            override_embedding_similarity_top_k = int (default 6)
            override_llm_response_mode = str (default 'tree_summarize'), see https://docs.llamaindex.ai/en/stable/module_guides/deploying/query_engine/response_modes/

    """

    def __init__(self, user_message_parts: dict, llm_id: str, data_source: Optional[DataSourceModel], overrides: List[dict]):
        self.__data_source: Optional[DataSourceModel] = data_source
        self.__llm_id: str = llm_id

        self.__overrides: dict = {}
        for override in overrides:
            self.__overrides[override['name']] = override['value']

        # Parse and process the message parts of the new user message
        self.__message_parts: [MessagePartModel] = []
        for i, part in enumerate(user_message_parts):
            self.__message_parts.append(MessagePartModel(type=MessagePartType[part['type']], sequence=i, content=part['content'], message=None))


    def execute(self) -> Generator[str, None, None]:
        logging.log(logging.INFO, f"*** Starting QueryProcess ***")

        _query_engine: BaseQueryEngine

        # 1. FETCH LLM
        _llm_module = fetch_module(self.__llm_id)
        
        _llm = _llm_module.get_impl()

        # 2. FETCH EMBEDDING MODEL & VECTOR STORE INDEX
        _similarity_top_k = self.__overrides[
            'override_embedding_similarity_top_k'] if 'override_embedding_similarity_top_k' in self.__overrides else 5
        _response_mode = self.__overrides[
            'override_llm_response_mode'] if 'override_llm_response_mode' in self.__overrides else "tree_summarize"
        _similarity_top_p = self.__overrides[
            'override_embedding_similarity_top_p'] if 'override_embedding_similarity_top_p' in self.__overrides else 0.9

        # Not supported by all models
        additional_kwargs = {
            "top_p": _similarity_top_p,
            "top_k": _similarity_top_k
        }
        _embed_model: Optional[AbstractModule] = None
        _index: Optional[BaseIndex] = None

        if self.__data_source:
            _embed_model = fetch_module(self.__data_source.embedding_model_id).get_impl()
            _index = cast(AbstractVectorStore, fetch_module(self.__data_source.vector_store_id)).get_impl(_embed_model)
        else:
            _response_mode = 'generation'
            _index = EmptyIndex()

        # 3. Define Meta Data filtering
        _meta_data_filters: List[MetadataFilter] = []
        _filter_values = []

        # Add the filter tag of the data source provided to this
        if self.__data_source and self.__data_source.filter_tag is not None:
            _filter_values.append(self.__data_source.filter_tag)  # Adding a conversation specific filter tag

        if len(_filter_values) > 0:
            _meta_data_filters.append(MetadataFilter(
                key="maxgpt-filter-tag",
                value=_filter_values,  # List of source_id values to filter by
                operator=FilterOperator.ANY
            ))

        # 4. Initialize Query Engine
        logging.log(logging.INFO, f"*** QueryProcess: Using response mode = {_response_mode}")
        logging.log(logging.INFO, f"*** QueryProcess: Using similarity top k = {_similarity_top_k}")
        logging.log(logging.INFO, f"*** QueryProcess: Using additional kwargs = {additional_kwargs}")

        _query_engine = _index.as_query_engine(streaming=True,
                                               response_mode=_response_mode,
                                               llm=_llm,
                                               filters=MetadataFilters(filters=_meta_data_filters),
                                               similarity_top_k=_similarity_top_k,
                                               kwargs=additional_kwargs)

        # To handles multiple different parts and types of the user input (text blocks, images, videos, attachment references, ...)
        #  we are asking the llm to create a final query out of it
        _final_query = cast(AbstractLLM, _llm_module).prompt_gen(self.__message_parts)
        query_response = _query_engine.query(_final_query)

        return query_response.response_gen


def fetch_module(module_id):
    return cast(AbstractModule, ModuleRegistry.get_module(module_id))
