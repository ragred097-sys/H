import abc
import base64
import enum
import hashlib
import json
import logging
import os
import tempfile
import time
import uuid
from abc import abstractmethod
from datetime import datetime
from json import JSONEncoder
from pathlib import Path
from typing import Optional, cast, Union, Type, List, Iterable, Sequence, Generator, Tuple

import nest_asyncio
from flask import stream_with_context
from llama_index.core import SimpleDirectoryReader, Document
from llama_index.core.constants import DEFAULT_CHUNK_SIZE
from llama_index.core.data_structs import IndexDict
from llama_index.core.extractors import TitleExtractor, SummaryExtractor, KeywordExtractor, QuestionsAnsweredExtractor
from llama_index.core.indices import EmptyIndex
from llama_index.core.indices.base import BaseIndex
from llama_index.core.ingestion import IngestionPipeline
from llama_index.core.llms import LLM
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.schema import BaseNode 
from llama_index.readers.web import SimpleWebPageReader
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.embedding_models.embedding_modules import AbstractEmbeddingModel
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleRegistry
from maxgpt.modules.readers.file import SingleSlidePptxReader
from maxgpt.services import database
from maxgpt.services.database_model import DataObjectModel, IngestProcessModel, DataSourceModel, FileStorageFileSystem
import base64
from llama_index.core.base.llms.types import ImageBlock, TextBlock
from maxgpt.api.internal.utils import convert_to_base64
from llama_index.core.llms import (
    ChatMessage,
    ImageBlock,
    TextBlock,
    MessageRole,
)


class JsonEncoderWithDates(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, enum.Enum):
            return obj.value
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

class ProcessStatus(abc.ABC):

    def __init__(self, steps: int):
        self._steps = steps
        self._current_step = 0
        self._current_step_name = "Process Started"
        self._progress = 0.0
        self._data_objects = []

    def update(self,
               current_step: Optional[int] = None,
               current_step_name: Optional[str] = None,
               progress: Optional[float] = None,
               data_objects: [DataObjectModel] =None):
        self._current_step = current_step if current_step else self._current_step
        self._current_step_name = current_step_name if current_step_name else self._current_step_name
        self._progress = progress if progress else self._progress
        self._data_objects = data_objects if data_objects else self._data_objects
        return self

    def to_string(self) -> str:
        return json.dumps(self._to_json(), cls=JsonEncoderWithDates)

    def _to_json(self):
        return {
            "steps": self._steps,
            "currentStep": self._current_step,
            "currentStepName": self._current_step_name,
            "progress": self._progress,
            "dataObjects": [do.to_dict() for do in self._data_objects]
        }

def _fetch_vector_store_index(embed_model, vector_store_id) -> Union[EmptyIndex, BaseIndex[IndexDict]]:
    from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore

    # Check for vector store selection or take default. Consider availability of embed_model too because it is
    #  required to instantiate a VectorStoreIndex
    selected_vector_store: Optional[AbstractVectorStore] = ModuleRegistry.get_module(vector_store_id)
    if selected_vector_store is not None and embed_model is None:
        raise ValueError(
            f"If you specify a VectorStore in your request, there must be a valid Embedding Model selected too.")
    elif selected_vector_store is not None:
        vector_store_index = selected_vector_store.get_impl(embed_model=embed_model)
    else:
        vector_store_index = EmptyIndex()
    return vector_store_index


def _fetch_module(module_id):
    return cast(AbstractModule, ModuleRegistry.get_module(module_id))


def _print_nodes(nodes):
    # TODO: Make this dynamic by transformer implementation
    #  Just for dev debugging at the moment
    filename = ""
    section_counter = 0
    for node in nodes:
        n_file_name = node.metadata["file_name"]
        n_q_a = node.metadata[
            "questions_this_excerpt_can_answer"] if "questions_this_excerpt_can_answer" in node.metadata else "<Not Available>"
        n_summary = node.metadata["section_summary"] if "section_summary" in node.metadata else "<Not Available>"

        if filename != n_file_name:
            print("#######################")
            print(n_file_name)
            print("#######################")
            print("")
            section_counter = 1
            filename = n_file_name
        print(f"###### Section {section_counter}")
        print("")
        print(f"Section Summary:")
        print(f"{n_summary}")
        print("")
        print(f"Questions:")
        print(f"{n_q_a}")
        print("")
        print("")
        section_counter = section_counter + 1

def _get_splitters(overrides: dict):
    logging.log(logging.DEBUG, f"***    Add splitters")
    _splitters = []

    # SentenceSplitter
    _chunk_size = int(overrides['sentence_splitter_chunk_size']) if 'sentence_splitter_chunk_size' in overrides else DEFAULT_CHUNK_SIZE
    _chunk_overlap = int(overrides['sentence_splitter_chunk_overlap']) if 'sentence_splitter_chunk_overlap' in overrides else 2
    _splitters.append(SentenceSplitter(chunk_size=_chunk_size, chunk_overlap=_chunk_overlap))

    return _splitters

def _get_metadata_extractors(overrides: dict, llm: Type[LLM]):
    logging.log(logging.DEBUG, f"***    Add extractors")

    _extractors = []

    # Summary Extractor
    if 'summary_extractor_enabled' not in overrides or bool(overrides['summary_extractor_enabled']):
        _summary_extractor_summaries = overrides['summary_extractor_summaries'] if 'summary_extractor_summaries' in overrides else ["prev", "self"]
        _extractors.append(SummaryExtractor(summaries=_summary_extractor_summaries, llm=llm))

    # Title Extractor
    if 'title_extractor_enabled' in overrides and bool(overrides['title_extractor_enabled']):
        _title_extractor_nodes = overrides['title_extractor_nodes'] if 'title_extractor_nodes' in overrides else 5
        _extractors.append(TitleExtractor(nodes=_title_extractor_nodes, llm=llm))

    # Keywords Extractor
    if 'keywords_extractor_enabled' in overrides and bool(overrides['keywords_extractor_enabled']):
        _keywords_extractor_amount = overrides['keywords_extractor_amount'] if 'keywords_extractor_amount' in overrides else 5
        _extractors.append(KeywordExtractor(keywords=_keywords_extractor_amount, llm=llm))

    # QA Extractor
    if 'qa_extractor_enabled' in overrides and bool(overrides['qa_extractor_enabled']):
        _qa_extractor_questions = overrides['qa_extractor_questions'] if 'qa_extractor_questions' in overrides else 3
        _extractors.append(QuestionsAnsweredExtractor(questions=_qa_extractor_questions, llm=llm))

    return _extractors


class AbstractIngestProcess(abc.ABC):
    def __init__(self, process, data_source: DataSourceModel, llm: AbstractLLM, overrides: List[dict]):
        self._process: IngestProcessModel = process

        self._overrides: dict = {}
        for override in overrides:
            self._overrides[override['name']] = override['value']

        self._data_source: DataSourceModel = data_source
        self._llm: Type[LLM] = llm.get_impl() 

        self._embed_model: AbstractEmbeddingModel = cast(AbstractEmbeddingModel, _fetch_module(self._data_source.embedding_model_id))
        self._vector_store: AbstractVectorStore = cast(AbstractVectorStore, _fetch_module(self._data_source.vector_store_id))
        self._index:  Union[BaseIndex[IndexDict], EmptyIndex] = _fetch_vector_store_index(self._embed_model.get_impl(), self._data_source.vector_store_id)
        self._file_storage: Optional[AbstractFileStorage] = None
        if self._data_source.file_storage_id:
            self._file_storage = cast(AbstractFileStorage, _fetch_module(self._data_source.file_storage_id))

        database.session.add(self._process)
        database.session.commit()

        database.session.expunge(self._data_source)
        database.session.expunge(self._process)

    @stream_with_context
    def execute(self) -> Iterable:
        nest_asyncio.apply()

        database.session.add(self._data_source)
        database.session.add(self._process)

        p_status = ProcessStatus(steps=5)

        logging.log(logging.INFO, f"*** Starting ingestion process - {self._process.id} ***")
        overall_start_time = time.time()

        # 1. Extract llama-index documents from the provided data (file, webpage, raw text, ...)
        logging.log(logging.INFO, f"*** Process provided data and create documents") 
        try:
            yield p_status.update(current_step=1, current_step_name="Retrieve data", progress=1.0).to_string() + "\n"

            (new_data_object, documents) = yield from self.process_retrieve_data(p_status)

            # 2. Always add base meta data specific for our application
            for document in documents:
                document.metadata["file_name"] = new_data_object.file_name
                document.metadata["maxgpt-data_object-id"] = new_data_object.id
                document.metadata["maxgpt-data_object-file_system"] = new_data_object.file_system.name
                document.metadata["maxgpt-data_object-mime_type"] = new_data_object.mime_type

            yield p_status.update(progress=100.0, data_objects=[new_data_object]).to_string() + "\n"

            # 3. Tokenize documents and create llama-index nodes
            logging.log(logging.INFO, f"*** Split and create nodes for file content.")
            yield p_status.update(current_step=2, current_step_name="Tokenizing", progress=1.0).to_string() + "\n"
            nodes = self.split_documents_into_nodes(documents, p_status)
            logging.log(logging.INFO, f"*** ... {len(nodes)} nodes generated.")
            yield p_status.update(progress=100.0).to_string() + "\n"

            # 4. Extract additional meta data for all nodes depending on selected extractors and enrich nodes with the details
            logging.log(logging.INFO, f"*** Extract MetaData")
            yield p_status.update(current_step=3, current_step_name="Meta Data Extraction", progress=1.0).to_string() + "\n"
            nodes = self.extract_meta_data(nodes, p_status)
            yield p_status.update(progress=100.0).to_string() + "\n"

            # 5. Create embeddings aka Vectorization
            logging.log(logging.INFO, f"*** Generate embeddings for {len(nodes)} nodes.")
            yield p_status.update(current_step=4, current_step_name="Vectorization", progress=1.0).to_string() + "\n"
            embedding_nodes: [BaseNode] = []
            counter = 0
            for node in nodes:
                counter += 1
                embedding_nodes.append(self.create_text_embedding(node))
                yield p_status.update(progress=round(counter / len(nodes) * 100, 2)).to_string() + "\n"

            # 6. Store embeddings into the selected vector store
            logging.log(logging.INFO, f"*** Load {len(embedding_nodes)} nodes into Vector Store and persist")
            yield p_status.update(current_step=5, current_step_name="Finalizing", progress=1.0).to_string() + "\n"
            self._index.insert_nodes(embedding_nodes)
            self._vector_store.persist()
            elapsed_time = time.time() - overall_start_time
            logging.log(logging.INFO, f"*** Ingestion complete. Elapsed time: {elapsed_time} seconds")
            yield p_status.update(progress=100.0).to_string() + "\n"
            
            # Debug information
            if logging.getLogger().getEffectiveLevel() == logging.DEBUG:
                _print_nodes(embedding_nodes)
                
        except Exception as e:
            logging.error(f"Error during ingestion process: {str(e)}")
            # Create a final error status that indicates failure
            error_status = p_status.update(
                current_step_name=f"Error: {str(e)}",
                progress=0.0
            ).to_string() + "\n" 
            yield error_status 

    @abstractmethod
    def process_retrieve_data(self, p_status: ProcessStatus) -> Generator[str, None, Tuple[DataObjectModel, List[Document]]]:
        pass

    def split_documents_into_nodes(self, documents: list[Document], p_status: ProcessStatus) -> Sequence[BaseNode]:
        split_transformers = []
        split_transformers = split_transformers + _get_splitters(self._overrides)
        pipeline = IngestionPipeline(
            transformations=split_transformers,
        )
        return pipeline.run(documents=documents, in_place=False)

    def extract_meta_data(self, nodes: Sequence[BaseNode], p_status: ProcessStatus) -> Sequence[BaseNode]:
        extract_transformers = []
        extract_transformers = extract_transformers + _get_metadata_extractors(self._overrides, self._llm)
        pipeline = IngestionPipeline(
            transformations=extract_transformers,
        )
        return pipeline.run(nodes=list(nodes), in_place=False)

    def create_text_embedding(self, node: BaseNode) -> BaseNode:
        if node.get_content():
            node_embedding = self._embed_model.get_impl().get_text_embedding(
                node.get_content()
            )
            node.embedding = node_embedding
            if self._data_source.filter_tag is not None:
                node.metadata['maxgpt-filter-tag'] = self._data_source.filter_tag
        else:
            logging.log(logging.INFO, f"*** Skipping node because it does not contain any text")
        return node



class FileIngestProcess(AbstractIngestProcess):
    """
        Process to handle file uploads:
        - Retrieve file
        - Parse and tokenize
        - Extract metadata
        - Generate embeddings
        - Persist
    """

    __file: FileStorage
    __file_length: int

    def __init__(self, file: FileStorage, file_length: int, data_source: DataSourceModel, llm: AbstractLLM, overrides: List[dict]):
        self.__file = file
        self.__file_length = file_length
        super().__init__(IngestProcessModel(data_source_id=data_source.id), data_source, llm, overrides)
        logging.log(logging.INFO,
                            f"***LLMID***.{llm}.")
    def process_retrieve_data(self, p_status: ProcessStatus) -> Generator[str, None, Tuple[DataObjectModel, List[Document]]]:
         
        file_extractor = {
            ".pptx": SingleSlidePptxReader()
        }   

        filename = secure_filename(self.__file.filename)
        relative_path = self._data_source.id + os.path.sep + filename

        # Here comes a fun part because we trace a progress while reading the buggered stream
        file_content = b''
        bytes_read = 0
        while True:
            chunk = self.__file.stream.read(4096)
            if not chunk:
                break
            bytes_read += len(chunk)
            file_content += chunk
            # Calculate the progress (ratio of data read)
            # We say some % smaller 100 here as the simple reader further below still need some time to create a document
            progress = bytes_read / self.__file_length * 72 
            yield p_status.update(progress=progress).to_string() + "\n"
        
        # Magic guessing :D
        # mime_type, _ = mimetypes.guess_type(filename)
        mime_type = self.__file.content_type
        if mime_type is None:
            mime_type = 'application/octet-stream'

        # Store original file in file storage if available and create data object in the db 
        if self._file_storage:
            logging.log(logging.DEBUG,
                        f"*** Storing received file to filestorage {self._file_storage.get_file_system().name}.")
            self._file_storage.write(filename=relative_path, binary_data=file_content)
            new_data_object = DataObjectModel(name=filename,
                                                file_name=filename,
                                                file_system=self._file_storage.get_file_system(),
                                                url=self._file_storage.get_url_for_filename(relative_path),
                                                ingest_process=self._process,
                                                mime_type=mime_type)
        else:
            logging.log(logging.DEBUG,
                        f"*** No file storage selected, so the received file will not be stored in the filesystem.")
            new_data_object = DataObjectModel(name=filename,
                                                file_name=filename,
                                                file_system=FileStorageFileSystem.NONE,
                                                ingest_process=self._process,
                                                mime_type=mime_type)

        database.session.add(new_data_object)
        database.session.commit()

        # Take it easy here: Use Llamaindex default Directory Reader to create documents by creating a temp file
        try:
            _, extension = os.path.splitext(filename)
            with tempfile.NamedTemporaryFile(suffix=extension, delete=False) as temp_file:
                temp_file.write(file_content)
                temp_file.flush()
                temp_filename = temp_file.name

            #documents = SimpleDirectoryReader.load_file(Path(new_data_object.url), file_extractor=file_extractor,
            documents = SimpleDirectoryReader.load_file(Path(temp_filename), file_extractor=file_extractor,
                                                        file_metadata = lambda x : {})

            return new_data_object, documents
        finally:
             # Ensure the temporary file is deleted
             if temp_filename is not None and os.path.exists(temp_filename):
                os.remove(temp_filename)
                logging.log(logging.DEBUG, f"Removed temp file {temp_filename}")


class TextIngestProcess(AbstractIngestProcess):
    """
        Process to handle raw text input:
        - Simply and statically create a singe Document with the provided text
    """

    __content: str


    def __init__(self, content: str,  data_source: DataSourceModel, llm: AbstractLLM, overrides: List[dict]):
        self.__content = content
        super().__init__(IngestProcessModel(data_source_id=data_source.id), data_source, llm, overrides)


    def process_retrieve_data(self, p_status: ProcessStatus) -> Generator[str, None, Tuple[DataObjectModel, List[Document]]]:
        filename = secure_filename(f"{uuid.uuid4()}.txt")
        relative_path = self._data_source.id + os.path.sep + filename

        if self._file_storage:
            logging.log(logging.DEBUG,
                        f"*** Storing received content to filestorage {self._file_storage.get_file_system().name}.")
            self._file_storage.write(filename=relative_path, binary_data=self.__content.encode())
            new_data_object = DataObjectModel(name=self.__content.lstrip()[0:100],
                                              file_name=filename,
                                              file_system=self._file_storage.get_file_system(),
                                              url=self._file_storage.get_url_for_filename(relative_path),
                                              ingest_process=self._process,
                                              mime_type="text/plain")
        else:
            logging.log(logging.DEBUG,
                        f"*** No file storage selected, so the received content will not be stored in the filesystem.")
            new_data_object = DataObjectModel(name=self.__content.lstrip()[0:100],
                                              file_name=filename,
                                              file_system=FileStorageFileSystem.NONE,
                                              ingest_process=self._process,
                                              mime_type="text/plain")

        database.session.add(new_data_object)
        database.session.commit()

        documents = [Document(
            text=self.__content
        )]

        # The following yield is required to satisfy the yield from signature of the caller
        # Something must be yielded when using it. Weired but hey... this is python, isn't it? :D
        yield p_status.update(progress=75.0).to_string() + "\n"

        return (new_data_object, documents)


class WebCrawlIngestProcess(AbstractIngestProcess):
    """
        Process to handle content of a referenced website:
        - Retrieve website content and convert to text using SimpleWebPageReader
    """

    __website_url: str

    def __init__(self, website_url: str, data_source: DataSourceModel, llm: AbstractLLM, overrides: List[dict]):
        self.__website_url = website_url
        super().__init__(IngestProcessModel(data_source_id=data_source.id), data_source, llm, overrides)

    def process_retrieve_data(self, p_status: ProcessStatus) -> Generator[str, None, Tuple[DataObjectModel, List[Document]]]:
        _documents = SimpleWebPageReader(html_to_text=True).load_data(
            [self.__website_url]
        )

        hasher = hashlib.sha3_256(f"{self.__website_url}".encode())
        _fs_filename = secure_filename(
            f"{base64.urlsafe_b64encode(hasher.digest()[:10]).decode('utf-8').replace('=', '')}.txt")
        relative_path = self._data_source.id + os.path.sep + _fs_filename

        new_data_object = DataObjectModel(name=self.__website_url,
                                          file_name=_fs_filename,
                                          file_system=self._file_storage.get_file_system(),
                                          url=self._file_storage.get_url_for_filename(relative_path),
                                          ingest_process=self._process,
                                          mime_type="text/plain")

        database.session.add(new_data_object)
        database.session.commit()

        print(f"Website ingest with {len(_documents)} documents.")
        for i, document in enumerate(_documents):
            # TODO: Do we really need have multiple objects here?
            if self._file_storage:
                logging.log(logging.INFO,
                            f"*** Storing received content to filestorage {self._file_storage.get_file_system().name}.")
                self._file_storage.write(filename=relative_path, binary_data=document.text.encode())
            else:
                logging.log(logging.INFO,
                            f"*** No file storage selected, so the received content will not be stored in the filesystem.")

        # The following yield is required to satisfy the yield from signature of the caller
        # Something must be yielded when using it. Weired but hey... this is python, isn't it? :D
        yield p_status.update(progress=75.0).to_string() + "\n"

        return (new_data_object, _documents)
    
    
class ImageIngestProcess(AbstractIngestProcess):
    """
    Process to handle image file uploads:
    - Retrieve image file
    - Store in file system (if available)
    - Generate alternative text description using LLM
    - Create document from description
    - Prepare for embedding and indexing
    """

    def __init__(self, image_file: FileStorage, data_source: DataSourceModel, llm_id: str, llm: AbstractLLM, overrides: List[dict]):
        self.__file = image_file
        self.__file_length = image_file.seek(0, os.SEEK_END)
        image_file.seek(0, os.SEEK_SET)
        super().__init__(IngestProcessModel(data_source_id=data_source.id), data_source, llm, overrides)
        logging.log(logging.INFO, f"***LLMID***.{llm}.")

    def process_retrieve_data(self, p_status: ProcessStatus) -> Generator[str, None, Tuple[DataObjectModel, List[Document]]]:
        filename = secure_filename(self.__file.filename)
        relative_path = self._data_source.id + os.path.sep + filename

        # Here comes a fun part because we trace a progress while reading the buffered stream
        file_content = b''
        bytes_read = 0
        while True:
            chunk = self.__file.stream.read(4096)
            if not chunk:
                break
            bytes_read += len(chunk)
            file_content += chunk
            # Calculate the progress (ratio of data read)
            # We say some % smaller 100 here as the simple reader further below still need some time to create a document
            progress = bytes_read / self.__file_length * 72
            yield p_status.update(progress=progress).to_string() + "\n"

        # Get mime type
        mime_type = self.__file.content_type
        if mime_type is None:
            mime_type = 'application/octet-stream'

        # Store original file in file storage if available and create data object in the db
        if self._file_storage:
            logging.log(logging.DEBUG,
                        f"*** Storing received file to filestorage {self._file_storage.get_file_system().name}.")
            self._file_storage.write(filename=relative_path, binary_data=file_content)
            new_data_object = DataObjectModel(name=filename,
                                              file_name=filename,
                                              file_system=self._file_storage.get_file_system(),
                                              url=self._file_storage.get_url_for_filename(relative_path),
                                              ingest_process=self._process,
                                              mime_type=mime_type)
        else:
            logging.log(logging.DEBUG,
                        f"*** No file storage selected, so the received file will not be stored in the filesystem.")
            new_data_object = DataObjectModel(name=filename,
                                              file_name=filename,
                                              file_system=FileStorageFileSystem.NONE,
                                              ingest_process=self._process,
                                              mime_type=mime_type)

        database.session.add(new_data_object)
        database.session.commit()

        # Process the image using a temporary file
        temp_filename = None
        try:
            _, extension = os.path.splitext(filename)
            with tempfile.NamedTemporaryFile(suffix=extension, delete=False) as temp_file:
                temp_file.write(file_content)
                temp_file.flush()
                temp_filename = temp_file.name

            # Create message for the LLM to describe the image
            msg = ChatMessage(
                role=MessageRole.USER,
                blocks=[
                    TextBlock(text="Describe the images as an alternative text"),
                    ImageBlock(path=Path(temp_filename), image_mimetype=mime_type)
                ],
            )
        
            response = self._llm.chat(messages=[msg])    
            
            documents = [Document(text=str(response.message))]

            logging.log(logging.INFO, f"Image processed and description generated {documents}")
            return new_data_object, documents
        finally:
            # Ensure the temporary file is deleted
            if temp_filename is not None and os.path.exists(temp_filename):
                os.remove(temp_filename)
                logging.log(logging.DEBUG, f"Removed temp file {temp_filename}")