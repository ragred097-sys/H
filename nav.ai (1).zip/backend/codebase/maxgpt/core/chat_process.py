import abc
import json
import logging
import re
from typing import cast, List, Generator, Optional, Union
from llama_index.core.base.base_retriever import BaseRetriever
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import ChatMessage, ImageBlock, ContentBlock, TextBlock, ChatResponse
from llama_index.core.base.llms.types import MessageRole as LlamaIndexMessageRole
from llama_index.core.callbacks import CallbackManager
from llama_index.core.chat_engine import CondensePlusContextChatEngine
from llama_index.core.chat_engine.types import BaseChatEngine, ChatMode
from llama_index.core.indices import EmptyIndex
from llama_index.core.indices.base import BaseIndex
from llama_index.core.memory import ChatMemoryBuffer
from llama_index.core.multi_modal_llms import MultiModalLLM
from llama_index.core.retrievers import RouterRetriever
from llama_index.core.schema import NodeWithScore
from llama_index.core.tools import RetrieverTool, ToolMetadata
from llama_index.core.vector_stores import MetadataFilters, MetadataFilter
from pydash import to_lower

from maxgpt.api.internal.utils import convert_to_base64, context_node_to_content_dict, \
    append_dataframe_from_part
from maxgpt.core.internal.CustomChatEventHandler import CustomChatEventHandler
from maxgpt.core.internal.utils import get_file_from_file_storage
from maxgpt.modules.impl.abstract_module import AbstractModule
from maxgpt.modules.impl.file_storage.fs_modules import AbstractFileStorage
from maxgpt.modules.impl.llms.llm_modules import AbstractLLM
from maxgpt.modules.impl.vector_stores.vector_store_indexes import AbstractVectorStore
from maxgpt.modules.modules import ModuleRegistry
from maxgpt.modules.retrievers.BroadcastRetrieverSelector import BroadcastRetrieverSelector
from maxgpt.services import database
from maxgpt.services.database_model import ConversationModel, MessageModel, MessageProcessModel, MessagePartType, \
    MessagePartModel, \
    MessageRole, DataSourceModel, DataObjectModel, IngestProcessModel, AttachmentModel, DocumentType

import pandasai as pai
from pandasai.schemas.df_config import Config


base64_pattern = re.compile(r"^data:(image/[^;]+);base64,")


class ChatResponse:
    def __init__(self, response_gen, source_nodes):
        self.__response_gen = response_gen
        self.__source_nodes = source_nodes

    def get_token_generator(self) -> Generator[str | ChatMessage | ChatResponse, None, None]:
        return self.__response_gen

    def get_source_nodes(self) -> List[NodeWithScore]:
        return self.__source_nodes


class ChatProcess(abc.ABC):
    """
    This class defines the standard workflow of MaximumGPT to retrieve data and creating
    a response to a user query using a LLM, Embedding Model, Vector Store, Agents and other transformers.
    Each component except for the LLM processing is optional and its relevance is defined by the
    request of the user, the system configuration and the availability of each module.
    Every interaction with each module is logged to the system persistence for tracing and lineage reasons.
    In a simplified point of view, this class described a low-level api implementation of
    Llama Index' stream_chat function.

    Possible overrides:

        override_embedding_similarity_top_k = int (default 6)
        override_chat_memory_buffer_token_limit = int (default 100000)

    """

    def __init__(self, conversation: ConversationModel, user_message_parts: dict, overrides: List[dict]):
        self.__conversation: ConversationModel = conversation
        self.__overrides: dict = {}
        for override in overrides:
            self.__overrides[override['name']] = override['value'] 
        # 1. Fetch and build chat history for additional context information (memory)
        # - SYSTEM prompts always remain inside the history
        # - the number of chat messages (ASSISTANT or USER) can be overwritten with override_chat_history_message_limit. The default is 10 messages
        # - SYSTEM prompts are not deducted from the limited history messages
        # For dev: we need to reverse the list of messages to fetch the LAST n messages of the conversation and then reverse again to hand it over to llama_index in the correct order!
        _chat_history_message_limit = self.__overrides[
            'override_chat_history_message_limit'] if 'override_chat_history_message_limit' in self.__overrides else 10
        self.__chat_history = []
        self.__pandas_dataframes = []
        if self.__conversation.assistant_id and self.__conversation.assistant.custom_system_instruction:
            self.__chat_history.append(
                ChatMessage(role=LlamaIndexMessageRole.SYSTEM,
                            blocks=[TextBlock(text=self.__conversation.assistant.custom_system_instruction)]))
        for i, message in enumerate(list(reversed(self.__conversation.messages))):
            if message.role == MessageRole.SYSTEM or _chat_history_message_limit > 0:
                if message.role != MessageRole.SYSTEM:
                    _chat_history_message_limit -= 1

                content_blocks: List[ContentBlock] = []
                for part in message.parts:
                    if part.type == MessagePartType.IMAGE:
                        content_blocks.append(ImageBlock(url=part.content))
                    elif part.type == MessagePartType.TEXT:
                        content_blocks.append(TextBlock(text=part.content))
                    elif part.type == MessagePartType.DOCUMENT:
                        append_dataframe_from_part(part.content, self.__pandas_dataframes)
                    elif part.type == MessagePartType.ATTACHMENT_REFERENCE:
                        # fetch attachment meta from db
                        _attachment: Optional[AttachmentModel] = AttachmentModel.query.get(part.content)
                        if _attachment:
                            if _attachment.id not in [ca.attachment_id for ca in self.__conversation.attachments]:
                                raise Exception(
                                    f"Corrupted data. Attachment with identifier '{_attachment.id}' belongs to another conversation")

                            if _attachment.type == DocumentType.IMAGE:
                                # get image from file storage
                                file_object = get_file_from_file_storage(_attachment)
                                content_blocks.append(
                                    ImageBlock(url="data:image/jpeg;base64," + convert_to_base64(file_object)))
                            elif _attachment.type == DocumentType.TEXT:
                                file_object = get_file_from_file_storage(_attachment)
                                # Try processing supported structured data files
                                append_dataframe_from_part(convert_to_base64(file_object), self.__pandas_dataframes, _attachment.mime_type)
                            elif _attachment.type == DocumentType.VIDEO:
                                _attachment_dict = _attachment.to_dict()
                                _attachment_dict.pop("thumbnail") #Avoid base64 encoded string of thumbnail in system prompt to save tokens :D
                                _attachment_ref_instruct = (
                                    f"The user might ask a question about a video. If he does without further referencing it, use the following attachment to answer him:\n"
                                    f"{_attachment_dict}.\n"
                                    f"In particular, use the field objectReference as id referencing the video and use the description to answer questions about the content of the video when its available and not instructed otherwise in order to avoid additional tool invocations.")
                                content_blocks.append(TextBlock(text=_attachment_ref_instruct))
                            else:
                                _attachment_dict = _attachment.to_dict()
                                _attachment_dict.pop(
                                    "thumbnail")  # Avoid base64 encoded string of thumbnail in system prompt to save tokens :D
                                _attachment_ref_instruct = (
                                    f"The user might ask a question about a media file. If he does without further referencing which document, use the following attachment reference details: {_attachment_dict}.\n"
                                    f"In particular, make use the objectReference if you need to refer to the document with its original identifier.")
                                content_blocks.append(TextBlock(text=_attachment_ref_instruct))
                        else:
                            logging.log(logging.WARNING, f"Attachment reference could not be resolved.")

                self.__chat_history.append(
                    ChatMessage(role=LlamaIndexMessageRole(to_lower(message.role.value)), blocks=content_blocks))

        self.__chat_history = list(reversed(self.__chat_history))

        # 2. Process and create persistence entities for the provided user message
        #    (This follows "what comes in, goes out" while the actual user prompt to the llm later is different)
        self.__user_message = MessageModel(role=MessageRole.USER, conversation=self.__conversation)
        database.session.add(self.__user_message)

        # Parse and process the message parts of the new user message
        for i, part in enumerate(user_message_parts):
            database.session.add(
                MessagePartModel(type=MessagePartType[part['type']], sequence=i, content=part['content'],
                                 message=self.__user_message))


    def get_user_message(self) -> MessageModel:
        return self.__user_message

    def execute(self) -> ChatResponse:
        logging.log(logging.INFO, f"*** Starting MessageProcess ***")

        _chat_engine: BaseChatEngine

        # 1. Collect basic configurations and modules
        # TODO: We need to get rid of the idea that a conversation can have multiple LLMs. This becomes obsolete with the support of agentic networks.
        _llm_module = fetch_module(self.__conversation.llms[0].module_id)
        _llm : Union[BaseLLM, MultiModalLLM] = _llm_module.get_impl()

        # Get configurations
        _token_limit = self.__overrides[
            'override_chat_memory_buffer_token_limit'] if 'override_chat_memory_buffer_token_limit' in self.__overrides else 100000
        _similarity_top_k = self.__overrides[
            'override_embedding_similarity_top_k'] if 'override_embedding_similarity_top_k' in self.__overrides else 3
        _similarity_top_p = self.__overrides[
            'override_embedding_similarity_top_p'] if 'override_embedding_similarity_top_p' in self.__overrides else 0.9

        # Not supported by all models
        additional_kwargs = {
            "top_p": _similarity_top_p,
            "top_k": _similarity_top_k
        }

        # 2. Collect all relevant data sources and instantiate indexes and retrievers using these indexes
        #    In case of multiple indexes, a broadcast routing will be used to consider all indexes for context creation
        _linked_assistant_ds: List[DataSourceModel] = []
        _linked_conversation_ds: List[DataSourceModel] = []
        _index_and_retrievers: List[(BaseIndex, BaseRetriever)] = []

        llama_debug = CustomChatEventHandler(callback_function=lambda x: print(x))
        callback_manager = CallbackManager([llama_debug])

        if len(self.__conversation.data_sources) > 0:
            for _c_data_source in self.__conversation.data_sources: 
                ingested_filed: List[DataObjectModel] = []
                for process in IngestProcessModel.query.filter(
                        IngestProcessModel.data_source_id == _c_data_source.data_source_id).all():
                    ingested_filed = ingested_filed + DataObjectModel.query.filter(
                        DataObjectModel.ingest_process_id == process.id).all()
                if ingested_filed:
                    # Check if data source is soft deleted 
                    _conversation_ds = DataSourceModel.query.filter(
                                     DataSourceModel.id == _c_data_source.data_source_id,
                                     DataSourceModel.deleted_at.is_(None)
                                    ).first()
                    if _conversation_ds is None:
                        continue
                    
                    _linked_conversation_ds.append(_conversation_ds)
                    _embed_model = fetch_module(_conversation_ds.embedding_model_id).get_impl()
                    _index_instance = cast(AbstractVectorStore, fetch_module(_conversation_ds.vector_store_id)).get_impl(_embed_model)
                    _index_instance.callback_manager = callback_manager
                    _retriever = _index_instance.as_retriever(
                        similarity_top_k=_similarity_top_k,
                        kwargs=additional_kwargs,
                        filters=MetadataFilters(
                            filters=[MetadataFilter(
                                key="maxgpt-filter-tag",
                                value=_conversation_ds.filter_tag
                            )]) if _conversation_ds.filter_tag else None )
                    _index_and_retrievers.append((_index_instance, _retriever))
                    logging.log(logging.DEBUG,
                                f"*** ChatProcess: Using DS '{_conversation_ds.name}' {('with filterTag: ' + _conversation_ds.filter_tag) if _conversation_ds.filter_tag else ''}")
                else:
                    logging.log(logging.WARNING, f"*** Skipping Conversation-DS for chatting with id {_c_data_source.data_source_id} because it has no ingested files ***")
        if self.__conversation.assistant and  len(self.__conversation.assistant.data_sources) > 0:
            for _a_data_source in self.__conversation.assistant.data_sources: 
                ingested_filed: List[DataObjectModel] = []
                for process in IngestProcessModel.query.filter(
                        IngestProcessModel.data_source_id == _a_data_source.data_source_id).all():
                    ingested_filed = ingested_filed + DataObjectModel.query.filter(
                        DataObjectModel.ingest_process_id == process.id).all()
                if ingested_filed:
                    # Check if data source is soft deleted  
                    _assistant_ds = DataSourceModel.query.filter(
                                     DataSourceModel.id == _a_data_source.data_source_id,
                                     DataSourceModel.deleted_at.is_(None)
                                    ).first()
                    if _assistant_ds is None:
                        continue
                    _linked_assistant_ds.append(_assistant_ds)
                    _embed_model = fetch_module(_assistant_ds.embedding_model_id).get_impl()
                    _index_instance = cast(AbstractVectorStore, fetch_module(_assistant_ds.vector_store_id)).get_impl(_embed_model)
                    _index_instance.callback_manager = callback_manager
                    _retriever = _index_instance.as_retriever(
                        similarity_top_k=_similarity_top_k,
                        kwargs=additional_kwargs,
                        filters=MetadataFilters(
                            filters=[MetadataFilter(
                                key="maxgpt-filter-tag",
                                value=_assistant_ds.filter_tag
                            )]) if _assistant_ds.filter_tag else None)
                    _index_and_retrievers.append((_index_instance, _retriever))
                    logging.log(logging.DEBUG, f"*** ChatProcess: Using DS '{_assistant_ds.name}' {('with filterTag: ' + _assistant_ds.filter_tag) if _assistant_ds.filter_tag else ''}")
                else:
                    logging.log(logging.WARNING, f"*** Skipping Assistant-DS for chatting with id {_a_data_source.data_source_id} because it has no ingested files ***")


        # 3. Initialize Chat Engine
        _chat_mode = ChatMode.CONDENSE_PLUS_CONTEXT if len(_index_and_retrievers) >= 1 else ChatMode.SIMPLE

        if len(_index_and_retrievers) > 1:
            _retriever_tools = [RetrieverTool(retriever=index_retriever, metadata=ToolMetadata(description=index.index_id, name=index.index_id)) for i, (index, index_retriever) in enumerate(_index_and_retrievers)]
            _index = RouterRetriever(llm=_llm, selector=BroadcastRetrieverSelector(), retriever_tools=_retriever_tools)
            _chat_engine = CondensePlusContextChatEngine.from_defaults(retriever=_index,
                                                           llm=_llm,
                                                           memory=ChatMemoryBuffer.from_defaults(token_limit=_token_limit),
                                                           chat_mode=_chat_mode,
                                                           kwargs=additional_kwargs)
        elif len(_index_and_retrievers) == 1:
            _chat_engine = CondensePlusContextChatEngine.from_defaults(retriever=_index_and_retrievers[0][1],
                                                 chat_mode=_chat_mode,
                                                 llm=_llm,
                                                 memory=ChatMemoryBuffer.from_defaults(token_limit=_token_limit),
                                                 kwargs=additional_kwargs)
        else:
            _index = EmptyIndex(callback_manager=callback_manager)
            _chat_engine = _index.as_chat_engine(chat_mode=_chat_mode,
                                                 llm=_llm,
                                                 memory=ChatMemoryBuffer.from_defaults(token_limit=_token_limit),
                                                 kwargs=additional_kwargs)


        # 4. Put it all together and run the llama_index wrappers
        __process = MessageProcessModel(message=self.__user_message)
        database.session.add(__process)
        database.session.commit()

        # To handles multiple different parts and types of the user input (text blocks, images, videos, attachment references, ...)
        #  we are asking the llm to create a final query out of it
        _user_message = cast(AbstractLLM, _llm_module).prompt_gen(self.__user_message.parts)

        # MULTI_MODAL: images needs to be appended to the chat history
        chat_history = self.__chat_history

        image_blocks: List[ImageBlock] = []
        for part in self.__user_message.parts:
            if part.type == MessagePartType.IMAGE:
                image_blocks.append(
                        ImageBlock(
                            url=part.content
                        ))
            elif part.type == MessagePartType.DOCUMENT:
                append_dataframe_from_part(part.content, self.__pandas_dataframes)
            elif part.type == MessagePartType.ATTACHMENT_REFERENCE:
                # fetch attachment meta from db
                _attachment: AttachmentModel = AttachmentModel.query.get_or_404(part.content)
                if _attachment.id not in [ca.attachment_id for ca in self.__conversation.attachments]:
                    raise Exception(
                        f"Corrupted data. Attachment with identifier '{_attachment.id}' belongs to another conversation")

                if _attachment.type == DocumentType.IMAGE:
                    # get image from file storage
                    file_object = get_file_from_file_storage(_attachment)
                    image_blocks.append(
                        ImageBlock(url="data:image/jpeg;base64," + convert_to_base64(file_object)))
                elif _attachment.type == DocumentType.TEXT:
                    file_object = get_file_from_file_storage(_attachment)
                    # Try processing supported structured data files
                    append_dataframe_from_part(convert_to_base64(file_object), self.__pandas_dataframes, _attachment.mime_type)

        if len(image_blocks) > 0:
            chat_history = chat_history + [ChatMessage(
                role=LlamaIndexMessageRole.USER,
                blocks=image_blocks)]

        # go with pandasai processing if we have dataframes
        if len(self.__pandas_dataframes) > 0:
            _pai_llm = cast(AbstractLLM, _llm_module).get_pandasai_impl()
            if _pai_llm is None:
                raise Exception(
                    f"Structured data was attached but no pandasai implementation was found for the selected llm"
                )
            agent = pai.agent.Agent(self.__pandas_dataframes, config=Config(llm=_pai_llm))
            for msg in chat_history:
                agent.add_message(msg.content, msg.role==MessageRole.USER)
            agent.add_message("\n IMPORTANT INSTRUCTION: Column names and values can contain trailing spaces.", is_user=False)
            pandas_response = agent.chat(_user_message, output_type="string")
            logging.log(logging.DEBUG, f"*** ChatProcess: Pandasai response: {pandas_response}:")

            if not isinstance(pandas_response, str):
                pandas_response = str(pandas_response)

            logging.log(logging.DEBUG, f"*** ChatProcess: Pandasai response: {pandas_response}:")

            # Create a generator that yields the pandas_response
            # def pandas_response_gen():
            #     yield pandas_response

            # We append the on-the-fly generated context information to the chat history and the let the workflow
            # process normally.
            chat_history = chat_history + [ChatMessage(
                content=pandas_response,
                role=LlamaIndexMessageRole.SYSTEM
            )]

            _user_message += (
                "\n CRITICAL INSTRUCTION: The answer for this prompt is already given by the assistant in the last message. "
                "Present the answer as if it was given by you and integrate it seamlessly into the conversation.")

            # return ChatResponse(pandas_response_gen(), []) #TODO: Use if the append to the history does not work out


        logging.log(logging.INFO,
                    f"*** Using a total of {len(_index_and_retrievers)} data sources for chatting ***")
        logging.log(logging.INFO, f"*** ChatProcess: Using token limit = {_token_limit}")
        logging.log(logging.INFO, f"*** ChatProcess: Using chat mode = {_chat_mode}")
        logging.log(logging.INFO, f"*** ChatProcess: Using similarity top k = {_similarity_top_k}")
        logging.log(logging.INFO, f"*** ChatProcess: Using additional kwargs = {additional_kwargs}")

        # Calling llama_index chat engine routine and return the response generator to yield response tokens.
        # dispatcher = get_dispatcher()
        # event_handler = ChatEventHandler()
        # dispatcher.add_event_handler(event_handler)
        # TODO: DK: Please help here. I would like to have something that does not work with the global disptcher
        #  because this will probably cause threading issues and mem leaks. Also, I would like to yield from within
        #  the event handler.

        chat_response = _chat_engine.stream_chat(_user_message, chat_history)

        logging.log(logging.DEBUG, f"*** ChatProcess: Retrieved this context from the VS:")
        retrieved_context_nodes = []
        for source_node in chat_response.source_nodes:
            retrieved_context_nodes.append(context_node_to_content_dict(source_node))
        logging.log(logging.DEBUG, json.dumps(retrieved_context_nodes, indent=2))

        if len(retrieved_context_nodes) == 0:
            chat_history = chat_history + [ChatMessage(
                role=LlamaIndexMessageRole.USER,
                content=_user_message)]
            return ChatResponse (_llm.stream_chat(chat_history), chat_response.source_nodes)
        else:
            return ChatResponse (chat_response.response_gen, chat_response.source_nodes)


def fetch_module(module_id):
    return cast(AbstractModule, ModuleRegistry.get_module(module_id))
