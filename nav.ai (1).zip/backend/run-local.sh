#!/bin/bash

set -e
trap 'cleanup' EXIT

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="${SCRIPT_DIR}/codebase/maxgpt"
VENV_DIR="${SCRIPT_DIR}/../venv"
REQUIRED_ENV_VARS=(
    "DB_PROVIDER"
    "DB_POSTGRES_DBNAME"
    "DB_POSTGRES_HOST"
    "DB_POSTGRES_PASSWORD"
    "DB_POSTGRES_PORT"
    "DB_POSTGRES_USERNAME"
    "EQTY_INDEX_USERID"
    "EQTY_INDEX_PASSWD"
    "AUTH_OPENID_AUTHORITY_URL"
    "AUTH_OPENID_CLIENT_ID"
    "AUTH_OPENID_CLIENT_SECRET"
    "AUTH_OPENID_REDIRECT_URI"
    "EQTY_PROJECT"
    "API_PORT"
)

log() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $1"
}

error() {
    log "ERROR: $1" >&2
}

cleanup() {
    log "Cleaning up..."
    # Add any cleanup tasks here
}

check_env_vars() {
    local missing_vars=()
    for var in "${REQUIRED_ENV_VARS[@]}"; do
        if [ -z "${!var}" ]; then
            missing_vars+=("$var")
        fi
    done
    if [ ${#missing_vars[@]} -ne 0 ]; then
        error "Missing required environment variables:"
        printf '%s\n' "${missing_vars[@]}"
        exit 1
    fi
}

load_env() {
    if [ -f "${SCRIPT_DIR}/../.env" ]; then
        log "Loading environment variables from .env file"
        set -o allexport
        source "${SCRIPT_DIR}/../.env"
        set +o allexport
    else
        log "No .env file found, using existing environment variables"
    fi
    
    # Override database hosts for local development
    log "Overriding database hosts for local development"
    export DB_POSTGRES_HOST=0.0.0.0
    export DB_MSSQL_HOST=0.0.0.0
    
    # Also override any other potential database host variables
    export DB_HOST=0.0.0.0
    export POSTGRES_HOST=0.0.0.0
    export MSSQL_HOST=0.0.0.0
    
    log "Database hosts set to: DB_POSTGRES_HOST=$DB_POSTGRES_HOST, DB_MSSQL_HOST=$DB_MSSQL_HOST"
}

# Check for container runtime
check_container_runtime() {
    if command -v docker >/dev/null 2>&1; then
        echo "docker"
    elif command -v podman >/dev/null 2>&1; then
        echo "podman"
    else
        error "Neither Docker nor Podman is installed"
        exit 1
    fi
}

# Stop backend container if running
stop_container() {
    local runtime=$1
    local container_name="nav-ai-docker-backend-1"
    if "$runtime" ps -q --filter "name=$container_name" | grep -q .; then
        log "Stopping container: $container_name"
        "$runtime" stop "$container_name"
    else
        log "Container $container_name is not running"
    fi
}

# Create VSCode debug configuration
create_vscode_config() {
    local vscode_dir="${SCRIPT_DIR}/../.vscode"
    local launch_file="${vscode_dir}/launch.json"
    
    log "Creating/updating VSCode debug configuration..."
    mkdir -p "$vscode_dir"
    cat > "$launch_file" << EOF
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Flask Debug",
            "type": "debugpy",
            "request": "launch",
            "module": "flask",
            "python": "${VENV_DIR}/bin/python",
            "env": {
                "FLASK_APP": "api.main",
                "FLASK_ENV": "development",
                "FLASK_DEBUG": "1",
                "PYTHONPATH": "${BACKEND_DIR}",
                "APP_APPLICATION_ROOT": "/maximumgpt-dev",
                "APP_ENABLE_CORS": "true",
                "DB_POSTGRES_HOST": "0.0.0.0",
                "DB_MSSQL_HOST": "0.0.0.0",
                "DB_HOST": "0.0.0.0",
                "POSTGRES_HOST": "0.0.0.0",
                "MSSQL_HOST": "0.0.0.0"
            },
            "args": [
                "run",
                "--host=0.0.0.0",
                "--port=5001"
            ],
            "cwd": "${BACKEND_DIR}"
        }
    ]
}
EOF
    log "VSCode debug configuration updated at $launch_file"
}

main() {
    log "Starting backend in local debug mode..."

    load_env
    check_env_vars

    # Check and stop backend container if running
    local runtime=$(check_container_runtime)
    stop_container "$runtime"

    cd "$BACKEND_DIR" || {
        error "Failed to change to backend directory: $BACKEND_DIR"
        exit 1
    }

    # Activate venv if exists, otherwise create it
    if [ ! -d "${VENV_DIR}" ]; then
        log "Python virtual environment not found. Creating one in ${VENV_DIR}..."
        if command -v python3.12 >/dev/null 2>&1; then
            PYTHON_BIN=python3.12
        else
            error "Python 3.12 is required but not found. Please install Python 3.12."
            exit 1
        fi
        $PYTHON_BIN -m venv "${VENV_DIR}"
        log "Virtual environment created."
    fi
    log "Activating Python virtual environment"
    source "${VENV_DIR}/bin/activate"
    log "Installing backend requirements..."
    python -m pip install --upgrade pip
    python -m pip install -r "${SCRIPT_DIR}/codebase/requirements.txt"

    export FLASK_APP=api.main
    export FLASK_ENV=development
    export FLASK_DEBUG=1
    export PYTHONPATH="$BACKEND_DIR"

    # Create VSCode debug configuration
    create_vscode_config
    
    log "Done. To debug in Cursor/VSCode:
1. Open the project in VSCode
2. Press F5 to start debugging
3. Select 'Flask Debug' from the dropdown
4. Set breakpoints in the code
5. The debugger will start Flask automatically"
}

main 