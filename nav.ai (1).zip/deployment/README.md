# Info 
This repo contains all of the deployment scripts necessary to stand up a kubernetes deployment.

# Repo Structure

```
this-repo/
├── certs/ - for the domains, steal privatekey from here
│   ├── navai.accentureanalytics.com/
│   └── navairefinery.accentureanalytics.com/
├── helm/ - deploy a full environment
│   ├── templates/
│   │   ├── backend/
│   │   ├── frontend/
│   │   ├── minio/
│   │   ├── postgres/
│   │   └── qdrant/
|   ├── Chart.yaml - helm chart meta
│   └── values.yaml - where the magic happens
├── manifests/ - if you want to manually deploy to k8s
│   ├── aip/ - required by ACN Infosec (Prisma cluster integration)
│   ├── backend/
│   ├── frontend/
│   ├── minio/
│   ├── nginx-ingress/ - run once for new clusters, not part of helm
│   ├── keycloak/ - run once for new clusters, not part of helm
│   ├── postgres/
│   └── qdrant/
└── seeder/
    ├── module_seeder.py - run once env is up
    └── requirements.txt - install in a venv
```

# Login aliases
Put these in your .rc 

`alias loginnavai1='az login --tenant 7f80e33e-9708-4370-91bb-b63cbe535f18 && az aks get-credentials -n aips1ahrapaks01 -g rg-navai && kubelogin convert-kubeconfig -l msi'`

`alias loginnavai2='az login --tenant 7f80e33e-9708-4370-91bb-b63cbe535f18 && az aks get-credentials -n aips1ahrapaks02 -g rg-navai && kubelogin convert-kubeconfig -l msi'`

Install latest az-cli, and then `az aks install-cli`

Use subscription aip4defense-sandbox_1 e3040798-48f2-4498-a90b-32a3c59e677f

# Cluster info
Clusters: 
- aips1ahrapaks01 - demo1/demo2
- aips1ahrapaks02 - dev/qa/prod

Certs deployed @ ingress/navai-cert:
- aks02: navai.accentureanalytics.com 
- aks01: navairefinery.accentureanalytics.com 

TLS required between Application Gateway and Internal Load Balancers (otherwise you get a g2g vulnerability)

ILBs for ingress: 
- aks01: 10.185.252.201 (hostname: navaiaks01.local)
- aks02: 10.185.252.202 (hostname: navaiaks02.local)

Use AIP VPN to aip4defense to access navaiaks01/02.local for direct access to:
* minio ui: http://navaiaks02.local/{env}/minio-ui
* qdrant ui: http://navaiaks02.local/{env}/qdrant-ui/dashboard
* postgres: 
  - dev: navaiaks02.local:5432
  - qa: navaiaks02.local:15432
  - prod: navaiaks02.local:25432

## Other considerations
You need the following agent pools in your cluster: `workerpool` (for ingress, frontend, backend) and `databases` (for postgres, qdrant, minio).

If you're running in AKS with D6 series that have NVME controllers, Azure is currently lacking the nvme driver on the OS deployed to the node.

```kubectl apply -f https://raw.githubusercontent.com/andyzhangx/demo/refs/heads/master/aks/download-v6-disk-rules.yaml```

This will fix the driver issue, but it'll create a dependency on this guy andyzhangx's yaml file, so you might want to run/server this locally instead. Azure fix is pending.

# Architecture

Each NAVAI deployment has its own namespace in the clusters, dev, qa, prod on aks02, and demo1, demo2 on aks01. One nginx ingress controller is deployed in each cluster with a private Azure Load Balancer in the resource group of the cluster (that AKS automatically creates). There are 2 Azure Application Gateways that each connect to one cluster. Each namespace has the NAVAI UI frontend application, MaxGPT backend application, minio, postgres and qdrant.

Use the [Mermaid Markdown Preview extension](https://marketplace.visualstudio.com/items?itemName=bierner.markdown-mermaid) to view the diagram:
```mermaid
flowchart TB
    %% External Access Points
    AppGW1("Azure Application Gateway 1
    ag-navai-1
    navairefinery.accentureanalytics.com")
    AppGW2("Azure Application Gateway 2
    ag-navai
    navai.accentureanalytics.com")
    
    %% Load Balancers
    ILB1("Internal Azure Load Balancer
    navaiaks01.local
    10.185.252.201")
    ILB2("Internal Azure Load Balancer
    navaiaks02.local
    10.185.252.202")
    
    %% Connection from AppGW to ILB
    AppGW1 -- "TLS required" --> ILB1
    AppGW2 -- "TLS required" --> ILB2
    
    %% AKS Clusters
    subgraph AKS01["Cluster: aips1ahrapaks01"]
        Nginx1["Nginx Ingress Controller"] -- routes --> demo1
        Nginx1 -- routes --> demo2
        
        subgraph demo1["Namespace: demo1"]
            demo1_ui["NAVAI UI Frontend"]
            demo1_max["MaxGPT Backend"]
            demo1_minio["Minio"]
            demo1_postgres["Postgres"]
            demo1_qdrant["Qdrant"]
        end
        
        subgraph demo2["Namespace: demo2"]
            demo2_ui["NAVAI UI Frontend"]
            demo2_max["MaxGPT Backend"]
            demo2_minio["Minio"]
            demo2_postgres["Postgres"]
            demo2_qdrant["Qdrant"]
        end
    end
    
    subgraph AKS02["Cluster: aips1ahrapaks02"]
        Nginx2["Nginx Ingress Controller"] -- routes --> dev
        Nginx2 -- routes --> qa
        Nginx2 -- routes --> prod
        
        subgraph dev["Namespace: dev"]
            dev_ui["NAVAI UI Frontend"]
            dev_max["MaxGPT Backend"]
            dev_minio["Minio"]
            dev_postgres["Postgres"]
            dev_qdrant["Qdrant"]
        end
        
        subgraph qa["Namespace: qa"]
            qa_ui["NAVAI UI Frontend"]
            qa_max["MaxGPT Backend"]
            qa_minio["Minio"]
            qa_postgres["Postgres"]
            qa_qdrant["Qdrant"]
        end
        
        subgraph prod["Namespace: prod"]
            prod_ui["NAVAI UI Frontend"]
            prod_max["MaxGPT Backend"]
            prod_minio["Minio"]
            prod_postgres["Postgres"]
            prod_qdrant["Qdrant"]
        end
    end
    
    %% Load Balancer connections to Nginx
    ILB1 --> Nginx1
    ILB2 --> Nginx2
```

# Module Seeder
Create a venv and install reqs. Run with `python module_seeder.py --help` to see the options. There's no check on whether the modules exist or not, don't run more than once or you will have duplicate modules.

# VPN
If you have access...
1. Download [FortiClient VPN-only](https://www.fortinet.com/support/product-downloads)
2. Create a new connection for aip4defense
  - Remote Gateway: `137.117.196.6`
  - Enable SSO (use Accenture email for Username)
  - Check "Use external browser as user-agent"
3. If you need to (re)set your password
  - https://ssp.accentureanalytics.com/
  - Use either First Time Login? or Forgot Password?
  - Your username is domain\eid. Domain is `hpsandbox`

# Access and Deployment
You'll need VPN connectivity to access the AKS controlplane apis. 

Use [k9s](https://k9scli.io/) to see your cluster at a glance and exec easily into pods.

## Helm
Run from within the `./helm` folder.

You'll need to create the namespace first.

Do a dry-run first:

```
helm install navai . \
--namespace qa \
--set global.environment=qa \
--set global.akslocaldns=navaiaks02.local \
--set global.domain=navai.accentureanalytics.com \
--set backend.config.AUTH_OPENID_CLIENT_SECRET="mCCEize5FnphN9Mc4sVA3g6M0F4U2gj1" \
--values values-dqp.yaml \
--dry-run
```

Make sure to provide the arguments above, but hopefully you'll never have to run this. `global.` vars intentionally left blank inside the `values-*.yaml` - they need to be passed as arguments. When running, remove `--dry-run` from the command above.

When deploying to demo1/demo2, ensure that frontend/backend image tags are set to `demo`

```
helm upgrade navai . \
--namespace demo1 \
--set global.environment=demo1 \
--set global.akslocaldns=navaiaks01.local \
--set global.domain=navairefinery.accentureanalytics.com \
--set backend.config.AUTH_OPENID_CLIENT_SECRET="NsRn3IUJUZfT91mPLQAPh40QYbgzKVDj" \
--values values-demo.yaml \ 
--set frontend.image.tag=demo \
--set backend.image.tag=demo
```


## Post Install
0. Connect to VPN

### MinIO
1. Navigate to cluster.local/minio-ui/login (ex. http://navaiaks01.local/demo2/minio-ui/login)
2. Login with credentials
3. Create a key/secret, and a bucket called "data"
4. Update the MinIO module config

### Qdrant
1. Create a test datasource for both Qdrant indexes
2. Use the ONE embedding model that you will use from that moment forward in that index
3. Upload a document

### Postgres
To connect to the postgres db, use the ILB IP and not the cluster.local name with the respective port from the nginx-ingress configuration.

## Other gotchas
### Azure Install
When following standard deployment BOM with Application Gateway -> Cluster Internal Azure Load Balancer -> Nginx Ingress, you need to set the AG backend timeout to 10 minutes and the LB idle timeout to 10 minutes to avoid having client disconnects from browser to backend on ingesting large files.

## SHA Cipher policy 
When setting up the Application gateway make sure to setup the Appropriate Cipher policy 
For this Azure Deployment follow below steps
1. Go to Application Gateway ag-navai(QA\DEV\PROD) ag-navai-1(demo1\demo2)
2. Setting > Listeners
3. Selected SSL Policy:Policy name: AppGwSslPolicy20220101S    
