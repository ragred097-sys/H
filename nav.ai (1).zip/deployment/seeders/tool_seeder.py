import getpass
import requests
import json
import os
import argparse

def get_config():
    # Use argparse for command-line options
    parser = argparse.ArgumentParser(
        description='NAV.AI backend configuration',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Backend URL configuration
    parser.add_argument('--domain', choices=['navai', 'navairefinery'], 
                      default=os.environ.get('NAVAI_DOMAIN', 'navai'),
                      help='Domain to use (navai or navairefinery)')
    parser.add_argument('--env', 
                      default=os.environ.get('NAVAI_ENV', 'dev'),
                      help='Environment to use (dev/qa/prod for navai, demo1/demo2 for navairefinery)')
    parser.add_argument('--username', 
                      help='Username to use for authentication')
    parser.add_argument('--password', 
                      help='Password to use for authentication')
    
    # Enable all modules option
    parser.add_argument('--enable-all-tools', 
                      action='store_true',
                      help='Enable all tool types (overrides individual tool settings)')
    
    # Individual tool activation flags - all default to disabled (store_false)
    parser.add_argument('--enable-charting-tool', 
                      dest='ENABLE_CHARTING_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_CHARTING_TOOL', '').lower() == 'true',
                      help='Enable Charting tool')

    parser.add_argument('--enable-gantt-chart-tool', 
                      dest='ENABLE_GANTT_CHART_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_GANTT_CHART_TOOL', '').lower() == 'true',
                      help='Enable Gantt Chart tool')

    parser.add_argument('--enable-mapping-tool', 
                      dest='ENABLE_MAPPING_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_MAPPING_TOOL', '').lower() == 'true',
                      help='Enable Mapping tool')
    
    parser.add_argument('--enable-markdown-tool', 
                      dest='ENABLE_MARKDOWN_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_MARKDOWN_TOOL', '').lower() == 'true',
                      help='Enable Markdown tool')
    
    parser.add_argument('--enable-react-flow-tool', 
                      dest='ENABLE_REACT_FLOW_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_REACT_FLOW_TOOL', '').lower() == 'true',
                      help='Enable React Flow tool')
    
    parser.add_argument('--enable-react-flow-swimlane-tool', 
                      dest='ENABLE_REACT_FLOW_SWIMLANE_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_REACT_FLOW_SWIMLANE_TOOL', '').lower() == 'true',
                      help='Enable React Flow Swimlane tool')
    
    parser.add_argument('--enable-mermaid-tool', 
                      dest='ENABLE_MERMAID_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_MERMAID_TOOL', '').lower() == 'true',
                      help='Enable Mermaid tool')
    
    parser.add_argument('--enable-table-tool', 
                      dest='ENABLE_TABLE_TOOL',
                      action='store_true',
                      default=os.environ.get('ENABLE_TABLE_TOOL', '').lower() == 'true',
                      help='Enable Table tool')
    
    # Tool prefix setting
    parser.add_argument('--tools-prefix',
                      dest='TOOLS_PREFIX',
                      default=os.environ.get('VITE_APP_TOOLS_PREFIX', 'Nav.AI Tool - '),
                      help='Prefix for tool names')
    
    # Parse arguments
    args = parser.parse_args()
    
    # If enable-all-modules is set, override all individual settings
    if args.enable_all_tools:
        args.ENABLE_CHARTING_TOOL = True
        args.ENABLE_GANTT_CHART_TOOL = True
        args.ENABLE_MAPPING_TOOL = True
        args.ENABLE_MARKDOWN_TOOL = True
        args.ENABLE_REACT_FLOW_TOOL = True
        args.ENABLE_REACT_FLOW_SWIMLANE_TOOL = True
        args.ENABLE_MERMAID_TOOL = True
        args.ENABLE_TABLE_TOOL = True

    if args.env == "local":
        backend_url = os.environ.get('VITE_BACKEND_BASE_URL')
    else: 
        # Validate environment for chosen domain
        valid_envs = {
            "navai": ["dev", "qa", "prod"],
            "navairefinery": ["demo1", "demo2"]
        }
        
        if args.domain in valid_envs and args.env not in valid_envs[args.domain]:
            print(f"Warning: '{args.env}' may not be a valid environment for domain '{args.domain}'")
            print(f"Valid environments for '{args.domain}' are: {', '.join(valid_envs[args.domain])}")
        
        # Construct the backend URL
        backend_url = f"https://{args.domain}.accentureanalytics.com/{args.env}/api/api/v1"
    
    # Return all configuration
    config = {
        "backend": backend_url,
        "username": args.username,
        "password": args.password,
        "ENABLE_CHARTING_TOOL": args.ENABLE_CHARTING_TOOL,
        "ENABLE_GANTT_CHART_TOOL": args.ENABLE_GANTT_CHART_TOOL,
        "ENABLE_MAPPING_TOOL": args.ENABLE_MAPPING_TOOL,
        "ENABLE_MARKDOWN_TOOL": args.ENABLE_MARKDOWN_TOOL,
        "ENABLE_REACT_FLOW_TOOL": args.ENABLE_REACT_FLOW_TOOL,
        "ENABLE_REACT_FLOW_SWIMLANE_TOOL": args.ENABLE_REACT_FLOW_SWIMLANE_TOOL,
        "ENABLE_MERMAID_TOOL": args.ENABLE_MERMAID_TOOL,
        "ENABLE_TABLE_TOOL": args.ENABLE_TABLE_TOOL,
        "TOOLS_PREFIX": args.TOOLS_PREFIX
    }
    
    return config

# Get all configuration settings
config = get_config()
backend = config["backend"]

# Configuration flags - extracted from config
ENABLE_CHARTING_TOOL = config["ENABLE_CHARTING_TOOL"]
ENABLE_GANTT_CHART_TOOL = config["ENABLE_GANTT_CHART_TOOL"]
ENABLE_MAPPING_TOOL = config["ENABLE_MAPPING_TOOL"]
ENABLE_MARKDOWN_TOOL = config["ENABLE_MARKDOWN_TOOL"]
ENABLE_REACT_FLOW_TOOL = config["ENABLE_REACT_FLOW_TOOL"]
ENABLE_REACT_FLOW_SWIMLANE_TOOL = config["ENABLE_REACT_FLOW_SWIMLANE_TOOL"] 
ENABLE_MERMAID_TOOL = config["ENABLE_MERMAID_TOOL"]
ENABLE_TABLE_TOOL = config["ENABLE_TABLE_TOOL"]
TOOLS_PREFIX = config["TOOLS_PREFIX"]


# Print the configuration
print("########## CONFIGURATION ##########")
print(f"Backend URL: {backend}")
print(f"Tools Prefix: {TOOLS_PREFIX}")
print(f"Charting Tool: {'Enabled' if ENABLE_CHARTING_TOOL else 'Disabled'}")
print(f"Gantt Chart Tool: {'Enabled' if ENABLE_GANTT_CHART_TOOL else 'Disabled'}")
print(f"Mapping Tool: {'Enabled' if ENABLE_MAPPING_TOOL else 'Disabled'}")
print(f"Markdown Tool: {'Enabled' if ENABLE_MARKDOWN_TOOL else 'Disabled'}")
print(f"React Flow Tool: {'Enabled' if ENABLE_REACT_FLOW_TOOL else 'Disabled'}")
print(f"React Flow Swimlane Tool: {'Enabled' if ENABLE_REACT_FLOW_SWIMLANE_TOOL else 'Disabled'}")
print(f"Mermaid Tool: {'Enabled' if ENABLE_MERMAID_TOOL else 'Disabled'}")
print(f"Table Tool: {'Enabled' if ENABLE_TABLE_TOOL else 'Disabled'}")

grant_type = "password"
print("########## AUTHENTICATING TO KEYCLOAK ##########")
if config["username"] and config["password"]:
    username = config["username"]
    password = config["password"]
else:
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")

r = requests.get(f"{backend}/authentication/", verify=False)
print("########## AUTHENTICATION CONFIG ##########")
print(json.dumps(r.json(), indent=4))
auth_config = r.json()["config"]

keycloak_url = f"{auth_config['authority']}/protocol/openid-connect/token"
client_id = auth_config["clientId"]
client_secret = auth_config["clientSecret"]

token_response = requests.post(
    keycloak_url,
    data={
        "client_id": client_id,
        "username": username,
        "password": password,
        "client_secret": client_secret,
        "grant_type": grant_type,
    },
    headers={"Content-Type": "application/x-www-form-urlencoded"},
)

if token_response.status_code == 200:
    token_data = token_response.json()
    bearer_token = token_data["access_token"]
    print("RETRIEVED TOKEN, CREATING DEFAULT TOOLS")
else:
    raise Exception(
        "Failed to retrieve token:", token_response.status_code, token_response.text
    )

if bearer_token:
    auth_headers = {"Authorization": f"Bearer {bearer_token}"}
else:
    raise Exception("Bearer token not found, exiting script.")

# Extract tool from markdown file
def extract_tool_from_markdown(file_name):
    with open(os.path.join(os.path.dirname(__file__), "../ip/tools/" + file_name), 'r') as file:
        content = file.read()
        name_part = TOOLS_PREFIX + content.split("Name:")[1].split("Description:")[0].strip()
        description_part = content.split("Description:")[1].split("\n\n", 1)[0].strip()
        
        # Extract message part - everything after the empty lines following description
        message_part = content.split("Description:")[1].split("\n\n", 1)[1].strip() if "\n\n" in content.split("Description:")[1] else ""
        
        tool = {
            "name": name_part,
            "description": description_part,
            "message": message_part
        }
    return tool


# Build the tools array based on enabled sections
tools = []
if ENABLE_CHARTING_TOOL:
    tools.append(extract_tool_from_markdown("charting.md"))
if ENABLE_GANTT_CHART_TOOL:
    tools.append(extract_tool_from_markdown("gantt_chart.md"))
if ENABLE_MAPPING_TOOL:
    tools.append(extract_tool_from_markdown("mapping.md"))
if ENABLE_MARKDOWN_TOOL:
    tools.append(extract_tool_from_markdown("markdown.md"))
if ENABLE_REACT_FLOW_TOOL:
    tools.append(extract_tool_from_markdown("react_flow.md"))
if ENABLE_REACT_FLOW_SWIMLANE_TOOL:
    tools.append(extract_tool_from_markdown("react_flow_swimlane.md"))
if ENABLE_MERMAID_TOOL:
    tools.append(extract_tool_from_markdown("mermaid.md"))
if ENABLE_TABLE_TOOL:
    tools.append(extract_tool_from_markdown("table.md"))

r = requests.get(f"{backend}/system-instructions", headers=auth_headers)
if r.status_code != 200:
    raise Exception(f"Failed to retrieve tools: {r.status_code}")
existing_tools = r.json()

# Build a dict for fast lookup by name
existing_tools_by_name = {t["name"]: t for t in existing_tools}

for tool in tools:
    existing = existing_tools_by_name.get(tool["name"])
    if existing:
        # Check if any relevant fields differ
        needs_update = False
        for k in ["description", "message"]:
            if k in tool and tool[k] != existing.get(k):
                needs_update = True
        if needs_update:
            updated_tool = existing.copy()
            for k in ["description", "message"]:
                if k in tool:
                    updated_tool[k] = tool[k]
            put_url = f"{backend}/system-instruction/{existing['id']}"
            r = requests.put(put_url, json=updated_tool, headers=auth_headers)
            if r.status_code != 200:
                print(f"Failed to update tool {tool['name']}: {r.status_code}")
                print(r.text)
            else:
                print(f"Tool {tool['name']} updated successfully!")
                print(r.json().get("modifiedAt"))
                print(r.json()["modifier"]["name"])
                print(r.json().get("name"))
        else:
            print(f"Tool {tool['name']} is up to date, skipping update.")
    else:
        r = requests.post(f"{backend}/system-instruction", json=tool, headers=auth_headers)
        if r.status_code != 200:
            print(f"Failed to create tool {tool['name']}: {r.status_code}")
            print(r.text)
        else:
            print(f"Tool {tool['name']} created successfully!")
            print(r.json().get("createdAt"))
            print(r.json()["creator"]["name"])
            print(r.json().get("name"))
