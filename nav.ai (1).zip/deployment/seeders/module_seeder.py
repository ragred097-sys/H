import getpass
import requests
import json
import os
import argparse

def get_config():
    # Use argparse for command-line options
    parser = argparse.ArgumentParser(
        description='NAV.AI backend configuration',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Backend URL configuration
    parser.add_argument('--domain', choices=['navai', 'navairefinery'], 
                      default=os.environ.get('NAVAI_DOMAIN', 'navai'),
                      help='Domain to use (navai or navairefinery)')
    parser.add_argument('--env', 
                      default=os.environ.get('NAVAI_ENV', 'dev'),
                      help='Environment to use (dev/qa/prod for navai, demo1/demo2 for navairefinery)')
    parser.add_argument('--username', 
                      help='Username to use for authentication')
    parser.add_argument('--password', 
                      help='Password to use for authentication')
    
    # Enable all modules option
    parser.add_argument('--enable-all-modules', 
                      action='store_true',
                      help='Enable all module types (overrides individual module settings)')
    
    # Individual module activation flags - all default to disabled (store_false)
    parser.add_argument('--enable-azure-openai', 
                      dest='ENABLE_AZURE_OPENAI',
                      action='store_true',
                      default=os.environ.get('ENABLE_AZURE_OPENAI', '').lower() == 'true',
                      help='Enable Azure OpenAI modules')
    
    parser.add_argument('--enable-vector-stores', 
                      dest='ENABLE_VECTOR_STORES',
                      action='store_true',
                      default=os.environ.get('ENABLE_VECTOR_STORES', '').lower() == 'true',
                      help='Enable Vector Store modules (Qdrant)')
    
    parser.add_argument('--enable-file-storage', 
                      dest='ENABLE_FILE_STORAGE',
                      action='store_true',
                      default=os.environ.get('ENABLE_FILE_STORAGE', '').lower() == 'true',
                      help='Enable File Storage modules (MinIO)')
    
    parser.add_argument('--enable-nvidia-vss', 
                      dest='ENABLE_NVIDIA_VSS',
                      action='store_true',
                      default=os.environ.get('ENABLE_NVIDIA_VSS', '').lower() == 'true',
                      help='Enable NVIDIA Video Storage Service modules')
    
    parser.add_argument('--enable-nvidia-models', 
                      dest='ENABLE_NVIDIA_MODELS',
                      action='store_true',
                      default=os.environ.get('ENABLE_NVIDIA_MODELS', '').lower() == 'true',
                      help='Enable NVIDIA LLM modules (Llama, Granite, etc)')
    
    # Parse arguments
    args = parser.parse_args()
    
    # If enable-all-modules is set, override all individual settings
    if args.enable_all_modules:
        args.ENABLE_AZURE_OPENAI = True
        args.ENABLE_VECTOR_STORES = True
        args.ENABLE_FILE_STORAGE = True
        args.ENABLE_NVIDIA_VSS = True
        args.ENABLE_NVIDIA_MODELS = True
    
    if args.env == "local":
        backend_url = os.environ.get('VITE_BACKEND_BASE_URL')
    else: 
        # Validate environment for chosen domain
        valid_envs = {
            "navai": ["dev", "qa", "prod"],
            "navairefinery": ["demo1", "demo2"]
        }
        
        if args.domain in valid_envs and args.env not in valid_envs[args.domain]:
            print(f"Warning: '{args.env}' may not be a valid environment for domain '{args.domain}'")
            print(f"Valid environments for '{args.domain}' are: {', '.join(valid_envs[args.domain])}")
        
        # Construct the backend URL
        backend_url = f"https://{args.domain}.accentureanalytics.com/{args.env}/api/api/v1"
    
    # Return all configuration
    config = {
        "backend": backend_url,
        "username": args.username,
        "password": args.password,
        "ENABLE_AZURE_OPENAI": args.ENABLE_AZURE_OPENAI,
        "ENABLE_VECTOR_STORES": args.ENABLE_VECTOR_STORES,
        "ENABLE_FILE_STORAGE": args.ENABLE_FILE_STORAGE,
        "ENABLE_NVIDIA_VSS": args.ENABLE_NVIDIA_VSS,
        "ENABLE_NVIDIA_MODELS": args.ENABLE_NVIDIA_MODELS
    }
    
    return config

# Get all configuration settings
config = get_config()
backend = config["backend"]

# Configuration flags - extracted from config
ENABLE_AZURE_OPENAI = config["ENABLE_AZURE_OPENAI"]
ENABLE_VECTOR_STORES = config["ENABLE_VECTOR_STORES"]
ENABLE_FILE_STORAGE = config["ENABLE_FILE_STORAGE"]
ENABLE_NVIDIA_VSS = config["ENABLE_NVIDIA_VSS"]
ENABLE_NVIDIA_MODELS = config["ENABLE_NVIDIA_MODELS"]

# Print the configuration
print("########## CONFIGURATION ##########")
print(f"Backend URL: {backend}")
print(f"Azure OpenAI Modules: {'Enabled' if ENABLE_AZURE_OPENAI else 'Disabled'}")
print(f"Vector Store Modules: {'Enabled' if ENABLE_VECTOR_STORES else 'Disabled'}")
print(f"File Storage Modules: {'Enabled' if ENABLE_FILE_STORAGE else 'Disabled'}")
print(f"NVIDIA VSS Modules: {'Enabled' if ENABLE_NVIDIA_VSS else 'Disabled'}")
print(f"NVIDIA Model Modules: {'Enabled' if ENABLE_NVIDIA_MODELS else 'Disabled'}")

gpt_4o_1_api_key = "d80fccd0dbcb411eb3d30e1bc02f6e96"
gpt_4o_1_endpoint = "https://aiphuahhaiopai04.openai.azure.com"
gpt_4o_1_version = "2023-07-01-preview"
gpt_4o_1_deploymentname = "aip4d-gpt4o"

oai_embed_1_api_key = "d80fccd0dbcb411eb3d30e1bc02f6e96"
oai_embed_1_endpoint = "https://aiphuahhaiopai04.openai.azure.com"
oai_embed_1_version = "2023-05-15"
oai_embed_1_deploymentname = "aip4d-textemblg"

oai_embed_2_api_key = "3GMIBPWp0tydudN889B46AYvhLZ5yeJ6tDFJ5bFyVD1JqFqph6KaJQQJ99BCACfhMk5XJ3w3AAABACOGY8Xg"
oai_embed_2_endpoint = "https://aipnavaioai02.openai.azure.com"
oai_embed_2_version = "2023-05-15"
oai_embed_2_deploymentname = "text-embedding-3-large"

gpt_4o_2_api_key = "3GMIBPWp0tydudN889B46AYvhLZ5yeJ6tDFJ5bFyVD1JqFqph6KaJQQJ99BCACfhMk5XJ3w3AAABACOGY8Xg"
gpt_4o_2_endpoint = "https://aipnavaioai02.openai.azure.com"
gpt_4o_2_version = "2024-10-21" 
gpt_4o_2_deploymentname = "gpt-4o-std"

minio_api_key = "CHANGE AFTER INSTALL"
minio_secret_key = "CHANGE AFTER INSTALL"
minio_convo_bucket = "data"
#minio_reference_bucket = "reference_dev"
minio_root_user = "minio-user"
minio_root_password = "minio-password"
minio_host = "minio-service:9000"

qdrant_host = "http://qdrant-service"
qdrant_port = "6333"

grant_type = "password"
print("########## AUTHENTICATING TO KEYCLOAK ##########")
if config["username"] and config["password"]:
    username = config["username"]
    password = config["password"]
else:
    username = input("Enter your username: ")
    password = getpass.getpass("Enter your password: ")

r = requests.get(f"{backend}/authentication/", verify=False)
print("########## AUTHENTICATION CONFIG ##########")
print(json.dumps(r.json(), indent=4))
auth_config = r.json()["config"]

keycloak_url = f"{auth_config['authority']}/protocol/openid-connect/token"
client_id = auth_config["clientId"]
client_secret = auth_config["clientSecret"]

token_response = requests.post(
    keycloak_url,
    data={
        "client_id": client_id,
        "username": username,
        "password": password,
        "client_secret": client_secret,
        "grant_type": grant_type,
    },
    headers={"Content-Type": "application/x-www-form-urlencoded"},
)

if token_response.status_code == 200:
    token_data = token_response.json()
    bearer_token = token_data["access_token"]
    print("RETRIEVED TOKEN, CREATING DEFAULT MODULES")
else:
    raise Exception(
        "Failed to retrieve token:", token_response.status_code, token_response.text
    )

if bearer_token:
    auth_headers = {"Authorization": f"Bearer {bearer_token}"}
else:
    raise Exception("Bearer token not found, exiting script.")

# Azure OpenAI modules
azure_openai_modules = [
    {
        "name": "GPT4o on Azure (AIP-HPS)",
        "supportedInputs": [
            "IMAGE",
            "TEXT"
        ],
        "specId": "d7975f09-2b33-4ddf-bc29-cdc6c64a6781",
        "parameters": [
            {
                "name": "M_LLM_AZURE_OPENAI_API_KEY",
                "value": gpt_4o_1_api_key,
            },
            {"name": "M_LLM_AZURE_OPENAI_API_VERSION", "value": gpt_4o_1_version},
            {"name": "M_LLM_AZURE_OPENAI_DEPLOYMENT_NAME", "value": gpt_4o_1_deploymentname},
            {
                "name": "M_LLM_AZURE_OPENAI_ENDPOINT",
                "value": gpt_4o_1_endpoint
            },
            {"name": "M_LLM_AZURE_OPENAI_MODEL_NAME", "value": "gpt-4o"},
        ],
    },
    {
        "name": "GPT4o on Azure (AIP-NAVAI)",
        "supportedInputs": [
            "IMAGE",
            "TEXT"
        ],
        "specId": "d7975f09-2b33-4ddf-bc29-cdc6c64a6781",
        "parameters": [
            {
                "name": "M_LLM_AZURE_OPENAI_API_KEY",
                "value": gpt_4o_2_api_key,
            },
            {"name": "M_LLM_AZURE_OPENAI_API_VERSION", "value": gpt_4o_2_version},
            {"name": "M_LLM_AZURE_OPENAI_DEPLOYMENT_NAME", "value": gpt_4o_2_deploymentname},
            {
                "name": "M_LLM_AZURE_OPENAI_ENDPOINT",
                "value": gpt_4o_2_endpoint
            },
            {"name": "M_LLM_AZURE_OPENAI_MODEL_NAME", "value": "gpt-4o"},
        ],
    },
    {
        "name": "Text Embedding 3 Large (AIP-HPS)",
        "specId": "846232c8-b6e9-4ee2-87ab-3e173768f06c",
        "parameters": [
            {
                "name": "M_EMB_AZURE_OPENAI_API_KEY",
                "value": oai_embed_1_api_key,
            },
            {"name": "M_EMB_AZURE_OPENAI_API_VERSION", "value": oai_embed_1_version},
            {"name": "M_EMB_AZURE_OPENAI_DEPLOYMENT_NAME", "value": oai_embed_1_deploymentname},
            {
                "name": "M_EMB_AZURE_OPENAI_ENDPOINT",
                "value": oai_embed_1_endpoint,
            },
            {
                "name": "M_EMB_AZURE_OPENAI_MODEL_NAME",
                "value": "text-embedding-3-large",
            },
        ],
    },
    {
        "name": "Text Embedding 3 Large (AIP-NAVAI)",
        "specId": "846232c8-b6e9-4ee2-87ab-3e173768f06c",
        "parameters": [
            {
                "name": "M_EMB_AZURE_OPENAI_API_KEY",
                "value": oai_embed_2_api_key,
            },
            {"name": "M_EMB_AZURE_OPENAI_API_VERSION", "value": oai_embed_2_version},
            {"name": "M_EMB_AZURE_OPENAI_DEPLOYMENT_NAME", "value": oai_embed_2_deploymentname},
            {
                "name": "M_EMB_AZURE_OPENAI_ENDPOINT",
                "value": oai_embed_2_endpoint,
            },
            {
                "name": "M_EMB_AZURE_OPENAI_MODEL_NAME",
                "value": "text-embedding-3-large",
            },
        ],
    },
]

# Vector Store modules
vector_store_modules = [
    {
        "name": "Qdrant Vector Store (Conversations)",
        "specId": "6be9447d-b45e-4563-af34-22d44fbde905",
        "parameters": [
            {"name": "M_VECTOR_STORE_QDRANT_URL", "value": qdrant_host},
            {"name": "M_VECTOR_STORE_QDRANT_PORT", "value": qdrant_port},
            {"name": "M_VECTOR_STORE_QDRANT_INDEX_NAME", "value": "conversations"},
            {"name": "M_VECTOR_STORE_QDRANT_HTTPS", "value": "false"},
            {"name": "M_VECTOR_STORE_QDRANT_HTTPS_VERIFY", "value": "false"},
        ],
    },
    {
        "name": "Qdrant Vector Store (Data)",
        "specId": "6be9447d-b45e-4563-af34-22d44fbde905",
        "parameters": [
            {"name": "M_VECTOR_STORE_QDRANT_URL", "value": qdrant_host},
            {"name": "M_VECTOR_STORE_QDRANT_PORT", "value": qdrant_port},
            {"name": "M_VECTOR_STORE_QDRANT_INDEX_NAME", "value": "data"},
            {"name": "M_VECTOR_STORE_QDRANT_HTTPS", "value": "false"},
            {"name": "M_VECTOR_STORE_QDRANT_HTTPS_VERIFY", "value": "false"},
        ],
    },
]

# File Storage modules
file_storage_modules = [
    {
        "name": "MinIO File Storage",
        "specId": "1e77cd2f-39d4-457a-84bd-950ea488cac3",
        "parameters": [
            {"name": "M_FS_MINIO_SERVER_URL", "value": minio_host},
            {"name": "M_FS_MINIO_ACCESS_KEY", "value": minio_api_key},
            {"name": "M_FS_MINIO_SECRET_KEY", "value": minio_secret_key},
            {"name": "M_FS_MINIO_BUCKET_NAME", "value": minio_convo_bucket},
            {"name": "M_FS_MINIO_SSL", "value": "false"},
            {"name": "M_FS_MINIO_VERIFY_SSL_CERT", "value": "false"},
        ],
    },
]

# NVIDIA VSS modules
nvidia_vss_modules = [
    {    
        "name": "NVIDIA VSS Storage (Demo)",
        "specId": "df96ca9b-45ad-478d-8acd-91d2ae38c9b6", 
        "parameters": [
            {
                "name": "M_FS_NVIDIA_VSS_URI",
                "value": "http://34.45.199.71:32145"
            }
        ],  
    },
    {
        "name": "NVIDIA VSS (Demo)",
        "specId": "c7bf8553-f4b5-4f2e-a168-b1ff3bd23cd4",
        "parameters": [
            {
                "name": "M_VSS_NVIDIA_NIM_BASE_URL",
                "value": "http://34.45.199.71:32145"
            },
            {
                "name": "M_LLM_NVIDIA_VSS_SUMMARIZE_PROMPT",
                "value": "Generate a clear summary for the provided video."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_CAPTION_SUMMARIZATION_PROMPT",
                "value": "No special instructions required."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_SUMMARY_AGGREGATION_PROMPT",
                "value": "No special instructions required."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_USE_NVIDIA_RECOMMENDATION_SERVICE_FOR_CHUNKING",
                "value": "True"
            },
            {
                "name": "M_LLM_NVIDIA_MAX_TOKENS",
                "value": "512"
            },
            {
                "name": "M_LLM_NVIDIA_TEMPERATURE",
                "value": "0.2"
            },
            {
                "name": "M_LLM_NVIDIA_TOP_P",
                "value": "1.0"
            },
            {
                "name": "M_LLM_NVIDIA_TOP_K",
                "value": "100"
            },
            {
                "name": "M_LLM_NVIDIA_SEED",
                "value": "10"
            }
        ],
    },
    {
        "name": "NVIDIA VSS Storage (Dev)",
        "specId": "df96ca9b-45ad-478d-8acd-91d2ae38c9b6",
        "parameters": [
            {
                "name": "M_FS_NVIDIA_VSS_URI",
                "value": "http://35.194.26.157:31425"
            }
        ],
    },
    {
        "name": "NVIDIA VSS (Dev)",
        "specId": "c7bf8553-f4b5-4f2e-a168-b1ff3bd23cd4",
        "parameters": [
            {
                "name": "M_VSS_NVIDIA_NIM_BASE_URL",
                "value": "http://35.194.26.157:31425"
            },
            {
                "name": "M_LLM_NVIDIA_VSS_SUMMARIZE_PROMPT",
                "value": "Generate a clear summary for the provided video."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_CAPTION_SUMMARIZATION_PROMPT",
                "value": "No special instructions required."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_SUMMARY_AGGREGATION_PROMPT",
                "value": "No special instructions required."
            },
            {
                "name": "M_LLM_NVIDIA_VSS_USE_NVIDIA_RECOMMENDATION_SERVICE_FOR_CHUNKING",
                "value": "True"
            },
            {
                "name": "M_LLM_NVIDIA_MAX_TOKENS",
                "value": "512"
            },
            {
                "name": "M_LLM_NVIDIA_TEMPERATURE",
                "value": "0.2"
            },
            {
                "name": "M_LLM_NVIDIA_TOP_P",
                "value": "1.0"
            },
            {
                "name": "M_LLM_NVIDIA_TOP_K",
                "value": "100"
            },
            {
                "name": "M_LLM_NVIDIA_SEED",
                "value": "10"
            }
        ],
    },
    
]

# NVIDIA API model modules
nvidia_model_modules = [
    {
        "name": "NVIDIA - granite-8b-code-instruct #1",
        "specId": "c1befa38-b299-467f-9fb9-81ff6c583c91",
        "parameters": [
            {
                "name": "M_LLM_NVIDIA_NIM_MODEL_NAME",
                "value": "ibm/granite-8b-code-instruct"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_BASE_URL",
                "value": "https://integrate.api.nvidia.com/v1"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_API_KEY",
                "value": "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"
            }
        ],
    },
    {
        "name": "NVIDIA - granite-8b-code-instruct #2",
        "specId": "c1befa38-b299-467f-9fb9-81ff6c583c91",
        "parameters": [
            {
                "name": "M_LLM_NVIDIA_NIM_MODEL_NAME",
                "value": "ibm/granite-8b-code-instruct"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_BASE_URL",
                "value": "https://integrate.api.nvidia.com/v1"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_API_KEY",
                "value": "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"
            }
        ],
    },
    {
        "name": "NVIDIA - llama-3.1-nemotron-70b-instruct #1",
        "specId": "c1befa38-b299-467f-9fb9-81ff6c583c91",
        "parameters": [
            {
                "name": "M_LLM_NVIDIA_NIM_MODEL_NAME",
                "value": "nvidia/llama-3.1-nemotron-70b-instruct"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_BASE_URL",
                "value": "https://integrate.api.nvidia.com/v1"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_API_KEY",
                "value": "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"
            }
        ],
    },
    {
        "name": "NVIDIA - llama-3.1-nemotron-70b-instruct #2",
        "specId": "c1befa38-b299-467f-9fb9-81ff6c583c91",
        "parameters": [
            {
                "name": "M_LLM_NVIDIA_NIM_MODEL_NAME",
                "value": "nvidia/llama-3.1-nemotron-70b-instruct"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_BASE_URL",
                "value": "https://integrate.api.nvidia.com/v1"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_API_KEY",
                "value": "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"
            }
        ],
    },
    {
        "name": "NVIDIA - llama-3.2-90b-vision-instruct (Multimodal)",
        "specId": "c1befa38-b299-467f-9fb9-81ff6c583c91",
        "parameters": [
            {
                "name": "M_LLM_NVIDIA_NIM_MODEL_NAME",
                "value": "meta/llama-3.2-90b-vision-instruct"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_BASE_URL",
                "value": "https://ai.api.nvidia.com/v1/gr/meta/llama-3.2-90b-vision-instruct/chat/completions"
            },
            {
                "name": "M_LLM_NVIDIA_NIM_API_KEY",
                "value": "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"
            }
        ],
    },
]

# Build the modules array based on enabled sections
modules = []
if ENABLE_AZURE_OPENAI:
    modules.extend(azure_openai_modules)
if ENABLE_VECTOR_STORES:
    modules.extend(vector_store_modules)
if ENABLE_FILE_STORAGE:
    modules.extend(file_storage_modules)
if ENABLE_NVIDIA_VSS:
    modules.extend(nvidia_vss_modules)
if ENABLE_NVIDIA_MODELS:
    modules.extend(nvidia_model_modules)

r = requests.get(f"{backend}/modules", headers=auth_headers)
if r.status_code != 200:
    raise Exception(f"Failed to retrieve modules: {r.status_code}")
existing_modules = r.json()

# Build a dict for fast lookup by name
existing_modules_by_name = {m["name"]: m for m in existing_modules}

for module in modules:
    # Ensure supportedInputs is always present and is a list
    if "supportedInputs" not in module:
        module["supportedInputs"] = []
    elif not isinstance(module["supportedInputs"], list):
        module["supportedInputs"] = list(module["supportedInputs"])

    existing = existing_modules_by_name.get(module["name"])
    if existing:
        # Ensure supportedInputs is present in existing for comparison
        if "supportedInputs" not in existing:
            existing["supportedInputs"] = []
        # Check if any relevant fields differ
        needs_update = False
        for k in ["description", "supportedInputs", "specId", "parameters"]:
            if k in module and module[k] != existing.get(k, [] if k == "supportedInputs" else None):
                needs_update = True
        if needs_update:
            updated_module = existing.copy()
            for k in ["description", "supportedInputs", "specId", "parameters"]:
                if k in module:
                    updated_module[k] = module[k]
            put_url = f"{backend}/module/{existing['id']}"
            r = requests.put(put_url, json=updated_module, headers=auth_headers)
            if r.status_code != 200:
                print(f"Failed to update module {module['name']}: {r.status_code}")
                print(r.text)
            else:
                print(f"Module {module['name']} updated successfully!")
                print(r.json().get("modifiedAt"))
                print(r.json()["modifier"]["name"])
                print(r.json().get("name"))
        else:
            print(f"Module {module['name']} is up to date, skipping update.")
    else:
        # Ensure supportedInputs is present in POST payload
        if "supportedInputs" not in module:
            module["supportedInputs"] = []
        r = requests.post(f"{backend}/module", json=module, headers=auth_headers)
        if r.status_code != 200:
            print(f"Failed to create module {module['name']}: {r.status_code}")
            print(r.text)
        else:
            print(f"Module {module['name']} created successfully!")
            print(r.json().get("createdAt"))
            print(r.json()["creator"]["name"])
            print(r.json().get("name"))
