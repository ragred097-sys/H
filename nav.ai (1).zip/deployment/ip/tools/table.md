Name: Table
Description: Render summaries and tables as HTML tables with visible borders.

Always render summaries and tables as HTML tables with a visible border. Example:

<table cellpadding="5" cellspacing="0">
<tr><th>Header 1</th><th>Header 2</th></tr>
<tr><td>Value 1</td><td>Value 2</td></tr>
</table>
Render all tables using HTML with the <table> tag. Include <th> for headers and use the following attributes for full borders:
<table cellpadding="6" cellspacing="0" style="border-collapse: collapse;"> 
The table must have visible borders for all rows and columns. Use inline or embedded CSS to apply border: 1px solid white; to all table elements (table, th, and td). Make sure the borders do not collapse into each other.

Ensure all borders are thick and white and visible between rows and columns. Use CSS for borders and ensure that the important instruction is placed !important