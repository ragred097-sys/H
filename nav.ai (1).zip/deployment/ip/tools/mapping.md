Name: Mapping
Description: Create interactive maps with custom data.

GeoRenderer - Interactive Map Component
=======================================

Example User Queries
--------------------

*   "Generate a map with multiple points in London."
*   "How can I create a polygon area around these coordinates?"
*   "Create a radius of 500 meters around this point."
*   "How do I customize the popup content for my markers?"
*   "Help me set up a map with both points and areas."

Rules
-----

*   Provide 1 text response followed by the map data
*   Do not mention the word JSON in your text response
*   MOST IMPORTANT generate valid JSON only: no comments, special characters, or syntax errors
*   Relevant data in the context must be used, no placeholder or example in the json
*   Area coordinates must be in clockwise order
*   Coordinates must be accurate

Data Formats for GeoRenderer
----------------------------

### Point Map

[GEO]{ "type": "point", "center": { "lat": 51.505, "lng": -0.09 }, "zoom": 13, "tileLayerKey": "Google", "data": { "points": [{ "lat": 51.505, "lng": -0.09, "label": "London Point", "popup": "<h3>London Location</h3><p>Description here</p>" }] }, "options": { "maxZoom": 18, "scrollWheelZoom": true } }[/GEO]

### Area Map

[GEO]{ "type": "area", "center": { "lat": 51.505, "lng": -0.09 }, "zoom": 13, "tileLayerKey": "ArcGIS", "data": { "areas": [{ "coordinates": [ {"lat": 51.509, "lng": -0.08}, {"lat": 51.503, "lng": -0.06}, {"lat": 51.51, "lng": -0.047} ], "color": "#ff7800", "fillColor": "#ff7800", "label": "London Area", "popup": "Area Description" }] } }[/GEO]

### Radius Map

[GEO]{ "type": "radius", "center": { "lat": 51.505, "lng": -0.09 }, "zoom": 14, "tileLayerKey": "OpenStreetMap", "data": { "radiuses": [{ "center": { "lat": 51.505, "lng": -0.09 }, "radius": 500, "color": "#ff4400", "fillColor": "#ff4400", "label": "Coverage Area", "popup": "500m Radius Zone" }] } }[/GEO]

### Combined Map

[GEO]{ "type": "point", "center": { "lat": 51.505, "lng": -0.09 }, "zoom": 13, "data": { "points": [{ "lat": 51.505, "lng": -0.09, "label": "Center" }], "areas": [{ "coordinates": [ {"lat": 51.509, "lng": -0.08}, {"lat": 51.503, "lng": -0.06}, {"lat": 51.51, "lng": -0.047} ], "color": "#ff7800" }], "radiuses": [{ "center": {"lat": 51.505, "lng": -0.09}, "radius": 500 }] }, "options": { "maxZoom": 18, "minZoom": 10, "dragging": true, "scrollWheelZoom": true } }[/GEO]